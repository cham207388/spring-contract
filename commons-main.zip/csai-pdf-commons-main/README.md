# USCIS PDF Commons Library:

A library of common classes used by multiple services of the [csai-pdf-intake](https://git.uscis.dhs.gov/USCIS/csai-pdf-intake) project

## Up and running

### Requirements

Learn more about system [configuration prerequisites](README-requirements.md) for building USCIS PDF Commons Library

### Building the library

You can build this library locally by running this command from the root directory


```bash
./gradlew clean build
```
The built library artifact will be located in `build/libs/csai-pdf-commons-0.0.1-SNAPSHOT.jar`

### Publishing the library (on local)
To use this built library from csai-pdf-commons, publish it to Maven local like so:
```bash
./gradlew publishToMavenLocal
```
You'll find the built artifacts here:
```
~/.m2/repository/gov/dhs/uscis/intake/pdf-commons-library/local
```
So you'll reference it in local csai-pdf-intake like so (in build.gradles):
```
implementation 'gov.dhs.uscis.intake:pdf-commons-library:local'
```

### Publishing the library (in PR and beyond)
The PR pipeline for csai-pdf-commons automatically builds and publishes the library with a semantic version (based on source control) to Nexus repository. You can browse all the available versions here:

[https://nexus-nonprod-gss.uscis.dhs.gov/nexus/#browse/browse:myuscis-csai-maven:gov%2Fdhs%2Fuscis%2Fintake%2Fpdf-commons-library](https://nexus-nonprod-gss.uscis.dhs.gov/nexus/#browse/browse:myuscis-csai-maven:gov%2Fdhs%2Fuscis%2Fintake%2Fpdf-commons-library)

To build and deploy csai-pdf-intake to environments outside your local, you'll need to specify the appropriate version of csai-pdf-commons in the build.gradle files like so:
```
// here, we're showing version 0.0.212 as an example
implementation 'gov.dhs.uscis.intake:pdf-commons-library:0.0.212'
```


