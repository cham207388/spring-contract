# PDF Intake Commons Library Requirements
This library has similar prerequisites as csai-pdf-intake, so if you're having trouble setting up you system, refer to that [README](https://git.uscis.dhs.gov/USCIS/csai-pdf-intake/blob/main/README.md) as well.

1. Set these environment variables like so ( add these entries to .zshrc ):
```
export http_proxy=http://preproxy.uscis.dhs.gov:80
export HTTP_PROXY=$http_proxy
export https_proxy=$http_proxy
export no_proxy=localhost,127.0.0.1,.uscis.dhs.gov,uscis.dhs.gov,nexus-gss.uscis.dhs.gov,nexus-nonprod-gss.uscis.dhs.gov,nonprod-preproxy.uscis.dhs.gov,preproxy.uscis.dhs.gov
export NO_PROXY=$no_proxy
```

2.  **Docker** installed. Docker Desktop in Self Service is fine. Make sure the following is set in Settings > Resources > Proxy:

    Manual proxy configuration = `true`
    Use the same values as http_proxy and https_proxy env values (from previous step above) to set Web Server (HTTP) and Secure Web Server (HTTPS) respectively. Under ‘Bypass proxy settings…’ use the same value as no_proxy.



3.  **Node** installed, preferably via `nvm`. As of writing, v20 is the latest with longest term of support.
4.  **Java21** installed. This is easily managed with [JEnv](https://www.jenv.be/).

    * In Self Service, search for "java" and install **Java JDK 21.0.4**.
    * Install JEnv using Homebrew.
        ```bash
        brew install jenv
        ```
    * Per the installation instructions, add these lines to your ~/.zshrc file:
        ```bash
        export PATH="$HOME/.jenv/bin:$PATH"
        eval "$(jenv init -)"
        ```
    * Restart your shell window and verify $JAVA_HOME is set:
        ```bash
        echo $JAVA_HOME
        ```
    * Add the JVM install to JEnv's list:
        ```bash
        jenv add /Library/Java/JavaVirtualMachines/jdk-21.jdk/Contents/Home/
        jenv versions
        ```
    * Configure your project root to use that JVM
        ```bash
        cd ~/<path to project dir>/csai-pdf-intake
        jenv local 21
        ```