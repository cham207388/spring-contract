
package gov.dhs.uscis.intake.enums;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import org.junit.jupiter.api.Test;

public class ReasonForFilingTest {

    @Test
    void shouldGetInitialString() {
        assertThat(ReasonForFiling.INITIAL).hasToString("Initial");
    }

    @Test
    void shouldGetReplacementString() {
        assertThat(ReasonForFiling.REPLACEMENT).hasToString("Replacement");
    }

    @Test
    void shouldGetRenewalString() {
        assertThat(ReasonForFiling.RENEWAL).hasToString("Renewal");
    }

    @Test
    void shouldGetInitialEnumFromString() {
        assertThat(ReasonForFiling.fromString("Initial")).isEqualTo(ReasonForFiling.INITIAL);
    }

     @Test
    void shouldGetReplacementEnumFromString() {
        assertThat(ReasonForFiling.fromString("Replacement")).isEqualTo(ReasonForFiling.REPLACEMENT);
    }

    @Test
    void shouldGetRenewalEnumFromString() {
        assertThat(ReasonForFiling.fromString("Renewal")).isEqualTo(ReasonForFiling.RENEWAL);
    }

    @Test
    void shouldThrowWhenReasonFromStringNotSupported() {
        assertThrows(IllegalArgumentException.class, () ->
            ReasonForFiling.fromString("invalid"));
    }

    @Test
    void shouldConvertInitialFormEntryToEnum() {
        assertThat(ReasonForFiling.fromFormEntry("1.a.")).isEqualTo(ReasonForFiling.INITIAL);
    }

    @Test
    void shouldConvertReplacementFormEntryToEnum() {
        assertThat(ReasonForFiling.fromFormEntry("1.b.")).isEqualTo(ReasonForFiling.REPLACEMENT);
    }

    @Test
    void shouldConvertRenewalFormEntryToEnum() {
        assertThat(ReasonForFiling.fromFormEntry("1.c.")).isEqualTo(ReasonForFiling.RENEWAL);
    }

    @Test
    void shouldThrowWhenNullFormEntryReceived() {
        assertThrows(UnsupportedOperationException.class, () -> ReasonForFiling.fromFormEntry(null));
    }

    @Test
    void shouldThrowWhenUnknownFormEntryReceived() {
        assertThrows(UnsupportedOperationException.class, () -> ReasonForFiling.fromFormEntry("unknown"));
    }

    @Test
    void shouldReturnTrueIfEligibilityCategoryIsApplicable() {
        assertTrue(ReasonForFiling.isApplicableToEligibilityCategory(I765EligibilityCategory.C11UKRAINE));
    }

    @Test
    void shouldReturnFalseIfEligibilityCategoryIsNotApplicable() {
        assertFalse(ReasonForFiling.isApplicableToEligibilityCategory(I765EligibilityCategory.C9));
    }
}
