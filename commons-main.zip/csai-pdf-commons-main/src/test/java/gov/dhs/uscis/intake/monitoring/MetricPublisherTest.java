package gov.dhs.uscis.intake.monitoring;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.EntityType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest.SubmissionUpdate;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest.ManifestUpdate;
import software.amazon.awssdk.services.cloudwatch.CloudWatchClient;
import software.amazon.awssdk.services.cloudwatch.model.PutMetricDataRequest;
import software.amazon.awssdk.services.cloudwatch.model.StandardUnit;

class MetricPublisherTest {

    private CloudWatchClient cloudWatchClient;

    @BeforeEach
    public void setup(){
        cloudWatchClient = mock(CloudWatchClient.class);
    }

    @Test
    void shouldPublishMetric(){
        String namespace = "PDFI/Payments";
        var metricPublisher = new MetricPublisher("fake", cloudWatchClient);
        MetricAware metricAware = mock(MetricAware.class);
        when(metricAware.count()).thenReturn(1d);
        when(metricAware.transaction()).thenReturn(AuditableTransaction.AcceptedPayment);
        when(metricAware.namespace()).thenReturn(namespace);

        metricPublisher.postMetric(mock(ProceedingJoinPoint.class), metricAware );
        ArgumentCaptor<PutMetricDataRequest> captor = ArgumentCaptor.forClass(PutMetricDataRequest.class);
        verify(cloudWatchClient).putMetricData(captor.capture());
        PutMetricDataRequest request = captor.getValue();
        assertThat(request.metricData()).hasSize(1);
        assertThat(request.namespace()).isEqualTo(namespace);
        var metricData = request.metricData().get(0);
        assertThat(metricData.metricName()).isEqualTo("fake_AcceptedPayment");
        assertThat(metricData.unit()).isEqualTo(StandardUnit.COUNT);
        assertThat(metricData.value()).isEqualTo(1d);
        assertThat(metricData.dimensions()).hasSize(1);
        assertThat(metricData.dimensions().get(0).name()).isEqualTo("Transactions");
        assertThat(metricData.dimensions().get(0).value()).isEqualTo(AuditableTransaction.AcceptedPayment.toString());

    }

    @Test
    public void shouldReturnTheSubmissionIdOfASubmissionWhenThereIsAnArgument(){
        String namespace = "PDFI/Payments";
        var metricPublisher = new MetricPublisher("fake", cloudWatchClient);
        var metricAware = mock(MetricAware.class);
        when(metricAware.count()).thenReturn(1d);
        when(metricAware.namespace()).thenReturn(namespace);
        when(metricAware.transaction()).thenReturn(AuditableTransaction.AcceptedPayment);

        ProceedingJoinPoint mock = mock(ProceedingJoinPoint.class);
        Object[] args = new Object[1];
        Submission submission = new Submission();
        submission.setSubmissionId("fakeSubmissionId");
        args[0] = submission;
        when(mock.getArgs()).thenReturn(args);

        metricPublisher.postMetric(mock, metricAware );
        ArgumentCaptor<PutMetricDataRequest> captor = ArgumentCaptor.forClass(PutMetricDataRequest.class);
        verify(cloudWatchClient).putMetricData(captor.capture());
        PutMetricDataRequest request = captor.getValue();
        assertThat(request.metricData()).hasSize(1);
        assertThat(request.namespace()).isEqualTo(namespace);
        var metricData = request.metricData().get(0);
        assertThat(metricData.metricName()).isEqualTo("fake_AcceptedPayment");
        assertThat(metricData.unit()).isEqualTo(StandardUnit.COUNT);
        assertThat(metricData.value()).isEqualTo(1d);
        assertThat(metricData.dimensions()).hasSize(1);
        assertThat(metricData.dimensions().get(0).name()).isEqualTo("Transactions");
        assertThat(metricData.dimensions().get(0).value()).isEqualTo("AcceptedPayment");
    }

    @Test
    public void shouldHandleTheConditionWhereASubmissionStateChangeIsRequestedForSubmission(){
        String namespace = "PDFI/Payments";
        var metricPublisher = new MetricPublisher("fake", cloudWatchClient);
        var submissionStatusChange = mock(SubmissionStateChange.class);
        when(submissionStatusChange.count()).thenReturn(1d);
        when(submissionStatusChange.namespace()).thenReturn(namespace);

        ProceedingJoinPoint mock = mock(ProceedingJoinPoint.class);
        Object[] args = new Object[1];
        var updateRequest = new SubmissionUpdateRequest();
        updateRequest.setUpdateType(EntityType.SUBMISSION);
        SubmissionUpdate submissionUpdate = new SubmissionUpdate();
        submissionUpdate.setStatus(StatusEnum.ACCEPTED);
        updateRequest.setSubmissionUpdate(submissionUpdate);
        args[0] = updateRequest;
        when(mock.getArgs()).thenReturn(args);

        metricPublisher.postMetric(mock, submissionStatusChange );
        ArgumentCaptor<PutMetricDataRequest> captor = ArgumentCaptor.forClass(PutMetricDataRequest.class);
        verify(cloudWatchClient).putMetricData(captor.capture());
        PutMetricDataRequest request = captor.getValue();
        assertThat(request.metricData()).hasSize(1);
        assertThat(request.namespace()).isEqualTo(namespace);
        var metricData = request.metricData().get(0);
        assertThat(metricData.metricName()).isEqualTo("fake_SUBMISSION_ACCEPTED");
        assertThat(metricData.unit()).isEqualTo(StandardUnit.COUNT);
        assertThat(metricData.value()).isEqualTo(1d);
        assertThat(metricData.dimensions()).hasSize(1);
        assertThat(metricData.dimensions().get(0).name()).isEqualTo("Transactions");
        assertThat(metricData.dimensions().get(0).value()).isEqualTo("ACCEPTED");
    }

    @Test
    public void shouldHandleTheConditionWhereASubmissionStateChangeIsRequestedForSubmissionWithNullArgs(){
        String namespace = "PDFI/Payments";
        var metricPublisher = new MetricPublisher("fake", cloudWatchClient);
        var submissionStatusChange = mock(SubmissionStateChange.class);
        when(submissionStatusChange.count()).thenReturn(1d);
        when(submissionStatusChange.namespace()).thenReturn(namespace);

        ProceedingJoinPoint mock = mock(ProceedingJoinPoint.class);
        var updateRequest = new SubmissionUpdateRequest();
        updateRequest.setUpdateType(EntityType.SUBMISSION);
        SubmissionUpdate submissionUpdate = new SubmissionUpdate();
        submissionUpdate.setStatus(StatusEnum.ACCEPTED);
        updateRequest.setSubmissionUpdate(submissionUpdate);

        metricPublisher.postMetric(mock, submissionStatusChange );
        ArgumentCaptor<PutMetricDataRequest> captor = ArgumentCaptor.forClass(PutMetricDataRequest.class);
        verify(cloudWatchClient, never()).putMetricData(captor.capture());
    }

    @Test
    public void shouldHandleTheConditionWhereASubmissionStateChangeIsRequestedForManifestWithNullArgs(){
        String namespace = "PDFI/Payments";
        var metricPublisher = new MetricPublisher("fake", cloudWatchClient);
        var submissionStatusChange = mock(SubmissionStateChange.class);
        when(submissionStatusChange.count()).thenReturn(1d);
        when(submissionStatusChange.namespace()).thenReturn(namespace);

        ProceedingJoinPoint mock = mock(ProceedingJoinPoint.class);
        var updateRequest = new SubmissionUpdateRequest();
        updateRequest.setUpdateType(EntityType.MANIFEST);
        var update = new ManifestUpdate();
        update.setStatus(StatusEnum.ACCEPTED);
        updateRequest.setManifestUpdate(update);

        metricPublisher.postMetric(mock, submissionStatusChange );
        ArgumentCaptor<PutMetricDataRequest> captor = ArgumentCaptor.forClass(PutMetricDataRequest.class);
        verify(cloudWatchClient, never()).putMetricData(captor.capture());
    }

    @Test
    public void shouldHandleTheConditionWhereASubmissionStateChangeIsRequestedForManifest(){
        var namespace = "PDFI/Submissions";
        var metricPublisher = new MetricPublisher("fake", cloudWatchClient);
        var submissionStatusChange = mock(SubmissionStateChange.class);
        when(submissionStatusChange.count()).thenReturn(1d);
        when(submissionStatusChange.namespace()).thenReturn(namespace);

        ProceedingJoinPoint mock = mock(ProceedingJoinPoint.class);
        Object[] args = new Object[1];
        var updateRequest = new SubmissionUpdateRequest();
        updateRequest.setUpdateType(EntityType.MANIFEST);
        ManifestUpdate manifestUpdate = new ManifestUpdate();
        manifestUpdate.setStatus(StatusEnum.ACCEPTED);
        updateRequest.setManifestUpdate(manifestUpdate);
        args[0] = updateRequest;
        when(mock.getArgs()).thenReturn(args);

        metricPublisher.postMetric(mock, submissionStatusChange );
        ArgumentCaptor<PutMetricDataRequest> captor = ArgumentCaptor.forClass(PutMetricDataRequest.class);
        verify(cloudWatchClient).putMetricData(captor.capture());
        PutMetricDataRequest request = captor.getValue();
        assertThat(request.metricData()).hasSize(1);
        assertThat(request.namespace()).isEqualTo(namespace);
        var metricData = request.metricData().get(0);
        assertThat(metricData.metricName()).isEqualTo("fake_SUBMISSION_ACCEPTED");
        assertThat(metricData.unit()).isEqualTo(StandardUnit.COUNT);
        assertThat(metricData.value()).isEqualTo(1d);
        assertThat(metricData.dimensions()).hasSize(1);
        assertThat(metricData.dimensions().get(0).name()).isEqualTo("Transactions");
        assertThat(metricData.dimensions().get(0).value()).isEqualTo("ACCEPTED");
    }
}
