package gov.dhs.uscis.intake.monitoring;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

public class MDCInterceptorTest {

    private MDCInterceptor unitUnderTest;
    private HttpServletRequest request;
    private HttpServletResponse response;
    private static final String HEADER = "X-Correlation-ID";

    @BeforeEach
    public void setup() {
        unitUnderTest = new MDCInterceptor(HEADER);
        request = mock(HttpServletRequest.class);
        response = mock(HttpServletResponse.class);
    }

    @Test
    public void testPreHandle_generates_id() throws Exception {
        when(request.getHeader(HEADER)).thenReturn("");
        boolean result = unitUnderTest.preHandle(request, response, null);
        assertEquals("preHandle should return true", true, result);
        String actualId = MDC.get("TRACER");
        assertNotNull(actualId);
    }

    @Test
    public void testPreHandle_reads_id() throws Exception {
        String expectedId = "not blank";
        when(request.getHeader(HEADER)).thenReturn(expectedId);
        boolean result = unitUnderTest.preHandle(request, response, null);
        assertEquals("preHandle should return true", true, result);

        String actualId = MDC.get("TRACER");
        assertNotNull(actualId);
        assertEquals("expected id should match", expectedId, actualId);
    }

    @Test
    public void testPostHandle() throws Exception {
        unitUnderTest.postHandle(request, response, null, null);
        assertTrue("intentionally left empty", true);
    }

    @Test
    public void testAfterCompletion() throws Exception {
        String actualId = "id";
        MDC.put("TRACER", actualId);
        unitUnderTest.afterCompletion(request, response, null, null);
        assertNull("expected id should be empty", MDC.get(actualId));
    }
}