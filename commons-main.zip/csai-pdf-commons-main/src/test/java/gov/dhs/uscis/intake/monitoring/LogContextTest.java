package gov.dhs.uscis.intake.monitoring;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class LogContextTest {

    @BeforeEach
    @AfterEach
    void clearMdc() {
        MDC.clear();
    }

    @Test
    void testSinglePutAddsAndRemoves() {
        assertNull(MDC.get("userId"), "MDC should be empty initially");

        try (LogContext ctx = LogContext.put("userId", "Kabir123")) {
            assertEquals("Kabir123", MDC.get("userId"), "Value should be present inside try block");
        }

        assertNull(MDC.get("userId"), "Value should be removed after try-with-resources");
    }

    @Test
    void testFluentAndAddsMultiple() {
        try (LogContext ctx = LogContext.put("key1", "val1")
                                        .and("key2", "val2")) {
            assertEquals("val1", MDC.get("key1"));
            assertEquals("val2", MDC.get("key2"));
        }

        assertNull(MDC.get("key1"));
        assertNull(MDC.get("key2"));
    }

    @Test
    void testPutAll() {
        Map<String, String> data = Map.of("appId", "A1", "status", "active");

        try (LogContext ctx = LogContext.putAll(data)) {
            assertEquals("A1", MDC.get("appId"));
            assertEquals("active", MDC.get("status"));
        }

        assertNull(MDC.get("appId"));
        assertNull(MDC.get("status"));
    }

    @Test
    void testCleanupOnException() {
        assertThrows(RuntimeException.class, () -> {
            try (LogContext ctx = LogContext.put("errorKey", "errorVal")) {
                assertEquals("errorVal", MDC.get("errorKey"));
                throw new RuntimeException("Simulated error");
            }
        });

        // This is the most important check: ensuring cleanup even after a crash
        assertNull(MDC.get("errorKey"), "MDC should be cleared even if an exception is thrown");
    }

    @Test
    void testNestedContexts() {
        // Verification that inner contexts don't accidentally wipe outer context keys
        try (LogContext outer = LogContext.put("outerKey", "outerVal")) {
            assertEquals("outerVal", MDC.get("outerKey"));

            try (LogContext inner = LogContext.put("innerKey", "innerVal")) {
                assertEquals("outerVal", MDC.get("outerKey"));
                assertEquals("innerVal", MDC.get("innerKey"));
            }

            assertNull(MDC.get("innerKey"), "Inner key should be gone");
            assertEquals("outerVal", MDC.get("outerKey"), "Outer key should still exist");
        }
        
        assertNull(MDC.get("outerKey"), "Outer key should be gone now");
    }

    @Test
    void testNullSafety() {
        // Ensure the helper doesn't crash if passed nulls (per the null checks we added)
        assertDoesNotThrow(() -> {
            try (LogContext ctx = LogContext.put(null, null)) {
                // Should just do nothing
            }
        });
    }
}
