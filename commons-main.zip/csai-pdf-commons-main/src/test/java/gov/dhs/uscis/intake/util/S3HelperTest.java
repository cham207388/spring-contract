package gov.dhs.uscis.intake.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import gov.dhs.uscis.intake.constants.MetadataConstants;

import java.util.stream.IntStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.core.io.ClassPathResource;

import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.http.AbortableInputStream;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.HeadObjectResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

class S3HelperTest {

    @Test
    void shouldTransformS3KeyWithSpaceInsteadOfPlus() {
        String key = "Test+%28Key%29+%28test%29.pdf";

        assertEquals("Test (Key) (test).pdf", S3Helper.transformS3Key(key));
    }

    @Test
    public void shouldFlattenAndUploadSelectPagesOfFormToS3() throws IOException {
        String key = "objectKey.pdf";
        String bucketName = "default-form";
        String name = "name";
        String strippedPageObjectKey = "objectKey_name_pages_1_2_3_4_5_6_7.pdf";
        String documentId = "formId";
        String submissionId = "submissionId";
        String myUscisId = "uscisid";

        S3Client s3Client = mock(S3Client.class);

        Map<String, String> metadata = new HashMap<>();
        metadata.put("id", documentId);
        metadata.put("submissionid", submissionId);
        metadata.put("myuscisid", myUscisId);

        HeadObjectResponse headObjectResponse = HeadObjectResponse.builder().metadata(metadata).build();

        when(s3Client.headObject(any(HeadObjectRequest.class))).thenReturn(headObjectResponse);
        File file = new ClassPathResource("test-files/multi-edition-i765.pdf").getFile();
        byte[] bytes = Files.readAllBytes(Paths.get(file.toURI()));

        when(s3Client.getObject(any(GetObjectRequest.class))).thenReturn(new ResponseInputStream<>(
                GetObjectResponse.builder().metadata(
                        metadata).build(),
                AbortableInputStream.create(new ByteArrayInputStream(bytes))));
        // act
        PDDocument documentSpy = Loader.loadPDF(file);
        try (MockedStatic<Loader> mockLoader = Mockito.mockStatic(Loader.class);
             MockedStatic<LosslessFactory> losslessFactory = Mockito.mockStatic(LosslessFactory.class)) {

            mockLoader.when(() -> Loader.loadPDF(any(byte[].class))).thenReturn(documentSpy);

            String actual = S3Helper.getStrippedPdf(s3Client, key, bucketName, IntStream.rangeClosed(1, 7).boxed().toList(), name, true);

            // assert
            ArgumentCaptor<PutObjectRequest> captor = ArgumentCaptor.forClass(PutObjectRequest.class);
            verify(s3Client, times(1)).putObject(captor.capture(), any(RequestBody.class));
            verify(s3Client, times(1)).getObject(any(GetObjectRequest.class));
            losslessFactory.verify(()-> LosslessFactory.createFromImage(any(PDDocument.class), any(BufferedImage.class)), times(7));
            assertEquals(key, captor.getValue().metadata().get(MetadataConstants.ORIGINAL_S3_KEY));
            assertEquals(strippedPageObjectKey, actual);
            assertEquals(documentId, captor.getValue().metadata().get(MetadataConstants.ID));
            assertEquals(submissionId, captor.getValue().metadata().get(MetadataConstants.SUBMISSIONID));
            assertEquals(myUscisId, captor.getValue().metadata().get(MetadataConstants.MYUSCISID));
        }

    }

    @Test
    public void shouldUploadAndNotFlattenSelectPagesOfFormToS3() throws IOException {
        String key = "objectKey.pdf";
        String bucketName = "default-form";
        String name = "name";
        String strippedPageObjectKey = "objectKey_name_pages_4.pdf";
        String documentId = "formId";
        String submissionId = "submissionId";
        String myUscisId = "uscisid";

        S3Client s3Client = mock(S3Client.class);

        Map<String, String> metadata = new HashMap<>();
        metadata.put("id", documentId);
        metadata.put("submissionid", submissionId);
        metadata.put("myuscisid", myUscisId);

        HeadObjectResponse headObjectResponse = HeadObjectResponse.builder().metadata(metadata).build();

        when(s3Client.headObject(any(HeadObjectRequest.class))).thenReturn(headObjectResponse);
        File file = new ClassPathResource("test-files/multi-edition-i765.pdf").getFile();
        byte[] bytes = Files.readAllBytes(Paths.get(file.toURI()));

        when(s3Client.getObject(any(GetObjectRequest.class))).thenReturn(new ResponseInputStream<>(
                GetObjectResponse.builder().metadata(
                        metadata).build(),
                AbortableInputStream.create(new ByteArrayInputStream(bytes))));
        // act
        PDDocument documentSpy = Loader.loadPDF(file);
        try (MockedStatic<Loader> mockLoader = Mockito.mockStatic(Loader.class);
             MockedStatic<LosslessFactory> losslessFactory = Mockito.mockStatic(LosslessFactory.class)) {
            mockLoader.when(() -> Loader.loadPDF(any(byte[].class))).thenReturn(documentSpy);

            String actual = S3Helper.getStrippedPdf(s3Client, key, bucketName, List.of(4), name, false);

            // assert
            ArgumentCaptor<PutObjectRequest> captor = ArgumentCaptor.forClass(PutObjectRequest.class);
            verify(s3Client, times(1)).putObject(captor.capture(), any(RequestBody.class));
            verify(s3Client, times(1)).getObject(any(GetObjectRequest.class));
            losslessFactory.verify(()-> LosslessFactory.createFromImage(any(PDDocument.class), any(BufferedImage.class)), times(0));
            assertEquals(key, captor.getValue().metadata().get(MetadataConstants.ORIGINAL_S3_KEY));
            assertEquals(strippedPageObjectKey, actual);
            assertEquals(documentId, captor.getValue().metadata().get(MetadataConstants.ID));
            assertEquals(submissionId, captor.getValue().metadata().get(MetadataConstants.SUBMISSIONID));
            assertEquals(myUscisId, captor.getValue().metadata().get(MetadataConstants.MYUSCISID));
        }

    }

    @Test
    public void shouldUploadFirstPageToS3WhenSelectedPagesAreOutOfBounds() throws IOException {
        String key = "objectKey.pdf";
        String bucketName = "default-form";
        String name = "name";
        String strippedPageObjectKey = "objectKey_name_pages_1.pdf";
        String documentId = "formId";
        String submissionId = "submissionId";
        String myUscisId = "uscisid";

        S3Client s3Client = mock(S3Client.class);

        Map<String, String> metadata = new HashMap<>();
        metadata.put("id", documentId);
        metadata.put("submissionid", submissionId);
        metadata.put("myuscisid", myUscisId);

        HeadObjectResponse headObjectResponse = HeadObjectResponse.builder().metadata(metadata).build();

        when(s3Client.headObject(any(HeadObjectRequest.class))).thenReturn(headObjectResponse);
        File file = new ClassPathResource("test-files/multi-edition-i765.pdf").getFile();
        byte[] bytes = Files.readAllBytes(Paths.get(file.toURI()));

        when(s3Client.getObject(any(GetObjectRequest.class))).thenReturn(new ResponseInputStream<>(
                GetObjectResponse.builder().metadata(
                        metadata).build(),
                AbortableInputStream.create(new ByteArrayInputStream(bytes))));
        // act
        PDDocument documentSpy = Loader.loadPDF(file);
        try (MockedStatic<Loader> mockLoader = Mockito.mockStatic(Loader.class);
             MockedStatic<LosslessFactory> losslessFactory = Mockito.mockStatic(LosslessFactory.class)) {
            mockLoader.when(() -> Loader.loadPDF(any(byte[].class))).thenReturn(documentSpy);

            String actual = S3Helper.getStrippedPdf(s3Client, key, bucketName,
                    IntStream.range(1, 25).boxed().toList(), name, false);

            // assert
            ArgumentCaptor<PutObjectRequest> captor = ArgumentCaptor.forClass(PutObjectRequest.class);
            verify(s3Client, times(1)).putObject(captor.capture(), any(RequestBody.class));
            verify(s3Client, times(2)).getObject(any(GetObjectRequest.class));
            losslessFactory.verify(()-> LosslessFactory.createFromImage(any(PDDocument.class), any(BufferedImage.class)), times(0));
            assertEquals(key, captor.getValue().metadata().get(MetadataConstants.ORIGINAL_S3_KEY));
            assertEquals(strippedPageObjectKey, actual);
            assertEquals(documentId, captor.getValue().metadata().get(MetadataConstants.ID));
            assertEquals(submissionId, captor.getValue().metadata().get(MetadataConstants.SUBMISSIONID));
            assertEquals(myUscisId, captor.getValue().metadata().get(MetadataConstants.MYUSCISID));
        }

    }

}
