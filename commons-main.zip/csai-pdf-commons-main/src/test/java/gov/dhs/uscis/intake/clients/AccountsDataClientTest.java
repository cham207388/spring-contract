package gov.dhs.uscis.intake.clients;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.exceptions.AccountsDataClientException;
import gov.dhs.uscis.intake.models.myuscis.Admin;
import gov.dhs.uscis.intake.models.myuscis.AdminResponse;
import gov.dhs.uscis.intake.models.myuscis.ToggleResponse;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import reactor.netty.http.client.HttpClient;

class AccountsDataClientTest {

	private AccountsDataClient client;
	private static MockWebServer server;
	
	@BeforeEach
	void setup() throws IOException {
		server = new MockWebServer();
		server.start();
        HttpClient httpClient = HttpClient.create().responseTimeout(Duration.ofSeconds(1));
        WebClient webClient = WebClient.builder()
                .baseUrl(String.format("http://localhost:%s", server.getPort()))
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
		
		client = new AccountsDataClient(webClient);
	}
	
	@AfterAll
	static void tearDown() throws IOException {
		server.shutdown();
	}
	
	@Test
	void testGetAdministrators() {
		Admin admin = new Admin();
		admin.setUuid("MOCK-UUID");
		AdminResponse response = new AdminResponse();
		response.setData(List.of(admin));
		
		server.enqueue(new MockResponse()
    			.addHeader("Content-Type", "application/json")
				.setResponseCode(200)
				.setBody(writeToString(response)));
		
		List<Admin> admins = client.getAdministrators("mockICAMUUID", "mockUserGroupId");
		assertEquals(1, admins.size());
		Admin actual = admins.get(0);
		assertEquals(admin.getUuid(), actual.getUuid());
	}
	
	@Test
	void getAdministratorsWebClientResponseException() {
		server.enqueue(new MockResponse()
    			.addHeader("Content-Type", "application/json")
				.setResponseCode(500));
		try {
			client.getAdministrators("mockICAMUUID", "mockUserGroupId");
		} catch(Exception e) {
			assertEquals(AccountsDataClientException.class, e.getClass());
		}
	}
	
	@Test
	void notifyAdministratorsWebClientResponseException() {
		server.enqueue(new MockResponse()
				.addHeader("Content-Type", "application/json")
				.setResponseCode(500));
		try {
			client.notifyAdministrators("mock-my-uscis-id", "mock-submission-id", List.of("mock-admin-uuid"));
		} catch(Exception e) {
			assertEquals(AccountsDataClientException.class, e.getClass());
		}
	}

    @Test
	void testGetToggle_Success() {
		ToggleResponse.ToggleData data = new ToggleResponse.ToggleData();
		data.setToggle("ft_sample_feature");
		data.setEnabled(true);
		
		ToggleResponse response = new ToggleResponse();
		response.setData(data);
		
		server.enqueue(new MockResponse()
				.addHeader("Content-Type", "application/json")
				.setResponseCode(200)
				.setBody(writeToString(response)));
		
		boolean isEnabled = client.getToggle("ft_sample_feature");
		
		assertEquals(true, isEnabled);
	}

	@Test
	void testGetToggle_ReturnsFalseWhenDisabled() {
		ToggleResponse.ToggleData data = new ToggleResponse.ToggleData();
		data.setToggle("ft_disabled_feature");
		data.setEnabled(false);
		
		ToggleResponse response = new ToggleResponse();
		response.setData(data);
		
		server.enqueue(new MockResponse()
				.addHeader("Content-Type", "application/json")
				.setResponseCode(200)
				.setBody(writeToString(response)));
		
		boolean isEnabled = client.getToggle("ft_disabled_feature");
		
		assertEquals(false, isEnabled);
	}

	@Test
	void testGetToggle_WebClientResponseException() {
		server.enqueue(new MockResponse()
				.setResponseCode(500));
		
		try {
			client.getToggle("ft_error_feature");
			fail("Should have thrown AccountsDataClientException");
		} catch (AccountsDataClientException e) {
			assertEquals(AccountsDataClientException.class, e.getClass());
			assert(e.getMessage().contains("ft_error_feature"));
		}
	}
	
	private String writeToString(Object object) {
		String result = null;
		try {
			result = new ObjectMapper().writeValueAsString(object);
		} catch(IOException e) {
			fail(e.getMessage());
		}
		return result;
	}
	
}
