package gov.dhs.uscis.intake.enums;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class EligibilityCategoryEnumTest {

    @Test
    void shouldGetEligibilityByCategoryString() {
        EligibilityCategoryEnum.EligibilityCategoryRegistry.register(I765EligibilityCategory.C11PAROLE);
        EligibilityCategoryEnum category = EligibilityCategoryEnum.fromString(I765EligibilityCategory.C11PAROLE.getCategory());

        assertThat(category).isEqualTo(I765EligibilityCategory.C11PAROLE);
    }

    @Test
    void shouldGetEligibilityByEnumStringForBackwardCompatibility() {
        EligibilityCategoryEnum.EligibilityCategoryRegistry.register(I765EligibilityCategory.C11PAROLE);
        EligibilityCategoryEnum category = EligibilityCategoryEnum.fromString("C11PAROLE");

        assertThat(category).isEqualTo(I765EligibilityCategory.C11PAROLE);
    }

}
