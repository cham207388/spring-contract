package gov.dhs.uscis.intake.daos;

import static gov.dhs.uscis.intake.entities.audit.ActionPerformed.DRAFT_CREATED;
import static gov.dhs.uscis.intake.entities.submission.SubmissionState.DRAFT;
import static java.time.format.DateTimeFormatter.ISO_INSTANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.testcontainers.containers.localstack.LocalStackContainer.Service.DYNAMODB;
import static software.amazon.awssdk.auth.credentials.StaticCredentialsProvider.create;
import static software.amazon.awssdk.enhanced.dynamodb.TableSchema.fromClass;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.containers.output.Slf4jLogConsumer;
import org.testcontainers.utility.DockerImageName;
import org.testcontainers.utility.MountableFile;

import gov.dhs.uscis.intake.entities.audit.Audit;
import gov.dhs.uscis.intake.entities.audit.Audit.Event;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.GetItemResponse;
import software.amazon.awssdk.services.dynamodb.model.ScanRequest;

class AuditDAOTest {
    private static final String DATE = "\\d{4}-\\d{2}-\\d{2}";
    private static final String TIME = "\\d{2}:\\d{2}:\\d{2}\\.\\d{3,9}"; 
    private static final String ISO_8601_UTC = DATE + "T" + TIME + "Z";
    
    private static final String TABLE_NAME = "Audit";
    private static final DockerImageName localstackImage = DockerImageName.parse("nexus-nonprod-gss.uscis.dhs.gov:8132/localstack/localstack:3.4")
        .asCompatibleSubstituteFor("localstack/localstack");

    @SuppressWarnings("resource")
    private static final LocalStackContainer localStack = new LocalStackContainer(localstackImage)
            .withCopyFileToContainer(MountableFile.forHostPath("init-aws-local.sh"),
                    "/etc/localstack/init/ready.d/init-aws.sh")
            .withLogConsumer(new Slf4jLogConsumer(LoggerFactory.getLogger("localstack")))
            .withEnv("DEBUG", "1")
            .withStartupAttempts(10)
            .withServices(DYNAMODB);

    private static AuditDAO dao;
    private static DynamoDbClient rawClient;
    private static DynamoDbTable<Audit> table;

    @BeforeAll
    static void before() {
        localStack.start();
        rawClient = DynamoDbClient.builder()
            .endpointOverride(localStack.getEndpoint())
            .credentialsProvider(
                create(AwsBasicCredentials.create(localStack.getAccessKey(), localStack.getSecretKey())))
            .region(Region.of(localStack.getRegion()))
            .build();
        DynamoDbEnhancedClient client = DynamoDbEnhancedClient.builder().dynamoDbClient(rawClient).build();
        table = client.table(TABLE_NAME, fromClass(Audit.class));
        dao = new AuditDAO(client.table(TABLE_NAME, fromClass(Audit.class)));
    }

    @BeforeEach
    void beforeEach() {
      rawClient.waiter().waitUntilTableExists(b -> b.tableName(TABLE_NAME));
    }
  
    @AfterEach
    void afterEach() {
      table.deleteTable();
      table.createTable();
    }
  
    @AfterAll
    static void afterAll() {
        localStack.stop();
    }

    @Test
    @DisplayName("Should persist new audit entries")
    void shouldPersistNewAuditEntries() {
        String myUscisId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        Audit expected = createAudit(myUscisId, submissionId);

        Audit actual = dao.save(expected);

        assertEquals(1, returnCount());
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Should update existing audit entries")
    void shouldUpdateExistingAuditEntries() {
        String myUscisId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        Audit expected = createAudit(myUscisId, submissionId);
        expected = dao.save(expected);
        expected.getEvents().add(Audit.Event.builder()
                                        .actionPerformed(DRAFT_CREATED)
                                        .submissionState(DRAFT)
                                        .timestamp(Instant.now()).build());
        Audit actual = dao.update(expected);
        assertEquals(1, returnCount());
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Should persist Instant timestamp using ISO 8601 UTC format") 
    void shouldPersistInstantWithDefaultUTCFormat() {
        String myUscisId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        Audit audit = createAudit(myUscisId, submissionId);
                
        dao.save(audit);

        GetItemResponse response = rawClient.getItem(GetItemRequest.builder()
            .tableName(TABLE_NAME)
            .key(Map.of(
                "myUscisId", AttributeValue.fromS(myUscisId),
                "submissionId", AttributeValue.fromS(submissionId)
            ))
            .build());
        String timestamp = response.item().get("events").l().get(0).m().get("timestamp").s();
        assertThat(timestamp).matches(ISO_8601_UTC);
        assertEquals(ISO_INSTANT.format(audit.getEvents().get(0).getTimestamp()), timestamp);
    }

    @Test
    @DisplayName("Should find existing Audit by myUscisId and submissionId")
    void shouldFindExistingAuditByMyUscisIdAndSubmissionId(){

        String myUscisId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();

        Audit expected = Audit.builder()
                        .myUscisId(myUscisId)
                        .submissionId(submissionId)
                        .events(List.of(
                                Audit.Event.builder()
                                        .actionPerformed(DRAFT_CREATED)
                                        .submissionState(DRAFT)
                                        .timestamp(Instant.now())
                                        .build()))
                        .build();


        dao.save(expected);

        Audit actual = dao.find(myUscisId, submissionId);

        assertEquals(expected, actual);
    }

    private int returnCount() {
        ScanRequest request = ScanRequest.builder().tableName(TABLE_NAME)
                                            .select("COUNT").build();
        return rawClient.scan(request).count();
    }

    private Audit createAudit(String myUscisId, String submissionId) {
        List<Event> events = new ArrayList<>();
        events.add(Audit.Event.builder()
                        .actionPerformed(DRAFT_CREATED)
                        .submissionState(DRAFT)
                        .timestamp(Instant.now())
                        .build());
        return  Audit.builder()
                .myUscisId(myUscisId)
                .submissionId(submissionId)
                .events(events)
                .build();
    }

}
