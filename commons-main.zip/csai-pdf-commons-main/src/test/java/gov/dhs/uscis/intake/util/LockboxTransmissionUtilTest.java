package gov.dhs.uscis.intake.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.instancio.Instancio;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import gov.dhs.uscis.intake.constants.DocumentType;
import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Application;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.AdditionalInfo;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.ApplicationFile;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.ApplicationSupportDocument;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.ManifestStatus;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;

import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;

@TestInstance(Lifecycle.PER_CLASS)
public class LockboxTransmissionUtilTest {

    private static final String TEST_MYUSCIS_ID = "TEST_MYUSCIS_ID";
    private static final String TEST_LOCKBOX_ID = "TEST_LOCKBOX_ID";
    private static final String TEST_SUBMISSION_ID = "TEST_SUBMISSION_ID";

    private static final String TEST_EVIDENCE_GROUP_TYPE = "TEST_EVIDENCE_GROUP_TYPE";
    private static final String TEST_EVIDENCE_ID = "TEST_EVIDENCE_ID";
    private static final String TEST_EVIDENCE_NAME = "TEST_EVIDENCE_NAME";
    private static final String TEST_EVIDENCE_URI = "TEST_EVIDENCE_URI";
    private static final String TEST_EVIDENCE_MD5HASH = "TEST_EVIDENCE_MD5HASH";
    private static final SubmissionEvidence TEST_EVIDENCE_SUBMISSION_EVIDENCE = SubmissionEvidence.builder()
            .evidenceGroupType(TEST_EVIDENCE_GROUP_TYPE)
            .type(TEST_EVIDENCE_GROUP_TYPE)
            .id(TEST_EVIDENCE_ID)
            .name(TEST_EVIDENCE_NAME)
            .url(TEST_EVIDENCE_URI)
            .md5Hash(TEST_EVIDENCE_MD5HASH)
            .build();
    private static final ApplicationFile TEST_EVIDENCE_APPLICATION_FILE = ApplicationFile.builder()
            .order(1)
            .id(TEST_EVIDENCE_ID)
            .name(TEST_EVIDENCE_NAME)
            .uri(TEST_EVIDENCE_URI)
            .md5Hash(TEST_EVIDENCE_MD5HASH)
            .build();

    private static final String TEST_FEE_WAIVER_GROUP_TYPE = "TEST_FEE_WAIVER_GROUP_TYPE";
    private static final String TEST_FEE_WAIVER_ID = "TEST_FEE_WAIVER_ID";
    private static final String TEST_FEE_WAIVER_NAME = "TEST_FEE_WAIVER_NAME";
    private static final String TEST_FEE_WAIVER_URI = "TEST_FEE_WAIVER_URI";
    private static final String TEST_FEE_WAIVER_MD5HASH = "TEST_FEE_WAIVER_MD5HASH";
    private static final SubmissionEvidence TEST_FEE_WAIVER_SUBMISSION_EVIDENCE = SubmissionEvidence.builder()
            .evidenceGroupType(TEST_FEE_WAIVER_GROUP_TYPE)
            .type(TEST_FEE_WAIVER_GROUP_TYPE)
            .id(TEST_FEE_WAIVER_ID)
            .name(TEST_FEE_WAIVER_NAME)
            .url(TEST_FEE_WAIVER_URI)
            .md5Hash(TEST_FEE_WAIVER_MD5HASH)
            .build();
    private static final ApplicationFile TEST_FEE_WAIVER_APPLICATION_FILE = ApplicationFile.builder()
            .order(1)
            .id(TEST_FEE_WAIVER_ID)
            .name(TEST_FEE_WAIVER_NAME)
            .uri(TEST_FEE_WAIVER_URI)
            .md5Hash(TEST_FEE_WAIVER_MD5HASH)
            .build();

    private static final String TEST_I765_FORM_ID = "TEST_I765_FORM_ID";
    private static final String TEST_I765_FORM_NAME = "TEST_I765_FORM_NAME";
    private static final String TEST_I765_FORM_URL = "TEST_I765_FORM_URL";
    private static final String TEST_I765_FORM_MD5HASH = "TEST_I765_FORM_MD5HASH";
    private BigDecimal testI765FeeTotal = BigDecimal.valueOf(100.00);
    private static final SubmissionForm TEST_I765_SUBMISSION_FORM = SubmissionForm.builder()
            .id(TEST_I765_FORM_ID)
            .name(TEST_I765_FORM_NAME)
            .type(FormType.I765.getType())
            .url(TEST_I765_FORM_URL)
            .md5Hash(TEST_I765_FORM_MD5HASH)
            .build();
    private static final ApplicationFile TEST_I765_APPLICATION_FILE = ApplicationFile.builder()
            .order(1)
            .id(TEST_I765_FORM_ID)
            .name(TEST_I765_FORM_NAME)
            .uri(TEST_I765_FORM_URL)
            .md5Hash(TEST_I765_FORM_MD5HASH)
            .build();

    private static final String TEST_N400_FORM_ID = "TEST_N400_FORM_ID";
    private static final String TEST_N400_FORM_NAME = "TEST_N400_FORM_NAME";
    private static final String TEST_N400_FORM_URL = "TEST_N400_FORM_URL";
    private static final String TEST_N400_FORM_MD5HASH = "TEST_N400_FORM_MD5HASH";
    private BigDecimal testN400FeeTotal = BigDecimal.valueOf(750.00);
    private static final SubmissionForm TEST_N400_SUBMISSIONFORM = SubmissionForm.builder()
            .id(TEST_N400_FORM_ID)
            .name(TEST_N400_FORM_NAME)
            .type(FormType.N400.getType())
            .url(TEST_N400_FORM_URL)
            .md5Hash(TEST_N400_FORM_MD5HASH)
            .build();
    private static final ApplicationFile TEST_N400_APPLICATION_FILE = ApplicationFile.builder()
            .order(1)
            .id(TEST_N400_FORM_ID)
            .name(TEST_N400_FORM_NAME)
            .uri(TEST_N400_FORM_URL)
            .md5Hash(TEST_N400_FORM_MD5HASH)
            .build();

    private static final String TEST_G28_FORM_ID = "TEST_G28_FORM_ID";
    private static final String TEST_G28_FORM_NAME = "TEST_G28_FORM_NAME";
    private static final String TEST_G28_FORM_URL = "TEST_G28_FORM_URL";
    private static final String TEST_G28_FORM_MD5HASH = "TEST_G28_FORM_MD5HASH";
    private static final SubmissionForm TEST_G28_SUBMISSION_FORM = SubmissionForm.builder()
            .id(TEST_G28_FORM_ID)
            .name(TEST_G28_FORM_NAME)
            .type(FormType.G28.getType())
            .url(TEST_G28_FORM_URL)
            .md5Hash(TEST_G28_FORM_MD5HASH)
            .build();
    private static final ApplicationFile TEST_G28_APPLICATION_FILE = ApplicationFile.builder()
            .order(1)
            .id(TEST_G28_FORM_ID)
            .name(TEST_G28_FORM_NAME)
            .uri(TEST_G28_FORM_URL)
            .md5Hash(TEST_G28_FORM_MD5HASH)
            .build();

    private static Statuses generateTestStatuses(String formType, BigDecimal feeTotal) {
        return Statuses.builder()
                .manifestStatus(
                        ManifestStatus.builder()
                                .status(StatusEnum.PUBLISHED)
                                .errors(List.of())
                                .build())
                .submissionStatus(
                        SubmissionStatus.builder()
                                .uscisId(TEST_LOCKBOX_ID)
                                .status(StatusEnum.RECEIVED)
                                .totalCost(feeTotal)
                                .applicationStatuses(List.of(
                                        ApplicationStatus.builder()
                                                .uscisId(TEST_SUBMISSION_ID)
                                                .formType(formType)
                                                .status(StatusEnum.RECEIVED)
                                                .build()))
                                .build())
                .build();
    }

    @Test
    void shouldMapSingleI765Form() {

        Submission inputSubmission = Submission.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .formType(FormType.I765)
                .feeTotal(testI765FeeTotal)
                .feeWaiver(null)
                .userRequestedFeeWaiver(false)
                .forms(List.of(TEST_I765_SUBMISSION_FORM))
                .evidences(null)

                .build();

        SubmissionManifest expectedSubmissionManifest = SubmissionManifest.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .manifestId(TEST_LOCKBOX_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .manifest(
                        Manifest.builder()
                                .manifestId(TEST_LOCKBOX_ID)
                                .submissionDate(LockboxTransmissionUtil.getFormattedDate())
                                .feeTotal(testI765FeeTotal)
                                .applications(List.of(
                                        Application.builder()
                                                .formType(FormType.I765.getType())
                                                .submissionId(String.format("%s-%s", FormType.I765.getType(), TEST_SUBMISSION_ID))
                                                .files(List.of(TEST_I765_APPLICATION_FILE))
                                                .supportDocuments(List.of())
                                                .additionalInfo(List.of(
                                                        AdditionalInfo.builder()
                                                                .name("feeWaiverRequested")
                                                                .value("false")
                                                                .build()))
                                                .build()))
                                .build())
                .statuses(generateTestStatuses(FormType.I765.getType(), testI765FeeTotal))

                .build();

        LockboxTransmission actualLockboxTransmission = LockboxTransmissionUtil
                .lockboxTransmissionFromSubmission(inputSubmission);
        SubmissionManifest actualSubmissionManifest = LockboxTransmissionUtil
                .submissionManifestFromLockboxTransmission(actualLockboxTransmission, TEST_LOCKBOX_ID);
        assertEquals(expectedSubmissionManifest, actualSubmissionManifest);

    }

    @Test
    void shouldMapEvidencesToSupportDocuments() {

        Submission inputSubmission = Submission.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .formType(FormType.I765)
                .feeTotal(testI765FeeTotal)
                .feeWaiver(null)
                .userRequestedFeeWaiver(false)
                .forms(List.of(TEST_I765_SUBMISSION_FORM))
                .evidences(List.of(TEST_EVIDENCE_SUBMISSION_EVIDENCE))
                .build();

        SubmissionManifest expectedSubmissionManifest = SubmissionManifest.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .manifestId(TEST_LOCKBOX_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .manifest(
                        Manifest.builder()
                                .manifestId(TEST_LOCKBOX_ID)
                                .submissionDate(LockboxTransmissionUtil.getFormattedDate())
                                .feeTotal(testI765FeeTotal)
                                .applications(List.of(
                                        Application.builder()
                                                .formType(FormType.I765.getType())
                                                .submissionId(TEST_SUBMISSION_ID)
                                                .files(List.of(TEST_I765_APPLICATION_FILE))
                                                .supportDocuments(List.of(
                                                        ApplicationSupportDocument.builder()
                                                                .supportId(UUID
                                                                        .nameUUIDFromBytes(
                                                                                TEST_EVIDENCE_GROUP_TYPE.getBytes())
                                                                        .toString())
                                                                .category(TEST_EVIDENCE_GROUP_TYPE)
                                                                .files(List.of(TEST_EVIDENCE_APPLICATION_FILE))
                                                                .build()))
                                                .additionalInfo(List.of(
                                                        AdditionalInfo.builder()
                                                                .name("feeWaiverRequested")
                                                                .value("false")
                                                                .build()))
                                                .build()))
                                .build())
                .statuses(generateTestStatuses(FormType.I765.getType(), testI765FeeTotal))
                .build();

        LockboxTransmission actualLockboxTransmission = LockboxTransmissionUtil
                .lockboxTransmissionFromSubmission(inputSubmission);
        SubmissionManifest actualSubmissionManifest = LockboxTransmissionUtil
                .submissionManifestFromLockboxTransmission(actualLockboxTransmission, TEST_LOCKBOX_ID);
        assertEquals(expectedSubmissionManifest.getManifestId(), actualSubmissionManifest.getManifestId());
        assertEquals(expectedSubmissionManifest.getSubmissionId(), actualSubmissionManifest.getSubmissionId());



    }

    @Test
    void shouldMapFeeWaiverToSupportDocuments() {

        Submission inputSubmission = Submission.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .formType(FormType.I765)
                .feeTotal(testI765FeeTotal)
                .forms(List.of(TEST_I765_SUBMISSION_FORM))
                .userRequestedFeeWaiver(true)
                .feeWaiver(
                        SubmissionEvidence.builder()
                                .evidenceGroupType(TEST_FEE_WAIVER_GROUP_TYPE)
                                .type(TEST_FEE_WAIVER_GROUP_TYPE)
                                .id(TEST_FEE_WAIVER_ID)
                                .name(TEST_FEE_WAIVER_NAME)
                                .url(TEST_FEE_WAIVER_URI)
                                .md5Hash(TEST_FEE_WAIVER_MD5HASH)
                                .build())
                .build();

        SubmissionManifest expectedSubmissionManifest = SubmissionManifest.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .manifestId(TEST_LOCKBOX_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .manifest(
                        Manifest.builder()
                                .manifestId(TEST_LOCKBOX_ID)
                                .submissionDate(LockboxTransmissionUtil.getFormattedDate())
                                .feeTotal(testI765FeeTotal)
                                .applications(List.of(
                                        Application.builder()
                                                .formType(FormType.I765.getType())
                                                .submissionId(TEST_SUBMISSION_ID)
                                                .files(List.of(TEST_I765_APPLICATION_FILE))
                                                .supportDocuments(List.of(
                                                        ApplicationSupportDocument.builder()
                                                                .supportId(UUID.nameUUIDFromBytes(
                                                                        DocumentType.FeeWaiver.FORM_I912.getBytes())
                                                                        .toString())
                                                                .category(DocumentType.FeeWaiver.FORM_I912)
                                                                .files(List.of(TEST_FEE_WAIVER_APPLICATION_FILE))
                                                                .build()))
                                                .additionalInfo(List.of(
                                                        AdditionalInfo.builder()
                                                                .name("feeWaiverRequested")
                                                                .value("true")
                                                                .build()))
                                                .build()))
                                .build())
                .statuses(generateTestStatuses(FormType.I765.getType(), testI765FeeTotal))
                .build();

        LockboxTransmission actualLockboxTransmission = LockboxTransmissionUtil
                .lockboxTransmissionFromSubmission(inputSubmission);
        SubmissionManifest actualSubmissionManifest = LockboxTransmissionUtil
                .submissionManifestFromLockboxTransmission(actualLockboxTransmission, TEST_LOCKBOX_ID);
                assertEquals(expectedSubmissionManifest.getManifestId(), actualSubmissionManifest.getManifestId());
                assertEquals(expectedSubmissionManifest.getSubmissionId(), actualSubmissionManifest.getSubmissionId());
    }

    @Test
    void shouldMapAdditionalFormsToAdditionalManifestApplications() {

        Submission inputSubmission = Submission.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .formType(FormType.N400)
                .userRequestedFeeWaiver(false)
                .feeTotal(testN400FeeTotal)
                .feeWaiver(null)
                .forms(List.of(TEST_N400_SUBMISSIONFORM, TEST_G28_SUBMISSION_FORM))
                .evidences(null)
                .build();

        SubmissionManifest expectedSubmissionManifest = SubmissionManifest.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .manifestId(TEST_LOCKBOX_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .manifestId(TEST_LOCKBOX_ID)
                .manifest(
                        Manifest.builder()
                                .manifestId(TEST_LOCKBOX_ID)
                                .submissionDate(LockboxTransmissionUtil.getFormattedDate())
                                .feeTotal(testN400FeeTotal)
                                .applications(List.of(
                                        Application.builder()
                                                .formType(FormType.N400.getType())
                                                .submissionId(String.format("%s-%s", FormType.N400.getType(), TEST_SUBMISSION_ID))
                                                .files(List.of(TEST_N400_APPLICATION_FILE))
                                                .supportDocuments(List.of())
                                                .additionalInfo(List.of(
                                                        AdditionalInfo.builder()
                                                                .name("feeWaiverRequested")
                                                                .value("false")
                                                                .build()))
                                                .build(),
                                        Application.builder()
                                                .formType(FormType.G28.getType())
                                                .submissionId(String.format("%s-%s", FormType.G28.getType(), TEST_SUBMISSION_ID))
                                                .files(List.of(TEST_G28_APPLICATION_FILE))
                                                .supportDocuments(List.of())
                                                .additionalInfo(List.of())
                                                .build()))
                                .build())
                .statuses(generateTestStatuses(FormType.N400.getType(), testN400FeeTotal))
                .build();

        LockboxTransmission actualLockboxTransmission = LockboxTransmissionUtil
                .lockboxTransmissionFromSubmission(inputSubmission);
        SubmissionManifest actualSubmissionManifest = LockboxTransmissionUtil
                .submissionManifestFromLockboxTransmission(actualLockboxTransmission, TEST_LOCKBOX_ID);
        assertEquals(expectedSubmissionManifest, actualSubmissionManifest);

    }

    @Test
    void shouldMapSupportDocumentsToPrimaryFormApplication() {

        Submission inputSubmission = Submission.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .formType(FormType.I765)
                .feeTotal(testI765FeeTotal)
                .forms(
                        List.of(TEST_I765_SUBMISSION_FORM, TEST_G28_SUBMISSION_FORM))
                .evidences(List.of(TEST_EVIDENCE_SUBMISSION_EVIDENCE))
                .userRequestedFeeWaiver(true)
                .feeWaiver(TEST_FEE_WAIVER_SUBMISSION_EVIDENCE)
                .build();

        SubmissionManifest expectedSubmissionManifest = SubmissionManifest.builder()
                .myUscisId(TEST_MYUSCIS_ID)
                .manifestId(TEST_LOCKBOX_ID)
                .submissionId(TEST_SUBMISSION_ID)
                .manifestId(TEST_LOCKBOX_ID)
                .manifest(
                        Manifest.builder()
                                .manifestId(TEST_LOCKBOX_ID)
                                .submissionDate(LockboxTransmissionUtil.getFormattedDate())
                                .feeTotal(testI765FeeTotal)
                                .applications(List.of(
                                        Application.builder()
                                                .formType(FormType.I765.getType())
                                                .submissionId(TEST_SUBMISSION_ID)
                                                .files(List.of(TEST_I765_APPLICATION_FILE))
                                                .supportDocuments(List.of(
                                                        ApplicationSupportDocument.builder()
                                                                .supportId(UUID.nameUUIDFromBytes(
                                                                        DocumentType.FeeWaiver.FORM_I912.getBytes())
                                                                        .toString())
                                                                .category(DocumentType.FeeWaiver.FORM_I912)
                                                                .files(List.of(TEST_FEE_WAIVER_APPLICATION_FILE))
                                                                .build(),
                                                        ApplicationSupportDocument.builder()
                                                                .supportId(UUID
                                                                        .nameUUIDFromBytes(
                                                                                TEST_EVIDENCE_GROUP_TYPE.getBytes())
                                                                        .toString())
                                                                .category(TEST_EVIDENCE_GROUP_TYPE)
                                                                .files(List.of(TEST_EVIDENCE_APPLICATION_FILE))
                                                                .build()))
                                                .additionalInfo(List.of(
                                                        AdditionalInfo.builder()
                                                                .name("feeWaiverRequested")
                                                                .value("true")
                                                                .build()))
                                                .build(),
                                        Application.builder()
                                                .formType(FormType.G28.getType())
                                                .submissionId(String.format("G-%s", TEST_SUBMISSION_ID))
                                                .files(List.of(TEST_G28_APPLICATION_FILE))
                                                .supportDocuments(List.of())
                                                .additionalInfo(List.of())
                                                .build()))
                                .build())
                .statuses(generateTestStatuses(FormType.I765.getType(), testI765FeeTotal))
                .build();

        LockboxTransmission actualLockboxTransmission = LockboxTransmissionUtil
                .lockboxTransmissionFromSubmission(inputSubmission);
        SubmissionManifest actualSubmissionManifest = LockboxTransmissionUtil
                .submissionManifestFromLockboxTransmission(actualLockboxTransmission, TEST_LOCKBOX_ID);
                assertEquals(expectedSubmissionManifest.getManifestId(), actualSubmissionManifest.getManifestId());
                assertEquals(expectedSubmissionManifest.getSubmissionId(), actualSubmissionManifest.getSubmissionId());
    }

    @Test
    void shouldMapGroupedEvidences() {
        String evidenceType = "Other";
        Submission submission = Instancio.create(Submission.class);
        submission.setFormType(FormType.I765);
        submission.setFeeWaiver(null);
        submission.setEvidences(List.of(SubmissionEvidence.builder().type(evidenceType).build(),
                SubmissionEvidence.builder().type(evidenceType).build()));
        submission.setForms(List.of(SubmissionForm.builder().type(FormType.I765.getType()).build(),
                SubmissionForm.builder().type(FormType.G28.getType()).build()));
        submission.setUserRequestedFeeWaiver(false);
        submission.setUserRequestedPartialFeeWaiver(false);
        LockboxTransmission transmission = LockboxTransmissionUtil.lockboxTransmissionFromSubmission(submission);
        SubmissionManifest manifest = LockboxTransmissionUtil.submissionManifestFromLockboxTransmission(transmission,
                "manifestId");

        List<Application> applications = manifest.getManifest().getApplications();
        assertThat(applications).hasSize(2);
        Optional<Application> optionalForm = applications.stream()
                .filter(app -> app.getFormType().equals(FormType.I765.getType())).findFirst();
        assertThat(optionalForm).isPresent();
        assertThat(optionalForm.get().getSupportDocuments()).hasSize(1);
        ApplicationSupportDocument supportDocument = optionalForm.get().getSupportDocuments().get(0);
        assertThat(supportDocument.getCategory()).isEqualTo(evidenceType);
        assertThat(supportDocument.getSupportId()).isNotBlank();
        List<ApplicationFile> supportFiles = supportDocument.getFiles();
        assertThat(supportFiles).hasSize(2);
    }

    @Test
    void shouldMapGroupedEOIR() {
        String evidenceType = "EOIR";
        String mappedToEvidenceType = "Other";
        Submission submission = Instancio.create(Submission.class);
        submission.setFormType(FormType.I765);
        submission.setFeeWaiver(null);
        submission.setEvidences(List.of(SubmissionEvidence.builder().type(evidenceType).build(),
                SubmissionEvidence.builder().type(evidenceType).build()));
        submission.setForms(List.of(SubmissionForm.builder().type(FormType.I765.getType()).build(),
                SubmissionForm.builder().type(FormType.G28.getType()).build()));
        submission.setUserRequestedFeeWaiver(false);
        submission.setUserRequestedPartialFeeWaiver(false);
        LockboxTransmission transmission = LockboxTransmissionUtil.lockboxTransmissionFromSubmission(submission);
        SubmissionManifest manifest = LockboxTransmissionUtil.submissionManifestFromLockboxTransmission(transmission,
                "manifestId");

        List<Application> applications = manifest.getManifest().getApplications();
        assertThat(applications).hasSize(2);
        Optional<Application> optionalForm = applications.stream()
                .filter(app -> app.getFormType().equals(FormType.I765.getType())).findFirst();
        assertThat(optionalForm).isPresent();
        assertThat(optionalForm.get().getSupportDocuments()).hasSize(1);
        ApplicationSupportDocument supportDocument = optionalForm.get().getSupportDocuments().get(0);
        assertThat(supportDocument.getCategory()).isNotEqualTo(evidenceType);
        assertThat(supportDocument.getCategory()).isEqualTo(mappedToEvidenceType);

        assertThat(supportDocument.getSupportId()).isNotBlank();
        List<ApplicationFile> supportFiles = supportDocument.getFiles();
        assertThat(supportFiles).hasSize(2);
    }

    @Test
    void shouldMapGroupedBIAOrder() {
        String evidenceType = "BIA Order";
        String mappedToEvidenceType = "Other";
        Submission submission = Instancio.create(Submission.class);
        submission.setFormType(FormType.I765);
        submission.setFeeWaiver(null);
        submission.setEvidences(List.of(SubmissionEvidence.builder().type(evidenceType).build(),
                SubmissionEvidence.builder().type(evidenceType).build()));
        submission.setForms(List.of(SubmissionForm.builder().type(FormType.I765.getType()).build(),
                SubmissionForm.builder().type(FormType.G28.getType()).build()));
        submission.setUserRequestedFeeWaiver(false);
        submission.setUserRequestedPartialFeeWaiver(false);
        LockboxTransmission transmission = LockboxTransmissionUtil.lockboxTransmissionFromSubmission(submission);
        SubmissionManifest manifest = LockboxTransmissionUtil.submissionManifestFromLockboxTransmission(transmission,
                "manifestId");

        List<Application> applications = manifest.getManifest().getApplications();
        assertThat(applications).hasSize(2);
        Optional<Application> optionalForm = applications.stream()
                .filter(app -> app.getFormType().equals(FormType.I765.getType())).findFirst();
        assertThat(optionalForm).isPresent();
        assertThat(optionalForm.get().getSupportDocuments()).hasSize(1);
        ApplicationSupportDocument supportDocument = optionalForm.get().getSupportDocuments().get(0);
        assertThat(supportDocument.getCategory()).isEqualTo(mappedToEvidenceType);
        assertThat(supportDocument.getSupportId()).isNotBlank();
        List<ApplicationFile> supportFiles = supportDocument.getFiles();
        assertThat(supportFiles).hasSize(2);
    }

}
