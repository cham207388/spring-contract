package gov.dhs.uscis.intake.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static software.amazon.awssdk.auth.credentials.StaticCredentialsProvider.create;
import static software.amazon.awssdk.enhanced.dynamodb.TableSchema.fromClass;

import java.util.List;

import static org.testcontainers.containers.localstack.LocalStackContainer.Service.DYNAMODB;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.containers.output.Slf4jLogConsumer;
import org.testcontainers.utility.DockerImageName;
import org.testcontainers.utility.MountableFile;

import gov.dhs.uscis.intake.models.ErrorType;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.form.metadata.ErrorMap;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

public class FormServiceTest {

    
    private static final String DATE = "\\d{4}-\\d{2}-\\d{2}";
    private static final String TIME = "\\d{2}:\\d{2}:\\d{2}\\.\\d{3,9}"; 
    private static final String ISO_8601_UTC = DATE + "T" + TIME + "Z";
    
    private static final String TABLE_NAME = "FormMetaData";
    private static final DockerImageName localstackImage = DockerImageName.parse("nexus-nonprod-gss.uscis.dhs.gov:8132/localstack/localstack:3.4")
        .asCompatibleSubstituteFor("localstack/localstack");

    @SuppressWarnings("resource")
    private static final LocalStackContainer localStack = new LocalStackContainer(localstackImage)
            .withCopyFileToContainer(MountableFile.forHostPath("init-aws-local.sh"),
                    "/etc/localstack/init/ready.d/init-aws.sh")
            .withLogConsumer(new Slf4jLogConsumer(LoggerFactory.getLogger("localstack")))
            .withEnv("DEBUG", "1")
            .withStartupAttempts(10)
            .withServices(DYNAMODB);

    private static FormService formService;
    private static DynamoDbClient rawClient;
    private static DynamoDbEnhancedClient client;
    private static DynamoDbTable<FormMetaData> table;

    @BeforeAll
    static void before() {
        localStack.start();
        rawClient = DynamoDbClient.builder()
            .endpointOverride(localStack.getEndpoint())
            .credentialsProvider(
                create(AwsBasicCredentials.create(localStack.getAccessKey(), localStack.getSecretKey())))
            .region(Region.of(localStack.getRegion()))
            .build();
        client = DynamoDbEnhancedClient.builder().dynamoDbClient(rawClient).build();
        table = client.table(TABLE_NAME, fromClass(FormMetaData.class));
        formService = new FormService(table);
    }

    @BeforeEach
    void beforeEach() {
      rawClient.waiter().waitUntilTableExists(b -> b.tableName(TABLE_NAME));
    }
  
    @AfterEach
    void afterEach() {
      table.deleteTable();
      table.createTable();
    }
  
    @AfterAll
    static void afterAll() {
        localStack.stop();
    }

    @Test
    void shouldRetrieveFormMetaData() {

        FormMetaData testFormMetaData = FormMetaData.builder()
            .formType("I-751")
            .errorMap(
                List.of(
                    ErrorMap.builder()
                        .errorType(ErrorType.PAGE_NUMBER_ERROR)
                        .errorMessage("Your Form %s has a duplicate page (Page %s) and/or has been scanned in the wrong order. Please rescan your completed form to proceed")
                    .build(),
                    ErrorMap.builder()
                        .errorType(ErrorType.PAGE_ORDER_ERROR)
                        .errorMessage("Your Form %s has a duplicate page (Page %s) and/or has been scanned in the wrong order. Please rescan your completed form to proceed")
                    .build()
                )
            )
        .build();

        table.putItem(testFormMetaData);

        FormMetaData formMetaDataRetrieved = formService.retrieveFormMetaData("I-751");

        assertEquals(formMetaDataRetrieved.getFormType(), "I-751");

        List<ErrorMap> errorMap = formMetaDataRetrieved.getErrorMap();
        assertEquals(errorMap.size(), 2);

    }

}
