package gov.dhs.uscis.intake.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.constants.DocumentType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;

public class LockboxTransmissionUtilTest_lockboxTransmissionFromSubmission {
    @Test
    void shouldReturnNullIfSubmissionFormIsNull() {
        Submission submission = Instancio.create(Submission.class);
        submission.setFormType(FormType.I765);
        submission.setForms(List.of());
        LockboxTransmission transmission = LockboxTransmissionUtil.lockboxTransmissionFromSubmission(submission);
        assertThat(transmission.getSubmission().getPrimaryForm()).isNull();
    }

    @Test
    void shouldMapEvidences() {
        Submission submission = Instancio.create(Submission.class);
        submission.setFormType(FormType.I765);
        submission.setFeeWaiver(SubmissionEvidence.builder().build());
        submission.setEvidences(List.of(SubmissionEvidence.builder().type("Other").build(), SubmissionEvidence.builder().type("Other").build()));
        submission.setUserRequestedFeeWaiver(true);
        submission.setUserRequestedPartialFeeWaiver(false);
        LockboxTransmission transmission = LockboxTransmissionUtil.lockboxTransmissionFromSubmission(submission);
        assertThat(transmission.getSubmission().getEvidences().size()).isEqualTo(submission.getEvidences().size() + 1);
        assertThat(transmission.getSubmission().getEvidences().stream().filter(evidence -> evidence.getType().equals(DocumentType.FeeWaiver.FORM_I912)).count()).isEqualTo(1);
    }
}
