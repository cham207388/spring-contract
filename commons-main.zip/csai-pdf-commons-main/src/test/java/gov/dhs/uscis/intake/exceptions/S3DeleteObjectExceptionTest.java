package gov.dhs.uscis.intake.exceptions;

import static gov.dhs.uscis.intake.constants.S3Constants.DELETION_FAILURE_MESSAGE;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class S3DeleteObjectExceptionTest {
    @Test
    void testConstructor () {
        var ex = new S3DeleteObjectException("test message");
        assertThat(ex.getMessage()).isEqualTo(DELETION_FAILURE_MESSAGE + " : test message");
    }
}
