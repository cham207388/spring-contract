package gov.dhs.uscis.intake.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.services.formats.MagicBytes;

class FileFormatValidatorTest {

    private FileFormatValidator validator = new FileFormatValidator();

    @Test
    void shouldSayThatTheFileIsUnSupported(){
        assertThat(validator.isSupportedFile(MagicBytes.b(0x88), MagicBytes.b(0x50)))
            .isEqualTo(MagicBytes.UNSUPPORTED);
    }

    @Test
    void shouldSayFileIsaPNG(){
        MagicBytes detectedFormat = validator.isSupportedFile(MagicBytes.b(0x89), MagicBytes.b(0x50));
        assertThat(detectedFormat).isEqualTo(MagicBytes.PNG);
        assertThat(detectedFormat.getContentType()).isEqualTo("image/png");
        assertThat(detectedFormat.getExtension()).isEqualTo(".png");
    }

    @Test
    void shouldSayFileIsaJPEG(){
        MagicBytes detectedFormat = validator.isSupportedFile(MagicBytes.b(0xFF), MagicBytes.b(0xD8));
        assertThat(detectedFormat).isEqualTo(MagicBytes.JPG);
        assertThat(detectedFormat.getContentType()).isEqualTo("image/jpeg");
        assertThat(detectedFormat.getExtension()).isEqualTo(".jpeg");
    }

    @Test
    void shouldSayFileIsaTIFF_A(){
        MagicBytes detectedFormat = validator.isSupportedFile(MagicBytes.b(0x49) ,MagicBytes.b(0x49));
        assertThat(detectedFormat).isEqualTo(MagicBytes.TIFFA);
        assertThat(detectedFormat.getContentType()).isEqualTo("image/tiff");
        assertThat(detectedFormat.getExtension()).isEqualTo(".tiff");
    }

    @Test
    void shouldSayFileIsaTIFF_B(){
        MagicBytes detectedFormat = validator.isSupportedFile(MagicBytes.b(0x4D) ,MagicBytes.b(0x4D));
        assertThat(detectedFormat).isEqualTo(MagicBytes.TIFFB);
        assertThat(detectedFormat.getContentType()).isEqualTo("image/tiff");
        assertThat(detectedFormat.getExtension()).isEqualTo(".tiff");
    } 

    @Test
    void shouldSayFileIsaPDF() throws IOException{
        PDDocument doc = new PDDocument();
        var outputStream = new ByteArrayOutputStream();
        doc.save( outputStream);
        MagicBytes detectedFormat = validator.isSupportedFile(outputStream.toByteArray());
        assertThat(detectedFormat).isEqualTo(MagicBytes.PDF);
        assertThat(detectedFormat.getContentType()).isEqualTo("application/pdf");
        assertThat(detectedFormat.getExtension()).isEqualTo(".pdf");
    }

    @Test
    void shouldSayFileIsUnsupportedWhenFileIsHeic(){
        MagicBytes detectedFormat = validator.isSupportedFile(MagicBytes.b(0x66), 
            MagicBytes.b(0x74),
            MagicBytes.b(0x79));
        assertThat(detectedFormat).isEqualTo(MagicBytes.UNSUPPORTED);
    }

    @Test
    void shouldDoExtractOnInputStream() throws IOException{
        var buffer = MagicBytes.extract(InputStream.nullInputStream(), 0);
        assertNotNull(buffer);
    }
}