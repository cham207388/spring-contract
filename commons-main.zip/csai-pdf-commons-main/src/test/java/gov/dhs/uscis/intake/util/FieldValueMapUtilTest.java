package gov.dhs.uscis.intake.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static java.util.Collections.singletonMap;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

import org.junit.jupiter.api.Test;

import software.amazon.awssdk.services.textract.model.Block;
import software.amazon.awssdk.services.textract.model.BlockType;
import software.amazon.awssdk.services.textract.model.EntityType;
import software.amazon.awssdk.services.textract.model.Relationship;
import software.amazon.awssdk.services.textract.model.RelationshipType;
import software.amazon.awssdk.services.textract.model.TextType;

public class FieldValueMapUtilTest {
    
    @Test
    public void shouldGetKeyValueRelationShipForEmptyBlockArray() {
        Map<String, String> keyValueMap = FieldValueMapUtil.getKeyValueRelationShipByBlocks(List.of());
        assertThat(keyValueMap).isNotNull();
        assertTrue(keyValueMap.isEmpty());
    }

    @Test
    public void shouldGetKeyValueRelationShipForNoRelationships() {
        Map<String, String> keyValueMap = FieldValueMapUtil.getKeyValueRelationShipByBlocks(
            List.of(
                Block.builder()
                    .blockType(BlockType.WORD)
                    .text("TEST_TEXT_VALUE")
                .build()
                ,
                Block.builder()
                    .blockType(BlockType.KEY_VALUE_SET)
                .build()
                ,
                Block.builder()
                    .blockType(BlockType.SELECTION_ELEMENT)
                .build()
            )
        );
        assertThat(keyValueMap).isNotNull();
        assertTrue(keyValueMap.isEmpty());
    }

    @Test
    public void shouldGetKeyValueRelationShipWithNullBlock() {
        // This was taken as an example here: https://docs.aws.amazon.com/textract/latest/dg/how-it-works-kvp.html
            
        Map<String, String> keyValueMap = FieldValueMapUtil.getKeyValueRelationShipByBlocks(
            List.of(
                Block.builder()
                    .id("7ca7caa6-00ef-4cda-b1aa-5571dfed1a7c")
                    .page(1)
                    .blockType(BlockType.KEY_VALUE_SET)
                    .entityTypes(List.of(EntityType.VALUE))
                    .relationships(List.of(
                        Relationship.builder()
                            .ids(List.of(
                                "db553509-64ef-4ecf-ad3c-bea62cc1cd8a"
                            ))
                            .type(RelationshipType.CHILD)
                        .build()
                    ))
                .build()
                ,
                Block.builder()
                    .id("c734fca6-c4c4-415c-b6c1-30f7510b72ee")
                    .blockType(BlockType.WORD)
                    .textType(TextType.PRINTED)
                    .text("Name:")
                .build()
                ,
                Block.builder()
                    .id("db553509-64ef-4ecf-ad3c-bea62cc1cd8a")
                    .blockType(BlockType.WORD)
                    .textType(TextType.PRINTED)
                    .text("Ana Williams")
                .build()
                ,Block.builder()
                    .id("db553509-64ef-4ecf-ad3c-bea62cc1cd8a")
                    .blockType(BlockType.SELECTION_ELEMENT)
                    .textType(TextType.PRINTED)
                .build()
            )
        );
        assertThat(keyValueMap).isNotNull();

        assertTrue(keyValueMap.isEmpty());
    }

    @Test
    public void shouldGetKeyValueRelationShip() {
        // This was taken as an example here: https://docs.aws.amazon.com/textract/latest/dg/how-it-works-kvp.html
            
        Map<String, String> keyValueMap = FieldValueMapUtil.getKeyValueRelationShipByBlocks(
            List.of(
                Block.builder()
                    .id("52be1777-53f7-42f6-a7cf-6d09bdc15a30")
                    .page(1)
                    .blockType(BlockType.KEY_VALUE_SET)
                    .entityTypes(List.of(EntityType.KEY))
                    .relationships(List.of(
                        Relationship.builder()
                            .ids(List.of(
                                "c734fca6-c4c4-415c-b6c1-30f7510b72ee"
                            ))
                            .type(RelationshipType.CHILD)
                        .build()
                        ,
                        Relationship.builder()
                            .ids(List.of(
                                "7ca7caa6-00ef-4cda-b1aa-5571dfed1a7c"
                            ))
                            .type(RelationshipType.VALUE)
                        .build()
                    ))
                .build()
                ,
                Block.builder()
                    .id("7ca7caa6-00ef-4cda-b1aa-5571dfed1a7c")
                    .page(1)
                    .blockType(BlockType.KEY_VALUE_SET)
                    .entityTypes(List.of(EntityType.VALUE))
                    .relationships(List.of(
                        Relationship.builder()
                            .ids(List.of(
                                "db553509-64ef-4ecf-ad3c-bea62cc1cd8a"
                            ))
                            .type(RelationshipType.CHILD)
                        .build()
                    ))
                .build()
                ,
                Block.builder()
                    .id("c734fca6-c4c4-415c-b6c1-30f7510b72ee")
                    .blockType(BlockType.WORD)
                    .textType(TextType.PRINTED)
                    .text("Name:")
                .build()
                ,
                Block.builder()
                    .id("db553509-64ef-4ecf-ad3c-bea62cc1cd8a")
                    .blockType(BlockType.WORD)
                    .textType(TextType.PRINTED)
                    .text("Ana Williams")
                .build()
            )
        );
        assertThat(keyValueMap)
            .isNotNull()
            .hasSize(1)
            .containsKey("1-NAME")
            .containsValue("Ana Williams")
            .containsEntry("1-NAME", "Ana Williams");

    }


    @Test
    public void testMappings() {
        assertThat(FieldValueMapUtil.getUnitTypeFromKeyValues(
                singletonMap("1-STE", "foo"), "1")).isEqualTo("Ste.");
        assertThat(FieldValueMapUtil.getUnitTypeFromKeyValues(
                singletonMap("1-APT", "foo"), "1")).isEqualTo("Apt.");
        assertThat(FieldValueMapUtil.getUnitTypeFromKeyValues(
                singletonMap("1-FLR", "foo"), "1")).isEqualTo("Flr.");
        assertThat(FieldValueMapUtil.getUnitTypeFromKeyValues(
                new HashMap(), "1")).isNull();
    }


}
