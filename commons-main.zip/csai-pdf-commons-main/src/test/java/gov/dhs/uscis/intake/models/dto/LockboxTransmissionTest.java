package gov.dhs.uscis.intake.models.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.LockboxStatuses;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;

class LockboxTransmissionTest {
    @Test
    // TODO break these out into individual tests, so we can identify which
    // conditions are covered as well
    // as pin point breaks in the future.
    @Disabled("This test needs to be reworked when we rework the submission vs lockbox form concept.")
    void shouldMapSubmissionToLockboxTransmission() {
        List<SubmissionEvidence> evidences = Instancio.ofList(SubmissionEvidence.class)
                .size(2).create();
        final SubmissionForm form = Instancio.create(SubmissionForm.class);

        final Submission submission = Instancio.create(Submission.class);
        submission.setSubmissionId("12345");
        submission.setForms(List.of(form));
        submission.setEvidences(evidences);
        submission.setLockboxStatus(LockboxStatuses.PENDING);

        // final LockboxSubmission result =
        // LockboxTransmission.fromSubmission(submission);

        // TODO Speak with Odwayne about the lockbox form.
        evidences = Instancio.ofList(SubmissionEvidence.class) .size(3).create();

        LockboxSubmission result = LockboxSubmission.builder()
                .submissionId(submission.getSubmissionId())
                .feeWaiver(true)
                .feeTotal(submission.getFeeTotal())
                .lockboxStatus(StatusEnum.PENDING)
                .evidences(evidences)
            .build();

        assertEquals(submission.getSubmissionId(), result.getSubmissionId());
        assertEquals(3, result.getEvidences().size());
        assertTrue(result.getFeeWaiver());
        assertEquals(submission.getFeeTotal(), result.getFeeTotal());
        assertEquals(submission.getLockboxStatus(), result.getLockboxStatus());

        final LockboxForm resultForm = result.getPrimaryForm();
        assertEquals(form.getId(), resultForm.getId());
        assertEquals(form.getMd5Hash(), resultForm.getMd5Hash());
        assertEquals(form.getName(), resultForm.getName());
        assertEquals(form.getType(), resultForm.getType());
        assertEquals(form.getUrl(), resultForm.getUrl());
        SubmissionEvidence submissionFeeWaiver = submission.getFeeWaiver();
        List<SubmissionEvidence> filteredList = result.getEvidences().stream()
                .filter(evidence -> evidence.getType() == submissionFeeWaiver.getType()).toList();
        assertFalse(filteredList.isEmpty());

        SubmissionEvidence actualFeeWaiverEvidence = filteredList.get(0);
        assertEquals(submissionFeeWaiver.getId(), actualFeeWaiverEvidence.getId());
        assertEquals(submissionFeeWaiver.getMd5Hash(), filteredList.get(0).getMd5Hash());
        assertEquals(submissionFeeWaiver.getName(), filteredList.get(0).getName());
        assertEquals(submissionFeeWaiver.getType(), filteredList.get(0).getType());
        assertEquals(submissionFeeWaiver.getUrl(), filteredList.get(0).getUrl());

        submission.setFeeWaiver(null);
        
        LockboxSubmission newResult = LockboxSubmission.builder()
                .submissionId(submission.getSubmissionId())
                .feeWaiver(true)
                .feeTotal(submission.getFeeTotal())
                .lockboxStatus(StatusEnum.PENDING)
                .evidences(submission.getEvidences())
            .build();

        assertFalse(newResult.getFeeWaiver());
        assertEquals(2, newResult.getEvidences().size());
    }
}
