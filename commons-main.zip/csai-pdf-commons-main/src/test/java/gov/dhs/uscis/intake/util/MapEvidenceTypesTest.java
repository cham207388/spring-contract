package gov.dhs.uscis.intake.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;

public class MapEvidenceTypesTest {
    @Test
    void shouldMapEOIRBIAEvidence() {
        assertThat(MapEvidenceTypes.mapEOIRBIAEvidence(SubmissionEvidence.builder().type("EOIR").build()).getType()).isEqualTo("Other");
        assertThat(MapEvidenceTypes.mapEOIRBIAEvidence(SubmissionEvidence.builder().type("BIA Order").build()).getType()).isEqualTo("Other");
        assertThat(MapEvidenceTypes.mapEOIRBIAEvidence(SubmissionEvidence.builder().type("Photo").build()).getType()).isEqualTo("Photo");
    }

    @Test
    void shouldMapEOIRBIAEvidenceList() {
        assertThat(MapEvidenceTypes.mapEOIRBIAEvidenceList(List.of(SubmissionEvidence.builder().type("EOIR").build())).get(0).getType()).isEqualTo("Other");
        assertThat(MapEvidenceTypes.mapEOIRBIAEvidenceList(List.of(SubmissionEvidence.builder().type("BIA Order").build())).get(0).getType()).isEqualTo("Other");
        assertThat(MapEvidenceTypes.mapEOIRBIAEvidenceList(List.of(SubmissionEvidence.builder().type("Photo").build())).get(0).getType() ).isEqualTo("Photo");
    }
}
