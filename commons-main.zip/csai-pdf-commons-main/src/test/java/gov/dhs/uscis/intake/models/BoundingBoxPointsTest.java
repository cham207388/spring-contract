package gov.dhs.uscis.intake.models;


import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.models.form_extraction.BoundingBoxPoints;
import software.amazon.awssdk.services.textract.model.BoundingBox;

public class BoundingBoxPointsTest {

  @Test
  public void shouldReturnTrueIfBoundsEnclosed(){
    BoundingBoxPoints boundingBox = new BoundingBoxPoints(0.5f,0.6f,0.5f,0.6f);
    BoundingBox blockBounds = BoundingBox.builder().top(0.45f).height(0.2f).left(0.45f).width(0.2f).build();
    // midXPoint = 0.55
    // midYPoint = 0.55
    assertTrue(boundingBox.isEnclosing(blockBounds));
  }

  @Test
  public void shouldReturnFalseIfBoundsEnclosed(){
    BoundingBoxPoints boundingBox = new BoundingBoxPoints(0.5f,0.6f,0.5f,0.6f);
    BoundingBox blockBounds = BoundingBox.builder().top(0f).height(0.2f).left(0.45f).width(0.2f).build();
    // midXPoint = 0.1
    // midYPoint = 0.55
    assertFalse(boundingBox.isEnclosing(blockBounds));
  }

  @Test
  public void shouldReturnTrueIfBoxesIntersect(){
    BoundingBoxPoints boundingBox = new BoundingBoxPoints(0.5f,0.6f,0.5f,0.6f);
    BoundingBox blockBounds = BoundingBox.builder().top(0.5f).height(0.2f).left(0.45f).width(0.2f).build();

    assertTrue(boundingBox.isIntersecting(blockBounds));
  }

  @Test
  public void shouldReturnFalseIfBoxesDoNotIntersect(){
    BoundingBoxPoints boundingBox = new BoundingBoxPoints(0.55f,0.6f,0.5f,0.6f);
    BoundingBox blockBounds = BoundingBox.builder().top(0.5f).height(0.02f).left(0.45f).width(0.2f).build();

    assertFalse(boundingBox.isIntersecting(blockBounds));
  }

}