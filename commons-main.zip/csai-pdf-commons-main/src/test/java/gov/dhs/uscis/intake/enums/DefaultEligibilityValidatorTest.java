package gov.dhs.uscis.intake.enums;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class DefaultEligibilityValidatorTest {

    private DefaultEligibilityValidator validator = new DefaultEligibilityValidator();

    @Test
    public void shouldHandleIfZeroInExtractedC8(){
        assertThat(validator.isValid("C8", "C08")).isTrue();
    }

    @Test
    public void shouldHandleIfSpaceInExtractedC_8(){
        assertThat(validator.isValid("C8", "C 8")).isTrue();
    }


    @Test
    public void shoudlNotMatchIfC11WithC1(){
        assertThat(validator.isValid("C11 - Afghan Parolee", "C1")).isFalse();
    }

    @Test
    public void shouldNotWorkIfStringIsNotCompleteComparedToActualCategory(){
        assertThat(validator.isValid("A12", "A1")).isFalse();   
    }
}
