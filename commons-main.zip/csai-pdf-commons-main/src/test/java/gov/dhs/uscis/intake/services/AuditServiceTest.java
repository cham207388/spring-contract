package gov.dhs.uscis.intake.services;

import static gov.dhs.uscis.intake.entities.audit.ActionPerformed.SELECT_ELIGIBILITY_CATEGORY;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.daos.AuditDAO;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.audit.Audit;
import gov.dhs.uscis.intake.entities.audit.Audit.Event;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;

@ExtendWith(MockitoExtension.class)
class AuditServiceTest {

    @Mock
    AuditDAO auditDao;

    @Mock
    Clock clock;

    @InjectMocks
    AuditService service;

    @Test
    void createAudit_shouldSucceed() {
        Instant now = Instant.now();

        String myUscisId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();

        when(clock.instant()).thenReturn(now);
        when(auditDao.save(any(Audit.class))).thenAnswer(call -> call.getArgument(0));

        Audit actual = service.createAudit(myUscisId, submissionId);
        verify(auditDao, times(1)).save(any(Audit.class));

        assertNotNull(actual);
        assertEquals(myUscisId, actual.getMyUscisId());
        assertEquals(submissionId, actual.getSubmissionId());
        assertEquals(1, actual.getEvents().size());
        assertEquals(SubmissionState.DRAFT, actual.getEvents().get(0).getSubmissionState());
        assertEquals(ActionPerformed.DRAFT_CREATED, actual.getEvents().get(0).getActionPerformed());
        assertEquals(now, actual.getEvents().get(0).getTimestamp());
    }

    @Test
    void shouldAddNewEvent() {
        Instant now = Instant.now();
        String myUscisId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        String metadata = "some metadata";
        List<Event> events = new ArrayList<>();
        events.add(Event.builder()
                .actionPerformed(ActionPerformed.DRAFT_CREATED)
                .submissionState(SubmissionState.DRAFT)
                .timestamp(this.clock.instant())
                .build());

        Audit source = Audit.builder()
                .myUscisId(myUscisId)
                .submissionId(submissionId)
                .events(events)
                .build();
        when(clock.instant()).thenReturn(now);
        when(auditDao.find(myUscisId, submissionId)).thenReturn(source);
        when(auditDao.update(any(Audit.class))).thenAnswer(call -> call.getArgument(0));

        Audit newTrail = this.service.addEvent(myUscisId, submissionId, SELECT_ELIGIBILITY_CATEGORY, metadata);
        assertEquals(2, newTrail.getEvents().size());
        assertEquals(SubmissionState.DRAFT, newTrail.getEvents().get(1).getSubmissionState());
        assertEquals(SELECT_ELIGIBILITY_CATEGORY, newTrail.getEvents().get(1).getActionPerformed());
        assertEquals(metadata, newTrail.getEvents().get(1).getMetadata());
        assertEquals(now, newTrail.getEvents().get(1).getTimestamp());
    }

    @Test
    void shouldAddNewEvent_whenAuditDAOReturnsNull() {
        String myUscisId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        String metadata = "some metadata";

        when(auditDao.find(myUscisId, submissionId)).thenReturn(null);

        var audit = this.service.addEvent(myUscisId, submissionId, SELECT_ELIGIBILITY_CATEGORY, metadata);
        assertNull(audit);
    }
}
