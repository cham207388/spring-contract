package gov.dhs.uscis.intake.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.time.ZonedDateTime;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;

public class SubmissionUtilsTest {

    @Test
    public void shouldThrowIllegalStateExceptionWhenTryingToConstruct()
            throws NoSuchMethodException, SecurityException {
        Constructor<SubmissionUtils> constructor = SubmissionUtils.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        assertThrows(InvocationTargetException.class, constructor::newInstance);
    }

    @Test
    public void shouldNotConvertAndValidateFiltersWhenThereIsAnIllegalArgumentException(){
        var filters = SubmissionUtils.convertAndValidateFilters("*/. - *");

        assertThat(filters).isEmpty();
    }

    @Test
    public void shouldConvertOverAStringToValidSubmissionState() {
        var filters = SubmissionUtils.convertAndValidateFilters("REJECTED,ACCEPTED");

        assertThat(filters)
            .hasSize(2)
            .contains(SubmissionState.ACCEPTED)
            .contains(SubmissionState.REJECTED);
    }

    @Test
    public void shouldHandleWhenThereAreNoFilterTermsThatAreProvided() {
        var filters = SubmissionUtils.convertAndValidateFilters("");
        assertThat(filters).isEmpty();
    }

    @Test
    public void shouldHandleWhenTheTermIsNull() {
        var filters = SubmissionUtils.convertAndValidateFilters(null);
        assertThat(filters).isEmpty();
    }

    @Test
    public void shouldCopySubmission() {
        Submission submission = Instancio.create(Submission.class);
        Submission copy = SubmissionUtils.copySubmission(submission);
        submission.setLockedAt(ZonedDateTime.now());
        submission.setTimestamp(ZonedDateTime.now());
        submission.setUpdatedAt(ZonedDateTime.now());
        submission.setSubmittedAt(ZonedDateTime.now());
        submission.setAttestedAt(ZonedDateTime.now());

        assertThat(copy.getApplicant()).isEqualTo(submission.getApplicant());
        assertThat(copy.getEligibilityCategory()).isEqualTo(submission.getEligibilityCategory());
        assertThat(copy.getFormType()).isEqualTo(submission.getFormType());
        assertThat(copy.getMyUscisId()).isEqualTo(submission.getMyUscisId());
        assertThat(copy.getStatus()).isEqualTo(submission.getStatus());
        assertThat(copy.getFeeTotal()).isEqualTo(submission.getFeeTotal());
        assertThat(copy.getForms()).isEqualTo(submission.getForms());
        assertThat(copy.getEvidences()).isEqualTo(submission.getEvidences());
        assertThat(copy.getFeeWaiver()).isEqualTo(submission.getFeeWaiver());
        assertThat(copy.getUserRequestedFeeWaiver()).isEqualTo(submission.getUserRequestedFeeWaiver());
        assertThat(copy.getUserRequestedPartialFeeWaiver()).isEqualTo(submission.getUserRequestedPartialFeeWaiver());
        assertThat(copy.getUserIsEligibleForFeeWaiver()).isEqualTo(submission.getUserIsEligibleForFeeWaiver());
        assertThat(copy.getImmvi()).isEqualTo(submission.getImmvi());
        assertThat(copy.getReasonForFiling()).isEqualTo(submission.getReasonForFiling());
        assertThat(copy.getSubmissionId()).isNotEqualTo(submission.getSubmissionId());
        assertThat(copy.getManifestId()).isNotEqualTo(submission.getManifestId());
        assertThat(copy.getLockboxStatus()).isNotEqualTo(submission.getLockboxStatus());
        assertThat(copy.getLockedAt()).isNull();
        assertThat(copy.getAttestationSignature()).isNotEqualTo(submission.getAttestationSignature());
        assertThat(copy.getAttested()).isNotEqualTo(submission.getAttested());
        assertThat(copy.getAttestedAt()).isNull();
        assertThat(copy.getLockboxErrors()).isNotEqualTo(submission.getLockboxErrors());
        assertThat(copy.getSubmittedAt()).isNull();
        assertThat(copy.getTimestamp()).isNotEqualTo(submission.getTimestamp());
        assertThat(copy.getUpdatedAt()).isNull();
    }

    @Test
    public void shouldConvertFormToEvidence() {
        SubmissionForm form = Instancio.create(SubmissionForm.class);
        SubmissionEvidence evidence = SubmissionUtils.convertToEvidence(form);

        assertThat(evidence.getType()).isEqualTo("Other");
        assertThat(evidence.getEvidenceGroupType()).isEqualTo("additional-evidence");
        assertThat(evidence.getId()).isEqualTo(form.getId());
        assertThat(evidence.getUrl()).isEqualTo(form.getUrl());
        assertThat(evidence.getName()).isEqualTo(form.getName());
        assertThat(evidence.getMd5Hash()).isEqualTo(form.getMd5Hash());
        assertThat(evidence.getUploadedAt()).isEqualTo(form.getUploadedAt());
        assertThat(evidence.getS3Key()).isEqualTo(form.getS3Key());
        assertThat(evidence.getMarkedS3Key()).isEqualTo(form.getMarkedS3Key());
    }
}
