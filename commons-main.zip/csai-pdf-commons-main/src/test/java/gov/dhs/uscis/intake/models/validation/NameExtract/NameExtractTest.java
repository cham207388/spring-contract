package gov.dhs.uscis.intake.models.validation.NameExtract;


import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.validation.name_extract.ClientName;
import gov.dhs.uscis.intake.models.validation.name_extract.NameExtract;

class NameExtractTest {

    @Test
    void shouldSetNameExtractForExistingI765() {

        NameExtract existingNameExtract = NameExtract.builder()
            .clientNameOnForm(
                ClientName.builder()
                    .givenName(null)
                    .familyName(null)
                    .build()
            )
            .clientNameOnG28(null)
            .form(FormType.I765)
            .build()
        ;

        existingNameExtract.updateClientName(
            FormType.G28,
            ClientName.builder()
                .givenName(null)
                .familyName(null)
                .build(),
            "TEST_FORM_ID");

        assertTrue(existingNameExtract.hasAllNamesForValidation());

    }

    @Test
    void shouldSetNameExtractForExistingG28() {

        NameExtract existingNameExtract = NameExtract.builder()
            .clientNameOnForm(null)
            .clientNameOnG28(ClientName.builder()
                    .givenName(null)
                    .familyName(null)
                    .build())
            .form(FormType.G28)
            .build()
        ;

        existingNameExtract.updateClientName(
            FormType.I765,
            ClientName.builder()
                .givenName(null)
                .familyName(null)
                .build(),
            "TEST_FORM_ID");

        assertTrue(existingNameExtract.hasAllNamesForValidation());

    }


}
