package gov.dhs.uscis.intake.enums;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class I485JEligibilityCategoryTest {

    @Test
    void shouldGetEligibilityByEnumStringForBackwardCompatibility() {
        EligibilityCategoryEnum.EligibilityCategoryRegistry.register(I485JEligibilityCategory.REQUEST_FOR_JOB_PORTABILITY);
        EligibilityCategoryEnum category = EligibilityCategoryEnum.fromString("RequestForJobPortability");

        assertThat(category).isEqualTo(I485JEligibilityCategory.REQUEST_FOR_JOB_PORTABILITY);
    }

}
