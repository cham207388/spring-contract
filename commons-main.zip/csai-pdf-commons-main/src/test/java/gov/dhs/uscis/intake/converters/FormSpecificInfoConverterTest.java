package gov.dhs.uscis.intake.converters;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I751FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I765FormSpecificInfo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.lang.reflect.Field;

public class FormSpecificInfoConverterTest {

    private FormSpecificInfoConverter converter;

    @BeforeEach
    void setUp() {
        converter = new FormSpecificInfoConverter();
    }

    @Test
    void transformFrom_ShouldSerializeCorrectly_WhenGivenI751FormSpecificInfo() throws JsonMappingException, JsonProcessingException {
        I751FormSpecificInfo i751 = new I751FormSpecificInfo(true);
        FormSpecificInfo i751FromJson = new ObjectMapper().readValue("{\"formType\":\"I-751\",\"isUnderOrders\":true}", FormSpecificInfo.class);

        String expectedJson = "{\"formType\":\"I-751\",\"isUnderOrders\":true}";


        assertEquals(expectedJson, converter.transformFrom(i751).s());
        assertEquals(expectedJson, converter.transformFrom(i751FromJson).s());
    }

    @Test
    void transformFrom_ShouldSerializeCorrectly_WhenGivenI765FormSpecificInfo() throws JsonMappingException, JsonProcessingException {
        I765FormSpecificInfo i765 = new I765FormSpecificInfo(true);
        FormSpecificInfo i765FromJson = new ObjectMapper().readValue("{\"formType\":\"I-765\",\"underABCAgreement\":true}", FormSpecificInfo.class);

        String expectedJson = "{\"formType\":\"I-765\",\"before04012024\":false,\"onOrAfterApril012024\":false,\"feeWaiverRequested\":false,\"immvi\":false,\"reasonForFiling\":null,\"underABCAgreement\":true}";


        assertEquals(expectedJson, converter.transformFrom(i765).s());
        assertEquals(expectedJson, converter.transformFrom(i765FromJson).s());
    }

    @Test
    void transformTo_ShouldDeserializeCorrectly_WhenGivenI751Json() {
        String json = "{\"formType\":\"I-751\",\"isUnderOrders\":false}";
        AttributeValue attributeValue = AttributeValue.builder().s(json).build();

        FormSpecificInfo result = converter.transformTo(attributeValue);

        assertNotNull(result);
        assertInstanceOf(I751FormSpecificInfo.class, result);
        I751FormSpecificInfo i751Info = (I751FormSpecificInfo) result;
        assertEquals(FormType.I751, i751Info.getFormType());
        assertFalse(i751Info.isUnderOrders());
    }



    @Test
    void transformTo_ShouldDeserializeCorrectly_WhenGivenI765Json() {
        String json = "{\"formType\":\"I-765\",\"underABCAgreement\":false}";
        AttributeValue attributeValue = AttributeValue.builder().s(json).build();

        FormSpecificInfo result = converter.transformTo(attributeValue);

        assertNotNull(result);
        assertInstanceOf(I765FormSpecificInfo.class, result);
        I765FormSpecificInfo i765info = (I765FormSpecificInfo) result;
        assertEquals(FormType.I765, i765info.getFormType());
        assertFalse(i765info.isUnderABCAgreement());
    }
    @Test
    void transformFrom_ShouldHandleSerializationError() throws JsonProcessingException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        ObjectMapper brokenMapper = mock(ObjectMapper.class);
        when(brokenMapper.writeValueAsString(any())).thenThrow(new JsonProcessingException("Test error") {});

        Field field = FormSpecificInfoConverter.class.getDeclaredField("objectMapper");
        field.setAccessible(true);
        field.set(null, brokenMapper);

        I751FormSpecificInfo i751Info = new I751FormSpecificInfo( true);

        RuntimeException thrown = assertThrows(RuntimeException.class, () -> converter.transformFrom(i751Info));
        assertTrue(thrown.getMessage().contains("Error converting FormSpecificInfo to JSON string"));

        field.set(null, new ObjectMapper());
    }

    @SuppressWarnings("unchecked")
    @Test
    void transformTo_ShouldHandleDeserializationError() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        AttributeValue invalidAttributeValue = AttributeValue.builder().s("invalid-json").build();
        ObjectMapper brokenMapper = mock(ObjectMapper.class);
        when(brokenMapper.readValue(anyString(), any(Class.class))).thenThrow(new JsonProcessingException("Test error") {});

        Field field = FormSpecificInfoConverter.class.getDeclaredField("objectMapper");
        field.setAccessible(true);
        field.set(null, brokenMapper);

        RuntimeException thrown = assertThrows(RuntimeException.class, () -> converter.transformTo(invalidAttributeValue));
        assertTrue(thrown.getMessage().contains("Error converting JSON string to FormSpecificInfo"));

        field.set(null, new ObjectMapper());
    }

    @Test
    void type_ShouldReturnCorrectEnhancedType() {
        EnhancedType<FormSpecificInfo> enhancedType = converter.type();

        assertEquals(EnhancedType.of(FormSpecificInfo.class), enhancedType);
    }

    @Test
    void attributeValueType_ShouldReturnCorrectType() {
        AttributeValueType attributeValueType = converter.attributeValueType();

        assertEquals(AttributeValueType.S, attributeValueType);
    }

    @Test
    void transformFrom_ShouldReturnNullAttributeValue_WhenGivenNull() {
        AttributeValue result = converter.transformFrom(null);

        assertNotNull(result);
        assertTrue(result.nul());
    }

    @Test
    void transformTo_ShouldReturnNull_WhenAttributeValueIsNull() {
        assertNull(converter.transformTo(null));
    }

    @Test
    void transformTo_ShouldReturnNull_WhenAttributeValueHasNoString() {
        AttributeValue nulAttribute = AttributeValue.builder().nul(true).build();
        AttributeValue emptyAttribute = AttributeValue.builder().build();

        assertNull(converter.transformTo(nulAttribute));
        assertNull(converter.transformTo(emptyAttribute));
    }

    @Test
    void transformTo_ShouldReturnNull_WhenStringIsEmpty() {
        AttributeValue emptyStringAttribute = AttributeValue.builder().s("").build();

        assertNull(converter.transformTo(emptyStringAttribute));
    }

}
