package gov.dhs.uscis.intake.util;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import gov.dhs.uscis.intake.enums.FormType;

public class I129FormTypeConverterTest  {

    @Test
    public void shouldConvertI129H1BToHaveSpace() {
        String convertInput = FormType.I129H1B.getType();
        String expectedOutput = "I-129 H1B";
        String actualOutput = I129FormTypeConverter.fromFormType(convertInput);

        assertThat(actualOutput).isEqualTo(expectedOutput);
    }

    @Test
    public void shouldConvertI129EnumH1BToNOTHaveSpace() {
        String convertInput = "I-129 H1B";
        String expectedOutput = FormType.I129H1B.getType();
        String actualOutput = I129FormTypeConverter.toFormEnum(convertInput);

        assertThat(actualOutput).isEqualTo(expectedOutput);
        assertThat(I129FormTypeConverter.toFormEnum("I-129")).isEqualTo(expectedOutput);
    }

    @Test
    public void shouldLeaveNONI129H1BUnchanged() {
        String convertInput = FormType.I765.getType();
        String expectedOutput = FormType.I765.getType();
        String actualOutput = I129FormTypeConverter.fromFormType(convertInput);

        assertThat(actualOutput).isEqualTo(expectedOutput);
    }

    @Test
    public void shouldLeaveNONI129H1BUnchangedtoFormEnum() {
        String convertInput = FormType.I765.getType();
        String expectedOutput = FormType.I765.getType();
        String actualOutput = I129FormTypeConverter.toFormEnum(convertInput);

        assertThat(actualOutput).isEqualTo(expectedOutput);
    }

}
