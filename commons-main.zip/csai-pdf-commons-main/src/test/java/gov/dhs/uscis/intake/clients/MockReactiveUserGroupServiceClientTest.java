package gov.dhs.uscis.intake.clients;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

public class MockReactiveUserGroupServiceClientTest {

    @Test
    public void shouldReturnStaticFakeGroupId() {
        var client = new MockReactiveUserGroupServiceClient();
        Assertions.assertThat(client.getRepGroupId("foo").block().getUserGroupId()).isEqualTo("fakeGroupId");
    }

    @Test
    public void shouldMockInviteClient() {
        var client = new MockReactiveUserGroupServiceClient();
        var response = client.inviteClient(null, null, null, null, null).block();
        Assertions.assertThat(response.getClientId()).isNotNull();
    }

    @Test
    public void shouldAlwaysSayClientIsAssociated() {
        var client = new MockReactiveUserGroupServiceClient();
        var info = client.isClientAssociated("icam", "applicant").block();
        Assertions.assertThat(info.isAssociated()).isTrue();
        Assertions.assertThat(info.clientUserGroupId()).isNotNull();
    }
}
