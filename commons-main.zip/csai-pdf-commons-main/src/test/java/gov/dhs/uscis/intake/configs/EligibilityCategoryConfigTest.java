package gov.dhs.uscis.intake.configs;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I129EEligibilityCategory;
import gov.dhs.uscis.intake.enums.I129H1BEligibilityCategory;
import gov.dhs.uscis.intake.enums.I129H2AEligibilityCategory;
import gov.dhs.uscis.intake.enums.I129REligibilityCategory;
import gov.dhs.uscis.intake.enums.I485EligibilityCategory;
import gov.dhs.uscis.intake.enums.I485JEligibilityCategory;

public class EligibilityCategoryConfigTest {

    private static EligibilityCategoryConfig eligibilityCategoryConfig;

    @BeforeAll()
    static void initEligibilityCategoryConfig() {
        eligibilityCategoryConfig = new EligibilityCategoryConfig();
        eligibilityCategoryConfig.registerEnums();
    }


    @Test
    void shouldLoadFormTypes() {
        assertThat(FormType.fromString("I-129H1B")).isEqualTo(FormType.I129H1B);
        assertThat(FormType.fromString("I-129E")).isEqualTo(FormType.I129E);
        assertThat(FormType.fromString("I-129R")).isEqualTo(FormType.I129R);
        assertThat(FormType.fromString("I-129H2A")).isEqualTo(FormType.I129H2A);
        assertThat(FormType.fromString("I-485")).isEqualTo(FormType.I485);
        assertThat(FormType.fromString("I-485A")).isEqualTo(FormType.I485A);
        assertThat(FormType.fromString("I-485J")).isEqualTo(FormType.I485J);
    }

    @Test
    void shouldLoadEligibilityCategories() {

        assertThat(EligibilityCategoryEnum.fromString("H1B_NEW_EMPLOYMENT"))
            .isEqualTo(I129H1BEligibilityCategory.H1B_NEW_EMPLOYMENT);

        assertThat(EligibilityCategoryEnum.fromString("E_NEW_EMPLOYMENT"))
            .isEqualTo(I129EEligibilityCategory.E_NEW_EMPLOYMENT);

        assertThat(EligibilityCategoryEnum.fromString("R_NEW_EMPLOYMENT"))
            .isEqualTo(I129REligibilityCategory.R_NEW_EMPLOYMENT);

        assertThat(EligibilityCategoryEnum.fromString("NEW_EMPLOYMENT"))
            .isEqualTo(I129H2AEligibilityCategory.NEW_EMPLOYMENT);

        assertThat(EligibilityCategoryEnum.fromString("PrincipalApplicant"))
                .isEqualTo(I485EligibilityCategory.PRINCIPAL_APPLICANT);


        assertThat(EligibilityCategoryEnum.fromString("RequestForJobPortability"))
            .isEqualTo(I485JEligibilityCategory.REQUEST_FOR_JOB_PORTABILITY);


    }

}
