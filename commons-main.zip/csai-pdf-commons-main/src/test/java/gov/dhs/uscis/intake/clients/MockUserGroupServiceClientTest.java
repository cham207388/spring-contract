package gov.dhs.uscis.intake.clients;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

public class MockUserGroupServiceClientTest {

    /*
     * Todo replace this client with a test double.
     */
    @Test
    public void shouldReturnStaticFakeGroupId() {
        var client = new MockUserGroupServiceClient();
        Assertions.assertThat(client.getRepGroupId("foo").getUserGroupId()).isEqualTo("fakeGroupId");
    }

    @Test
    public void shouldMockInviteClient() {
        var client = new MockUserGroupServiceClient();
        var response = client.inviteClient(null, null, null, null, null);
        Assertions.assertThat(response.getClientId()).isNotNull();
    }

    @Test
    public void shouldAlwaysSayClientIsAssociated() {
        var client = new MockUserGroupServiceClient();
        var info = client.isClientAssociated("icam", "applicant");
        Assertions.assertThat(info.isAssociated()).isTrue();
        Assertions.assertThat(info.clientUserGroupId()).isNotNull();
    }
}
