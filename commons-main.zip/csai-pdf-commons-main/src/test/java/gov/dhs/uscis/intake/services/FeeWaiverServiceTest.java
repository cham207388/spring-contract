package gov.dhs.uscis.intake.services;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.containers.output.Slf4jLogConsumer;
import org.testcontainers.utility.DockerImageName;
import org.testcontainers.utility.MountableFile;

import static software.amazon.awssdk.auth.credentials.StaticCredentialsProvider.create;
import static software.amazon.awssdk.enhanced.dynamodb.TableSchema.fromClass;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.testcontainers.containers.localstack.LocalStackContainer.Service.DYNAMODB;

import gov.dhs.uscis.intake.models.form.metadata.FeeWaiverEditions;
import gov.dhs.uscis.intake.models.form.metadata.FeeWaiverMetaData;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

public class FeeWaiverServiceTest {

    private static final String TABLE_NAME = "default-FeeWaiverMetaData";
    private static final DockerImageName localstackImage = DockerImageName.parse("nexus-nonprod-gss.uscis.dhs.gov:8132/localstack/localstack:3.4")
        .asCompatibleSubstituteFor("localstack/localstack");

    @SuppressWarnings("resource")
    private static final LocalStackContainer localStack = new LocalStackContainer(localstackImage)
            .withCopyFileToContainer(MountableFile.forHostPath("init-aws-local.sh"),
                    "/etc/localstack/init/ready.d/init-aws.sh")
            .withLogConsumer(new Slf4jLogConsumer(LoggerFactory.getLogger("localstack")))
            .withEnv("DEBUG", "1")
            .withStartupAttempts(10)
            .withServices(DYNAMODB);

    private static FeeWaiverService feeWaiverService;
    private static DynamoDbClient rawClient;
    private static DynamoDbEnhancedClient client;
    private static DynamoDbTable<FeeWaiverMetaData> feeWaiverTable;


    @BeforeAll
    static void before() {
        localStack.start();
        rawClient = DynamoDbClient.builder()
            .endpointOverride(localStack.getEndpoint())
            .credentialsProvider(
                create(AwsBasicCredentials.create(localStack.getAccessKey(), localStack.getSecretKey())))
            .region(Region.of(localStack.getRegion()))
            .build();
        client = DynamoDbEnhancedClient.builder().dynamoDbClient(rawClient).build();
        feeWaiverTable = client.table(TABLE_NAME, fromClass(FeeWaiverMetaData.class));
        feeWaiverService = new FeeWaiverService(feeWaiverTable);
    }

    @BeforeEach
    void beforeEach() {
      rawClient.waiter().waitUntilTableExists(b -> b.tableName(TABLE_NAME));
    }

    @AfterEach
    void afterEach() {
      feeWaiverTable.deleteTable();
      feeWaiverTable.createTable();
    }

    @AfterAll
    static void afterAll() {
        localStack.stop();
    }


    @Test
    void shouldRetrieveFormMetaData() {

        final String TEST_FORM_DESCRIPTION = "TEST_FORM_DESCRIPTION";
        final String TEST_FORM_TYPE = "TEST_FORM_TYPE";

        final FeeWaiverEditions testFeeWaiverEditions = FeeWaiverEditions.builder()
                    .edition("TEST_EDITION")
                    .expires("TEST_EXPIRES")
                    .numberOfPages(2)
                    .signaturePage(101)
                .build();

        FeeWaiverMetaData feeWaiverMetaData = FeeWaiverMetaData.builder()

            .formDescription(TEST_FORM_DESCRIPTION)
            .formType(TEST_FORM_TYPE)
            .editions(List.of(
                testFeeWaiverEditions
            ))
        .build();

        feeWaiverTable.putItem(feeWaiverMetaData);

        FeeWaiverMetaData feeWaiverMetaDataRetrieved = feeWaiverService.retrieveFeeWaiverMetaData(TEST_FORM_TYPE);

        assertEquals(feeWaiverMetaDataRetrieved.getFormType(), TEST_FORM_TYPE);
        assertEquals(feeWaiverMetaDataRetrieved.getFormDescription(), TEST_FORM_DESCRIPTION);
        assertEquals(feeWaiverMetaData.getEditions().get(0), testFeeWaiverEditions);

    }

}
