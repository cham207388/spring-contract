package gov.dhs.uscis.intake.clients;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.user_group.ClientDetailsResponse;
import gov.dhs.uscis.intake.models.user_group.UserGroupResponse;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;
import gov.dhs.uscis.intake.models.user_group.UserGroupRoleData;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

@ExtendWith(MockitoExtension.class)
public class UserGroupServiceClientTest {

    String applicantUUID = UUID.randomUUID().toString();
    String icamUUID = UUID.randomUUID().toString();
    String repUserGroupUUID = UUID.randomUUID().toString();

    private String clientListSuccessResponse = "{\n" + //
            "  \"data\": [\n" + //
            "    {\n" + //
            "      \"clientName\": \"American Mortgage\",\n" + //
            "      \"clientType\": \"organization\",\n" + //
            "      \"clientGroupId\": \"O-36bc119a-b456-47dc-8f5e-5289ec61952a\",\n" + //
            "      \"collaborationGroupId\": \"111a21ce-4daf-4eb9-8b9d-47704fc90a09\",\n" + //
            "      \"lawFirmName\": \"Vasco Law\",\n" + //
            "      \"applicantUuid\": null\n" + //
            "    },\n" + //
            "    {\n" + //
            "      \"clientName\": \"McFadden, Winslow\",\n" + //
            "      \"clientType\": \"applicant\",\n" + //
            "      \"clientGroupId\": \"A-f9293e17-829b-4359-be26-1b0afef7f141\",\n" + //
            "      \"collaborationGroupId\": \"7c4c1f47-b7e7-430d-a2bc-dee5fd7d239a\",\n" + //
            "      \"lawFirmName\": \"Vasco Law\",\n" + //
            "      \"applicantUuid\":  \"" + applicantUUID + "\"\n" + //
            "    }\n" + //
            "  ]\n" + //
            "}";

    private String clientListSuccessNotFound = "{\n" + //
            "  \"data\": [\n" + //
            "    {\n" + //
            "      \"clientName\": \"American Mortgage\",\n" + //
            "      \"clientType\": \"organization\",\n" + //
            "      \"clientGroupId\": \"O-36bc119a-b456-47dc-8f5e-5289ec61952a\",\n" + //
            "      \"collaborationGroupId\": \"111a21ce-4daf-4eb9-8b9d-47704fc90a09\",\n" + //
            "      \"lawFirmName\": \"Vasco Law\",\n" + //
            "      \"applicantUuid\": null\n" + //
            "    },\n" + //
            "    {\n" + //
            "      \"clientName\": \"McFadden, Winslow\",\n" + //
            "      \"clientType\": \"applicant\",\n" + //
            "      \"clientGroupId\": \"A-f9293e17-829b-4359-be26-1b0afef7f141\",\n" + //
            "      \"collaborationGroupId\": \"7c4c1f47-b7e7-430d-a2bc-dee5fd7d239a\",\n" + //
            "      \"lawFirmName\": \"Vasco Law\",\n" + //
            "      \"applicantUuid\":  \"31ya21ae-4ddf-4fb2-8395-47724fc60a09\"\n" + //
            "    }\n" + //
            "  ]\n" + //
            "}";

    private static final String clientListFailure = "{\n" + //
            "  \"data\": null,\n" + //
            "  \"error\": {\n" + //
            "    \"failureCode\": null,\n" + //
            "    \"developerMessage\": \"Error getting client list, \",\n" + //
            "    \"userMessage\": null\n" + //
            "  }\n" + //
            "}";

    private String inviteSuccessResponse = "{\n" + //
            "  \"data\": {\n" + //
            "    \"acceptedBy\": \"system\",\n" + //
            "    \"acceptedAt\": \"2025-04-11T00:00:00.000Z\",\n" + //
            "    \"inviteeData\": {\n" + //
            "      \"developerMessage\": \"Invitation accepted, invitee_data has been removed\"\n" + //
            "    },\n" + //
            "    \"inviterData\": {\n" + //
            "      \"developerMessage\": \"Invitation accepted, inviter_data has been removed\"\n" + //
            "    },\n" + //
            "    \"id\": \"d33e8809-1af9-45c6-841e-6332349a97b0\",\n" + //
            "    \"createdBy\": \"test_rep_uuid\",\n" + //
            "    \"expiresAt\": \"2025-04-18T19:00:21.921Z\",\n" + //
            "    \"createdAt\": \"2025-04-11T19:00:21.921Z\",\n" + //
            "    \"updatedAt\": \"2025-04-11T19:00:21.938Z\",\n" + //
            "    \"fromUserGroupId\": \"L-27412880-f4ea-4299-8820-4bdccf272e1c\",\n" + //
            "    \"toUserGroupId\": \"A-3eed78ac-faa5-4933-9465-c7f086a3313c\",\n" + //
            "    \"email\": \"test_applicant_email@email.com\",\n" + //
            "    \"collabGroupId\": \"205c1095-b30d-4fb9-ad41-01042503286b\",\n" + //
            "    \"firstInvitationAcceptance\": false,\n" + //
            "    \"invitationType\": \"collaboration_invite\",\n" + //
            "    \"status\": \"accepted\",\n" + //
            "    \"role\": \"applicant\"\n" + //
            "  }\n" + //
            "}";

    private String userGroupRolesSuccessResponse = "{\n" + //
            "  \"data\": {\n" + //
            "    \"userUuid\": \"01968a09-832a-745d-ac9a-ec4cb53bf70a\",\n" + //
            "    \"userGroupRoles\": [\n" + //
            "      {\n" + //
            "        \"userGroupId\": \"L-01968a09-a028-7f87-a978-320bfb84aded\",\n" + //
            "        \"name\": \"Test user's Legal Team\",\n" + //
            "        \"displayName\": null,\n" + //
            "        \"parentClientId\": null,\n" + //
            "        \"parentId\": null,\n" + //
            "        \"parentName\": null,\n" + //
            "        \"userGroupType\": \"law_firm\",\n" + //
            "        \"roles\": [\n" + //
            "          \"user_group_rep_admin\"\n" + //
            "        ]\n" + //
            "      }\n" + //
            "    ]\n" + //
            "  }\n" + //
            "}";

    static private MockWebServer mockUserGroupService;
    private UserGroupServiceClient client;
    private ReactiveUserGroupServiceClient userGroupServiceClient;

    @Mock
    Mono<ClientDetailsResponse[]> bulkInfoResponseMono;

    @BeforeEach
    void initialize() throws IOException {
        mockUserGroupService = new MockWebServer();
        mockUserGroupService.start();

        HttpClient httpClient = HttpClient.create().responseTimeout(Duration.ofSeconds(1));
        WebClient webClient = WebClient.builder()
                .baseUrl(String.format("http://localhost:%s", mockUserGroupService.getPort()))
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
        userGroupServiceClient = new ReactiveUserGroupServiceClient(webClient);
        client = new UserGroupServiceClient(userGroupServiceClient);

    }

    @AfterAll
    static void tearDown() throws IOException {
        mockUserGroupService.shutdown();
    }

    @Test
    public void shouldReturnSuccessfully() {
        mockUserGroupService.enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                .setResponseCode(200).setBody(inviteSuccessResponse));
        var clientInfo = client.inviteClient("attorneyId", "attorneyUserGroupId", "submissionId", "emailAddress",
                new Name("first", "middle", "last"));
        assertThat(clientInfo.getClientId()).isEqualTo("d33e8809-1af9-45c6-841e-6332349a97b0");
        assertThat(clientInfo.getUserGroupIds()).contains("A-3eed78ac-faa5-4933-9465-c7f086a3313c");
    }

    @Test
    void shouldThrowlWhenClientThrowsWebClientResponseException() {
        mockUserGroupService.enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                .setResponseCode(500).setBody(clientListFailure));

        assertThrows(WebClientResponseException.class,
                () -> client.isClientAssociated(UUID.randomUUID().toString(), UUID.randomUUID().toString()));

    }

    /*
     * @Test
     * void shouldThrowWhenApplicantUuidResponseEmpty() throws
     * JsonProcessingException {
     * String userRole = "applicant";
     * mockUserGroupService.enqueue(new MockResponse().addHeader("Content-Type",
     * "application/json")
     * .setResponseCode(500).setBody(clientListFailure));
     *
     * Exception exception = assertThrows(RuntimeException.class,
     * () -> client.isClientAssociated(icamUUID, userRole, applicantUUID));
     * assertEquals("Received invalid response from client list api",
     * exception.getMessage());
     * }
     */
    @Test
    void shouldReturnTrueWhenApplicantUUidFound() {
        mockUserGroupService.enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                .setResponseCode(200).setBody(clientListSuccessResponse));

        var actual = client.isClientAssociated(icamUUID, applicantUUID);
        assertEquals(actual.isAssociated(), true);
    }

    @Test
    void shouldReturnTrueWhenApplicantUUidNotFound() {
        mockUserGroupService.enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                .setResponseCode(200).setBody(clientListSuccessNotFound));

        var actual = client.isClientAssociated(icamUUID, applicantUUID);
        assertEquals(actual.isAssociated(), false);
    }

    @Test
    void shouldReturnUserGroupRoleForRepAdmin() {
        mockUserGroupService.enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                .setResponseCode(200).setBody(userGroupRolesSuccessResponse));

        var actual = client.getRepGroupId(icamUUID);
        assertEquals(actual.getUserGroupId(), "L-01968a09-a028-7f87-a978-320bfb84aded");
    }

    @Test
    public void shouldHandleATimeoutWhenGoingToUserGroupService() {
        var responseBody = new HashMap<String, String>();
        responseBody.put("manifestId", "fakeId");
        mockUserGroupService
                .enqueue(new MockResponse().setBodyDelay(2, TimeUnit.SECONDS)
                        .addHeader("Content-Type", "application/json")
                        .setResponseCode(200).setBody(userGroupRolesSuccessResponse));

        var actual = client.getRepGroupId(icamUUID);
        assertTrue(actual.getUserGroupId().isEmpty());
    }

    @Test
    void testPartOfOrgRole() {
    	UserGroupRole expected = UserGroupRole.builder()
    			.userGroupType("organization")
				.roles(Arrays.asList("user_group_org_admin"))
				.build();
    	UserGroupResponse response = UserGroupResponse.builder()
    			.data(UserGroupRoleData.builder()
    					.userGroupRoles(Arrays.asList(expected))
    					.build())
    			.build();

    	mockUserGroupService.enqueue(new MockResponse()
    			.addHeader("Content-Type", "application/json")
                .setResponseCode(200)
                .setBody(writeValueAsString(response)));

        assertTrue(client.isUserPartOfOrg(icamUUID));
    }

    @Test
    void notPartOfOrgRole() {
    	UserGroupResponse response = UserGroupResponse.builder()
    			.data(UserGroupRoleData.builder()
    					.userGroupRoles(Collections.emptyList())
    					.build())
    			.build();

    	mockUserGroupService.enqueue(new MockResponse()
    			.addHeader("Content-Type", "application/json")
                .setResponseCode(200)
                .setBody(writeValueAsString(response)));


        assertFalse(client.isUserPartOfOrg(icamUUID));

    }

    @Test
    void returnsOrganizationGroupRole() {
    	UserGroupRole expected = UserGroupRole.builder()
    			.userGroupType("organization")
				.roles(Arrays.asList("user_group_org_admin"))
				.build();
    	UserGroupResponse response = UserGroupResponse.builder()
    			.data(UserGroupRoleData.builder()
    					.userGroupRoles(Arrays.asList(expected))
    					.build())
    			.build();

    	mockUserGroupService.enqueue(new MockResponse()
    			.addHeader("Content-Type", "application/json")
                .setResponseCode(200)
                .setBody(writeValueAsString(response)));

    	UserGroupRole result = client.getOrganizationGroupRole(icamUUID);
    	assertEquals(expected, result);
    }

    @Test
    void organizationGroupRoleNotPresent() {
    	UserGroupRole expected = UserGroupRole.builder()
    			.userGroupType("applicant")
				.roles(Arrays.asList("not_organization"))
				.build();
    	UserGroupResponse response = UserGroupResponse.builder()
    			.data(UserGroupRoleData.builder()
    					.userGroupRoles(Arrays.asList(expected))
    					.build())
    			.build();

    	mockUserGroupService.enqueue(new MockResponse()
    			.addHeader("Content-Type", "application/json")
                .setResponseCode(200)
                .setBody(writeValueAsString(response)));

    	UserGroupRole result = client.getOrganizationGroupRole(icamUUID);
    	assertEquals(UserGroupRole.emptyUserGroupRole(), result);

    }

    @Test
    void noDataInOrganizationResponse() {
    	UserGroupResponse response = UserGroupResponse.builder()
    			.data(null)
    			.build();

    	mockUserGroupService.enqueue(new MockResponse()
    			.addHeader("Content-Type", "application/json")
                .setResponseCode(200)
                .setBody(writeValueAsString(response)));

    	UserGroupRole result = client.getOrganizationGroupRole(icamUUID);
    	assertEquals(UserGroupRole.emptyUserGroupRole(), result);
    }

    @Test
    void noDataInOrganizationResponseOrgExists() {
    	UserGroupResponse response = UserGroupResponse.builder()
    			.data(null)
    			.build();

    	mockUserGroupService.enqueue(new MockResponse()
    			.addHeader("Content-Type", "application/json")
                .setResponseCode(200)
                .setBody(writeValueAsString(response)));

    	boolean actual = client.isUserPartOfOrg(icamUUID);
    	assertFalse(actual);
    }

    @Test
    void exceptionRetrievingOrganizationGroupRole() {
    	mockUserGroupService.enqueue(new MockResponse()
                .setResponseCode(404));

    	UserGroupRole result = client.getOrganizationGroupRole(icamUUID);
    	assertEquals(UserGroupRole.emptyUserGroupRole(), result);
    }
    @Test
    void exceptionRetrievingOrganizationGroupRolePartOfOrg() {
    	mockUserGroupService.enqueue(new MockResponse()
                .setResponseCode(404));

    	boolean result = client.isUserPartOfOrg(icamUUID);
    	assertFalse(result);
    }

    private String writeValueAsString(UserGroupResponse userGroupResponse) {
    	String result = null;
    	try {
    		result = new ObjectMapper().writeValueAsString(userGroupResponse);
    	} catch(IOException e) {
    		fail(e.getMessage());
    	}
    	return result;
    }

}
