package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I485AAdditionalInformation extends AdditionalInformation {
    private @Getter @Setter boolean isI817Beneficiary;

    public I485AAdditionalInformation() {
    	this.formType = FormType.I485.getType();
    	this.formType = FormType.I485A.getType();
    }
}
