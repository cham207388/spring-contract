package gov.dhs.uscis.intake.models;

import lombok.Builder;

@Builder
public record EsignRequest(String submissionId, String formId, String role, String uuid, EsignData esignData) {}
