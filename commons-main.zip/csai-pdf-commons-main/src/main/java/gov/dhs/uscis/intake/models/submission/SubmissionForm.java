package gov.dhs.uscis.intake.models.submission;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import gov.dhs.uscis.intake.converters.EligibilityCategoryConverterProvider;
import gov.dhs.uscis.intake.converters.EligibilitySubcategoryConverterProvider;
import gov.dhs.uscis.intake.converters.EligibilitySubcategoryListConverterProvider;
import gov.dhs.uscis.intake.converters.FormSpecificInfoConverter;
import gov.dhs.uscis.intake.converters.ZonedDateTimeConverterProvider;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.models.WatermarkerStatus.StatusEnum;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.DefaultAttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbConvertedBy;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbIgnore;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean(converterProviders = {ZonedDateTimeConverterProvider.class, EligibilityCategoryConverterProvider.class, EligibilitySubcategoryConverterProvider.class, EligibilitySubcategoryListConverterProvider.class, DefaultAttributeConverterProvider.class})
public class SubmissionForm {
    private String type;
    private EligibilityCategoryEnum eligibilityCategory;
    private EligibilitySubcategoryEnum eligibilitySubcategory;
    private Integer benefitTypeCode;
    private Integer applicationReasonCode;
    private List<EligibilitySubcategoryEnum> eligibilitySubcategoryList;
    private String id;
    private String url;
    private String name;
    private BigDecimal feeTotal;
    private String paymentTrackingId;
    private String md5Hash;
    private String lockboxStatus;
    private List<String> validations;
    private List<RejectionReason> rejectionReasons;
    private ZonedDateTime uploadedAt;
    @JsonIgnore
    private String s3Key;
    @JsonIgnore
    private String markedS3Key;
    @JsonIgnore
    private String attestedS3Key;
    private StatusEnum attestationStatus;
    private ExtractedFormEntries extractedData;
    @Getter(onMethod_ = { @DynamoDbConvertedBy(FormSpecificInfoConverter.class) })
    private FormSpecificInfo formSpecificInfo;
    private String clientId;
    private Name clientName;
}
