package gov.dhs.uscis.intake.enums;

public enum ActionRequested {
    NOTIFY_CONSULATE,
    CHANGE_STATUS,
    EXTEND_STAY,
	AMEND_STAY,
	EXTEND_STATUS_NONIMMIGRANT,
	CHANGE_STATUS_NONIMMIGRANT
}
