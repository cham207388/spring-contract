package gov.dhs.uscis.intake.models;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@SuppressWarnings("serial")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class SubmissionStatusResponse implements Serializable {
    private String correlationId;
    private String uscisId;
    private String processingStatus;
    private String errorMessage;
    private String formName;
    // TODO figure out why there is errorMessage and the need for a list of errors.
    private List<String> errors;
}
