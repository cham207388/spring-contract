package gov.dhs.uscis.intake.enums;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum AccountType {
    //This is lowercased to ensure backwards compatibility for existing drafts/submissions
    APPLICANT("applicant"),
    REPRESENTATIVE("representative"),
    REGISTRANT("registrant");

    private String name;
    private static final Map<String, AccountType> ACCOUNT_TYPES = Stream.of(values())
            .collect(Collectors.toMap(t -> t.getType(), Function.identity()));

    private AccountType(String name) {
        this.name = name;
    }

    @JsonValue
    public String getType() {
        return name;
    }

    @JsonCreator
    public static AccountType fromString(String from) {
        return Optional.ofNullable(ACCOUNT_TYPES.get(from.toLowerCase())).orElseThrow(() -> new IllegalArgumentException(from));
    }

}
