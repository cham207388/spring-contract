package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I129TNEligibilitySubcategory implements EligibilitySubcategoryEnum{
    TN1_FREE_TRADE_CANADA("TN1_FREE_TRADE_CANADA", "TN1"),
    TN2_FREE_TRADE_MEXICO("TN2_FREE_TRADE_MEXICO", "TN2");

	private @Getter String category;
	private @Getter String immigrationClassCode;

	I129TNEligibilitySubcategory(String category, String immigrationClassCode) {
		this.category = category;
        this.immigrationClassCode = immigrationClassCode;
		EligibilitySubcategoryRegistry.register(this);
	}
}
