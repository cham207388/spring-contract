package gov.dhs.uscis.intake.models.validation;

import java.util.List;
import java.util.Map;

import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import lombok.Builder;

@Builder
public record ValidationDetails(ValidatorEnum validator, ValidationResultEnum result,
        List<String> reasons, Map<String,String> warnings) {

}
