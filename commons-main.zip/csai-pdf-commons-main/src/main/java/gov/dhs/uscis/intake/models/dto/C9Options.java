package gov.dhs.uscis.intake.models.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class C9Options {
    // These options were introduced by CSAI-4258. The reason two booleans are needed is because they can both be false. See below for what they represent: 
    
    // You filed your I-485 on or after July 30, 2007 AND before April 1, 2024.
    // AND your form I-485 is still pending.
    // AND you paid the I-485 filing fee.
    // OR you are eligible for an exemption. 
    private boolean onOrAfterApril012024;

    // You filed your I-483 with a fee on or after April 1, 2024.
    // AND your form I-485 is still pending.
    private boolean beforeApril012024;
}
