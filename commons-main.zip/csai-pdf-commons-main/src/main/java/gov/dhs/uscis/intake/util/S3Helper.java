package gov.dhs.uscis.intake.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import gov.dhs.uscis.intake.constants.MetadataConstants;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.core.sync.RequestBody;

@UtilityClass
@Slf4j
public class S3Helper {

    public static String transformS3Key(String originalKey) {

        return originalKey.replaceAll("[+]", " ").replaceAll("%28", "(").replaceAll("%29", ")");
    }

    public static String getStrippedPdf(S3Client s3Client, String objectKey, String bucket, List<Integer> pages, String context, boolean flatten) {
        String pageObjectKey = String.format("%s_%s_pages_%s.pdf",
                objectKey.substring(0, objectKey.lastIndexOf('.')), context,
                String.join("_", pages.stream().map(String::valueOf).toList()));

        try (PDDocument newDoc = new PDDocument()) {

            // pull and save pages into pdDocument
            GetObjectRequest objectRequest = GetObjectRequest
                    .builder()
                    .key(objectKey)
                    .bucket(bucket)
                    .build();
            var docInputStream = s3Client.getObject(objectRequest);
            
            PDDocument inputDoc = Loader.loadPDF(docInputStream.readAllBytes());
            log.info("page count: " + inputDoc.getNumberOfPages());
            
            for (var page : pages) {
                int idx = page - 1;
                if (idx >= inputDoc.getNumberOfPages()) {
                    log.info("inputDocNumberOfPages: " + inputDoc.getNumberOfPages());
                    log.info("index: {}, page: {}", idx, page);
                    log.info("Failed to extract page {} from the {} pdf, falling back to stripping page 1", page, context);
                    return getStrippedPdf(s3Client, objectKey, bucket, List.of(1), context, flatten);
                }

                if (flatten) flattenAndAddPage(newDoc, inputDoc, idx);
                else newDoc.addPage(inputDoc.getPage(idx));
            }

            // save final pdDocument to ByteArrayInputStream
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            newDoc.save(outputStream);
            ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());

            // save pdf back in s3
            Map<String, String> metadata = new HashMap<>(docInputStream.response().metadata());
            metadata.put(MetadataConstants.ORIGINAL_S3_KEY, objectKey);
            metadata.put(MetadataConstants.ORIGINAL_PDF_PAGE_COUNT, String.valueOf(inputDoc.getNumberOfPages()));
            metadata.put(MetadataConstants.STRIPPED_PDF, String.valueOf(true));

            PutObjectRequest request = PutObjectRequest.builder().metadata(metadata)
                    .bucket(bucket).key(pageObjectKey).build();
            s3Client.putObject(request, RequestBody.fromInputStream(inputStream, outputStream.size()));
            inputDoc.close();
            log.info("Saved stripped pdf: {}", pageObjectKey);
        } catch (IOException e) {
            log.error("Failed to extract {} page from form {}", context, e);
        }
        return pageObjectKey;
    }

    private static void flattenAndAddPage(PDDocument newDoc, PDDocument inputDoc, Integer pageIndex) throws IOException {
        PDRectangle mediaBox = inputDoc.getPage(pageIndex).getMediaBox();
        PDPage emptyPage = new PDPage(new PDRectangle(mediaBox.getWidth(), mediaBox.getHeight()));
        newDoc.addPage(emptyPage);

        try (PDPageContentStream contentStream = new PDPageContentStream(newDoc, emptyPage)) {
            contentStream.drawImage(
                    LosslessFactory.createFromImage(newDoc,
                            new PDFRenderer(inputDoc).renderImageWithDPI(pageIndex, 200, ImageType.RGB)),
                    0, 0,
                    mediaBox.getWidth(), mediaBox.getHeight());
        }
    }
}