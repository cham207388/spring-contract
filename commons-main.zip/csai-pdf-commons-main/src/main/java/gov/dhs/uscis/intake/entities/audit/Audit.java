package gov.dhs.uscis.intake.entities.audit;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import software.amazon.awssdk.enhanced.dynamodb.DefaultAttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean(converterProviders = {DefaultAttributeConverterProvider.class})
@EqualsAndHashCode
public class Audit {

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  @DynamoDbBean
  public static class Event {
    Instant timestamp;
    ActionPerformed actionPerformed;
    SubmissionState submissionState;
    String metadata;
  }

  @NonNull @Getter(onMethod_ = { @DynamoDbPartitionKey })
  String myUscisId;
  @NonNull @Getter(onMethod_ = { @DynamoDbSortKey })
  String submissionId;
  @NonNull @Builder.Default
  List<Event> events = new ArrayList();
}