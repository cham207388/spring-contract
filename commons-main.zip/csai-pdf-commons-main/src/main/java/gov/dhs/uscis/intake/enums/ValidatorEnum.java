package gov.dhs.uscis.intake.enums;

public enum ValidatorEnum {
    CORE,
    SIGNATURE,
    ELIGIBILITY_CATEGORY,
    REASON_FOR_FILING,
    PERSON, 
    NOA, 
    I797C,
    I912,
    E9089FD,
    G28_COMP,
    G28_COMP_NAME,
    G28_NAME_EMAIL,
    G28_ATTORNEY_NAME,
    PFVS,
    ESIGN
}
