package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I765AdditionalInformation extends AdditionalInformation {
    private @Getter @Setter boolean before04012024;
    private @Getter @Setter boolean onOrAfterApril012024;
    private @Getter @Setter boolean immvi;

    public I765AdditionalInformation() {
    	this.formType = FormType.I765.getType();
    }
}
