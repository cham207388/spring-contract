package gov.dhs.uscis.intake.models;

import gov.dhs.uscis.intake.entities.ClientInformation;
import lombok.Builder;

@Builder
public record ConcurrentForm(String formType, java.util.Optional<ClientInformation> clientInformation) {

}
