package gov.dhs.uscis.intake.configs;

import org.springframework.context.annotation.Configuration;

import gov.dhs.uscis.intake.enums.I129EEligibilityCategory;
import gov.dhs.uscis.intake.enums.I129H1BEligibilityCategory;
import gov.dhs.uscis.intake.enums.I129H2AEligibilityCategory;
import gov.dhs.uscis.intake.enums.I129TNEligibilityCategory;
import gov.dhs.uscis.intake.enums.I129REligibilityCategory;
import gov.dhs.uscis.intake.enums.I130EligibilityCategory;
import gov.dhs.uscis.intake.enums.I131EligibilityCategory;
import gov.dhs.uscis.intake.enums.I140EligibilityCategory;
import gov.dhs.uscis.intake.enums.I360EligibilityCategory;
import gov.dhs.uscis.intake.enums.I485EligibilityCategory;
import gov.dhs.uscis.intake.enums.I485AEligibilityCategory;
import gov.dhs.uscis.intake.enums.I485JEligibilityCategory;
import gov.dhs.uscis.intake.enums.I539EligibilityCategory;
import gov.dhs.uscis.intake.enums.I751EligibilityCategory;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.N400EligibilityCategory;
import gov.dhs.uscis.intake.enums.I90EligibilityCategory;
import jakarta.annotation.PostConstruct;

@Configuration
public class EligibilityCategoryConfig {

  @PostConstruct
  public void registerEnums() {
      N400EligibilityCategory.values();
      I765EligibilityCategory.values();
      I131EligibilityCategory.values();
      I130EligibilityCategory.values();
      I751EligibilityCategory.values();
      I140EligibilityCategory.values();
      I485EligibilityCategory.values();
      I485AEligibilityCategory.values();
      I485JEligibilityCategory.values();
      I129EEligibilityCategory.values();
      I129H1BEligibilityCategory.values();
      I129H2AEligibilityCategory.values();
      I129TNEligibilityCategory.values();
      I129REligibilityCategory.values();
      I90EligibilityCategory.values();
      I539EligibilityCategory.values();
      I360EligibilityCategory.values();
  }
}
