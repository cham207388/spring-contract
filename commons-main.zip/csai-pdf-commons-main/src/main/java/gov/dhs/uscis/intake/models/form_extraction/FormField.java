package gov.dhs.uscis.intake.models.form_extraction;

import lombok.AllArgsConstructor;
import lombok.Data;
import software.amazon.awssdk.services.textract.model.BlockType;

@Data
@AllArgsConstructor
public abstract class FormField {
    String fieldName;
    BoundingBoxPoints boundingBox;
    BlockType expectedBlockType;
}
