package gov.dhs.uscis.intake.models.user_group;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClientDetailsResponse {

    private List<ClientDetail> data;
    private Error error;
}
