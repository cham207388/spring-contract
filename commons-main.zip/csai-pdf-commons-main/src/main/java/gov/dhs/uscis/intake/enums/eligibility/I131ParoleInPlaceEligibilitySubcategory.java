package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I131ParoleInPlaceEligibilitySubcategory implements EligibilitySubcategoryEnum {
	PIP_MEMBER("PIP_MEMBER"), 
	PIP_DEPENDENT("PIP_DEPENDENT"), 
	FRTF("FRTF"),
	OTHER("OTHER"), 
	NON_SPECIFIC("NON_SPECIFIC");

	private @Getter String category;

	I131ParoleInPlaceEligibilitySubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}

}
