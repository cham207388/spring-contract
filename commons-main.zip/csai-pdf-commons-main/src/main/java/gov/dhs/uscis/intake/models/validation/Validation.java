package gov.dhs.uscis.intake.models.validation;

import java.util.List;

import lombok.Builder;

@Builder
public record Validation(
    String groupType,
    String id,
    ValidationStatusEnum status,
    List<ValidationDetails> details
) {
    
}
