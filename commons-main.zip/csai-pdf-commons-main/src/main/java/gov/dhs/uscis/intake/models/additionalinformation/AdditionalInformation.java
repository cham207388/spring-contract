package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown=true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "formType", visible = true)
@JsonSubTypes({ 
	@JsonSubTypes.Type(value = I129H2AAdditionalInformation.class, name = "I-129H2A"),
    @JsonSubTypes.Type(value = I129H1BAdditionalInformation.class, name = "I-129H1B"),
    @JsonSubTypes.Type(value = I129EAdditionalInformation.class, name = "I-129E"),
    @JsonSubTypes.Type(value = I129TNAdditionalInformation.class, name = "I-129TN"),
    @JsonSubTypes.Type(value = I129RAdditionalInformation.class, name = "I-129R"),
    @JsonSubTypes.Type(value = I751AdditionalInformation.class, name = "I-751"),
	@JsonSubTypes.Type(value = I130AdditionalInformation.class, name = "I-130"),
    @JsonSubTypes.Type(value = I131AdditionalInformation.class, name = "I-131"),
    @JsonSubTypes.Type(value = I912AdditionalInformation.class, name = "I-912"),
    @JsonSubTypes.Type(value = I140AdditionalInformation.class, name = "I-140"),
    @JsonSubTypes.Type(value = I907AdditionalInformation.class, name = "I-907"),
    @JsonSubTypes.Type(value = ETA9089AdditionalInformation.class, name = "ETA-9089"),
    @JsonSubTypes.Type(value = I485AdditionalInformation.class, name = "I-485"),
    @JsonSubTypes.Type(value = I485AAdditionalInformation.class, name = "I-485A"),
    @JsonSubTypes.Type(value = I765AdditionalInformation.class, name = "I-765"),
    @JsonSubTypes.Type(value = I90AdditionalInformation.class, name = "I-90"),
    @JsonSubTypes.Type(value = I539AdditionalInformation.class, name = "I-539"),
    @JsonSubTypes.Type(value = I360AdditionalInformation.class, name = "I-360")
})
public class AdditionalInformation {
    protected @Getter @Setter String formType;
}

