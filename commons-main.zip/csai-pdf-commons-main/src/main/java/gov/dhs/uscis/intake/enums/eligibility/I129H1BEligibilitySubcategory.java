package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I129H1BEligibilitySubcategory implements EligibilitySubcategoryEnum {
    H1B_SPECIALTY_OCCUPATION("H1B_SPECIALTY_OCCUPATION", "H1B"),
    H1B1_CHILE_AND_SINGAPORE("H1B1_CHILE_AND_SINGAPORE", "1B1"),
    H1B2_EXCEPTIONAL_SERVICES("H1B2_EXCEPTIONAL_SERVICES","1B2"),
    H1B3_FASHION_MODEL("H1B3_FASHION_MODEL", "1B3")
	;

	private @Getter String category;
	private @Getter String immigrationClassCode;

	I129H1BEligibilitySubcategory(String category, String immigrationClassCode) {
		this.category = category;
        this.immigrationClassCode = immigrationClassCode;
		EligibilitySubcategoryRegistry.register(this);
	}

}