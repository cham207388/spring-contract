package gov.dhs.uscis.intake.enums;

public enum N400EligibilityCategory implements EligibilityCategoryEnum {
  GENERAL_PROVISION("General Provision"),
  SPOUSE_OF_US_CITIZEN("Spouse of a U.S. citizen"),
  VAWA("Spouse, former spouse, or child of a U.S. citizen under the Violence Against Women Act (VAWA)"),
  SPOUSE_OF_ABROAD_US_CITIZEN("Spouse of U.S. citizen in qualified employment outside the United States"),
  MILITARY_DURING_HOSTILITIES("Military service during a period of hostilities"),
  MILITARY_ONE_YEAR_HONORABLE("At least one year of honorable military service at any time"),
  OTHER("Other");

  private String category;

  N400EligibilityCategory(String category) {
    this.category = category;
    EligibilityCategoryRegistry.register(this);
  }

  @Override
  public String getCategory() {
    return category;
  }

}
