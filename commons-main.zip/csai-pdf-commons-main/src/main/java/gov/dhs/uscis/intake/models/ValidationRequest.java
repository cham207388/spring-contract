package gov.dhs.uscis.intake.models;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.additionalinformation.AdditionalInformation;
import lombok.Builder;

@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public record ValidationRequest(String submissionId, String formId, String parentFormId, String uuid, String userGroupId, String clientUuid, String s3Key, String formType, String submissionFormType, Integer benefitTypeCode, Integer applicationReasonCode, AdditionalInformation additionalInfo, List<String> submissionFormIds, List<String> evidenceIds, List<FormType> concurrentForms) {
	
	private static final String ORGANIZATION_PREFIX = "O-";
	
	@JsonIgnore
	public boolean isFilingByOrganization() {
		if(StringUtils.isBlank(userGroupId)) {
			return false;
		}
		return userGroupId.startsWith(ORGANIZATION_PREFIX);
	}
}
