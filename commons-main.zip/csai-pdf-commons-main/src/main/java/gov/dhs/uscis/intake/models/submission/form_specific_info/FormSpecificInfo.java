package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.EXISTING_PROPERTY, property = "formType", visible = true)
@JsonSubTypes({
 @JsonSubTypes.Type(value = I129H1BFormSpecificInfo.class, name = "I-129H1B"),
 @JsonSubTypes.Type(value = I129EFormSpecificInfo.class, name = "I-129E"),
 @JsonSubTypes.Type(value = I129H2AFormSpecificInfo.class, name = "I-129H2A"),
 @JsonSubTypes.Type(value = I129TNFormSpecificInfo.class, name = "I-129TN"),
 @JsonSubTypes.Type(value = I129RFormSpecificInfo.class, name = "I-129R"),
 @JsonSubTypes.Type(value = I751FormSpecificInfo.class, name = "I-751"),
 @JsonSubTypes.Type(value = I485FormSpecificInfo.class, name = "I-485"),
 @JsonSubTypes.Type(value = I485AFormSpecificInfo.class, name = "I-485A"),
 @JsonSubTypes.Type(value = I765FormSpecificInfo.class, name = "I-765"),
 @JsonSubTypes.Type(value = I140FormSpecificInfo.class, name = "I-140"),
 @JsonSubTypes.Type(value = I130FormSpecificInfo.class, name = "I-130"),
 @JsonSubTypes.Type(value = I907FormSpecificInfo.class, name = "I-907"),
 @JsonSubTypes.Type(value = I90FormSpecificInfo.class, name = "I-90"),
 @JsonSubTypes.Type(value = I539FormSpecificInfo.class, name = "I-539"),
  @JsonSubTypes.Type(value = I360FormSpecificInfo.class, name = "I-360"),

})
@Getter
@Setter
@AllArgsConstructor
public abstract class FormSpecificInfo {
    private FormType formType;

        protected FormSpecificInfo() {}

}
