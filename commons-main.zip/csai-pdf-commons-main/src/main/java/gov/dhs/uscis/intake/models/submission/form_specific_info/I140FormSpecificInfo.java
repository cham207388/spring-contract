package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Getter
@Setter
public class I140FormSpecificInfo extends FormSpecificInfo {
    @JsonProperty("dolNumber")
    private String dolNumber;
    @JsonProperty("isScheduleA")
    private Boolean isScheduleA;

    public I140FormSpecificInfo(String dolNumber, Boolean isScheduleA) {
        super(FormType.I140);
        this.dolNumber = dolNumber;
        this.isScheduleA = isScheduleA;
    }

    public I140FormSpecificInfo() {
        super(FormType.I140);
    }
}