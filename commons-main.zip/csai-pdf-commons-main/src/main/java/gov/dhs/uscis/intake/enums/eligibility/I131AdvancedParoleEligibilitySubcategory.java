package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I131AdvancedParoleEligibilitySubcategory implements EligibilitySubcategoryEnum {
	PENDING_485("PENDING_485"), 
	PENDING_589("PENDING_589"),
	PENDING_INITIAL_821("PENDING_INITIAL_821"),
	DEFERRED_ENFORCED_DEPARTURE("DEFERRED_ENFORCED_DEPARTURE"), 
	APPROVED_821D("APPROVED_821D"),
	APPROVED_914("APPROVED_914"), 
	APPROVED_918("APPROVED_918"),
	CURRENT_PAROLEE("CURRENT_PAROLEE"), 
	APPROVED_817("APPROVED_817"),
	PENDING_687("PENDING_687"), 
	APPROVED_V_NONIMMIGRANT("APPROVED_V_NONIMMIGRANT"),
	CNMI("CNMI"), 
	OTHER("OTHER");

	private @Getter String category;

	I131AdvancedParoleEligibilitySubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}

}
