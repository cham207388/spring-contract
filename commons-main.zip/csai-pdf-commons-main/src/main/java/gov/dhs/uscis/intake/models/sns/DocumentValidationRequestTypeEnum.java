package gov.dhs.uscis.intake.models.sns;

public enum DocumentValidationRequestTypeEnum {
  FORM,EVIDENCE
}
