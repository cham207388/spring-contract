package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.ActionRequested;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.eligibility.I129TNEligibilitySubcategory;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown=true)
public class I129TNAdditionalInformation extends AdditionalInformation  {
	private @Getter @Setter ActionRequested actionRequested;
    private @Getter @Setter I129TNEligibilitySubcategory immigrationClassCode;

    public I129TNAdditionalInformation() {
    	this.formType = FormType.I129TN.getType();
    }
}
