package gov.dhs.uscis.intake.models;

import lombok.Builder;

@Builder
public record DocumentAnalysisResult(String JobId, String Status, String API, Long Timestamp, DocumentAnalysisDocumentLocation DocumentLocation) {
}