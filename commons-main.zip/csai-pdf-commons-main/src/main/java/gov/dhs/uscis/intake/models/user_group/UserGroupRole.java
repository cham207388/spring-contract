package gov.dhs.uscis.intake.models.user_group;

import java.util.Collections;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class UserGroupRole {
    private String userGroupId;
    private String name;
    private String displayName;
    private String parentClientId;
    private String parentId;
    private String parentName;
    private String userGroupType;
    private List<String> roles;
    public static UserGroupRole emptyUserGroupRole() {
        return UserGroupRole.builder().userGroupId("").roles(Collections.emptyList()).build();
    }
}