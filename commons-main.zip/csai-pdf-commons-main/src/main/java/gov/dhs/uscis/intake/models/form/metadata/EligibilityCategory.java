package gov.dhs.uscis.intake.models.form.metadata;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@DynamoDbBean
public class EligibilityCategory {
  String category;
  String label;
  Integer code;
  String benefitTypeCode;
  String applicationReasonCode;
  MetaData metaData;
  List<EligibilitySubcategory> eligibilitySubcategories;
}