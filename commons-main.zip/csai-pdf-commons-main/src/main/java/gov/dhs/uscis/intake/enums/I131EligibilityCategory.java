package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I131AdvancedParoleEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I131InitialParoleEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I131ParoleInPlaceEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I131RefugeeStatusEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I131ReparoleNewPeriodOfParoleEligibilitySubcategory;
import lombok.Getter;

public enum I131EligibilityCategory implements PFVSEligibilityCategoryEnum {
	REENTRY_PERMIT("REENTRY_PERMIT", Arrays.asList()),
	REFUGEE_STATUS("REFUGEE_STATUS", Arrays.asList(I131RefugeeStatusEligibilitySubcategory.values())),
	TPS_BENEFICIARY("TPS_BENEFICIARY", Arrays.asList()),
	ADVANCE_PAROLE("ADVANCE_PAROLE", Arrays.asList(I131AdvancedParoleEligibilitySubcategory.values())),
	INITIAL_PAROLE("INITIAL_PAROLE", Arrays.asList(I131InitialParoleEligibilitySubcategory.values())),
	PAROLE_IN_PLACE("PAROLE_IN_PLACE", Arrays.asList(I131ParoleInPlaceEligibilitySubcategory.values())),
	REPAROLE_NEW_PERIOD_OF_PAROLE("REPAROLE_NEW_PERIOD_OF_PAROLE", Arrays.asList(I131ReparoleNewPeriodOfParoleEligibilitySubcategory.values()));

	private @Getter String category;
	private @Getter List<EligibilitySubcategoryEnum> subcategories;

	I131EligibilityCategory(String category, List<EligibilitySubcategoryEnum> subCategories) {
		this.category = category;
		this.subcategories = subCategories;
		EligibilityCategoryRegistry.register(this);
	}

}
