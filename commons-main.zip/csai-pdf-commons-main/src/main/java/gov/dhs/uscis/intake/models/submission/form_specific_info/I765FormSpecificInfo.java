package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
@Getter
@Setter
@AllArgsConstructor

public class I765FormSpecificInfo extends FormSpecificInfo {

    @JsonProperty("underABCAgreement")
    private boolean underABCAgreement;

    private @Getter @Setter boolean before04012024;
    private @Getter @Setter boolean onOrAfterApril012024;
    private @Getter @Setter boolean feeWaiverRequested;
    private @Getter @Setter boolean immvi;
    private @Getter @Setter ReasonForFiling reasonForFiling;

        public I765FormSpecificInfo(boolean underABCAgreement) {
        super(FormType.I765);
        this.underABCAgreement = underABCAgreement;
    }

            public I765FormSpecificInfo() {
        super(FormType.I765);
    }
}
