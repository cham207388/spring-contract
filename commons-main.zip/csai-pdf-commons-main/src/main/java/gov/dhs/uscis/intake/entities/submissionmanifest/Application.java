package gov.dhs.uscis.intake.entities.submissionmanifest;

import java.io.Serializable;
import java.util.List;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

import gov.dhs.uscis.intake.entities.submissionmanifest.applications.AdditionalInfo;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.ApplicationSupportDocument;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.ApplicationFile;
import lombok.AllArgsConstructor;

@SuppressWarnings("serial")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class Application implements Serializable {
    String formType;
    String submissionId;
    List<ApplicationFile> files;
    List<ApplicationSupportDocument> supportDocuments;
    List<AdditionalInfo> additionalInfo;
}
