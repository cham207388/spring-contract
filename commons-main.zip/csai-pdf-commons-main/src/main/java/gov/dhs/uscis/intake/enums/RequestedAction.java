package gov.dhs.uscis.intake.enums;


public enum RequestedAction {
	NOTIFY_OFFICE,
	CHANGE_STATUS,
	EXTEND_STAY,
	AMEND_STAY
}
