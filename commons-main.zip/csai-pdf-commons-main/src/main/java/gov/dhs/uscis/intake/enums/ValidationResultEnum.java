package gov.dhs.uscis.intake.enums;

public enum ValidationResultEnum {
    PASS, FAIL, WARN, PENDING;
}
