package gov.dhs.uscis.intake.daos;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.entities.audit.Audit;
import lombok.AllArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@Component
@AllArgsConstructor
public class AuditDAO {
    
    private final DynamoDbTable<Audit> table;

    public Audit save(Audit audit) {
        final PutItemEnhancedRequest<Audit> request = PutItemEnhancedRequest
                .builder(Audit.class)
                .item(audit)
                .build();
        table.putItem(request);
        
        return audit;
    }

    public Audit update(Audit audit) {
        final UpdateItemEnhancedRequest<Audit> request = UpdateItemEnhancedRequest
                .builder(Audit.class)
                .item(audit)
                .build();

        return table.updateItem(request);
    }

    public Audit find(String myUscisId, String submissionId) {
        final GetItemEnhancedRequest request = GetItemEnhancedRequest.builder().key(builder -> builder.sortValue(submissionId)
                                        .partitionValue(myUscisId).build())
                                        .build();
        
        return table.getItem(request);                         
    }

}
