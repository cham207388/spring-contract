package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I129REligibilitySubcategory;
import lombok.Getter;

public enum I129REligibilityCategory implements PFVSEligibilityCategoryEnum {
    R_NEW_EMPLOYMENT(
        "R_NEW_EMPLOYMENT", 
        Arrays.asList(I129REligibilitySubcategory.values())
    ),
    R_CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITHOUT_CHANGE_WITH_THE_SAME_EMPLOYER(
        "R_CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITHOUT_CHANGE_WITH_THE_SAME_EMPLOYER", 
        Arrays.asList(I129REligibilitySubcategory.values())
    ),
    R_CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT(
        "R_CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT", 
        Arrays.asList(I129REligibilitySubcategory.values())
    ),
    R_NEW_CONCURRENT_EMPLOYMENT(
        "R_NEW_CONCURRENT_EMPLOYMENT", 
        Arrays.asList(I129REligibilitySubcategory.values())
    ),
    R_CHANGE_OF_EMPLOYER(
        "R_CHANGE_OF_EMPLOYER", 
        Arrays.asList(I129REligibilitySubcategory.values())
    ),
    R_AMENDED_PETITION(
        "R_AMENDED_PETITION", 
        Arrays.asList(I129REligibilitySubcategory.values())
    );

	private @Getter String category;
	private @Getter List<EligibilitySubcategoryEnum> subcategories;

	I129REligibilityCategory(String category, List<EligibilitySubcategoryEnum> subcategories) {
		this.category = category;
        this.subcategories = subcategories;
		EligibilityCategoryRegistry.register(this);
	}
}