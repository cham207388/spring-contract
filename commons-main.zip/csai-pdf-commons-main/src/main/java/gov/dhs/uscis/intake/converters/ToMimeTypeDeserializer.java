package gov.dhs.uscis.intake.converters;

import java.io.IOException;

import org.springframework.util.MimeType;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public final class ToMimeTypeDeserializer extends JsonDeserializer<MimeType>{

    @Override
    public MimeType deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
        return MimeType.valueOf(p.getValueAsString());
    }
    
}
