package gov.dhs.uscis.intake.entities.submissionmanifest.applications;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
@SuppressWarnings("serial")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class AdditionalInfo implements Serializable {
    String name;
    String value;
}
