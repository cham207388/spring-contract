package gov.dhs.uscis.intake.models.validation.address_extract;

import org.springframework.util.StringUtils;

import ch.qos.logback.core.util.StringUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
@ToString
public class ClientAddress {
    private String streetNumberAndName;
    private String unitType;
    private String unitNumber;
    private String cityOrTown;
    private String state;
    private String zipCode;

    public boolean equalsIgnoreCase(Object otherObject) {

        if (super.equals(otherObject)) {
            return true;
        }

        if (!(otherObject instanceof ClientAddress)) {
            return false;
        }

        ClientAddress otherClientAddress = (ClientAddress) otherObject;
        return equalsIgnoreCaseNullSafe(otherClientAddress.getStreetNumberAndName(), this.getStreetNumberAndName())
                && equalsIgnoreCaseNullSafe(otherClientAddress.getUnitType(), this.getUnitType())
                && equalsIgnoreCaseNullSafe(otherClientAddress.getUnitNumber(), this.getUnitNumber())
                && equalsIgnoreCaseNullSafe(otherClientAddress.getCityOrTown(), this.getCityOrTown())
                && equalsIgnoreCaseNullSafe(otherClientAddress.getState(), this.getState())
                && equalsIgnoreCaseNullSafe(otherClientAddress.getZipCode(), this.getZipCode());
    }

    public boolean hasMissingAddressPart() {
        return (!StringUtils.hasText(getStreetNumberAndName()) ||
                !StringUtils.hasText(getCityOrTown()) ||
                !StringUtils.hasText(getState()) ||
                !StringUtils.hasText(getZipCode()));
    }

    private boolean equalsIgnoreCaseNullSafe(String s1, String s2) {
        if (null == s1 && null == s2)
            return true;
        if (null == s1 || null == s2)
            return false;
        return s1.equalsIgnoreCase(s2);
    }

    public boolean addressesMatchAndAreValid(ClientAddress otherAddress) {
        return
            otherAddress != null &&
            !(this.hasMissingAddressPart() || otherAddress.hasMissingAddressPart())
        ;
    }

}
