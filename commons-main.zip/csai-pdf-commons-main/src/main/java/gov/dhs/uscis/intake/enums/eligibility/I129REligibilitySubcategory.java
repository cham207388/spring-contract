package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I129REligibilitySubcategory implements EligibilitySubcategoryEnum{
    R1_RELIGIOUS_WORKER("R1_RELIGIOUS_WORKER", "R1");


	private @Getter String category;
	private @Getter String immigrationClassCode;

	I129REligibilitySubcategory(String category, String immigrationClassCode) {
		this.category = category;
        this.immigrationClassCode = immigrationClassCode;
		EligibilitySubcategoryRegistry.register(this);
	}
}