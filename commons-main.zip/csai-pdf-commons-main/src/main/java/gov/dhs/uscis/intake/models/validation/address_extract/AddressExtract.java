package gov.dhs.uscis.intake.models.validation.address_extract;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPreserveEmptyObject;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
public class AddressExtract {
    @Getter(onMethod_ = { @DynamoDbPartitionKey })
    private String submissionId;
    private String formId;
    private String g28FormId;
    private FormType formType;
    @Getter(onMethod_ = { @DynamoDbPreserveEmptyObject })
    private ClientAddress clientAddressOnForm;
    @Getter(onMethod_ = { @DynamoDbPreserveEmptyObject })
    private ClientAddress clientAddressOnG28;

    public boolean hasAllAddressForValidation() {
        return null != clientAddressOnG28 && null != clientAddressOnForm;
    }

    public AddressExtract updateClientAddress(FormType formType, ClientAddress clientAddress, String formId) {
        if (FormType.G28.equals(formType)) {
            this.clientAddressOnG28 = clientAddress;
            this.setG28FormId(formId);
        } else {
            this.clientAddressOnForm = clientAddress;
            this.setFormId(formId);
            this.setFormType(formType);
        }
        return this;
    }
}
