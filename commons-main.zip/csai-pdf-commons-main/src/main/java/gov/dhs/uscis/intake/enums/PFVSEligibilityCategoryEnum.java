package gov.dhs.uscis.intake.enums;

import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;

public interface PFVSEligibilityCategoryEnum extends EligibilityCategoryEnum {

    public List<EligibilitySubcategoryEnum> getSubcategories();
}
