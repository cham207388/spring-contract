package gov.dhs.uscis.intake.enums;

public enum AuthorizationStatusCode {
    Pending,
    Canceled, 
    Success, 
    Declined, 
    Error
}
