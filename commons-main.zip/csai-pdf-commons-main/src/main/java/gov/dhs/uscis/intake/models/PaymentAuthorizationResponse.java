package gov.dhs.uscis.intake.models;

import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import lombok.Builder;

@Builder
public record PaymentAuthorizationResponse(AuthorizationStatusCode result, String message){}
