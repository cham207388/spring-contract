package gov.dhs.uscis.intake.models.myuscis;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class ToggleResponse {
    private ToggleData data;

    @Data
    public static class ToggleData {
        private String toggle;
        private boolean enabled;
    }
}
