package gov.dhs.uscis.intake.converters;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import java.io.IOException;

@Slf4j
public class FormSpecificInfoConverter implements AttributeConverter<FormSpecificInfo> {
    private static ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    @Override
    public AttributeValue transformFrom(FormSpecificInfo formSpecificInfo) {
        if (formSpecificInfo == null) {
            return AttributeValue.builder().nul(true).build();
        }
        try {
            String json = objectMapper.writeValueAsString(formSpecificInfo);
            return AttributeValue.builder().s(json).build();
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting FormSpecificInfo to JSON string", e);
        }
    }

    @Override
    public FormSpecificInfo transformTo(AttributeValue attributeValue) {
        if (attributeValue == null || attributeValue.s() == null || attributeValue.s().isEmpty()) {
            return null;
        }

        String json = attributeValue.s();
        try {
            return objectMapper.readValue(json, FormSpecificInfo.class);
        } catch (IOException e) {
            log.error("Failed to deserialize FormSpecificInfo. Raw JSON from DB: " + json);
            throw new RuntimeException("Error converting JSON string to FormSpecificInfo", e);
        }
    }

    @Override
    public EnhancedType<FormSpecificInfo> type() {
        return EnhancedType.of(FormSpecificInfo.class);
    }

    @Override
    public AttributeValueType attributeValueType() {
        return AttributeValueType.S;
    }
}
