package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I751WaiverOrIndividualFilingSubcategory implements EligibilitySubcategoryEnum {

  EXTREME_HARDSHIP("ExtremeHardship"),
  PARENT_GOOD_FAITH_EXTREME_CRUELTY("ParentGoodFaithExtremeCruelty"),
  GOOD_FAITH_SPOUSE_EXTREME_CRUELTY("GoodFaithSpouseExtremeCruelty"),
  SPOUSE_DECEASED("SpouseDeceased"),
  DIVORCE_ANNULMENT("DivorceAnnulment");

    	private @Getter String category;


	I751WaiverOrIndividualFilingSubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}
}
