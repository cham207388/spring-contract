package gov.dhs.uscis.intake.converters;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class ZonedDateTimeDeserializer extends JsonDeserializer<ZonedDateTime> {

  private static final DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.sZ");

  @Override
  public ZonedDateTime deserialize(JsonParser p, DeserializationContext context) throws IOException {
    return ZonedDateTime.parse(p.getValueAsString(), format);
  }
  
}
