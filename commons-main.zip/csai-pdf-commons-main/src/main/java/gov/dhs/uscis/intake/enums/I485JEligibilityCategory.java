package gov.dhs.uscis.intake.enums;

public enum I485JEligibilityCategory implements EligibilityCategoryEnum{
  CONFIRMATION_OF_VALID_JOB_OFFER("ConfirmationOfValidJobOffer"),
  REQUEST_FOR_JOB_PORTABILITY("RequestForJobPortability");

  private String category;

  I485JEligibilityCategory(String category) {
    this.category = category;
    EligibilityCategoryRegistry.register(this);
  }

  @Override
  public String getCategory() {
    return category;
  }

}
