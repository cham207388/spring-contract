package gov.dhs.uscis.intake.services;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.Loader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.dhs.uscis.intake.services.formats.MagicBytes;

public class FileFormatValidator {

    private List<MagicBytes> supportedFileTypes;
    private Logger logger = LoggerFactory.getLogger(FileFormatValidator.class);

    public FileFormatValidator() {
        this.supportedFileTypes = Arrays.asList(
                MagicBytes.PDF,
                MagicBytes.JPG,
                MagicBytes.TIFFA,
                MagicBytes.TIFFB,
                MagicBytes.PNG);
    }

    public MagicBytes isSupportedFile(byte... bytes) {
        Optional<MagicBytes> format = supportedFileTypes.stream()
                .filter(a -> a.is(bytes) != MagicBytes.UNSUPPORTED)
                .findFirst();

        return format.isPresent() ? checkIfFileIsEncrypted(format.get(), bytes) : MagicBytes.UNSUPPORTED;
    }

    public MagicBytes checkIfFileIsEncrypted(MagicBytes magicBytes, byte... bytes) {
        if (magicBytes == MagicBytes.PDF) {
            return canOpenPdfFile(magicBytes, bytes);
        }
        return magicBytes;
    }

    public MagicBytes canOpenPdfFile(MagicBytes magicBytes, byte... bytes) {
        try {
            PDDocument pdDocument = Loader.loadPDF(bytes);
            if (pdDocument != null)
                pdDocument.close();
        } catch (IOException e) {
            logger.debug("Can not open file the pdf is encrypted or missing");
            return MagicBytes.UNSUPPORTED;
        }
        return magicBytes;
    }

}