package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I485AdditionalInformation extends AdditionalInformation {
    private @Getter @Setter boolean isFilingUnderINA101A27K;
    private @Getter @Setter boolean isMilitaryVeteran;
    private @Getter @Setter boolean isFamilyBased;
    private @Getter @Setter boolean isUnder14;


    public I485AdditionalInformation() {
    	this.formType = FormType.I485.getType();
    }
}
