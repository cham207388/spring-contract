package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class I539FormSpecificInfo extends FormSpecificInfo {

	@JsonProperty("isOnlyApplicantApplying")
	private boolean isOnlyApplicantApplying;

    public I539FormSpecificInfo(boolean isOnlyApplicantApplying) {
        super(FormType.I539);
        this.isOnlyApplicantApplying = isOnlyApplicantApplying;
    }

    public I539FormSpecificInfo() {
         super(FormType.I539);
    }

}