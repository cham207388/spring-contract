package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ResidencyStatus;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class I130FormSpecificInfo extends FormSpecificInfo {

	@JsonProperty("isUSCitizen")
	private ResidencyStatus isUSCitizen;

    public I130FormSpecificInfo(ResidencyStatus isUSCitizen) {
        super(FormType.I130);
        this.isUSCitizen = isUSCitizen;
    }
    public I130FormSpecificInfo() {
         super(FormType.I130);
    }
}