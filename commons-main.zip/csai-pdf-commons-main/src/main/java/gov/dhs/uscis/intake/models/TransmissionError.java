package gov.dhs.uscis.intake.models;

import java.io.Serializable;

import lombok.Builder;

@Builder
public record TransmissionError(String uscisId, String errorCode, String description) implements Serializable {
}
