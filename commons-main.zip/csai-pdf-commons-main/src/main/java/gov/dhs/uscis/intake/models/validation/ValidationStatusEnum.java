package gov.dhs.uscis.intake.models.validation;

public enum ValidationStatusEnum {
    IN_PROGRESS("IN_PROGRESS"), COMPLETE("COMPLETE"), AWAITING("AWAITING");

    String cd;

    private ValidationStatusEnum(String cd) {
        this.cd = cd;
    }

    public String getCd() {
        return cd;
    }
}
