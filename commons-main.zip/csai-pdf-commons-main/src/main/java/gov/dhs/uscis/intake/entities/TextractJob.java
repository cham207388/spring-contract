package gov.dhs.uscis.intake.entities;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.services.textract.model.JobStatus;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
public class TextractJob {
    private String jobId;
    private String documentId;
    private String eligibiltyCategory;
    private String submissionId;
    private JobTypeEnum jobTypeEnum;
    private JobStatus jobStatus;
    private FormType formType;
    private String formVersion;


    @DynamoDbPartitionKey
    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }
    public String getDocumentId() {
        return documentId;
    }
    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }
    public JobStatus getJobStatus() {
        return jobStatus;
    }
    public void setJobStatus(JobStatus jobStatus) {
        this.jobStatus = jobStatus;
    }

    public FormType getFormType() {
        return formType;
    }

    public void setEligibilityCategory(String eligibiltyCategory) {
        this.eligibiltyCategory = eligibiltyCategory;
    }

    public void setSubmissionId(String submissionId) {
        this.submissionId = submissionId;
    }

    public void setFormType(FormType formType) {
    this.formType = formType;
    }

    public void setFormVersion(String formVersion) {
        this.formVersion = formVersion;
    }
    public String getFormVersion() {
        return this.formVersion;
    }
}