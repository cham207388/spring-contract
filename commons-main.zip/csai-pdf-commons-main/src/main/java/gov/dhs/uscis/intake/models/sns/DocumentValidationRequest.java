package gov.dhs.uscis.intake.models.sns;

public record DocumentValidationRequest(DocumentValidationRequestTypeEnum type, DocumentValidationRequestDetails details) {

}
