package gov.dhs.uscis.intake.clients;

import java.util.List;
import java.util.Optional;

import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import gov.dhs.uscis.intake.exceptions.AccountsDataClientException;
import gov.dhs.uscis.intake.models.myuscis.ToggleResponse;
import gov.dhs.uscis.intake.models.myuscis.Admin;
import gov.dhs.uscis.intake.models.myuscis.AdminResponse;
import gov.dhs.uscis.intake.models.myuscis.NotificationRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountsDataClient {
	
	private WebClient client;
	
	private static final String ADMINS_URI = "/api/pdfi/%s/admins";
	private static final String TOGGLES_URI = "/api/pdfi/toggles/%s";
	private static final String NOTIFY_URI = "/api/pdfi/send-notification";
	
	public AccountsDataClient(WebClient client) {
		this.client = client;
	}

	public List<Admin> getAdministrators(String icamUUID, String userGroupId) {
		log.info("Attempting to retrieve administrators for user group id: {}", userGroupId);
		
		AdminResponse response = null;
		try {
			response = client.get()
					.uri(String.format(ADMINS_URI, userGroupId))
					.header("ICAM-UUID", icamUUID)
					.retrieve()
					.bodyToMono(AdminResponse.class)
					.block();
		} catch(WebClientResponseException e) {
			String message = String.format("An error occured retrieving admins for user group id %s", userGroupId);
			throw new AccountsDataClientException(message, e);
		}
		return response.getData();
	}

    public boolean getToggle(String toggleName) {
        log.info("Attempting to retrieve toggle value for: {}", toggleName);
        
        try {
            ToggleResponse response = client.get()
                    .uri(String.format(TOGGLES_URI, toggleName))
                    .retrieve()
                    .bodyToMono(ToggleResponse.class)
                    .block();

            return Optional.ofNullable(response)
                    .map(ToggleResponse::getData)
                    .map(ToggleResponse.ToggleData::isEnabled)
                    .orElse(false);

        } catch (WebClientResponseException e) {
            String message = String.format("An error occurred retrieving toggle value for %s", toggleName);
            throw new AccountsDataClientException(message, e);
        }
    }

	
	public void notifyAdministrators(String myUscisId, String submissionId, List<String> admins) {
		log.info("Attempting to send notify admin request. [ myUscisId = {}, submission = {}, uuids = {} ]",
				myUscisId, submissionId, admins);
		NotificationRequest request = new NotificationRequest();
		request.setNotificationType("case_review_org_account_notification");
		request.setResourceId(submissionId);
		request.setResourceType("draft");
		request.setUuids(admins);
		
		try {
			client.post()
				.uri(NOTIFY_URI)
				.header("ICAM-UUID", myUscisId)
				.contentType(MediaType.APPLICATION_JSON)
				.bodyValue(request)
				.retrieve()
				.toBodilessEntity()
				.block();
		} catch(WebClientResponseException e) {
			String message = String.format("An error occured sending notify admin request for submission %s", submissionId);
			throw new AccountsDataClientException(message, e);
		}
	}
	
}
