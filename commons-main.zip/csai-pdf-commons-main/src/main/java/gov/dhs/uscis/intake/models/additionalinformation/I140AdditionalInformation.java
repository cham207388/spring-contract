package gov.dhs.uscis.intake.models.additionalinformation;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I140AdditionalInformation extends AdditionalInformation {
    private @Getter @Setter String dolNumber;
    private @Getter @Setter boolean isScheduleA;

    public I140AdditionalInformation() {
    	this.formType = FormType.I140.getType();
    }
}