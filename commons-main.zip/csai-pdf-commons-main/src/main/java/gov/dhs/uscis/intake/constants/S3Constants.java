package gov.dhs.uscis.intake.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class S3Constants {
  public static final String DELETION_FAILURE_MESSAGE = "Deletion failed";
  public static final String DELETION_SUCCESS_MESSAGE = "Deletion successful";
  public static final String UPLOAD_FAILURE_MESSAGE = "Upload failed";

}