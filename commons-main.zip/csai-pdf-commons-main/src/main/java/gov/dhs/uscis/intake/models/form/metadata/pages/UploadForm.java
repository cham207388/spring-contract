package gov.dhs.uscis.intake.models.form.metadata.pages;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
public class UploadForm {
    private String additionalInfoPartNumber;
    private String optionalLinkText;
    private String pageMarkdown;
}
