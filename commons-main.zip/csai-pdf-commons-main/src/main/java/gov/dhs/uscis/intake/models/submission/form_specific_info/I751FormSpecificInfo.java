package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Getter
@Setter
public class I751FormSpecificInfo extends FormSpecificInfo {
    @JsonProperty("isUnderOrders")
    private boolean isUnderOrders;

    public I751FormSpecificInfo(boolean isUnderOrders) {
        super(FormType.I751);
        this.isUnderOrders = isUnderOrders;
    }

    public I751FormSpecificInfo() {
        super(FormType.I751);
    }
}
