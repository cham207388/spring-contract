package gov.dhs.uscis.intake.entities.submissionmanifest;

import java.io.Serializable;

import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.ManifestStatus;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@SuppressWarnings("serial")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class Statuses implements Serializable {
    ManifestStatus manifestStatus;
    SubmissionStatus submissionStatus;
}
