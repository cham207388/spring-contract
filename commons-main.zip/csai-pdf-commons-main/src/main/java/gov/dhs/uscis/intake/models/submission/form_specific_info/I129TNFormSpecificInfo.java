package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.ActionRequested;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.submission.form_specific_info.interfaces.ActionRequestedProvider;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class I129TNFormSpecificInfo extends FormSpecificInfo implements ActionRequestedProvider {

    @JsonProperty("actionRequested")
	private ActionRequested actionRequested;

    public I129TNFormSpecificInfo(ActionRequested actionRequested) {
        super(FormType.I129TN);
        this.actionRequested = actionRequested;
    }
        public I129TNFormSpecificInfo() {
         super(FormType.I129TN);
    }
}

