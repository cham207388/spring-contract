package gov.dhs.uscis.intake.exceptions;

public class MyUscisProcessingException extends RuntimeException {
    public MyUscisProcessingException(String message) {
        super(message);
    }

}
