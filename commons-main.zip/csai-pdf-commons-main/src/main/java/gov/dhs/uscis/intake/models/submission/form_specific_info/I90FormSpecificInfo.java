package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.ActionRequested;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.submission.form_specific_info.interfaces.ActionRequestedProvider;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class I90FormSpecificInfo extends FormSpecificInfo implements ActionRequestedProvider {

	@JsonProperty("actionRequested")
	private ActionRequested actionRequested;

    public I90FormSpecificInfo(ActionRequested actionRequested) {
        super(FormType.I90);
        this.actionRequested = actionRequested;
    }

    public I90FormSpecificInfo() {
         super(FormType.I90);
    }

}