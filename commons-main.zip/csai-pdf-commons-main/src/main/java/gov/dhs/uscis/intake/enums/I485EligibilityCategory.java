package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I485EligibilitySubcategories;
import gov.dhs.uscis.intake.enums.eligibility.I485FBEligibilitySubcategories;
import lombok.Getter;
import lombok.Setter;

public enum I485EligibilityCategory implements PFVSEligibilityCategoryEnum {
    PRINCIPAL_APPLICANT("PrincipalApplicant", Stream.of(
            I485EligibilitySubcategories.values(),
            I485FBEligibilitySubcategories.values())
            .flatMap(Arrays::stream)
            .collect(Collectors.toList())),
    DERIVATIVE_APPLICANT("DerivativeApplicant", Stream.of(
            I485EligibilitySubcategories.values(),
            I485FBEligibilitySubcategories.values())
            .flatMap(Arrays::stream)
            .collect(Collectors.toList()));

  private String category;
  private @Getter  @Setter List<EligibilitySubcategoryEnum> subcategories;

  I485EligibilityCategory(String category, List<EligibilitySubcategoryEnum> subCategories) {
    this.category = category;
    this.subcategories = subCategories;

    EligibilityCategoryRegistry.register(this);
  }

  @Override
  public String getCategory() {
    return category;
  }
    
}
