package gov.dhs.uscis.intake.enums;

public enum ResidencyStatus {
	USC,
	LPR
}
