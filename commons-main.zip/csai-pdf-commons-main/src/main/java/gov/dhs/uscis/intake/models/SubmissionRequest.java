package gov.dhs.uscis.intake.models;

import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import lombok.Builder;

@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public record SubmissionRequest(FormType formType, String formDescription, String eligibilityCategory, AccountType accountType,
        Optional<ClientInformation> clientInformation, List<ConcurrentForm> concurrentForms, Integer applicationReasonCode) {
	
	public SubmissionRequest(FormType formType, String formDescription, String eligibilityCategory, AccountType accountType, Optional<ClientInformation> clientInformation, Integer applicationReasonCode) {
		this(formType, formDescription, eligibilityCategory, accountType, clientInformation, List.of(), applicationReasonCode);
	}
}