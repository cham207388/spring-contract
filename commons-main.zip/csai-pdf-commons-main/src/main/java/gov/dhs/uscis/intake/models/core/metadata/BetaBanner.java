package gov.dhs.uscis.intake.models.core.metadata;

import gov.dhs.uscis.intake.converters.AccountTypeConverter;
import gov.dhs.uscis.intake.enums.AccountType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbConvertedBy;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@DynamoDbBean
public class BetaBanner {
    String bannerText;
    String formType;
    boolean showBanner;
    @Getter(onMethod_ = { @DynamoDbConvertedBy(AccountTypeConverter.class) })
    AccountType showBannerFor;
}
