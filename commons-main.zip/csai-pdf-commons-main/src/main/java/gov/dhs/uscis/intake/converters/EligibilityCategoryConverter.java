package gov.dhs.uscis.intake.converters;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

public final class EligibilityCategoryConverter implements AttributeConverter<EligibilityCategoryEnum> {

  @Override
  public AttributeValue transformFrom(EligibilityCategoryEnum input) {
    return AttributeValue.fromS(input.getCategory());
  }

  @Override
  public EligibilityCategoryEnum transformTo(AttributeValue input) {
    return EligibilityCategoryEnum.fromString(input.s());
  }

  @Override
  public EnhancedType<EligibilityCategoryEnum> type() {
    return EnhancedType.of(EligibilityCategoryEnum.class);
  }

  @Override
  public AttributeValueType attributeValueType() {
    return AttributeValueType.S;
  }

}
