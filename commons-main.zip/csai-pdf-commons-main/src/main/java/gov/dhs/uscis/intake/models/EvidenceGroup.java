package gov.dhs.uscis.intake.models;

import java.util.List;

import org.springframework.util.MimeType;

import com.fasterxml.jackson.annotation.JsonIgnore;

import gov.dhs.uscis.intake.converters.MimeTypeConverterProvider;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.DefaultAttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Builder
@Data
@DynamoDbBean(converterProviders = {MimeTypeConverterProvider.class, DefaultAttributeConverterProvider.class})
@AllArgsConstructor
@NoArgsConstructor
public class EvidenceGroup {
    String id;
    String name;
    List<EvidenceType> evidenceTypes;
    List<MetadataValidationEnum> validations;
    Integer maxNumberOfFiles;
    List<MimeType> allowMediaTypes;

    @JsonIgnore
    public boolean isPFVSSupported() {
        if (validations != null) {
         return validations.stream().filter(validation->("PFVS").equals(validation.toString())).count() > 0;
        }
        else return false;
    }
}