package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I131RefugeeStatusEligibilitySubcategory implements EligibilitySubcategoryEnum {
	REFUGEE_STATUS_HOLD("REFUGEE_STATUS_HOLD"),
	REFUGEE_STATUS_PERM_RESIDENT("REFUGEE_STATUS_PERM_RESIDENT");

	private @Getter String category;

	I131RefugeeStatusEligibilitySubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}

}
