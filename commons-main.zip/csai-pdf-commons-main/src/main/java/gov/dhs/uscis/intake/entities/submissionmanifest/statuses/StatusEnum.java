package gov.dhs.uscis.intake.entities.submissionmanifest.statuses;

public enum StatusEnum {
    COMPLETE,
    ACCEPTED,
    REJECTED,
    RECEIVED,
    ERROR,
    PUBLISHED,
    PENDING,
    MIXED;
}
