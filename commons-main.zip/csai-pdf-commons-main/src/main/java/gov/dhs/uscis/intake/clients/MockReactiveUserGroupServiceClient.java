package gov.dhs.uscis.intake.clients;

import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.models.core.ClientAssociation;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;
import reactor.core.publisher.Mono;

public class MockReactiveUserGroupServiceClient extends ReactiveUserGroupServiceClient {

    private Logger logger = LoggerFactory.getLogger(MockReactiveUserGroupServiceClient.class);

    public MockReactiveUserGroupServiceClient() {
        super(null);
        logger.info("Usergroup Service is not enabled - Initializing a mock");
    }

    @Override
    public Mono<UserGroupRole> getRepGroupId(String icamUUID) {
        logger.info("Usergroup Service is not enabled");
        return Mono.just(UserGroupRole.builder().userGroupId("fakeGroupId").build());
    }

    @Override
    public Mono<ClientInformation> inviteClient(String attorneyId, String attorneyUserGroupId, String submissionId,
            String emailAddress, Name name) {
        logger.info("Usergroup Service is not enabled");
        return Mono.just(new ClientInformation(UUID.randomUUID().toString(), attorneyId, submissionId, name, List.of()));
    }

    @Override
    public Mono<ClientAssociation> isClientAssociated(String icamUUID, String applicantUuid) {
        logger.info("Usergroup Service is not enabled");
        return Mono.just(new ClientAssociation(true, "fakeGroupId"));
    }

}
