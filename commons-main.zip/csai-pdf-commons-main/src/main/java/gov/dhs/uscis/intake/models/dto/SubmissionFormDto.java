package gov.dhs.uscis.intake.models.dto;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;
import lombok.Builder;

@Builder
public record SubmissionFormDto(
  String type,
  EligibilityCategoryEnum eligibilityCategory,
  EligibilitySubcategoryEnum eligibilitySubcategory,
  Integer benefitTypeCode,
  Integer applicationReasonCode,
  String id,
  String name,
  BigDecimal feeTotal,
  String md5Hash,
  String paymentTrackingId,
  String lockboxStatus,
  List<String> validations,
  List<RejectionReason> rejectionReasons,
  ZonedDateTime uploadedAt,
  FormSpecificInfo formSpecificInfo,
  String clientId,
  Name clientName) {}
