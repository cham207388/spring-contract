package gov.dhs.uscis.intake.converters;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

public final class ZonedDateTimeConverter implements AttributeConverter<ZonedDateTime> {

    @Override
    public AttributeValue transformFrom(ZonedDateTime value) {
        return AttributeValue.fromS(value.format(DateTimeFormatter.ISO_DATE_TIME));
    }

    @Override
    public ZonedDateTime transformTo(AttributeValue attributeValue) {
        return ZonedDateTime.parse(attributeValue.s(), DateTimeFormatter.ISO_DATE_TIME);
    }

    @Override
    public EnhancedType<ZonedDateTime> type() {
        return EnhancedType.of(ZonedDateTime.class);
    }

    @Override
    public AttributeValueType attributeValueType() {
        return AttributeValueType.S;
    }
}
