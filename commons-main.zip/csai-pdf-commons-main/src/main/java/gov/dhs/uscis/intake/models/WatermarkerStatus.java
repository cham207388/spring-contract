package gov.dhs.uscis.intake.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
public class WatermarkerStatus {

    private String submissionId;
    private StatusEnum status;

    public enum StatusEnum {
        SUCCESS,
        FAILURE,
        IN_PROGRESS,
    }
}
