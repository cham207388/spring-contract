package gov.dhs.uscis.intake.models.submissionstatus;

import java.io.Serializable;
import java.util.List;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@SuppressWarnings("serial")
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Builder
@DynamoDbBean
public class ApplicationStatus implements Serializable {
    private String uscisId;
    private String formType;
    private StatusEnum status;
    @Nullable
    private String uscisReceiptNumber;
    private List<RejectionReason> rejectionReasons;

    @JsonProperty("id")
    public String getUscisId() {
        return uscisId;
    }
    public String getFormType() {
        return formType;
    }
    public StatusEnum getStatus() {
        return status;
    }
    public void setUscisId(String uscisId) {
        this.uscisId = uscisId;
    }
    public void setFormType(String formType) {
        this.formType = formType;
    }
    public void setStatus(StatusEnum status) {
        this.status = status;
    }
    public void setRejectionReasons(List<RejectionReason> rejectionReasons) {
        this.rejectionReasons = rejectionReasons;
    }
    public List<RejectionReason> getRejectionReasons() {
        return rejectionReasons;
    }
    public String getUscisReceiptNumber() {
        return uscisReceiptNumber;
    }
    public void setUscisReceiptNumber(String uscisReceiptNumber) {
        this.uscisReceiptNumber = uscisReceiptNumber;
    }
}
