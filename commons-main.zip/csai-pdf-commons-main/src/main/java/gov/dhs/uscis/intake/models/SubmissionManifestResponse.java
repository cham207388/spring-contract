package gov.dhs.uscis.intake.models;

import java.io.Serializable;
import java.util.List;

import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import lombok.Builder;

@Builder
public record SubmissionManifestResponse(String uscisId, StatusEnum status, List<TransmissionError> errors) implements Serializable {}
