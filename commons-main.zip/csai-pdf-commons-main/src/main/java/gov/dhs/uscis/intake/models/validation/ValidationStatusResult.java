package gov.dhs.uscis.intake.models.validation;

import java.util.List;
import java.util.Map;

import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import lombok.Builder;

@Builder
public record ValidationStatusResult(String formId, String submissionId, String myUscisId,
                ValidationResultEnum status, ValidatorEnum validator, List<Map<String, String>> failureReasons,
                Map<String, String> validationWarnings, boolean isMultipart) { }
