package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I129H1BEligibilitySubcategory;
import lombok.Getter;

public enum I129H1BEligibilityCategory implements PFVSEligibilityCategoryEnum {

    H1B_NEW_EMPLOYMENT("H1B_NEW_EMPLOYMENT", Arrays.asList(I129H1BEligibilitySubcategory.values())),
	H1B_CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITH_SAME_EMPLOYER("H1B_CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITH_SAME_EMPLOYER", Arrays.asList(I129H1BEligibilitySubcategory.values())),
	H1B_CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT("H1B_CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT", Arrays.asList(I129H1BEligibilitySubcategory.values())),
	H1B_NEW_CONCURRENT_EMPLOYMENT("H1B_NEW_CONCURRENT_EMPLOYMENT", Arrays.asList(I129H1BEligibilitySubcategory.values())),
	H1B_CHANGE_OF_EMPLOYER("H1B_CHANGE_OF_EMPLOYER", Arrays.asList(I129H1BEligibilitySubcategory.values())),
	H1B_AMENDED_PETITION("H1B_AMENDED_PETITION", Arrays.asList(I129H1BEligibilitySubcategory.values()));
    ;

	private @Getter String category;
	private @Getter List<EligibilitySubcategoryEnum> subcategories;

	I129H1BEligibilityCategory(String category, List<EligibilitySubcategoryEnum> subcategories) {
		this.category = category;
        this.subcategories = subcategories;
		EligibilityCategoryRegistry.register(this);
	}

}