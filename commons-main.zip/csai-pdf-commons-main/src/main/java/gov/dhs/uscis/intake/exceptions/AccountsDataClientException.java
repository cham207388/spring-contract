package gov.dhs.uscis.intake.exceptions;

public class AccountsDataClientException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	AccountsDataClientException(String message) {
		super(message);
	}
	
	public AccountsDataClientException(String message, Throwable t) {
		super(message, t);
	}
	
}
