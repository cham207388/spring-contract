package gov.dhs.uscis.intake.services;

import java.time.ZonedDateTime;

public interface SystemClockService {
    ZonedDateTime getSystemTime();
}