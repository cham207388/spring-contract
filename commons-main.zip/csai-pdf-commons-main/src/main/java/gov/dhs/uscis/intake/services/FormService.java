package gov.dhs.uscis.intake.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.models.FormMetaData;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

@Service
public class FormService {

    private static Logger logger = LoggerFactory.getLogger(FormService.class);
    DynamoDbTable<FormMetaData> formMetaDataTable;

    public FormService(DynamoDbTable<FormMetaData> formMetaDataTable) {
        this.formMetaDataTable = formMetaDataTable;
    }

    public FormMetaData retrieveFormMetaData(String formType) {
        logger.info(String.format("Form type: %s", formType));
        
        Key key = Key.builder().partitionValue(AttributeValue.fromS(formType)).build();
        GetItemEnhancedRequest request = GetItemEnhancedRequest.builder().key(key).build();
        return formMetaDataTable.getItem(request);
    }
}
