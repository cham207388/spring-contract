package gov.dhs.uscis.intake.models;

import java.time.ZonedDateTime;

public record UploadResponse(String formId, String artifactId, ZonedDateTime uploadedAt) {}
