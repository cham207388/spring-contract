package gov.dhs.uscis.intake.entities.submissionmanifest.applications;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
@SuppressWarnings("serial")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class ApplicationFile implements Serializable {
    int order;
    String id;
    String name;
    String uri;
    String md5Hash;
}
