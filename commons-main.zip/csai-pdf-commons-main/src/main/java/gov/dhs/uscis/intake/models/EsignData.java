package gov.dhs.uscis.intake.models;

import java.util.Date;

import lombok.Builder;

@Builder
public record EsignData(String timeZone, Date esignDate, String ipAddress, String emailAddress, String applicantFullName, String sessionIdentifier, String browserInformation) {}