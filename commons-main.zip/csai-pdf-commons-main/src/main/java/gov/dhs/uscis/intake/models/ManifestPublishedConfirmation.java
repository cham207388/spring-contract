package gov.dhs.uscis.intake.models;

public record ManifestPublishedConfirmation(String manifestId, String submissionId, boolean alreadySubmitted ) { }
