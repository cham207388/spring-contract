package gov.dhs.uscis.intake.models;

import lombok.Builder;
import gov.dhs.uscis.intake.models.dto.SubmissionDto;

@Builder
public record UpdateSubmissionResponse (
    SubmissionDto submission
) {}
