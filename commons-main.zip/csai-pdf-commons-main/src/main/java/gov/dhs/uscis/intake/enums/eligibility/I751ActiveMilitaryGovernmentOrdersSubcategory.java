package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I751ActiveMilitaryGovernmentOrdersSubcategory implements EligibilitySubcategoryEnum {
    ACTIVE_MILITARY_OR_GOVERNMENT_ORDERS("ACTIVE_MILITARY_OR_GOVERNMENT_ORDERS");

    private @Getter String category;

 	I751ActiveMilitaryGovernmentOrdersSubcategory(String category) {
 		this.category = category;
 		EligibilitySubcategoryRegistry.register(this);
 	}
}
