package gov.dhs.uscis.intake.models.form.metadata;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@DynamoDbBean
public class FormEdition {
    Integer numberOfPages;
    String edition;
    String ombNo;
    String expires;
    String available;
}
