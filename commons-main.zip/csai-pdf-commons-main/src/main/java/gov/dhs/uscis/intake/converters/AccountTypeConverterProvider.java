package gov.dhs.uscis.intake.converters;

import java.util.Map;

import gov.dhs.uscis.intake.enums.AccountType;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.utils.ImmutableMap;

public final class AccountTypeConverterProvider implements AttributeConverterProvider {
 private final Map<EnhancedType<?>, AttributeConverter<?>> converterCache = ImmutableMap.of(
         EnhancedType.of(AccountType.class), new AccountTypeConverter());

 public static AccountTypeConverterProvider create() {
     return new AccountTypeConverterProvider();
 }

 @SuppressWarnings("unchecked")
 @Override
 public <T> AttributeConverter<T> converterFor(EnhancedType<T> enhancedType) {
     return (AttributeConverter<T>) converterCache.get(enhancedType);
 }
}