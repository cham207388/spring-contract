package gov.dhs.uscis.intake.monitoring;

import java.time.Instant;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import gov.dhs.uscis.intake.models.EntityType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest.ManifestUpdate;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest.SubmissionUpdate;
import software.amazon.awssdk.services.cloudwatch.CloudWatchClient;
import software.amazon.awssdk.services.cloudwatch.model.Dimension;
import software.amazon.awssdk.services.cloudwatch.model.MetricDatum;
import software.amazon.awssdk.services.cloudwatch.model.PutMetricDataRequest;
import software.amazon.awssdk.services.cloudwatch.model.StandardUnit;

@Aspect
@Component
public class MetricPublisher {

    private Logger logger = LoggerFactory.getLogger(MetricPublisher.class);
    private CloudWatchClient cloudWatchClient;
    private ObjectMapper objectMapper;
    private String environment;

    public MetricPublisher(@Value("${application.cloudwatch.environment}") String environment,
            CloudWatchClient cloudWatchClient) {
        this.objectMapper = new ObjectMapper().configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        this.cloudWatchClient = cloudWatchClient;
        this.environment = environment;

    }

    @AfterReturning(value = "@annotation(annotation)")
    public void postMetric(final JoinPoint joinPoint, final MetricAware annotation) {
        try {
            logger.info("Publishing metric {} to cloudwatch", annotation.transaction());
            String submissionId = extractSubmissionIdFromArgumentsIfAvailable(joinPoint.getArgs());

            publishCloudWatchMetric(annotation, submissionId);
        } catch (Exception e) {
            logger.error("There was an issue while processing Metric Request", e);
        }
    }

    @AfterReturning(value = "@annotation(annotation)")
    public void postMetric(final JoinPoint joinPoint, final SubmissionStateChange annotation) {
        try {
            String submissionId = extractSubmissionIdFromArgumentsIfAvailable(joinPoint.getArgs());
            String updateEvent = extractUpdateEvent(joinPoint.getArgs());
            logger.info("Publishing SubmissionStateChange metric {} to cloudwatch", updateEvent);

            if (updateEvent != null) {
                publishCloudWatchMetric(annotation, updateEvent, submissionId);
            } else {
                logger.error(
                        "Submission State Change metric is not configured correctly.  Transaction is processing but no metric will be broadcasted");
            }
        } catch (Exception e) {
            logger.error("There was an issue while processing Metric Request", e);
        }
    }

    // Todo: Fix with inheritance.
    private String extractUpdateEvent(Object[] args) {
        if (args != null) {
            for (var obj : args) {
                if (obj != null && obj.getClass() == SubmissionUpdateRequest.class) {
                    var update = ((SubmissionUpdateRequest) obj);
                    if (update.getUpdateType() == EntityType.MANIFEST && update.getManifestUpdate() != null
                            && update.getManifestUpdate().getClass() == ManifestUpdate.class) {
                        return update.getManifestUpdate().getStatus().toString();
                    } else if (update.getUpdateType() == EntityType.SUBMISSION && update.getSubmissionUpdate() != null
                            && update.getSubmissionUpdate().getClass() == SubmissionUpdate.class) {
                        return update.getSubmissionUpdate().getStatus().toString();
                    }
                }
            }
        }

        return null;
    }

    private String extractSubmissionIdFromArgumentsIfAvailable(Object[] args) {
        if (args != null) {
            for (var obj : args) {
                if (obj != null && obj.getClass() == Submission.class) {
                    return ((Submission) obj).getSubmissionId();
                }
            }
        }

        return "";
    }

    private void publishCloudWatchMetric(SubmissionStateChange annotation, String updateEvent, String submissionId)
            throws JsonProcessingException {
        var metricMessage = PutMetricDataRequest.builder()
                .metricData(buildMetricData(annotation, updateEvent, submissionId))
                .namespace(annotation.namespace())
                .build();
        logger.info("publishing metric {}", objectMapper.writeValueAsString(metricMessage));
        cloudWatchClient.putMetricData(metricMessage);
    }

    private MetricDatum buildMetricData(SubmissionStateChange annotation, String updateEvent, String submissionId) {
        var dimension = Dimension.builder()
                .name("Transactions")
                .value(updateEvent)
                .build();
        var metric = MetricDatum.builder()
                .dimensions(dimension)
                .value(annotation.count())
                .unit(StandardUnit.COUNT)
                .timestamp(Instant.now())
                .metricName(String.format("%s_SUBMISSION_%s", environment, updateEvent))
                .build();

        return metric;
    }

    private void publishCloudWatchMetric(MetricAware annotation, String submissionId) throws JsonProcessingException {
        var metricMessage = PutMetricDataRequest.builder()
                .metricData(buildMetricData(annotation, submissionId))
                .namespace(annotation.namespace())
                .build();
        logger.info("publishing metric {}", objectMapper.writeValueAsString(metricMessage));
        cloudWatchClient.putMetricData(metricMessage);
    }

    private MetricDatum buildMetricData(MetricAware annotation, String submissionId) {
        var dimension = Dimension.builder()
                .name("Transactions")
                .value(annotation.transaction().toString())
                .build();
        var metric = MetricDatum.builder()
                .dimensions(dimension)
                .value(annotation.count())
                .unit(StandardUnit.COUNT)
                .timestamp(Instant.now())
                .metricName(String.format("%s_%s", environment, annotation.transaction().toString()))
                .build();

        return metric;
    }

}
