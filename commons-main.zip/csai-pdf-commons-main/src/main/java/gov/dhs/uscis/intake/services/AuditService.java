package gov.dhs.uscis.intake.services;

import java.time.Clock;
import java.util.List;

import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.daos.AuditDAO;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.audit.Audit;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import static gov.dhs.uscis.intake.entities.audit.Audit.Event;

@RequiredArgsConstructor
@Service
@Slf4j
public class AuditService {

    final AuditDAO auditDao;

    final Clock clock;

    public Audit createAudit(String myUscisId, String submissionId) {
        Audit audit = Audit.builder()
                .myUscisId(myUscisId)
                .submissionId(submissionId)
                .events(List.of(
                        Event.builder()
                                .actionPerformed(ActionPerformed.DRAFT_CREATED)
                                .submissionState(SubmissionState.DRAFT)
                                .timestamp(this.clock.instant())
                                .build()))
                .build();

        return auditDao.save(audit);
    }

    public Audit addEvent(String myUscisId, String submissionId, ActionPerformed action,
            SubmissionState submissionState,
            String metadata) {
                log.info("Adding audit record for user {}, submission {} for action {}", myUscisId, submissionId, action );
        Audit audit = auditDao.find(myUscisId, submissionId);
        if (audit != null) {
            audit.getEvents()
                    .add(Event.builder()
                            .actionPerformed(action)
                            .metadata(metadata)
                            .submissionState(submissionState)
                            .timestamp(this.clock.instant())
                            .build());

            return auditDao.update(audit);
        }
        log.info("There was an issue saving audit record relating to submission {} for {}.", submissionId, action );
        return audit;

    }

    public Audit addEvent(String myUscisId, String submissionId, ActionPerformed action, String metadata) {
        return addEvent(myUscisId, submissionId, action, SubmissionState.DRAFT, metadata);
    }

}