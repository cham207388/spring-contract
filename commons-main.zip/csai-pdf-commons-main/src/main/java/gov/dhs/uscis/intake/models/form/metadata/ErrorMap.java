package gov.dhs.uscis.intake.models.form.metadata;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import gov.dhs.uscis.intake.models.ErrorType;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@Builder
@DynamoDbBean
@AllArgsConstructor
@NoArgsConstructor
public class ErrorMap {
    ErrorType errorType;
    String errorMessage;
}
