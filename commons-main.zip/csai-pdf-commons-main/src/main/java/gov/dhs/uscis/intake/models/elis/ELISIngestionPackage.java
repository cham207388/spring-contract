package gov.dhs.uscis.intake.models.elis;

import java.io.Serializable;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ELISIngestionPackage implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Map<String, String> s3Key;
	private String myUscisId;
	private String manifestId;
	private String submissionId;
	private String userGroupId;

}
