package gov.dhs.uscis.intake.entities;

public enum JobTypeEnum {
  I797Validation,
  I912AllValidations,
  I912EditionValidation,
  I912SignatureValidation,
  ApplicantSignature,
  RepresentativeSignature,
  I765NameExtract,
  N400NameExtract,
  G28NameExtract,
  AddressExtract,
  AttorneyNameExtract,
  ClientNameEmailExtract;
}