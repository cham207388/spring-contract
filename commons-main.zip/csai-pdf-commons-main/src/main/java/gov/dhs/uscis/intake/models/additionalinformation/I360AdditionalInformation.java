package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.Builder;

@Builder
@JsonIgnoreProperties(ignoreUnknown=true)
public class I360AdditionalInformation extends AdditionalInformation {


    public I360AdditionalInformation() {
    	this.formType = FormType.I360.getType();
    }
}
