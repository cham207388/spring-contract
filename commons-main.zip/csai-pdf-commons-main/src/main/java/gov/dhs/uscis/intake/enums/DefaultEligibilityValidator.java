package gov.dhs.uscis.intake.enums;

public class DefaultEligibilityValidator implements EligibilityValidator {

    @Override
    public boolean isValid(String category, String rawFormExtractedCategory) {
        if (rawFormExtractedCategory == null)
            return false;

        var cleanedFormExtractedCategory = cleanedEligibilityCategory(rawFormExtractedCategory);
        if (!cleanedFormExtractedCategory.matches("(?i)^[CA]\\d+$")) {
            return false;
        } else if (category.equals(normalizeEligibilityCategory(cleanedFormExtractedCategory))) {
            return true;
        }
        return false;

    }

    protected String cleanedEligibilityCategory(String formFieldEligibilityCategory) {
        return String.valueOf(formFieldEligibilityCategory).replace(" ", "");
    }

    protected String normalizeEligibilityCategory(String formFieldEligibilityCategory) {
        return String.valueOf(formFieldEligibilityCategory).toUpperCase().replace("0", "");
    }

    protected String clean(String formFieldEligibilityCategory) {
        return cleanedEligibilityCategory(normalizeEligibilityCategory(formFieldEligibilityCategory));
    }

}