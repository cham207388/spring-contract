package gov.dhs.uscis.intake.models.sns;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;

public record DocumentValidationRequestDetails(FormType formType, EligibilityCategoryEnum eligibilityCategory,
    String submissionId, String documentId, String evidenceType, String bucket, String key) {

}
