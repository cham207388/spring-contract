package gov.dhs.uscis.intake.converters;

import java.util.Map;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.enhanced.dynamodb.internal.converter.attribute.ListAttributeConverter;
import software.amazon.awssdk.utils.ImmutableMap;

public final class EligibilitySubcategoryListConverterProvider implements AttributeConverterProvider {
	private final Map<EnhancedType<?>, AttributeConverter<?>> converterCache = ImmutableMap
			.of(EnhancedType.listOf(EligibilitySubcategoryEnum.class), ListAttributeConverter.create(new EligibilitySubcategoryConverter()));

	public static EligibilitySubcategoryListConverterProvider create() {
		return new EligibilitySubcategoryListConverterProvider();
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> AttributeConverter<T> converterFor(EnhancedType<T> enhancedType) {
		return (AttributeConverter<T>) converterCache.get(enhancedType);
    }


}