package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I539EligibilitySubcategory implements EligibilitySubcategoryEnum {

    EXTENSION_OF_STAY_IN_CURRENT_STATUS("EXTENSION_OF_STAY_IN_CURRENT_STATUS"),
	CHANGE_OF_STATUS("CHANGE_OF_STATUS"),
    REINSTATEMENT_OF_STUDENT_STATUS("REINSTATEMENT_OF_STUDENT_STATUS"),

	TEST_SUB("TEST_SUB");
    
	private @Getter String category;

	I539EligibilitySubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}
}
