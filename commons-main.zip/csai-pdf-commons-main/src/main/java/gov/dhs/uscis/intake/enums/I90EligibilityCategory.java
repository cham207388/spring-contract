package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I90EligibilitySubcategory;
import lombok.Getter;

public enum I90EligibilityCategory implements PFVSEligibilityCategoryEnum {
    LAWFUL_PERMANENT_RESIDENT("LAWFUL_PERMANENT_RESIDENT", Arrays.asList(I90EligibilitySubcategory.values())),
    PERMANENT_RESIDENT_IN_COMMUTER_STATUS("PERMANENT_RESIDENT_IN_COMMUTER_STATUS", Arrays.asList(I90EligibilitySubcategory.values())),
    CONDITIONAL_PERMANENT_RESIDENT("CONDITIONAL_PERMANENT_RESIDENT", Arrays.asList(I90EligibilitySubcategory.values()));

    private @Getter String category;
    private @Getter List<EligibilitySubcategoryEnum> subcategories;

    I90EligibilityCategory(String category, List<EligibilitySubcategoryEnum> subcategories) {
		this.category = category;
        this.subcategories = subcategories;
		EligibilityCategoryRegistry.register(this);
	}

}