package gov.dhs.uscis.intake.models.form.metadata;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@DynamoDbBean
public class FeeWaiverMetaData {

    @Getter(onMethod_ = { @DynamoDbPartitionKey })
    String formType;
    List<FeeWaiverEditions> editions;
    String formDescription;


}
