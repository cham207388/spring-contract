package gov.dhs.uscis.intake.services.formats;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public enum MagicBytes {
    //Define the first 2 required bytes, some have more.
    PNG("image/png", ".png", b(0x89), b(0x50)),
    JPG("image/jpeg", ".jpeg", b(0xFF), b(0xD8)),
    PDF("application/pdf", ".pdf", b(0x25), b(0x50)),
    TIFFA("image/tiff", ".tiff", b(0x49) ,b(0x49)),
    TIFFB("image/tiff", ".tiff", b(0x4D) ,b(0x4D)),
    UNSUPPORTED(null, null);

    private final byte[] magicBytes;
    private final String contentType;
    private final String extension;

    public String getContentType(){ return this.contentType; }
    public String getExtension(){ return this.extension; }
    public byte[] getMagicBytes(){ return this.magicBytes; }
    
    private MagicBytes(String contentType, String extension , byte...bytes) {
        this.magicBytes = bytes;
        this.contentType = contentType;
        this.extension = extension;
    }
    
    // Checks if bytes match a specific magic bytes sequence
    public MagicBytes is(byte... bytes) {
        if (bytes.length < magicBytes.length)
            throw new RuntimeException("[" + contentType + "] -Insufficient bytes for comparison, this format requires: " + magicBytes.length);
        for (int i=0; i<magicBytes.length; i++)
            if (b(bytes[i]) != magicBytes[i])
                return UNSUPPORTED;
        return this;
    }

    public static byte b(int b){
        return (byte) b;
    }
    
    // Extracts head bytes from any stream
    public static byte[] extract(InputStream is, int length) throws IOException {
        try (is) {  // automatically close stream on return
            byte[] buffer = new byte[length];
            is.read(buffer, 0, length);
            return buffer;
        }
    }
    
    /* Convenience methods */
    public MagicBytes is(File file) throws IOException {
        return is(new FileInputStream(file));
    }
    
    public MagicBytes is(InputStream is) throws IOException {
        return is(extract(is, magicBytes.length));
    }
}