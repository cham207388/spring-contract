package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I131ReparoleNewPeriodOfParoleEligibilitySubcategory implements EligibilitySubcategoryEnum {
	FAMILY_REUNIFICATION("FAMILY_REUNIFICATION"),
	CERTAIN_AFGHANS("CERTAIN_AFGHANS"),
	UKRANIAN("UKRANIAN"),
	FWVP("FWVP"),
	IMMVI_MEMBER("IMMVI_MEMBER"),
	IMMVI_DEPENDENT("IMMVI_DEPENDENT"),
	IMMVI_GUARDIAN("IMMVI_GUARDIAN"),
	CAM("CAM"),
	PIP_MEMBER("PIP_MEMBER"),
	PIP_DEPENDENT("PIP_DEPENDENT"),
	FRTF("FRTF"),
	OTHER("OTHER"),
	NON_SPECIFIC("NON_SPECIFIC");

	private @Getter String category;

	I131ReparoleNewPeriodOfParoleEligibilitySubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}

}
