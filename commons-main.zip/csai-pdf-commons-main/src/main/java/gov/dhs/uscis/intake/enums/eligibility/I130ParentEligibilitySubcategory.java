package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I130ParentEligibilitySubcategory implements EligibilitySubcategoryEnum {
	PARENT_MARRIED("PARENT_MARRIED"), 
	PARENT_STEPPARENT("PARENT_STEPPARENT"),
	PARENT_NOT_MARRIED("PARENT_NOT_MARRIED"),
	PARENT_ADOPTED("PARENT_ADOPTED")
	;

	private @Getter String category;

	I130ParentEligibilitySubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}

}
