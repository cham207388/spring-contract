package gov.dhs.uscis.intake.models.dto;


import java.util.List;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LockboxForm {
    private String type;
    private String id;
    private String url;
    private String name;
    private String md5Hash;
    private List<RejectionReason> rejectionReasons;
}