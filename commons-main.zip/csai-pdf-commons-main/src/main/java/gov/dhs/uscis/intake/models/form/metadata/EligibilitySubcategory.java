package gov.dhs.uscis.intake.models.form.metadata;

import java.util.List;

import gov.dhs.uscis.intake.models.EvidenceGroup;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@DynamoDbBean
public class EligibilitySubcategory {
	String category;
	String label;
	boolean disabled;
    String filterValue;
    List<EvidenceGroup> evidenceGroupsToInclude;
    List<String> evidenceCategoriesToExclude;
	boolean feeWaivable;
    String applicationReasonCode;
    String benefitTypeCodeOverride;
    String immigrationClassCode;
    List<ActionRequestedOption> actionRequestedOptions;
}