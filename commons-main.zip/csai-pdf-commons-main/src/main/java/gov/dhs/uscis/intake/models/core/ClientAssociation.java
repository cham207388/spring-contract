package gov.dhs.uscis.intake.models.core;

public record ClientAssociation(boolean isAssociated, String clientUserGroupId) {
}