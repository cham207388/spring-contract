package gov.dhs.uscis.intake.enums;

import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import lombok.Getter;

public enum I129H2AEligibilityCategory implements PFVSEligibilityCategoryEnum {

	NEW_EMPLOYMENT("NEW_EMPLOYMENT"),
	CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITH_SAME_EMPLOYER("CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITH_SAME_EMPLOYER"),
	CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT("CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT"),
	NEW_CONCURRENT_EMPLOYMENT("NEW_CONCURRENT_EMPLOYMENT"),
	CHANGE_OF_EMPLOYER("CHANGE_OF_EMPLOYER"),
	AMENDED_PETITION("AMENDED_PETITION");
	
	private @Getter String category;
	private @Getter List<EligibilitySubcategoryEnum> subcategories;
	
	I129H2AEligibilityCategory(String category) {
		this.category = category;
		EligibilityCategoryRegistry.register(this);
	}
	
}
