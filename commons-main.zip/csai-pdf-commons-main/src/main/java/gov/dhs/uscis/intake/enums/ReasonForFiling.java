package gov.dhs.uscis.intake.enums;

import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import lombok.Getter;

public enum ReasonForFiling {

    INITIAL("Initial", 31),
    REPLACEMENT("Replacement", 32),
    RENEWAL("Renewal", 33);

    private String reasonForFiling;
    @Getter private Integer benefitTypeCode;
    
     private static final Map<String, ReasonForFiling> REASONS_FOR_FILING = Stream.of(values()).collect(Collectors.toMap(Object::toString, Function.identity()));

    ReasonForFiling(String reasonForFiling, Integer benefitTypeCode) {
        this.reasonForFiling = reasonForFiling;
        this.benefitTypeCode = benefitTypeCode;
    }

    @Override
    public String toString() {
        return reasonForFiling;
    }

    public static ReasonForFiling fromString(String from) {
        return Optional.ofNullable(REASONS_FOR_FILING.get(from)).orElseThrow(() -> new IllegalArgumentException(from));
    }

    public static ReasonForFiling fromFormEntry(String entry) {
        if (REASONS_FOR_FILING.get(entry) != null) {
            return fromString(entry);
        }

        entry = entry == null ? "" : entry;
        switch (entry) {
            case "1.a.": {
                return INITIAL;
            }
            case "1.b.": {
                return REPLACEMENT;
            }
            case "1.c.": {
                return RENEWAL;
            }
            default: throw new UnsupportedOperationException("Reason for applying does not match any defined reasons for filing.");
        }
    }

    public static boolean isApplicableToEligibilityCategory(EligibilityCategoryEnum eligibilityCategoryEnum) {
        Set<String> eligibleCategories = Set.of("C8",
                                                "C11 - Afghan Parolee",
                                                "C11 - Parole",
                                                "C11 - Ukraine Parolee",
                                                "C19",
                                                "A12",
                                                "NEW_EMPLOYMENT",
                                                "CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITH_SAME_EMPLOYER",
                                                "CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT",
                                                "NEW_CONCURRENT_EMPLOYMENT",
                                                "CHANGE_OF_EMPLOYER",
                                                "AMENDED_PETITION");
        return eligibilityCategoryEnum != null && eligibleCategories.contains(eligibilityCategoryEnum.getCategory());
    }
}
