package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I539EligibilitySubcategory;
import lombok.Getter;

public enum I539EligibilityCategory implements PFVSEligibilityCategoryEnum {

    H1B1("1B1", Arrays.asList(I539EligibilitySubcategory.values())),
    H1B2("1B2", Arrays.asList(I539EligibilitySubcategory.values())),
    H1B3("1B3", Arrays.asList(I539EligibilitySubcategory.values())),
    H1B4("1B4", Arrays.asList(I539EligibilitySubcategory.values())),
    H1B5("1B5", Arrays.asList(I539EligibilitySubcategory.values())),
    H1BS("1BS", Arrays.asList(I539EligibilitySubcategory.values())),
    B1("B1", Arrays.asList(I539EligibilitySubcategory.values())),
    B1A("B1A", Arrays.asList(I539EligibilitySubcategory.values())),
    B1B("B1B", Arrays.asList(I539EligibilitySubcategory.values())),
    B1C("B1C", Arrays.asList(I539EligibilitySubcategory.values())),
    B1D("B1D", Arrays.asList(I539EligibilitySubcategory.values())),
    B2("B2", Arrays.asList(I539EligibilitySubcategory.values())),
    CW1("CW1", Arrays.asList(I539EligibilitySubcategory.values())),
    CW2("CW2", Arrays.asList(I539EligibilitySubcategory.values())),
    E1("E1", Arrays.asList(I539EligibilitySubcategory.values())),
    E1S("E1S", Arrays.asList(I539EligibilitySubcategory.values())),
    E1Y("E1Y", Arrays.asList(I539EligibilitySubcategory.values())),
    E2("E2", Arrays.asList(I539EligibilitySubcategory.values())),
    E2C("E2C", Arrays.asList(I539EligibilitySubcategory.values())),
    E2S("E2S", Arrays.asList(I539EligibilitySubcategory.values())),
    E2Y("E2Y", Arrays.asList(I539EligibilitySubcategory.values())),
    E3("E3", Arrays.asList(I539EligibilitySubcategory.values())),
    E3D("E3D", Arrays.asList(I539EligibilitySubcategory.values())),
    E3S("E3S", Arrays.asList(I539EligibilitySubcategory.values())),
    E3Y("E3Y", Arrays.asList(I539EligibilitySubcategory.values())),
    F1("F1", Arrays.asList(I539EligibilitySubcategory.values())),
    F2("F2", Arrays.asList(I539EligibilitySubcategory.values())),
    H1C("H1C", Arrays.asList(I539EligibilitySubcategory.values())),
    H2A("H2A", Arrays.asList(I539EligibilitySubcategory.values())),
    H2B("H2B", Arrays.asList(I539EligibilitySubcategory.values())),
    H3("H3", Arrays.asList(I539EligibilitySubcategory.values())),
    H4("H4", Arrays.asList(I539EligibilitySubcategory.values())),
    I("I", Arrays.asList(I539EligibilitySubcategory.values())),
    J1("J1", Arrays.asList(I539EligibilitySubcategory.values())),
    J2("J2", Arrays.asList(I539EligibilitySubcategory.values())),
    K3("K3", Arrays.asList(I539EligibilitySubcategory.values())),
    K4("K4", Arrays.asList(I539EligibilitySubcategory.values())),
    L1("L1", Arrays.asList(I539EligibilitySubcategory.values())),
    L1A("L1A", Arrays.asList(I539EligibilitySubcategory.values())),
    L1B("L1B", Arrays.asList(I539EligibilitySubcategory.values())),
    L2("L2", Arrays.asList(I539EligibilitySubcategory.values())),
    L2S("L2S", Arrays.asList(I539EligibilitySubcategory.values())),
    L2Y("L2Y", Arrays.asList(I539EligibilitySubcategory.values())),
    M1("M1", Arrays.asList(I539EligibilitySubcategory.values())),
    M2("M2", Arrays.asList(I539EligibilitySubcategory.values())),
    N8("N8", Arrays.asList(I539EligibilitySubcategory.values())),
    N9("N9", Arrays.asList(I539EligibilitySubcategory.values())),
    O1("O1", Arrays.asList(I539EligibilitySubcategory.values())),
    O1A("O1A", Arrays.asList(I539EligibilitySubcategory.values())),
    O1B("O1B", Arrays.asList(I539EligibilitySubcategory.values())),
    O2("O2", Arrays.asList(I539EligibilitySubcategory.values())),
    O3("O3", Arrays.asList(I539EligibilitySubcategory.values())),
    P1("P1", Arrays.asList(I539EligibilitySubcategory.values())),
    P1A("P1A", Arrays.asList(I539EligibilitySubcategory.values())),
    P1B("P1B", Arrays.asList(I539EligibilitySubcategory.values())),
    P1S("P1S", Arrays.asList(I539EligibilitySubcategory.values())),
    P2("P2", Arrays.asList(I539EligibilitySubcategory.values())),
    P2S("P2S", Arrays.asList(I539EligibilitySubcategory.values())),
    P3("P3", Arrays.asList(I539EligibilitySubcategory.values())),
    P3S("P3S", Arrays.asList(I539EligibilitySubcategory.values())),
    P4("P4", Arrays.asList(I539EligibilitySubcategory.values())),
    Q1("Q1", Arrays.asList(I539EligibilitySubcategory.values())),
    R1("R1", Arrays.asList(I539EligibilitySubcategory.values())),
    R2("R2", Arrays.asList(I539EligibilitySubcategory.values())),
    TD("TD", Arrays.asList(I539EligibilitySubcategory.values())),
    TN1("TN1", Arrays.asList(I539EligibilitySubcategory.values())),
    TN2("TN2", Arrays.asList(I539EligibilitySubcategory.values())),
    UU("UU", Arrays.asList(I539EligibilitySubcategory.values())),

    TEST("TEST", Arrays.asList(I539EligibilitySubcategory.values()));

    private @Getter String category;
    private @Getter List<EligibilitySubcategoryEnum> subcategories;

    I539EligibilityCategory(String category, List<EligibilitySubcategoryEnum> subcategories) {
		this.category = category;
        this.subcategories = subcategories;
		EligibilityCategoryRegistry.register(this);
	}

}
