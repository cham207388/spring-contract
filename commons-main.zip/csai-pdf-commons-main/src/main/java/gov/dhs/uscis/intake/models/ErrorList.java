package gov.dhs.uscis.intake.models;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ErrorList {
    private List<Map<String, String>> errors;

    public ErrorList() {
        this.errors = new ArrayList<>();
    }

    public void add(ErrorType errorType, String message) {
        HashMap<String, String> error = new HashMap<>();
        error.put(errorType.getName(), message);
        errors.add(error);
    }

    public List<Map<String, String>> getErrors() {
        return errors;
    }

}
