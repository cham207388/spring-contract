package gov.dhs.uscis.intake.util;

import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SubmissionUtils {

    private SubmissionUtils() {
        throw new IllegalStateException("Utility class");
    }

    public static List<SubmissionState> convertAndValidateFilters(String filters) {
        if (filters == null)
            return new java.util.ArrayList<>();

        var filterList = filters.split(",");
        return Arrays.stream(filterList)
                .filter(f -> {
                    try {
                        SubmissionState.valueOf(f.trim());
                        return true;
                    } catch (IllegalArgumentException e) {
                        log.error("Invalid filter value: " + f, e);
                    } catch (Exception e) {
                        log.error("Unexpected exception while parsing filter value: " + f, e);
                    }
                    return false;
                })
                .map(f -> SubmissionState.valueOf(f.trim()))
                .toList();
    }

    public static Submission copySubmission(Submission submission) {
        return Submission.builder()
                .applicant(submission.getApplicant())
                .eligibilityCategory(submission.getEligibilityCategory())
                .formType(submission.getFormType())
                .myUscisId(submission.getMyUscisId())
                .formType(submission.getFormType())
                .eligibilityCategory(submission.getEligibilityCategory())
                .eligibilitySubcategory(submission.getEligibilitySubcategory())
                .status(submission.getStatus())
                .feeTotal(submission.getFeeTotal())
                .timestamp(ZonedDateTime.now())
                .forms(submission.getForms())
                .evidences(submission.getEvidences())
                .feeWaiver(submission.getFeeWaiver())
                .userRequestedFeeWaiver(submission.getUserRequestedFeeWaiver())
                .userRequestedPartialFeeWaiver(submission.getUserRequestedPartialFeeWaiver())
                .userIsEligibleForFeeWaiver(submission.getUserIsEligibleForFeeWaiver())
                .immvi(submission.getImmvi())
                .reasonForFiling(submission.getReasonForFiling())
                .applicant(submission.getApplicant())
                .isUSCitizen(submission.getIsUSCitizen())
                .sentNotify(submission.getSentNotify())
                .selectedConcurrentForms(submission.getSelectedConcurrentForms())
                .build();
    }

    public static SubmissionEvidence convertToEvidence(SubmissionForm form) {
        return SubmissionEvidence.builder()
                .type("Other")
                .evidenceGroupType("additional-evidence")
                .id(form.getId())
                .url(form.getUrl())
                .name(form.getName())
                .md5Hash(form.getMd5Hash())
                .uploadedAt(form.getUploadedAt())
                .s3Key(form.getS3Key())
                .markedS3Key(form.getMarkedS3Key())
                .build();
    }
}
