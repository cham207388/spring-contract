package gov.dhs.uscis.intake.entities;

import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@DynamoDbBean
public class SubmissionManifest {
  String myUscisId;
  String submissionId;
  @Getter(onMethod_ = { @DynamoDbPartitionKey })
  String manifestId;
  Statuses statuses;
  Manifest manifest;
}
