package gov.dhs.uscis.intake.models;

public enum EntityType {
    SUBMISSION,
    MANIFEST
}