package gov.dhs.uscis.intake.models.additionalinformation;


import gov.dhs.uscis.intake.enums.PFVSEvidenceType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
public class ETA9089AdditionalInformation extends AdditionalInformation {
    private @Getter @Setter String dolNumber;

    public ETA9089AdditionalInformation() {
    	this.formType = PFVSEvidenceType.E9089FD.getType();
    }
}