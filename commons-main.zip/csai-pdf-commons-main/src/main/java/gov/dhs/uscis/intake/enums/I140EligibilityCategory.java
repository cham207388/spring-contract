package gov.dhs.uscis.intake.enums;

public enum I140EligibilityCategory implements EligibilityCategoryEnum{
  EXTRAORDINARY_ABILITY("ExtraordinaryAbility"),
  OUTSTANDING_PROFESSOR("OutstandingProfessor"),
  MULTINATIONAL_EXECUTIVE("MultinationalExecutive"),
  MEMBER_OF_PROFESSIONS("MemberOfProfessionsHoldingAnAdvancedDegree"),
  PROFESSIONAL("Professional"),
  SKILLED_WORKER("SkilledWorker"),
  ANY_OTHER_WORKER("AnyOtherWorker"),
  ALIEN_APPLYING_FOR_NIW("AlienApplyingForNiw");

  private String category;

  I140EligibilityCategory(String category) {
    this.category = category;
    EligibilityCategoryRegistry.register(this);
  }

  @Override
  public String getCategory() {
    return category;
  }
    
}
