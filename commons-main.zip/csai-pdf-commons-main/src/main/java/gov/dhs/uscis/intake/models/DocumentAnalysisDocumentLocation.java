package gov.dhs.uscis.intake.models;

import lombok.Builder;

@Builder
public record DocumentAnalysisDocumentLocation(String S3ObjectName, String S3Bucket) {
}
