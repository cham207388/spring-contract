package gov.dhs.uscis.intake.models;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.lang.Nullable;

import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@SuppressWarnings("serial")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@DynamoDbBean
public class SubmissionStatus implements Serializable {

    private String correlationId;
    private String uscisId;
    private StatusEnum status;
    private List<ApplicationStatus> applicationStatuses;
    @Nullable
    private List<RejectionReason> unableToProcessReason;
    @Nullable
    private BigDecimal totalCost;

}
