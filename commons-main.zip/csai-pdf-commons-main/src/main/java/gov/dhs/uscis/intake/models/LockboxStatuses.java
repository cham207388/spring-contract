package gov.dhs.uscis.intake.models;

public enum LockboxStatuses {
    RECEIVED,
    REJECTED,
    ACCEPTED,
    PROCESSING,
    PENDING,
    ERROR;
}
