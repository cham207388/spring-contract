package gov.dhs.uscis.intake.models.submission;

import java.time.ZonedDateTime;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import gov.dhs.uscis.intake.converters.ZonedDateTimeConverterProvider;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.DefaultAttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@DynamoDbBean(converterProviders = {ZonedDateTimeConverterProvider.class, DefaultAttributeConverterProvider.class})
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubmissionEvidence {
    @Nullable
    private String type;
    @Nullable
    private String evidenceGroupType;
    private String id;
    private String formId;
    private String url;
    private String name;
    private String md5Hash;
    private ZonedDateTime uploadedAt;
    @JsonIgnore
    private String s3Key;
    @JsonIgnore
    private String markedS3Key;
    @Builder.Default
    private Boolean isEditable = true;
}
