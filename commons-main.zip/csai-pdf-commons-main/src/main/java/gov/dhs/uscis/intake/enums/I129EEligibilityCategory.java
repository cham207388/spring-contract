package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I129EEligibilitySubcategory;
import lombok.Getter;

public enum I129EEligibilityCategory implements PFVSEligibilityCategoryEnum {

    E_NEW_EMPLOYMENT("E_NEW_EMPLOYMENT", Arrays.asList(I129EEligibilitySubcategory.values())),
	E_CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITH_SAME_EMPLOYER("E_CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITH_SAME_EMPLOYER", Arrays.asList(I129EEligibilitySubcategory.values())),
	E_CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT("E_CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT", Arrays.asList(I129EEligibilitySubcategory.values())),
	E_NEW_CONCURRENT_EMPLOYMENT("E_NEW_CONCURRENT_EMPLOYMENT", Arrays.asList(I129EEligibilitySubcategory.values())),
	E_CHANGE_OF_EMPLOYER("E_CHANGE_OF_EMPLOYER", Arrays.asList(I129EEligibilitySubcategory.values())),
	E_AMENDED_PETITION("E_AMENDED_PETITION", Arrays.asList(I129EEligibilitySubcategory.values()));
    ;

	private @Getter String category;
	private @Getter List<EligibilitySubcategoryEnum> subcategories;

	I129EEligibilityCategory(String category, List<EligibilitySubcategoryEnum> subcategories) {
		this.category = category;
        this.subcategories = subcategories;
		EligibilityCategoryRegistry.register(this);
	}

}