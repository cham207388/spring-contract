package gov.dhs.uscis.intake.util;

import java.util.List;

import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;

public class MapEvidenceTypes {

    private MapEvidenceTypes() {

    }

    public static SubmissionEvidence mapEOIRBIAEvidence(SubmissionEvidence submissionEvidence) {
        if (("BIA Order").equalsIgnoreCase(submissionEvidence.getType())
                || ("EOIR").equalsIgnoreCase(submissionEvidence.getType())) {
            submissionEvidence.setType("Other");
        }
        return submissionEvidence;
    }

    public static List<SubmissionEvidence> mapEOIRBIAEvidenceList(List<SubmissionEvidence> evidenceList) {
        evidenceList.stream()
                .filter(submissionEvidence -> ("BIA Order").equalsIgnoreCase(submissionEvidence.getType())
                        || ("EOIR").equalsIgnoreCase(submissionEvidence.getType()))
                .forEach(submissionEvidence -> submissionEvidence.setType("Other"));
        return evidenceList;
    }
}