package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I129EEligibilitySubcategory implements EligibilitySubcategoryEnum {
    E1_TREATY_TRADER("E1_TREATY_TRADER", "E1"),
    E2_TREATY_INVESTOR("E2_TREATY_INVESTOR", "E2"),
    E2_CNMI_INVESTOR("E2_CNMI_INVESTOR","E2C"),
	;

	private @Getter String category;
	private @Getter String immigrationClassCode;

	I129EEligibilitySubcategory(String category, String immigrationClassCode) {
		this.category = category;
        this.immigrationClassCode = immigrationClassCode;
		EligibilitySubcategoryRegistry.register(this);
	}

}