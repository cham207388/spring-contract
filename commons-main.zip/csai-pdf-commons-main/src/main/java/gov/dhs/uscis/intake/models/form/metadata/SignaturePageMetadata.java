package gov.dhs.uscis.intake.models.form.metadata;

import gov.dhs.uscis.intake.converters.AccountTypeConverter;
import gov.dhs.uscis.intake.enums.AccountType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbConvertedBy;

@Data
@Builder
@DynamoDbBean
@AllArgsConstructor
@NoArgsConstructor
public class SignaturePageMetadata {
    @Getter(onMethod_ = { @DynamoDbConvertedBy(AccountTypeConverter.class) })
    AccountType entity;
    Integer page;
}
