package gov.dhs.uscis.intake.models.validation.name_extract;

import gov.dhs.uscis.intake.enums.ValidatorEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor

public class NameValidationResult {
    String formId;
    String submissionId;
    String myUscisId;
    ValidatorEnum validator;
    String formType;
    ClientName clientName;
}