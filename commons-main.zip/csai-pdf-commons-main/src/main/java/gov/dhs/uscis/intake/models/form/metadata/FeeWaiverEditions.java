package gov.dhs.uscis.intake.models.form.metadata;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@DynamoDbBean
public class FeeWaiverEditions {
    String edition;
    String expires;
    Integer numberOfPages;
    Integer signaturePage;

}
