package gov.dhs.uscis.intake.models.dto;

import java.math.BigDecimal;
import java.util.List;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LockboxSubmission {
    private String submissionId;
    private Boolean feeWaiver;
    private BigDecimal feeTotal;
    private StatusEnum lockboxStatus;

    private LockboxForm primaryForm;
    private List<LockboxForm> additionalForms;
    private List<SubmissionEvidence> evidences;
}