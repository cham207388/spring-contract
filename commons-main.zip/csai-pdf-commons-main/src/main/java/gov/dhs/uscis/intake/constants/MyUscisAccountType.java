package gov.dhs.uscis.intake.constants;

public enum MyUscisAccountType {
    REPRESENTATIVE("representative"),
    APPLICANT("applicant");
    
    private String type;

    MyUscisAccountType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
