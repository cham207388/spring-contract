package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I751ActiveMilitaryGovernmentOrdersSubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I751WaiverOrIndividualFilingSubcategory;
import lombok.Getter;
import lombok.Setter;

public enum I751EligibilityCategory implements PFVSEligibilityCategoryEnum {

SPOUSE("Spouse", Arrays.asList(I751ActiveMilitaryGovernmentOrdersSubcategory.values())),
MY_PARENT_SPOUSE("MyParentSpouse", Arrays.asList(I751ActiveMilitaryGovernmentOrdersSubcategory.values())),
WAIVER_OR_INDIVIDUAL_FILING(
    "WaiverOrIndividualFiling", 
            Stream.of(
                I751WaiverOrIndividualFilingSubcategory.values(),
                I751ActiveMilitaryGovernmentOrdersSubcategory.values()
            )
            .flatMap(Arrays::stream)
            .collect(Collectors.toList())
        );

  private String category;
  private @Getter  @Setter List<EligibilitySubcategoryEnum> subcategories;

  I751EligibilityCategory(String category, List<EligibilitySubcategoryEnum> subCategories) {
    this.category = category;
    this.subcategories = subCategories;

    EligibilityCategoryRegistry.register(this);
  }

  @Override
  public String getCategory() {
    return category;
  }
}
