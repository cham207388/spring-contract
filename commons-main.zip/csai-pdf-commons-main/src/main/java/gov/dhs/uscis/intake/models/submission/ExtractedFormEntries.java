package gov.dhs.uscis.intake.models.submission;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class ExtractedFormEntries {
    private String eligibilityCategory;
    private boolean isSalvadorianABCEligible;
    private String reasonForFiling;
    private List<String> eligibilitySubcategories;
}
