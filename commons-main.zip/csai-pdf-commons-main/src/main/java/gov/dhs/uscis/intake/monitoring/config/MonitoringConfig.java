package gov.dhs.uscis.intake.monitoring.config;

import java.net.URI;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatch.CloudWatchClient;

@Configuration
public class MonitoringConfig {
    
    @Bean
    public CloudWatchClient cloudWatchClient(@Value("${application.cloudwatch.endpoint}") String endpoint) {
        return CloudWatchClient.builder().endpointOverride(URI.create(endpoint)).region(Region.US_EAST_1).build();
    }
}
