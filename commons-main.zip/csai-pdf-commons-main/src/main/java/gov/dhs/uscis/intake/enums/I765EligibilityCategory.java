package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.StreamSupport;

public enum I765EligibilityCategory implements EligibilityCategoryEnum {
    A12(new DefaultEligibilityValidator(), "A12"),
    C8(new DefaultEligibilityValidator(), "C8", "C08"),
    C9(new DefaultEligibilityValidator(), "C9", "C09"),
    C19(new DefaultEligibilityValidator(), "C19"),
    C11AFGHAN(new DefaultEligibilityValidator(), "C11 - Afghan Parolee", "C11"),
    C11PAROLE(new DefaultEligibilityValidator(), "C11 - Parole", "C11"),
    C11UKRAINE(new DefaultEligibilityValidator(), "C11 - Ukraine Parolee", "C11");

    private String[] category;
    private EligibilityValidator validator;

  I765EligibilityCategory(EligibilityValidator validator, String... category) {
        this.category = category;
        this.validator = validator;
        EligibilityCategoryRegistry.register(this);
    }   

    public boolean isValid(String formCategory) {
        return StreamSupport.stream(Arrays.spliterator(category), false)
                .anyMatch(s -> validator.isValid(s, formCategory));
    }

    @Override
    public String getCategory() {
        return category[0];
    }


    public static boolean isC11Category(EligibilityCategoryEnum eligibilityCategory) {
        return List.of(I765EligibilityCategory.C11AFGHAN, I765EligibilityCategory.C11PAROLE,
                I765EligibilityCategory.C11UKRAINE).contains(eligibilityCategory);
    }

    public static boolean isC9Category(EligibilityCategoryEnum eligibilityCategory) {
        return I765EligibilityCategory.C9.equals(eligibilityCategory);
    }

}
