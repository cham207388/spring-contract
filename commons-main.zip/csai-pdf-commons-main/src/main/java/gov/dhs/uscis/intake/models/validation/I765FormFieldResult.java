package gov.dhs.uscis.intake.models.validation;

import java.util.List;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class I765FormFieldResult extends FormFieldResult {
  public final static FormType FORM_TYPE= FormType.I765;
  private String reasonForApplySelection;
  private Boolean abcBenefitsApplied;

  @Builder
  public I765FormFieldResult(String formId, String submissionId, String myUscisId, String alienNumber,
      String dateOfBirth, ValidatorEnum validator, List<EligibilityCategoryEnum> selectedCategories,
      boolean abcBenefitsApplied, String reasonForApplySelection) {
    super(formId, submissionId, myUscisId, alienNumber, dateOfBirth, validator, selectedCategories);
    this.abcBenefitsApplied = abcBenefitsApplied;
    this.reasonForApplySelection = reasonForApplySelection;
  }

  @Override
  public FormType getFormType() {
    return I765FormFieldResult.FORM_TYPE;
  }
}
