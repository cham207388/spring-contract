package gov.dhs.uscis.intake.entities.submission;

public enum SubmissionState {
  DRAFT,
  DELETED,
  PUBLISHED,
  ACCEPTED,
  REJECTED,
  RECEIVED,
  ERROR
}
