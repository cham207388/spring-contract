package gov.dhs.uscis.intake.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public interface EligibilityCategoryEnum {

  @JsonValue
  String getCategory();
  
  @JsonCreator
  static EligibilityCategoryEnum fromString(String from) throws IllegalArgumentException {
    if (from == null) return null;
    
    EligibilityCategoryEnum result = EligibilityCategoryRegistry.REGISTRY.get(from);
    if (result == null) {
      throw new IllegalArgumentException("Unknown enum value: " + from);
    }
    return result;
    
  }

  static class EligibilityCategoryRegistry {

    private EligibilityCategoryRegistry() {}

    static final Map<String, EligibilityCategoryEnum> REGISTRY = new HashMap<>();

    static void register(EligibilityCategoryEnum el) {
      REGISTRY.put(el.getCategory(), el);
      REGISTRY.put(el.toString(), el); // For backward compatibility
    }
  }

}
