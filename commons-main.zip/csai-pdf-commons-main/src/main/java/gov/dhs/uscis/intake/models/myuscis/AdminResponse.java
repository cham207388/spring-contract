package gov.dhs.uscis.intake.models.myuscis;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class AdminResponse implements Serializable {

	private static final long serialVersionUID = 7433023475969874297L;
	
	private List<Admin> data;
	
}
