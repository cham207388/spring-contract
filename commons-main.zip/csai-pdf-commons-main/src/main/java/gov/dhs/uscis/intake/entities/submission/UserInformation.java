package gov.dhs.uscis.intake.entities.submission;

import gov.dhs.uscis.intake.converters.AccountTypeConverter;
import gov.dhs.uscis.intake.enums.AccountType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbConvertedBy;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class UserInformation {
    private String myUscisId;
    private String userGroupId;
    private String email;
    @Getter(onMethod_ = { @DynamoDbConvertedBy(AccountTypeConverter.class) })
    private AccountType accountType;
}