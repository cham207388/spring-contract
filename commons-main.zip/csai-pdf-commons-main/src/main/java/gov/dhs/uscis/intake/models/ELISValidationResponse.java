package gov.dhs.uscis.intake.models;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.models.additionalinformation.AdditionalInformation;
import lombok.Builder;


@Builder
@JsonIgnoreProperties(ignoreUnknown=true)
public record ELISValidationResponse(String submissionId, String formId, boolean pass, String formType, List<ValidationStatus> results, BigDecimal fee, boolean inProgress, Map<String,BigDecimal> submissionFees, AdditionalInformation additionalInfo, BigDecimal totalFee) {}
