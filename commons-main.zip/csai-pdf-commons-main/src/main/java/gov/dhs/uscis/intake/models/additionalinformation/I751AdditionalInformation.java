package gov.dhs.uscis.intake.models.additionalinformation;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I751AdditionalInformation extends AdditionalInformation {
    private @Getter @Setter List<Integer> eligibilityCategories;

    public I751AdditionalInformation() {
    	this.formType = FormType.I751.getType();
    }
}
