package gov.dhs.uscis.intake.models.validation;

import java.util.List;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.form.metadata.EligibilitySubcategory;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@AllArgsConstructor
public class I751FormFieldsResult extends FormFieldResult {
  public final static FormType FORM_TYPE = FormType.I751;

  @Builder
  public I751FormFieldsResult(String formId, String submissionId, String myUscisId, String alienNumber,
      String dateOfBirth, ValidatorEnum validator, List<EligibilityCategoryEnum> selectedCategories, List<EligibilitySubcategory> subcategories) {
    super(formId, submissionId, myUscisId, alienNumber, dateOfBirth, validator, selectedCategories);
  }

  @Override
  public FormType getFormType() {
    return I751FormFieldsResult.FORM_TYPE;
  }
}