package gov.dhs.uscis.intake.converters;

import gov.dhs.uscis.intake.enums.AccountType;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

public final class AccountTypeConverter implements AttributeConverter<AccountType> {

  @Override
  public AttributeValue transformFrom(AccountType input) {
    return AttributeValue.fromS(input.getType());
  }

  @Override
  public AccountType transformTo(AttributeValue input) {
    return AccountType.fromString(input.s());
  }

  @Override
  public EnhancedType<AccountType> type() {
    return EnhancedType.of(AccountType.class);
  }

  @Override
  public AttributeValueType attributeValueType() {
    return AttributeValueType.S;
  }

}
