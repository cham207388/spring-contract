package gov.dhs.uscis.intake.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class MetadataConstants {
  public final static String FORMTYPE = "formtype";
  public final static String ID = "id";
  public final static String FILENAME = "filename";
  public final static String SUBMISSIONID = "submissionid";
  public final static String MYUSCISID = "myuscisid";
  public final static String ELIGIBILITYCATEGORY = "eligibilitycategory";
  public final static String EVIDENCETYPE = "evidencegrouptype";
  public final static String USERFLOW = "userflow";
  public final static String ORIGINAL_S3_KEY = "originals3key";
  public final static String ORIGINAL_PDF_PAGE_COUNT = "originalpdfpagecount";
  public final static String STRIPPED_PDF = "strippedpdf";
  public final static String SENT_TO_PFVS = "senttopfvs";

}
