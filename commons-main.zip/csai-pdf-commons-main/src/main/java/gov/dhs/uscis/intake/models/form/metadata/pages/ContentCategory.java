package gov.dhs.uscis.intake.models.form.metadata.pages;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
public class ContentCategory {
  private String title;
  private String body;
  @JsonInclude(NON_NULL)
  private String icon;
  @JsonInclude(NON_NULL)
  private List<AccordionCategory> accordionCategories;
  private String orgSpecificText;
}
