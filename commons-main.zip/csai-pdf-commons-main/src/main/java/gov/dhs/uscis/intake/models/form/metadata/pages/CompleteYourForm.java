package gov.dhs.uscis.intake.models.form.metadata.pages;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
public class CompleteYourForm {
    private String title;
    @JsonInclude(NON_NULL)
    private List<ContentCategory> categories;
    private List<ContentCategory> notices;
}
