package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I130SiblingEligibilitySubcategory implements EligibilitySubcategoryEnum {
	SIBLING_ADOPTED("SIBLING_ADOPTED"),
	SIBLING_NOT_ADOPTED("SIBLING_NOT_ADOPTED")
	;

	private @Getter String category;

	I130SiblingEligibilitySubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}

}
