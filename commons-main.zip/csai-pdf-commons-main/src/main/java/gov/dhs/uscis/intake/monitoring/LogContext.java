package gov.dhs.uscis.intake.monitoring;

import org.slf4j.MDC;

import java.io.Closeable;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class LogContext implements Closeable {

    private final Set<String> keys = new HashSet<>();

    private LogContext() {
    }

    public static LogContext put(String key, String value) {
        var context = new LogContext();
        context.and(key, value);
        return context;
    }

    public static LogContext putAll(Map<String, String> map) {
        LogContext context = new LogContext();
        if (map != null) {
            map.forEach(context::and);
        }
        return context;
    }

    public LogContext and(String key, String value) {
        if (key != null && value != null) {
            MDC.put(key, value);
            keys.add(key);
        }
        return this;
    }

    @Override
    public void close() {
        keys.forEach(MDC::remove);
    }

}