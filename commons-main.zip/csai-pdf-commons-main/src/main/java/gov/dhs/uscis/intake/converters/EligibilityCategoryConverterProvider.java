package gov.dhs.uscis.intake.converters;

import java.util.Map;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.utils.ImmutableMap;

public final class EligibilityCategoryConverterProvider implements AttributeConverterProvider {
 private final Map<EnhancedType<?>, AttributeConverter<?>> converterCache = ImmutableMap.of(
         EnhancedType.of(EligibilityCategoryEnum.class), new EligibilityCategoryConverter());

 public static EligibilityCategoryConverterProvider create() {
     return new EligibilityCategoryConverterProvider();
 }

 @SuppressWarnings("unchecked")
 @Override
 public <T> AttributeConverter<T> converterFor(EnhancedType<T> enhancedType) {
     return (AttributeConverter<T>) converterCache.get(enhancedType);
 }
}