package gov.dhs.uscis.intake.models.validation;

import java.util.List;

import lombok.Builder;

@Builder
public record ValidationStatusResponse(
    ValidationStatusEnum status, 
    
    List<Validation> formValidations,
    List<Validation> evidenceValidations,
    ValidationDetails i912FeeWaiverValidation
    ) {
}
