package gov.dhs.uscis.intake.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum PFVSEvidenceType {

	I912("I-912", ValidatorEnum.I912, ToggleEnum.PFVS_I912, null), 
	I797C("Form-797c", ValidatorEnum.I797C, ToggleEnum.PFVS_797C, "I-797C"),
	I797("Form-797", ValidatorEnum.I797C, ToggleEnum.PFVS_797C, "I-797C"),
	E9089FD("ETA-9089FD", ValidatorEnum.E9089FD, null, null);

	private String type;
	private ValidatorEnum validator;
	private ToggleEnum toggle;
    private String pfvsFormTypeOverride;

	PFVSEvidenceType(String type, ValidatorEnum validator, ToggleEnum toggle, String pfvsFormTypeOverride) {
		this.type = type;
		this.validator = validator;
		this.toggle = toggle;
        this.pfvsFormTypeOverride = pfvsFormTypeOverride;
	}

	@JsonValue
	public String getType() {
		return type;
	}

	public ValidatorEnum getValidator() {
		return validator;
	}
	
	public ToggleEnum getToggle() {
		return toggle;
	}

    public String getPFVSFormTypeOverride() {
        return pfvsFormTypeOverride;
    }

	public static PFVSEvidenceType findByValidator(ValidatorEnum validator) {
		for (PFVSEvidenceType existing : PFVSEvidenceType.values()) {
			if (existing.getValidator().equals(validator)) {
				return existing;
			}
		}
		return null;
	}
	
	public static PFVSEvidenceType findByFormType(String type) {
		for (PFVSEvidenceType existing : PFVSEvidenceType.values()) {
			if (existing.getType().equals(type)) {
				return existing;
			}
		}
		return null;
	}

}
