package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.ActionRequested;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.eligibility.I129H1BEligibilitySubcategory;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I129H1BAdditionalInformation extends AdditionalInformation {

	private @Getter @Setter ActionRequested actionRequested;
    private @Getter @Setter I129H1BEligibilitySubcategory immigrationClassCode;
	private @Getter @Setter Boolean isCapGap;
	private @Getter @Setter Boolean isCapEnabled;

    public I129H1BAdditionalInformation() {
    	this.formType = FormType.I129H1B.getType();
    }
}
