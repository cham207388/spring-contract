package gov.dhs.uscis.intake.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
@ToString
public class SubmissionSummary {
  @Getter(onMethod_ = { @DynamoDbPartitionKey })
  String submissionId;
  @Getter(onMethod_ = { @DynamoDbSecondaryPartitionKey(indexNames = { "summary_by_manifestId" }) })
  String manifestId;
}
