package gov.dhs.uscis.intake.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.models.form.metadata.FeeWaiverMetaData;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

@Service
public class FeeWaiverService {

    private static Logger logger = LoggerFactory.getLogger(FeeWaiverService.class);
    DynamoDbTable<FeeWaiverMetaData> feeWaiverTable;

    public FeeWaiverService(DynamoDbTable<FeeWaiverMetaData> feeWaiverTable) {
        this.feeWaiverTable = feeWaiverTable;
    }

    public FeeWaiverMetaData retrieveFeeWaiverMetaData(String feeWaiverType) {
        logger.info(String.format("Fee Waiver: %s", feeWaiverType));

        Key key = Key.builder().partitionValue(AttributeValue.fromS(feeWaiverType)).build();
        GetItemEnhancedRequest request = GetItemEnhancedRequest.builder().key(key).build();
        return feeWaiverTable.getItem(request);
    }
}
