package gov.dhs.uscis.intake.constants;

public class DocumentType {
    /** Allowed document types for fee waiver */
    public class FeeWaiver {
        private FeeWaiver(){}
        
        public static final String FORM_I912 = "I-912";
        public static final String FEE_DECLARATION = "Fee Declaration";
    }
}
