package gov.dhs.uscis.intake.models.submission.form_specific_info;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class I360FormSpecificInfo extends FormSpecificInfo {

    public I360FormSpecificInfo() {
         super(FormType.I360);
    }

}