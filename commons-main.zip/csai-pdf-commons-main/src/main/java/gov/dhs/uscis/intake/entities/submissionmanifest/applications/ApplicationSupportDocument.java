package gov.dhs.uscis.intake.entities.submissionmanifest.applications;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@SuppressWarnings("serial")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class ApplicationSupportDocument implements Serializable {
    String supportId;
    String category;
    List<ApplicationFile> files;
}
