package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I907AdditionalInformation extends AdditionalInformation {
    private @Getter @Setter String relatedFormType;
    private @Getter @Setter String underlyingPetitionReceiptNumber;

    public I907AdditionalInformation() {
        this.formType = FormType.I907.getType();
    }
}
