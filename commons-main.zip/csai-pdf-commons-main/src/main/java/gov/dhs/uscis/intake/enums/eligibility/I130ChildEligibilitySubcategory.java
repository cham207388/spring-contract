package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I130ChildEligibilitySubcategory implements EligibilitySubcategoryEnum {
	CHILD_MARRIED("CHILD_MARRIED"), 
	CHILD_STEPPARENT("CHILD_STEPPARENT"),
	CHILD_NOT_MARRIED("CHILD_NOT_MARRIED"),
	CHILD_ADOPTED("CHILD_ADOPTED")
	;

	private @Getter String category;

	I130ChildEligibilitySubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}

}
