package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.ActionRequested;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.eligibility.I129EEligibilitySubcategory;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I129EAdditionalInformation extends AdditionalInformation {

	private @Getter @Setter ActionRequested actionRequested;
    private @Getter @Setter I129EEligibilitySubcategory immigrationClassCode;

    public I129EAdditionalInformation() {
    	this.formType = FormType.I129E.getType();
    }
}
