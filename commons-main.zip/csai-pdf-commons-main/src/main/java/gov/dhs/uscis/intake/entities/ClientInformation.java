package gov.dhs.uscis.intake.entities;

import java.util.List;

import gov.dhs.uscis.intake.models.core.Name;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@DynamoDbBean
@ToString
public class ClientInformation {

    @Getter(onMethod_ = { @DynamoDbSecondaryPartitionKey(indexNames = { "by_clientId" }) })
    private String clientId;
    private String attorneyId;
    @Getter(onMethod_ = { @DynamoDbPartitionKey })
    private String submissionId;
    private Name name;
    private List<String> userGroupIds;
}
