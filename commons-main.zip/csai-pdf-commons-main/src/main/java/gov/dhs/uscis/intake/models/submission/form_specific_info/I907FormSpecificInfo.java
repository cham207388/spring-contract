package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class I907FormSpecificInfo extends FormSpecificInfo {
    @JsonProperty("underlyingPetitionReceiptNumber")
    private String underlyingPetitionReceiptNumber;

    public I907FormSpecificInfo(String underlyingPetitionReceiptNumber) {
        super(FormType.I907);
        this.underlyingPetitionReceiptNumber = underlyingPetitionReceiptNumber;
    }
        public I907FormSpecificInfo() {
        super(FormType.I907);
    }
}