package gov.dhs.uscis.intake.entities.submissionmanifest;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@SuppressWarnings("serial")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class Manifest implements Serializable {
    String manifestId;
    String submissionDate;
    java.math.BigDecimal feeTotal;
    List<Application> applications;
}
