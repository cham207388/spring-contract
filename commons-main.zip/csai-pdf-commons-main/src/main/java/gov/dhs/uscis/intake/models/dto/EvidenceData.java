package gov.dhs.uscis.intake.models.dto;

import java.util.Map;

import lombok.Builder;

import gov.dhs.uscis.intake.models.core.metadata.EvidencePages;

@Builder
public record EvidenceData (Map<String, EvidencePages> evidencePages) {
}
