package gov.dhs.uscis.intake.converters;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

public final class EligibilitySubCategoryListConverter implements AttributeConverter<List<EligibilitySubcategoryEnum>> {

	@Override
	public AttributeValue transformFrom(List<EligibilitySubcategoryEnum> subCategoryList) {
        if (subCategoryList == null) {
            return AttributeValue.builder().l(Collections.emptyList()).build();
        }
		return AttributeValue.builder()
            .l(subCategoryList.stream().map(subCategory -> AttributeValue.builder().s(subCategory.getCategory()).build())
            .collect(Collectors.toList()))
            .build();
	}

	@Override
	public List<EligibilitySubcategoryEnum> transformTo(AttributeValue attributeValue) {
		if (attributeValue.l() == null) {
			return Collections.emptyList();
		}
		return attributeValue.l().stream()
		.map(av -> EligibilitySubcategoryEnum.fromString(av.s()))
		.collect(Collectors.toList());
	}

	@Override
	public EnhancedType<List<EligibilitySubcategoryEnum>> type() {
		return EnhancedType.listOf(EligibilitySubcategoryEnum.class);
	}

	@Override
	public AttributeValueType attributeValueType() {
		return AttributeValueType.L;
	}
}
