package gov.dhs.uscis.intake.models.dto;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ResidencyStatus;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.models.LockboxStatuses;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import lombok.Builder;

@Builder
public record SubmissionDto(
        String myUscisId,
        String submissionId,
        FormType formType,
        String formName,
        EligibilityCategoryEnum eligibilityCategory,
        EligibilitySubcategoryEnum eligibilitySubcategory,
        List<EligibilitySubcategoryEnum> eligibilitySubcategories,
        Integer benefitTypeCode,
        Integer applicationReasonCode,
        String manifestId,
        SubmissionState status,
        LockboxStatuses lockboxStatus,
        List<ManifestError> lockboxErrors,
        BigDecimal feeTotal,
        ZonedDateTime timestamp,
        ZonedDateTime updatedAt,
        ZonedDateTime expireDate,
        ZonedDateTime submittedAt,
        List<SubmissionFormDto> forms,
        List<SubmissionEvidenceDto> evidences,
        SubmissionEvidenceDto feeWaiver,
        Boolean userRequestedFeeWaiver,
        Boolean userRequestedPartialFeeWaiver,
        Boolean userIsEligibleForFeeWaiver,
        Boolean attested,
        Boolean hasReviewedSignature,
        ZonedDateTime attestedAt,
        String attestationSignature,
        Boolean immvi,
        String reasonForFiling,
        UserInformation applicant,
        ClientInformation clientInformation,
        C9UpdateRequest c9UpdateRequest,
        ResidencyStatus isUSCitizen,
        FormSpecificInfo formSpecificInfo,
        String orgMyUscisId,
        Boolean sentNotification,
        List<FormType> selectedConcurrentForms
        ) {
}