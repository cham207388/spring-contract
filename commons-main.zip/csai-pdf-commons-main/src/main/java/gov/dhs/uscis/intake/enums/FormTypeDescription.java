package gov.dhs.uscis.intake.enums;

public enum FormTypeDescription {

 G28("Notice of Entry of Appearance as Attorney or Accredited Representative"),
 I765("Application for Employment Authorization"),
 I131("Application for Travel Documents, Parole Documents, and Arrival/Departure Records"),
 I130("Petition for Alien Relative"),
 N400("Application for Naturalization"),
 I751("Petition to Remove Conditions on Residence");


 private String description;

 FormTypeDescription(String description) {
  this.description = description;
 }

 public String getDescription() {
  return description;
 }
}
