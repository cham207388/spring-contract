package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I130ChildEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I130ParentEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I130SiblingEligibilitySubcategory;
import lombok.Getter;

public enum I130EligibilityCategory implements PFVSEligibilityCategoryEnum {
	PETITION_FOR_PARENT("PETITION_FOR_PARENT", Arrays.asList(I130ParentEligibilitySubcategory.values())),
	PETITION_FOR_SIBLING("PETITION_FOR_SIBLING", Arrays.asList(I130SiblingEligibilitySubcategory.values())),
	PETITION_FOR_CHILD("PETITION_FOR_CHILD", Arrays.asList(I130ChildEligibilitySubcategory.values())),
	PETITION_FOR_SPOUSE("PETITION_FOR_SPOUSE", Arrays.asList());

	private @Getter String category;
	private @Getter List<EligibilitySubcategoryEnum> subcategories;
	
	I130EligibilityCategory(String category, List<EligibilitySubcategoryEnum> subCategories) {
		this.category = category;
		this.subcategories = subCategories;
		EligibilityCategoryRegistry.register(this);
	}

}
