package gov.dhs.uscis.intake.models.validation.name_extract;

import org.springframework.util.StringUtils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
@ToString
public class ClientName {
    private String givenName;
    private String familyName;

    @Override
    public boolean equals(Object otherObject) {

        if (super.equals(otherObject)) {
            return true;
        }

        if (!(otherObject instanceof ClientName)) {
            return false;
        }

        ClientName otherClientName = (ClientName) otherObject;
        return equalsIgnoreCaseNullSafe(otherClientName.getGivenName(), getGivenName())
                && equalsIgnoreCaseNullSafe(otherClientName.getFamilyName(), getFamilyName());
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    private boolean equalsIgnoreCaseNullSafe(String s1, String s2) {
        if (null == s1 && null == s2) return true;
        if (null == s1 || null == s2) return false;
        return sanitize(s1).equalsIgnoreCase(sanitize(s2));
    }


    private String sanitize(String value) { return value.replace(" ", "");}

    public boolean hasMissingNamePart() {
        return !StringUtils.hasText(getFamilyName()) || !StringUtils.hasText(getGivenName());
    }

}
