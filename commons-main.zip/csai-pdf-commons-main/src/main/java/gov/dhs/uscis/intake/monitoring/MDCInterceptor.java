package gov.dhs.uscis.intake.monitoring;

import java.util.UUID;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

public class MDCInterceptor implements HandlerInterceptor {
    private static final Logger logger = LoggerFactory.getLogger(MDCInterceptor.class);

    private String correlationIdHeader;

    public MDCInterceptor(String correlationIdHeader) {
        super();
        this.correlationIdHeader = correlationIdHeader;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String tracer = null;
        if (correlationIdHeaderIsDefined()) {
            if (containsCorrelationId(request)) {
                tracer = readCorrelationIdFromRequest(request);
            } else {
                tracer = UUID.randomUUID().toString();
            }
        }
        MDC.put("TRACER", tracer);
        logger.info("Trigger logging for request URI: {}", request.getRequestURI());
        return true;
    }

    private boolean correlationIdHeaderIsDefined() {
        return StringUtils.isNotBlank(correlationIdHeader);
    }

    private boolean containsCorrelationId(HttpServletRequest request) {
        return StringUtils.isNotBlank(request.getHeader(correlationIdHeader));
    }

    private String readCorrelationIdFromRequest(HttpServletRequest request) {
        return request.getHeader(correlationIdHeader);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
        logger.info("Ending request: {}", request.getRequestURI());
        MDC.remove("TRACER");
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
    }
}
