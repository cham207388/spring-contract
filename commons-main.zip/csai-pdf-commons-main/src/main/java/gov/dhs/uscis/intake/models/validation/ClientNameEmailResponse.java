package gov.dhs.uscis.intake.models.validation;

import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.validation.name_extract.ClientName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ClientNameEmailResponse {
  private String formId;
  private String myUscisId;
  private String submissionId;
  private ValidatorEnum validator;
  private ClientName clientName;
  private String email;
}