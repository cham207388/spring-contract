package gov.dhs.uscis.intake.entities.submissionmanifest.statuses;

import java.io.Serializable;
import java.util.List;

import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@SuppressWarnings("serial")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean
public class ManifestStatus implements Serializable {
    StatusEnum status;
    List<ManifestError> errors;
}
