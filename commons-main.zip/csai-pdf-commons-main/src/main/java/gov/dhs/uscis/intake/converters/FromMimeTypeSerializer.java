package gov.dhs.uscis.intake.converters;

import java.io.IOException;

import org.springframework.util.MimeType;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public final class FromMimeTypeSerializer extends JsonSerializer<MimeType>{

    @Override
    public void serialize(MimeType value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        gen.writeString(value.toString());
    }
    
}
