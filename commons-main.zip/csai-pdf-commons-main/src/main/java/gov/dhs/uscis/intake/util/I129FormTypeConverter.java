package gov.dhs.uscis.intake.util;

import java.util.Set;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.experimental.UtilityClass;

@UtilityClass
public class I129FormTypeConverter {

    public static String fromFormType(String formType){
        Set<String> supportedFormTypes = Set.of(FormType.I129H1B.getType());

        if(supportedFormTypes.contains(formType)) return "I-129 H1B";
        return formType;
    }

    public static String toFormEnum(String formType){
        Set<String> supportedFormTypes = Set.of("I-129 H1B", "I-129");

        if(supportedFormTypes.contains(formType)) return FormType.I129H1B.getType();
        return formType;
    }

}
