package gov.dhs.uscis.intake.models.dto;

import java.time.ZonedDateTime;

import lombok.Builder;

@Builder
public record SubmissionEvidenceDto(
    String type,
    String evidenceGroupType,
    String id,
    String formId,
    String name,
    String md5Hash,
    ZonedDateTime uploadedAt,
    Boolean isEditable
) {}
