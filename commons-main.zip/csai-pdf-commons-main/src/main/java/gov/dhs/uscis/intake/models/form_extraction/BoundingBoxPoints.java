package gov.dhs.uscis.intake.models.form_extraction;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.services.textract.model.BoundingBox;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class BoundingBoxPoints {
  Float top;
  Float bottom;
  Float left;
  Float right;

  public boolean isValid() {
    return !(top == null || bottom == null || left == null || right == null);
  }

  public boolean isEnclosing(BoundingBox bounds) {
    Float midYPoint = bounds.top() + (bounds.height() / 2);
    Float midXPoint = bounds.left() + (bounds.width() / 2);

    return midYPoint > top &&
      midYPoint < bottom &&
      midXPoint > left &&
      midXPoint < right;
  }

  public boolean isIntersecting(BoundingBox bounds) {
      Float midpoint= bounds.top() + (bounds.height() / 2);
      log.info(String.format("%s", midpoint));
      return top <= midpoint && bottom >= midpoint;
  }

}