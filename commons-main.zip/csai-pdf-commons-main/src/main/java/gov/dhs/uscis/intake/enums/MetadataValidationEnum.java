package gov.dhs.uscis.intake.enums;

public enum MetadataValidationEnum {
    CORE,
    SIGNATURE,
    FORM_FIELDS,
    NOA,
    G28_COMP,
    G28_COMP_NAME,
    G28_NAME_EMAIL,
    G28_ATTORNEY_NAME,
    PFVS
}
