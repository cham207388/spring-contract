package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.RequestedAction;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I129H2AAdditionalInformation extends AdditionalInformation {
    
	private @Getter @Setter RequestedAction requestedAction;
    
    public I129H2AAdditionalInformation() {
    	this.formType = FormType.I129H2A.getType();
    }
}
