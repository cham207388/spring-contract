package gov.dhs.uscis.intake.models.user_group;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserGroupResponse {

    private UserGroupRoleData data;
}