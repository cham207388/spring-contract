package gov.dhs.uscis.intake.models;

public enum SubmissionProcessingStatusEnum {
    SUCCESS,
    FAILURE
}
