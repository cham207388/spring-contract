package gov.dhs.uscis.intake.enums;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

@SuppressWarnings("java:S1201")
public enum FormType {

	G28("G-28", false, false),
	I765("I-765", false, false),
	I130("I-130", true, false),
	I140("I-140", true, false),
	I485("I-485", true, false),
	I485A("I-485A", true, false),
    I485J("I-485J", true, false),
	I131("I-131", true, false),
    I129R("I-129R", true, false),
	I751("I-751", true, false),
	I129H2A("I-129H2A", true, true),
	I129H1B("I-129H1B", true, false, "I-129 H1B"),
    I129TN("I-129TN", true, false),
    I129E3("I-129E3", true, false),
    I129H3("I-129H3", true, false),
    I129L("I-129L", true, false),
    I129OP("I-129OP", true, false),
    I129Q("I-129Q", true, false),
    I129S("I-129S", true, false),
    I129CW("I-129CW", true, false),
    I129H2B("I-129H2B", true, false),
	N400("N-400", false, false),
	I907("I-907", true, false),
	I129E("I-129E", true, false),
    I90("I-90", true, false),
    I539("I-539", true, false),
    I360("I-360", true, false);

	public static final Set<FormType> ORGANIZATION_FILED_FORM_TYPES = Collections.unmodifiableSet(EnumSet.of(FormType.I140, FormType.I129H1B, FormType.I129H2A, FormType.I907, FormType.I129E, FormType.I129R, FormType.I129TN, FormType.I129E3, FormType.I129H3, FormType.I129L, FormType.I129Q, FormType.I129OP, FormType.I129S, FormType.I129CW, FormType.I129H2B));

	private String type;
	private boolean pfvsSupported;
	private boolean autoIngested;
    private String lockboxType;
	private static final Map<String, FormType> FORM_TYPES = Stream.of(values())
			.collect(Collectors.toMap(t -> t.getType(), Function.identity()));

	FormType(String type, boolean pfvsSupported, boolean autoIngested) {
		this.type = type;
		this.pfvsSupported = pfvsSupported;
		this.autoIngested = autoIngested;
	}
    	FormType(String type, boolean pfvsSupported, boolean autoIngested, String lockboxType) {
		this.type = type;
		this.pfvsSupported = pfvsSupported;
		this.autoIngested = autoIngested;
        this.lockboxType = lockboxType;
	}

	@JsonValue
	public String getType() {       
		return type;
	}

	public boolean isPFVSSupported() {
		return pfvsSupported;
	}

	public boolean isAutoIngested() {
		return autoIngested;
	}
    public String getLockboxType() {
        return this.lockboxType;
    }

	@JsonCreator
	public static FormType fromString(String from) {
		return Optional.ofNullable(FORM_TYPES.get(from)).orElseThrow(() -> new IllegalArgumentException(from));
	}

    public static String convertForLockBox(String from) {
        return Optional.ofNullable(FORM_TYPES.get(from))
                .map(FormType::getLockboxType)
                .orElse(from);
    }
        public static FormType fromStringIgnoreSpace(String from) {
            if (from == null) return null;

            // Remove all whitespace to normalize (e.g., "I-129 H1B" -> "I-129H1B")
            String normalizedInput = from.replaceAll("\\s", "");

            // Use fromString to get the enum constant
            return FormType.fromString(normalizedInput);
        }

	public static Optional<FormType> fromStringOrNull(String from) {
		return Optional.ofNullable(FORM_TYPES.get(from));
	}

	public boolean equals(String formType) {
		return Objects.equals(type, formType);
	}
}
