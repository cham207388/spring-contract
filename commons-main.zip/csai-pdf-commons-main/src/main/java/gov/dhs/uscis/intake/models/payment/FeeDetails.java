package gov.dhs.uscis.intake.models.payment;

import java.math.BigDecimal;
import java.util.List;

import lombok.Builder;

@Builder
public record FeeDetails(
    BigDecimal amount,
    String eligibilityCategory,
    boolean isUnder14,
    List<String> formTypeList,
    PayGovClassification payGovClassification
){}
