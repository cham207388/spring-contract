package gov.dhs.uscis.intake.models;

import java.util.List;

import gov.dhs.uscis.intake.models.core.metadata.BetaBanner;
import gov.dhs.uscis.intake.models.core.metadata.PaygovMaintenance;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@DynamoDbBean
public class CoreMetaData {
    @Getter(onMethod_ = { @DynamoDbPartitionKey })
    String id;
    PaygovMaintenance paygovMaintenanceWindow;
    List<BetaBanner> betaBanners;
}