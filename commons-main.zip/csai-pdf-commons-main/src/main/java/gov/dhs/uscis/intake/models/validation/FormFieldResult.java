package gov.dhs.uscis.intake.models.validation;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonTypeInfo(use=JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.EXISTING_PROPERTY, property = "formType")
@JsonSubTypes({
  @JsonSubTypes.Type(value=N400FormFieldResult.class, name="N-400"),
  @JsonSubTypes.Type(value=I765FormFieldResult.class, name="I-765"),
  @JsonSubTypes.Type(value=I751FormFieldsResult.class, name="I-751")
})
public abstract class FormFieldResult {
  protected String formId;
  protected String submissionId;
  protected String myUscisId;
  protected String alienNumber;
  protected String dateOfBirth;
  protected ValidatorEnum validator;
  protected List<EligibilityCategoryEnum> selectedCategories;

  public abstract FormType getFormType();
}
