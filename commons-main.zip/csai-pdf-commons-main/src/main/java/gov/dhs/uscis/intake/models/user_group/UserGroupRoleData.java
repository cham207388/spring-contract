package gov.dhs.uscis.intake.models.user_group;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserGroupRoleData {
    private String userUuid;
    List<UserGroupRole> userGroupRoles;
}