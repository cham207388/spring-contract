package gov.dhs.uscis.intake.enums.eligibility;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public interface EligibilitySubcategoryEnum {

	@JsonValue
	String getCategory();

	@JsonCreator
	static EligibilitySubcategoryEnum fromString(String from) throws IllegalArgumentException {
		if (from == null) {
			return null;
		}

		EligibilitySubcategoryEnum result = EligibilitySubcategoryRegistry.REGISTRY.get(from);
		if (result == null) {
			throw new IllegalArgumentException("Unknown enum value: " + from);
		}
		return result;

	}

	static class EligibilitySubcategoryRegistry {

		private EligibilitySubcategoryRegistry() {}

		static final Map<String, EligibilitySubcategoryEnum> REGISTRY = new HashMap<>();

		static void register(EligibilitySubcategoryEnum el) {
			REGISTRY.put(el.getCategory(), el);
			REGISTRY.put(el.toString(), el); // For backward compatibility
		}
	}

}
