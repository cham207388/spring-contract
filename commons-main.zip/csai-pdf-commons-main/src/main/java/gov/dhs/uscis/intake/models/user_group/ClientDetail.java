package gov.dhs.uscis.intake.models.user_group;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonProperty;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClientDetail {
    @JsonProperty("clientName")
    private String clientName;
    @JsonProperty("clientType")
    private String clientType;
    @JsonProperty("clientGroupId")
    private String clientGroupId;
    @JsonProperty("collaborationGroupId")
    private String collaborationGroupId;
    @JsonProperty("lawFirmName")
    private String lawFirmName;
    @JsonProperty("applicantUuid")
    private String applicantUuid;
}
