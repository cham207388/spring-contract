package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ResidencyStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I130AdditionalInformation extends AdditionalInformation {
    private @Getter @Setter ResidencyStatus isUSCitizen;
    
    public I130AdditionalInformation() {
    	this.formType = FormType.I130.getType();
    }
}
