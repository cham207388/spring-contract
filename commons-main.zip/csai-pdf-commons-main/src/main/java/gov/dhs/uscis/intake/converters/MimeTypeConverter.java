package gov.dhs.uscis.intake.converters;

import org.springframework.util.MimeType;

import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

public class MimeTypeConverter implements AttributeConverter<MimeType> {

    @Override
    public AttributeValue transformFrom(MimeType input) {
        return AttributeValue.fromS(input.toString());
    }

    @Override
    public MimeType transformTo(AttributeValue input) {
        return MimeType.valueOf(input.s());
    }

    @Override
    public EnhancedType<MimeType> type() {
        return EnhancedType.of(MimeType.class);
    }

    @Override
    public AttributeValueType attributeValueType() {
        return AttributeValueType.S;
    }

}
