package gov.dhs.uscis.intake.enums;

public interface EligibilityValidator{
    boolean isValid( String category, String str );
}