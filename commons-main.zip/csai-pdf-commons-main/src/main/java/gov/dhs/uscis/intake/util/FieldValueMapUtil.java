package gov.dhs.uscis.intake.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import software.amazon.awssdk.services.textract.model.Block;
import software.amazon.awssdk.services.textract.model.BlockType;
import software.amazon.awssdk.services.textract.model.EntityType;
import software.amazon.awssdk.services.textract.model.Relationship;
import software.amazon.awssdk.services.textract.model.RelationshipType;
import software.amazon.awssdk.services.textract.model.SelectionStatus;


public class FieldValueMapUtil {

    private FieldValueMapUtil(){}

    public static String getUnitTypeFromKeyValues(Map<String, String> keyValuePairs, String pageNumber) {

      String steLookup = keyValuePairs.get(pageNumber + "-" + "STE");
      if(null != steLookup && !steLookup.isBlank())
      {
        return "Ste.";
      }

      String flrLookup = keyValuePairs.get(pageNumber + "-" + "FLR");
      if(null != flrLookup && !flrLookup.isBlank())
      {
        return "Flr.";
      }

      String aptLookup = keyValuePairs.get(pageNumber + "-" + "APT");
      if(null != aptLookup  && !aptLookup .isBlank())
      {
        return "Apt.";
      }

      return null;

    }

    public static Map<String, String> getKeyValueRelationShipByBlocks(List<Block> blocks) {
        Map<String, Map<String, Block>> keyValueBlockMap = getKeyValueBlockMap(blocks);
        return getKeyValueRelationShip(keyValueBlockMap);
    }

    private static Block findValueBlock(Block keyBlock, Map<String, Block> valueMap) {
        Block valueBlock = null;
        for (Relationship relationship : keyBlock.relationships()) {
            if (RelationshipType.VALUE.equals(relationship.type())) {
                for (String id : relationship.ids()) {
                    valueBlock = valueMap.get(id);
                    return valueBlock;
                }
            }
        }
        return valueBlock;
    }

    private static Map<String, String> getKeyValueRelationShip(Map<String, Map<String, Block>> keyValueBlockMap) {
        Map<String, String> keyValueRelationShip = new HashMap<>();
        Map<String, Block> keyMap = keyValueBlockMap.get("keyMap");
        Map<String, Block> valueMap = keyValueBlockMap.get("valueMap");
        Map<String, Block> blocksMap = keyValueBlockMap.get("blockMap");
        keyMap.forEach((blockId, keyBlock) -> {
            Block valueBlock = findValueBlock(keyBlock, valueMap);

            String key = getBlockText(keyBlock, blocksMap);
            key = key.replaceAll("[^a-zA-Z0-9]", "").toUpperCase();
            key = keyBlock.page() + "-" + key; 

            String val = getBlockText(valueBlock, blocksMap);
            val = val.strip();
            keyValueRelationShip.put(key, val);
        });
        return keyValueRelationShip;
    }

    private static String getBlockText(Block resultBlock, Map<String, Block> blocksMap) {
        StringBuilder blockText = new StringBuilder();
        List<Relationship> relationShips = resultBlock.relationships();
        if (relationShips != null) {
            for (Relationship relationship : relationShips) {
                if (RelationshipType.CHILD.equals(relationship.type())) {
                    // relationship.getIds().forEach(childId ->
                    for (String childId : relationship.ids()) {
                        Block wordBlock = blocksMap.get(childId);
                        //wordBlock.page();
                        if (BlockType.WORD.equals(wordBlock.blockType())) {
                            blockText.append(wordBlock.text())
                                    .append(" ");
                        }
                        if (BlockType.SELECTION_ELEMENT.equals(wordBlock.blockType())) {
                            if (SelectionStatus.SELECTED.equals(wordBlock.selectionStatus())) {
                                blockText.append("X ");
                            }
                        }
                    }
                }
            }
        }
        return blockText.toString();
    }

    private static Map<String, Map<String, Block>> getKeyValueBlockMap(List<Block> blocks) {
        Map<String, Map<String, Block>> keyValueBlockMap = new HashMap<>();
        Map<String, Block> keyMap = new HashMap<>();
        Map<String, Block> valueMap = new HashMap<>();
        Map<String, Block> blockMap = new HashMap<>();
        // for block in blocks:
        for (Block block : blocks) {
            String blockId = block.id();
            blockMap.put(blockId, block);
            if (BlockType.KEY_VALUE_SET.equals(block.blockType())) {
                if (block.entityTypes().contains(EntityType.KEY)) {
                    keyMap.put(blockId, block);
                } else {
                    valueMap.put(blockId, block);
                }
            }
        }
        keyValueBlockMap.put("keyMap", keyMap);
        keyValueBlockMap.put("valueMap", valueMap);
        keyValueBlockMap.put("blockMap", blockMap);
        return keyValueBlockMap;
    }
}
