package gov.dhs.uscis.intake.models.core;

import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@DynamoDbBean
public class Name {

    private String lastName;
    private String firstName;
    private String middleName;

    public Name (){}
    public Name(String firstName, String middleName, String lastName) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;

    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }



    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object otherObject) {

        if (otherObject == this) {
            return true;
        }

        if (!(otherObject instanceof Name)) {
            return false;
        }

        Name otherName = (Name) otherObject;
        return equalsIgnoreCaseNullSafe(otherName.getFirstName(), getFirstName())
                && equalsIgnoreCaseNullSafe(otherName.getLastName(), getLastName());
    }

    private boolean equalsIgnoreCaseNullSafe(String s1, String s2) {
        if (null == s1 || null == s2) {
            return false;
        }
        return sanitize(s1).equalsIgnoreCase(sanitize(s2));
    }

    private String sanitize(String value) {
        return value.replace(" ", "");
    }

}
