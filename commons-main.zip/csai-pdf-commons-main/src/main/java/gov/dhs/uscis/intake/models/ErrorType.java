package gov.dhs.uscis.intake.models;

public enum ErrorType {
    PAGE_ERROR("page"),
    PAGE_NUMBER_ERROR("pageNumber"),
    PAGE_ORDER_ERROR("pageOrder"),
    FORM_TYPE_ERROR("formType"),
    FORM_VERSION_ERROR("formVersion"),
    SIGNATURE_ERROR("signature"),
    BARCODE_ERROR("barcode"),
    UNEXPECTED_FORM_TYPE("formUnsupported"),
    UNSUPPORTED_FORM_EDITION_ERROR("formEditionUnsupported"),
    TOTAL_PAGE_NUMBER_ERROR("totalPageNumberError"),
    A_NUMBER_ERROR("aNumberError"),
    DOB_ERROR("dateOfBirthError");

    private String name;

    ErrorType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
