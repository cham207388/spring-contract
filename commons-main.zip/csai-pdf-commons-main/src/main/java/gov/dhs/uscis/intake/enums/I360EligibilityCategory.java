package gov.dhs.uscis.intake.enums;

import lombok.Getter;

public enum I360EligibilityCategory implements EligibilityCategoryEnum {
    ABUSED_SPOUSE("ABUSED_SPOUSE"),
    ABUSED_CHILD("ABUSED_CHILD"),
    ABUSED_PARENT("ABUSED_PARENT");

    private @Getter String category;

    I360EligibilityCategory(String category) {
        this.category = category;
        EligibilityCategoryRegistry.register(this);
    }

    @Override
    public String getCategory() {
        return category;
    }
}
