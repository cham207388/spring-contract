package gov.dhs.uscis.intake.converters;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeValueType;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

public final class EligibilitySubcategoryConverter implements AttributeConverter<EligibilitySubcategoryEnum> {

	@Override
	public AttributeValue transformFrom(EligibilitySubcategoryEnum input) {
		return AttributeValue.fromS(input.getCategory());
	}

	@Override
	public EligibilitySubcategoryEnum transformTo(AttributeValue input) {
		return EligibilitySubcategoryEnum.fromString(input.s());
	}

	@Override
	public EnhancedType<EligibilitySubcategoryEnum> type() {
		return EnhancedType.of(EligibilitySubcategoryEnum.class);
	}

	@Override
	public AttributeValueType attributeValueType() {
		return AttributeValueType.S;
	}

}
