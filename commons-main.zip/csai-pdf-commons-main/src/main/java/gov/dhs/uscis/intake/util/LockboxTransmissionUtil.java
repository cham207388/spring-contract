package gov.dhs.uscis.intake.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import gov.dhs.uscis.intake.constants.DocumentType;
import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Application;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.AdditionalInfo;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.ApplicationFile;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.ApplicationSupportDocument;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.ManifestStatus;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.intake.models.dto.LockboxForm;
import gov.dhs.uscis.intake.models.dto.LockboxSubmission;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;

public class LockboxTransmissionUtil {

    private LockboxTransmissionUtil() {
    }

    private static LockboxForm lockboxFormFromSubmissionForm(SubmissionForm submissionForm) {
        if (submissionForm == null) {
            return null;
        }

        return LockboxForm.builder()
                .type(submissionForm.getType())
                .id(submissionForm.getId())
                .url(submissionForm.getUrl())
                .name(submissionForm.getName())
                .md5Hash(submissionForm.getMd5Hash())
                .rejectionReasons(submissionForm.getRejectionReasons())
                .build();
    }

    public static LockboxTransmission lockboxTransmissionFromSubmission(Submission submission) {

        SubmissionForm primaryForm = submission.getForms().stream()
                .filter(form -> submission.getFormType().equals(form.getType())).findFirst().orElse(null);
        List<SubmissionForm> additionalForms = submission.getForms().stream()
                .filter(form -> !submission.getFormType().equals(form.getType())).toList();

        LockboxForm primaryLockboxForm = lockboxFormFromSubmissionForm(primaryForm);

        Function<SubmissionForm, LockboxForm> submissionFormConverter = LockboxTransmissionUtil::lockboxFormFromSubmissionForm;
        List<LockboxForm> additionalLockboxForms = additionalForms.stream().map(submissionFormConverter)
                .collect(Collectors.toList());

        List<SubmissionEvidence> evidences = new ArrayList<>();
        if (submission.getEvidences() != null)
            evidences.addAll(submission.getEvidences());

        if (submission.getFeeWaiver() != null &&
                Boolean.TRUE.equals(submission.getUserRequestedFeeWaiver()) &&
                !Boolean.TRUE.equals(submission.getUserRequestedPartialFeeWaiver())) {
            SubmissionEvidence feeWaiver = submission.getFeeWaiver();
            feeWaiver.setType(DocumentType.FeeWaiver.FORM_I912);
            evidences.add(feeWaiver);
        }
        evidences = MapEvidenceTypes.mapEOIRBIAEvidenceList(evidences);
        LockboxSubmission lockboxSubmission = LockboxSubmission.builder()
                .submissionId(submission.getSubmissionId())
                .feeWaiver(submission.getUserRequestedFeeWaiver())
                .feeTotal(submission.getFeeTotal())
                .lockboxStatus(StatusEnum.RECEIVED)

                .primaryForm(primaryLockboxForm)
                .additionalForms(additionalLockboxForms)

                .evidences(evidences)

                .build();

        return LockboxTransmission.builder()
                .myUscisId(submission.getMyUscisId())
                .submission(lockboxSubmission)
                .build();

    }

    public static SubmissionManifest submissionManifestFromLockboxTransmission(LockboxTransmission lockboxTransmission,
            String manifestId) {
        LockboxSubmission lockboxSubmission = lockboxTransmission.getSubmission();
        LockboxForm lockboxForm = lockboxSubmission.getPrimaryForm();
        List<LockboxForm> additionalForms = lockboxSubmission.getAdditionalForms();

        List<AdditionalInfo> additionalInfo = List.of(
                AdditionalInfo.builder()
                        .name("feeWaiverRequested")
                        .value(lockboxSubmission.getFeeWaiver().toString())
                        .build());

        ManifestStatus manifestStatus = ManifestStatus.builder()
                .status(StatusEnum.PUBLISHED)
                .errors(Collections.emptyList())
                .build();

        ApplicationStatus applicationStatus = ApplicationStatus.builder()
                .uscisId(lockboxSubmission.getSubmissionId())
                .formType(I129FormTypeConverter.fromFormType(lockboxForm.getType()))
                // .formType(lockboxForm.getType())
                .status(lockboxSubmission.getLockboxStatus())
                .rejectionReasons(lockboxForm.getRejectionReasons())
                .build();

        SubmissionStatus submissionStatus = SubmissionStatus.builder()
                .uscisId(manifestId)
                .status(lockboxSubmission.getLockboxStatus())
                .totalCost(lockboxSubmission.getFeeTotal())
                .applicationStatuses(List.of(applicationStatus))
                .build();

        Statuses statuses = Statuses.builder()
                .manifestStatus(manifestStatus)
                .submissionStatus(submissionStatus)
                .build();

        ApplicationFile file = ApplicationFile.builder()
                .order(1)
                .id(lockboxForm.getId())
                .name(lockboxForm.getName())
                .uri(lockboxForm.getUrl())
                .md5Hash(lockboxForm.getMd5Hash())
                .build();

        List<SubmissionEvidence> submissionEvidenceList = lockboxSubmission.getEvidences();
        Map<String, List<SubmissionEvidence>> groupedEvidence = submissionEvidenceList == null ? Map.of()
                : submissionEvidenceList.stream()
                        .collect(Collectors.groupingBy(SubmissionEvidence::getType));
        List<ApplicationSupportDocument> supportDocuments = new ArrayList<>();
        groupedEvidence.forEach(
                (type, evidences) -> supportDocuments.add(ApplicationSupportDocument
                        .builder()
                        .category(type)
                        .supportId(UUID.randomUUID().toString())
                        .files(evidences.stream().map((evidence) -> ApplicationFile.builder()
                                .order(evidences.indexOf(evidence) + 1)
                                .id(evidence.getId())
                                .name(evidence.getName())
                                .uri(evidence.getUrl())
                                .md5Hash(evidence.getMd5Hash())
                                .build())
                                .toList())
                        .build()));

        Application primaryApplication = Application.builder()
                .formType(I129FormTypeConverter.fromFormType(lockboxForm.getType()))
                .submissionId(String.format("%s-%s", I129FormTypeConverter.fromFormType(lockboxForm.getType()),
                                lockboxSubmission.getSubmissionId()))
                .files(List.of(file))
                .supportDocuments(supportDocuments)
                .additionalInfo(additionalInfo)
                .build();

        List<Application> additionalApplications = additionalForms.stream()
                .map((additionalForm) -> Application.builder()
                        .formType(additionalForm.getType())
                        .submissionId(String.format("%s-%s", I129FormTypeConverter.fromFormType(additionalForm.getType()),
                                lockboxSubmission.getSubmissionId()))
                        .files(List.of(
                                ApplicationFile.builder()
                                        .order(1)
                                        .id(additionalForm.getId())
                                        .name(additionalForm.getName())
                                        .uri(additionalForm.getUrl())
                                        .md5Hash(additionalForm.getMd5Hash())
                                        .build()))
                        .supportDocuments(List.of())
                        .additionalInfo(List.of())
                        .build())
                .toList();

        List<Application> applications = new ArrayList<>(List.of(primaryApplication));
        applications.addAll(additionalApplications);

        Manifest manifest = Manifest.builder()
                .manifestId(manifestId)
                .submissionDate(getFormattedDate())
                .feeTotal(lockboxTransmission.getSubmission().getFeeTotal())
                .applications(applications)

                .build();

        return SubmissionManifest.builder()
                .myUscisId(lockboxTransmission.getMyUscisId())
                .submissionId(lockboxSubmission.getSubmissionId())
                .manifestId(manifestId)
                .statuses(statuses)
                .manifest(manifest)
                .build();
    }

    public static String getFormattedDate() {
        LocalDate date = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        return date.format(formatter);
    }

}
