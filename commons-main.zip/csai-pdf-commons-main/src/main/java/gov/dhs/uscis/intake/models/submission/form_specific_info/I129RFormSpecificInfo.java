package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.ActionRequested;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.submission.form_specific_info.interfaces.ActionRequestedProvider;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class I129RFormSpecificInfo extends FormSpecificInfo implements ActionRequestedProvider {

    @JsonProperty("actionRequested")
	private ActionRequested actionRequested;

    public I129RFormSpecificInfo(ActionRequested actionRequested) {
        super(FormType.I129R);
        this.actionRequested = actionRequested;
    }
        public I129RFormSpecificInfo() {
            super(FormType.I129R);
    }
}