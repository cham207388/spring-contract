package gov.dhs.uscis.intake.converters;

import java.util.Map;

import org.springframework.util.MimeType;

import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.enhanced.dynamodb.internal.converter.attribute.ListAttributeConverter;
import software.amazon.awssdk.utils.ImmutableMap;

public final class MimeTypeConverterProvider implements AttributeConverterProvider {
    private final Map<EnhancedType<?>, AttributeConverter<?>> converterCache = ImmutableMap.of(
            EnhancedType.of(MimeType.class), new MimeTypeConverter(), 
            EnhancedType.listOf(MimeType.class), ListAttributeConverter.create(new MimeTypeConverter()));

    public static MimeTypeConverterProvider create() {
        return new MimeTypeConverterProvider();
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> AttributeConverter<T> converterFor(EnhancedType<T> enhancedType) {
        return (AttributeConverter<T>) converterCache.get(enhancedType);
    }
}