package gov.dhs.uscis.intake.models;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResult;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ValidationStatus {
    @Getter(onMethod_ = {@DynamoDbPartitionKey})
    private String formId;
    private String submissionId;
    private ValidationResultEnum status;
    @Getter(onMethod_ = {@DynamoDbSortKey})
    private ValidatorEnum validator;
    private List<String> failureReasons;
    private Map<String, String> validationWarnings; 
    private String messageId;
    private boolean isMultipart;

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ValidationStatus other = (ValidationStatus) obj;
        if (formId == null) {
            if (other.formId != null)
                return false;
        } else if (!formId.equals(other.formId))
            return false;
        if (submissionId == null) {
            if (other.submissionId != null)
                return false;
        } else if (!submissionId.equals(other.submissionId))
            return false;
        if (status != other.status)
            return false;
        if (validator != other.validator)
            return false;
        if (failureReasons == null) {
            if (other.failureReasons != null)
                return false;
        } else if (!failureReasons.equals(other.failureReasons))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((formId == null) ? 0 : formId.hashCode());
        result = prime * result + ((submissionId == null) ? 0 : submissionId.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((validator == null) ? 0 : validator.hashCode());
        result = prime * result + ((failureReasons == null) ? 0 : failureReasons.hashCode());
        return result;
    }

    public static ValidationStatus fromResult(ValidationStatusResult result) {
        return ValidationStatus.builder()
                .formId(result.formId())
                .submissionId(result.submissionId())
                .status(result.status())
                .validator(result.validator())
                .isMultipart(result.isMultipart())
                .failureReasons(result.failureReasons().stream().flatMap(reasons -> reasons.values().stream())
                        .collect(Collectors.toList())).validationWarnings(result.validationWarnings())
                .build();
    }
}
