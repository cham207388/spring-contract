package gov.dhs.uscis.intake.models;

import java.util.List;
import java.util.Map;

import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.models.form.metadata.EligibilityCategory;
import gov.dhs.uscis.intake.models.form.metadata.ErrorMap;
import gov.dhs.uscis.intake.models.form.metadata.FormEdition;
import gov.dhs.uscis.intake.models.form.metadata.Pages;
import gov.dhs.uscis.intake.models.form.metadata.SignaturePageMetadata;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

@Data
@Builder
@DynamoDbBean
@AllArgsConstructor
@NoArgsConstructor
public class FormMetaData {
    @Getter(onMethod_ = { @DynamoDbPartitionKey })
    String formType;
    String formDescription;
    Boolean showBanner;
    Boolean enabled;
    Boolean feeWaiverEnabled;
    Boolean elisEsignFlowEnabled;
    String currentEdition;
    Boolean representativeEnabled;
    List<SignaturePageMetadata> signaturePages;
    List<FormEdition> editions;
    List<MetadataValidationEnum> validations;
    List<EligibilityCategory> eligibilityCategories;
    Pages pages;
    Map<String, Integer> landmarks;
    List<ErrorMap> errorMap;
    Map<String, Integer> fees;
    List<String> concurrentFormTypes;
}
