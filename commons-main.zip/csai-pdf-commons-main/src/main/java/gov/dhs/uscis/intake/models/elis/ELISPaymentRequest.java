package gov.dhs.uscis.intake.models.elis;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ELISPaymentRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private List<String> refIds;
	private String emailAddress;
	@JsonProperty(value="isNew")
	private boolean isNew;
	private String trackingId;
	private String benefitId;
	private BigDecimal payableFee;
	private ELISPayment payment;

}
