package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I131InitialParoleEligibilitySubcategory implements EligibilitySubcategoryEnum {
	FWVP_I130("FWVP_I130"), 
	IMMVI_MEMBER("IMMVI_MEMBER"),
	IMMVI_DEPENDENT("IMMVI_DEPENDENT"), 
	IMMVI_GUARDIAN("IMMVI_GUARDIAN"),
	INTERGOVERNMENTAL_PAROLE_REFERRAL("INTERGOVERNMENTAL_PAROLE_REFERRAL"), 
	FRTF("FRTF"),
	OTHER("OTHER"), 
	NON_SPECIFIC("NON_SPECIFIC");

	private @Getter String category;

	I131InitialParoleEligibilitySubcategory(String category) {
		this.category = category;
		EligibilitySubcategoryRegistry.register(this);
	}

}
