package gov.dhs.uscis.intake.models.form.metadata;

import java.util.List;

import gov.dhs.uscis.intake.models.EvidenceGroup;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@Builder
@DynamoDbBean
@AllArgsConstructor
@NoArgsConstructor
public class MetaData {
    boolean feeWaivable;
    boolean feeExemptable;
    List<EvidenceGroup> evidenceGroups;
    List<FeeExemptQuestion> feeExemptQuestions;
    String subCategoryHeader;
    List<EligibilitySubcategory> subcategories;
    boolean disabled;
    List<String> roleTypes;
    List<String> excludeForParentFormTypes;
}
