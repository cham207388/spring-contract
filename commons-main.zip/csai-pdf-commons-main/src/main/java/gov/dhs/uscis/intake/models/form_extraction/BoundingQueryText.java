package gov.dhs.uscis.intake.models.form_extraction;

public record BoundingQueryText(String top, String bottom, String left, String right) {}
