package gov.dhs.uscis.intake.clients;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.models.core.ClientAssociation;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserGroupServiceClient {

    private ReactiveUserGroupServiceClient client;

    public UserGroupServiceClient(ReactiveUserGroupServiceClient client) {
        this.client = client;
    }

    public ClientAssociation isClientAssociated(String icamUUID, String applicantUuid) {
        // return true if the client is associated, or false if not
        String truncatedMyUscisId = icamUUID.substring(0, 8);

        log.info("Looking up if applicant ...{} is associated with rep ...{}.", applicantUuid.substring(0, 8),
                truncatedMyUscisId);

        try {
            return client.isClientAssociated(icamUUID, applicantUuid)
                    .block();
        } catch (Exception ex) {
            log.error("Error fetching relative clients for {}.", icamUUID,
                    ex);
            throw ex;
        }
    }


    public UserGroupRole getRepGroupId(String icamUUID) {
        log.info("Looking up rep lawfirm id for rep: {}", icamUUID);

        try {
            return client.getRepGroupId(icamUUID).block();

        } catch (Exception ex) {
            log.error("Error fetching rep user group roles for rep ...{}.", icamUUID, ex);
            return null;
        }
    }

    public ClientInformation inviteClient(String attorneyId, String attorneyUserGroupId, String submissionId,
            String emailAddress, Name name) {
        log.info("About to invite email address {} to connect with rep {} in user group: {}", emailAddress, attorneyId,
                attorneyUserGroupId);

        return client.inviteClient(attorneyId, attorneyUserGroupId, submissionId, emailAddress, name).block();
    }

    public UserGroupRole getOrganizationGroupRole(String icamUUID) {
    	return client.getOrganizationGroupRole(icamUUID).block();
    }
    public Boolean isUserPartOfOrg(String icamUUID) {
        return client.isPartOfUserOrg(icamUUID).block();
    }
}
