package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Getter
@Setter
public class I485FormSpecificInfo extends FormSpecificInfo {
    @JsonProperty("isMilitaryVeteran")
    private boolean isMilitaryVeteran;
    @JsonProperty("isFamilyBased")
    private boolean isFamilyBased;
    @JsonProperty("isUnder14")
    private boolean isUnder14;

    public I485FormSpecificInfo(boolean isMilitaryVeteran, boolean isFamilyBased, boolean isUnder14) {
        super(FormType.I485);
        this.isMilitaryVeteran = isMilitaryVeteran;
        this.isFamilyBased = isFamilyBased;
        this.isUnder14 = isUnder14;
    }
    public I485FormSpecificInfo() {
        super(FormType.I485);
    }
}