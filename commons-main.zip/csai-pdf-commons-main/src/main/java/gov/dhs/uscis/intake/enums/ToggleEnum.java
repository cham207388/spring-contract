package gov.dhs.uscis.intake.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum ToggleEnum {
    PFVS_I912("PFVS_I912"),
    PFVS_797C("PFVS_797C"),
    PFVS_ENABLED("PFVS_ENABLED");

    private String name;

    private ToggleEnum(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

}
