package gov.dhs.uscis.intake.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class FeeWaiverErrors {
  public static final String SIGNATURE_NOT_PRESENT_MESSAGE = "Your signature does not appear to be present on your fee waiver request, Form I-912.";
  public static final String FORM_TYPE_NOT_PRESENT_MESSAGE = "Form type 'I-912' is not present.";
  public static final String FORM_EDITION_UNSUPPORTED_TEMPLATE = "I-912 Form Edition is unsupported. Go to https://www.uscis.gov/i-912 to download the latest edition";
  public static final String INCORRECT_PAGE_COUNT = "Form I-912 you uploaded has the wrong number of pages";
}
