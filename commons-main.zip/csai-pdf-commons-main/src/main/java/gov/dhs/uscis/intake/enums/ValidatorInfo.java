package gov.dhs.uscis.intake.enums;

public enum ValidatorInfo {
    IS_I912_FORM
}
