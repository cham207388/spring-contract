package gov.dhs.uscis.intake.converters;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class ZonedDateTimeSerializer extends JsonSerializer<ZonedDateTime> {

 private static final DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.sZ");

 @Override
 public void serialize(ZonedDateTime value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
   gen.writeString(value.format(format));
 }
 
}
