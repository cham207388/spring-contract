package gov.dhs.uscis.intake.models.myuscis;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class Admin implements Serializable {

	private static final long serialVersionUID = 8896876716901602207L;
	
	private String firstName;
	private String lastName;
	private String uuid;
	
}
