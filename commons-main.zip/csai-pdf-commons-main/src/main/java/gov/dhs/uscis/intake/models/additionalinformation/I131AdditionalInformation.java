package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.FormType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I131AdditionalInformation extends AdditionalInformation {
    private @Getter @Setter Boolean requestedEAD;

    public I131AdditionalInformation() {
        this.formType = FormType.I131.getType();
    }
}
