package gov.dhs.uscis.intake.converters;

import java.time.ZonedDateTime;
import java.util.Map;

import software.amazon.awssdk.enhanced.dynamodb.AttributeConverter;
import software.amazon.awssdk.enhanced.dynamodb.AttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.EnhancedType;
import software.amazon.awssdk.utils.ImmutableMap;

public final class ZonedDateTimeConverterProvider implements AttributeConverterProvider {
 private final Map<EnhancedType<?>, AttributeConverter<?>> converterCache = ImmutableMap.of(
         EnhancedType.of(ZonedDateTime.class), new ZonedDateTimeConverter());

 public static ZonedDateTimeConverterProvider create() {
     return new ZonedDateTimeConverterProvider();
 }

 @SuppressWarnings("unchecked")
 @Override
 public <T> AttributeConverter<T> converterFor(EnhancedType<T> enhancedType) {
     return (AttributeConverter<T>) converterCache.get(enhancedType);
 }
}