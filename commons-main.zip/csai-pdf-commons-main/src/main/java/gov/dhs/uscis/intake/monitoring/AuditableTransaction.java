package gov.dhs.uscis.intake.monitoring;

public enum AuditableTransaction{
    CanceledAuthorization,
    AcceptedPayment,
    CanceledPayment,
    DeclinedPayment,
    PaymentProcessingError,
    RejectedSubmission,
    SubmissionStarted,
    SubmissionPublished,
    PendingSubmission,
    ErroredSubmission, 
    UpdatedSubmission
}