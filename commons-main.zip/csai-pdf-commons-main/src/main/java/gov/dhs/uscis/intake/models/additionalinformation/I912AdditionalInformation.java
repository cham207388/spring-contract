package gov.dhs.uscis.intake.models.additionalinformation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.PFVSEvidenceType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class I912AdditionalInformation extends AdditionalInformation {
    private @Getter @Setter boolean isFeeDeclaration;

    public I912AdditionalInformation() {
    	this.formType = PFVSEvidenceType.I912.getType();
    }
}
