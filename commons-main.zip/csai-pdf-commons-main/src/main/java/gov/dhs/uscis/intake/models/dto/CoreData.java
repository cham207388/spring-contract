package gov.dhs.uscis.intake.models.dto;

import java.util.List;

import gov.dhs.uscis.intake.models.core.metadata.BetaBanner;
import lombok.Builder;

@Builder
public record CoreData(
        Boolean paygovMaintenanceEnabled,
        List<BetaBanner> betaBanners) {
}
