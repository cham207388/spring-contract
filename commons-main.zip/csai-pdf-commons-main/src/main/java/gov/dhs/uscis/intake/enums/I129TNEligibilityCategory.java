package gov.dhs.uscis.intake.enums;

import java.util.Arrays;
import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I129TNEligibilitySubcategory;
import lombok.Getter;

public enum I129TNEligibilityCategory implements PFVSEligibilityCategoryEnum {
    TN_NEW_EMPLOYMENT(
        "TN_NEW_EMPLOYMENT", 
        Arrays.asList(I129TNEligibilitySubcategory.values())
    ),
    TN_CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITHOUT_CHANGE_WITH_THE_SAME_EMPLOYER(
        "TN_CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITHOUT_CHANGE_WITH_THE_SAME_EMPLOYER", 
        Arrays.asList(I129TNEligibilitySubcategory.values())
    ),
    TN_CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT(
        "TN_CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT", 
        Arrays.asList(I129TNEligibilitySubcategory.values())
    ),
    TN_NEW_CONCURRENT_EMPLOYMENT(
        "TN_NEW_CONCURRENT_EMPLOYMENT", 
        Arrays.asList(I129TNEligibilitySubcategory.values())
    ),
    TN_CHANGE_OF_EMPLOYER(
        "TN_CHANGE_OF_EMPLOYER", 
        Arrays.asList(I129TNEligibilitySubcategory.values())
    ),
    TN_AMENDED_PETITION(
        "TN_AMENDED_PETITION", 
        Arrays.asList(I129TNEligibilitySubcategory.values())
    );

	private @Getter String category;
	private @Getter List<EligibilitySubcategoryEnum> subcategories;

	I129TNEligibilityCategory(String category, List<EligibilitySubcategoryEnum> subcategories) {
		this.category = category;
        this.subcategories = subcategories;
		EligibilityCategoryRegistry.register(this);
	}
}
