package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.ActionRequested;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.submission.form_specific_info.interfaces.ActionRequestedProvider;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class I129H1BFormSpecificInfo extends FormSpecificInfo implements ActionRequestedProvider {

	@JsonProperty("actionRequested")
	private ActionRequested actionRequested;

    @JsonProperty("isCapEnabled")
    private Boolean isCapEnabled;

    @JsonProperty("isCapGap")
    private Boolean isCapGap;

    public I129H1BFormSpecificInfo(ActionRequested actionRequested, Boolean isCapEnabled, Boolean isCapGap) {
        super(FormType.I129H1B);
        this.actionRequested = actionRequested;
        this.isCapEnabled = isCapEnabled;
        this.isCapGap = isCapGap;
    }

        public I129H1BFormSpecificInfo() {
         super(FormType.I129H1B);
    }
}