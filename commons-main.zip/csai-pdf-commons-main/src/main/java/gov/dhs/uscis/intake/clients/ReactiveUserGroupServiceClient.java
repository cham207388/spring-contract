package gov.dhs.uscis.intake.clients;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.exceptions.MyUscisProcessingException;
import gov.dhs.uscis.intake.models.core.ClientAssociation;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.user_group.ClientDetailsResponse;
import gov.dhs.uscis.intake.models.user_group.UserGroupResponse;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;
import gov.dhs.uscis.intake.models.user_group.UserGroupRoleData;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
public class ReactiveUserGroupServiceClient {
    private WebClient webClient;
    private static final String INVITE_USER_URL = "/api/invitations/pdfi/applicant_invite";
    public static final String CLIENT_LIST_URL = "/api/clients";
    public static final String USER_GROUP_ROLES = "/api/users/current/user_group_roles?exclude_user_group_types=applicant%2Corganization%2Cfamily%2Ccollaboration";
    public static final String ORGANIZATION_GROUP_ROLES = "/api/users/current/user_group_roles?exclude_user_group_types=applicant%2Claw_firm%2Cfamily%2Ccollaboration";

    private static final String ORGANIZATION_GROUP_TYPE = "organization";

    public ReactiveUserGroupServiceClient(WebClient webClient) {
        this.webClient = webClient;
    }

    public Mono<ClientAssociation> isClientAssociated(String icamUUID, String applicantUuid) {

        // return true if the client is associated, or false if not
        String truncatedMyUscisId = icamUUID.substring(0, 8);

        log.info("Looking up if applicant ...{} is associated with rep ...{}.", applicantUuid.substring(0, 8),
                truncatedMyUscisId);

        try {
            return webClient.get()
                    .uri(CLIENT_LIST_URL)
                    .header("ICAM-UUID", icamUUID)
                    .header("ICAM-USER-ROLE", AccountType.REPRESENTATIVE.getType())
                    .retrieve()
                    .bodyToMono(ClientDetailsResponse.class)
                    .mapNotNull(response -> {
                        // Search through the ClientDetailsResponse for the applicantUuid
                        var associations = (response.getData().stream()
                                .filter(item -> applicantUuid.equals(item.getApplicantUuid())))
                                .map(i -> new ClientAssociation(true, i.getClientGroupId()))
                                .toList();
                        log.info(String.format("Applicant (...{}) associated? {}.", applicantUuid.substring(0, 8),
                                !associations.isEmpty()));
                        return associations == null || associations.isEmpty()
                                ? new ClientAssociation(false, null)
                                : associations.get(0);
                    });

            // throw new RuntimeException("Received invalid response from client list api");

        } catch (Exception ex) {
            log.error("Error fetching relative clients for {}.", icamUUID,
                    ex);
            throw ex;
        }
    }

    public Mono<UserGroupRole> getRepGroupId(String icamUUID) {
        log.info("Looking up rep lawfirm id for rep: {}", icamUUID);

        try {
            return webClient.get()
                    .uri(USER_GROUP_ROLES)
                    .header("ICAM-UUID", icamUUID)
                    .retrieve()
                    .bodyToMono(UserGroupResponse.class)
                    .onErrorResume(WebClientResponseException.class, f-> {
                        log.error( "Exception while reading User Group Service for icam {}", icamUUID );
                        return Mono.just(new UserGroupResponse(new UserGroupRoleData(icamUUID, new ArrayList<UserGroupRole>())));
                    })
                    .mapNotNull(response -> {
                        // Search through the UserGroupResponse data for the applicable law_firm id
                        if (response.getData() != null) {
                            Optional<UserGroupRole> roleOptional = response.getData().getUserGroupRoles().stream()
                                    .filter(role -> "law_firm".equals(role.getUserGroupType())
                                            && role.getRoles().contains("user_group_rep_admin"))
                                    .findFirst();

                            return roleOptional.orElse(UserGroupRole.emptyUserGroupRole());
                        }
                        return UserGroupRole.emptyUserGroupRole();
                    });

        } catch (Exception ex) {
            log.error("Error fetching rep user group roles for rep ...{}.", icamUUID, ex);
            return null;
        }
    }

    public Mono<ClientInformation> inviteClient(String attorneyId, String attorneyUserGroupId, String submissionId,
            String emailAddress, Name name) {
        log.info("About to invite email address {} to connect with rep {} in user group: {}", emailAddress, attorneyId,
                attorneyUserGroupId);

        var request = new InviteClientRequest(
                new Invite(emailAddress, name.getFirstName(), name.getMiddleName(), name.getLastName(), false));

        return webClient.post()
                .uri(INVITE_USER_URL)
                .header("ICAM-UUID", attorneyId)
                .header("USER-GROUP-ID", attorneyUserGroupId)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(InviteUserResponse.class)
                .doOnError(WebClientResponseException.class, (e) -> {
                    log.error("Unable to create new account for email address {}: {}", emailAddress, e.getMessage());
                    throw new MyUscisProcessingException("Account creation failed for " + emailAddress);
                })
                .mapNotNull(response -> new ClientInformation(response.data().id(), attorneyId, submissionId, name,
                        List.of(response.data.toUserGroupId(), attorneyUserGroupId)));

    }

    public Mono<UserGroupRole> getOrganizationGroupRole(String icamUUID) {
    	log.info("Attempting to retrieve organization group id for icam uuid: {}", icamUUID);
    	return webClient.get()
    	    		.uri(ORGANIZATION_GROUP_ROLES)
    	    		.header("ICAM-UUID", icamUUID)
    	    		.retrieve()
    	    		.bodyToMono(UserGroupResponse.class)
    	    		.onErrorResume(WebClientResponseException.class, e -> {
    	    			String message = String.format("An exception occured while retrieving organization group role for icam uuid %s, returning empty group role.", icamUUID);
    	    			log.error(message, e);
    	    			return Mono.just(new UserGroupResponse());
    	    		})
    	    		.mapNotNull(response -> {
    	    			if(response.getData() != null) {
    	    				Optional<UserGroupRole> organizationGroupRole = response.getData().getUserGroupRoles()
    	    						.stream()
    	    						.filter(role -> ORGANIZATION_GROUP_TYPE.equals(role.getUserGroupType()))
    	    						.findFirst();
    	    				if(organizationGroupRole.isPresent()) {
    	    					return organizationGroupRole.get();
    	    				}
    	    				log.info("Could not find organization role type in response, returning empty group role.");
    	    				return UserGroupRole.emptyUserGroupRole();
    	    			}
    	    			log.info("There is no data in response, returning empty group role.");
    	    			return UserGroupRole.emptyUserGroupRole();
    	    		});
    }

    public Mono<Boolean> isPartOfUserOrg(String icamUUID) {
    	log.info("Attempting to retrieve organization group id for icam uuid: {}", icamUUID);
    	return webClient.get()
    	    		.uri(ORGANIZATION_GROUP_ROLES)
    	    		.header("ICAM-UUID", icamUUID)
    	    		.retrieve()
    	    		.bodyToMono(UserGroupResponse.class)
    	    		.onErrorResume(WebClientResponseException.class, e -> {
    	    			log.error("An exception occured while retrieving organization group role for icam uuid {}, returning empty group role. {}", icamUUID, e);
    	    			return Mono.just(new UserGroupResponse());
    	    		})
    	    		.mapNotNull(response -> {
    	    			if(response.getData() != null) {
                            return   !response.getData().getUserGroupRoles().isEmpty();

    	    			}
    	    			log.info("There is no data in response, returning empty group role.");
    	    			return false;
    	    		});
    }


    public record InviteResponseData(String id, String toUserGroupId) {}

    public record InviteUserResponse(InviteResponseData data) {}

    public record InviteClientRequest(Invite invitation) {}

    public record Invite(String email, String firstName, String middleName, String lastName, boolean skipNotification) {}

}
