package gov.dhs.uscis.intake.models;

import java.util.Map;

import gov.dhs.uscis.intake.models.core.metadata.EvidencePages;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@DynamoDbBean
public class EvidenceMetaData {
    @Getter(onMethod_ = { @DynamoDbPartitionKey })
    String id;
    Map<String, EvidencePages> evidencePages;
}