package gov.dhs.uscis.intake.models;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.lang.Nullable;

import gov.dhs.uscis.intake.converters.EligibilityCategoryConverterProvider;
import gov.dhs.uscis.intake.converters.EligibilitySubcategoryConverterProvider;
import gov.dhs.uscis.intake.converters.EligibilitySubcategoryListConverterProvider;
import gov.dhs.uscis.intake.converters.FormSpecificInfoConverter;
import gov.dhs.uscis.intake.converters.ZonedDateTimeConverterProvider;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ResidencyStatus;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.models.dto.C9UpdateRequest;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.DefaultAttributeConverterProvider;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbConvertedBy;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbIgnore;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamoDbBean(converterProviders = { ZonedDateTimeConverterProvider.class, EligibilityCategoryConverterProvider.class,
        EligibilitySubcategoryConverterProvider.class,   EligibilitySubcategoryListConverterProvider.class, DefaultAttributeConverterProvider.class })
public class Submission {
    @Getter(onMethod_ = { @DynamoDbSecondaryPartitionKey(indexNames = { "requests_by_myUscisId" }) })
    private String myUscisId;
    @Getter(onMethod_ = { @DynamoDbSecondaryPartitionKey(indexNames = { "requests_by_orgMyUscisId" }) })
    private String orgMyUscisId;
    @Getter(onMethod_ = { @DynamoDbPartitionKey })
    private String submissionId;
    @Getter(onMethod_ = { @DynamoDbSecondaryPartitionKey(indexNames = { "requests_by_formType" }) })
    private FormType formType;
    private String formName;
    @Nullable
    private EligibilityCategoryEnum eligibilityCategory;
    @Nullable
    private EligibilitySubcategoryEnum eligibilitySubcategory;
    @Nullable
    private List<EligibilitySubcategoryEnum> eligibilitySubcategories;
    private Integer benefitTypeCode;
    private Integer applicationReaonCode;
    @Getter(onMethod_ = { @DynamoDbSecondaryPartitionKey(indexNames = { "requests_by_manifestId" }) })
    private String manifestId;
    @Getter(onMethod_ = { @DynamoDbSecondaryPartitionKey(indexNames = { "requests_by_status" }) })
    private SubmissionState status;
    @Getter(onMethod_ = { @DynamoDbSecondaryPartitionKey(indexNames = { "requests_by_lockboxStatus" }) })
    private LockboxStatuses lockboxStatus;
    private List<ManifestError> lockboxErrors;
    private BigDecimal feeTotal;
    private ZonedDateTime timestamp;
    private ZonedDateTime updatedAt;
    private ZonedDateTime lockedAt;
    private ZonedDateTime submittedAt;
    @Nullable
    private List<SubmissionForm> forms;
    @Nullable
    private List<SubmissionEvidence> evidences;
    // discuss making this a concrete type since it has specific behavior?
    @Nullable
    private SubmissionEvidence feeWaiver;
    private Boolean userRequestedFeeWaiver;
    private Boolean userRequestedPartialFeeWaiver;
    private Boolean userIsEligibleForFeeWaiver;
    private Boolean attested;
    private ZonedDateTime attestedAt;
    private String attestationSignature;
    private Boolean hasReviewedSignature;
    private Boolean immvi;
    private ResidencyStatus isUSCitizen;
    @Nullable
    private C9UpdateRequest c9updateRequest;
    private String reasonForFiling;
    private FinalTransmissionStatus transmissionStatus;
    @Getter(onMethod_ = { @DynamoDbIgnore })
    private ClientInformation clientInformation;
    private UserInformation applicant;
    @Getter(onMethod_ = { @DynamoDbConvertedBy(FormSpecificInfoConverter.class) })
    private FormSpecificInfo formSpecificInfo;
    private Boolean sentNotify;
    private List<FormType> selectedConcurrentForms;
}
