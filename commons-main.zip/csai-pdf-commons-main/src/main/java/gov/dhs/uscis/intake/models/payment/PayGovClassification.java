package gov.dhs.uscis.intake.models.payment;

import lombok.Builder;

@Builder
public record PayGovClassification(
    Integer applicationReasonCode,
    String immigrationStatusCode
){}
