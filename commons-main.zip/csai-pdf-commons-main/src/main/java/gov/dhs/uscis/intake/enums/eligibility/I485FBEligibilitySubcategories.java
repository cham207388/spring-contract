package gov.dhs.uscis.intake.enums.eligibility;

import lombok.Getter;

public enum I485FBEligibilitySubcategories implements EligibilitySubcategoryEnum {
    // Immediate Relatives of a U.S. citizen (USC)
    USC_SPOUSE("USC_SPOUSE"),
    USC_MINOR_CHILD("USC_MINOR_CHILD"),
    USC_PARENT("USC_PARENT"),
    USC_FIANCE_K1K2("USC_FIANCE_K1K2"),
    USC_WIDOW("USC_WIDOW"),
    USC_MIL_REL("USC_MIL_REL"),

    // Other relatives of a U.S. citizen under the family-based preference categories (F1, F3, F4)
    USC_UNMARRIED_ADULT_SON_DAU("USC_UNMARRIED_ADULT_SON_DAU"),
    USC_MARRIED_SON_DAU("USC_MARRIED_SON_DAU"),
    USC_SIBLING("USC_SIBLING"),

    // Relative of a lawful permanent resident (LPR) under the family-based preference categories (F2A, F2B)
    LPR_SPOUSE("LPR_SPOUSE"),
    LPR_MINOR_CHILD("LPR_MINOR_CHILD"),
    LPR_UNMARRIED_ADULT_SON_DAU("LPR_UNMARRIED_ADULT_SON_DAU");

    private @Getter String category;

    I485FBEligibilitySubcategories(String category) {
        this.category = category;
        EligibilitySubcategoryRegistry.register(this);
    }
}
