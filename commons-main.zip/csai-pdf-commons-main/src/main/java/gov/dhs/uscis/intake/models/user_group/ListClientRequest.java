package gov.dhs.uscis.intake.models.user_group;

import com.fasterxml.jackson.annotation.JsonProperty;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ListClientRequest {

    @JsonProperty("ICAM-UUID")
    private String iCamUUID;
    @JsonProperty("ICAM-USER-ROLE")
    private String iCamUserRole;

}
