package gov.dhs.uscis.intake.models.submission.form_specific_info.interfaces;

import gov.dhs.uscis.intake.enums.ActionRequested;

public interface ActionRequestedProvider {
    public ActionRequested getActionRequested();
}

