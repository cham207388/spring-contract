package gov.dhs.uscis.intake.models.validation.name_extract;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPreserveEmptyObject;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
@ToString
public class NameExtract {
    @Getter(onMethod_ = { @DynamoDbPartitionKey })
    private String submissionId;
    private String formId;
    private String g28FormId;
    private FormType form;

    @Getter(onMethod_ = { @DynamoDbPreserveEmptyObject })
    private ClientName clientNameOnForm;

    @Getter(onMethod_ = { @DynamoDbPreserveEmptyObject })
    private ClientName clientNameOnG28;

    public boolean hasAllNamesForValidation() {
        return null != clientNameOnG28 && null != clientNameOnForm;
    }

    public NameExtract updateClientName(FormType formType, ClientName clientName, String formId) {
        if (FormType.G28.equals(formType)) {
            this.clientNameOnG28 = clientName;
            this.g28FormId = formId;
        } else {
            this.clientNameOnForm = clientName;
            this.formId = formId;
            if (this.form == FormType.G28) {
                this.form = formType;
            }

        }
        return this;
    }
}
