
package gov.dhs.uscis.intake.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Builder
@DynamoDbBean
@NoArgsConstructor
@AllArgsConstructor
@Data
public class EvidenceType {
    private String id;
    private String name;
    private int contentCategoryCode;
}
