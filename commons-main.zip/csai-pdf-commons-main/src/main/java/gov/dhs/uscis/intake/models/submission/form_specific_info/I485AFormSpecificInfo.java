package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Getter
@Setter
public class I485AFormSpecificInfo extends FormSpecificInfo {
    @JsonProperty("isApplicantUnder17Unmarried")
    private boolean isApplicantUnder17Unmarried;
    @JsonProperty("isSpouseOfLegalizedAlien")
    private boolean isSpouseOfLegalizedAlien;
    @JsonProperty("isUnmarriedChildUnder21")
    private boolean isUnmarriedChildUnder21;

    public I485AFormSpecificInfo(boolean isApplicantUnder17Unmarried, boolean isSpouseOfLegalizedAlien, boolean isUnmarriedChildUnder21) {
        super(FormType.I485A);
        this.isApplicantUnder17Unmarried = isApplicantUnder17Unmarried;
        this.isSpouseOfLegalizedAlien = isSpouseOfLegalizedAlien;
        this.isUnmarriedChildUnder21 = isUnmarriedChildUnder21;
    }

    public boolean calcIsI817Beneficiary() {
        return this.isApplicantUnder17Unmarried || this.isSpouseOfLegalizedAlien || this.isUnmarriedChildUnder21;
    }

        public I485AFormSpecificInfo() {
            super(FormType.I485A);
    }
}