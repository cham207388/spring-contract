package gov.dhs.uscis.intake.clients;

import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.models.core.ClientAssociation;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;

public class MockUserGroupServiceClient extends UserGroupServiceClient {

    private Logger logger = LoggerFactory.getLogger(MockUserGroupServiceClient.class);

    public MockUserGroupServiceClient() {
        super(null);
        logger.info("Usergroup Service is not enabled - Initializing a mock");
    }

    @Override
    public UserGroupRole getRepGroupId(String icamUUID) {
        logger.info("Usergroup Service is not enabled");
        return UserGroupRole.builder().userGroupId("fakeGroupId").build();
    }

    @Override
    public ClientInformation inviteClient(String attorneyId, String attorneyUserGroupId, String submissionId,
            String emailAddress, Name name) {
        logger.info("Usergroup Service is not enabled");
        return new ClientInformation(UUID.randomUUID().toString(), attorneyId, submissionId, name, List.of());
    }

    @Override
    public ClientAssociation isClientAssociated(String icamUUID, String applicantUuid) {
        logger.info("Usergroup Service is not enabled");
        return new ClientAssociation(true, "fakeGroupId");
    }

}
