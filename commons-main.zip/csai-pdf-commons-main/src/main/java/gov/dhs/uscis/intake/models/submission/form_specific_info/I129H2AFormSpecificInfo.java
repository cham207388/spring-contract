package gov.dhs.uscis.intake.models.submission.form_specific_info;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.RequestedAction;
import gov.dhs.uscis.intake.models.submission.form_specific_info.interfaces.RequestedActionProvider;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class I129H2AFormSpecificInfo extends FormSpecificInfo implements RequestedActionProvider {

	@JsonProperty("actionRequested")
	private RequestedAction requestedAction;

    public I129H2AFormSpecificInfo(RequestedAction requestedAction) {
        super(FormType.I129H2A);
        this.requestedAction = requestedAction;
    }
    public I129H2AFormSpecificInfo() {
         super(FormType.I129H2A);
    }
}