package gov.dhs.uscis.intake.models.validation.address_extract;

import gov.dhs.uscis.intake.enums.ValidatorEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AddressValidationResult {
    String formId;
    String submissionId;
    String myUscisId;
    ValidatorEnum validator;
    String formType;
    ClientAddress clientAddress;
}