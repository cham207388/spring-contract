package gov.dhs.uscis.intake.models.validation;

import java.util.List;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@AllArgsConstructor
public class N400FormFieldResult extends FormFieldResult {
  public final static FormType FORM_TYPE = FormType.N400;

  @Builder
  public N400FormFieldResult(String formId, String submissionId, String myUscisId, String alienNumber,
      String dateOfBirth, ValidatorEnum validator, List<EligibilityCategoryEnum> selectedCategories) {
    super(formId, submissionId, myUscisId, alienNumber, dateOfBirth, validator, selectedCategories);
  }

  @Override
  public FormType getFormType() {
    return N400FormFieldResult.FORM_TYPE;
  }
}