package gov.dhs.uscis.intake.models.elis;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class ELISPayment implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Date paymentStatusDate;
	private Date transactionDate;
	private Date paymentDate;
	private BigDecimal paymentAmount;
	private String payGovTrackingId;
	private String paymentStatus;
	private String paymentType;

}
