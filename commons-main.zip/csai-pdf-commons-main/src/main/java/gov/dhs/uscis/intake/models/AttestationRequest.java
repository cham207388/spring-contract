package gov.dhs.uscis.intake.models;

import lombok.Builder;

@Builder
public record AttestationRequest(String submissionId, String formId) {}
