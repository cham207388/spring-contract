package gov.dhs.uscis.intake.models.myuscis;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class NotificationRequest {

	@JsonProperty(value = "notification_type")
	private String notificationType;
	
	@JsonProperty(value = "resource_id")
	private String resourceId;
	
	@JsonProperty(value = "resource_type")
	private String resourceType;
	
	private List<String> uuids;

}
