package gov.dhs.uscis.intake.models;

import java.math.BigDecimal;
import java.util.List;

import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubmissionUpdateRequest {

    private ManifestUpdate manifestUpdate;
    private SubmissionUpdate submissionUpdate;
    private EntityType updateType;

    @Getter
    @Setter
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ManifestUpdate {
        private StatusEnum status;
        private String lockboxId;
        private List<ManifestError> errors;
    }

    @Getter
    @Setter
    @ToString
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SubmissionUpdate {
        private String lockboxId;
        private StatusEnum status;
        private BigDecimal totalCost;
        private List<ApplicationStatus> applicationStatuses;
    }


}
