package gov.dhs.uscis.intake.models.core.metadata;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@DynamoDbBean
public class DropzoneProps {
    int maxSize;
    int maxUploads;
    int maxDrop;
    boolean validated;
    Map<String, List<String>> accept; 
}