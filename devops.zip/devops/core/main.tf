terraform {
  required_version = "= 1.12.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.0.0"
    }

    random = {
      source  = "hashicorp/random"
      version = "3.6.3"
    }
  }
  backend "s3" {
    bucket = "digital-intake-core-infra"
    key    = "state"
    region = "us-east-1"
  }
}

data "aws_region" "current" {}

variable "aws_environment" {}

variable "archive_bucket_name" {
  default = "csai-lambda-archives"
}

data "aws_security_group" "no_jump_box" {
  name   = "uscis_default_security_group_linux_1"
  vpc_id = data.aws_vpc.vpc.id
}

data "aws_subnets" "subnets" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.vpc.id]
  }
}

data "aws_vpc" "vpc" {}

# one per workspace or one per aws account?
resource "aws_s3_bucket" "lambda_archives" {
  bucket = "${var.aws_environment}-${var.archive_bucket_name}"

  tags = {
    "ECS:System"  = "CSAI/DigitalIntake"
    "ECS:FismaId" = "CIS-07773-GSS-07773"
  }
}

variable "tf_env_infra_state" {
  default = "digital-intake-tf-environments"
}

resource "aws_s3_bucket" "infra-state" {
  bucket = "${var.aws_environment}-${var.tf_env_infra_state}"
}

locals {
  tags = {
    Environment   = terraform.workspace
    "ECS:System"  = "CSAI/DigitalIntake"
    "ECS:FismaId" = "CIS-07773-GSS-07773"
  }
}
