
locals {
  amq_subnet = {
    "prod" : "subnet-0625d2635092c9ac0",
    "nonprod" : "subnet-05ee39cdb312ced0b",
    "default" : data.aws_subnets.subnets.ids[0]
  }
  amq_engine_version = "5.18"
}

resource "aws_mq_broker" "broker" {
  count                      = terraform.workspace == "nonprod" || terraform.workspace == "prod" ? 1 : 0
  broker_name                = "pdf-intake-${terraform.workspace}"
  # auto_minor_version_upgrade = true

  configuration {
    id       = aws_mq_configuration.amq_configuration[count.index].id
    revision = aws_mq_configuration.amq_configuration[count.index].latest_revision
  }

  engine_type        = "ActiveMQ"
  engine_version     = local.amq_engine_version
  host_instance_type = "mq.m5.large"
  security_groups    = [aws_security_group.amq[count.index].id, data.aws_security_group.no_jump_box.id]
  subnet_ids         = [local.amq_subnet[var.aws_environment]]
  deployment_mode    = "SINGLE_INSTANCE"
  auto_minor_version_upgrade = true

  user {
    console_access = true
    username       = "ExampleUser"
    password       = var.amq_pw
  }
}

# amq pw is used when accessing aws amq and is not used for accessing elis amq
variable "amq_pw" {
  default = "changemelonger"  
}

resource "aws_security_group" "amq" {
  vpc_id = data.aws_vpc.vpc.id
  count  = terraform.workspace == "nonprod" || terraform.workspace == "prod" ? 1 : 0

  # SSH access from anywhere
  ingress {
    from_port = 22
    to_port   = 22
    protocol  = "tcp"
    cidr_blocks = [
    "10.0.0.0/8"]
  }

  ingress {
    from_port = 61616
    to_port   = 61617
    protocol  = "tcp"
    cidr_blocks = [
    "10.0.0.0/8"]
  }

  ingress {
    from_port = 8161
    to_port   = 8162
    protocol  = "tcp"
    cidr_blocks = [
    "10.0.0.0/8"]
  }

  # for git clone
  egress {
    from_port = 0
    to_port   = 0
    protocol  = "-1"
    cidr_blocks = [
    "0.0.0.0/0"]
  }

  tags = { "Name" = "csai-amq-${terraform.workspace}" }

}


resource "aws_mq_configuration" "amq_configuration" {
  count          = terraform.workspace == "nonprod" || terraform.workspace == "prod" ? 1 : 0
  description    = "Example Configuration"
  name           = "example-new-${terraform.workspace}"
  engine_type    = "ActiveMQ"
  engine_version = local.amq_engine_version

  data = <<DATA
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<broker xmlns="http://activemq.apache.org/schema/core">
  <plugins>
    <forcePersistencyModeBrokerPlugin persistenceFlag="true"/>
    <statisticsBrokerPlugin/>
    <timeStampingBrokerPlugin ttlCeiling="86400000" zeroExpirationOverride="86400000"/>
  </plugins>
</broker>
DATA
}



output "amq-endpoints" {
  #value = length(resource.aws_mq_broker[*].broker.broker_name) > 0 ? aws_mq_broker[*].broker.instances.0.endpoints : null
  value = "check in aws console"
}


output "broker-ip" {
  #value = length(resource.aws_mq_broker[*].broker.broker_name) > 0 ? aws_mq_broker[*].broker.instances.0.ip_address : null
  value = "check in aws console"
}

output "amq-ui-url" {
  #value = length(resource.aws_mq_broker[*].broker.broker_name) > 0 ? aws_mq_broker[*].broker.instances.0.console_url : null
  value = "check in aws console"
}
