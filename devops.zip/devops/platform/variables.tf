variable "eks_edgeproxy_context" { default = "esb-nonprod-shared-eks-cluster" }
variable "eks_default_context" { default = "esb-nonprod-shared-eks-cluster" }
variable "aws_environment" {}
variable "validators_jar" {}
variable "orchestrator_validator_jar" {}
variable "I912Validator_jar" {}
variable "signature_validator_jar" {}
variable "eligibility_validator_jar" {}
variable "name_validator_jar" {}
variable "address_validator_jar" {}
variable "client_name_email_validator_jar" {}
variable "attorney_name_validator_jar" {}
variable "person_validator_jar" {}
variable "i797c_validator_jar" {}
variable "migrator_jar" {default = "changeme"}
variable "values_environment" {}

variable "edge_chart_path_or_name" {}
variable "gateway_chart_path_or_name"{}
variable "submission_chart_path_or_name"{}
variable "payment_chart_path_or_name"{}
variable "downloader_chart_path_or_name"{}
variable "oauth_service_chart_path_or_name"{}
variable "paygov_service_chart_path_or_name"{}
variable "elis_service_chart_path_or_name"{}
variable "mockserver_service_chart_path_or_name" {}

variable "admin_chart_path_or_name"{}

variable "chart_repository"{}

variable "edge_chart_version"{}
variable "gateway_chart_version"{}
variable "submission_chart_version"{}
variable "payment_chart_version"{}
variable "downloader_chart_version"{}
variable "oauth_service_chart_version"{}
variable "paygov_service_chart_version"{}
variable "elis_service_chart_version"{}
variable "mockserver_service_chart_version" {}

variable "admin_chart_version"{}

variable "lockbox_gw_url"{}
variable "submission_service_url"{}
variable "uscis_submission_url"{}
variable "payment_service_url"{}
variable "downloader_url"{}
variable "paygov_url"{}
variable "edge_base_url" {}
variable "mock_oauth_url" {}
variable "elis_payment_url"{}
variable "peeps_url" {}
variable "usergroupservice_url" {}
variable "accountsdata_url" {
    default=""
}
variable "kubernetes_namespace" {}
variable "kubernetes_edgeproxy_namespace" {}
variable "image_tag"{}
variable "eks_domain"{}
variable "eks_edgeproxy_domain" {}
variable "edge_proxyimage_tag"{}
variable "submission_service_image_tag"{}
variable "lockbox_gateway_image_tag"{}
variable "payment_service_image_tag" {}
variable "oauth_service_image_tag" {}
variable "paygov_service_image_tag" {}
variable "elis_service_image_tag" {}
variable "admin_service_image_tag" {}
variable "pdfiadminpassword" {}

variable "elisApiEncodedJks"{}
variable "amqKeystore" {}
variable "amqKeystorePassword" {}
variable "amqTrustStorePassword" {}
variable "brokerUrl" {}
variable "secondaryBrokerUrl" {}
variable "ternaryBrokerUrl" {}
variable "amqPassword" {}
variable "ap_oidc_client_id" { }
variable "ap_oidc_client_secret" { }
variable "myuscis_encoded_key" { }
variable "myuscis_encoded_cert" { }
variable "helm_history_max" { default = 3 }
variable "jwt_secret_name" { }
variable "jwt_public_key" { }
variable "jwt_private_key" { }
variable "peeps_username" { }
variable "peeps_password" { }
variable "usergroupservice_username" { }
variable "usergroupservice_password" { }
variable "accountsdata_username" {
    default=""
}
variable "accountsdata_password" {
    default=""
}
variable "cacheupdate_username" {}
variable "cacheupdate_password" {}
variable "draftbenefits_username" { }
variable "draftbenefits_password" { }
variable "new_relic_license_key" {}
variable "app_version" {}


variable "lockbox_test_double_chart_path_or_name" {} 
variable "lockbox_test_double_chart_version" {}
variable "lockbox_test_double_image_tag" {}
variable "backup_retention_period" {
  default=35
}

variable "enable_versioning" {
  default = true
  description = "Boolean to enable S3 versioning"
}

variable "s3_bucket_owner" { default = "changeme" }

variable "sqs_saturation_email_list" {
 description = "List of emails to subscribe to SQS saturation alerts"
 type        = string
 default = "Adekunle.K.Afolabi@uscis.dhs.gov"
}
