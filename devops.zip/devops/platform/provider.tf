provider "aws" {
  region = "us-east-1"
  
  ignore_tags {
    keys = ["SCP:EnterpriseIAM"]
  }
}

provider "helm" {
  kubernetes {
    config_path = "~/.kube/config"
    config_context = var.eks_default_context
  }
}