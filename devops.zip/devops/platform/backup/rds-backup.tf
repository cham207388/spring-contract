module "rds_backup" {
  source  = "cloudposse/backup/aws"
  version = "1.1.1"

  name          = "${terraform.workspace}-postgres-4-hour-backup"
  vault_name    = "${terraform.workspace}-postgres-backup-vault"
  vault_enabled = true
  enabled       = contains(["csai6683rdsbac"], terraform.workspace)
#   enabled       = contains(["prod", "preprod"], terraform.workspace)
  tags          = local.tags

  backup_resources = [
    var.rds_instance_arn
  ]

  rules = [
    {
      name                     = "${terraform.workspace}-postgres-every-4-hour-rule"
      schedule                 = "cron(0 0/4 * * ? *)"
      start_window             = 60
      completion_window        = 240
      enable_continuous_backup = true
      lifecycle = {
        delete_after = 7
      }
    }
  ]
}


locals {
  tags = {
    Environment   = terraform.workspace
    "ECS:System"  = "CSAI/DigitalIntake"
    "ECS:FismaId" = "CIS-07773-GSS-07773"
  }
}
