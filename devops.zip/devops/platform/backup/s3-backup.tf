resource "aws_sns_topic" "s3Backup" {
  name = "${terraform.workspace}-backup-vault-events"
}

data "aws_iam_policy_document" "s3Backup" {
  policy_id = "__default_policy_ID"
  statement {
    actions = [
      "SNS:Publish",
    ]
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["cloudwatch.amazonaws.com"]
    }
    resources = [
      aws_sns_topic.s3Backup.arn,
    ]
    sid = "__default_statement_ID"
  }
}

resource "aws_sns_topic_policy" "s3Backup" {
  arn    = aws_sns_topic.s3Backup.arn
  policy = data.aws_iam_policy_document.s3Backup.json
}


data "aws_iam_policy_document" "assume_role" {
  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["backup.amazonaws.com"]
    }

    actions = ["sts:AssumeRole"]
  }
}
resource "aws_iam_role" "s3Backup" {
  name               = "${terraform.workspace}-s3Backup"
  assume_role_policy = data.aws_iam_policy_document.assume_role.json
}

resource "aws_iam_role_policy_attachment" "s3Backup_s3" {
 policy_arn = "arn:aws:iam::aws:policy/AWSBackupServiceRolePolicyForS3Backup"
 role       = aws_iam_role.s3Backup.name
}
resource "aws_iam_role_policy_attachment" "s3Backup_s3_restore" {
 policy_arn = "arn:aws:iam::aws:policy/AWSBackupServiceRolePolicyForS3Restore"
 role       = aws_iam_role.s3Backup.name
}

resource "aws_backup_vault" "s3Backup" {
 count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
 name = "${terraform.workspace}-s3-backup-vault"
 tags = {
   Environment = terraform.workspace
 }
}

resource "aws_backup_selection" "s3Backup" {
  count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
  iam_role_arn = aws_iam_role.s3Backup.arn
  name         = "${terraform.workspace}-s3Selection"
  plan_id      = aws_backup_plan.s3Backup[0].id

  resources = var.backup_bucket_arns
}

resource "aws_backup_plan" "s3Backup" {
  count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
  name = "${terraform.workspace}-s3_backup_plan"
  rule {
    rule_name = "${terraform.workspace}-s3_DayRetention"
    schedule          = "cron(0 */4 * * ? *)"
    target_vault_name = aws_backup_vault.s3Backup[0].name
    completion_window = 480
    lifecycle {
      delete_after = 14
    }
  }
}

resource "aws_cloudwatch_metric_alarm" "backup_failed" {
    count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
    alarm_name          = "${terraform.workspace}-backup-job-failed"
    comparison_operator = "GreaterThanThreshold"
    evaluation_periods  = 1
    metric_name         = "NumberOfBackupJobsFailed"
    namespace           = "AWS/Backup"
    period              = 3600
    statistic           = "Sum"
    threshold           = 0
    alarm_description   = "Backup job failed"
    alarm_actions       = [aws_sns_topic.s3Backup.arn]
    dimensions = {
      BackupVaultName = aws_backup_vault.s3Backup[0].name
    }
}

variable "backup_bucket_arns" {
 description = "List of S3 bucket ARNs to back up"
 type        = list(string)
 default     = []
}