variable "notification_email" {
  description = "Email address for backup alerts"
  type        = string
  default     = "kabir.a.shaikh@uscis.dhs.gov"
}
locals {
  is_backup_enabled = contains(["prod", "preprod"], terraform.workspace)
}

resource "aws_backup_vault" "dynamodb_vault" {
  count         = local.is_backup_enabled ? 1 : 0
  name          = "${terraform.workspace}-dynamodb-backup-vault-v3"
  force_destroy = true

  tags = { Environment = terraform.workspace }
}
resource "null_resource" "set_backup_notifications" {
  count = local.is_backup_enabled ? 1 : 0
  triggers = {
    vault_name = aws_backup_vault.dynamodb_vault[0].name
    sns_arn    = aws_sns_topic.backup_notifications[0].arn
  }

  provisioner "local-exec" {
    command = <<EOT
        aws backup put-backup-vault-notifications \
        --backup-vault-name ${aws_backup_vault.dynamodb_vault[0].name} \
        --sns-topic-arn ${aws_sns_topic.backup_notifications[0].arn} \
        --backup-vault-events BACKUP_JOB_FAILED RESTORE_JOB_FAILED
      EOT
  }

  depends_on = [
    aws_backup_vault.dynamodb_vault,
    aws_sns_topic.backup_notifications,
    aws_sns_topic_policy.backup_sns_policy
  ]
}

resource "aws_backup_plan" "dynamodb_hourly_plan" {
  count = local.is_backup_enabled ? 1 : 0
  name  = "${terraform.workspace}_dynamo_backup_plan"

  rule {
    rule_name         = "${terraform.workspace}-Every4HoursRule"
    target_vault_name = aws_backup_vault.dynamodb_vault[0].name

    # Cron for every 4 hours
    schedule = "cron(0 */4 * * ? *)"

    # 15 minutes for testing
    # schedule = "cron(0 0/4 * * ? *)"

    lifecycle {
      delete_after = 30
    }
  }
}

resource "aws_iam_role" "AWSDyanamodbBackup" {
  count = local.is_backup_enabled ? 1 : 0
  name  = "${terraform.workspace}-AWSDyanamodbBackup"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "backup.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_backup_vault_lock_configuration" "immutable_lock" {
  # Only enable the lock in prod/preprod to prevent accidental costs in dev
  count = (local.is_backup_enabled && (terraform.workspace == "prod" || terraform.workspace == "preprod")) ? 1 : 0


  backup_vault_name = aws_backup_vault.dynamodb_vault[0].name

  min_retention_days  = 7
  max_retention_days  = 365
  changeable_for_days = 3 # You have 3 days to delete the lock before it becomes permanent
}

resource "aws_kms_key" "backup_key" {
  count                   = local.is_backup_enabled ? 1 : 0
  description             = "KMS key for ${terraform.workspace} AWS Backup Vault"
  deletion_window_in_days = 10
  enable_key_rotation     = true

  tags = { Environment = terraform.workspace }
}

resource "aws_iam_role_policy_attachment" "backup_service_standard" {
  count      = local.is_backup_enabled ? 1 : 0
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSBackupServiceRolePolicyForBackup"
  role       = aws_iam_role.AWSDyanamodbBackup[0].name
}

resource "aws_sns_topic" "backup_notifications" {
  count = local.is_backup_enabled ? 1 : 0
  name  = "${terraform.workspace}-dynamodb-backup-alerts"
}
resource "aws_sns_topic_policy" "backup_sns_policy" {
  count = local.is_backup_enabled ? 1 : 0
  arn   = aws_sns_topic.backup_notifications[0].arn

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowBackupServiceToPublish"
        Effect = "Allow"
        Principal = {
          Service = "backup.amazonaws.com"
        }
        Action   = "sns:Publish"
        Resource = aws_sns_topic.backup_notifications[0].arn
      }
    ]
  })
}

resource "aws_backup_selection" "backup_selection" {
  count        = local.is_backup_enabled ? 1 : 0
  name         = "${terraform.workspace}-DynamoDBTableSelection"
  plan_id      = aws_backup_plan.dynamodb_hourly_plan[0].id
  iam_role_arn = aws_iam_role.AWSDyanamodbBackup[0].arn

  resources = [
    var.submissions_summary_table_arn,
    var.core_metadata_table_arn,
    var.evidence_metadata_table_arn,
    var.feewaiver_metadata_table_arn,
    var.form_metadata_table_arn,
    var.submission_table_arn,
    var.textract_job_status_table_arn,
    var.validation_status_table_arn,
    var.client_information_table_arn,
    var.name_validation_arn,
    var.audit_table_arn
  ]

  selection_tag {
    type  = "STRINGEQUALS"
    key   = "Backup"
    value = "true"
  }
}

resource "aws_sns_topic_subscription" "backup_email_alert" {
  count     = local.is_backup_enabled ? 1 : 0
  topic_arn = aws_sns_topic.backup_notifications[0].arn
  protocol  = "email"
  endpoint  = var.notification_email
}

variable "core_metadata_table_arn" {
}
variable "evidence_metadata_table_arn" {
}

variable "feewaiver_metadata_table_arn" {
}

variable "validation_status_table_arn" {
}

variable "client_information_table_arn" {
}

variable "textract_job_status_table_arn" {}

variable "submission_table_arn" {
}

variable "form_metadata_table_arn" {
}

variable "submissions_summary_table_arn" {
}

variable "name_validation_arn" {
}

variable "audit_table_arn" {
}

variable "address_extract_table_arn" {}

variable "rds_instance_arn" {}
