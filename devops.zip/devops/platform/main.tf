terraform {
  required_version = "= 1.12.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.0.0"
    }

    helm = {
      source = "hashicorp/helm"
      version = "2.17.0"
    }

    archive = {
      source  = "hashicorp/archive"
      version = "2.7.1"
    }
  }
  backend "s3" {
    bucket = "digital-intake-tf-environments"
    key    = "platform"
    region = "us-east-1"
  }
}


data "aws_region" "current" {}



data "aws_vpc" "vpc" {}

data "aws_subnets" "subnets" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.vpc.id]
  }
}

locals {
  tags = {
    Environment   = terraform.workspace
    "ECS:System"  = "CSAI/DigitalIntake"
    "ECS:FismaId" = "CIS-07773-GSS-07773"
  }
}

data "aws_security_group" "no_jump_box" {
  name   = "uscis_default_security_group_linux_1"
  vpc_id = data.aws_vpc.vpc.id
}

module "infrastructure" {
  source = "./infrastructure"
  
  vpc_id = data.aws_vpc.vpc.id
  textract-notification_arn = module.validation_lambdas.textract_topic_arn
  aws_environment = var.aws_environment
  enable_versioning = var.enable_versioning
}

output "form_data_table_name" {
  value = module.infrastructure.form_data_table_name
}

output "core_data_table_name" {
  value = module.infrastructure.core_data_table_name
}

output "evidence_data_table_name" {
  value = module.infrastructure.evidence_data_table_name
}

output "core_metadata_table" {
    value = module.infrastructure.core_metadata_table
}

output "name_validation" {
    value = module.infrastructure.name_validation
}

output "submissions_summary_table" {
    value = module.infrastructure.submissions_summary_table
}

output "feewaiver_data_table_name" {
  value = module.infrastructure.feewaiver_data_table_name
}

/*output "rds_instance_arn" {
    value = module.payment.database_arn
}
*/
output "evidence_metadata_table" {
    value = module.infrastructure.evidence_data_table_name
}

output "ss-url" {
  value = module.submission_service.url
}

output "lbg-url" {
  value= module.lockbox_gateway.url
}

output "ep-url" {
  value= module.edge_proxy.url
}

output "downloader-url" {
  value= module.downloader.url
}
