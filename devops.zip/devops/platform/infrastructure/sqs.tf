resource "aws_sqs_queue" "replay_submission_request_queue_deadletter" {
  name = "${terraform.workspace}-replay-submisison-request-deadletter-queue"
  tags = local.tags
}


resource "aws_sqs_queue" "replay_submission_request" {
  name = "${terraform.workspace}-replay-submisison-request"

  message_retention_seconds = 86400
  receive_wait_time_seconds = 10
  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.replay_submission_request_queue_deadletter.arn
    maxReceiveCount     = 4
  })

  tags       = local.tags
  depends_on = [aws_sqs_queue.replay_submission_request_queue_deadletter]
}