variable "jar" {
  description = "Name of deployable Lambda JAR in S3 bucket"
  default     = "intake-0.0.1-SNAPSHOT.jar"
}


variable "bucket" {
  description = "S3 bucket housing deployable Lambda JAR"
  default     = "csai-lambda-archives"
}

variable "aws_environment" {
  description = "aws environment you are deploying to, nonprod or prod"
  default     = "nonprod"
}

# variable "secrets_environment" {
#   description = "aws environment you are deploying to, nonprod or prod"
#   default     = "nonprod"
# }

variable "amq_pw" {
  default = "changemelonger"
}

variable "vpc_id" {}

variable "textract-notification_arn" {}

variable "enable_versioning" {
  default = true
  description = "Boolean to enable S3 versioning"
}

# variable "dynamodb_init_script_name" {
#     default = "../submission-service/db_seed_script.sh"
# }

# variable "db_data_script" {
#   default = "../submission-service/db_data.json"
# }
# variable "deletion_protection" {
#   default = true
# }

# variable "dynamo_db_endpoint" {
#   default = "https://dynamodb.us-east-1.amazonaws.com"
#   #"http://localhost:4566"
# }
