locals {
  deletion_protection = {
    "prod" : "true",
    "preprod" : "true"
  }
}
resource "aws_dynamodb_table" "form_metadata_table" {
  name                        = "${terraform.workspace}-FormMetaData"
  hash_key                    = "formType"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "formType"
    type = "S"
  }

  tags = local.tags
}

resource "aws_dynamodb_table" "name_validation" {
  name                        = "${terraform.workspace}-NameExtract"
  hash_key                    = "submissionId"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "submissionId"
    type = "S"
  }

  tags = local.tags
}

resource "aws_dynamodb_table" "address_validation" {
  name                        = "${terraform.workspace}-AddressExtract"
  hash_key                    = "submissionId"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "submissionId"
    type = "S"
  }

  tags = local.tags
}

resource "aws_dynamodb_table" "submissions_table" {
  name                        = "${terraform.workspace}-Submission"
  hash_key                    = "submissionId"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  global_secondary_index {
    name            = "requests_by_myUscisId"
    hash_key        = "myUscisId"
    projection_type = "ALL"
  }

  global_secondary_index {
    name            = "requests_by_orgMyUscisId"
    hash_key        = "orgMyUscisId"
    projection_type = "ALL"
  }

  global_secondary_index {
    name            = "requests_by_manifestId"
    hash_key        = "manifestId"
    projection_type = "ALL"
  }

  global_secondary_index {
    name            = "requests_by_formType"
    hash_key        = "formType"
    projection_type = "ALL"
  }

  global_secondary_index {
    name            = "requests_by_lockboxStatus"
    hash_key        = "lockboxStatus"
    projection_type = "ALL"
  }

  global_secondary_index {
    name            = "requests_by_status"
    hash_key        = "status"
    projection_type = "ALL"
  }

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "submissionId"
    type = "S"
  }

  attribute {
    name = "myUscisId"
    type = "S"
  }

  attribute {
    name = "orgMyUscisId"
    type = "S"
  }

  attribute {
    name = "manifestId"
    type = "S"
  }

  attribute {
    name = "formType"
    type = "S"
  }

  attribute {
    name = "lockboxStatus"
    type = "S"
  }

  attribute {
    name = "status"
    type = "S"
  }

  tags = local.tags
}

resource "aws_dynamodb_table" "submissions_summary_table" {
  name                        = "${terraform.workspace}-SubmissionSummary"
  hash_key                    = "submissionId"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  global_secondary_index {
    name            = "summary_by_manifestId"
    hash_key        = "manifestId"
    projection_type = "ALL"
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "submissionId"
    type = "S"
  }

  attribute {
    name = "manifestId"
    type = "S"
  }
  tags = local.tags
}

resource "aws_dynamodb_table" "audit_table" {
  name                        = "${terraform.workspace}-Audit"
  hash_key                    = "myUscisId"
  range_key                   = "submissionId"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "myUscisId"
    type = "S"
  }

  attribute {
    name = "submissionId"
    type = "S"
  }

  tags = local.tags
}

resource "aws_dynamodb_table" "core_metadata_table" {
  name                        = "${terraform.workspace}-CoreMetaData"
  hash_key                    = "id"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "id"
    type = "S"
  }

  tags = local.tags
}

resource "aws_dynamodb_table" "evidence_metadata_table" {
  name                        = "${terraform.workspace}-EvidenceMetaData"
  hash_key                    = "id"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "id"
    type = "S"
  }

  tags = local.tags
}

resource "aws_dynamodb_table" "feewaiver_metadata_table" {
  name                        = "${terraform.workspace}-FeeWaiverMetaData"
  hash_key                    = "formType"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "formType"
    type = "S"
  }

  tags = local.tags
}

# resource "aws_iam_policy" "dynamoDB_policy" {
#   name_prefix = "${terraform.workspace}-dig-intake-db-"


#   policy = jsonencode({
#     Version = "2012-10-17"
#     Statement = [
#       {
#         Effect = "Allow"
#         Action = [
#           "dynamodb:GetItem",
#           "dynamodb:PutItem",
#           "dynamodb:CreateTable",
#           "dynamodb:DeleteItem",
#           "dynamodb:UpdateItem",
#           "dynamodb:Scan",
#           "dynamodb:Query",
#           "dynamodb:BatchGetItem"
#         ]
#         Resource = [aws_dynamodb_table.form_metadata_table.arn, aws_dynamodb_table.validation_status_table.arn,
#           aws_dynamodb_table.submissions_table.arn, aws_dynamodb_table.textract_job_table.arn,
#           aws_dynamodb_table.paymentAuth_table.arn, "${aws_dynamodb_table.paymentAuth_table.arn}/index/*"
#         ]
#       }
#     ]
#   })

#   tags       = local.tags
#   depends_on = [aws_dynamodb_table.form_metadata_table]
# }
