resource "aws_s3_bucket" "cloudtrail" {
    bucket = "csai-${local.workspace_lowercase}-cloudtrail-bucket"
}

resource "aws_s3_bucket_policy" "cloudtrail" {
    bucket = aws_s3_bucket.cloudtrail.id

    policy = jsonencode({
        Version = "2012-10-17"
        Statement = [
            {
                Sid = "CloudTrailAclCheck"
                Effect = "Allow"
                Principal = {Service = "cloudtrail.amazonaws.com"}
                Action = "s3:GetBucketAcl"
                Resource = aws_s3_bucket.cloudtrail.arn
            },
            {
                Sid = "CloudTrailWrite"
                Effect = "Allow"
                Principal = {Service = "cloudtrail.amazonaws.com"}
                Action = "s3:PutObject"
                Resource = "${aws_s3_bucket.cloudtrail.arn}/AWSLogs/${data.aws_caller_identity.current.account_id}/*"
                Condition = {
                    StringEquals = {
                        "s3:x-amz-acl" = "bucket-owner-full-control"
                    }
                }
            }
        ]
    })
}
