locals {
  tags = {
    Environment   = terraform.workspace
    "ECS:System"  = "CSAI/DigitalIntake"
    "ECS:FismaId" = "CIS-07773-GSS-07773"
  }
  workspace_lowercase = lower(terraform.workspace)
}

data "aws_caller_identity" "current" {}
