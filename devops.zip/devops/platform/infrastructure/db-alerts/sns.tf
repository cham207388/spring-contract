
resource "aws_sns_topic" "leads_alerts_topic" {
  name = "${terraform.workspace}-leads-alerts-topic"
  tags = local.tags
}

resource "aws_sns_topic_subscription" "lead_emails" {
  for_each = toset(["rikhin.s.bhuta@uscis.dhs.gov", "abdulrahman.o.moussa@uscis.dhs.gov"])

  topic_arn = aws_sns_topic.leads_alerts_topic.arn
  protocol  = "email"
  endpoint  = each.value
}