resource "aws_cloudtrail" "ddb_data_events" {
    name = "csai-${local.workspace_lowercase}-ddb-data-events"
    s3_bucket_name = aws_s3_bucket.cloudtrail.bucket

    is_multi_region_trail = true
    include_global_service_events = true
    enable_log_file_validation = true
    enable_logging = true

    advanced_event_selector {
        name = "DynamoDBDataEventsAllTables"

        field_selector {
            field = "eventCategory"
            equals = ["Data"]
        }
        field_selector {
            field = "eventSource"
            equals = ["dynamodb.amazonaws.com"]
        }
        field_selector {
            field = "resources.type"
            equals = ["AWS::DynamoDB::Table"]
        }
        field_selector {
            field = "resources.ARN"
            starts_with = ["arn:aws:dynamodb:"]
        }
    }
}
