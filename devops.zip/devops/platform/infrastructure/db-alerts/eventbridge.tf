data "aws_iam_policy_document" "sns_allow_eventbridge_publish" {
   statement {
     sid = "AllowEventBridgePublish"
     effect = "Allow"
     actions = ["sns:Publish"]

     principals {
       type = "Service"
       identifiers = ["events.amazonaws.com"]
     }
     resources = [ aws_sns_topic.leads_alerts_topic.arn ]
   }
}

resource "aws_sns_topic_policy" "cloudtrail_ddb_alerts" {
    arn = aws_sns_topic.leads_alerts_topic.arn
    policy = data.aws_iam_policy_document.sns_allow_eventbridge_publish.json
}



resource "aws_cloudwatch_event_rule" "cloudtrail_ddb_writes" {
    name = "csai-${local.workspace_lowercase}-cloudtrail-ddb-writes"

    event_pattern = jsonencode({
        "detail": {
            "eventSource": ["dynamodb.amazonaws.com"],
            "eventName": ["DeleteItem","BatchWriteItem"],
            "userIdentity": { "arn": [{ "prefix": "arn:aws:sts::${data.aws_caller_identity.current.account_id}:assumed-role/USCIS" }]}
        }
    })
}

resource "aws_cloudwatch_event_target" "eventbridge_to_sns" {
    rule = aws_cloudwatch_event_rule.cloudtrail_ddb_writes.name
    arn = aws_sns_topic.leads_alerts_topic.arn

      input_transformer {
    input_paths = {
      actor   = "$.detail.userIdentity.principalId"
      action  = "$.detail.eventName"
      table   = "$.detail.requestParameters.tableName"
      itemKey = "$.detail.requestParameters.key"
      time    = "$.detail.eventTime"
      region  = "$.detail.awsRegion"
    }


    input_template = <<EOF
    "ALARM: DynamoDB Mutation Detected"
    "User: <actor>"
    "Action: <action>"
    "Table: <table>"
    "Key Deleted: <itemKey>"
    "Region: <region>"
    "Time: <time>"
    "Details: A manual DeleteItem or BatchWriteItem was performed via the AWS Console."
    EOF
  }
}