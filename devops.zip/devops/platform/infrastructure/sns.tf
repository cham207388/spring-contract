data "aws_iam_policy_document" "topic_policy" {
  statement {
    sid    = "allowS3Notification"
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["s3.amazonaws.com"]
    }

    actions   = ["SNS:Publish"]
    resources = [aws_sns_topic.form_s3_topic.arn]

    condition {
      test     = "ArnLike"
      variable = "aws:SourceArn"
      values   = [aws_s3_bucket.form-staging.arn]
    }
  }
  statement {
    sid    = "allowS3EvidenceNotification"
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["s3.amazonaws.com"]
    }

    actions   = ["SNS:Publish"]
    resources = [aws_sns_topic.evidence_s3_topic.arn]

    condition {
      test     = "ArnLike"
      variable = "aws:SourceArn"
      values   = [aws_s3_bucket.evidence.arn]
    }
  }

  dynamic "statement" {
    for_each = local.should_enable_backup ? [""] : []
    content {
      sid    = "AllowBackupEventBridge"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["events.amazonaws.com"]
      }
      actions   = ["SNS:Publish"]
      resources = [aws_sns_topic.backup_alerts[0].arn]
    }
  }
}

resource "aws_sns_topic" "backup_alerts" {
  count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
  name = "${terraform.workspace}-aws-backup-alerts"
  tags = local.tags
}

resource "aws_sns_topic_policy" "backup_policy" {
  count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
  arn    = aws_sns_topic.backup_alerts[0].arn
  policy = data.aws_iam_policy_document.topic_policy.json
}

resource "aws_sns_topic_subscription" "backup_sub" {
  count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
  topic_arn = aws_sns_topic.backup_alerts[0].arn
  protocol  = "email"
  endpoint  = "Stephen.Kankam@uscis.dhs.gov"
}

resource "aws_sns_topic" "form_s3_topic" {
  name = "${terraform.workspace}-s3-notification-topic"
  tags = local.tags
}

resource "aws_sns_topic" "evidence_s3_topic" {
  name = "${terraform.workspace}-s3-evidence-notification-topic"
  tags = local.tags
}

resource "aws_sns_topic_policy" "s3-policy" {
  arn    = aws_sns_topic.form_s3_topic.arn
  policy = data.aws_iam_policy_document.topic_policy.json
}

resource "aws_sns_topic_policy" "s3-evidence-policy" {
  arn    = aws_sns_topic.evidence_s3_topic.arn
  policy = data.aws_iam_policy_document.topic_policy.json
}

resource "aws_cloudwatch_event_rule" "backup_failure" {
  count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
  name        = "${terraform.workspace}-aws-backup-failure-rule"
  description = "Triggers when aws backup job fails"
  event_pattern = jsonencode({
    source      = ["aws.backup"]
    detail-type = ["Backup Job State Change"]
    detail = {
      state = ["FAILED", "ABORTED"]
    }
  })
}

resource "aws_cloudwatch_event_target" "sns" {
  count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
  rule      = aws_cloudwatch_event_rule.backup_failure[0].name
  target_id = "SendToSNS"
  arn       = aws_sns_topic.backup_alerts[0].arn

  depends_on = [aws_cloudwatch_event_rule.backup_failure]
}

locals {
  should_enable_backup = contains(["prod", "preprod"], terraform.workspace)
}