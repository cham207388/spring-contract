

# one openid provider per eks cluster should be created outside of this module
# https://pages.git.uscis.dhs.gov/USCIS/eid-platform-eks/best-practices/irsa/
# example module for creating it at the team level
# module "iam_openid_connect_provider" {
#   source = "./oidc"
#   oidc_url = local.oidc_issuer_url
#   client_id_list = [
#     "sts.amazonaws.com",
#   ]
#   thumbprint_list = [
#     "9e99a48a9960b14926bb7f3b02e22da2b0ab7280"
#   ]
# }
# data "aws_iam_openid_connect_provider" "example" {
#   arn = local.oidc_issuer_arn[var.aws_environment]
# }


locals {
  oidc_issuer_url = {
    "prod" : "https://oidc.eks.us-east-1.amazonaws.com/id/A5D75AF4E82F9E35E7B2D2B33D69BC34",
    "nonprod" : "https://oidc.eks.us-east-1.amazonaws.com/id/4761C7466B1B3951E351BD0D47A23C29",
    "default" : "https://oidc.eks.us-east-1.amazonaws.com/id/4761C7466B1B3951E351BD0D47A23C29"
  }
   aws_iam_openid_connect_provider = {
    "prod" : "arn:aws:iam::622324437377:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/A5D75AF4E82F9E35E7B2D2B33D69BC34",
    "nonprod" : "arn:aws:iam::412097299655:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/4761C7466B1B3951E351BD0D47A23C29",
    "default" : "arn:aws:iam::412097299655:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/4761C7466B1B3951E351BD0D47A23C29"
  }
  oidc_issuer_arn = {
    "nonprod" : "arn:aws:iam::412097299655:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/4761C7466B1B3951E351BD0D47A23C29",
    "prod" : "arn:aws:iam::622324437377:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/A5D75AF4E82F9E35E7B2D2B33D69BC34",
    "default" : "arn:aws:iam::412097299655:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/4761C7466B1B3951E351BD0D47A23C29"
  }
  eks_namespace = {
    "nonprod" : "csai-dt",
    "prod" : "csai-prod",
    "default" : "csai-dt"
  }
  eks_edgeproxy_namespace = {
    "nonprod" : "csai-dt",
    "prod" : "myuscis-ext-prod",
    "default" : "csai-dt"
  }
}

variable "csai-k8s_submission_service_account_name" {
  default = "csai-intake-submission"
}

# service account name should match service name override
variable "csai-k8s_upload_service_account_name" {
  default = "csai-pdf-intake-s3"
}
variable "csai-k8s_web_service_account_name" {
  default = "csai-intake-web"
}


variable "csai-k8s_payment_service_account_name" {
  default = "csai-intake-payment-service"
}

variable "csai-k8s_admin_service_account_name" {
  default = "csai-intake-pdfiadmin"
}

variable "csai-k8s_lbg_service_account_name" {
  default = "csai-intake-gateway"
}

variable "csai-k8s_elis_payment_service_account_name" {
  default = "csai-intake-elispayment-service"
}

variable "csai-k8s_oauth_service_account_name" {
  default = "csai-oauth-server"
}

variable "csai-k8s_paygov_service_account_name" {
  default = "csai-paygov"
}

module "example_irsa_role" {
  source                               = "./irsarole"
  eks_cluster_identity_oidc_issuer_url = local.oidc_issuer_url[var.aws_environment]
  eks_cluster_identity_oidc_issuer_arn = local.aws_iam_openid_connect_provider[var.aws_environment]
  k8s_service_account_namespace        = local.eks_namespace[var.aws_environment]
  #k8s_edgeproxy_service_account_namespace  = terraform.workspace == "prod" || terraform.workspace == "preprod" ? "myuscis-ext-prod" : local.eks_namespace[var.aws_environment]
  k8s_edgeproxy_service_account_namespace  = local.eks_edgeproxy_namespace[var.aws_environment]
  k8s_service_account_name             = var.csai-k8s_submission_service_account_name
  k8s_upload_service_account_name      = var.csai-k8s_upload_service_account_name
  k8s_web_service_account_name         = var.csai-k8s_web_service_account_name
  k8s_lbg_service_account_name         = var.csai-k8s_lbg_service_account_name
  k8s_paygov_service_account_name      = var.csai-k8s_paygov_service_account_name
  k8s_oauth_service_account_name = var.csai-k8s_oauth_service_account_name
  k8s_elispayment_service_account_name = var.csai-k8s_elis_payment_service_account_name
  k8s_payment_service_account_name = var.csai-k8s_payment_service_account_name
  k8s_admin_service_account_name = var.csai-k8s_admin_service_account_name
  cluster_name                         = "pdfi" #local.csai-k8s_cluster_name[var.aws_environment]
  form_staging_bucket_arn              = aws_s3_bucket.form-staging.arn
  evidence_bucket_arn                  = aws_s3_bucket.evidence.arn
  form_backup_bucket_arn                  = aws_s3_bucket.form-backup.arn
  textract_notification_arn            = var.textract-notification_arn
}
