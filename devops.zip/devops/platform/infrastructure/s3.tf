locals {
  workspace_lowercase = lower(terraform.workspace)
}

resource "aws_s3_bucket" "form-staging" {
  bucket = "csai-${local.workspace_lowercase}-form-staging"
  tags = merge(local.tags, {
    Name = "${terraform.workspace} Form Staging"
    }
  )
}

resource "aws_s3_bucket_versioning" "form-staging-versioning" {
  bucket = aws_s3_bucket.form-staging.id
  versioning_configuration {
    status = var.enable_versioning ? "Enabled" : "Disabled"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "form-staging-bucket-config" {
  # Must have bucket versioning enabled first
  depends_on = [aws_s3_bucket_versioning.form-staging-versioning]

  bucket = aws_s3_bucket.form-staging.id

  rule {
    id = "forms"

    # noncurrent_version_expiration {
    #   noncurrent_days = 90
    # }

    noncurrent_version_transition {
      noncurrent_days = 60
      storage_class   = "STANDARD_IA"
    }

    noncurrent_version_transition {
      noncurrent_days = 90
      storage_class   = "GLACIER"
    }

    status = "Enabled"
  }
}

resource "aws_s3_bucket" "form-backup" {
  bucket = "csai-${local.workspace_lowercase}-form-backup"
  tags = merge(local.tags, {
    Name = "${terraform.workspace} Form Staging"
    }
  )
}

resource "aws_s3_bucket_notification" "form_staging" {
 count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
 bucket      = aws_s3_bucket.form-staging.id
 eventbridge = true
}

resource "aws_s3_bucket_notification" "evidence" {
 count = contains(["prod", "preprod"], terraform.workspace) ? 1 : 0
 bucket      = aws_s3_bucket.evidence.id
 eventbridge = true
}
resource "aws_s3_bucket_versioning" "form-backup-versioning" {
  bucket = aws_s3_bucket.form-backup.id
  versioning_configuration {
    status = var.enable_versioning ? "Enabled" : "Disabled"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "form-backup-bucket-config" {
  # Must have bucket versioning enabled first
  depends_on = [aws_s3_bucket_versioning.form-backup-versioning]

  bucket = aws_s3_bucket.form-backup.id

  rule {
    id = "backup"

    noncurrent_version_expiration {
      noncurrent_days = 90
    }

    status = "Enabled"
  }
}

resource "aws_s3_bucket" "evidence" {
  bucket = "csai-${local.workspace_lowercase}-evidence"

  tags = merge(local.tags, {
    Name = "${terraform.workspace} Evidence"
    }
  )
}

resource "aws_s3_bucket_versioning" "evidence-versioning" {
  bucket = aws_s3_bucket.evidence.id
  versioning_configuration {
    status = var.enable_versioning ? "Enabled" : "Disabled"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "evidence-bucket-config" {
  # Must have bucket versioning enabled first
  depends_on = [aws_s3_bucket_versioning.evidence-versioning]

  bucket = aws_s3_bucket.evidence.id

  rule {
    id = "forms"

    # noncurrent_version_expiration {
    #   noncurrent_days = 90
    # }

    noncurrent_version_transition {
      noncurrent_days = 60
      storage_class   = "STANDARD_IA"
    }

    noncurrent_version_transition {
      noncurrent_days = 90
      storage_class   = "GLACIER"
    }

    status = "Enabled"
  }
}

resource "aws_s3_bucket_cors_configuration" "form_staging_cors" {
  bucket = aws_s3_bucket.form-staging.id

  cors_rule {
    allowed_headers = ["*"]
    allowed_methods = ["PUT", "GET"]
    allowed_origins = ["*"]
    expose_headers  = []
    max_age_seconds = 3000
  }
}

resource "aws_s3_bucket_cors_configuration" "evidence_cors" {
  bucket = aws_s3_bucket.evidence.id

  cors_rule {
    allowed_headers = ["*"]
    allowed_methods = ["PUT", "GET"]
    allowed_origins = ["*"]
    expose_headers  = []
    max_age_seconds = 3000
  }
}

resource "aws_s3_bucket_notification" "bucket_notification" {
  bucket = aws_s3_bucket.form-staging.id
  topic {
    topic_arn = aws_sns_topic.form_s3_topic.arn
    events    = ["s3:ObjectCreated:*"]
  }

  # prevent: api error Notification: operation error S3: PutBucketNotificationConfiguration
  # api error InvalidArgument: Unable to validate the following destination configurations
  depends_on = [aws_sns_topic_policy.s3-policy]
}

resource "aws_s3_bucket_notification" "evidence_bucket_notification" {
  bucket = aws_s3_bucket.evidence.id
  topic {
    topic_arn = aws_sns_topic.evidence_s3_topic.arn
    events    = ["s3:ObjectCreated:*"]
  }
  # to try and prevent: api error Notification: operation error S3: PutBucketNotificationConfiguration
  # api error InvalidArgument: Unable to validate the following destination configurations
  depends_on = [aws_sns_topic_policy.s3-evidence-policy]
}