data "aws_security_group" "no_jump_box" {
  name   = "uscis_default_security_group_linux_1"
  vpc_id = var.vpc_id
}

locals {
  tags = {
    Environment   = terraform.workspace
    "ECS:System"  = "CSAI/DigitalIntake"
    "ECS:FismaId" = "CIS-07773-GSS-07773"
  }
}

module "dynamodb_alerts" {
    source = "./db-alerts"
    count = local.workspace_lowercase == "prod" ? 1 : 0
}

output "form_metadata_table" {
  value = aws_dynamodb_table.form_metadata_table
}
output "core_metadata_table" {
    value = aws_dynamodb_table.core_metadata_table
}

output "submissions_summary_table" {
    value = aws_dynamodb_table.submissions_summary_table
}

output "validation_status_table" {
    value = aws_dynamodb_table.name_validation
}

output "audit_table" {
    value = aws_dynamodb_table.audit_table
}

output "name_validation" {
    value = aws_dynamodb_table.name_validation
}



output "evidence_metadata_table" {
    value = aws_dynamodb_table.evidence_metadata_table
}

