output "textract_role_arn" {
  value = module.example_irsa_role.textract_role_arn
}

output "form_data_table_name" {
  value = aws_dynamodb_table.form_metadata_table.name
}

output "core_data_table_name" {
  value = aws_dynamodb_table.core_metadata_table.name   
}

output "evidence_data_table_name" {
  value = aws_dynamodb_table.evidence_metadata_table.name   
}

output "feewaiver_data_table_name" {
  value = aws_dynamodb_table.feewaiver_metadata_table.name   
}

output "form_staging_bucket" {
  value = aws_s3_bucket.form-staging.bucket
}

output "evidence_bucket" {
  value = aws_s3_bucket.evidence.bucket
}

output "form_backup_bucket" {
  value = aws_s3_bucket.form-backup.bucket
}

output "form_staging_bucket_arn" {
  value = aws_s3_bucket.form-staging.arn
}

output "evidence_bucket_arn" {
  value = aws_s3_bucket.evidence.arn
}

output "form_backup_bucket_arn" {
  value = aws_s3_bucket.form-backup.arn
}

output "form_s3_sns_topic_arn" {
  value = aws_sns_topic.form_s3_topic.arn
}

output "evidence_s3_sns_topic_arn" {
  value = aws_sns_topic.evidence_s3_topic.arn
}

output "form_metadata_table_arn" {
  value = aws_dynamodb_table.form_metadata_table.arn
}

output "submission_table_arn" {
  value = aws_dynamodb_table.submissions_table.arn
}

output "name_validation_table_arn" {
  value = aws_dynamodb_table.name_validation
}

output "address_validation_table_arn" {
  value = aws_dynamodb_table.address_validation
}

output "feewaiver_metadata_table_arn" {
  value = aws_dynamodb_table.feewaiver_metadata_table.arn
}

output "replay_submission_request_queue_url" {
  value = aws_sqs_queue.replay_submission_request.name
}

output "replay_submission_request_deadletter_queue_url" {
  value = aws_sqs_queue.replay_submission_request_queue_deadletter.name
}