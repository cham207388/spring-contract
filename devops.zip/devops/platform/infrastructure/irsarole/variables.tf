variable "eks_cluster_identity_oidc_issuer_url" {
  description = "The OIDC issuer of the target EKS cluster."
  type        = string
}

variable "eks_cluster_identity_oidc_issuer_arn" {
  description = "The ARN of the OIDC provider in the AWS account with the target IAM role."
  type        = string
}

variable "k8s_service_account_namespace" {
  type = string
}
variable "k8s_edgeproxy_service_account_namespace" {type = string}

variable "k8s_service_account_name" {
  type = string
}

variable "cluster_name" {
  type = string
}

variable "k8s_upload_service_account_name" {
  type = string
}
variable "k8s_web_service_account_name" {
  type = string
}
variable "k8s_lbg_service_account_name" {
  type = string
}
variable "k8s_oauth_service_account_name" {
  type = string
}
variable "k8s_payment_service_account_name" {
  type = string
}
variable "k8s_admin_service_account_name" {
  type = string
}
variable "k8s_elispayment_service_account_name" {
  type = string
}
variable "k8s_paygov_service_account_name" {
  type = string
}


variable "form_staging_bucket_arn" {
  description = "The ARN of the form-staging bucket"
  type        = string
}

variable "evidence_bucket_arn" {
  description = "The ARN of the evidence bucket"
  type        = string
}

variable "form_backup_bucket_arn" {
  description = "The ARN of the evidence bucket"
  type        = string
}

variable "textract_notification_arn" {}
