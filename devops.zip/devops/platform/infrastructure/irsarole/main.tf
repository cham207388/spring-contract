data "aws_caller_identity" "current" {}

locals {
  oidc_issuer_hostpath = substr(var.eks_cluster_identity_oidc_issuer_url, 8, -1)
}

data "aws_iam_policy_document" "textract-s3" {
  statement {
    effect = "Allow"

    actions = [
      "s3:*"
    ]

    resources = ["${var.form_staging_bucket_arn}", "${var.form_staging_bucket_arn}/*"]
  }
}


resource "aws_iam_policy" "textract_s3" {
  name_prefix = "${var.cluster_name}-textract-s3"
  path        = "/"
  description = "IAM policy for textract s3"
  policy      = data.aws_iam_policy_document.textract-sns.json
}

data "aws_iam_policy_document" "textract-sns" {
  statement {
    effect = "Allow"

    actions   = ["SNS:Publish"]
    resources = [var.textract_notification_arn]
  }
}

resource "aws_iam_policy" "textract_sns" {
  name_prefix = "${var.cluster_name}-textract-sns"
  path        = "/"
  description = "IAM policy for textract sns"
  policy      = data.aws_iam_policy_document.textract-sns.json
}

data "aws_iam_policy_document" "current" {
  statement {
    actions = [
      "dynamodb:*",
    ] 
    resources = ["arn:aws:dynamodb:*:${data.aws_caller_identity.current.account_id}:table/*", "arn:aws:dynamodb:*:${data.aws_caller_identity.current.account_id}:table/*/index/*"]
  }
  statement {
    actions = [
      "sqs:*",
    ]
    resources = [
      "arn:aws:sqs:us-east-1:*:*"
    ]
  }
  statement {
    actions = [
      "sns:*",
    ]

    resources = [
      "arn:aws:sns:us-east-1:*:*"
    ]
  }
  statement {
    actions = [
      "s3:PutObject",
      "s3:GetObject",
      "s3:AbortMultipartUpload",
      "s3:ListBucket",
      "s3:DeleteObject",
      "s3:GetObjectVersion",
      "s3:ListMultipartUploadParts"
    ]
    resources = [ var.form_staging_bucket_arn, "${var.form_staging_bucket_arn}/*", var.evidence_bucket_arn, "${var.evidence_bucket_arn}/*", var.form_backup_bucket_arn, "${var.form_backup_bucket_arn}/*" ]
  }


  statement {
    actions = [
      "textract:StartDocumentAnalysis",
      "textract:GetDocumentAnalysis"
    ]
    resources = ["*"]
  }
}

data "aws_iam_policy_document" "lockbox_gateway" {
  statement {
    actions = [
      "dynamodb:*",
    ] 
    resources = ["arn:aws:dynamodb:*:${data.aws_caller_identity.current.account_id}:table/*", "arn:aws:dynamodb:*:${data.aws_caller_identity.current.account_id}:table/*/index/*"]
  }
  statement {
    actions = [
      "mq:*",
    ] 
    resources = ["arn:aws:mq:us-east-1:${data.aws_caller_identity.current.account_id}:broker:pdf-intake-nonprod:*"]
  }
  # statement {
  #   actions = [
  #     "ec2:*",
  #   ] 
  #   resources = ["*"]
  # }
  statement {
    actions = [
      "logs:*",
      "cloudwatch:PutMetricData"
    ] 
    resources = ["*"]
  }
}

resource "aws_iam_policy" "lockbox_gateway" {
  name_prefix = "${var.cluster_name}-lockbox_gateway"
  path        = "/"
  description = "IAM policy for dynamodb"
  policy      = data.aws_iam_policy_document.lockbox_gateway.json
}
resource "aws_iam_role" "lbg" {
  name        = "${var.cluster_name}-lbg-role-${terraform.workspace}"
  description = "IAM role for lockbox gateway service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_service_account_namespace}:${var.k8s_lbg_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-lbg-role"
  }
}

resource "aws_iam_role_policy_attachment" "lbg" {
  role       = aws_iam_role.lbg.name
  policy_arn = aws_iam_policy.lockbox_gateway.arn
}

data "aws_iam_policy_document" "paygov" {
  statement {
    actions = [
      "dynamodb:*",
    ] 
    resources = ["arn:aws:dynamodb:*:${data.aws_caller_identity.current.account_id}:table/*", "arn:aws:dynamodb:*:${data.aws_caller_identity.current.account_id}:table/*/index/*"]
  }
}

resource "aws_iam_policy" "paygov" {
  name_prefix = "${var.cluster_name}-paygov"
  path        = "/"
  description = "IAM policy for PayGov mock"
  policy      = data.aws_iam_policy_document.paygov.json
}

resource "aws_iam_role" "paygov" {
  name        = "${var.cluster_name}-paygov-role-${terraform.workspace}"
  description = "IAM role for PayGov mock service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_service_account_namespace}:${var.k8s_paygov_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-paygov-role"
  }
}

resource "aws_iam_role_policy_attachment" "paygov" {
  role       = aws_iam_role.paygov.name
  policy_arn = aws_iam_policy.paygov.arn
}


resource "aws_iam_policy" "current" {
  name_prefix = "${var.cluster_name}-object-storage"
  path        = "/"
  description = "IAM policy for dynamodb, s3, textract, and sqs"
  policy      = data.aws_iam_policy_document.current.json
}

resource "aws_iam_role" "doc" {
  name        = "${var.cluster_name}-ss-role-${terraform.workspace}"
  description = "IAM role for document service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_service_account_namespace}:${var.k8s_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-doc-role"
  }
}

resource "aws_iam_role_policy_attachment" "doc" {
  role       = aws_iam_role.doc.name
  policy_arn = aws_iam_policy.current.arn
}

resource "aws_iam_role" "upload" {
  name        = "${var.cluster_name}-upload-role-${terraform.workspace}"
  description = "IAM role for upload service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_service_account_namespace}:${var.k8s_upload_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-upload-role"
  }
}

resource "aws_iam_role_policy_attachment" "upload" {
  role       = aws_iam_role.upload.name
  policy_arn = aws_iam_policy.current.arn
}

resource "aws_iam_role" "web" {
  name        = "${var.cluster_name}-web-role-${terraform.workspace}"
  description = "IAM role for web service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_edgeproxy_service_account_namespace}:${var.k8s_web_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-edgeproxy-role"
  }
}

resource "aws_iam_role_policy_attachment" "web" {
  role       = aws_iam_role.web.name
  policy_arn = aws_iam_policy.current.arn
}

resource "aws_iam_role" "textract" {
  name        = "${var.cluster_name}-textract-role-${terraform.workspace}"
  description = "IAM role for textract service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_service_account_namespace}:${var.k8s_web_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-textract-role"
  }
}

resource "aws_iam_role_policy_attachment" "textract_current" {
  role       = aws_iam_role.textract.name
  policy_arn = aws_iam_policy.current.arn
}

resource "aws_iam_role" "oauth" {
  name        = "${var.cluster_name}-oauth-role-${terraform.workspace}"
  description = "IAM role for oauth service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_service_account_namespace}:${var.k8s_oauth_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-web-role"
  }
}

resource "aws_iam_role_policy_attachment" "oauth" {
  role       = aws_iam_role.oauth.name
  policy_arn = aws_iam_policy.current.arn
}

resource "aws_iam_role" "payment" {
  name        = "${var.cluster_name}-payment-role-${terraform.workspace}"
  description = "IAM role for payment service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_service_account_namespace}:${var.k8s_payment_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-web-role"
  }
}

resource "aws_iam_role_policy_attachment" "payment" {
  role       = aws_iam_role.payment.name
  policy_arn = aws_iam_policy.current.arn
}

resource "aws_iam_role" "admin" {
  name        = "${var.cluster_name}-admin-role-${terraform.workspace}"
  description = "IAM role for admin service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_service_account_namespace}:${var.k8s_admin_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-web-role"
  }
}

resource "aws_iam_role_policy_attachment" "admin" {
  role       = aws_iam_role.admin.name
  policy_arn = aws_iam_policy.current.arn
}

resource "aws_iam_role" "elis_payment" {
  name        = "${var.cluster_name}-elispmt-role-${terraform.workspace}"
  description = "IAM role for elis payment service account"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "${var.eks_cluster_identity_oidc_issuer_arn}"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "${local.oidc_issuer_hostpath}:sub": "system:serviceaccount:${var.k8s_service_account_namespace}:${var.k8s_elispayment_service_account_name}-${terraform.workspace}",
          "${local.oidc_issuer_hostpath}:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
EOF

  tags = {
    Name = "${var.cluster_name}-web-role"
  }
}

resource "aws_iam_role_policy_attachment" "elispayment" {
  role       = aws_iam_role.elis_payment.name
  policy_arn = aws_iam_policy.current.arn
}