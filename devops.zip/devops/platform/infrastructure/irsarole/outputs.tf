
output "policy_arn" {
  value = aws_iam_policy.current.arn
}

output "doc_role_arn" {
  value = aws_iam_role.doc.arn
}

output "web_role_arn" {
  value = aws_iam_role.web.arn
}

output "upload_role_arn" {
  value = aws_iam_role.upload.arn
}

output "textract_role_arn" {
  value = aws_iam_role.textract.arn
}