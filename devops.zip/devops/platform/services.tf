module "edge_proxy" {
  source = "../../services/edge-proxy/devops/terraform/app"
  eks_context = var.eks_edgeproxy_context
  values_environment = var.values_environment
  tags   = local.tags
  helm_values_path = "../../services/edge-proxy/helm-values/${var.values_environment}-env-values.yaml"
  chart_path_or_name = var.edge_chart_path_or_name
  chart_repository = var.chart_repository
  helm_chart_version = var.edge_chart_version
  submission_service_url = var.submission_service_url
  payment_service_url = var.payment_service_url
  kubernetes_edgeproxy_namespace = var.kubernetes_edgeproxy_namespace
  image_tag = var.edge_proxyimage_tag
  nameOverride = "csai-intake-edge-${terraform.workspace}"
  fullnameOverride = "csai-intake-edge-${terraform.workspace}"
  ap_oidc_client_id = var.ap_oidc_client_id
  ap_oidc_client_secret = var.ap_oidc_client_secret
  myuscis_encoded_key = var.myuscis_encoded_key
  myuscis_encoded_cert = var.myuscis_encoded_cert
  eks_edgeproxy_domain = var.eks_edgeproxy_domain
  base_url = var.edge_base_url
  oauth_url = var.mock_oauth_url
  helm_history_max = var.helm_history_max
  jwt_secret_name = var.jwt_secret_name
  jwt_public_key = var.jwt_public_key
  jwt_private_key = var.jwt_private_key
  new_relic_license_key = var.new_relic_license_key
  app_version = var.app_version
  usergroupservice_username = var.usergroupservice_username
  usergroupservice_password = var.usergroupservice_password
}

module "submission_service" {
  source = "../../services/submission-service/devops/terraform/app"
  eks_context = var.eks_default_context
  s3_buckets_form = module.infrastructure.form_staging_bucket
  s3_buckets_evidence = module.infrastructure.evidence_bucket
  s3_buckets_backup = module.infrastructure.form_backup_bucket
  sqs_validation_queueUrl = module.validation_lambdas.validation_results_queue
  sqs_validation_field_queueUrl = module.validation_lambdas.field_validation_results_queue
  sqs_validation_eligibility_queueUrl = module.eligibility_validation_lambda.eligibility_validation_results_queue
  sqs_validation_name_queueUrl = module.name_validation_lambda.name_validation_results_queue
  sqs_validation_address_queueUrl = module.address_validation_lambda.address_validation_results_queue
  sqs_elis_validation_request_queueUrl = module.validation_lambdas.elis_validation_request_queue
  sqs_elis_validation_response_queueUrl = module.validation_lambdas.elis_validation_response_queue
  sqs_elis_esign_request_queueUrl = module.validation_lambdas.elis_esign_request_queue
  sqs_elis_evidence_validation_request_queueUrl = module.validation_lambdas.elis_evidence_validation_request_queue
  sqs_elis_evidence_validation_response_queueUrl = module.validation_lambdas.elis_evidence_validation_response_queue
  sqs_validation_client_name_email_queueUrl = module.client_name_email_validation_lambda.client_name_email_validation_results_queue
  sqs_validation_attorney_name_queueUrl = module.attorney_name_validation_lambda.attorney_name_validation_results_queue
  sqs_validation_person_queueUrl = module.person_validation_lambda.person_validation_results_queue
  sqs_i912_validation_queue_url = module.I912_validation_lambda.i912_validation_results_queue
  sqs_replay_submission_queue_url = module.infrastructure.replay_submission_request_queue_url
  values_environment = var.values_environment
  tags   = local.tags
  helm_values_path = "../../services/submission-service/helm-values/${var.values_environment}-env-values.yaml"
  chart_path_or_name = var.submission_chart_path_or_name
  chart_repository = var.chart_repository
  helm_chart_version = var.submission_chart_version
  lockbox_gw_url = var.lockbox_gw_url
  downloader_url = var.downloader_url
  payment_service_url = var.payment_service_url
  peeps_url = var.peeps_url
  usergroupservice_url = var.usergroupservice_url
  accountsdata_url = var.accountsdata_url
  kubernetes_namespace = var.kubernetes_namespace
  image_tag = var.submission_service_image_tag
  eks_domain = var.eks_domain
  nameOverride = "csai-intake-submission-${terraform.workspace}"
  fullnameOverride = "csai-intake-submission-${terraform.workspace}"
  elisApiEncodedJks = var.elisApiEncodedJks
  eks-domain = var.eks_domain
  helm_history_max = var.helm_history_max
  jwt_public_key = var.jwt_public_key
  peeps_username = var.peeps_username
  peeps_password = var.peeps_password
  usergroupservice_username = var.usergroupservice_username
  usergroupservice_password = var.usergroupservice_password
  accountsdata_username = var.accountsdata_username
  accountsdata_password = var.accountsdata_password
  cacheupdate_username = var.cacheupdate_username
  cacheupdate_password = var.cacheupdate_password
  draftbenefits_username = var.draftbenefits_username
  draftbenefits_password = var.draftbenefits_password
  new_relic_license_key = var.new_relic_license_key
  postgres_password = module.payment.database_password
  postgres_url = module.payment.database_url
}

module "validation_orchestrator_lambda" {
  source = "../../lambdas/orchestrator/devops/terraform/app"

  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  form_s3_sns_topic_arn = module.infrastructure.form_s3_sns_topic_arn
  evidence_s3_sns_topic_arn = module.infrastructure.evidence_s3_sns_topic_arn
  jar = var.orchestrator_validator_jar
  tags   = local.tags
  aws_environment = var.aws_environment
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  s3_bucket_evidence_arn = module.infrastructure.evidence_bucket_arn
}

module "validation_lambdas" {
  source = "../../lambdas/validators/devops/terraform/app"
  submission_service_url = module.submission_service.url
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  s3_bucket_evidence = module.infrastructure.evidence_bucket
  s3_bucket_evidence_arn = module.infrastructure.evidence_bucket_arn
  form_s3_sns_topic_arn = module.infrastructure.form_s3_sns_topic_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  jar = var.validators_jar
  tags   = local.tags
  aws_environment = var.aws_environment
  sqs_saturation_email_list = compact(split(",", var.sqs_saturation_email_list))
}

module "validation_lambdas_i797" {
  source = "../../lambdas/evidence-validators/i797CValidator/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  s3_bucket_evidence = module.infrastructure.evidence_bucket
  s3_bucket_evidence_arn = module.infrastructure.evidence_bucket_arn
  form_s3_sns_topic_arn = module.infrastructure.form_s3_sns_topic_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  jar = var.i797c_validator_jar
  valiation_result_queue_arn = module.validation_lambdas.validation_results_queue_arn
  valiation_result_queue_id = module.validation_lambdas.validation_results_queue_id
  validation_dispatch_topic_arn = module.validation_orchestrator_lambda.validation_dispatch_topic_arn
  tags   = local.tags
  textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
  aws_environment = var.aws_environment
}

module "I912_validation_lambda" {
  source = "../../lambdas/evidence-validators/I912Validator/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  s3_bucket_evidence = module.infrastructure.evidence_bucket
  s3_bucket_evidence_arn = module.infrastructure.evidence_bucket_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  feewaiver_metadata_table_arn = module.infrastructure.feewaiver_metadata_table_arn
  jar = var.I912Validator_jar
  tags   = local.tags
  validation_dispatch_topic_arn = module.validation_orchestrator_lambda.validation_dispatch_topic_arn
  textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
  aws_environment = var.aws_environment
}
module "signature_validation_lambda" {
  source = "../../lambdas/form-validators/signatureValidator/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  jar = var.signature_validator_jar
  tags   = local.tags
  validation_result_queue_arn = module.validation_lambdas.validation_results_queue_arn
  validation_result_queue_id = module.validation_lambdas.validation_results_queue_id
  signature_validation_dispatch_topic_arn = module.validation_lambdas.signature_validation_dispatch_topic_arn
  textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
  aws_environment = var.aws_environment
}
module "person_validation_lambda" {
  source = "../../lambdas/form-validators/personValidator/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  jar = var.person_validator_jar
  tags   = local.tags
  person_validation_dispatch_topic_arn = module.validation_lambdas.person_validation_dispatch_topic_arn
  textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
  aws_environment = var.aws_environment
}

module "eligibility_validation_lambda" {
  source = "../../lambdas/form-validators/eligibilityValidator/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  jar = var.eligibility_validator_jar
  tags   = local.tags
  eligibility_validation_dispatch_topic_arn = module.validation_lambdas.eligibility_validation_dispatch_topic_arn
  textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
  aws_environment = var.aws_environment
}

module "name_validation_lambda" {
  source = "../../lambdas/form-validators/nameValidator/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  jar = var.name_validator_jar
  tags   = local.tags
  name_validation_dispatch_topic_arn = module.validation_lambdas.name_validation_dispatch_topic_arn
  textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
  aws_environment = var.aws_environment
}
module "address_validation_lambda" {
  source = "../../lambdas/form-validators/addressValidator/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  jar = var.address_validator_jar
  tags   = local.tags
  address_validation_dispatch_topic_arn = module.validation_lambdas.address_validation_dispatch_topic_arn
  textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
  aws_environment = var.aws_environment
}

module "client_name_email_validation_lambda" {
  source = "../../lambdas/form-validators/clientNameEmailValidator/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  jar = var.client_name_email_validator_jar
  tags   = local.tags
  client_name_email_validation_dispatch_topic_arn = module.validation_lambdas.client_name_email_validation_dispatch_topic_arn
  textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
  aws_environment = var.aws_environment
}

module "attorney_name_validation_lambda" {
  source = "../../lambdas/form-validators/attorneyNameValidator/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form = module.infrastructure.form_staging_bucket
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
  jar = var.attorney_name_validator_jar
  tags   = local.tags
  attorney_name_validation_dispatch_topic_arn = module.validation_lambdas.attorney_name_validation_dispatch_topic_arn
  textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
  aws_environment = var.aws_environment
}

module "validation_lambdas_migrator" {
  source = "../../lambdas/data-migration-lambda/devops/terraform/app"
  no_jump_box_sg_id = data.aws_security_group.no_jump_box.id
  subnet_id = data.aws_subnets.subnets.ids[0]
  s3_bucket_form_arn = module.infrastructure.form_staging_bucket_arn
  s3_bucket_evidence_arn = module.infrastructure.evidence_bucket_arn
  submission_table_arn = module.infrastructure.submission_table_arn
  jar = var.migrator_jar
  validation_dispatch_topic_arn = module.validation_orchestrator_lambda.validation_dispatch_topic_arn
  tags   = local.tags
  aws_environment = var.aws_environment
  validation_status_table_arn = module.submission_service.validation_status_table_arn
}


module "lockbox_gateway" {
  source = "../../services/lockbox-gateway/devops/terraform/app"
  eks_context = var.eks_default_context
  values_environment = var.values_environment
  tags   = local.tags
  helm_values_path = "../../services/lockbox-gateway/helm-values/${var.values_environment}-env-values.yaml"
  chart_path_or_name = var.gateway_chart_path_or_name
  chart_repository = var.chart_repository
  helm_chart_version = var.edge_chart_version
  submission_service_url = var.submission_service_url
  paymentservice_url = var.payment_service_url
  kubernetes_namespace = var.kubernetes_namespace
  image_tag = var.lockbox_gateway_image_tag
  eks_domain = var.eks_domain
  nameOverride = "csai-intake-gateway-${terraform.workspace}"
  fullnameOverride = "csai-intake-gateway-${terraform.workspace}"
  amqKeystore = var.amqKeystore
  amqKeystorePassword = var.amqKeystorePassword
  amqTrustStorePassword = var.amqTrustStorePassword
  brokerUrl = var.brokerUrl
  secondaryBrokerUrl = var.secondaryBrokerUrl
  ternaryBrokerUrl = var.ternaryBrokerUrl
  amqPassword = var.amqPassword
  helm_history_max = var.helm_history_max
  new_relic_license_key = var.new_relic_license_key

  amqQueuePrefix = !contains(["prod", "preprod", "sint", "dev"],terraform.workspace) ? "${terraform.workspace}." : ""

}

module "downloader" {
  source = "../../services/pdf-intake-s3/devops/terraform/app"
  eks_context = var.eks_default_context
  values_environment = var.values_environment
  helm_values_path = "../../services/pdf-intake-s3/helm-values/${var.values_environment}-env-values.yaml"
  chart_path_or_name = var.downloader_chart_path_or_name
  chart_repository = var.chart_repository
  helm_chart_version = var.downloader_chart_version
  kubernetes_namespace = var.kubernetes_namespace
  image_tag = var.image_tag
  eks_domain = var.eks_domain
  s3_buckets_form = module.infrastructure.form_staging_bucket
  s3_buckets_evidence = module.infrastructure.evidence_bucket
  nameOverride = "csai-pdf-intake-s3-${terraform.workspace}"
  fullnameOverride = "csai-pdf-intake-s3-${terraform.workspace}"
  helm_history_max = var.helm_history_max
  new_relic_license_key = var.new_relic_license_key
  s3_bucket_owner = var.s3_bucket_owner
}

module "payment" {
  source = "../../services/payment-service/devops"
  eks_context = var.eks_default_context
  values_environment = var.values_environment
  helm_values_path = "../../services/payment-service/helm-values/${var.values_environment}-env-values.yaml"
  chart_path_or_name = var.payment_chart_path_or_name
  chart_repository = var.chart_repository
  helm_chart_version = var.payment_chart_version
  kubernetes_namespace = var.kubernetes_namespace
  image_tag = var.payment_service_image_tag
  eks_domain = var.eks_domain
  nameOverride = "csai-intake-payment-${terraform.workspace}"
  fullnameOverride = "csai-intake-payment-${terraform.workspace}"
  tags = local.tags
  db_enable_deletion_protection = terraform.workspace == "prod" ? true : false
  subnet_ids = data.aws_subnets.subnets.ids
  ec2_scheduler = "default"
  vpc_id = data.aws_vpc.vpc.id
  elisApiKeystorePath = var.elisApiEncodedJks
  elisPaymentUrl = var.elis_payment_url
  helm_history_max = var.helm_history_max
  new_relic_license_key = var.new_relic_license_key
  backup_retention_period = var.backup_retention_period
  uscis_submission_url = var.uscis_submission_url
}

module "admin_service" {
  source = "../../services/admin/devops/terraform/app"
  eks_context = var.eks_default_context
  s3_buckets_form = module.infrastructure.form_staging_bucket
  s3_buckets_evidence = module.infrastructure.evidence_bucket
  tags   = local.tags
  helm_values_path = "../../services/admin/helm-values/${var.values_environment}-env-values.yaml"
  chart_path_or_name = var.admin_chart_path_or_name
  chart_repository = var.chart_repository
  helm_chart_version = var.admin_chart_version
  kubernetes_namespace = var.kubernetes_namespace
  image_tag = var.admin_service_image_tag
  eks_domain = var.eks_domain
  nameOverride = "csai-intake-pdfiadmin-${terraform.workspace}"
  fullnameOverride = "csai-intake-pdfiadmin-${terraform.workspace}"
  helm_history_max = var.helm_history_max
  pdfiadminpassword = var.pdfiadminpassword
  sqs_elis_validation_request_queueUrl = module.validation_lambdas.elis_validation_request_queue
  sqs_elis_validation_response_queueUrl = module.validation_lambdas.elis_validation_response_queue
  submission_service_url = var.uscis_submission_url
##  sqs_elis_evidence_validation_request_queueUrl = module.validation_lambdas.elis_evidence_validation_request_queue
##  sqs_elis_evidence_validation_response_queueUrl = module.validation_lambdas.elis_evidence_validation_response_queue
}

module "paygov_mock" {
  count = !contains(["prod", "preprod", "perf", "sint"], terraform.workspace) ? 1 : 0
  source = "../../tools/test-doubles/paygov/devops/terraform/app"

  values_environment = var.values_environment
  helm_values_path = "../../tools/test-doubles/paygov/helm-values/${var.values_environment}-env-values.yaml"
  chart_repository = var.chart_repository
  chart_path_or_name = var.paygov_service_chart_path_or_name
  helm_chart_version = var.paygov_service_chart_version
  kubernetes_namespace = var.kubernetes_namespace
  image_tag = var.paygov_service_image_tag
  eks_domain = var.eks_domain
  nameOverride = "csai-paygov-${terraform.workspace}"
  fullnameOverride = "csai-paygov-${terraform.workspace}"
  successUrl="${var.elis_payment_url}/public/pay/complete"
  cancelUrl="${var.elis_payment_url}/public/pay/cancel"
  helm_history_max = var.helm_history_max
  tags = local.tags
}

module "elis_payment" {
  count = !contains(["prod", "preprod", "perf", "sint"], terraform.workspace) ? 1 : 0
  source = "../../tools/third-party/elis-payment/devops/terraform/app"
  
  values_environment = var.values_environment
  helm_values_path = "../../tools/third-party/elis-payment/helm-values/${var.values_environment}-env-values.yaml"
  chart_repository = var.chart_repository
  chart_path_or_name = var.elis_service_chart_path_or_name
  helm_chart_version = var.elis_service_chart_version
  kubernetes_namespace = var.kubernetes_namespace
  image_tag = var.elis_service_image_tag
  eks_domain = var.eks_domain
  nameOverride = "csai-elis-payment-${terraform.workspace}"
  fullnameOverride = "csai-elis-payment-${terraform.workspace}"
  tcs_redirect = "${var.paygov_url}/makeTCSPayment/tcsForm/index.html"
  tcs_ws = "${var.paygov_url}/services/TCSOnlineService"
  tcs_single_ws = "${var.paygov_url}/services/TCSSingleService"
  tcs_confirm_url = "${var.elis_payment_url}/public/pay/complete"
  tcs_cancel_url = "${var.elis_payment_url}/public/pay/cancel"
  helm_history_max = var.helm_history_max
}


module "lockbox_test_double" {

  count = !contains(["prod", "preprod", "perf", "sint"], terraform.workspace) ? 1 : 0
  source = "../../tools/test-doubles/lockbox/devops/terraform/app"
  helm_values_path = "../../tools/test-doubles/lockbox/helm-values/${var.values_environment}-env-values.yaml"

  chart_path_or_name = var.lockbox_test_double_chart_path_or_name
  helm_chart_version = var.lockbox_test_double_chart_version
  image_tag = var.lockbox_test_double_image_tag

  values_environment = var.values_environment
  chart_repository = var.chart_repository
  kubernetes_namespace = var.kubernetes_namespace
  eks_domain = var.eks_domain
  nameOverride = "csai-lockbox-test-double-${terraform.workspace}"
  fullnameOverride = "csai-lockbox-test-double-${terraform.workspace}"
  helm_history_max = var.helm_history_max

  springActiveMqBrokerUrl = var.brokerUrl
  springActiveMqUser = "ExampleUser"
  springActiveMqPassword = var.amqPassword

  amqQueuePrefix = !contains(["prod", "preprod", "sint", "dev"],terraform.workspace) ? "${terraform.workspace}." : ""

}

module "peeps_test_double" {
  count = !contains(["prod", "preprod", "perf", "sint"], terraform.workspace) ? 1 : 0
  nameOverride = "csai-peeps-test-double-${terraform.workspace}"
  fullnameOverride = "csai-peeps-test-double-${terraform.workspace}"
  source = "../../tools/test-doubles/mock-server/devops/terraform"
  initializationJsonPath = "static/peeps/*"
  chart_repository = var.chart_repository
  chart_path_or_name = var.mockserver_service_chart_path_or_name
  helm_chart_version = var.mockserver_service_chart_version
  kubernetes_namespace = var.kubernetes_namespace
  eks_domain = var.eks_domain
  helm_history_max = var.helm_history_max
}

module "user_group_service_test_double" {
  count = !contains(["prod", "preprod", "perf", "sint"], terraform.workspace) ? 1 : 0
  nameOverride = "usergroupservice-test-double-${terraform.workspace}"
  fullnameOverride = "usergroupservice-test-double-${terraform.workspace}"
  source = "../../tools/test-doubles/mock-server/devops/terraform"
  initializationJsonPath = "static/user-group-service/*"
  chart_repository = var.chart_repository
  chart_path_or_name = var.mockserver_service_chart_path_or_name
  helm_chart_version = var.mockserver_service_chart_version
  kubernetes_namespace = var.kubernetes_namespace
  eks_domain = var.eks_domain
  helm_history_max = var.helm_history_max
}

module "backup" { 
    source= "./backup"
    #count = contains(["dev"], terraform.workspace) ? 1 : 0
    validation_status_table_arn =   module.submission_service.validation_status_table_arn
    client_information_table_arn = module.submission_service.client_information_table_arn 
    textract_job_status_table_arn = module.validation_lambdas.textract_job_status_table_arn
    submission_table_arn = module.infrastructure.submission_table_arn
    form_metadata_table_arn = module.infrastructure.form_metadata_table_arn
    submissions_summary_table_arn = module.infrastructure.submissions_summary_table.arn
    core_metadata_table_arn = module.infrastructure.core_metadata_table.arn
    evidence_metadata_table_arn = module.infrastructure.evidence_metadata_table.arn
    feewaiver_metadata_table_arn = module.infrastructure.feewaiver_metadata_table_arn
    name_validation_arn = module.infrastructure.name_validation.arn
    audit_table_arn = module.infrastructure.audit_table.arn
    address_extract_table_arn =  module.infrastructure.address_validation_table_arn
    rds_instance_arn = module.payment.database_arn
    backup_bucket_arns = [module.infrastructure.form_staging_bucket_arn, module.infrastructure.evidence_bucket_arn]
}


# module "mock_oauth" {
#   count = !contains(["prod", "preprod", "perf", "sint"], terraform.workspace) ? 1 : 0
#   source = "../../tools/test-doubles/cis-mock-oauth-server/devops/terraform/app"
#   values_environment = var.values_environment
#   helm_values_path = "../../tools/test-doubles/cis-mock-oauth-server/helm-values/${var.values_environment}-env-values.yaml"
#   chart_path_or_name = var.oauth_service_chart_path_or_name
#   chart_repository = var.chart_repository
#   helm_chart_version = var.oauth_service_chart_version
#   kubernetes_namespace = var.kubernetes_namespace
#   image_tag = var.oauth_service_image_tag
#   eks_domain = var.eks_domain
#   nameOverride = "csai-mock-oauth-${terraform.workspace}"
#   fullnameOverride = "csai-mock-oauth-${terraform.workspace}"
# }
