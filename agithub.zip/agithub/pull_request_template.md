# PR Template Review

- https://maestro.dhs.gov/jira/browse/CSAI-{number}

## Notes/Brief Description

### Problem

### Approach

## Screenshots (including of SonarQube coverage):

## Steps to test

## Security Considerations (if applicable):

## Explanation for foregoing pre-prod deployment (if applicable)

## Author Checklist

- [ ] Checked that all acceptance criteria are met.
- [ ] Tested deliverable in PR environment.
- [ ] If tested in PR, add screenshots.
- [ ] Tested for 508 compliance (applicable to UI changes).
- [ ] Updated appropriate project documentation (applicable to new API endpoints or system components).
- [ ] Included appropriate unit test coverage.
- [ ] Provided screenshot of local journey test successful run.
- [ ] Prepared quick dev demo and short walkthrough.
- [ ] The scope of the work has not changed after this PR was created.
- [ ] Will deploy changes to pre-prod -OR- provide explanation of why deploying to pre-prod is unnecessary.
- [ ] Will update the ticket to QA review when this PR is ready to be tested.

## Reviewer Checklist

- [ ] Checked that the commit message is formatted correctly (e.g., "CSAI-4321: Explain what your commit does.").
- [ ] Checked for style and readability.
- [ ] Checked that implementation follows programming best practices (e.g., using design patters, avoiding risky capabilities) and solves the right problem. 
- [ ] Checked that integration doesn't raise security or resource concerns.
- [ ] Scheduled a demo with the author -OR- tested feature in PR build.
- [ ] If issues needed to be addressed, communicated clear direction.
- [ ] Addressed security considerations - spot check (e.g., PII appropriately encrypted, acquired appropriate certs, no hardcoded keys).
- [ ] Checked SonarQube that there are no uncovered lines.
- [ ] Checked journey test success screenshot.
