#!/usr/bin/env bash
# Append manifest-derived values to GITHUB_OUTPUT (GitHub Actions).
set -euo pipefail
JSON="${1:-deploy_artifacts/release-manifest.json}"
{
  echo "EDGE_HASH=$(jq -r '."edge-proxy".semantic_tag' "$JSON")"
  echo "S3_DOWNLOADER_HASH=$(jq -r '."pdf-intake-s3".semantic_tag' "$JSON")"
  echo "SUBMISSION_HASH=$(jq -r '."submission-service".semantic_tag' "$JSON")"
  echo "GATEWAY_HASH=$(jq -r '."lockbox-gateway".semantic_tag' "$JSON")"
  echo "PAYMENT_HASH=$(jq -r '."payment-service".semantic_tag' "$JSON")"
  echo "ADMIN_HASH=$(jq -r '."admin".semantic_tag' "$JSON")"
  echo "PAYGOV_HASH=$(jq -r '."paygov-testdouble".semantic_tag' "$JSON")"
  echo "OAUTH_HASH=1.0"
  echo "ELIS_PAYMENT_TAG=pr-1.3.18"
  echo "LOCKBOX_TESTDOUBLE_HASH=$(jq -r '."lockbox-testdouble".semantic_tag' "$JSON")"
} >>"$GITHUB_OUTPUT"