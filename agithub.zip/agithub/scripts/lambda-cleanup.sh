#!/usr/bin/env bash
# lambda-cleanup.sh
# Usage: ./lambda-cleanup.sh <env1> [env2] ... [region]
# Example: ./lambda-cleanup.sh dev to clean up dev
# Example: ./lambda-cleanup.sh dev,sint to clean up dev and sint
set -euo pipefail

if [[ $# -eq 0 ]]; then
  echo "Usage: $0 <env1> [env2] ... [region]"
  exit 1
fi

REGION="${AWS_REGION:-us-east-1}"
last_arg="${!#}"

# Check if the last argument looks like a region (e.g., us-east-1)
if [[ "$last_arg" =~ ^[a-z]{2}(-[a-z]+)+-[0-9]$ ]]; then
  REGION="$last_arg"
  # Use all arguments except the last one as environments
  if [[ $# -gt 1 ]]; then
    set -- "${@:1:$(($#-1))}"
  else
    echo "Error: No environment specified."
    exit 1
  fi
fi

# Join arguments with pipe and replace commas with pipes
IFS="|"
ENV_PATTERN="$*"
ENV_PATTERN="${ENV_PATTERN//,/|}"
unset IFS

VERSIONS_FILE="lambda-versions.txt"

log() { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }

log "Region: $REGION | Filter: $ENV_PATTERN"
log "Step 1/4: Listing Lambda versions -> $VERSIONS_FILE"

: > "$VERSIONS_FILE"
aws lambda list-functions --region "$REGION" \
| jq -r '.Functions[].FunctionName' \
| grep -E -w "$ENV_PATTERN" \
| while IFS= read -r FN; do
    aws lambda list-versions-by-function --region "$REGION" --function-name "$FN" \
    | jq -r '.Versions[] | "\(.FunctionName):\(.Version)"'
  done >> "$VERSIONS_FILE"

log "Step 2/4: Removing \$LATEST markers"
sed 's/\$LATEST//g' "$VERSIONS_FILE" > "${VERSIONS_FILE}.tmp" && mv "${VERSIONS_FILE}.tmp" "$VERSIONS_FILE"

log "Step 3/4: Dropping base (NAME:) and each function's largest version"
CLEANED_FILE="$(mktemp)"
awk -F: '
  {
    name=$1; ver=$2
    if (ver=="") next                       # skip base line (NAME:)
    if (ver ~ /^[0-9]+$/) {
      versions[name] = (name in versions ? versions[name] "," ver : ver)
      line[name ":" ver] = $0
      v = ver + 0
      if (!(name in maxv) || v > maxv[name]) maxv[name] = v
    }
  }
  END {
    for (n in versions) {
      split(versions[n], arr, ",")
      for (i in arr) {
        v = arr[i] + 0
        if (v != maxv[n]) print line[n ":" v]
      }
    }
  }
' "$VERSIONS_FILE" > "$CLEANED_FILE"

TO_DELETE_COUNT=$(grep -c . "$CLEANED_FILE" || true)

if [[ "$TO_DELETE_COUNT" -eq 0 ]]; then
  log "Step 4/4: Nothing to delete (each function only had base + largest)."
  log "Done."
  exit 0
fi

log "Step 4/4: Deleting $TO_DELETE_COUNT Lambda version(s):"
cat "$CLEANED_FILE" | while IFS=: read -r NAME VERSION; do
  [[ -n "$NAME" && "$VERSION" =~ ^[0-9]+$ ]] || continue
  log "-> Deleting ${NAME} version ${VERSION} in ${REGION}"
  aws lambda delete-function --region "$REGION" --function-name "$NAME" --qualifier "$VERSION"
done

log "Done. Listed all versions in $VERSIONS_FILE; deleted entries enumerated in $CLEANED_FILE"