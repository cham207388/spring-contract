import csv
import json
import logging
import os
from datetime import date, timedelta

import boto3
from boto3.dynamodb.conditions import Attr

# Create output directory
output_dir = ".github/artifacts"
os.makedirs(output_dir, exist_ok=True)

# Initialize DynamoDB resource
dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")

five_days_ago = date.today() - timedelta(days=5)
start_date_str = five_days_ago.strftime("%Y-%m-%d")

prod_submission_table = dynamodb_resource.Table("prod-Submission")
prod_submission_manifest_table = dynamodb_resource.Table("prod-SubmissionManifest")

output_csv = os.path.join(output_dir, f"lockbox-pending-{date.today()}.csv")

desired_columns = ["submissionId", "manifestId"]
filter_expression = Attr("lockboxStatus").is_in(["PENDING", "PROCESSING"]) & Attr(
    "timestamp"
).lte(start_date_str)


def generate_pending_submissions_report():
    """
    Performs a simple application-side merge:
    1. Scans 'prod-Submission' table with a FilterExpression.
    2. Scans 'prod-SubmissionManifest' table with a FilterExpression for collected submissionId's.
    3. Merges the specific 'manifestId' into the filtered 'prod-Submission' items.

    WARNING: Scanning is INEFFICIENT for large tables. This approach will involve TWO scans,
    one for each table. Use ONLY for occasional reports on tables where you can tolerate
    reading the entire table (or a significant portion) for each step.
    """

    # --- Step 1: Scan prod-Submission table with FilterExpression and Pagination ---
    # This is the "driving" query to find submissions that match our category filter.

    filtered_submissions = {}  # Will store initial filtered submission items, keyed by submissionId

    try:
        scan_params_submissions = {
            "FilterExpression": filter_expression,
            "ProjectionExpression": "submissionId",
        }

        # Initial scan of prod-Submission
        scan_response_submissions = prod_submission_table.scan(
            **scan_params_submissions
        )

        for item in scan_response_submissions.get("Items", []):
            filtered_submissions[item["submissionId"]] = item

        # Handle pagination for the submission scan
        while "LastEvaluatedKey" in scan_response_submissions:
            scan_params_submissions["ExclusiveStartKey"] = scan_response_submissions[
                "LastEvaluatedKey"
            ]
            scan_response_submissions = prod_submission_table.scan(
                **scan_params_submissions
            )
            for item in scan_response_submissions.get("Items", []):
                filtered_submissions[item["submissionId"]] = item

        if not filtered_submissions:
            logging.warning("No prod-Submission items found")
            return []

        logging.info(
            f"Found {len(filtered_submissions)} submission items after scan filter."
        )

    except Exception as e:
        logging.error(f"Error scanning prod-Submission table: {e}")
        return []

    # --- Step 2: Collect all 'submissionId's from filtered submissions for the manifest lookup ---
    submission_ids_to_lookup = list(filtered_submissions.keys())

    if not submission_ids_to_lookup:
        logging.warning("No submission IDs collected to fetch manifests.")
        return list(filtered_submissions.values())

    # --- Step 3: Scan prod-SubmissionManifest table with a FilterExpression for collected 'submissionId's ---
    # Since submissionId is NOT the PK of prod-SubmissionManifest and no GSI is available,
    # we must SCAN the ENTIRE prod-SubmissionManifest table and filter client-side or
    # with an IN-filter if the list is small enough.
    # An 'IN' filter expression can handle up to 100 values. If more, it needs to be chunked.

    manifest_data_map = {}  # To store manifest data, indexed by submissionId

    # Create an IN-filter for the scan, chunking if necessary
    chunk_size = 100  # Max for IN filter
    submission_id_chunks = [
        submission_ids_to_lookup[i : i + chunk_size]
        for i in range(0, len(submission_ids_to_lookup), chunk_size)
    ]

    try:
        for i, chunk in enumerate(submission_id_chunks):
            logging.info(
                f"--- Scanning prod-SubmissionManifest for chunk {i + 1}/{len(submission_id_chunks)} ---"
            )

            # Construct the FilterExpression dynamically for the 'IN' clause
            # We need ExpressionAttributeValues for an 'IN' filter
            filter_expression_parts = []
            expression_attribute_values = {}
            for j, sub_id in enumerate(chunk):
                placeholder = f":subId{j}"
                filter_expression_parts.append(placeholder)
                expression_attribute_values[placeholder] = sub_id

            # This constructs an expression like "submissionId IN (:subId0, :subId1, ...)"
            manifest_scan_params = {
                "FilterExpression": f"submissionId IN ({', '.join(filter_expression_parts)})",
                "ExpressionAttributeValues": expression_attribute_values,
                "ProjectionExpression": "submissionId, manifestId",
            }

            scan_response_manifest = prod_submission_manifest_table.scan(
                **manifest_scan_params
            )
            for item in scan_response_manifest.get("Items", []):
                # Make sure the submissionId is valid and manifestId is present before adding
                if "submissionId" in item and "manifestId" in item:
                    manifest_data_map[item["submissionId"]] = item["manifestId"]

            # Handle pagination for the manifest scan (within each chunk)
            while "LastEvaluatedKey" in scan_response_manifest:
                logging.info(
                    f"--- Fetching next page from prod-SubmissionManifest scan (chunk {i + 1}) ---"
                )
                manifest_scan_params["ExclusiveStartKey"] = scan_response_manifest[
                    "LastEvaluatedKey"
                ]
                scan_response_manifest = prod_submission_manifest_table.scan(
                    **manifest_scan_params
                )
                for item in scan_response_manifest.get("Items", []):
                    if "submissionId" in item and "manifestId" in item:
                        manifest_data_map[item["submissionId"]] = item["manifestId"]

        logging.info(f"Found {len(manifest_data_map)} manifest IDs.")

    except Exception as e:
        logging.error(f"Error scanning prod-SubmissionManifest table: {e}")
        pass  # Proceed with available data even if manifest data fetch fails

    # --- Step 4: Merge the data ---
    final_merged_list = []
    for submission_id, submission_item in filtered_submissions.items():
        # Look up the manifestId using the submissionId
        manifest_id_value = manifest_data_map.get(submission_id)

        if manifest_id_value is not None:
            submission_item["manifestId"] = manifest_id_value
        else:
            submission_item["manifestId"] = None
            logging.warning(
                f"Warning: No manifest found for submissionId: {submission_id}"
            )

        final_merged_list.append(submission_item)

    csv_headers = []
    for col in desired_columns:
        if "." in col:
            csv_headers.append(col.replace(".", "_"))
        else:
            csv_headers.append(col)

    with open(output_csv, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=csv_headers)
        writer.writeheader()

        for item in final_merged_list:
            flattened_item = {}
            for col in desired_columns:
                current_value = item
                keys = col.split(".")
                found_value = None

                try:
                    for k in keys:
                        if isinstance(current_value, dict):
                            current_value = current_value.get(k)
                        else:
                            current_value = None
                            break
                    found_value = current_value
                except AttributeError:
                    found_value = None

                if isinstance(found_value, (dict, list)):
                    flattened_item[col.replace(".", "_")] = json.dumps(found_value)
                else:
                    flattened_item[col.replace(".", "_")] = found_value

            writer.writerow(flattened_item)


if __name__ == "__main__":
    generate_pending_submissions_report()
