#!/bin/bash

echo "Running Submission Service init"

awslocal s3api create-bucket --bucket form-staging --region us-east-1
awslocal s3api create-bucket --bucket application-jars --region us-east-1
awslocal s3api create-bucket --bucket evidence --region us-east-1
awslocal s3api create-bucket --bucket form-backup --region us-east-1
awslocal sqs create-queue --queue-name validation-results --region us-east-1
awslocal sqs create-queue --queue-name field-validation-results --region us-east-1
awslocal sqs create-queue --queue-name eligibility-validation-results --region us-east-1
awslocal sqs create-queue --queue-name name-validation-results --region us-east-1
awslocal sqs create-queue --queue-name profile-validation-results --region us-east-1
awslocal sqs create-queue --queue-name attorney-name-validation-results --region us-east-1
awslocal sqs create-queue --queue-name address-validation-results --region us-east-1
awslocal sqs create-queue --queue-name person-validation-results --region us-east-1
awslocal sqs create-queue --queue-name i912-validation-results --region us-east-1
awslocal sqs create-queue --queue-name elis-validation-request --region us-east-1
awslocal sqs create-queue --queue-name elis-validation-response --region us-east-1
awslocal sqs create-queue --queue-name elis-evidence-validation-request --region us-east-1
awslocal sqs create-queue --queue-name elis-evidence-validation-response --region us-east-1
awslocal sqs create-queue --queue-name elis-esign-request --region us-east-1
awslocal sqs create-queue --queue-name elis-validation-request-deadletter-queue --region us-east-1
awslocal sqs create-queue --queue-name elis-validation-response-deadletter-queue --region us-east-1
awslocal sqs create-queue --queue-name elis-evidence-validation-request-deadletter-queue --region us-east-1
awslocal sqs create-queue --queue-name elis-evidence-validation-response-deadletter-queue --region us-east-1
awslocal sqs create-queue --queue-name elis-esign-request-deadletter-queue --region us-east-1
awslocal sqs create-queue --queue-name replay-submission-request --region us-east-1
awslocal sqs set-queue-attributes \
    --queue-url http://sqs.us-east-1.localstack:4566/000000000000/elis-validation-response \
    --attributes '{ "RedrivePolicy": "{\"deadLetterTargetArn\":\"arn:aws:sqs:us-east-1:000000000000:elis-validation-response-deadletter-queue\",\"maxReceiveCount\":\"1\"}" }'

awslocal dynamodb create-table --table-name default-FormMetaData --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=formType,AttributeType=S --key-schema AttributeName=formType,KeyType=HASH --region us-east-1
awslocal dynamodb create-table --table-name default-CoreMetaData --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=id,AttributeType=S --key-schema AttributeName=id,KeyType=HASH --region us-east-1
awslocal dynamodb create-table --table-name default-EvidenceMetaData --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=id,AttributeType=S --key-schema AttributeName=id,KeyType=HASH --region us-east-1
awslocal dynamodb create-table --table-name default-FeeWaiverMetaData --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=formType,AttributeType=S --key-schema AttributeName=formType,KeyType=HASH --region us-east-1
awslocal dynamodb create-table --table-name default-ValidationStatus --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=formId,AttributeType=S AttributeName=validator,AttributeType=S --key-schema AttributeName=formId,KeyType=HASH AttributeName=validator,KeyType=RANGE --region us-east-1
awslocal dynamodb create-table --table-name default-TextractJob --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=jobId,AttributeType=S --key-schema AttributeName=jobId,KeyType=HASH --region us-east-1
awslocal dynamodb create-table --table-name default-SubmissionManifest --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=manifestId,AttributeType=S --key-schema AttributeName=manifestId,KeyType=HASH --region us-east-1
awslocal dynamodb create-table --table-name default-Submission --attribute-definitions AttributeName=submissionId,AttributeType=S AttributeName=myUscisId,AttributeType=S AttributeName=orgMyUscisId,AttributeType=S AttributeName=manifestId,AttributeType=S AttributeName=formType,AttributeType=S AttributeName=lockboxStatus,AttributeType=S --key-schema AttributeName=submissionId,KeyType=HASH --provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=10 --global-secondary-indexes "[{\"IndexName\": \"requests_by_myUscisId\",\"KeySchema\": [{\"AttributeName\":\"myUscisId\",\"KeyType\":\"HASH\"}],\"Projection\":{\"ProjectionType\":\"ALL\"},\"ProvisionedThroughput\": {\"ReadCapacityUnits\": 10,\"WriteCapacityUnits\": 10}}, {\"IndexName\": \"requests_by_orgMyUscisId\",\"KeySchema\": [{\"AttributeName\":\"orgMyUscisId\",\"KeyType\":\"HASH\"}],\"Projection\":{\"ProjectionType\":\"ALL\"},\"ProvisionedThroughput\": {\"ReadCapacityUnits\": 10,\"WriteCapacityUnits\": 10}}, {\"IndexName\": \"requests_by_manifestId\",\"KeySchema\": [{\"AttributeName\":\"manifestId\",\"KeyType\":\"HASH\"}],\"Projection\":{\"ProjectionType\":\"ALL\"},\"ProvisionedThroughput\": {\"ReadCapacityUnits\": 10,\"WriteCapacityUnits\": 10}}, {\"IndexName\": \"requests_by_formType\",\"KeySchema\": [{\"AttributeName\":\"formType\",\"KeyType\":\"HASH\"}],\"Projection\":{\"ProjectionType\":\"ALL\"},\"ProvisionedThroughput\": {\"ReadCapacityUnits\": 10,\"WriteCapacityUnits\": 10}}, {\"IndexName\": \"requests_by_lockboxStatus\",\"KeySchema\": [{\"AttributeName\":\"lockboxStatus\",\"KeyType\":\"HASH\"}],\"Projection\":{\"ProjectionType\":\"ALL\"},\"ProvisionedThroughput\": {\"ReadCapacityUnits\": 10,\"WriteCapacityUnits\": 10}}]" --region us-east-1
awslocal dynamodb create-table --table-name default-SubmissionSummary --attribute-definitions AttributeName=submissionId,AttributeType=S  AttributeName=manifestId,AttributeType=S --key-schema AttributeName=submissionId,KeyType=HASH --provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=10 --global-secondary-indexes "[{\"IndexName\": \"summary_by_manifestId\",\"KeySchema\": [{\"AttributeName\":\"manifestId\",\"KeyType\":\"HASH\"}],\"Projection\":{\"ProjectionType\":\"ALL\"},\"ProvisionedThroughput\": {\"ReadCapacityUnits\": 10,\"WriteCapacityUnits\": 10}}]" --region us-east-1
awslocal dynamodb create-table --table-name default-Audit --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=myUscisId,AttributeType=S AttributeName=submissionId,AttributeType=S --key-schema AttributeName=myUscisId,KeyType=HASH AttributeName=submissionId,KeyType=RANGE --region us-east-1
awslocal dynamodb create-table --table-name default-NameExtract --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=submissionId,AttributeType=S --key-schema AttributeName=submissionId,KeyType=HASH --region us-east-1
awslocal dynamodb create-table --table-name default-AddressExtract --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=submissionId,AttributeType=S --key-schema AttributeName=submissionId,KeyType=HASH --region us-east-1

awslocal dynamodb create-table --table-name default-ClientInformation --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 --attribute-definitions AttributeName=submissionId,AttributeType=S AttributeName=clientId,AttributeType=S --key-schema AttributeName=submissionId,KeyType=HASH --global-secondary-indexes "[{\"IndexName\": \"by_clientId\",\"KeySchema\": [{\"AttributeName\":\"clientId\",\"KeyType\":\"HASH\"}],\"Projection\":{\"ProjectionType\":\"ALL\"},\"ProvisionedThroughput\": {\"ReadCapacityUnits\": 10,\"WriteCapacityUnits\": 10}}]" --region us-east-1
