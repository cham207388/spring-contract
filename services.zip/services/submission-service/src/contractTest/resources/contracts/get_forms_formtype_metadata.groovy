/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        url value(consumer(regex('/api/v1/forms/[a-zA-Z0-9\\-]+/metadata')))
        method HttpMethods.GET
        headers {
            header(accept(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }

        body(
            formType: anyOf('I-765', 'N-400'),
            formDescription: anyNonEmptyString(),
            showBanner: aBoolean(),
            enabled: aBoolean(),
            editions: [
                [
                    numberOfPages: anyNumber(),
                    edition: anyNonEmptyString(),
                    ombNo: anyNonEmptyString(),
                    expires: anyNonEmptyString()
                ]
            ],
            validations: [
                anyOf('CORE')
            ],
            eligibilityCategories: [
                [
                category: anyNonEmptyString(),
                label: anyNonEmptyString(),
                code: anyNumber(),
                metaData: [
                    feeWaivable: aBoolean(),
                    feeExemptable: aBoolean(),
                    evidenceGroups: [
                        [
                            id: anyNonEmptyString(),
                            name: anyNonEmptyString(),
                            evidenceTypes: [
                                [
                                    id: anyNonEmptyString(),
                                    name: anyNonEmptyString(),
                                    contentCategoryCode: anyNumber()
                                ]
                            ],
                            validations: [
                                anyOf('CORE')
                            ],
                            maxNumberOfFiles: anyNumber(),
                            allowMediaTypes: [
                                regex('[a-z]+/[a-z0-9\\-\\.\\+\\*]+')
                            ]
                        ]
                    ],
                    feeExemptQuestions: [
                            [
                                question: anyNonEmptyString(),
                                answerRequired: anyNonEmptyString()
                            ]
                        ]
                    ]
                ]
            ],
            pages: [
                beforeYouStart: [
                    title: anyNonEmptyString(),
                    description: anyNonEmptyString(),
                    beforeYouStartCategories: [
                        [
                            title: anyNonEmptyString(),
                            body: anyNonEmptyString(),
                            icon: anyNonEmptyString(),
                            accordionCategories: [
                                [
                                    title: anyNonEmptyString(),
                                    id: anyNonEmptyString(),
                                    body: anyNonEmptyString()
                                ]
                            ]
                        ]
                    ],
                    afterYouFileCategories: [
                        [
                            title: anyNonEmptyString(),
                            body: anyNonEmptyString(),
                            icon: anyNonEmptyString(),
                            accordionCategories: [
                                [
                                    title: anyNonEmptyString(),
                                    id: anyNonEmptyString(),
                                    body: anyNonEmptyString()
                                ]
                            ]
                        ]
                    ]
                ],
                eligibility: [
                    header: anyNonEmptyString()
                ]
            ],
            landmarks: [
                "additionalProps1": anyNumber()
            ]      
        )
    }
    priority(1)
}
