/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        urlPath(regex('/api/v1/[a-zA-Z0-9\\-]+/submissions/[a-zA-Z0-9\\-]+/validation-status')) {
			queryParameters {
				parameter('orgMyUscisId', regex('[a-zA-Z0-9\\-]+'))
			}
		}
		method HttpMethods.GET
        headers {
            header(accept(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }

        body(
            [
                status: anyOf("IN_PROGRESS", "COMPLETE"),
                formValidations: [
                    [
                        groupType: anyNonEmptyString(),
                        id: anyNonEmptyString(),
                        status: "IN_PROGRESS",
                        details: [
                            [
                                validator: anyOf("CORE", "SIGNATURE", "ELIGIBILITY_CATEGORY", "PERSON", "NOA", "I797C","I912"),
                                result: anyOf("PASS", "FAIL", "WARN"),
                                reasons: [
                                    anyNonEmptyString()
                                ],
                                warnings: null
                            ]
                        ]
                    ]
                ],
                evidenceValidations: [
                    [
                        groupType: anyNonEmptyString(),
                        id: anyNonEmptyString(),
                        status: "IN_PROGRESS",
                        details: [
                            [
                                validator: anyOf("CORE", "SIGNATURE", "ELIGIBILITY_CATEGORY", "PERSON", "NOA", "I797C","I912"),
                                result: anyOf("PASS", "FAIL", "WARN"),
                                reasons: [
                                    anyNonEmptyString()
                                ],
                                warnings: null
                            ]
                        ]
                    ]
                ]
            ]
        )
    }
}