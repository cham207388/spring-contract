/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
		urlPath(regex('/api/v1/[a-zA-Z0-9\\-]+/submissions/[a-zA-Z0-9\\-]+/status')) {
			queryParameters {
				parameter('orgMyUscisId', regex('[a-zA-Z0-9\\-]+'))
			}
		}
        method HttpMethods.GET
        headers {
            header(accept(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }

        body(
            [
                submissionErrors: [
                    anyNonEmptyString()
                ],
                formErrors: [
                    [
                        type: anyNonEmptyString(),
                        errors: [
                            anyNonEmptyString()
                        ]
                    ]
                ],
                evidenceErrors: [
                    [
                        type: anyNonEmptyString(),
                        errors: [
                            anyNonEmptyString()
                        ]
                    ]
                ]
            ]
        )
    }
}