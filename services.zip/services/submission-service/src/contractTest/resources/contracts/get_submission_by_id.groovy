/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

def customIso8601 = '([1-9]\\d{3}-((0[1-9]|1[0-2])-(0[1-9]|1\\d|2[0-8])|(0[13-9]|1[0-2])-(29|30)|(0[13578]|1[02])-31)|([1-9]\\d(0[48]|[2468][048]|[13579][26])|([2468][048]|[13579][26])00)-02-29)T([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d\\.\\d+[+-](0[0-9]|1[0-4])00'


Contract.make {
    request {
		urlPath(regex('/api/v1/[a-zA-Z0-9\\-]+/submissions/[a-zA-Z0-9\\-]+')) {
			queryParameters {
				parameter('orgMyUscisId', regex('[a-zA-Z0-9\\-]+'))
			}
		}
        method HttpMethods.GET
        headers {
            header(accept(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }

        body(
            myUscisId: anyUuid(),
            submissionId: anyUuid(),
            formType: anyOf("I-765", "N-400"),
            eligibilityCategory: value(consumer("C11 - Parole"), producer(anyNonEmptyString())),
            manifestId: anyUuid(),
            status: anyOf('DRAFT', 'DELETED', 'PUBLISHED', 'ACCEPTED', 'REJECTED', 'RECEIVED'),
            lockboxStatus: anyOf('RECEIVED', 'REJECTED', 'ACCEPTED', 'PROCESSING', 'PENDING', 'ERROR'),
            lockboxErrors: [
                [
                    id: anyUuid(),
                    errorCode: anyNonEmptyString(),
                    description: anyNonEmptyString()
                ]
            ],
            feeTotal: anyNumber(),
            // Dates are coming through as epochs
            timestamp: regex(customIso8601),
            updatedAt: regex(customIso8601),
            expireDate: regex(customIso8601),
            submittedAt: regex(customIso8601),
            forms: [
                [
                    type: anyNonEmptyString(),
                    eligibilityCategory: value(consumer("C11 - Parole"), producer(anyNonEmptyString())),
                    id: anyUuid(),
                    name: anyNonEmptyString(),
                    feeTotal: 100,
                    md5Hash: anyNonEmptyString(),
                    paymentTrackingId: alphaNumeric(),
                    lockboxStatus: anyOf('RECEIVED', 'REJECTED', 'ACCEPTED', 'PROCESSING', 'PENDING', 'ERROR'),
                    validations: [
                        anyNonEmptyString()
                    ],
                    rejectionReasons: [
                        [
                            code: anyNonEmptyString(),
                            reason: anyNonEmptyString()
                        ]
                    ],
                    uploadedAt: regex(customIso8601)
                ]
            ],
            evidences: [
                [
                    type: anyNonEmptyString(),
                    evidenceGroupType: anyNonEmptyString(),
                    id: anyUuid(),
                    name: anyNonEmptyString(),
                    md5Hash: anyNonEmptyString(),
                    uploadedAt: regex(customIso8601)
                ]
            ],
            feeWaiver: [
                type: anyNonEmptyString(),
                evidenceGroupType: anyNonEmptyString(),
                id: anyUuid(),
                name: anyNonEmptyString(),
                md5Hash: anyNonEmptyString(),
                uploadedAt: regex(customIso8601)
            ],
            userRequestedFeeWaiver: aBoolean(),
            userRequestedPartialFeeWaiver: aBoolean(),
            attested: aBoolean(),
            hasReviewedSignature: aBoolean(),
            attestedAt: regex(customIso8601),
            attestationSignature: anyNonEmptyString(),
            immvi: aBoolean(),
            applicant: [
                myUscisId: anyUuid(),
                email: anyNonEmptyString(),
                accountType: anyOf('applicant', 'representative')
            ]
        )
    }
}
