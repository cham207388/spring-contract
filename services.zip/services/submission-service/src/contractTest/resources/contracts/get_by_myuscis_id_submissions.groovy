/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        urlPath(regex('/api/v1/[a-zA-Z0-9\\-]+/submissions')) {
            queryParameters {
                parameter('filters', regex('[a-zA-Z0-9\\-]+'))
 
            }
        }
        method HttpMethods.GET
        headers {
            header(contentType(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }
        body(
            [
                [
                    submissionId: anyUuid(),
                    formType: anyOf("N-400", "I-765"),
                    eligibilityCategory: $(consumer('C11 - Parole'), producer('C11 - Parole')),
                    manifestId: anyUuid(),
                    status: anyOf("DRAFT", "DELETED", "PUBLISHED", "ACCEPTED", "REJECTED", "RECEIVED"),
                    lockboxStatus: anyOf("RECEIVED", "REJECTED", "ACCEPTED", "PROCESSING", "PENDING", "ERROR"),
                    lockboxErrors: [
                        [
                            id: anyUuid(),
                            errorCode: anyNonEmptyString(),
                            description: anyNonEmptyString()
                        ]
                    ],
                    feeTotal: anyNumber(),
                    forms: [
                        [
                            type: anyNonEmptyString(),
                            eligibilityCategory: $(consumer('C11 - Parole'), producer('C11 - Parole')),
                            id: anyUuid(),
                            name: anyNonEmptyString(),
                            feeTotal: 100,
                            md5Hash: anyNonEmptyString(),
                            paymentTrackingId: alphaNumeric(),
                            lockboxStatus: anyOf("RECEIVED", "REJECTED", "ACCEPTED", "PROCESSING", "PENDING", "ERROR"),
                            validations: [
                                anyNonEmptyString()
                            ],
                            rejectionReasons: [
                                [
                                    code: anyNonEmptyString(),
                                    reason: anyNonEmptyString()
                                ]
                            ],
                        ]
                    ],
                    evidences: [
                        [
                            type: anyNonEmptyString(),
                            evidenceGroupType: anyNonEmptyString(),
                            id: anyUuid(),
                            name: anyNonEmptyString(),
                            md5Hash: anyNonEmptyString(),
                        ]
                    ],
                    feeWaiver: [
                        type: anyNonEmptyString(),
                        evidenceGroupType: anyNonEmptyString(),
                        id: anyUuid(),
                        name: anyNonEmptyString(),
                        md5Hash: anyNonEmptyString(),
                     ],
                    userRequestedFeeWaiver: aBoolean(),
                    userRequestedPartialFeeWaiver: aBoolean(),
                    attested: aBoolean(),
                    hasReviewedSignature: aBoolean(),
                    attestationSignature: anyNonEmptyString(),
                    immvi: aBoolean(),
                    applicant: [
                        myUscisId: anyUuid(),
                        email: anyNonEmptyString(),
                        accountType: anyOf('applicant', 'representative')
                    ]
                ]
            ]
        )
    }

}
