/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        url value(consumer(regex('/api/v1/[a-zA-Z0-9\\-]+/submissions/[a-zA-Z0-9\\-]+/final-transmission-status')))
        method HttpMethods.GET
        headers {
            header(accept(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }

        body(
            status: "SUCCESS",
            message: anyNonEmptyString()
        )
    }
}
