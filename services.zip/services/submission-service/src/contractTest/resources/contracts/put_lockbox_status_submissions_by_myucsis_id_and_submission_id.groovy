/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    priority(2)
    request {
        urlPath(regex('/api/v1/[a-zA-Z0-9\\-]+/submissions/[a-zA-Z0-9\\-]+/lockbox-status'))
        // /api/v1/{myUscisId}/submissions/{submissionId}/lockbox-status
        // url value(consumer(regex('/api/v1/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/submissions/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/lockbox-status')))
        method HttpMethods.PUT
        headers {
            header(contentType(), applicationJson())
        }
        body(
            [
                manifestUpdate: [
                    status: anyOf("COMPLETE"),
                    lockboxId: anyNonEmptyString(),
                    errors: [
                        [
                            id: anyNonEmptyString(),
                            errorCode: anyNonEmptyString(),
                            description: anyNonEmptyString()
                        ]
                    ]
                ],
                submissionUpdate: [
                    lockboxId: anyNonEmptyString(),
                    status: "COMPLETE",
                    totalCost: 0,
                    applicationStatuses: [
                    [
                        formType: anyNonEmptyString(),
                        status: "COMPLETE",
                        uscisReceiptNumber: anyNonEmptyString(),
                        rejectionReasons: [
                            [
                                code: anyNonEmptyString(),
                                reason: anyNonEmptyString()
                            ]
                        ],
                        id: anyNonEmptyString()
                    ]
                ]
            ],
            updateType: "SUBMISSION"
            ]
        )
    }
    response {
        status 200
    }
}