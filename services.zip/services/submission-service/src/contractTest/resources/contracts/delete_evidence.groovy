/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        url value(consumer(regex('/api/v1/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89aB][0-9a-f]{3}-[0-9A-f]{12}/submissions/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89aB][0-9a-f]{3}-[0-9A-f]{12}/evidence/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89aB][0-9a-f]{3}-[0-9A-f]{12}')))
        method HttpMethods.DELETE
        headers {
            header(accept(), applicationJson())
        }
    }

    response {
        status 204
    }
}