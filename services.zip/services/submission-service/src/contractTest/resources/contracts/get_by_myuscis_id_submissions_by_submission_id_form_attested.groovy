/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        url value(consumer(regex('/api/v1/myUscisId/submissions/submissionId/form/attested')))
        method HttpMethods.GET
    }
    response {
        status 200
        headers {
            header(contentType(), applicationPdf())
        }
        body(fileAsBytes("mock-files/response.pdf"))
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            