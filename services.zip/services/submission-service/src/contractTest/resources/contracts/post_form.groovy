/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

def customIso8601 = '([1-9]\\d{3}-((0[1-9]|1[0-2])-(0[1-9]|1\\d|2[0-8])|(0[13-9]|1[0-2])-(29|30)|(0[13578]|1[02])-31)|([1-9]\\d(0[48]|[2468][048]|[13579][26])|([2468][048]|[13579][26])00)-02-29)T([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d\\.\\d+[+-](0[0-9]|1[0-4])00'


Contract.make {
    request {
        urlPath(regex('/api/v1/myUscisId/submissions/submissionId/form')) {
			queryParameters {
				parameter('orgMyUscisId', regex('[a-zA-Z0-9\\-]+'))
			}
		}
		method HttpMethods.POST
        headers {
            contentType(multipartFormData())
        }
        multipart(
            file: named(
                name: $("file"),
                content: $("content")
            ),
            uploadRequest: named(
                name: $("uploadRequest"),
                content: $(c(regex(nonEmpty())), p('{"fileName": "text.txt", "isForm": false, "type": "pdf", "md5Hash": "12345", "formType": "I765", "forms": "[]"}')),
                contentType: $("application/json")
            )
        )
    }
    response {
        status 400
    }

}