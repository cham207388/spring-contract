/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        urlPath(regex('/api/v1/[a-zA-Z0-9\\-]+/submissions/[a-zA-Z0-9\\-]+/forms/[a-zA-Z0-9\\-]+/i912-validation-status')) {
			queryParameters {
				parameter('orgMyUscisId', regex('[a-zA-Z0-9\\-]+'))
			}
		}
		method HttpMethods.GET
        headers {
            header(accept(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }

        body(
            [
                status: anyOf("IN_PROGRESS", "COMPLETE"),
                i912FeeWaiverValidation: [ 
                    validator: anyOf("CORE", "SIGNATURE", "ELIGIBILITY_CATEGORY", "PERSON", "NOA", "I797C","I912"),
                    result: anyOf("PASS", "FAIL", "WARN"),
                    reasons: [
                        anyNonEmptyString()
                    ],
                    warnings: null
                ]
            ]
        )
    }
}