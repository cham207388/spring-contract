/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
		urlPath(regex('/api/v1/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/submissions/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}')) {
			queryParameters {
				parameter('orgMyUscisId', regex('[a-zA-Z0-9\\-]+'))
			}
		}
        method HttpMethods.POST
        headers {
            header(contentType(), applicationJson())
        }
    }
    response {
        status 200
    }

}