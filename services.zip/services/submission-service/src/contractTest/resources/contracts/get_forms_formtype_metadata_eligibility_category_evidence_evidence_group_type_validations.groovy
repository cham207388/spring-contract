/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        url value(consumer(regex('/api/v1/forms/[a-zA-Z0-9\\-]+/metadata/[a-zA-Z0-9\\-]+/evidence/[a-zA-Z0-9\\-]+/validations')))
        method HttpMethods.GET
        headers {
            header(accept(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }

        body(
            ["CORE"]
        )
    }
    priority(1)
}
