package gov.dhs.uscis.submissionservice;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ReasonForFiling;

import static gov.dhs.uscis.intake.enums.I765EligibilityCategory.A12;
import static gov.dhs.uscis.intake.enums.I765EligibilityCategory.C8;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.PASS;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.CORE;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.ELIGIBILITY_CATEGORY;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.SIGNATURE;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.PFVS;
import static gov.dhs.uscis.submissionservice.SubmissionFactory.aNewSubmission;
import static gov.dhs.uscis.submissionservice.SubmissionFactory.attachedEvidence;
import static gov.dhs.uscis.submissionservice.SubmissionFactory.attachedFeeWaiver;
import static gov.dhs.uscis.submissionservice.SubmissionFactory.attachedForm;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpEntity;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.JsonProcessingException;

import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.audit.Audit.Event;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.submissionservice.config.ApplicationConfig;
import gov.dhs.uscis.submissionservice.models.dto.AttestFormRequest;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765Fees;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = {
    ApplicationConfig.class }, properties = "spring.main.allow-bean-definition-overriding=true")
@AutoConfigureWebTestClient(timeout = "600000")
public class FilingSubmissionJourneysTest  extends BaseJourneyTest {

    @Test
    void shouldReturnNoContentWhenFilingValidSubmission() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        BigDecimal feeTotal = I765Fees.FEE_560;
        this.withSuccessfulManifest(submissionId, MYUSCIS_ID);
        this.withSuccessfulPaymentFor(submissionId, feeTotal, FormType.I765.getType());
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, SIGNATURE);
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, ELIGIBILITY_CATEGORY);
     //   this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, PFVS);
        this.attestForm(MYUSCIS_ID, submissionId, formId, new AttestFormRequest(true, "something"));
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isOk());
    }

    @Test
    void shouldReturnBadRequestWhenFilingASubmissionWithInvalidEvidenceType() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, SIGNATURE);
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, ELIGIBILITY_CATEGORY);
        
     //   this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, PFVS);
        this.attestForm(MYUSCIS_ID, submissionId, formId, new AttestFormRequest(true, "something"));
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestWhenFilingASubmissionWithoutEligibilityCategory() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().isBadRequest());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
        this.attestForm(MYUSCIS_ID, submissionId, formId, new AttestFormRequest(true, "something"));
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestWhenFilingASubmissionWithoutAttestation() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestWhenFilingASubmissionNotInDraftStatus() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, SIGNATURE);
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, ELIGIBILITY_CATEGORY);
     //   this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, PFVS);
        this.withSuccessfulPaymentFor(submissionId, I765Fees.FEE_560, FormType.I765.getType());
        this.withSuccessfulManifest(submissionId, MYUSCIS_ID);

        this.attestForm(MYUSCIS_ID, submissionId, formId, new AttestFormRequest(true, "something"));
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isOk());
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isBadRequest());
    }

    @Test
    void shouldReturnNoContentWhenFilingAFeeWaivedSubmissionWithFeeWaiver() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        BigDecimal feeTotal = new BigDecimal(560).setScale(2);
        this.withSuccessfulManifest(submissionId, MYUSCIS_ID);
        this.withSuccessfulPaymentFor(submissionId, feeTotal, FormType.I765.getType());
        this.updateEligibility(MYUSCIS_ID, submissionId, A12);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        this.withFeeWaiver(MYUSCIS_ID, submissionId,
                attachedFeeWaiver(fileName, MYUSCIS_ID, submissionId));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
                MultiValueMap<String, HttpEntity<?>> feeWaiverEvidenceRequest = attachedEvidence(MYUSCIS_ID,
        submissionId, "Other", "feeWaiver", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), feeWaiverEvidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
        this.attestForm(MYUSCIS_ID, submissionId, formId, new AttestFormRequest(true, "something"));
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isOk());
    }

    @Test
    void shouldReturnBadRequestWhenFilingAFeeWaivedSubmissionWithNoFeeWaiver() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        this.updateUserRequestedFeeWaiver(MYUSCIS_ID, submissionId, true);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
        this.attestForm(MYUSCIS_ID, submissionId, formId, new AttestFormRequest(true, "something"));

        assertAuditTrail(MYUSCIS_ID, submissionId, (audit) -> {
            Event event = findEventByExpectedAction(audit, ActionPerformed.FEE_WAIVER_REQUESTED).stream().findFirst()
                    .orElse(null);
            assertNotNull(event);
            assertEquals(MYUSCIS_ID, audit.getMyUscisId());
            assertEquals(submissionId, audit.getSubmissionId());
            assertEquals("true", event.getMetadata());
        });

        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isBadRequest());
    }

    @Test
    void shouldReturnNoContentWhenFilingAFeeWaivedSubmissionWithI912Document() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        BigDecimal feeTotal = I765Fees.FEE_560;
        this.withSuccessfulManifest(submissionId, MYUSCIS_ID);
        this.withSuccessfulPaymentFor(submissionId, feeTotal, FormType.I765.getType());
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        this.updateReasonForFiling(MYUSCIS_ID, submissionId, ReasonForFiling.INITIAL.toString());
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        MultiValueMap<String, HttpEntity<?>> feeWaiverEvidenceRequest = attachedEvidence(MYUSCIS_ID,
        submissionId, "Other", "feeWaiver", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), feeWaiverEvidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
        this.withFeeWaiver(MYUSCIS_ID, submissionId, attachedFeeWaiver(fileName, MYUSCIS_ID, submissionId));
        this.attestForm(MYUSCIS_ID, submissionId, formId, new AttestFormRequest(true, "something"));
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isOk());
    }
        
/*     @Test
    void shouldReturnBadRequestWhenFilingASubmissionWithValidationErrors() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, FAIL, CORE);
        this.attestForm(MYUSCIS_ID, submissionId, formId, new AttestFormRequest(true, "something"));
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isBadRequest());
    }

*/
    @Test
    void shouldReturnBadRequestWhenFilingASubmissionWithoutAForm() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        // TODO: Ideally this endpoint would reject as well
        this.attestForm(MYUSCIS_ID, submissionId, "fake", new AttestFormRequest(true, "something"));
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().is5xxServerError());
    }

/* 
    @Test
    void shouldReturnNoContentWhenFilingASubmissionWithAFormWithoutSignature() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        this.withFileableSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.withSuccessfulManifest(submissionId, MYUSCIS_ID);//this should be improve later
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType() ));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
        this.waitForSignatureAnalysis(MYUSCIS_ID, submissionId, formId, FAIL);
        this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, ELIGIBILITY_CATEGORY);
        this.attestForm(MYUSCIS_ID, submissionId, formId, new AttestFormRequest(true, "something"));
        this.submitSubmission(MYUSCIS_ID, submissionId, (response) -> response.expectStatus().isOk());
    }
        */

}
