package gov.dhs.uscis.submissionservice.components;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.constants.DocumentType.FeeWaiver;
import gov.dhs.uscis.intake.enums.PFVSEvidenceType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ELISValidationResponse;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import jakarta.jms.JMSException;
import jakarta.jms.TextMessage;

@ExtendWith(MockitoExtension.class)
class ElisEvidenceValidationResponseListenerTest {

    @Mock 
    ValidationStatusRepository mockValidationStatusDAO;
    
    @Mock 
    SubmissionRepository submissionDAO;

    @Mock 
    SubmissionService submissionService;

    @InjectMocks
    ElisEvidenceValidationResponseListener listener;

    @Test
    void shouldUpdateValidationStatus() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.I912)
                .failureReasons(null)
                .validationWarnings(null)
                .build();
        
        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType(PFVSEvidenceType.I912.getType())
        		.pass(true)
        		.results(Arrays.asList(status))
        		.fee(new BigDecimal(100.0))
        		.build();
        
        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionService.updateFeeWaiverEvidence(any(Submission.class), eq(FeeWaiver.FORM_I912), eq(true))).thenReturn(Submission.builder().build());
        when(submissionDAO.getById(submissionId)).thenReturn(Optional.of(Submission.builder().build()));
        
        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionService).updateFeeWaiverEvidence(any(Submission.class), eq(FeeWaiver.FORM_I912), eq(true));
        verify(submissionDAO).save(any(Submission.class));
    }
    
    @Test
    void shouldUpdateValidationStatusNotI912() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.I797C)
                .failureReasons(null)
                .validationWarnings(null)
                .build();
        
        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType("I-131")
        		.pass(true)
        		.results(Arrays.asList(status))
        		.fee(new BigDecimal(100.0))
        		.build();
        
        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(Optional.of(Submission.builder().build()));
        
        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionService, times(0)).updateFeeWaiverEvidence(any(), any(), any());
        verify(submissionDAO).save(any(Submission.class));
    }
}