package gov.dhs.uscis.submissionservice.validators;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;

import jakarta.servlet.http.Part;
import static org.instancio.Select.field;

public class SubmissionHasRequiredFieldsForEvidenceRequestValidatorTest {

    SubmissionHasRequiredFieldsForEvidenceRequestValidator validator = new SubmissionHasRequiredFieldsForEvidenceRequestValidator();

    @Test
    void shouldReturnTrueWhenSubmissionHasAFormTypeAndCategory() {
        List<Part> files = Instancio.ofList(Part.class).size(1).create();
        UploadEvidenceRequest newEvidence = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), "form-i-94-passport")
                .create();
        SubmissionEvidence evidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getEvidenceGroupType), "form-i-94-passport")
                .create();

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), List.of(evidence))
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                .set(field(Submission::getFormType), FormType.I765)
                .create();
        EvidenceRequest request = new EvidenceRequest(List.of(newEvidence), files, submission);

        assertTrue(validator.isValid(request, null));
    }

    @Test
    void shouldReturnFalseWhenSubmissionDoesNotHaveAFormType() {
        List<Part> files = Instancio.ofList(Part.class).size(1).create();
        UploadEvidenceRequest newEvidence = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), "form-i-94-passport")
                .create();
        SubmissionEvidence evidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getEvidenceGroupType), "form-i-94-passport")
                .create();

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), List.of(evidence))
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                .set(field(Submission::getFormType), null)
                .create();
        EvidenceRequest request = new EvidenceRequest(List.of(newEvidence), files, submission);

        assertFalse(validator.isValid(request, null));
    }

    @Test
    void shouldReturnFalseWhenSubmissionDoesNotHaveACategory() {
        List<Part> files = Instancio.ofList(Part.class).size(1).create();
        UploadEvidenceRequest newEvidence = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), "form-i-94-passport")
                .create();
        SubmissionEvidence evidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getEvidenceGroupType), "form-i-94-passport")
                .create();

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), List.of(evidence))
                .set(field(Submission::getEligibilityCategory), null)
                .set(field(Submission::getFormType), FormType.I765)
                .create();
        EvidenceRequest request = new EvidenceRequest(List.of(newEvidence), files, submission);

        assertFalse(validator.isValid(request, null));
    }


}
