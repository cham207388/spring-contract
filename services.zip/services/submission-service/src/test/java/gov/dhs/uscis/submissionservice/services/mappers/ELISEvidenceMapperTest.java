package gov.dhs.uscis.submissionservice.services.mappers;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;

public class ELISEvidenceMapperTest {

    @Test
    public void shouldMap797And797cEvidenceTypes() {
        Submission submission = Instancio.create(Submission.class);
        submission.getEvidences().add(SubmissionEvidence.builder().id(UUID.randomUUID().toString()).type("Form-797").build());
        submission.getEvidences().add(SubmissionEvidence.builder().id(UUID.randomUUID().toString()).type("Applicant Photo").build());
        submission.getEvidences().add(SubmissionEvidence.builder().id(UUID.randomUUID().toString()).type("Invalid-type").build());
        submission.getEvidences().add(SubmissionEvidence.builder().id(UUID.randomUUID().toString()).type("Form-797c").build());

        new ELISEvidenceMapper().transform(submission);

        assertEquals(2, submission.getEvidences().stream().filter(evidence -> evidence.getType() == "Other").count());
    }

    @Test
    public void shouldHandleWhen797And797cEvidenceTypesAreNotUploaded() {
        Submission submission = Instancio.create(Submission.class);
        submission.setEvidences(null);

        new ELISEvidenceMapper().transform(submission);

        assertNull(submission.getEvidences());
    }
}
