package gov.dhs.uscis.submissionservice.validators.i765;

import static gov.dhs.uscis.intake.entities.submission.SubmissionState.DRAFT;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.testcontainers.shaded.com.google.common.collect.Maps;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.models.EligibilityCategoryResponse;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.validators.i765.EligibilityCategoryValidator;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;

@ExtendWith(MockitoExtension.class)
public class EligibilityCategoryValidatorTest {

    @Mock
    DynamoDbTable<ValidationStatus> validationStatusTable;

    @Mock
    FormService formService;

    @InjectMocks
    private EligibilityCategoryValidator validator;

    private List<String> emptyList = List.of();
    private Map<String, String> emptyWarningMap = Maps.newHashMap();

    @Test
    void shouldPassValidationWhenEligibilityCategoriesAreTheSame() {

        String formId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        FormFields formFields = FormFields.builder().formId(formId).submissionId(submissionId)
                .eligibilityCategory("C 11").build();

        SubmissionForm form = SubmissionForm.builder().build();

        Submission submission = Submission.builder().submissionId(submissionId).status(DRAFT)
                .eligibilityCategory(I765EligibilityCategory.C11AFGHAN).forms(List.of(form)).build();

        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.PASS).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY).failureReasons(emptyList)
                .validationWarnings(emptyWarningMap)
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldPassValidationWhenEligibilityCategoriesAreTheSame_CaseInsensitive() {

        String formId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        FormFields formFields = FormFields.builder().formId(formId).submissionId(submissionId)
                .eligibilityCategory("a 1 2").build();

        SubmissionForm form = SubmissionForm.builder().build();

        Submission submission = Submission.builder().submissionId(submissionId).status(DRAFT)
                .eligibilityCategory(I765EligibilityCategory.A12).forms(List.of(form)).build();

        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.PASS).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY).failureReasons(emptyList)
                .validationWarnings(emptyWarningMap)
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldPassValidationWhenEligibilityCategory_C08() {

        String formId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        FormFields formFields = FormFields.builder().formId(formId).submissionId(submissionId)
                .eligibilityCategory("C 0 8").build();

        SubmissionForm form = SubmissionForm.builder().build();

        Submission submission = Submission.builder()
                .status(DRAFT).submissionId(submissionId)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms(List.of(form)).build();

        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.PASS).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .failureReasons(List.of())
                .validationWarnings(emptyWarningMap)
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenEligibilityCategoryIsInvalid_C008() {

        String formId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        FormFields formFields = FormFields.builder().formId(formId).submissionId(submissionId)
                .eligibilityCategory("C 0 0 8").build();

        SubmissionForm form = SubmissionForm.builder().build();

        Submission submission = Submission.builder()
                .status(DRAFT).submissionId(submissionId)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms(List.of(form)).build();

        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.PASS).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .failureReasons(emptyList)
                .validationWarnings(emptyWarningMap)
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenEligibilityCategoryIsOnlyALetter_C() {

        String formId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        FormFields formFields = FormFields.builder().formId(formId).submissionId(submissionId)
                .eligibilityCategory("C").build();

        SubmissionForm form = SubmissionForm.builder().build();

        Submission submission = Submission.builder()
                .status(DRAFT).submissionId(submissionId)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms(List.of(form)).build();

        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .failureReasons(List.of(EligibilityCategoryValidator.ELIGIBILITY_CATEGORY_MISMATCH))
                .validationWarnings(emptyWarningMap)
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenEligibilityCategoryIsInvalid_C011() {

        String formId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        FormFields formFields = FormFields.builder().formId(formId).submissionId(submissionId)
                .eligibilityCategory("C 0 1 1").build();

        SubmissionForm form = SubmissionForm.builder().build();

        Submission submission = Submission.builder()
                .status(DRAFT).submissionId(submissionId)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms(List.of(form)).build();

        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .failureReasons(List.of(EligibilityCategoryValidator.ELIGIBILITY_CATEGORY_MISMATCH))
                .validationWarnings(emptyWarningMap)
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenEligibilityCategoriesAreNotTheSameButEligible() {

        String formId = UUID.randomUUID().toString();
        String eligibilityCategoryOnForm = "C 11";
        String submissionId = UUID.randomUUID().toString();

        FormFields formFields = FormFields.builder().submissionId(submissionId).formId(formId)
                .eligibilityCategory(eligibilityCategoryOnForm)
                .build();

        SubmissionForm form = SubmissionForm.builder().build();
        Submission submission = Submission.builder()
                .submissionId(submissionId).formType(FormType.I765)
                .status(DRAFT)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms(List.of(form)).build();

        HashMap<String, String> warnings = Maps.newHashMap();
        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .validationWarnings(warnings)
                .failureReasons(List.of(EligibilityCategoryValidator.ELIGIBILITY_CATEGORY_MISMATCH))
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    @Disabled
    void shouldFailValidationWhenEligibilityCategoriesAreNotTheSameAndCategoryOnFormIsIneligibile() {

        String formId = UUID.randomUUID().toString();
        String eligibilityCategoryOnForm = "N 400";
        String submissionId = UUID.randomUUID().toString();

        FormFields formFields = FormFields.builder().submissionId(submissionId).formId(formId)
                .eligibilityCategory(eligibilityCategoryOnForm)
                .build();

        SubmissionForm form = SubmissionForm.builder().build();
        Submission submission = Submission.builder()
                .submissionId(submissionId)
                .formType(FormType.I765)
                .status(DRAFT)
                .eligibilityCategory(I765EligibilityCategory.C11AFGHAN)
                .forms(List.of(form)).build();

        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .failureReasons(List.of(EligibilityCategoryValidator.ELIGIBILITY_CATEGORY_MISMATCH))
                .validationWarnings(emptyWarningMap)
                .build();
        when(formService.retrieveEligibilityCategories(submission.getFormType().getType()))
                .thenReturn(List.of(new EligibilityCategoryResponse("C 11 - Parole", false, false)));

        validator.validate(submission, formFields);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenEligibilityCategoryWasMissingOnForm() {

        var formId = UUID.randomUUID().toString();
        var submissionId = UUID.randomUUID().toString();
        var formFields = FormFields.builder().formId(formId).submissionId(submissionId).eligibilityCategory("").build();

        var form = SubmissionForm.builder().build();
        var submission = Submission.builder()
                .submissionId(submissionId)
                .status(DRAFT)
                .eligibilityCategory(I765EligibilityCategory.C11AFGHAN)
                .forms(List.of(form)).build();

        var expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .validationWarnings(emptyWarningMap)
                .failureReasons(List.of(
                        "There was no Eligibility Category detected on the form. Please review your selection to prevent your application from being rejected."))
                .build();
        validator.validate(submission, formFields);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenEligibilityCategoryNotSelectedInApplication() {
        var formId = UUID.randomUUID().toString();
        var submissionId = UUID.randomUUID().toString();
        var formFields = FormFields.builder().formId(formId).submissionId(submissionId).eligibilityCategory("C 9")
                .build();

        var form = SubmissionForm.builder().build();
        var submission = Submission.builder().submissionId(submissionId).status(DRAFT).forms(List.of(form)).build();

        var expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .validationWarnings(emptyWarningMap)
                .failureReasons(List.of(EligibilityCategoryValidator.ELIGIBILITY_CATEGORY_NOT_SELECTED))
                .build();

        validator.validate(submission, formFields);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }
}
