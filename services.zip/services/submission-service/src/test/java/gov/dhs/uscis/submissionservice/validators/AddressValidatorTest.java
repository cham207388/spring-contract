package gov.dhs.uscis.submissionservice.validators;

import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.validation.address_extract.AddressValidationResult;
import gov.dhs.uscis.intake.models.validation.address_extract.ClientAddress;
import gov.dhs.uscis.submissionservice.repository.AddressExtractRepository;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;

@ExtendWith(MockitoExtension.class)
public class AddressValidatorTest {

    AddressExtractRepository addressExtractDAO = mock(AddressExtractRepository.class);
    ValidationStatusRepository statusDAO = mock(ValidationStatusRepository.class);
    SubmissionRepository submissionRepository = mock(SubmissionRepository.class);
    AddressValidator addressValidator = new AddressValidator(statusDAO);

    String submissionId = UUID.randomUUID().toString();
    String formId = UUID.randomUUID().toString();
    String g28FormId = UUID.randomUUID().toString();
    FormType formType = FormType.I765;
    FormType g28FormType = FormType.G28;

    SubmissionForm g28 = SubmissionForm.builder().id(formId).build();
    SubmissionForm I765 = SubmissionForm.builder().id(g28FormId).build();
    Submission submission = Submission.builder().submissionId(submissionId).forms(List.of(g28, I765)).build();

    @BeforeEach
    void setUp() {
        reset(addressExtractDAO, statusDAO);
    }

    @Test
    public void shouldPassValidationWhenFieldsAreFilled() {
        ClientAddress clientAddressI765 = ClientAddress.builder()
                .cityOrTown("cityOrTown")
                .state("TN")
                .streetNumberAndName("2121 street")
                .zipCode("33333")
                .build();

        ValidationStatusRepository statusRepository = mock(ValidationStatusRepository.class);
        AddressValidationResult result = AddressValidationResult.builder()
                .submissionId(submissionId)
                .formId(formId)
                .formType(formType.getType())
                .clientAddress(clientAddressI765)
                .build();

        when(submissionRepository.getById(submissionId)).thenReturn(Optional.of(submission));

        AddressValidator addressValidator = new AddressValidator(statusRepository);

        addressValidator.validate(result);

        verify(statusRepository, times(1)).save(argThat(
                status -> status.getStatus() == ValidationResultEnum.PASS && status.getFailureReasons().isEmpty() && status.getValidator().equals(ValidatorEnum.G28_COMP)));
    }

    @Test
    public void shouldFailValidationWhenAFieldIsMissing() {
        ClientAddress clientAddressI765 = ClientAddress.builder()
                .cityOrTown("cityOrTown")
                .streetNumberAndName("2121 street")
                .zipCode("33333")
                .build();

        ValidationStatusRepository statusRepository = mock(ValidationStatusRepository.class);
        AddressValidationResult result = AddressValidationResult.builder()
                .submissionId(submissionId)
                .formId(formId)
                .formType(formType.getType())
                .clientAddress(clientAddressI765)
                .build();

        when(submissionRepository.getById(submissionId)).thenReturn(Optional.of(submission));

        AddressValidator addressValidator = new AddressValidator(statusRepository);

        addressValidator.validate(result);

        verify(statusRepository, times(1)).save(argThat(
                status -> status.getStatus() == ValidationResultEnum.FAIL
                && !status.getFailureReasons().isEmpty()
                && status.getFailureReasons().get(0).equals(String.format(AddressValidator.INCOMPLETE_FAILURE_MESSAGE, formType.getType()))
                && status.getValidator().equals(ValidatorEnum.G28_COMP)));
    }

    @Test
    public void shouldFailValidationWhenClientAddressIsNull() {
        ValidationStatusRepository statusRepository = mock(ValidationStatusRepository.class);
        AddressValidationResult result = AddressValidationResult.builder()
                .submissionId(submissionId)
                .formId(formId)
                .formType(formType.getType())
                .build();

        when(submissionRepository.getById(submissionId)).thenReturn(Optional.of(submission));

        AddressValidator addressValidator = new AddressValidator(statusRepository);

        addressValidator.validate(result);

        verify(statusRepository, times(1)).save(argThat(
                status -> status.getStatus() == ValidationResultEnum.FAIL
                && !status.getFailureReasons().isEmpty()
                && status.getFailureReasons().get(0).equals(String.format(AddressValidator.INCOMPLETE_FAILURE_MESSAGE, formType.getType()))
                && status.getValidator().equals(ValidatorEnum.G28_COMP)));
    }
}
