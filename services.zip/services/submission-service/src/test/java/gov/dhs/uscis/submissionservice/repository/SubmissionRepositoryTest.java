package gov.dhs.uscis.submissionservice.repository;

import static gov.dhs.uscis.intake.entities.submission.SubmissionState.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.net.URI;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import gov.dhs.uscis.submissionservice._testutils.LocalDbCreationRule;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.services.AuditService;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.ScanRequest;

public class SubmissionRepositoryTest {

    private static final String TABLE_NAME = "default-Submission";
    private final String myUscisId = UUID.randomUUID().toString();
    private final String orgMyUscisId = "O-" + UUID.randomUUID().toString();

    @RegisterExtension
    static LocalDbCreationRule localDynamoDb = new LocalDbCreationRule();
  
    private static DynamoDbClient dynamoDbClient;
    private static DynamoDbEnhancedClient dynamoDbEnhancedClient;
    private static DynamoDbTable<Submission> submissionTable;
    private static SubmissionRepository submissionRepository;        

    private static String testManifestId;
    private static AuditService auditService;
    private static ClientInformationRepository clientRepository;

    @BeforeAll
    private static void before() {

        testManifestId = UUID.randomUUID().toString();
        auditService = mock(AuditService.class);
        clientRepository = mock(ClientInformationRepository.class);

        dynamoDbClient = DynamoDbClient
        .builder()
        .endpointOverride(URI.create(String.format("http://localhost:%s", localDynamoDb.getPort())))
        .build();

        dynamoDbEnhancedClient = DynamoDbEnhancedClient
                .builder()
                .dynamoDbClient(dynamoDbClient)
                .build();

        submissionTable = dynamoDbEnhancedClient.table(TABLE_NAME, TableSchema.fromBean(Submission.class));
        submissionTable.createTable();

        submissionRepository = new SubmissionRepository(submissionTable, clientRepository, auditService, dynamoDbEnhancedClient);

    }

    @BeforeEach
    private void beforeEach() {
        dynamoDbClient.waiter().waitUntilTableExists(b -> b.tableName(TABLE_NAME));
    }

    @AfterEach
    private void afterEach() {
        submissionTable.deleteTable();
        submissionTable.createTable();
    }

    private Submission generate() {
        return Submission.builder()
                .formType(FormType.I765)
                .myUscisId(myUscisId)
                .orgMyUscisId(myUscisId)
                .submissionId(UUID.randomUUID().toString())
                .lockedAt(ZonedDateTime.now())
                .updatedAt(ZonedDateTime.now())
                .applicant(new UserInformation(myUscisId, null, "fake@email.com", AccountType.APPLICANT))
                .build();
    }

    private int count() {
        ScanRequest request = ScanRequest.builder()
                .tableName(submissionTable.tableName())
                .select("COUNT").build();
        return dynamoDbClient.scan(request).count();
    }

    @Test
    public void save_shouldPersist() {
        Submission s = generate();
        Submission actual = submissionRepository.save(s);
        assertEquals(1, count());
        assertSame(s, actual);
        assertNotNull(s.getUpdatedAt());

        var item = dynamoDbClient.getItem(GetItemRequest.builder()
                .tableName(TABLE_NAME)
                .key(Map.of("submissionId", AttributeValue.fromS(s.getSubmissionId())))
                .build()).item();
        assertThat(item.get("submissionId").s(), equalTo(s.getSubmissionId()));
        // TODO: Check formatting of dates here.
    }

    @Test
    public void getById_shouldSucceed() {
        Submission s = submissionRepository.save(generate());
        Submission actual = submissionRepository.getById(s.getSubmissionId()).orElseThrow();
        // FIXME: updatedAt does not symmetrically de/serialize
        assertThat(actual, samePropertyValuesAs(s, "updatedAt"));
    }

    @Test
    public void getByManifestId_shouldSucceed() {
        Submission s = generate();
        s.setManifestId(testManifestId);
        submissionRepository.save(s);

        Submission actual = submissionRepository.getByManifestId(s.getManifestId()).orElseThrow();
        assertThat(actual, samePropertyValuesAs(s, "updatedAt"));
    }

    @Test
    public void getByManifestId_shouldSucceed_case_insensitive() {
        Submission s = generate();
        s.setManifestId(testManifestId);
        submissionRepository.save(s);

        Submission actual = submissionRepository.getByManifestId(s.getManifestId().toUpperCase()).orElseThrow();
        assertThat(actual, samePropertyValuesAs(s, "updatedAt"));
    }

    @Test
    public void getByManifestId_shouldReturnEmpty() {
        Submission s = generate();
        s.setManifestId(testManifestId);
        submissionRepository.save(s);

        String manifestId = UUID.randomUUID().toString();
        Optional<Submission> response = submissionRepository.getByManifestId(manifestId);
        assertFalse(response.isPresent());
    }

    @Test
    public void findAllByMyUscisId_shouldSucceed() {

        Submission reject = submissionRepository.save(
                Submission.builder().submissionId(UUID.randomUUID().toString()).myUscisId(myUscisId).status(REJECTED)
                        .applicant(UserInformation.builder().build()).formType(FormType.I765)
                        .build());
        Submission draft = submissionRepository.save(
                Submission.builder().submissionId(UUID.randomUUID().toString()).myUscisId(myUscisId).status(DRAFT)
                        .applicant(UserInformation.builder().build()).formType(FormType.I765)
                        .build());

        List<Submission> result = submissionRepository.findAllDraftsByMyUscisId(myUscisId);
        assertThat(result, hasSize(1));
        assertThat(result, contains(hasProperty("submissionId", equalTo(draft.getSubmissionId()))));
        assertThat(result, not(contains(hasProperty("submissionId", equalTo(reject.getSubmissionId())))));
    }

    @Test
    public void update_shouldSucceed() {

        Submission s = submissionRepository.save(generate());
        ZonedDateTime start = s.getUpdatedAt();

        s.setFeeTotal(new BigDecimal("123.45"));
        submissionRepository.update(s);

        Submission actual = submissionRepository.getById(s.getSubmissionId()).orElseThrow();
        boolean compareUpdatedAtTime = actual.getUpdatedAt().isAfter(start);
        assertEquals(s.getFeeTotal(), actual.getFeeTotal());
        assertTrue(compareUpdatedAtTime);
        verify(auditService, times(1)).addEvent(myUscisId, s.getSubmissionId(), ActionPerformed.SUBMISSION_UPDATED,
                null);
    }

    @Test
    public void updateSubmissionLock_shouldSucceed() {

        Submission s = submissionRepository.save(generate());
        ZonedDateTime start = s.getLockedAt();

        s.setFeeTotal(new BigDecimal("123.45"));
        submissionRepository.updateSubmissionLock(s);

        Submission actual = submissionRepository.getById(s.getSubmissionId()).orElseThrow();
        boolean compareLockedAtTime = actual.getLockedAt().isAfter(start);

        assertEquals(s.getFeeTotal(), actual.getFeeTotal());
        assertTrue(compareLockedAtTime);
    }

    @Test
    void deleteById_shouldAlwaysSucceed() {
        Submission s = submissionRepository.save(generate());
        assertEquals(1, count());
        submissionRepository.deleteById(s.getSubmissionId());
        assertEquals(0, count());

        // Delete should succeed even if the ID does not exist.
        assertDoesNotThrow(() -> submissionRepository.deleteById(UUID.randomUUID().toString()));
    }

    @Test
    public void shouldNotBlowUpIfThereAreNoFilters() {
        Submission reject = submissionRepository.save(
                Submission.builder().submissionId(UUID.randomUUID().toString()).myUscisId(myUscisId).status(REJECTED).formType(FormType.I765)
                        .build());
        Submission draft = submissionRepository.save(
                Submission.builder().submissionId(UUID.randomUUID().toString()).myUscisId(myUscisId).status(DRAFT).formType(FormType.I765)
                        .build());

        List<Submission> result = submissionRepository.findAllByMyUscisIdAndStatus(myUscisId, new ArrayList());
        assertThat(result, hasSize(2));
    }

    @Test
    public void shouldNotBlowUpApplicantIfThereAreNoFilters() {
        String applicantUUID = UUID.randomUUID().toString();

        submissionRepository.save(
                Submission.builder().submissionId(UUID.randomUUID().toString()).myUscisId(myUscisId).status(REJECTED)
                        .applicant(UserInformation.builder()
                                .myUscisId(applicantUUID)
                                .build())
                        .formType(FormType.I765)
                        .build());

        submissionRepository.save(
                Submission.builder().submissionId(UUID.randomUUID().toString()).myUscisId(myUscisId).status(DRAFT)
                        .applicant(UserInformation.builder()
                                .myUscisId(applicantUUID)
                                .build())
                        .formType(FormType.I765)
                        .build());

        List<Submission> result = submissionRepository.findAllByMyUscisIdAndStatuswithApplicant(applicantUUID, new ArrayList());

        assertThat(result, hasSize(2));

    }

    @Test
    public void shouldNotBlowUpApplicantIfThereAre() {
        String applicantUUID = UUID.randomUUID().toString();

        Submission reject = submissionRepository.save(
                Submission.builder().submissionId(UUID.randomUUID().toString()).myUscisId(myUscisId).status(REJECTED).formType(FormType.I765)
                        .applicant(UserInformation.builder()
                                .myUscisId(applicantUUID)
                                .build())
                        .build());

        Submission draft = submissionRepository.save(
                Submission.builder().submissionId(UUID.randomUUID().toString()).myUscisId(myUscisId).status(DRAFT).formType(FormType.I765)
                        .applicant(UserInformation.builder()
                                .myUscisId(applicantUUID)
                                .build())
                        .build());

        List<Submission> resultForDraft = submissionRepository.findAllByMyUscisIdAndStatuswithApplicant(applicantUUID,
                Arrays.asList(DRAFT));

        assertThat(resultForDraft, hasSize(1));

    }

    @Test
    public void shouldGetDraftSubmissionById() {
        Submission submission = generate();
        submission.setStatus(SubmissionState.DRAFT);
        submissionRepository.save(submission);

        Optional<Submission> draftSubmission = submissionRepository.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId());
        assertTrue(draftSubmission.isPresent());
        assertEquals(submission, draftSubmission.get());
    }

    @Test
    public void shouldOnlyGetDraftSubmissionById() {
        Submission submission = generate();
        submission.setStatus(SubmissionState.DELETED);
        submissionRepository.save(submission);

        Optional<Submission> draftSubmission = submissionRepository.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId());
        assertFalse(draftSubmission.isPresent());
    }

    @Test
    public void shouldFindSubmissionBySubmissionIdAndMyUscisId() {
        Submission expected = generate();
        expected.setStatus(SubmissionState.DRAFT);
        submissionRepository.save(expected);

        Optional<Submission> actual = submissionRepository.findBySubmissionIdAndUscisId(expected.getSubmissionId(), myUscisId, orgMyUscisId);
        assertEquals(expected, actual.get());
    }

    @Test
    public void shouldNotReturnSubmissionWhenDoesNotExists() {
        Optional<Submission> actual = submissionRepository.findBySubmissionIdAndUscisId(UUID.randomUUID().toString(), myUscisId, orgMyUscisId);
        assertTrue(actual.isEmpty());
    }

    @Test
    public void shouldFindAllClientSubmissions() {
        String submissionIdA = UUID.randomUUID().toString();
        String submissionIdB = UUID.randomUUID().toString();
        Submission reject = submissionRepository.save(
                Submission.builder().submissionId(submissionIdA).myUscisId(UUID.randomUUID().toString())
                        .status(REJECTED)
                        .formType(FormType.I765)
                        .build());
        Submission draft = submissionRepository.save(
                Submission.builder().submissionId(submissionIdB).myUscisId(UUID.randomUUID().toString()).status(DRAFT).formType(FormType.I765)
                        .build());

        when(clientRepository.findAllByClientId(myUscisId)).thenReturn(List.of(
                ClientInformation.builder().submissionId(submissionIdA).build(),
                ClientInformation.builder().submissionId(submissionIdB).build()));

        List<Submission> result = submissionRepository.findAllByMyUscisIdAndStatus(myUscisId, List.of(REJECTED, RECEIVED));
        assertThat(result, hasSize(1));
        Submission submission = result.get(0);
        assertThat(submission.getSubmissionId(), equalTo(reject.getSubmissionId()));
        assertThat(submission.getStatus(), equalTo(reject.getStatus()));
    }
    
    @Test
    public void shouldFindAllClientOrgSubmissions() {
    	String orgMyUscisId = "O-ORGUUID";
    	
        String submissionIdA = UUID.randomUUID().toString();
        String submissionIdB = UUID.randomUUID().toString();
        Submission reject = submissionRepository.save(
                Submission.builder().submissionId(submissionIdA).myUscisId(UUID.randomUUID().toString())
                        .status(REJECTED)
                        .formType(FormType.I765)
                        .build());
        Submission draft = submissionRepository.save(
                Submission.builder().submissionId(submissionIdB).myUscisId(UUID.randomUUID().toString()).status(DRAFT).formType(FormType.I765)
                        .build());

        when(clientRepository.findAllByClientId(orgMyUscisId)).thenReturn(List.of(
                ClientInformation.builder().submissionId(submissionIdA).build(),
                ClientInformation.builder().submissionId(submissionIdB).build()));

        List<Submission> result = submissionRepository.findAllByOrgMyUscisIdAndStatus(orgMyUscisId, List.of(REJECTED, RECEIVED));
        assertThat(result, hasSize(1));
        Submission submission = result.get(0);
        assertThat(submission.getSubmissionId(), equalTo(reject.getSubmissionId()));
        assertThat(submission.getStatus(), equalTo(reject.getStatus()));
    }

    @Test
    public void shouldNotShowDraftsForClient() {
        String submissionIdA = UUID.randomUUID().toString();
        String submissionIdB = UUID.randomUUID().toString();
        Submission reject = submissionRepository.save(
                Submission.builder().submissionId(submissionIdA).myUscisId(UUID.randomUUID().toString())
                        .status(REJECTED)
                        .formType(FormType.I765)
                        .build());
        Submission draft = submissionRepository.save(
                Submission.builder().submissionId(submissionIdB).myUscisId(UUID.randomUUID().toString()).status(DRAFT).formType(FormType.I765)
                        .build());

        when(clientRepository.findAllByClientId(myUscisId)).thenReturn(List.of(
                ClientInformation.builder().submissionId(submissionIdA).build(),
                ClientInformation.builder().submissionId(submissionIdB).build()));

        List<Submission> result = submissionRepository.findAllByMyUscisIdAndStatus(myUscisId, List.of(REJECTED, DRAFT));
        assertThat(result, hasSize(1));
        Submission submission = result.get(0);
        assertThat(submission.getSubmissionId(), equalTo(reject.getSubmissionId()));
        assertThat(submission.getStatus(), equalTo(reject.getStatus()));
    }
}
