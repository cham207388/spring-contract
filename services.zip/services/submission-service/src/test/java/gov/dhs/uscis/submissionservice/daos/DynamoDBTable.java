package gov.dhs.uscis.submissionservice.daos;

public class DynamoDBTable<T> {

}
