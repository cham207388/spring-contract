package gov.dhs.uscis.submissionservice.validators;

import static gov.dhs.uscis.intake.enums.ValidatorEnum.CORE;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.ELIGIBILITY_CATEGORY;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.SIGNATURE;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.FAIL;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.WARN;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import java.util.List;

import org.junit.jupiter.api.Test;

import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import gov.dhs.uscis.intake.models.validation.ValidationDetails;
import jakarta.validation.ConstraintValidatorContext;


// Assumption: we will always receive a validation for Eligibility and for Signature

public class FormValidatorTest {

    private FormValidator validator = new FormValidator(); 

    @Test
    public void shouldReturnFalseWhenCoreValidationIsFailed() {
        FinalSubmissionDto submission = FinalSubmissionDto.builder().
                validations(List.of(ValidationDetails.builder().validator(CORE).result(FAIL).build())).build();
        assertFalse(validator.isValid(submission, mock(ConstraintValidatorContext.class)));
    }

    @Test
    public void shouldReturnFalseWhenEligibilityValidatorHasFailed() {
        FinalSubmissionDto submission = FinalSubmissionDto.builder().
                validations(List.of(ValidationDetails.builder().validator(CORE).result(WARN).build(),
                                    ValidationDetails.builder().validator(ELIGIBILITY_CATEGORY).result(FAIL).build())).build();
        assertFalse(validator.isValid(submission, mock(ConstraintValidatorContext.class)));
    }

    @Test
    public void shouldReturnTrueWhenSignatureValidatorHasFailedButIsAttested() {
        FinalSubmissionDto submission = FinalSubmissionDto.builder().
                validations(List.of(ValidationDetails.builder().validator(CORE).result(WARN).build(),
                                    ValidationDetails.builder().validator(ELIGIBILITY_CATEGORY).result(WARN).build(),
                                    ValidationDetails.builder().validator(SIGNATURE).result(FAIL).build())).
                attested(true).
                signature("some signature").
                build();
        assertTrue(validator.isValid(submission, mock(ConstraintValidatorContext.class)));
    }

    @Test
    public void shouldReturnTrueWhenSignatureValidationIsOkAndIsNotAttested() {
        FinalSubmissionDto submission = FinalSubmissionDto.builder().
                validations(List.of(ValidationDetails.builder().validator(CORE).result(WARN).build(),
                                    ValidationDetails.builder().validator(ELIGIBILITY_CATEGORY).result(WARN).build(),
                                    ValidationDetails.builder().validator(SIGNATURE).result(WARN).build())).
                attested(false).
                signature(null).
                build();
        assertTrue(validator.isValid(submission, mock(ConstraintValidatorContext.class)));
    }

    @Test
    public void shouldReturnFalseWhenSignatureValidatorHasFailedAndAttestationIsMissing() {
        FinalSubmissionDto submission = FinalSubmissionDto.builder().
                validations(List.of(ValidationDetails.builder().validator(CORE).result(WARN).build(),
                                    ValidationDetails.builder().validator(ELIGIBILITY_CATEGORY).result(WARN).build(),
                                    ValidationDetails.builder().validator(SIGNATURE).result(FAIL).build())).
                attested(false).
                build();
        assertFalse(validator.isValid(submission, mock(ConstraintValidatorContext.class)));
    }

    @Test
    public void shouldReturnFalseWhenSignatureValidatorHasFailedAndAttestationSignatureIsEmpty() {
        FinalSubmissionDto submission = FinalSubmissionDto.builder().
                validations(List.of(ValidationDetails.builder().validator(CORE).result(WARN).build(),
                                    ValidationDetails.builder().validator(ELIGIBILITY_CATEGORY).result(WARN).build(),
                                    ValidationDetails.builder().validator(SIGNATURE).result(FAIL).build())).
                attested(true).
                signature("").
                build();
        assertFalse(validator.isValid(submission, mock(ConstraintValidatorContext.class)));
    }

    @Test
    public void shouldReturnFalseWhenSignatureValidatorHasFailedAndAttestationSignatureIsMissing() {
        FinalSubmissionDto submission = FinalSubmissionDto.builder().
                validations(List.of(ValidationDetails.builder().validator(CORE).result(WARN).build(),
                                    ValidationDetails.builder().validator(ELIGIBILITY_CATEGORY).result(WARN).build(),
                                    ValidationDetails.builder().validator(SIGNATURE).result(FAIL).build())).
                attested(true).
                signature(null).
                build();
        assertFalse(validator.isValid(submission, mock(ConstraintValidatorContext.class)));
    }
}
