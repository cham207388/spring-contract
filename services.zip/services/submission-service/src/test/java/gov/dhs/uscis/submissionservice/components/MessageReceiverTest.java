package gov.dhs.uscis.submissionservice.components;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.assertj.core.util.Lists;
import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import software.amazon.awssdk.services.sns.model.InvalidStateException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.N400EligibilityCategory;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.enums.ValidatorInfo;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.validation.ClientNameEmailResponse;
import gov.dhs.uscis.intake.models.validation.FormFieldResult;
import gov.dhs.uscis.intake.models.validation.N400FormFieldResult;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResult;
import gov.dhs.uscis.intake.models.validation.address_extract.AddressValidationResult;
import gov.dhs.uscis.intake.models.validation.name_extract.NameValidationResult;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ToggleService;
import gov.dhs.uscis.submissionservice.services.ValidationService;
import gov.dhs.uscis.submissionservice.validators.AddressValidator;
import gov.dhs.uscis.submissionservice.validators.NameValidator;
import gov.dhs.uscis.submissionservice.validators.PersonValidator;
import gov.dhs.uscis.submissionservice.validators.AttorneyProfileValidator.AttorneyNameMatchesFormValidator;
import gov.dhs.uscis.submissionservice.validators.AttorneyProfileValidator.ClientNameEmailValidator;
import gov.dhs.uscis.submissionservice.validators.i765.AbcBenefitsAppliedValidator;
import gov.dhs.uscis.submissionservice.validators.i765.EligibilityCategoryValidator;
import gov.dhs.uscis.submissionservice.validators.i765.ReasonForFilingValidator;
import gov.dhs.uscis.submissionservice.validators.n400.BasisOfEligibilityValidator;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.DeleteMessageRequest;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;

@ExtendWith(MockitoExtension.class)
public class MessageReceiverTest {

    @Mock
    DynamoDbTable<ValidationStatus> validationStatusTable;

    @Mock
    SqsClient sqsClient;

    @Mock
    EligibilityCategoryValidator eligibilityCategoryValidator;

    @Mock
    ReasonForFilingValidator reasonForFilingValidator;

    @Mock
    BasisOfEligibilityValidator basisOfEligibilityValidator;

    @Mock
    AbcBenefitsAppliedValidator abcBenefitsAppliedValidator;

    @Mock
    PersonValidator personValidator;

    @Mock
    SubmissionService submissionService;

    @Mock
    AuditService auditService;

    @Mock
    ValidationService validationService;

    @Mock
    NameValidator nameValidator;

    @Mock
    AddressValidator addressValidator;

    @Mock
    ClientNameEmailValidator clientNameEmailValidator;

    @Mock
    AttorneyNameMatchesFormValidator attorneyNameMatchesFormValidator;

    @Mock
    ToggleService toggleService;

    @InjectMocks
    MessageReceiver receiver;

    @Test
    void shouldPollAndProcessValidationResultMessage() throws JsonProcessingException {
        String validationQueueURL = "validation queue url";
        ReflectionTestUtils.setField(receiver, "queueUrl", validationQueueURL);
        String aFailureReason = "a failure reason";
        String submissionId = UUID.randomUUID().toString();
        String myUscisId = UUID.randomUUID().toString();

        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        String receiptHandle = "receiptHandler";
        ValidationStatusResult expected = ValidationStatusResult.builder()
                .validator(ValidatorEnum.CORE)
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .status(ValidationResultEnum.FAIL)
                .failureReasons(List.of(Map.of("failure", aFailureReason)))
                .build();

        Message expectedMessage = Message.builder()
                .body(new ObjectMapper().writeValueAsString(expected))
                .receiptHandle(receiptHandle).build();

        when(mockResponse.messages()).thenReturn(List.of(expectedMessage));
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receiveValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(validationQueueURL, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(validationQueueURL, actualDeleteRequest.queueUrl());

        verify(validationService, times(1)).createFrom(eq(expected));
    }

    @Test
    void shouldPollAndProcessSignatureValidationResultMessage() throws JsonProcessingException {
        String validationQueueURL = "validation queue url";
        ReflectionTestUtils.setField(receiver, "queueUrl", validationQueueURL);
        String aFailureReason = "a failure reason";
        String submissionId = UUID.randomUUID().toString();
        String myUscisId = UUID.randomUUID().toString();

        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        String receiptHandle = "receiptHandler";
        String messageId = "messageId";
        ValidationStatusResult expected = ValidationStatusResult.builder()
                .validator(ValidatorEnum.SIGNATURE)
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .status(ValidationResultEnum.FAIL)
                .failureReasons(List.of(Map.of("failure", aFailureReason)))
                .build();

        Message expectedMessage = Message.builder()
                .body(new ObjectMapper().writeValueAsString(expected))
                .messageId(messageId)
                .receiptHandle(receiptHandle).build();

        when(mockResponse.messages()).thenReturn(List.of(expectedMessage));
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receiveValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(validationQueueURL, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(validationQueueURL, actualDeleteRequest.queueUrl());

        verify(validationService, times(1)).saveSignatureResult(eq(expected), eq(messageId));
    }

    @Test
    void shouldPollAndProcessI912ValidationResultMessage() throws JsonProcessingException {
        String i912ResultQueue = "validation queue url";
        ReflectionTestUtils.setField(receiver, "i912ResultQueue", i912ResultQueue);
        String aFailureReason = "a failure reason";
        String submissionId = UUID.randomUUID().toString();
        String myUscisId = UUID.randomUUID().toString();

        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        String receiptHandle = "receiptHandler";
        ValidationStatusResult expected = ValidationStatusResult.builder()
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .status(ValidationResultEnum.FAIL)
                .failureReasons(List.of(Map.of("failure", aFailureReason)))
                .build();

        Message expectedMessage = Message.builder()
                .body(new ObjectMapper().writeValueAsString(expected))
                .receiptHandle(receiptHandle).build();

        when(mockResponse.messages()).thenReturn(List.of(expectedMessage));
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receiveI912ValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(i912ResultQueue, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(i912ResultQueue, actualDeleteRequest.queueUrl());

        verify(validationService, times(1)).createFrom(eq(expected));
    }

    @Test
    void shouldPollAndProcessI912ValidationResultMessageForI751() throws JsonProcessingException {
        String i912ResultQueue = "validation queue url";
        ReflectionTestUtils.setField(receiver, "i912ResultQueue", i912ResultQueue);
        String submissionId = UUID.randomUUID().toString();
        String myUscisId = UUID.randomUUID().toString();
        String orgMyUscisId = UUID.randomUUID().toString();

        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        String receiptHandle = "receiptHandler";
        ValidationStatusResult expected = ValidationStatusResult.builder()
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .status(ValidationResultEnum.PASS)
                .validationWarnings(Map.of(ValidatorInfo.IS_I912_FORM.toString(), String.valueOf(Boolean.TRUE.equals(Boolean.TRUE))))
                .build();

                Submission submission = new Submission();
                submission.setStatus(SubmissionState.DRAFT);
                submission.setFormType(FormType.I751);
                submission.setSubmissionId(submissionId);
                when(submissionService.retrieveDraftSubmission(myUscisId, null, submissionId))
                        .thenReturn(submission);
                          Message expectedMessage = Message.builder()
                .body(new ObjectMapper().writeValueAsString(expected))
                .receiptHandle(receiptHandle).build();

        when(mockResponse.messages()).thenReturn(List.of(expectedMessage));
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receiveI912ValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(i912ResultQueue, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(i912ResultQueue, actualDeleteRequest.queueUrl());

        verify(validationService, times(1)).createFrom(eq(expected));
    }
      @Test
    void shouldPollAndProcessI912ValidationResultMessageForI765() throws JsonProcessingException {
        String i912ResultQueue = "validation queue url";
        ReflectionTestUtils.setField(receiver, "i912ResultQueue", i912ResultQueue);
        String submissionId = UUID.randomUUID().toString();
        String myUscisId = UUID.randomUUID().toString();
        String orgMyUscisId = UUID.randomUUID().toString();
        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        String receiptHandle = "receiptHandler";
        ValidationStatusResult expected = ValidationStatusResult.builder()
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .status(ValidationResultEnum.PASS)
                .validationWarnings(Map.of(ValidatorInfo.IS_I912_FORM.toString(), String.valueOf(Boolean.TRUE.equals(Boolean.TRUE))))
                .build();

                Submission submission = new Submission();
                submission.setStatus(SubmissionState.DRAFT);
                submission.setFormType(FormType.I765);
                submission.setSubmissionId(submissionId);
                when(submissionService.retrieveDraftSubmission(myUscisId, null, submissionId))
                        .thenReturn(submission);
                          Message expectedMessage = Message.builder()
                .body(new ObjectMapper().writeValueAsString(expected))
                .receiptHandle(receiptHandle).build();

        when(mockResponse.messages()).thenReturn(List.of(expectedMessage));
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receiveI912ValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(i912ResultQueue, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(i912ResultQueue, actualDeleteRequest.queueUrl());

        verify(validationService, times(1)).createFrom(eq(expected));
    }
    // TODO Potentiall remove this when PFVS is on
    @Test
    void shouldPollAndProcessFieldValidationResultMessage() throws JsonProcessingException {
        String fieldValidationQueueURL = "validation queue url";

        ReflectionTestUtils.setField(receiver, "fieldQueueUrl", fieldValidationQueueURL);
        FormFields formFields = Instancio.create(FormFields.class);

        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        List<Message> messages = Lists.newArrayList();
        String receiptHandle = "receiptHandler";

        Message message = Message.builder()
                .body(new ObjectMapper().writeValueAsString(formFields))
                .receiptHandle(receiptHandle).build();
        messages.add(message);

        when(mockResponse.messages()).thenReturn(messages);
        Submission submission = Instancio.create(Submission.class);
        submission.setStatus(SubmissionState.DRAFT);
        submission.setFormType(FormType.I765);
        when(submissionService.retrieveSubmission(formFields.submissionId())).thenReturn(submission);
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        List<FormFields> statusResults = receiver.receiveFormFieldsValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());
        verify(eligibilityCategoryValidator, times(1)).validate(submission, formFields);
        verify(reasonForFilingValidator, times(1)).validate(submission, formFields);
        verify(abcBenefitsAppliedValidator, times(1)).validate(submission, formFields);
        verify(personValidator, times(1)).validate(
                formFields.alienNumber(),
                formFields.dateOfBirth(),
                formFields.formId(),
                formFields.submissionId(), submission.getFormType());
        verify(submissionService, times(1)).updateSubmissionWithFormFields(formFields, submission.getFormType());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(fieldValidationQueueURL, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(fieldValidationQueueURL, actualDeleteRequest.queueUrl());

        assertFalse(statusResults.isEmpty());
        assertEquals(formFields, statusResults.get(0));
    }

    @Test
    void shouldPollAndProcessEligibilityValidationResultMessage() throws JsonProcessingException {
        String eligibilityResultQueue = "eligibility queue url";

        ReflectionTestUtils.setField(receiver, "eligibilityResultQueue", eligibilityResultQueue);
        FormFieldResult eligibilityValidationStatusResult = Instancio.create(N400FormFieldResult.class);
        eligibilityValidationStatusResult.setSelectedCategories(List.of(N400EligibilityCategory.GENERAL_PROVISION));

        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        List<Message> messages = Lists.newArrayList();
        String receiptHandle = "receiptHandler";

        Message message = Message.builder()
                .body(new ObjectMapper().writeValueAsString(eligibilityValidationStatusResult))
                .receiptHandle(receiptHandle).build();
        messages.add(message);

        Submission submission = new Submission();
        submission.setStatus(SubmissionState.DRAFT);
        submission.setFormType(FormType.N400);
        when(submissionService.retrieveSubmission(eligibilityValidationStatusResult.getSubmissionId()))
                .thenReturn(submission);
        when(mockResponse.messages()).thenReturn(messages);
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);
        receiver.receiveEligibilityValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(eligibilityResultQueue, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(eligibilityResultQueue, actualDeleteRequest.queueUrl());

        verify(basisOfEligibilityValidator, times(1)).validate(submission, eligibilityValidationStatusResult);
        ArgumentCaptor<FormFields> formFieldsCaptor = ArgumentCaptor.forClass(FormFields.class);
        verify(submissionService, times(1)).updateSubmissionWithFormFields(formFieldsCaptor.capture(), eq(submission.getFormType()));
        FormFields expected = FormFields.builder()
                .formId(eligibilityValidationStatusResult.getFormId())
                .submissionId(eligibilityValidationStatusResult.getSubmissionId())
                .abcBenefitsApplied(false)
                .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION.getCategory())
                .build();
        assertThat(formFieldsCaptor.getValue()).isEqualTo(expected);
    }

    @Test
    void shouldPollAndProcessPersonValidationResultMessage() throws JsonProcessingException {
        String personResultQueue = "person queue url";

        ReflectionTestUtils.setField(receiver, "personResultQueue", personResultQueue);
        FormFieldResult formFields = Instancio.create(N400FormFieldResult.class);
        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        List<Message> messages = Lists.newArrayList();
        String receiptHandle = "receiptHandler";
        var submissionId = UUID.randomUUID().toString();
        formFields.setSubmissionId(submissionId);

        Message message = Message.builder()
                .body(new ObjectMapper().writeValueAsString(formFields))
                .receiptHandle(receiptHandle).build();
        messages.add(message);
        var submission = Submission.builder().submissionId(submissionId).status(SubmissionState.DRAFT)
                .formType(FormType.N400).build();
        when(submissionService.retrieveSubmission(submissionId)).thenReturn(submission);
        when(mockResponse.messages()).thenReturn(messages);
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receivePersonValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(personResultQueue, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(personResultQueue, actualDeleteRequest.queueUrl());

        verify(personValidator, times(1)).validate(
                formFields.getAlienNumber(),
                formFields.getDateOfBirth(),
                formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

    }

    @Test
    void shouldThrowExceptionWhenSubmissionIsNotInDraftState() throws JsonProcessingException {
        String fieldValidationQueueURL = "validation queue url";

        ReflectionTestUtils.setField(receiver, "fieldQueueUrl", fieldValidationQueueURL);
        FormFields formFields = Instancio.create(FormFields.class);

        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        List<Message> messages = Lists.newArrayList();
        String receiptHandle = "receiptHandler";

        Message message = Message.builder()
                .body(new ObjectMapper().writeValueAsString(formFields))
                .receiptHandle(receiptHandle).build();
        messages.add(message);

        when(mockResponse.messages()).thenReturn(messages);
        var submissionId = UUID.randomUUID().toString();
        var submission = Submission.builder().submissionId(submissionId).status(SubmissionState.RECEIVED).build();
        when(submissionService.retrieveSubmission(formFields.submissionId())).thenReturn(submission);
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        when(submissionService.retrieveSubmission(formFields.submissionId())).thenReturn(submission);
        assertThrows(InvalidStateException.class,
                () -> receiver.receiveFormFieldsValidationResultMessage());
    }

    @Test
    void shouldPollAndProcessNameValidationResultMessage() throws JsonProcessingException {
        String nameResultQueue = "person queue url";

        ReflectionTestUtils.setField(receiver, "nameResultQueue", nameResultQueue);
        NameValidationResult result = Instancio.create(NameValidationResult.class);
        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        List<Message> messages = Lists.newArrayList();
        String receiptHandle = "receiptHandler";

        Message message = Message.builder()
                .body(new ObjectMapper().writeValueAsString(result))
                .receiptHandle(receiptHandle).build();
        messages.add(message);

        when(mockResponse.messages()).thenReturn(messages);
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receiveNameValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(nameResultQueue, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(nameResultQueue, actualDeleteRequest.queueUrl());

        verify(nameValidator, times(1)).validate(any());
    }

    @Test
    void shouldPollAndProcessAddressValidationResultMessage() throws JsonProcessingException {
        String addressResultQueue = "address queue url";

        AddressValidationResult result = Instancio.create(AddressValidationResult.class);
        ReflectionTestUtils.setField(receiver, "addressResultQueue", addressResultQueue);
        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        List<Message> messages = Lists.newArrayList();
        String receiptHandle = "receiptHandler";

        Message message = Message.builder()
                .body(new ObjectMapper().writeValueAsString(result))
                .receiptHandle(receiptHandle).build();
        messages.add(message);

        when(mockResponse.messages()).thenReturn(messages);
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receiveAddressValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(addressResultQueue, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(addressResultQueue, actualDeleteRequest.queueUrl());

        verify(addressValidator, times(1)).validate(any());

    }

    @Test
    void shouldPollAndProcessClientNameEmailValidationResultMessage() throws JsonProcessingException {
        String resultQueue = "client name queue url";

        ReflectionTestUtils.setField(receiver, "clientNameEmailQueueUrl", resultQueue);
        ClientNameEmailResponse result = Instancio.create(ClientNameEmailResponse.class);
        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        List<Message> messages = Lists.newArrayList();
        String receiptHandle = "receiptHandler";

        Message message = Message.builder()
                .body(new ObjectMapper().writeValueAsString(result))
                .receiptHandle(receiptHandle).build();
        messages.add(message);

        when(mockResponse.messages()).thenReturn(messages);
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receiveClientNameEmailValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(resultQueue, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(resultQueue, actualDeleteRequest.queueUrl());

        verify(clientNameEmailValidator, times(1)).validate(any());
    }

    @Test
    void shouldPollAndProcessAttorneyNameValidationResultMessage() throws JsonProcessingException {
        String resultQueue = "attorney name queue url";

        ReflectionTestUtils.setField(receiver, "attorneyNameQueueUrl", resultQueue);
        ClientNameEmailResponse result = Instancio.create(ClientNameEmailResponse.class);
        ReceiveMessageResponse mockResponse = mock(ReceiveMessageResponse.class);
        List<Message> messages = Lists.newArrayList();
        String receiptHandle = "receiptHandler";

        Message message = Message.builder()
                .body(new ObjectMapper().writeValueAsString(result))
                .receiptHandle(receiptHandle).build();
        messages.add(message);

        when(mockResponse.messages()).thenReturn(messages);
        when(sqsClient.receiveMessage(any(ReceiveMessageRequest.class))).thenReturn(mockResponse);

        receiver.receiveAttorneyNameValidationResultMessage();

        ArgumentCaptor<ReceiveMessageRequest> captor = ArgumentCaptor.forClass(ReceiveMessageRequest.class);
        ArgumentCaptor<DeleteMessageRequest> deleteCaptor = ArgumentCaptor.forClass(DeleteMessageRequest.class);

        verify(sqsClient, times(1)).receiveMessage(captor.capture());
        verify(sqsClient, times(1)).deleteMessage(deleteCaptor.capture());

        ReceiveMessageRequest actualRequest = captor.getValue();
        assertEquals(5, actualRequest.maxNumberOfMessages());
        assertEquals(resultQueue, actualRequest.queueUrl());

        DeleteMessageRequest actualDeleteRequest = deleteCaptor.getValue();
        assertEquals(receiptHandle, actualDeleteRequest.receiptHandle());
        assertEquals(resultQueue, actualDeleteRequest.queueUrl());

        verify(attorneyNameMatchesFormValidator, times(1)).validate(any());
    }
}
