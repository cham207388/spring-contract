package gov.dhs.uscis.submissionservice.controllers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.SubmissionFactory;
import gov.dhs.uscis.submissionservice.converters.SubmissionParameterConverter;
import gov.dhs.uscis.submissionservice.services.SubmissionService;

public class SubmissionManifestControllerTest {

    private static final String TEST_MANIFEST_ID = "testManifestId";
    private static final String SUBMISSION_ID = UUID.randomUUID().toString();
    private static final String MANIFEST_ID = UUID.randomUUID().toString();
    private static final String ELIS_OVERRIDE_URL = "http://elis-replacedurl.uscis.dhs.gov";
    private ObjectMapper mapper = new ObjectMapper();
    private MockMvc mockMvc;
    private SubmissionService submissionService;
    @MockitoBean
    private SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;

    @BeforeEach
    public void setup(){
        submissionService = mock(SubmissionService.class);
        ElisDataEnrichmentPipeline dataEncrichmentPipeline = new ElisDataEnrichmentPipeline(ELIS_OVERRIDE_URL, false);
        mockMvc = MockMvcBuilders.standaloneSetup(new SubmissionManifestController(submissionService, dataEncrichmentPipeline)).build();
    }

    @Test
    void shouldReturnSubmissionByManifest() throws Exception {
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);

        when(submissionService.retrieveSubmissionByManifestId(MANIFEST_ID)).thenReturn(Optional.ofNullable(submission));

        this.mockMvc.perform(get("/api/v1/submissions/manifest/{id}", MANIFEST_ID)
            .with(jwt()) )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.manifestId").value(MANIFEST_ID))
            .andExpect(jsonPath("$.forms[0].url").value("http://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov/62ab1987-6718-3943-933f-25ddd29d7e34/d02e82b4-8ffa-4917-a263-313ec645d38b/I765.pdf"))
            .andExpect(jsonPath("$.evidences[0].url").value("http://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov/72ab1987-6718-3943-933f-25ddd29d7e34/d02e82b4-8ffa-4917-a263-313ec645d38c/2x2Photo.png"))
            .andExpect(jsonPath("$.feeWaiver.url").value("http://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov/92ab1987-6718-3943-933f-25ddd29d7e34/d02e82b4-8ffa-4917-a263-313ec645d38f/I-912.pdf"));
    }

    @Test
    void shouldReturnUUIDMapByManifestId() throws Exception {
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        Map<String, String> uuidsMap = Map.of(submission.getFormType().getType(), "test-client-id");

        when(submissionService.retrieveSubmissionByManifestId(MANIFEST_ID)).thenReturn(Optional.ofNullable(submission));
        when(submissionService.getSubmissionICAMUUIDs(submission)).thenReturn(uuidsMap);

        ResultActions result = this.mockMvc.perform(get("/api/v1/submissions/manifest/{id}/icamuuids", MANIFEST_ID)
            .with(jwt()));

        result.andExpect(status().isOk())
            .andExpect(content().string(mapper.writeValueAsString(uuidsMap)));
    }

    @Test
    void shouldReturnSubmissionByManifestWhenElisOverrideIsToggledOn() throws Exception {
        ElisDataEnrichmentPipeline dataEncrichmentPipeline = new ElisDataEnrichmentPipeline(ELIS_OVERRIDE_URL, true);
        mockMvc = MockMvcBuilders.standaloneSetup(new SubmissionManifestController(submissionService, dataEncrichmentPipeline)).build();

        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);

        when(submissionService.retrieveSubmissionByManifestId(MANIFEST_ID)).thenReturn(Optional.ofNullable(submission));

        this.mockMvc.perform(get("/api/v1/submissions/manifest/{id}", MANIFEST_ID)
            .with(jwt()) )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.manifestId").value(MANIFEST_ID))
            .andExpect(jsonPath("$.forms[0].url").value(ELIS_OVERRIDE_URL + "/62ab1987-6718-3943-933f-25ddd29d7e34/d02e82b4-8ffa-4917-a263-313ec645d38b/I765.pdf"))
            .andExpect(jsonPath("$.evidences[0].url").value(ELIS_OVERRIDE_URL + "/72ab1987-6718-3943-933f-25ddd29d7e34/d02e82b4-8ffa-4917-a263-313ec645d38c/2x2Photo.png"))
            .andExpect(jsonPath("$.feeWaiver.url").value(ELIS_OVERRIDE_URL + "/92ab1987-6718-3943-933f-25ddd29d7e34/d02e82b4-8ffa-4917-a263-313ec645d38f/I-912.pdf"));
    }

    @Test
    void shouldRetrieveSubmissionByManifestIdAndMapEvidenceIdsFor797And797cToOther() throws Exception {
        Submission submission = Instancio.create(Submission.class);
        submission.setEvidences(new ArrayList<SubmissionEvidence>());
        submission.getEvidences()
                .add(SubmissionEvidence.builder().id(UUID.randomUUID().toString()).type("Form-797").build());
        submission.getEvidences()
                .add(SubmissionEvidence.builder().id(UUID.randomUUID().toString()).type("Form-797c").build());

        when(submissionService.retrieveSubmissionByManifestId(MANIFEST_ID)).thenReturn(Optional.of(submission));
        this.mockMvc.perform(get("/api/v1/submissions/manifest/{id}", MANIFEST_ID)
        .with(jwt()) )
        .andExpect(jsonPath("$.evidences[0].type").value("Other"))
        .andExpect(jsonPath("$.evidences[1].type").value("Other"))
        .andExpect(status().isOk());
        
    }
    
    @Test
    void shouldReturnSubmissionNotFoundWithIncorrectId() throws Exception {
        when(submissionService.retrieveSubmissionByManifestId(MANIFEST_ID)).thenReturn(Optional.ofNullable(null));

        this.mockMvc.perform(get("/api/v1/submissions/manifest/{id}", MANIFEST_ID)
            .with(jwt()) )
            .andExpect(status().isNotFound());
    }

    @Test
    public void shouldMapSubmissionIdToManifestId() throws Exception{
        Submission submission = mock(Submission.class);
        when(submission.getManifestId()).thenReturn(TEST_MANIFEST_ID);

        when(submissionService.retrieveSubmission(SUBMISSION_ID)).thenReturn(submission);


        this.mockMvc.perform(get("/api/v1/submissions/{id}/manifest/id", SUBMISSION_ID)
            .with(jwt()) )
            .andExpect(status().isOk())
            .andExpect(MockMvcResultMatchers.jsonPath("$.manifestId").value(TEST_MANIFEST_ID));
    }

    @Test
    void shouldReturnA404IfSubmissionNotFound() throws Exception {
        when(submissionService.retrieveSubmission(any())).thenReturn(null);

        this.mockMvc.perform(get("/api/v1/submissions/{id}/manifest/id", SUBMISSION_ID)
            .with(jwt()) )
            .andExpect(status().isNotFound());
    }

    @Test 
    void shouldReturnNotFoundIfSubmissionDoesNotHaveAManifestIdYet() throws Exception{
        Submission submission = mock(Submission.class);
        when(submissionService.retrieveSubmission(SUBMISSION_ID)).thenReturn(submission);

        this.mockMvc.perform(get("/api/v1/submissions/{id}/manifest/id", SUBMISSION_ID)
            .with(jwt()) )
            .andExpect(status().isNotFound());
    }

    @Test
    void shouldGetFormIngestionDTOAndReturn200() throws Exception {
        final String formType = "I-131";
        final String s3Key = "abc123.pdf";
        final String manifestId = "maniId";
        final String submissionId = "subId";
        final String myUSCISID = "someuser";
        final String userGroupId = "orgUUID";

        UserInformation userInfo = UserInformation.builder()
            .userGroupId(userGroupId)
            .build();

        Submission submission = Submission.builder().forms(List.of(
            SubmissionForm.builder()
                .type(formType)
                .s3Key(s3Key)
                .build()))
        	.submissionId(submissionId)
        	.manifestId(manifestId)
        	.myUscisId(myUSCISID)
            .applicant(userInfo)
            .build();

            
        when(submissionService.retrieveSubmission(submissionId)).thenReturn(submission);

        this.mockMvc.perform(get("/api/v1/submissions/{submissionId}/ingestion",
        		submissionId)
                .with(jwt()) )
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.manifestId").value(manifestId));
    }
    
    @Test
    void shouldGetFormIngestionDTOForRepFiledAndReturn200() throws Exception {
        final String formType = "I-131";
        final String s3Key = "abc123.pdf";
        final String manifestId = "maniId";
        final String submissionId = "subId";
        final String myUSCISID = "someuser";
        final String userGroupId = "orgUUID";

        UserInformation userInfo = UserInformation.builder()
            .myUscisId(myUSCISID)
            .build();
        
        ClientInformation clientInfo = ClientInformation.builder()
                .clientId(userGroupId)
                .build();

        Submission submission = Submission.builder().forms(List.of(
            SubmissionForm.builder()
                .type(formType)
                .s3Key(s3Key)
                .build(),
        	SubmissionForm.builder()
                .type(FormType.G28.getType())
                .s3Key(s3Key+"g28.pdf")
                .build()))
        	.submissionId(submissionId)
        	.manifestId(manifestId)
        	.myUscisId(myUSCISID)
            .applicant(userInfo)
            .clientInformation(clientInfo)
            .build();

            
        when(submissionService.retrieveSubmission(submissionId)).thenReturn(submission);

        this.mockMvc.perform(get("/api/v1/submissions/{submissionId}/ingestion",
        		submissionId)
                .with(jwt()) )
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.userGroupId").value(userGroupId));
    }
    
    @Test
    void shouldGetFormIngestionDTOAndReturn400() throws Exception {
    	final String submissionId = "subId";
    	
    	when(submissionService.retrieveSubmission(submissionId)).thenReturn(null);

        this.mockMvc.perform(get("/api/v1/submissions/{submissionId}/ingestion",
        		submissionId)
                .with(jwt()) )
        		.andExpect(status().isNotFound());;
    }
}
