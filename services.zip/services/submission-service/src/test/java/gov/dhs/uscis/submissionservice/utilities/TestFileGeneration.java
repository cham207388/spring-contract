package gov.dhs.uscis.submissionservice.utilities;

import gov.dhs.uscis.intake.services.formats.MagicBytes;

public class TestFileGeneration {

    public static byte[] randomPdf() {
        return MagicBytes.PDF.getMagicBytes();
    }

    public static byte[] randomJpg() {
        return MagicBytes.JPG.getMagicBytes();
    }

    public static byte[] randomUnsupportedFile() {
        return MagicBytes.UNSUPPORTED.getMagicBytes();
    }

    public static byte[] protectedPdf() {
        return "<<\n1 0 obj\n<<\n/O <1234567890ABCDEFG> /U <ABCDEFG1234567890> ".getBytes();
    }

}
