package gov.dhs.uscis.submissionservice.utils;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.models.validation.ValidationStatusEnum;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;

public class FormValidationStatusUtilTest {

    private FormMetaData I765_FormMetaData = FormMetaData.builder()
            .validations(
                    List.of(
                            MetadataValidationEnum.CORE,
                            MetadataValidationEnum.SIGNATURE,
                            MetadataValidationEnum.FORM_FIELDS))
            .build();

    private FormMetaData I765_FormMetaDataForRepresentative = FormMetaData.builder()
            .validations(
                    List.of(
                            MetadataValidationEnum.CORE,
                            MetadataValidationEnum.SIGNATURE,
                            MetadataValidationEnum.FORM_FIELDS,
                            MetadataValidationEnum.FORM_FIELDS,
                            MetadataValidationEnum.G28_COMP,
                            MetadataValidationEnum.G28_COMP_NAME))
            .build();

    private FormMetaData G28_FormMetaData = FormMetaData.builder()
            .validations(
                    List.of(
                            MetadataValidationEnum.CORE,
                            MetadataValidationEnum.SIGNATURE))
            .build();

    private FormMetaData FormFields_Validations_MetaData = FormMetaData.builder()
            .validations(
                    List.of(
                            MetadataValidationEnum.FORM_FIELDS))
            .build();

    private FormMetaData NO_Validations_MetaData = FormMetaData.builder()
            .validations(
                    List.of(

                    )).build();

    private boolean validationForApplicant = false;
    private boolean validationForRepresentative = true;

    @Test
    void shouldReturnValidationStatusCompleteWhenFormMetaDataHasNoValidations() {
        List<ValidationStatus> Form_ValidationStatuses_NONE = List.of();

        ValidationStatusEnum statusResult = FormValidationStatusUtil.determineFormStatus(Form_ValidationStatuses_NONE,
                NO_Validations_MetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.COMPLETE, statusResult);
    }

    @Test
    void shouldReturnValidationStatusInProgressWhenNoValidationsFoundI765() {
        List<ValidationStatus> I765_ValidationStatuses_Complete = List.of(

        );
        ValidationStatusEnum statusResult = FormValidationStatusUtil
                .determineFormStatus(I765_ValidationStatuses_Complete, I765_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.IN_PROGRESS, statusResult);
    }

    @Test
    void shouldReturnValidationStatusInProgressWhenNotAllValidationsExist() {

        List<ValidationStatus> I765_ValidationStatuses_InProgress = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.PERSON)
                        .status(ValidationResultEnum.PASS)
                        .build());

        ValidationStatusEnum statusResult = FormValidationStatusUtil
                .determineFormStatus(I765_ValidationStatuses_InProgress, I765_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.IN_PROGRESS, statusResult);
    }

    @Test
    void shouldReturnValidationStatusInProgressWhenNotAllFormFieldsValidationsExist() {

        List<ValidationStatus> I765_ValidationStatuses_MissingEligibilityCategory_InProgress = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.SIGNATURE)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.PERSON)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.CORE)
                        .status(ValidationResultEnum.PASS)
                        .build());
        ValidationStatusEnum missingEligibilityCategoryStatusResult = FormValidationStatusUtil.determineFormStatus(
                I765_ValidationStatuses_MissingEligibilityCategory_InProgress, I765_FormMetaData,
                validationForApplicant);
        assertEquals(ValidationStatusEnum.IN_PROGRESS, missingEligibilityCategoryStatusResult);

        List<ValidationStatus> I765_ValidationStatuses_MissingPerson_InProgress = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.SIGNATURE)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.CORE)
                        .status(ValidationResultEnum.PASS)
                        .build());
        ValidationStatusEnum missingPersonStatusResult = FormValidationStatusUtil.determineFormStatus(
                I765_ValidationStatuses_MissingPerson_InProgress, I765_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.IN_PROGRESS, missingPersonStatusResult);
    }

    @Test
    void shouldReturnValidationStatusCompleteWhenAllValidationsExistI765() {

        List<ValidationStatus> I765_ValidationStatuses_Complete = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.CORE)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.SIGNATURE)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.PERSON)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                        .status(ValidationResultEnum.PASS)
                        .build());

        ValidationStatusEnum statusResult = FormValidationStatusUtil
                .determineFormStatus(I765_ValidationStatuses_Complete, I765_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.COMPLETE, statusResult);
    }

    @Test
    void shouldReturnValidationStatusCompleteWhenAllValidationsExistG28() {

        List<ValidationStatus> G28_ValidationStatuses_Complete = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.CORE)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.SIGNATURE)
                        .status(ValidationResultEnum.PASS)
                        .build());

        ValidationStatusEnum statusResult = FormValidationStatusUtil
                .determineFormStatus(G28_ValidationStatuses_Complete, G28_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.COMPLETE, statusResult);
    }

    @Test
    void shouldMatchFormFieldsToEligibilityCategoryAndPerson() {
        List<ValidationStatus> FormFields_ValidationStatuses_Complete = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                        .status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder()
                        .validator(ValidatorEnum.PERSON)
                        .status(ValidationResultEnum.PASS)
                        .build());

        ValidationStatusEnum statusResult = FormValidationStatusUtil.determineFormStatus(
                FormFields_ValidationStatuses_Complete, FormFields_Validations_MetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.COMPLETE, statusResult);
    }

    @Test
    void shouldReturnValidationStatusCompleteWhenCoreValidationFailsI765() {
        List<ValidationStatus> I765_ValidationStatuses_Complete = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.CORE)
                        .status(ValidationResultEnum.FAIL)
                        .build());
        ValidationStatusEnum statusResult = FormValidationStatusUtil
                .determineFormStatus(I765_ValidationStatuses_Complete, I765_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.COMPLETE, statusResult);
    }

    @Test
    void shouldReturnValidationStatusInProgressWhenPersonValidationFailsI765() {
        List<ValidationStatus> I765_ValidationStatusesPerson_InProgress = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.PERSON)
                        .status(ValidationResultEnum.FAIL)
                        .build());
        ValidationStatusEnum statusResult = FormValidationStatusUtil.determineFormStatus(
                I765_ValidationStatusesPerson_InProgress, I765_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.IN_PROGRESS, statusResult);
    }

    @Test
    void shouldReturnValidationStatusInProgressWhenSignatureFailsForRepresentativeI765() {
        List<ValidationStatus> I765_ValidationStatusesSignature_InProgress = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.SIGNATURE)
                        .status(ValidationResultEnum.FAIL)
                        .build());
        ValidationStatusEnum statusResult = FormValidationStatusUtil.determineFormStatus(
                I765_ValidationStatusesSignature_InProgress, I765_FormMetaData, validationForRepresentative);
        assertEquals(ValidationStatusEnum.IN_PROGRESS, statusResult);
    }

    @Test
    void shouldReturnValidationStatusInProgressWhenSignatureFailsForApplicantI765() {
        List<ValidationStatus> I765_ValidationStatuses_Complete = List.of(
                ValidationStatus.builder()
                        .validator(ValidatorEnum.SIGNATURE)
                        .status(ValidationResultEnum.FAIL)
                        .build());
        ValidationStatusEnum statusResult = FormValidationStatusUtil
                .determineFormStatus(I765_ValidationStatuses_Complete, I765_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.IN_PROGRESS, statusResult);
    }

    @Test
    void shouldReturnValidationStatusCompleteWhenAllValidationsFail() {
        List<ValidationStatus> I765_ValidationAllPassedStatuses_Complete = List.of(
                ValidationStatus.builder().validator(ValidatorEnum.CORE).status(ValidationResultEnum.PASS).build(),
                ValidationStatus.builder().validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                        .status(ValidationResultEnum.PASS).build(),
                ValidationStatus.builder().validator(ValidatorEnum.G28_COMP).status(ValidationResultEnum.PASS).build(),
                ValidationStatus.builder().validator(ValidatorEnum.G28_COMP_NAME).status(ValidationResultEnum.PASS)
                        .build(),
                ValidationStatus.builder().validator(ValidatorEnum.PERSON).status(ValidationResultEnum.PASS).build(),
                ValidationStatus.builder().validator(ValidatorEnum.SIGNATURE).status(ValidationResultEnum.PASS)
                        .build());
        ValidationStatusEnum statusResult = FormValidationStatusUtil.determineFormStatus(
                I765_ValidationAllPassedStatuses_Complete, I765_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.COMPLETE, statusResult);
    }

    @Test
    void shouldReturnValidationStatusCompleteWhenAllValidationsPass() {
        List<ValidationStatus> I765_ValidationAllFailedStatuses_Complete = List.of(
                ValidationStatus.builder().validator(ValidatorEnum.CORE).status(ValidationResultEnum.PASS).build(),
                ValidationStatus.builder().validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                        .status(ValidationResultEnum.FAIL).build(),
                ValidationStatus.builder().validator(ValidatorEnum.G28_COMP).status(ValidationResultEnum.FAIL).build(),
                ValidationStatus.builder().validator(ValidatorEnum.G28_COMP_NAME).status(ValidationResultEnum.FAIL)
                        .build(),
                ValidationStatus.builder().validator(ValidatorEnum.PERSON).status(ValidationResultEnum.FAIL).build(),
                ValidationStatus.builder().validator(ValidatorEnum.SIGNATURE).status(ValidationResultEnum.FAIL)
                        .build());
        ValidationStatusEnum statusResult = FormValidationStatusUtil.determineFormStatus(
                I765_ValidationAllFailedStatuses_Complete, I765_FormMetaData, validationForApplicant);
        assertEquals(ValidationStatusEnum.COMPLETE, statusResult);
    }

    @Test
    void shouldIncludeAttorneySpecificValidationsWhenFilerIsAttorney() {
        FormMetaData I765_FormMetaData = FormMetaData.builder()
                .validations(
                        List.of(
                                MetadataValidationEnum.CORE,
                                MetadataValidationEnum.SIGNATURE,
                                MetadataValidationEnum.FORM_FIELDS,
                                MetadataValidationEnum.G28_COMP,
                                MetadataValidationEnum.G28_COMP_NAME))
                .build();

        List<String> statusResult = FormValidationStatusUtil.getValidationStatusLookupKeys(I765_FormMetaData,
                validationForRepresentative);
        assertTrue(statusResult.contains(MetadataValidationEnum.G28_COMP.toString()));
    }

    @Test
    void shouldNotIncludeAttorneySpecificValidationsWhenFilerIsNotAttorney() {
        FormMetaData I765_FormMetaData = FormMetaData.builder()
                .validations(
                        List.of(
                                MetadataValidationEnum.CORE,
                                MetadataValidationEnum.SIGNATURE,
                                MetadataValidationEnum.FORM_FIELDS,
                                MetadataValidationEnum.G28_COMP))
                .build();

        List<String> statusResult = FormValidationStatusUtil.getValidationStatusLookupKeys(I765_FormMetaData,
                validationForApplicant);
        assertFalse(statusResult.contains(MetadataValidationEnum.G28_COMP.toString()));
    }

    @Test
    void shouldReturnValidationStatusCompleteWhenRepresentative() {
        List<ValidationStatus> statuses = List.of(
                ValidationStatus.builder().validator(ValidatorEnum.CORE).status(ValidationResultEnum.PASS).build(),
                ValidationStatus.builder().validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                        .status(ValidationResultEnum.FAIL).build(),
                ValidationStatus.builder().validator(ValidatorEnum.G28_COMP).status(ValidationResultEnum.FAIL)
                        .build(),
                ValidationStatus.builder().validator(ValidatorEnum.G28_COMP_NAME).status(ValidationResultEnum.FAIL)
                        .build(),
                ValidationStatus.builder().validator(ValidatorEnum.PERSON).status(ValidationResultEnum.FAIL).build(),
                ValidationStatus.builder().validator(ValidatorEnum.SIGNATURE).status(ValidationResultEnum.FAIL)
                        .build());
        ValidationStatusEnum statusResult = FormValidationStatusUtil.determineFormStatus(statuses, I765_FormMetaDataForRepresentative,
                validationForRepresentative);
        assertEquals(ValidationStatusEnum.COMPLETE, statusResult);
    }

    @Test
    void shouldReturnValidationStatusAwaitingWhenAtleastOneValidationIsPending() {
        List<ValidationStatus> statuses = List.of(
                ValidationStatus.builder().validator(ValidatorEnum.CORE).status(ValidationResultEnum.PASS).build(),
                ValidationStatus.builder().validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                        .status(ValidationResultEnum.FAIL).build(),
                ValidationStatus.builder().validator(ValidatorEnum.G28_COMP).status(ValidationResultEnum.PENDING)
                        .build(),
                ValidationStatus.builder().validator(ValidatorEnum.G28_COMP_NAME).status(ValidationResultEnum.FAIL)
                        .build(),
                ValidationStatus.builder().validator(ValidatorEnum.PERSON).status(ValidationResultEnum.FAIL).build(),
                ValidationStatus.builder().validator(ValidatorEnum.SIGNATURE).status(ValidationResultEnum.FAIL)
                        .build());
        ValidationStatusEnum statusResult = FormValidationStatusUtil.determineFormStatus(statuses, I765_FormMetaDataForRepresentative,
                validationForRepresentative);
        assertEquals(ValidationStatusEnum.AWAITING, statusResult);
    }
}
