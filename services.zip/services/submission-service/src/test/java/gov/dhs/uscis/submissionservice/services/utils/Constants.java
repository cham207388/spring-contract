package gov.dhs.uscis.submissionservice.services.utils;
import java.util.UUID;

public final class Constants {
    public static final String MD5HASH = UUID.randomUUID().toString();
}
