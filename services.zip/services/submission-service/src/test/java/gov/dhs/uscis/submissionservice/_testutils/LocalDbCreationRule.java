package gov.dhs.uscis.submissionservice._testutils;

import org.junit.jupiter.api.extension.AfterAllCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.utility.DockerImageName;

public class LocalDbCreationRule implements AfterAllCallback, BeforeAllCallback {
    
    private static GenericContainer<?> dynamoContainer;

    private String port;

    public String getPort() {
        return this.port;
    }

    public LocalDbCreationRule() {
        System.setProperty("aws.region", "us-east-1");
        System.setProperty("aws.accessKeyId", "test");
        System.setProperty("aws.secretAccessKey", "test");
    }

    @Override
    @SuppressWarnings("resource") // Container is managed by Testcontainer's Ryuk sidecar 
    public void beforeAll(ExtensionContext context) {
        if (dynamoContainer == null) {
             dynamoContainer =  new GenericContainer<>(DockerImageName.parse("amazon/dynamodb-local:latest"))
             .withExposedPorts(8000);
             dynamoContainer.start();
        }
        
        this.port = String.valueOf(dynamoContainer.getMappedPort(8000));
        
        System.setProperty("amazon.dynamodb.endpoint", "http://localhost:" + port);
    }

    @Override
    public void afterAll(ExtensionContext context) {
        // Not stopping the container here so that it can be reused across
        // all test classes, hopefully speeding up the build
    }
}