package gov.dhs.uscis.submissionservice.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.models.EvidenceMetaData;
import gov.dhs.uscis.intake.models.core.metadata.EvidencePages;
import gov.dhs.uscis.intake.models.dto.EvidenceData;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;

@SuppressWarnings("unchecked")
public class EvidenceMetaDataServiceTest {

    private static final String TEST_EVIDENCE_ID = "TEST_EVIDENCE_ID";

    DynamoDbTable<EvidenceMetaData> mockDynamoDbTable = mock(DynamoDbTable.class);
    private EvidenceMetaDataService service = new EvidenceMetaDataService(mockDynamoDbTable);
    private GetItemEnhancedRequest request;

    @BeforeEach
    void setUp() {
        request = GetItemEnhancedRequest.builder()
                .key(Key.builder()
                        .partitionValue(TEST_EVIDENCE_ID)
                        .build())
                .build();
    }

    @Test
    void shouldRetrieveEvidencePages() {
        EvidenceMetaData evidenceMetaData = Instancio.create(EvidenceMetaData.class);
        EvidencePages pages = Instancio.create(EvidencePages.class);
        Map<String, EvidencePages> pageMap = new HashMap<>() {
            {
                put("id", pages);
            }
        };
        evidenceMetaData.setEvidencePages(pageMap);

        when(mockDynamoDbTable.getItem(request)).thenReturn(evidenceMetaData);

        EvidenceData response = service.getEvidenceMetaData(TEST_EVIDENCE_ID);

        assertThat(response.evidencePages()).isEqualTo(pageMap);
    }
}
