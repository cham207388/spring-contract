package gov.dhs.uscis.submissionservice;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Groups together tests that require OAuth to be disabled when the application
 * context loads.
 */
@SpringBootTest(webEnvironment = RANDOM_PORT, properties = {
    "application.security.enforce.oauth=false",
    "application.security.enforce.csrf=false",
})
@AutoConfigureWebTestClient
public class OAuthDisabledTest extends BaseJourneyTest {
    
    @Test
    public void contextLoads () {}
}
