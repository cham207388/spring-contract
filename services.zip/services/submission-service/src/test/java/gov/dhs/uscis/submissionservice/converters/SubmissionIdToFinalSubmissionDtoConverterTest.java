package gov.dhs.uscis.submissionservice.converters;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResponse;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ValidationService;

@ExtendWith(MockitoExtension.class)
public class SubmissionIdToFinalSubmissionDtoConverterTest {

    @Mock
    ValidationService validationService;

    @Mock
    SubmissionService submissionService;

    @InjectMocks
    SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;

    private final String MYUSCIS_ID = UUID.randomUUID().toString();

    @Test
    void shouldConvertSubmissionIdToFinalSubmissionDto() {
        Submission submission = Instancio.create(Submission.class);
        String submissionId = submission.getSubmissionId();
        ValidationStatusResponse validationStatusResponse = Instancio.create(ValidationStatusResponse.class);

        when(submissionService.retrieveSubmission(submissionId)).thenReturn(submission);
        when(validationService.retrieveValidationStatus(submission)).thenReturn(validationStatusResponse);
      
        FinalSubmissionDto finalSubmissionDto = submissionIdToFinalSubmissionDtoConverter.convert(submissionId);

        assertEquals(submissionId, finalSubmissionDto.getSubmissionId());
        assertEquals(submission.getAttested(), finalSubmissionDto.getAttested());
        assertEquals(submission.getAttestationSignature(), finalSubmissionDto.getSignature());
        assertEquals(submission.getUserRequestedFeeWaiver(), finalSubmissionDto.getUserRequestedFeeWaiver());
        assertEquals(submission.getFeeWaiver(), finalSubmissionDto.getFeeWaiver());
        assertEquals(submission.getStatus(), finalSubmissionDto.getStatus());
        assertEquals(submission.getEvidences(), finalSubmissionDto.getEvidences());
        assertEquals(submission.getFormType(), finalSubmissionDto.getType());
        assertEquals(submission.getForms(), finalSubmissionDto.getForms());
        assertEquals(submission.getHasReviewedSignature(), finalSubmissionDto.getHasReviewedSignature());
    }

    @Test
    void shouldConvertSubmissionIdToFinalSubmissionDtoWhenPartialFeeWaiverIsNull() {
        Submission submission = Instancio.create(Submission.class);
        submission.setUserRequestedPartialFeeWaiver(null);
        String submissionId = submission.getSubmissionId();
        ValidationStatusResponse validationStatusResponse = Instancio.create(ValidationStatusResponse.class);

        when(submissionService.retrieveSubmission(submissionId)).thenReturn(submission);
        when(validationService.retrieveValidationStatus(submission)).thenReturn(validationStatusResponse);
      
        FinalSubmissionDto finalSubmissionDto = submissionIdToFinalSubmissionDtoConverter.convert(submissionId);

        assertEquals(submissionId, finalSubmissionDto.getSubmissionId());
        assertEquals(submission.getAttested(), finalSubmissionDto.getAttested());
        assertEquals(submission.getAttestationSignature(), finalSubmissionDto.getSignature());
        assertEquals(submission.getUserRequestedFeeWaiver(), finalSubmissionDto.getUserRequestedFeeWaiver());
        assertThat(finalSubmissionDto.getUserRequestedPartialFeeWaiver()).isFalse();
        assertEquals(submission.getFeeWaiver(), finalSubmissionDto.getFeeWaiver());
        assertEquals(submission.getStatus(), finalSubmissionDto.getStatus());
        assertEquals(submission.getEvidences(), finalSubmissionDto.getEvidences());
        assertEquals(submission.getFormType(), finalSubmissionDto.getType());
        assertEquals(submission.getForms(), finalSubmissionDto.getForms());
        assertEquals(submission.getHasReviewedSignature(), finalSubmissionDto.getHasReviewedSignature());
    }
}
