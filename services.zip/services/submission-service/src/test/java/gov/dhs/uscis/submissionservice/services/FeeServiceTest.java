package gov.dhs.uscis.submissionservice.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I130EligibilityCategory;
import gov.dhs.uscis.intake.enums.I131EligibilityCategory;
import gov.dhs.uscis.intake.enums.I485EligibilityCategory;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.N400EligibilityCategory;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I130ChildEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I485EligibilitySubcategories;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I907FormSpecificInfo;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.submissionservice.controllers.SubmissionDetailsController.FeeDetails;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i130.I130FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i130.I130Fees;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i131.I131FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i131.I131Fees;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765Fees;
import gov.dhs.uscis.submissionservice.services.fees.strategies.n400.N400Fees;
import lombok.Getter;

class FeeServiceTest {
	enum NullSubCategoryEnum implements EligibilitySubcategoryEnum {
		NULL_CATEGORY(""),
		LONG_CATEGORY("SIBLING_NOT_ADOPTED_SIBLING_NOT_ADOPTED_SIBLING_NOT_ADOPTED_SIBLING_NOT_ADOPTED_SIBLING_NOT_ADOPTED_SIBLING_NOT_ADOPTED");
		private @Getter String category;
		NullSubCategoryEnum(String category) {
			this.category = category;
		}

        @Override
        public String getCategory() {
            return this.category;
        }

	}

    private FeeService service;
    private FormMetaDataRepository formMetaDataRepository;
    private SubmissionRepository submissionRepository;

    @BeforeEach
    public void setup() {
        submissionRepository = mock(SubmissionRepository.class);
        formMetaDataRepository = mock(FormMetaDataRepository.class);

        Map<String, Integer> feesInt = new HashMap<>();
        feesInt.put("C8ABCINITIALFEE", 1030);
        feesInt.put("C8INITIALFEE", 560);
        feesInt.put("C8INITIALFEEWAIVER", 0);
        feesInt.put("C8ABCINITIALFEEWAIVER", 470);
        feesInt.put("C8REPLACEMENTFEE", 470);
        feesInt.put("C8REPLACEMENTFEEWAIVER", 0);
        feesInt.put("C8RENEWALFEE", 745);
        feesInt.put("C8RENEWALFEEWAIVER", 470);
        feesInt.put("A19C19INITALFEE", 1030);
        feesInt.put("A19C19INITALFEEWAIVER", 470);
        feesInt.put("A19C19RENEWALFEEWAIVER", 470);
        feesInt.put("A19C19RENEWALFEE", 745);
        feesInt.put("C11INITIALUKRAINEFEE", 560);
        feesInt.put("C11INITIALUKRAINEFEEWAIVER", 470);
        feesInt.put("C11INITIALFAGHANFEE", 1030);
        feesInt.put("C11INITIALFAGHANFEEWAIVER", 470);
        feesInt.put("C11INITIALIMVIFEEWAIVER", 0);
        feesInt.put("C11IMMVIINITIALFEE", 280);
        feesInt.put("C11INITIALFEE", 1030);
        feesInt.put("C11INITIALFEEWAIVER", 470);
        feesInt.put("C11REPLACEMENTFAGHANFEE", 470);
        feesInt.put("C11REPLACEMENTFAGHANFEEWAIVER", 470);
        feesInt.put("C11IMMVIRENEWALFEE", 280);
        feesInt.put("C11IMMVIRENEWALFEEWAIVER", 0);
        feesInt.put("C11RENEWALFEE", 745);
        feesInt.put("C11RENEWALFEEWAIVER", 470);
        FormMetaData formMetaData = FormMetaData.builder().fees(feesInt).build();

        when(formMetaDataRepository.retrieveFormMataData(anyString())).thenReturn(formMetaData);
        service = new FeeService(formMetaDataRepository, submissionRepository);

    }

       @Test
    void shouldCalculateI765C8Fee() {
        String reasonForFiling = ReasonForFiling.INITIAL.toString();
        assertEquals(I765Fees.FEE_1030, service.calculateFeeFor(FormType.I765, I765EligibilityCategory.C8,
                new I765FeeStrategyOptions(true, false, false, reasonForFiling, false)));
        assertEquals(I765Fees.FEE_560, service.calculateFeeFor(FormType.I765, I765EligibilityCategory.C8,
                new I765FeeStrategyOptions(false, false, false, reasonForFiling, false)));
    }

    @Test
    void shouldCalculateI765C9Fee() {
        BigDecimal fee = service.calculateI765FeeFor(FormType.I765, I765EligibilityCategory.C9);
        assertEquals(I765Fees.FEE_260, fee);
    }

    @Test
    void shouldReturnExemptFeeForI765NonImplementedCategory() {
        BigDecimal fee = service.calculateI765FeeFor(FormType.I765, I765EligibilityCategory.C9);
        assertEquals(I765Fees.FEE_260, fee);
    }

    @Test
    void shouldReturnExemptFeeForNullCategory_I765() {
        BigDecimal fee = service.calculateI765FeeFor(FormType.I765, null);
        assertEquals(I765Fees.FEE_EXEMPT, fee);
    }

    @Test
    void shouldReturnFeeForN400() {
        BigDecimal fee = service.calculateFeeFor(FormType.N400, N400EligibilityCategory.OTHER, null);
        assertEquals(N400Fees.FULL_FEE, fee);
    }

    @Test
    void shouldReturnExemptFeeForNullCategory_N400() {
        BigDecimal fee = service.calculateN400FeeFor(FormType.N400, null);
        assertEquals(N400Fees.FEE_EXEMPT, fee);
    }

    @Test
    void shouldReturnFullFeeFeeForSpouseOfCitizenCategory() {
        BigDecimal fee = service.calculateN400FeeFor(FormType.N400,
                N400EligibilityCategory.SPOUSE_OF_ABROAD_US_CITIZEN);
        assertEquals(N400Fees.FULL_FEE, fee);
    }

    @Test
    void shouldReturnFullFeeFeeForVawaCategory() {
        BigDecimal fee = service.calculateN400FeeFor(FormType.N400, N400EligibilityCategory.VAWA);
        assertEquals(N400Fees.FULL_FEE, fee);
    }

    @Test
    void shouldReturnFullFeeSpouseOfAbroadCitizenCategory() {
        BigDecimal fee = service.calculateN400FeeFor(FormType.N400,
                N400EligibilityCategory.SPOUSE_OF_ABROAD_US_CITIZEN);
        assertEquals(N400Fees.FULL_FEE, fee);
    }

    @Test
    void shouldReturnExemptMilitaryDuringHostilitiesCategory() {
        BigDecimal fee = service.calculateN400FeeFor(FormType.N400,
                N400EligibilityCategory.MILITARY_DURING_HOSTILITIES);
        assertEquals(N400Fees.FEE_EXEMPT, fee);
    }

    @Test
    void shouldReturnExemptMilitaryOneYearHonorableCategory() {
        BigDecimal fee = service.calculateN400FeeFor(FormType.N400,
                N400EligibilityCategory.MILITARY_ONE_YEAR_HONORABLE);
        assertEquals(N400Fees.FEE_EXEMPT, fee);
    }

    @Test
    void shouldReturnFullFeeOtherCategory() {
        BigDecimal fee = service.calculateN400FeeFor(FormType.N400, N400EligibilityCategory.OTHER);
        assertEquals(N400Fees.FULL_FEE, fee);
    }

    @Test
    void shouldCalculateI131Fee() {
        assertEquals(I131Fees.FULL_FEE, service.calculateFeeFor(FormType.I131, I131EligibilityCategory.ADVANCE_PAROLE,
                new I131FeeStrategyOptions(true)));
    }

    @Test
    void shouldReturnFullFeeForI131Underlying485() {
        BigDecimal fee = service.calculateI131FeeFor(FormType.I131, I131EligibilityCategory.ADVANCE_PAROLE);
        assertEquals(I131Fees.FULL_FEE, fee);
    }

    @Test
    void shouldReturnFullFeeForNullCategory() {
        BigDecimal fee = service.calculateI131FeeFor(FormType.I131, null);
        assertEquals(I131Fees.FEE_EXEMPT, fee);
    }

    @Test
    void shouldCalculateI130Fee() {
        assertEquals(I130Fees.FULL_FEE,
                service.calculateFeeFor(FormType.I130, I130EligibilityCategory.PETITION_FOR_CHILD,
                        new I130FeeStrategyOptions()));
    }

    @Test
    void shouldReturnFullFeeForI130NullCategory() {
        BigDecimal fee = service.calculateI130FeeFor(FormType.I130, null);
        assertEquals(I130Fees.FEE_EXEMPT, fee);
    }

    @Test
    void shouldReturnFullFeeForI130NonNullCategory() {
        BigDecimal fee = service.calculateI130FeeFor(FormType.I130, I130EligibilityCategory.PETITION_FOR_CHILD);
        assertEquals(I130Fees.FULL_FEE, fee);
    }

    @Test
    public void shouldRetrieveFeeThatIsCalculatedOnTheSubmission() {
        var submission = Instancio.create(Submission.class);
                SubmissionForm mainForm = SubmissionForm.builder()
        .type(FormType.I765.getType())
        .id("form-123")
        .name("I-907 Request")
        .feeTotal(BigDecimal.TEN)
        .build();
        submission.setEligibilityCategory(I765EligibilityCategory.C8);
        submission.setFeeTotal(BigDecimal.TEN);
        submission.setForms(List.of(mainForm));
        submission.setFormType(FormType.I765);
        when(submissionRepository.getById("fakeSubmissionId")).thenReturn(Optional.of(submission));
        var result = service.retrieveCalculatedFeeFor("fakeSubmissionId");

        assertThat(result.amount()).isEqualTo(BigDecimal.TEN);
    }

    @Test
    public void shouldThrowAnExceptionIfSubmissionDoesNotExist() {
        assertThrows(NoSuchElementException.class,
                () -> service.retrieveCalculatedFeeFor("fakeSubmissionId"));
    }

    @Test
    public void shouldThrowAnExceptionIfAFeeHasNotBeenCalculated() {
        var submission = Instancio.create(Submission.class);
        submission.setEligibilityCategory(I765EligibilityCategory.C8);
        submission.setFeeTotal(null);
        when(submissionRepository.getById("fakeSubmissionId")).thenReturn(Optional.of(submission));
        assertThrows(NoSuchElementException.class,
                () -> service.retrieveCalculatedFeeFor("fakeSubmissionId"));
    }

    @Test
    public void shouldJoinCategoryAndSubCategory() {
    	var submission = Instancio.create(Submission.class);
                       SubmissionForm mainForm = SubmissionForm.builder()
        .type(FormType.I765.getType())
        .id("form-123")
        .name("I-907 Request")
        .feeTotal(BigDecimal.TEN)
        .build();
        submission.setEligibilityCategory(I130EligibilityCategory.PETITION_FOR_SPOUSE);
        submission.setEligibilitySubcategory(I130ChildEligibilitySubcategory.CHILD_ADOPTED);
        submission.setFeeTotal(BigDecimal.TEN);
        submission.setForms(List.of(mainForm));
        submission.setFormType(FormType.I765);
        when(submissionRepository.getById("fakeSubmissionId")).thenReturn(Optional.of(submission));
        var result = service.retrieveCalculatedFeeFor("fakeSubmissionId");
        assertThat(result.amount()).isEqualTo(BigDecimal.TEN);
    }

    @Test
    public void shouldFilterOutBlankSubCategory() {

    	var submission = Instancio.create(Submission.class);
                       SubmissionForm mainForm = SubmissionForm.builder()
        .type(FormType.I131.getType())
        .id("form-123")
        .name("I-907 Request")
        .feeTotal(BigDecimal.TEN)
        .build();
        submission.setEligibilityCategory(I130EligibilityCategory.PETITION_FOR_SPOUSE);
        submission.setEligibilitySubcategory(NullSubCategoryEnum.NULL_CATEGORY);
        submission.setFeeTotal(BigDecimal.TEN);
        submission.setFormType(FormType.I131);
        submission.setForms(List.of(mainForm));
        submission.setFormType(FormType.I131);
        when(submissionRepository.getById("fakeSubmissionId")).thenReturn(Optional.of(submission));
        var result = service.retrieveCalculatedFeeFor("fakeSubmissionId");
        assertThat(result.amount()).isEqualTo(BigDecimal.TEN);

    }

    @Test
    public void shouldSubStringCategoriesLongerThanEighty() {
    	var submission = Instancio.create(Submission.class);
                       SubmissionForm mainForm = SubmissionForm.builder()
        .type(FormType.I765.getType())
        .id("form-123")
        .name("I-907 Request")
        .feeTotal(BigDecimal.TEN)
        .build();
        submission.setEligibilityCategory(I130EligibilityCategory.PETITION_FOR_SPOUSE);
        submission.setEligibilitySubcategory(NullSubCategoryEnum.LONG_CATEGORY);
        submission.setFeeTotal(BigDecimal.TEN);
        submission.setForms(List.of(mainForm));
        submission.setFormType(FormType.I765);
        when(submissionRepository.getById("fakeSubmissionId")).thenReturn(Optional.of(submission));
        var result = service.retrieveCalculatedFeeFor("fakeSubmissionId");
        assertThat(result.amount()).isEqualTo(BigDecimal.TEN);

    }

    @Test
    public void shouldUseUnderlyingReceiptNumberAsEligibilityCategoryFor907() {
        String testUnderlyingReceiptNumber = "IOE1234567890";
        SubmissionForm mainForm = SubmissionForm.builder()
    .type(FormType.I907.getType())
    .id("form-123")
    .name("I-907 Request")
    .feeTotal(BigDecimal.TEN)
    .build();
        Submission submission = Submission.builder()
            .formType(FormType.I907)
            .formSpecificInfo(new I907FormSpecificInfo(testUnderlyingReceiptNumber))
                .forms(List.of(mainForm))
            .feeTotal(BigDecimal.TEN)
            .build();

        when(submissionRepository.getById("fakeSubmissionId")).thenReturn(Optional.of(submission));
        FeeDetails result = service.retrieveCalculatedFeeFor("fakeSubmissionId");
        assertEquals(testUnderlyingReceiptNumber, result.eligibilityCategory());
    }

    @Test
    public void shoulduseUnder14For485() {
        boolean isUnder14 = true;
        SubmissionForm mainForm = SubmissionForm.builder()
    .type(FormType.I485.getType())
    .id("form-123")
    .name("I-485 Request")
    .formSpecificInfo( new I485FormSpecificInfo(false, false, isUnder14))
    .eligibilitySubcategory(I485EligibilitySubcategories.ALIEN_INVESTOR_FORM_I526_OR_FORM_I526E)
    .eligibilityCategory(I485EligibilityCategory.PRINCIPAL_APPLICANT)
    .feeTotal(BigDecimal.TEN)
    .build();
            SubmissionForm G28form = SubmissionForm.builder()
    .type(FormType.G28.getType())
    .id("form-123")
    .name("I-485 Request")
    .feeTotal(BigDecimal.TEN)
    .build();
        Submission submission = Submission.builder()
            .formType(FormType.I485)
            .formSpecificInfo( new I485FormSpecificInfo(false, false, isUnder14))
                .forms(List.of(mainForm, G28form))
                    .eligibilitySubcategory(I485EligibilitySubcategories.ALIEN_INVESTOR_FORM_I526_OR_FORM_I526E)
    .eligibilityCategory(I485EligibilityCategory.PRINCIPAL_APPLICANT)
            .feeTotal(BigDecimal.TEN)
            .build();

        when(submissionRepository.getById("fakeSubmissionId")).thenReturn(Optional.of(submission));
        FeeDetails result = service.retrieveCalculatedFeeFor("fakeSubmissionId");
        assertEquals(isUnder14, result.isUnder14());
    }

        @Test
    public void shoulduseUnder14For485WhenFormSpecificNull() {
        SubmissionForm mainForm = SubmissionForm.builder()
    .type(FormType.I485.getType())
    .id("form-123")
    .name("I-485 Request")
    .formSpecificInfo(null)
    .eligibilitySubcategory(I485EligibilitySubcategories.ALIEN_INVESTOR_FORM_I526_OR_FORM_I526E)
    .eligibilityCategory(I485EligibilityCategory.PRINCIPAL_APPLICANT)
    .feeTotal(BigDecimal.TEN)
    .build();
            SubmissionForm G28form = SubmissionForm.builder()
    .type(FormType.G28.getType())
    .id("form-123")
    .name("I-485 Request")
    .feeTotal(BigDecimal.TEN)
    .build();
                SubmissionForm secondaryForm = SubmissionForm.builder()
    .type(FormType.I485A.getType())
    .id("form-123")
    .name("I-485A Request")
    .feeTotal(BigDecimal.TEN)
    .build();
        Submission submission = Submission.builder()
            .formType(FormType.I485)
            .formSpecificInfo(null)
                .forms(List.of(mainForm, G28form, secondaryForm))
                    .eligibilitySubcategory(I485EligibilitySubcategories.ALIEN_INVESTOR_FORM_I526_OR_FORM_I526E)
    .eligibilityCategory(I485EligibilityCategory.PRINCIPAL_APPLICANT)
            .feeTotal(BigDecimal.TEN)
            .build();

        when(submissionRepository.getById("fakeSubmissionId")).thenReturn(Optional.of(submission));
        FeeDetails result = service.retrieveCalculatedFeeFor("fakeSubmissionId");
        assertEquals(false, result.isUnder14());
    }
}
