package gov.dhs.uscis.submissionservice.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersUriSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.amazonaws.lambda.thirdparty.com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.submissionservice.exception.AddClientValidationException;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AccountTypeResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.ApplicantUuidResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.BulkInfo;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.BulkInfoResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.PeepsProfileResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.RepresentativeProfileResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.RepresentativeProfileResponseData;
import gov.dhs.uscis.submissionservice.validators.i765.receiptProfile.ReceiptProfile;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class PeepsServiceTest {
    
    private static final String DOB = "01/01/1990";
    private static final String ANUMBER = "123456789";
    private static final String FIRST_NAME = "John";
    private static final String LAST_NAME = "Doolittle";

    @Mock
    RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    RequestBodySpec requestBodySpec;

    @Mock
    ResponseSpec responseSpec;

    @Mock
    RequestHeadersSpec requestHeadersSpec;

    @Mock
    RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    Mono<BulkInfoResponse> bulkInfoResponseMono;

    @Mock
    Mono<RepresentativeProfileResponse> representativeProfileResponseMono;

    @Mock
    PeepsClient peepsClient;

    private WebClient webClient;
    private String myUscisId;
    private PeepsService service;

    @BeforeEach
    public void setup() {
        myUscisId = UUID.randomUUID().toString();
        webClient = Mockito.mock(WebClient.class);
        service = new PeepsService(webClient, peepsClient);
    }

    @Test
    void shouldThrowWhenClientThrowsWebClientResponseException() {
        WebClientResponseException mockException = mock(WebClientResponseException.class);

        doReturn(requestBodyUriSpec).when(webClient).post();
        when(requestBodyUriSpec.uri(PeepsService.BULK_USER_INFO_URL))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.header(any(), any())).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenThrow(mockException);

        assertThrows(WebClientResponseException.class, () -> service.retrieveAccountType(myUscisId));
        assertThat(service.retrieveApplicantId(myUscisId)).isNull();

    }

    @Test
    void shouldReturnEmptyArrayWhenAccountTypeResponseEmpty() throws JsonProcessingException {
        BulkInfoResponse response = Instancio.create(BulkInfoResponse.class);
        response.setData(Collections.emptyList());

        doReturn(requestBodyUriSpec).when(webClient).post();
        when(requestBodyUriSpec.uri(PeepsService.BULK_USER_INFO_URL))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.header(any(), any())).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(BulkInfoResponse.class)).thenReturn(bulkInfoResponseMono);
        when(bulkInfoResponseMono.block()).thenReturn(response);

        AccountTypeResponse accountType = service.retrieveAccountType(myUscisId);
        assertThat(accountType.accountType()).isEqualTo(AccountType.APPLICANT);
    }

    @Test
    void shouldReturnAccountTypeWhenAccountTypeResponseIsValid() {
        BulkInfoResponse validResponse = Instancio.create(BulkInfoResponse.class);
        validResponse.getData().getFirst().setAccountType("applicant");

        doReturn(requestBodyUriSpec).when(webClient).post();
        when(requestBodyUriSpec.uri(PeepsService.BULK_USER_INFO_URL))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.header(any(), any())).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(BulkInfoResponse.class)).thenReturn(bulkInfoResponseMono);
        when(bulkInfoResponseMono.block()).thenReturn(validResponse);
        AccountTypeResponse response = service.retrieveAccountType(myUscisId);

        assertNotNull(response);
        assertEquals(response.accountType(), AccountType.APPLICANT);
    }

    @Test
    void retrieveRepresentativeProfileTypeShouldReturnProfileWhenResponseIsValid() {
        RepresentativeProfileResponseData data = RepresentativeProfileResponseData.builder().email("email").build();
        RepresentativeProfileResponse validResponse = new RepresentativeProfileResponse(data, null);

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PeepsService.REPRESENTATIVE_PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(RepresentativeProfileResponse.class)).thenReturn(Mono.just(validResponse));

        RepresentativeProfileResponseData response = service.retrieveRepresentativeProfile(myUscisId);

        assertNotNull(response);
        assertEquals(response.email(), "email");
    }

    @Test
    void retrieveRepresentativeProfileShouldThrowWhenResponseEmpty() throws JsonProcessingException {
        RepresentativeProfileResponse validResponse = new RepresentativeProfileResponse(null, null);

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PeepsService.REPRESENTATIVE_PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(RepresentativeProfileResponse.class)).thenReturn(Mono.just(validResponse));

        Exception exception = assertThrows(RuntimeException.class,
                () -> service.retrieveRepresentativeProfile(myUscisId));
        assertEquals("Received invalid response from account profile api", exception.getMessage());
    }

    @Test
    void retrieveRepresentativeProfileShouldThrowWebClientResponseException() {
        WebClientResponseException mockException = mock(WebClientResponseException.class);

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PeepsService.REPRESENTATIVE_PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenThrow(mockException);

        assertThrows(WebClientResponseException.class, () -> service.retrieveRepresentativeProfile(myUscisId));
    }

    @Test
    void validateClientEmailShouldReturnTrueWhenEmailNotMatch() {
        final String appEmail = "ktrout@illium.edu";
        final String repEmail = "john.doe@uscis.dhs.gov";

        var repProfile = RepresentativeProfileResponseData.builder().email(repEmail).build();

        PeepsService spy = mock(PeepsService.class);
        // doReturn(repProfile).when(spy).retrieveRepresentativeProfile(myUscisId);
        // when(spy.validateClientEmail(myUscisId, appEmail)).thenReturn(true);
        var result = spy.validateClientEmailIsNotAttorneyEmail(myUscisId, appEmail);
        assertEquals(false, result);
        // verify(spy, times(1)).retrieveRepresentativeProfile(myUscisId);
    }

    @Test
    void validateClientEmailShouldThrowWhenEmailsMatch() {
        final String repEmail = "john.doe@uscis.dhs.gov";

        var repProfile = RepresentativeProfileResponseData.builder().email(repEmail).build();

        PeepsService spy = spy(service);
        doReturn(repProfile).when(spy).retrieveRepresentativeProfile(myUscisId);

        boolean validateClientEmail = spy.validateClientEmailIsNotAttorneyEmail(myUscisId, repEmail);
        assertThat(validateClientEmail).isFalse();
        verify(spy, times(1)).retrieveRepresentativeProfile(myUscisId);
    }

    @Test
    void validateClientInformationMatches() {
        Name name = new Name(FIRST_NAME, null, LAST_NAME);
        ReceiptProfile profile = new ReceiptProfile();
        profile.setAlienNumber(ANUMBER);
        profile.setDateOfBirth(DOB);
        profile.setFirstName(FIRST_NAME);
        profile.setLastName(LAST_NAME);
        PeepsProfileResponse response = new PeepsProfileResponse(profile, null);

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(response);

        var result = service.verifyClientInformation(myUscisId, name, DOB, ANUMBER);
        assertEquals(true, result);
    }

    @Test
    void validateClientInformation_nullResponseReturnsFalse() {
        String aNumber = ANUMBER;
        String dateOfBirth = DOB;

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(null);

        var result = service.verifyClientInformation(myUscisId, new Name(), dateOfBirth, aNumber);
        assertEquals(false, result);
    }

    @Test
    void validateClientInformationDoesNotMatch() {

        String aNumber = ANUMBER;
        String dateOfBirth = DOB;

        String peepsANumber = "987654321";
        String peepsDOB = "10/10/1987";
        ReceiptProfile profile = new ReceiptProfile();
        profile.setAlienNumber(peepsANumber);
        profile.setDateOfBirth(peepsDOB);
        PeepsProfileResponse response = new PeepsProfileResponse(profile, peepsDOB);

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(response);

        var result = service.verifyClientInformation(myUscisId, new Name(), dateOfBirth, aNumber);
        assertEquals(false, result);
    }

    @Test
    void validateClientInformationDoesNotMatch_nullDOB() {

        String aNumber = ANUMBER;
        String dateOfBirth = null;

        String peepsANumber = "987654321";
        String peepsDOB = "10/10/1987";
        ReceiptProfile profile = new ReceiptProfile();
        profile.setAlienNumber(peepsANumber);
        profile.setDateOfBirth(peepsDOB);
        PeepsProfileResponse response = new PeepsProfileResponse(profile, peepsDOB);

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(response);

        var result = service.verifyClientInformation(myUscisId, new Name(), dateOfBirth, aNumber);
        assertEquals(false, result);
    }

    @Test
    void validateClientInformationMatches_nullANumberInPeepsAndForm() {

        String aNumber = null;
        String peepsANumber = null;
        ReceiptProfile profile = new ReceiptProfile();
        profile.setAlienNumber(peepsANumber);
        profile.setDateOfBirth(DOB);
        profile.setFirstName(FIRST_NAME);
        profile.setLastName(LAST_NAME);
        PeepsProfileResponse response = new PeepsProfileResponse(profile, null);

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(response);

        var result = service.verifyClientInformation(myUscisId, new Name(FIRST_NAME, null, LAST_NAME), DOB, aNumber);
        assertEquals(true, result);
    }

    @Test
    void validateClientInformationDoesNotMatch_nullANumberButProfileHasAnANumber() {

        String aNumber = null;

        String peepsANumber = "987654321";
        String peepsDOB = DOB;
        ReceiptProfile profile = new ReceiptProfile();
        profile.setAlienNumber(peepsANumber);
        profile.setDateOfBirth(peepsDOB);
        PeepsProfileResponse response = new PeepsProfileResponse(profile, null);

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(response);

        var result = service.verifyClientInformation(myUscisId, new Name(), DOB, aNumber);
        assertEquals(false, result);
    }

    @Test
    void validateClientInformationDoesNotMatch_ANumberMismatchAndDobMatch() {

        String aNumber = ANUMBER;

        String peepsANumber = "987654321";
        ReceiptProfile profile = new ReceiptProfile();
        profile.setAlienNumber(peepsANumber);
        profile.setDateOfBirth(DOB);
        PeepsProfileResponse response = new PeepsProfileResponse(profile, DOB);

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(response);

        var result = service.verifyClientInformation(myUscisId, new Name(), DOB, aNumber);
        assertEquals(false, result);
    }

    @Test
    void validateClientInformationDoesNotMatch_FirstNameMismatch() {

        ReceiptProfile profile = new ReceiptProfile();
        profile.setAlienNumber(ANUMBER);
        profile.setDateOfBirth(DOB);
        profile.setFirstName(FIRST_NAME);
        profile.setLastName(LAST_NAME);
        PeepsProfileResponse response = new PeepsProfileResponse(profile, DOB);

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(response);

        String differentFirstName = String.format("%sTest", FIRST_NAME);
        var result = service.verifyClientInformation(myUscisId, new Name(differentFirstName, null, LAST_NAME), DOB, ANUMBER);
        assertEquals(false, result);
    }

    @Test
    void validateClientInformationDoesNotMatch_LastNameMismatch() {

        ReceiptProfile profile = new ReceiptProfile();
        profile.setAlienNumber(ANUMBER);
        profile.setDateOfBirth(DOB);
        profile.setFirstName(FIRST_NAME);
        profile.setLastName(LAST_NAME);
        PeepsProfileResponse response = new PeepsProfileResponse(profile, DOB);

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(response);

        String differentLastName = String.format("%sTest", LAST_NAME);
        var result = service.verifyClientInformation(myUscisId, new Name(FIRST_NAME, null, differentLastName), DOB, ANUMBER);
        assertEquals(false, result);
    }

    @Test
    void validateClientInformationMatches_CaseInsensitive() {

        ReceiptProfile profile = new ReceiptProfile();
        profile.setAlienNumber(ANUMBER);
        profile.setDateOfBirth(DOB);
        profile.setFirstName(FIRST_NAME);
        profile.setLastName(LAST_NAME);
        PeepsProfileResponse response = new PeepsProfileResponse(profile, DOB);

        when(peepsClient.retrieveUserInfo(myUscisId)).thenReturn(response);

        var result = service.verifyClientInformation(myUscisId, new Name(FIRST_NAME.toLowerCase(), null, LAST_NAME.toLowerCase()), DOB, ANUMBER);
        assertEquals(true, result);
    }

    @Test
    void shouldReturnApplicantUuidWhenAccountUuidResponseIsValid() {
        BulkInfoResponse validResponse = Instancio.create(BulkInfoResponse.class);
        validResponse.getData().getFirst().setEmail("test");
        validResponse.getData().getFirst().setAccountType(AccountType.APPLICANT.getType());

        doReturn(requestBodyUriSpec).when(webClient).post();
        when(requestBodyUriSpec.uri(service.BULK_USER_INFO_URL))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(BulkInfoResponse.class)).thenReturn(bulkInfoResponseMono);
        when(bulkInfoResponseMono.block()).thenReturn(validResponse);
        ApplicantUuidResponse response = service.retrieveApplicantId("example@gmail.com");

        assertNotNull(response);
        // TODO: mock the Uuid that is returned
        // assertEquals(response.applicatintUUid(), "applicant");
    }

    @Test
    void shouldThrowWhenAccountIsNotAnApplicant() {
        BulkInfoResponse validResponse = Instancio.create(BulkInfoResponse.class);
        validResponse.getData().getFirst().setEmail("test");
        validResponse.getData().getFirst().setAccountType(AccountType.REPRESENTATIVE.getType());

        doReturn(requestBodyUriSpec).when(webClient).post();
        when(requestBodyUriSpec.uri(service.BULK_USER_INFO_URL))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(BulkInfoResponse.class)).thenReturn(bulkInfoResponseMono);
        when(bulkInfoResponseMono.block()).thenReturn(validResponse);

        assertThrows(AddClientValidationException.class, () -> service.retrieveApplicantId("example@gmail.com"));

        // TODO: mock the Uuid that is returned
        // assertEquals(response.applicatintUUid(), "applicant");
    }
}
