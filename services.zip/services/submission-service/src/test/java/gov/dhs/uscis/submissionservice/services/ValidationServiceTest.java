package gov.dhs.uscis.submissionservice.services;

import static org.junit.jupiter.api.Assertions.assertThrows;

import static gov.dhs.uscis.intake.enums.ValidatorEnum.CORE;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.ELIGIBILITY_CATEGORY;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.PERSON;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.SIGNATURE;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.FAIL;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.PASS;
import static gov.dhs.uscis.intake.entities.audit.ActionPerformed.SIGNATURE_DETECTED;
import static gov.dhs.uscis.intake.entities.audit.ActionPerformed.SIGNATURE_NOT_DETECTED;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.assertj.core.api.Assertions.assertThat;
import static org.instancio.Select.field;
import static java.util.Collections.emptyMap;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import org.instancio.Instancio;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.constants.DocumentType;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.validation.ValidationDetails;
import gov.dhs.uscis.intake.models.validation.Validation;
import gov.dhs.uscis.intake.models.validation.ValidationStatusEnum;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResponse;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResult;
import gov.dhs.uscis.intake.services.AuditService;

import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.submissionservice.exception.ValidationStatusDeletionException;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;

@ExtendWith(MockitoExtension.class)
public class ValidationServiceTest {

  @Mock
  ValidationStatusRepository validationStatusRepository;
  @Mock
  UserInformation applicant;
  @Mock
  AuditService auditService;
  @Mock
  FormService formService;
  @Mock
  ToggleService toggleService;

  @InjectMocks
  private ValidationService service;

  private FormMetaData I765_FormMetaData = FormMetaData.builder()
    .validations(
        List.of(
            MetadataValidationEnum.CORE,
            MetadataValidationEnum.SIGNATURE,
            MetadataValidationEnum.FORM_FIELDS
        )
    ).build();

  @Test
  void shouldPersistANewValidationStatusAndNoNewAuditEntry() {
    String expectedError = "more errors";
    Map<String, String> expectedFailures = Map.of("errors", expectedError);
    ValidationStatusResult result = Instancio.of(ValidationStatusResult.class)
        .set(field("validator"), CORE)
        .set(field("status"), PASS)
        .set(field("failureReasons"), List.of(expectedFailures))
        .create();
    this.service.createFrom(result);
    ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
    verify(this.validationStatusRepository, times(1)).save(captor.capture());
    ValidationStatus actual = captor.getValue();
    assertEquals(result.formId(), actual.getFormId());
    assertEquals(result.submissionId(), actual.getSubmissionId());
    assertEquals(result.status(), actual.getStatus());
    assertEquals(result.validator(), actual.getValidator());
    assertEquals(result.validationWarnings(), actual.getValidationWarnings());
    assertEquals(List.of(expectedError), actual.getFailureReasons());
    verifyNoInteractions(auditService);
  }

  @Test
  void shouldPersistSignatureValidationWithNullStatusWhenStillDependentOnAdditionalValidations() {
    String expectedError = "more errors";
    String formId = "formId";
    String submissionId = "submissionId";
    String myUscisId = "myUscisId";
    String messageId = "messageId";

    Map<String, String> expectedFailures = Map.of("errors", expectedError);

    ValidationStatusResult result = Instancio.of(ValidationStatusResult.class)
        .set(field("formId"), formId)
        .set(field("submissionId"), submissionId)
        .set(field("myUscisId"), myUscisId)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), null)
        .set(field("isMultipart"), true)
        .set(field("failureReasons"), List.of(expectedFailures))
        .create();

    ValidationStatusResult expected = Instancio.of(ValidationStatusResult.class)
        .set(field("formId"), formId)
        .set(field("submissionId"), submissionId)
        .set(field("myUscisId"), myUscisId)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), null)
        .set(field("isMultipart"), true)
        .set(field("failureReasons"), List.of(expectedFailures))
        .create();

    when(validationStatusRepository.getByFileId(formId)).thenReturn(List.of());

    this.service.saveSignatureResult(result, messageId);

    ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);

    verify(this.validationStatusRepository, times(1)).save(captor.capture());
    ValidationStatus actual = captor.getValue();
    assertEquals(expected.formId(), actual.getFormId());
    assertEquals(expected.submissionId(), actual.getSubmissionId());
    assertEquals(expected.status(), actual.getStatus());
    assertEquals(expected.validator(), actual.getValidator());
    // assertEquals(expected.validationWarnings(), actual.getValidationWarnings());
    assertEquals(List.of(expectedError), actual.getFailureReasons());

    verify(auditService, times(0))
        .addEvent(eq(expected.myUscisId()),
            eq(expected.submissionId()),
            any(ActionPerformed.class), anyString());
  }
  @Test
  void shouldNotCompleteValidationWhenStillDependentOnAdditionalValidationsButMessageIsReadMoreThanOnce() {
    String expectedError = "more errors";
    String formId = "formId";
    String submissionId = "submissionId";
    String myUscisId = "myUscisId";
    String messageId = "messageId";

    Map<String, String> expectedFailures = Map.of("errors", expectedError);

    ValidationStatusResult result = Instancio.of(ValidationStatusResult.class)
        .set(field("formId"), formId)
        .set(field("submissionId"), submissionId)
        .set(field("myUscisId"), myUscisId)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), null)
        .set(field("isMultipart"), true)
        .set(field("failureReasons"), List.of(expectedFailures))
        .create();

    ValidationStatusResult expected = Instancio.of(ValidationStatusResult.class)
        .set(field("formId"), formId)
        .set(field("submissionId"), submissionId)
        .set(field("myUscisId"), myUscisId)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), null)
        .set(field("isMultipart"), true)
        .set(field("failureReasons"), List.of(expectedFailures))
        .create();

    var existingValidation = ValidationStatus.builder().formId(formId).validator(SIGNATURE).isMultipart(false)
        .messageId(messageId).failureReasons(List.of()).build();
    when(validationStatusRepository.getByFileId(formId)).thenReturn(List.of(existingValidation));

    this.service.saveSignatureResult(result, messageId);

    ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);

    verify(this.validationStatusRepository, times(1)).save(captor.capture());
    ValidationStatus actual = captor.getValue();
    assertEquals(expected.formId(), actual.getFormId());
    assertEquals(expected.submissionId(), actual.getSubmissionId());
    assertEquals(expected.status(), actual.getStatus());
    assertEquals(expected.validator(), actual.getValidator());
    // assertEquals(expected.validationWarnings(), actual.getValidationWarnings());
    assertEquals(List.of(expectedError), actual.getFailureReasons());

    verify(auditService, times(0))
        .addEvent(eq(expected.myUscisId()),
            eq(expected.submissionId()),
            any(ActionPerformed.class), anyString());
  }

  @Test
  void shouldPersistValidationStatusWhenNoLongerDependentOnAdditionalValidations_PASS() {
    String formId = "formId";
    String submissionId = "submissionId";
    String myUscisId = "myUscisId";
    String messageId = "messageId";

    ValidationStatusResult result = Instancio.of(ValidationStatusResult.class)
        .set(field("formId"), formId)
        .set(field("submissionId"), submissionId)
        .set(field("myUscisId"), myUscisId)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), PASS)
        .set(field("isMultipart"), true)
        .set(field("failureReasons"), List.of())
        .create();
    ValidationStatusResult expected = Instancio.of(ValidationStatusResult.class)
        .set(field("formId"), formId)
        .set(field("submissionId"), submissionId)
        .set(field("myUscisId"), myUscisId)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), PASS)
        .set(field("failureReasons"), List.of())
        .create();

    var existingValidation = ValidationStatus.builder().formId(formId).validator(SIGNATURE).isMultipart(false)
        .messageId("differentMessageId").failureReasons(List.of()).build();
    when(validationStatusRepository.getByFileId(formId)).thenReturn(List.of(existingValidation));

    this.service.saveSignatureResult(result, messageId);

    ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);

    verify(this.validationStatusRepository, times(1)).save(captor.capture());
    ValidationStatus actual = captor.getValue();
    assertEquals(expected.formId(), actual.getFormId());
    assertEquals(expected.submissionId(), actual.getSubmissionId());
    assertEquals(expected.status(), actual.getStatus());
    assertEquals(expected.validator(), actual.getValidator());
    // assertEquals(expected.validationWarnings(), actual.getValidationWarnings());
    assertEquals(List.of(), actual.getFailureReasons());

    verify(auditService, times(1))
        .addEvent(eq(expected.myUscisId()),
            eq(expected.submissionId()),
            eq(SIGNATURE_DETECTED), eq(""));
  }

  @Test
  void shouldPersistValidationStatusWhenNoLongerDependentOnAdditionalValidations_FAIL() {
    String expectedError = "The uploaded form is missing one or both signatures. Please sign the form and reupload.";
    String formId = "formId";
    String submissionId = "submissionId";
    String myUscisId = "myUscisId";
    String messageId = "messageId";

    Map<String, String> expectedFailures = Map.of("errors", expectedError);
    ValidationStatusResult result = Instancio.of(ValidationStatusResult.class)
        .set(field("formId"), formId)
        .set(field("submissionId"), submissionId)
        .set(field("myUscisId"), myUscisId)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), PASS)
        .set(field("isMultipart"), true)
        .set(field("failureReasons"), List.of(expectedFailures))
        .create();
    ValidationStatusResult expected = Instancio.of(ValidationStatusResult.class)
        .set(field("formId"), formId)
        .set(field("submissionId"), submissionId)
        .set(field("myUscisId"), myUscisId)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), FAIL)
        .set(field("failureReasons"), List.of(expectedFailures))
        .create();

    var existingValidation = ValidationStatus.builder().formId(formId).messageId("differentMessageId").isMultipart(true)
        .validator(SIGNATURE).failureReasons(List.of()).build();
    when(validationStatusRepository.getByFileId(formId)).thenReturn(List.of(existingValidation));

    this.service.saveSignatureResult(result, messageId);

    ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
    verify(this.validationStatusRepository, times(1)).save(captor.capture());
    ValidationStatus actual = captor.getValue();
    assertEquals(expected.formId(), actual.getFormId());
    assertEquals(expected.submissionId(), actual.getSubmissionId());
    assertEquals(expected.status(), actual.getStatus());
    assertEquals(expected.validator(), actual.getValidator());
    // assertEquals(expected.validationWarnings(), actual.getValidationWarnings());
    assertEquals(List.of(expectedError), actual.getFailureReasons());

    verify(auditService, times(1))
        .addEvent(eq(expected.myUscisId()),
            eq(expected.submissionId()),
            eq(SIGNATURE_NOT_DETECTED), eq(""));
  }

  @Test
  void shouldPersistANewValidationStatusAndAddNewSignatureDetectedAuditEvent() {
    String expectedError = "more errors";
    Map<String, String> expectedFailures = Map.of("errors", expectedError);
    ValidationStatusResult expected = Instancio.of(ValidationStatusResult.class)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), PASS)
        .set(field("failureReasons"), List.of(expectedFailures))
        .create();
    this.service.saveSignatureResult(expected, "");
    ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
    verify(this.validationStatusRepository, times(1)).save(captor.capture());
    ValidationStatus actual = captor.getValue();
    assertEquals(expected.formId(), actual.getFormId());
    assertEquals(expected.submissionId(), actual.getSubmissionId());
    assertEquals(expected.status(), actual.getStatus());
    assertEquals(expected.validator(), actual.getValidator());
    assertEquals(expected.validationWarnings(), actual.getValidationWarnings());
    assertEquals(List.of(expectedError), actual.getFailureReasons());
    verify(auditService, times(1))
        .addEvent(eq(expected.myUscisId()),
            eq(expected.submissionId()),
            eq(SIGNATURE_DETECTED), eq(""));
  }

  @Test
  void shouldPersistANewValidationStatusAndAddNewSignatureNotDetectedAuditEvent() {
    String expectedError = "more errors";
    Map<String, String> expectedFailures = Map.of("errors", expectedError);
    ValidationStatusResult expected = Instancio.of(ValidationStatusResult.class)
        .set(field("validator"), SIGNATURE)
        .set(field("status"), FAIL)
        .set(field("failureReasons"), List.of(expectedFailures))
        .create();
    this.service.saveSignatureResult(expected, "");
    ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
    verify(this.validationStatusRepository, times(1)).save(captor.capture());
    ValidationStatus actual = captor.getValue();
    assertEquals(expected.formId(), actual.getFormId());
    assertEquals(expected.submissionId(), actual.getSubmissionId());
    assertEquals(expected.status(), actual.getStatus());
    assertEquals(expected.validator(), actual.getValidator());
    assertEquals(expected.validationWarnings(), actual.getValidationWarnings());
    assertEquals(List.of(expectedError), actual.getFailureReasons());
    verify(auditService, times(1))
        .addEvent(eq(expected.myUscisId()),
            eq(expected.submissionId()),
            eq(SIGNATURE_NOT_DETECTED), eq(""));
  }

  @Test
  void shouldReturnValidationStatusWhenCompleted_AllPass() {
    String formId = "c0";
    Submission submission = createSubmissionWithFormId(formId);
    submission.setApplicant(applicant);
    when(applicant.getAccountType()).thenReturn(AccountType.APPLICANT);
    ValidationStatus result1 = ValidationStatus.builder().formId(formId).status(ValidationResultEnum.PASS).build();

    List<ValidationStatus> results = Arrays.asList(
        ValidationStatus.builder()
            .formId(formId)
            .validator(CORE)
            .status(ValidationResultEnum.PASS)
        .build(),
        ValidationStatus.builder()
            .formId(formId)
            .validator(PERSON)
            .status(ValidationResultEnum.PASS)
        .build(),
        ValidationStatus.builder()
            .formId(formId)
            .validator(ELIGIBILITY_CATEGORY)
            .status(ValidationResultEnum.PASS)
        .build(),
        ValidationStatus.builder()
            .formId(formId)
            .validator(SIGNATURE)
            .status(ValidationResultEnum.PASS)
        .build()
    );
    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);
    when(formService.retrieveFormMetaData(FormType.I765.getType())).thenReturn(I765_FormMetaData);

    ValidationStatusResponse response = service.retrieveValidationStatus(submission);

    assertEquals(ValidationStatusEnum.COMPLETE, response.status());
    assertEquals(1, response.formValidations().size());
    assertEquals(0, response.evidenceValidations().size());
    Validation formValidation = response.formValidations().get(0);

    assertEquals(ValidationStatusEnum.COMPLETE, formValidation.status());
    assertEquals(FormType.I765.getType(), formValidation.groupType());
    assertEquals(4, formValidation.details().size());
  }

  private Submission createSubmissionWithFormId(String formId) {
    Submission submission = Submission.builder()
        .submissionId(UUID.randomUUID().toString())
        .forms(Lists.newArrayList(SubmissionForm.builder().id(formId).type(FormType.I765.getType()).build()))
        .formType(FormType.I765)
        .build();
    return submission;
  }

  private Submission createSubmissionWithEvidenceWithId(String evidenceId, String evidenceType) {
    Submission submission = Submission.builder()
        .submissionId(UUID.randomUUID().toString())
        .evidences(Lists.newArrayList(SubmissionEvidence.builder().id(evidenceId).type(evidenceType).build()))
        .build();
    return submission;
  }

  @Test
  void shouldReturnI912ValidationStatusWhenCompleted_Pass() {
    String formId = "formId";
    ValidationStatus result = ValidationStatus.builder().formId(formId).validator(ValidatorEnum.I912)
        .status(ValidationResultEnum.PASS).build();

    List<ValidationStatus> results = Arrays.asList(result);
    Submission mockSubmission = mock(Submission.class);
    SubmissionEvidence mockFeeWaiver = mock(SubmissionEvidence.class);

    when(mockSubmission.getFeeWaiver()).thenReturn(mockFeeWaiver);
    when(mockFeeWaiver.getType()).thenReturn(DocumentType.FeeWaiver.FORM_I912);
    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);
    ValidationStatusResponse response = service.retrieveI912ValidationStatus(formId, mockSubmission);
    assertEquals(ValidationStatusEnum.COMPLETE, response.status());
    assertNull(response.formValidations());
    assertNull(response.evidenceValidations());
    assertNotNull(response.i912FeeWaiverValidation());
    assertEquals(ValidatorEnum.I912, response.i912FeeWaiverValidation().validator());

  }

  @Test
  void shouldReturnFeeDeclarationValidationStatus_Pass() {
    String formId = "formId";

    Submission mockSubmission = mock(Submission.class);
    SubmissionEvidence mockFeeWaiver = mock(SubmissionEvidence.class);

    ValidationStatus result = ValidationStatus.builder().formId(formId).validator(ValidatorEnum.I912)
    .status(ValidationResultEnum.FAIL).failureReasons(List.of("Form type 'I-912' is not present.")).build();
    List<ValidationStatus> results = Arrays.asList(result);

    when(mockSubmission.getFeeWaiver()).thenReturn(mockFeeWaiver);
    when(mockFeeWaiver.getType()).thenReturn(DocumentType.FeeWaiver.FEE_DECLARATION);
    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);

    ValidationStatusResponse response = service.retrieveI912ValidationStatus(formId, mockSubmission);
    org.assertj.core.api.Assertions.assertThat(response.status()).isEqualTo(ValidationStatusEnum.COMPLETE);
    org.assertj.core.api.Assertions.assertThat(response.i912FeeWaiverValidation()).isNotNull();
    org.assertj.core.api.Assertions.assertThat(response.i912FeeWaiverValidation().validator()).isEqualTo(ValidatorEnum.I912);
    org.assertj.core.api.Assertions.assertThat(response.i912FeeWaiverValidation().result())
        .isEqualTo(ValidationResultEnum.PASS);
  }

  @Test
  void shouldReturnFeeDeclarationValidationStatus_Fail() {
    String formId = "formId";

    Submission mockSubmission = mock(Submission.class);
    SubmissionEvidence mockFeeWaiver = mock(SubmissionEvidence.class);

    ValidationStatus result = ValidationStatus.builder().formId(formId).validator(ValidatorEnum.I912)
    .status(ValidationResultEnum.FAIL).failureReasons(List.of("Your Signature does not appear to be present")).build();
    List<ValidationStatus> results = Arrays.asList(result);

    when(mockSubmission.getFeeWaiver()).thenReturn(mockFeeWaiver);
    when(mockFeeWaiver.getType()).thenReturn(DocumentType.FeeWaiver.FEE_DECLARATION);
    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);

    ValidationStatusResponse response = service.retrieveI912ValidationStatus(formId, mockSubmission);
    org.assertj.core.api.Assertions.assertThat(response.status()).isEqualTo(ValidationStatusEnum.COMPLETE);
    org.assertj.core.api.Assertions.assertThat(response.i912FeeWaiverValidation()).isNotNull();
    org.assertj.core.api.Assertions.assertThat(response.i912FeeWaiverValidation().validator()).isEqualTo(ValidatorEnum.I912);
    org.assertj.core.api.Assertions.assertThat(response.i912FeeWaiverValidation().result())
        .isEqualTo(ValidationResultEnum.FAIL);
  }

  @Test
  void retrieveI912ValidationStatus_shouldHandleNulls() {
    String formId = UUID.randomUUID().toString();
    Submission mockSubmission = mock(Submission.class);
    when(mockSubmission.getFeeWaiver()).thenReturn(null);

    ValidationStatusResponse r1 = service.retrieveI912ValidationStatus(formId, mockSubmission);
    assertEquals(ValidationStatusEnum.IN_PROGRESS, r1.status());

    SubmissionEvidence mockFeeWaiver = mock(SubmissionEvidence.class);
    when(mockSubmission.getFeeWaiver()).thenReturn(mockFeeWaiver);
    when(mockFeeWaiver.getType()).thenReturn(null);

    ValidationStatusResponse r2 = service.retrieveI912ValidationStatus(formId, mockSubmission);
    assertEquals(ValidationStatusEnum.IN_PROGRESS, r2.status());
  }


  @Test
  void retrieveI912ValidationStatus_shouldShortCircutImageDocuments() {
    String formId = UUID.randomUUID().toString();
    Submission mockSubmission = mock(Submission.class);

    SubmissionEvidence mockFeeWaiver = mock(SubmissionEvidence.class);
    when(mockFeeWaiver.getS3Key()).thenReturn("uploaded_document.jpg");
    when(mockSubmission.getFeeWaiver()).thenReturn(mockFeeWaiver);

    ValidationStatusResponse validationStatusResponse = service.retrieveI912ValidationStatus(formId, mockSubmission);
    assertEquals(ValidationStatusEnum.COMPLETE, validationStatusResponse.status());
  }

  @Test
  void retrieveI912ValidationStatus_shouldValidatePdfDocuments() {
    String formId = UUID.randomUUID().toString();
    Submission mockSubmission = mock(Submission.class);

    SubmissionEvidence mockFeeWaiver = mock(SubmissionEvidence.class);
    when(mockFeeWaiver.getS3Key()).thenReturn("uploaded_document.pdf");
    when(mockSubmission.getFeeWaiver()).thenReturn(mockFeeWaiver);

    ValidationStatusResponse validationStatusResponse = service.retrieveI912ValidationStatus(formId, mockSubmission);
    assertEquals(ValidationStatusEnum.IN_PROGRESS, validationStatusResponse.status());
  }

  @Test
  void retrieveI912ValidationStatus_shouldValidatePdfDocumentWithEmptyKey() {
    String formId = UUID.randomUUID().toString();
    Submission mockSubmission = mock(Submission.class);

    SubmissionEvidence mockFeeWaiver = mock(SubmissionEvidence.class);
    when(mockFeeWaiver.getS3Key()).thenReturn("");
    when(mockSubmission.getFeeWaiver()).thenReturn(mockFeeWaiver);

    ValidationStatusResponse validationStatusResponse = service.retrieveI912ValidationStatus(formId, mockSubmission);
    assertEquals(ValidationStatusEnum.COMPLETE, validationStatusResponse.status());
  }

  @Test
  void retrieveI912ValidationStatus_shouldValidatePdfDocumentWithNullKey() {
    String formId = UUID.randomUUID().toString();
    Submission mockSubmission = mock(Submission.class);

    SubmissionEvidence mockFeeWaiver = mock(SubmissionEvidence.class);
    when(mockFeeWaiver.getS3Key()).thenReturn(null);
    when(mockSubmission.getFeeWaiver()).thenReturn(mockFeeWaiver);

    ValidationStatusResponse validationStatusResponse = service.retrieveI912ValidationStatus(formId, mockSubmission);
    assertEquals(ValidationStatusEnum.IN_PROGRESS, validationStatusResponse.status());
  }


  @Test
  void shouldReturnValidationStatusWhenCompleted_CoreFail() {
    String formId = "c0";
    Submission submission = createSubmissionWithFormId(formId);
    submission.setApplicant(applicant);
    when(applicant.getAccountType()).thenReturn(AccountType.APPLICANT);
    ValidationStatus result1 = ValidationStatus.builder().formId(formId).status(ValidationResultEnum.FAIL)
        .validator(ValidatorEnum.CORE).failureReasons(List.of("Failed core reason")).build();

    List<ValidationStatus> results = Arrays.asList(result1);
    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);
    when(formService.retrieveFormMetaData(FormType.I765.getType())).thenReturn(I765_FormMetaData);
    when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I765.getType())).thenReturn(false);
    ValidationStatusResponse response = service.retrieveValidationStatus(submission);
    assertEquals(ValidationStatusEnum.COMPLETE, response.status());
    assertEquals(1, response.formValidations().size());
  }

  @Test
  void shouldNotReturnValidationStatusInProgress() {
    String formId = "c0";
    UserInformation applicant = mock(UserInformation.class);
    Submission submission = createSubmissionWithFormId(formId);
    submission.setApplicant(applicant);
    when(applicant.getAccountType()).thenReturn(AccountType.APPLICANT);
    ValidationStatus result1 = ValidationStatus.builder().formId(formId).status(ValidationResultEnum.PASS).build();
    when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I765.getType())).thenReturn(true);

    List<ValidationStatus> results = Arrays.asList(result1);
    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);
    when(formService.retrieveFormMetaData(FormType.I765.getType())).thenReturn(I765_FormMetaData);
    ValidationStatusResponse response = service.retrieveValidationStatus(submission);
    assertEquals(ValidationStatusEnum.IN_PROGRESS, response.status());
  }

  @Test
  void shouldReturnValidationStatusForEvidenceWhenFormIsNotPresent() {
    String evidenceId = "ev1";
    Submission submission = createSubmissionWithEvidenceWithId(evidenceId, ValidationService.FORM_797);
    submission.setForms(Lists.newArrayList());
    submission.getEvidences().add(SubmissionEvidence.builder().id("ev2").type("Applicant Photo").build());
    submission.setApplicant(applicant);
    when(applicant.getAccountType()).thenReturn(AccountType.APPLICANT);
    ValidationStatus result1 = ValidationStatus.builder().formId(evidenceId).status(ValidationResultEnum.PASS).build();

    List<ValidationStatus> results = Arrays.asList(result1);
    when(validationStatusRepository.getByFileId(evidenceId)).thenReturn(results);
    ValidationStatusResponse response = service.retrieveValidationStatus(submission);

    verify(validationStatusRepository, times(1)).getByFileId(evidenceId);
    assertEquals(ValidationStatusEnum.COMPLETE, response.status());
    assertTrue(response.formValidations().isEmpty());
    assertFalse(response.evidenceValidations().isEmpty());

    Validation validationEvidenceItem = response.evidenceValidations().get(0);
    assertEquals(evidenceId, validationEvidenceItem.id());
    assertFalse(validationEvidenceItem.details().isEmpty());
    assertEquals(ValidationResultEnum.PASS, validationEvidenceItem.details().get(0).result());
  }

  @Test
  void shouldReturnEmptyValidationStatusResponse() {
    List<ValidationStatus> results = Collections.emptyList();
    String formId = "test";
    Submission submission = createSubmissionWithFormId(formId);
    submission.setApplicant(applicant);
    when(applicant.getAccountType()).thenReturn(AccountType.APPLICANT);
    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);
    when(formService.retrieveFormMetaData(FormType.I765.getType())).thenReturn(I765_FormMetaData);
    ValidationStatusResponse response = service.retrieveValidationStatus(submission);
    assertEquals(ValidationStatusEnum.IN_PROGRESS, response.status());

    Validation formValidation = response.formValidations().get(0);
    assertEquals(ValidationStatusEnum.IN_PROGRESS, formValidation.status());

    assertEquals(0, formValidation.details().size());
  }

  @Test
  void shouldReturnEligibilityCategoryPassValidation() {
    String formId = UUID.randomUUID().toString();
    Submission submission = createSubmissionWithFormId(formId);
    String submissionId = UUID.randomUUID().toString();
    submission.setApplicant(applicant);
    when(applicant.getAccountType()).thenReturn(AccountType.APPLICANT);
    ValidationStatus eligibilityCategory = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
        .failureReasons(List.of()).validationWarnings(Collections.emptyMap()).build();
    ValidationStatus core = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.CORE)
        .failureReasons(List.of()).validationWarnings(Collections.emptyMap()).build();
    ValidationStatus person = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.PERSON)
        .failureReasons(List.of("Person does not seem to be present")).validationWarnings(Collections.emptyMap())
        .build();
    ValidationStatus signature = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.FAIL).validator(ValidatorEnum.SIGNATURE)
        .failureReasons(List.of("Signature does not seem to be present")).validationWarnings(Collections.emptyMap())
        .build();
    List<ValidationStatus> results = Arrays.asList(eligibilityCategory, core, person, signature);

    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);
    when(formService.retrieveFormMetaData(FormType.I765.getType())).thenReturn(I765_FormMetaData);

    ValidationStatusResponse response = service.retrieveValidationStatus(submission);

    Validation formValidation = response.formValidations().get(0);

    assertEquals(ValidationStatusEnum.COMPLETE, response.status());
    assertEquals(4, formValidation.details().size());
    ValidationDetails item = formValidation.details().stream()
        .filter(validation -> validation.validator().equals(ValidatorEnum.ELIGIBILITY_CATEGORY)).findAny()
        .get();
    assertEquals(ValidationResultEnum.PASS, item.result());
    assertEquals(ValidatorEnum.ELIGIBILITY_CATEGORY, item.validator());
  }

  @Test
  void shouldReturnEligibilityCategoryFailValidation() {
    String formId = UUID.randomUUID().toString();
    Submission submission = createSubmissionWithFormId(formId);
    String submissionId = submission.getSubmissionId();
    submission.setApplicant(applicant);
    when(applicant.getAccountType()).thenReturn(AccountType.APPLICANT);
    ValidationStatus eligibilityCategory = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.FAIL).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
        .failureReasons(List.of("Eligibility category unsupported.")).validationWarnings(Collections.emptyMap())
        .build();
    ValidationStatus core = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.CORE)
        .failureReasons(List.of()).validationWarnings(Collections.emptyMap()).build();
    ValidationStatus person = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.PERSON)
        .failureReasons(List.of("Person does not seem to be present")).validationWarnings(Collections.emptyMap())
        .build();

    ValidationStatus signature = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.FAIL).validator(ValidatorEnum.SIGNATURE)
        .failureReasons(List.of("Signature does not seem to be present")).validationWarnings(Collections.emptyMap())
        .build();
    List<ValidationStatus> results = Arrays.asList(eligibilityCategory, core, person, signature);

    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);
    when(formService.retrieveFormMetaData(FormType.I765.getType())).thenReturn(I765_FormMetaData);
    ValidationStatusResponse response = service.retrieveValidationStatus(submission);

    assertEquals(ValidationStatusEnum.COMPLETE, response.status());
    assertEquals(1, response.formValidations().size());

    Validation formValidation = response.formValidations().get(0);
    assertEquals(4, formValidation.details().size());

    ValidationDetails item = formValidation.details().stream()
        .filter(validation -> validation.validator().equals(ValidatorEnum.ELIGIBILITY_CATEGORY)).findAny()
        .get();

    assertEquals(ValidationResultEnum.FAIL, item.result());
    assertEquals(ValidatorEnum.ELIGIBILITY_CATEGORY, item.validator());
    assertEquals(1, item.reasons().size());
  }

  @Test
  void shouldReturnEligibilityCategoryWarningValidation() {
    String formId = UUID.randomUUID().toString();
    Submission submission = createSubmissionWithFormId(formId);
    String submissionId = submission.getSubmissionId();
    String categoryOnForm = "onForm";
    String categoryOnSubmission = "onSubmission";
    submission.setApplicant(applicant);
    when(applicant.getAccountType()).thenReturn(AccountType.APPLICANT);
    HashMap<String, String> warnings = Maps.newHashMap();
    warnings.put("categoryOnForm", categoryOnForm);
    warnings.put("categoryOnSubmission", categoryOnSubmission);

    ValidationStatus eligibilityCategory = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.WARN).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
        .failureReasons(List.of()).validationWarnings(warnings).build();
    ValidationStatus core = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.CORE)
        .failureReasons(List.of()).validationWarnings(Collections.emptyMap()).build();
    ValidationStatus person = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.PERSON)
        .failureReasons(List.of("Person does not seem to be present")).validationWarnings(Collections.emptyMap())
        .build();
    ValidationStatus signature = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.FAIL).validator(ValidatorEnum.SIGNATURE)
        .failureReasons(List.of("Signature does not seem to be present")).validationWarnings(Collections.emptyMap())
        .build();
    List<ValidationStatus> results = Arrays.asList(eligibilityCategory, core, person, signature);

    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);
    when(formService.retrieveFormMetaData(FormType.I765.getType())).thenReturn(I765_FormMetaData);
    ValidationStatusResponse response = service.retrieveValidationStatus(submission);

    Validation formValidation = response.formValidations().get(0);

    assertEquals(ValidationStatusEnum.COMPLETE, formValidation.status());
    assertEquals(4, formValidation.details().size());
    ValidationDetails item = formValidation.details().stream()
        .filter(validation -> validation.validator().equals(ValidatorEnum.ELIGIBILITY_CATEGORY)).findAny()
        .get();
    assertEquals(ValidationResultEnum.WARN, item.result());
    assertEquals(ValidatorEnum.ELIGIBILITY_CATEGORY, item.validator());
    assertEquals(0, item.reasons().size());
    assertEquals(2, item.warnings().size());
    assertEquals(warnings, item.warnings());
  }

  @Test
  void deleteFormFromValidationStatus_shouldSucceed() {
    String formId = UUID.randomUUID().toString();
    String submissionId = UUID.randomUUID().toString();
    String categoryOnForm = "onForm";
    String categoryOnSubmission = "onSubmission";

    HashMap<String, String> warnings = Maps.newHashMap();
    warnings.put("categoryOnForm", categoryOnForm);
    warnings.put("categoryOnSubmission", categoryOnSubmission);

    ValidationStatus eligibilityCategory = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.WARN).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
        .failureReasons(List.of()).validationWarnings(warnings).build();
    ValidationStatus core = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.CORE)
        .failureReasons(List.of()).validationWarnings(emptyMap()).build();
    ValidationStatus signature = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.FAIL).validator(ValidatorEnum.SIGNATURE)
        .failureReasons(List.of("Signature does not seem to be present")).validationWarnings(emptyMap())
        .build();
    List<ValidationStatus> results = Arrays.asList(eligibilityCategory, core, signature);
    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);
    service.deleteStatus(formId);
    verify(validationStatusRepository, times(1)).deleteById(formId, ValidatorEnum.CORE);
  }

  @Test
  void deleteFormFromValidationStatus_shouldThrowValidationStatusDeletionException() {

    String formId = UUID.randomUUID().toString();
    String submissionId = UUID.randomUUID().toString();
    String categoryOnForm = "onForm";
    String categoryOnSubmission = "onSubmission";

    HashMap<String, String> warnings = Maps.newHashMap();
    warnings.put("categoryOnForm", categoryOnForm);
    warnings.put("categoryOnSubmission", categoryOnSubmission);

    ValidationStatus eligibilityCategory = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.WARN).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
        .failureReasons(List.of()).validationWarnings(warnings).build();
    ValidationStatus core = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.CORE)
        .failureReasons(List.of()).validationWarnings(Collections.emptyMap()).build();
    ValidationStatus signature = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.FAIL).validator(ValidatorEnum.SIGNATURE)
        .failureReasons(List.of("Signature does not seem to be present")).validationWarnings(emptyMap())
        .build();
    List<ValidationStatus> results = Arrays.asList(eligibilityCategory, core, signature);
    when(validationStatusRepository.getByFileId(formId)).thenReturn(results);

    doThrow(new ValidationStatusDeletionException("Exception")).when(validationStatusRepository).deleteById(formId,
        ValidatorEnum.CORE);
    assertThrows(ValidationStatusDeletionException.class,
        () -> service.deleteStatus(formId));
  }

   //todo: this test should be evaluated by CSAI-4261 because the method called (validateUpdateSubmission) is defining fee waiver eligibility through a giant if statement.
  @Test
  void shouldValidatePartialSubmissionForUpdate() {
    when(formService.isFeeWaiverEnabled(FormType.I765)).thenReturn(true);
    assertTrue(service.validateUpdateSubmission(Submission.builder().eligibilityCategory(I765EligibilityCategory.A12).build(), FormType.I765));
    assertTrue(service.validateUpdateSubmission(Submission.builder().immvi(true).build(), FormType.I765));
    assertTrue(service.validateUpdateSubmission(Submission.builder().userRequestedFeeWaiver(true).build(), FormType.I765));
    assertTrue(service.validateUpdateSubmission(Submission.builder().userRequestedFeeWaiver(false).build(), FormType.I765));
    assertTrue(service.validateUpdateSubmission(Submission.builder().hasReviewedSignature(true).build(), FormType.I765));
    assertTrue(service.validateUpdateSubmission(Submission.builder().attested(true).build(), FormType.I765));
    assertFalse(service.validateUpdateSubmission(Submission.builder().feeTotal(BigDecimal.ZERO).build(), FormType.I765));
  }

  @Test
  void shouldMarkPartialSubmissionForUpdateAsInvalid() {
    when(formService.isFeeWaiverEnabled(FormType.N400)).thenReturn(false);

    assertThat(service.validateUpdateSubmission(Submission.builder().userRequestedFeeWaiver(true).build(), FormType.N400)).isFalse();
    assertThat(service.validateUpdateSubmission(Submission.builder().userRequestedPartialFeeWaiver(true).build(), FormType.N400)).isFalse();
  }

}
