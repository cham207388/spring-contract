package gov.dhs.uscis.submissionservice.repository;

import java.net.URI;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import static org.junit.jupiter.api.Assertions.*;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.validation.name_extract.ClientName;
import gov.dhs.uscis.intake.models.validation.name_extract.NameExtract;
import gov.dhs.uscis.submissionservice._testutils.LocalDbCreationRule;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.ScanRequest;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;

public class NameExtractRepositoryTest {

    private static final String TABLE_NAME = "default-NameExtract";
    @RegisterExtension
    static LocalDbCreationRule localDynamoDb = new LocalDbCreationRule();

    private static DynamoDbClient dynamoDbClient;
    private static DynamoDbEnhancedClient dynamoDbEnhancedClient;
    private static DynamoDbTable<NameExtract> nameExtractTable;
    private static NameExtractRepository nameExtractRepository;

    @BeforeAll
    private static void before() {

        dynamoDbClient = DynamoDbClient
        .builder()
        .endpointOverride(URI.create(String.format("http://localhost:%s", localDynamoDb.getPort())))
        .build();

        dynamoDbEnhancedClient = DynamoDbEnhancedClient
                .builder()
                .dynamoDbClient(dynamoDbClient)
                .build();

        nameExtractTable = dynamoDbEnhancedClient.table(TABLE_NAME, TableSchema.fromBean(NameExtract.class));
        nameExtractTable.createTable();

        nameExtractRepository = new NameExtractRepository(nameExtractTable);

    }

    @BeforeEach
    private void beforeEach() {
        dynamoDbClient.waiter().waitUntilTableExists(b -> b.tableName(nameExtractTable.tableName()));
    }

    @AfterEach
    private void afterEach() {
        nameExtractTable.deleteTable();
        nameExtractTable.createTable();
    }

    private int count() {
        ScanRequest request = ScanRequest.builder()
                .tableName(nameExtractTable.tableName())
                .select("COUNT").build();
        return dynamoDbClient.scan(request).count();
    }

    private void checkRawClientGetItem(String submissionId) {
        var item = dynamoDbClient.getItem(GetItemRequest.builder()
        .tableName(TABLE_NAME)
        .key(Map.of("submissionId", AttributeValue.fromS(submissionId)))
        .build()).item();
        assertThat(item.get("submissionId").s(), equalTo(submissionId));
    }

    private NameExtract generateTestNameExtract(String familyName, String givenName, String submissionId) {
        return NameExtract.builder()
            .submissionId(submissionId)
            .clientNameOnForm(
                ClientName.builder()
                    .givenName(givenName)
                    .familyName(familyName)
                .build()
                )
            .clientNameOnG28(
                ClientName.builder()
                    .givenName(givenName)
                    .familyName(familyName)
                .build()
            )
        .build();
    }


    private static final String submissionId = UUID.randomUUID().toString();

    @Test
    public void shouldSaveAndRetrieve() {
        NameExtract nameExtract = generateTestNameExtract("TestFamilyName", "TestGivenName", submissionId);

        NameExtract.builder()
                .submissionId(submissionId)
                .form(FormType.G28)
                .build();

        NameExtract savedNameExtract = nameExtractRepository.save(nameExtract);

        assertThat(count()).isEqualTo(1);
        checkRawClientGetItem(submissionId);

        NameExtract retrievedNameExtract = nameExtractRepository.getBySubmissionId(submissionId).get();

        assertThat(nameExtract).isEqualTo(savedNameExtract);
        assertThat(nameExtract).isEqualTo(retrievedNameExtract);
    }


    @Test
    public void shouldFindByIdShouldReturnEmptyWhenNotFound() {
        String TEST_SUBMISSION_ID_NOT_EXISTS = UUID.randomUUID().toString();

        Optional<NameExtract> result = nameExtractRepository.getBySubmissionId(TEST_SUBMISSION_ID_NOT_EXISTS);
        assertThat(result.isPresent()).isFalse();

    }

    @Test
    public void shouldUpdate() {

        NameExtract nameExtract = generateTestNameExtract("TestFamilyName", "TestGivenName", submissionId);
        nameExtractRepository.save(nameExtract);

        NameExtract originalNameExtract = nameExtractRepository.getBySubmissionId(submissionId).get();

        nameExtract.setClientNameOnForm(
            ClientName.builder()
            .familyName("UpdatedFamilyName")
            .givenName("UpdatedGivenName")
            .build()
        );
        nameExtract.setClientNameOnG28(
            ClientName.builder()
            .familyName("UpdatedFamilyName")
            .givenName("UpdatedGivenName")
            .build()
        );
        nameExtractRepository.update(nameExtract);

        NameExtract updatedNameExtract = nameExtractRepository.getBySubmissionId(submissionId).get();

        assertThat(updatedNameExtract).isNotEqualTo(originalNameExtract);
        assertThat(updatedNameExtract).isEqualTo(nameExtract);

        assertThat(count()).isEqualTo(1);
        checkRawClientGetItem(submissionId);

    }

    @Test
    public void shouldDeleteById() {
        NameExtract nameExtract = generateTestNameExtract("TestFamilyName", "TestGivenName", submissionId);
        nameExtractRepository.save(nameExtract);

        nameExtractRepository.deleteBySubmissionId(submissionId);

        Optional<NameExtract> nameExtractResult = nameExtractRepository.getBySubmissionId(submissionId);

        assertThat(nameExtractResult).isEmpty();
    }

    @Test
    public void save_shouldSaveAndLoadBlankNamesSuccessfully() {

        String TEST_SUBMISSION_ID = UUID.randomUUID().toString();
        String TEST_GIVEN_NAME_BLANK = null;
        String TEST_FAMILY_NAME_BLANK = null;

        NameExtract blankNameExtract = generateTestNameExtract(TEST_FAMILY_NAME_BLANK, TEST_GIVEN_NAME_BLANK, TEST_SUBMISSION_ID);
        NameExtract savedNameExtract = nameExtractRepository.save(blankNameExtract);

        assertEquals(1, count());
        checkRawClientGetItem(TEST_SUBMISSION_ID);

        NameExtract fetchedNameExtract = nameExtractRepository.getBySubmissionId(TEST_SUBMISSION_ID).get();

        assertThat(blankNameExtract).isEqualTo((savedNameExtract));
        assertThat(blankNameExtract).isEqualTo((fetchedNameExtract));

        assertNotNull(fetchedNameExtract.getClientNameOnForm());
        assertNotNull(fetchedNameExtract.getClientNameOnG28());

    }


}
