package gov.dhs.uscis.submissionservice.validators;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import jakarta.validation.ConstraintValidatorContext;

@ExtendWith(MockitoExtension.class)
public class FinalSubmissionStatusValidatorTest {
    @Mock
    IsDraft constraintAnnotation;

    @Mock
    private ConstraintValidatorContext constraintValidatorContext;

    @Test
    public void shouldFailWhenStatusIsNotDraft() {

        IsDraftValidator FinalSubmissionStatusValidator = new IsDraftValidator();
        FinalSubmissionStatusValidator.initialize(constraintAnnotation);

        boolean result = FinalSubmissionStatusValidator.isValid(SubmissionState.RECEIVED, constraintValidatorContext);
        assertFalse(result);
    }

    @Test
    public void shouldPassWhenStatusIsDraft() {

        IsDraftValidator FinalSubmissionStatusValidator = new IsDraftValidator();
        FinalSubmissionStatusValidator.initialize(constraintAnnotation);

        boolean result = FinalSubmissionStatusValidator.isValid(SubmissionState.DRAFT, constraintValidatorContext);
        assertTrue(result);
    }

}
