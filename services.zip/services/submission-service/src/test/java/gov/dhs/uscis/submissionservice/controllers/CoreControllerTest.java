package gov.dhs.uscis.submissionservice.controllers;

import static org.mockito.Mockito.when;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.models.core.metadata.BetaBanner;
import gov.dhs.uscis.intake.models.dto.CoreData;
import gov.dhs.uscis.submissionservice.configs.ObjectMapperConfiguration;
import gov.dhs.uscis.submissionservice.converters.SubmissionParameterConverter;
import gov.dhs.uscis.submissionservice.services.CoreService;
import gov.dhs.uscis.submissionservice.services.SubmissionService;

@WebMvcTest(CoreController.class)
@Import(ObjectMapperConfiguration.class)
@ExtendWith({ RestDocumentationExtension.class })
public class CoreControllerTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @MockitoBean
    private CoreService coreService;
    @MockitoBean
    private SubmissionService submissionService;
    @MockitoBean
    SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;

    @BeforeEach
    void setUp(RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders
                .webAppContextSetup(this.webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)).build();
    }

    @Test
    void shouldRetrieveFormMetadataWhenFound() throws Exception {
        BetaBanner banner = BetaBanner.builder().bannerText("test banner").showBanner(false).showBannerFor(AccountType.REPRESENTATIVE).build();
        CoreData expectedCoreData = CoreData.builder()
                .paygovMaintenanceEnabled(true)
                .betaBanners(List.of(banner))
                .build();
        when(coreService.getCoreMetaData()).thenReturn(expectedCoreData);

        ResultActions actions = this.mockMvc.perform(get("/api/v1/metadata/core")
                .contentType(MediaType.APPLICATION_JSON));

        actions
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.paygovMaintenanceEnabled").value(true))
                .andExpect(jsonPath("$.betaBanners").isNotEmpty());
    }
}
