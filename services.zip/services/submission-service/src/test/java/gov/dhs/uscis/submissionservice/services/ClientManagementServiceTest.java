
package gov.dhs.uscis.submissionservice.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.util.ReflectionTestUtils;

import gov.dhs.uscis.intake.clients.UserGroupServiceClient;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.core.ClientAssociation;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;
import gov.dhs.uscis.submissionservice.controllers.AddClientRequestDetails;
import gov.dhs.uscis.submissionservice.exception.AddClientValidationException;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AccountTypeResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.ApplicantUuidResponse;
import gov.dhs.uscis.submissionservice.repository.ClientInformationRepository;

public class ClientManagementServiceTest {

    private static final String CLIENT_USER_GROUP_ID = "clientUserGroupId";
    private static final String CLIENT_ID = "clientId";
    private static final String ATTORNEY_ID = "attorneyId";
    private static final String ATTORNEY_USER_GROUP_ID = "attorneyUserGroupId";
    private static final String SUBMISSION_ID = "submissionId";

    private ClientInformationRepository repository = mock(ClientInformationRepository.class);
    private UserGroupServiceClient userGroupServiceClient = mock(UserGroupServiceClient.class);
    private PeepsService peepsService = mock(PeepsService.class);
    private DraftBenefitsService draftBenefitsService = mock(DraftBenefitsService.class);
    private ClientManagementService service = new ClientManagementService(userGroupServiceClient, peepsService,
            draftBenefitsService, repository);

    private static Submission createTestSubmission(FormType formType) {
        return Submission.builder()
                .submissionId(SUBMISSION_ID)
                .formType(formType)
                .build();
    }

    @Test
    public void shouldThrowExceptionIfRepUsesTheirOwnEmail() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(false);
        AddClientValidationException exception = assertThrows(AddClientValidationException.class,
                () -> service.addClient(ATTORNEY_ID, createTestSubmission(FormType.I765), requestDetails));

        assertThat(exception.getMessage()).isEqualTo(ClientManagementService.REP_EMAIL_ERROR);
    }

    @Test
    public void shouldInviteClientIfNoAccountIsFoundForEmail_ClientInformationExists() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);
        String emailAddress = requestDetails.emailAddress();
        Name name = requestDetails.name();

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(true);
        when(peepsService.retrieveApplicantId(requestDetails.emailAddress())).thenReturn(null);
        when(repository.findBySubmissionId(SUBMISSION_ID))
                .thenReturn(ClientInformation.builder().userGroupIds(List.of(ATTORNEY_USER_GROUP_ID)).build());
        List<String> clientInformationUserGroupIds = List.of(ATTORNEY_USER_GROUP_ID, CLIENT_USER_GROUP_ID);
        when(userGroupServiceClient.inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID, emailAddress,
                requestDetails.name()))
                .thenReturn(ClientInformation.builder().clientId(CLIENT_ID).userGroupIds(clientInformationUserGroupIds)
                        .build());

        service.addClient(ATTORNEY_ID, createTestSubmission(FormType.I765), requestDetails);

        verify(userGroupServiceClient, times(1)).inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID,
                emailAddress, name);
        verify(repository, times(1)).save(ATTORNEY_ID, CLIENT_ID, SUBMISSION_ID, name, clientInformationUserGroupIds);
    }

    @Test
    public void shouldInviteClientIfNoAccountIsFoundForEmail_ClientInformationDoesNotExist() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);
        String emailAddress = requestDetails.emailAddress();
        Name name = requestDetails.name();

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(true);
        when(peepsService.retrieveApplicantId(requestDetails.emailAddress())).thenReturn(null);
        when(repository.findBySubmissionId(SUBMISSION_ID)).thenReturn(null);
        when(userGroupServiceClient.getRepGroupId(ATTORNEY_ID))
                .thenReturn(UserGroupRole.builder().userGroupId(ATTORNEY_USER_GROUP_ID).build());
        List<String> clientInformationUserGroupIds = List.of(ATTORNEY_USER_GROUP_ID, CLIENT_USER_GROUP_ID);
        when(userGroupServiceClient.inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID, emailAddress,
                requestDetails.name()))
                .thenReturn(ClientInformation.builder().clientId(CLIENT_ID).userGroupIds(clientInformationUserGroupIds)
                        .build());

        service.addClient(ATTORNEY_ID, createTestSubmission(FormType.I765), requestDetails);

        verify(userGroupServiceClient, times(1)).inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID,
                emailAddress, name);
        verify(repository, times(1)).save(ATTORNEY_ID, CLIENT_ID, SUBMISSION_ID, name, clientInformationUserGroupIds);
    }

    @Test
    public void shouldInviteClientIfNoAccountIsFoundForEmail_ClientInformationDoesNotExist_N400() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);
        String emailAddress = requestDetails.emailAddress();
        Name name = requestDetails.name();

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(true);
        when(peepsService.retrieveApplicantId(requestDetails.emailAddress())).thenReturn(null);
        when(repository.findBySubmissionId(SUBMISSION_ID)).thenReturn(null);
        when(userGroupServiceClient.getRepGroupId(ATTORNEY_ID))
                .thenReturn(UserGroupRole.builder().userGroupId(ATTORNEY_USER_GROUP_ID).build());
        List<String> clientInformationUserGroupIds = List.of(ATTORNEY_USER_GROUP_ID, CLIENT_USER_GROUP_ID);
        when(userGroupServiceClient.inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID, emailAddress,
                requestDetails.name()))
                .thenReturn(ClientInformation.builder().clientId(CLIENT_ID).userGroupIds(clientInformationUserGroupIds)
                        .build());

        service.addClient(ATTORNEY_ID, createTestSubmission(FormType.N400), requestDetails);

        verify(userGroupServiceClient, times(1)).inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID,
                emailAddress, name);
        verify(repository, times(1)).save(ATTORNEY_ID, CLIENT_ID, SUBMISSION_ID, name, clientInformationUserGroupIds);
    }

    @Test
    public void shouldThrowExceptionIfRepUserGroupIdCannotBeFound() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(true);
        when(peepsService.retrieveApplicantId(requestDetails.emailAddress())).thenReturn(null);
        when(repository.findBySubmissionId(SUBMISSION_ID)).thenReturn(null);
        when(userGroupServiceClient.getRepGroupId(ATTORNEY_ID)).thenReturn(null);

        AddClientValidationException exception = assertThrows(AddClientValidationException.class,
                () -> service.addClient(ATTORNEY_ID, createTestSubmission(FormType.I765), requestDetails));

        assertThat(exception.getMessage()).isEqualTo(ClientManagementService.REP_USERGROUP_ID_NOT_FOUND_ERROR);
    }

    @Test
    public void shouldThrowExceptionIfClientAlreadyHasN400Application() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);
        String applicantId = UUID.randomUUID().toString();
        String emailAddress = requestDetails.emailAddress();

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(true);
        when(peepsService.retrieveApplicantId(requestDetails.emailAddress()))
                .thenReturn(ApplicantUuidResponse.builder().applicantUUID(applicantId).build());
        when(repository.findBySubmissionId(SUBMISSION_ID)).thenReturn(null);
        when(userGroupServiceClient.getRepGroupId(ATTORNEY_ID))
                .thenReturn(UserGroupRole.builder().userGroupId(ATTORNEY_USER_GROUP_ID).build());
        when(draftBenefitsService.canApplicantFileFor(FormType.N400.getType(), applicantId)).thenReturn(false);

        AddClientValidationException exception = assertThrows(AddClientValidationException.class,
                () -> service.addClient(ATTORNEY_ID, createTestSubmission(FormType.N400), requestDetails));

        assertThat(exception.getMessage()).isEqualTo(
                "A N-400 form that is currently in a draft or pending decision status already exists for this client. A new submission cannot be performed at this time.");
        verify(repository, never()).save(any(), any(), any(), any(), any());
    }

    @Test
    public void shouldThrowExceptionIfClientIsAlreadyAssociatedWithRep() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);
        String applicantId = UUID.randomUUID().toString();

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(true);
        when(peepsService.retrieveApplicantId(requestDetails.emailAddress()))
                .thenReturn(ApplicantUuidResponse.builder().applicantUUID(applicantId).build());
        when(repository.findBySubmissionId(SUBMISSION_ID))
                .thenReturn(ClientInformation.builder().userGroupIds(List.of(ATTORNEY_USER_GROUP_ID)).build());
        when(userGroupServiceClient.isClientAssociated(ATTORNEY_ID, applicantId))
                .thenReturn(new ClientAssociation(true, ""));

        AddClientValidationException exception = assertThrows(AddClientValidationException.class,
                () -> service.addClient(ATTORNEY_ID, createTestSubmission(FormType.I765), requestDetails));

        assertThat(exception.getMessage()).isEqualTo(ClientManagementService.CLIENT_ALREADY_ASSOCIATED_ERROR);
        verify(repository, never()).save(any(), any(), any(), any(), any());
    }

    @Test
    public void shouldThrowExceptionIfClientHasAReceiptProfileAndDoesNotMatchRequest() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);
        String applicantId = UUID.randomUUID().toString();

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(true);
        when(peepsService.retrieveApplicantId(requestDetails.emailAddress()))
                .thenReturn(ApplicantUuidResponse.builder().applicantUUID(applicantId).build());
        when(repository.findBySubmissionId(SUBMISSION_ID))
                .thenReturn(ClientInformation.builder().userGroupIds(List.of(ATTORNEY_USER_GROUP_ID)).build());
        when(userGroupServiceClient.isClientAssociated(ATTORNEY_ID, applicantId))
                .thenReturn(new ClientAssociation(false, ""));
        when(peepsService.verifyClientInformation(applicantId, requestDetails.name(), requestDetails.dateOfBirth(),
                requestDetails.aNumber())).thenReturn(false);

        AddClientValidationException exception = assertThrows(AddClientValidationException.class,
                () -> service.addClient(ATTORNEY_ID, createTestSubmission(FormType.I765), requestDetails));

        assertThat(exception.getMessage()).isEqualTo(ClientManagementService.CLIENT_INFORMATION_DOES_NOT_MATCH_ERROR);
        verify(repository, never()).save(any(), any(), any(), any(), any());
    }

    @Test
    public void shouldInviteClientThatCanFileForN400Form() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);
        String emailAddress = requestDetails.emailAddress();
        Name name = requestDetails.name();
        String applicantId = UUID.randomUUID().toString();
        FormType n400FormType = FormType.N400;

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(true);
        when(peepsService.retrieveApplicantId(requestDetails.emailAddress()))
                .thenReturn(ApplicantUuidResponse.builder().applicantUUID(applicantId).build());
        when(repository.findBySubmissionId(SUBMISSION_ID)).thenReturn(null);
        when(userGroupServiceClient.getRepGroupId(ATTORNEY_ID))
                .thenReturn(UserGroupRole.builder().userGroupId(ATTORNEY_USER_GROUP_ID).build());
        when(draftBenefitsService.canApplicantFileFor(n400FormType.getType(), applicantId)).thenReturn(true);
        when(userGroupServiceClient.isClientAssociated(any(), any())).thenReturn(new ClientAssociation(false, "foo"));
        when(peepsService.verifyClientInformation(applicantId, requestDetails.name(), requestDetails.dateOfBirth(),
                requestDetails.aNumber())).thenReturn(true);
        List<String> clientInformationUserGroupIds = List.of(ATTORNEY_USER_GROUP_ID, CLIENT_USER_GROUP_ID);
        when(userGroupServiceClient.inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID, emailAddress,
                requestDetails.name()))
                .thenReturn(ClientInformation.builder().clientId(CLIENT_ID).userGroupIds(clientInformationUserGroupIds)
                        .build());

        service.addClient(ATTORNEY_ID, createTestSubmission(n400FormType), requestDetails);

        verify(userGroupServiceClient, times(1)).inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID,
                emailAddress, name);
        verify(repository, times(1)).save(ATTORNEY_ID, applicantId, SUBMISSION_ID, name, clientInformationUserGroupIds);
    }

    @Test
    public void shouldInviteClientIfClientHasAReceiptProfileAndMatchesRequest() {
        AddClientRequestDetails requestDetails = Instancio.create(AddClientRequestDetails.class);
        String emailAddress = requestDetails.emailAddress();
        Name name = requestDetails.name();
        String applicantId = UUID.randomUUID().toString();

        when(peepsService.validateClientEmailIsNotAttorneyEmail(ATTORNEY_ID, requestDetails.emailAddress()))
                .thenReturn(true);
        when(peepsService.retrieveApplicantId(requestDetails.emailAddress()))
                .thenReturn(ApplicantUuidResponse.builder().applicantUUID(applicantId).build());
        when(repository.findBySubmissionId(SUBMISSION_ID)).thenReturn(null);
        when(userGroupServiceClient.getRepGroupId(ATTORNEY_ID))
                .thenReturn(UserGroupRole.builder().userGroupId(ATTORNEY_USER_GROUP_ID).build());
        when(userGroupServiceClient.isClientAssociated(any(), any())).thenReturn(new ClientAssociation(false, "foo"));
        when(peepsService.verifyClientInformation(applicantId, requestDetails.name(), requestDetails.dateOfBirth(),
                requestDetails.aNumber())).thenReturn(true);
        List<String> clientInformationUserGroupIds = List.of(ATTORNEY_USER_GROUP_ID, CLIENT_USER_GROUP_ID);
        when(userGroupServiceClient.inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID, emailAddress,
                requestDetails.name()))
                .thenReturn(ClientInformation.builder().clientId(CLIENT_ID).userGroupIds(clientInformationUserGroupIds)
                        .build());

        service.addClient(ATTORNEY_ID, createTestSubmission(FormType.I765), requestDetails);

        verify(userGroupServiceClient, times(1)).inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID, SUBMISSION_ID,
                emailAddress, name);
        verify(repository, times(1)).save(ATTORNEY_ID, applicantId, SUBMISSION_ID, name, clientInformationUserGroupIds);
    }

    // @Test
    // public void shouldThrowExceptionIfClientAlreadyExists() {
    // when(peepsService.validateClientEmail(any(), any())).thenReturn(true);
    // when(repository.findBySubmissionId(SUBMISSION_ID))
    // .thenReturn(ClientInformation.builder().userGroupIds(List.of(UUID.randomUUID().toString())).build());
    // when(userGroupServiceClient.isClientAssociated(any(),
    // any())).thenReturn(true);
    // when(peepsService.retrieveApplicantId(any()))
    // .thenReturn(new ApplicantUuidResponse(UUID.randomUUID().toString()));
    // when(peepsService.verifyClientInformation(anyString(), any(), any(),
    // any())).thenReturn(true);

    // assertThrows(AddClientValidationException.class,
    // () -> service.addClient(ATTORNEY_ID, SUBMISSION_ID,
    // mock(AddClientRequestDetails.class)));

    // verify(repository, never()).save(any(), any(), any(), any());
    // }

    // @Test
    // public void shouldBeAbleToAddClient() {
    // var name = new Name(FIRST_NAME, MIDDLE_NAME, LAST_NAME);
    // when(peepsService.validateClientEmail(any(), any())).thenReturn(true);
    // when(userGroupServiceClient.isClientAssociated(any(),
    // any())).thenReturn(false);
    // when(userGroupServiceClient.getRepGroupId(any()))
    // .thenReturn(UserGroupRole.builder().userGroupId(ATTORNEY_USER_GROUP_ID).build());
    // when(peepsService.retrieveApplicantId(any()))
    // .thenReturn(new ApplicantUuidResponse(UUID.randomUUID().toString()));
    // when(peepsService.verifyClientInformation(any(), any(), any(),
    // any())).thenReturn(true);
    // when(userGroupServiceClient.inviteClient(ATTORNEY_ID, ATTORNEY_USER_GROUP_ID,
    // SUBMISSION_ID, EMAIL, name))
    // .thenReturn(ClientInformation.builder().clientId(CLIENT_ID).build());
    // service.addClient(ATTORNEY_ID, SUBMISSION_ID,
    // new AddClientRequestDetails(EMAIL, name, A_NUMBER, DATE_OF_BIRTH));

    // verify(repository, times(1)).save(ATTORNEY_ID, CLIENT_ID, SUBMISSION_ID,
    // name);
    // }

    // @Test
    // public void errorAddingClient() {
    // var name = new Name(FIRST_NAME, MIDDLE_NAME, LAST_NAME);
    // when(peepsService.validateClientEmail(any(), any())).thenReturn(true);
    // when(userGroupServiceClient.isClientAssociated(any(),
    // any())).thenReturn(false);
    // when(peepsService.retrieveApplicantId(any()))
    // .thenReturn(new ApplicantUuidResponse(UUID.randomUUID().toString()));
    // when(peepsService.verifyClientInformation(any(), any(), any(),
    // any())).thenReturn(false);
    // assertThrows(AddClientValidationException.class,
    // () -> service.addClient(ATTORNEY_ID, SUBMISSION_ID,
    // mock(AddClientRequestDetails.class)));

    // when(userGroupServiceClient.isClientAssociated(any(),
    // any())).thenReturn(true);
    // assertThrows(AddClientValidationException.class,
    // () -> service.addClient(ATTORNEY_ID, SUBMISSION_ID,
    // mock(AddClientRequestDetails.class)));

    // verify(repository, times(0)).save(ATTORNEY_ID, CLIENT_ID, SUBMISSION_ID,
    // name);
    // }

    // @Test
    // public void shouldNotSendAnInvitationIfClientAlreadyExistsForTheAttorney() {
    // var name = new Name(FIRST_NAME, MIDDLE_NAME, LAST_NAME);
    // when(peepsService.validateClientEmail(any(), any())).thenReturn(true);
    // when(peepsService.retrieveApplicantId(any()))
    // .thenReturn(new ApplicantUuidResponse(UUID.randomUUID().toString()));
    // when(userGroupServiceClient.isClientAssociated(any(),
    // any())).thenReturn(true);
    // when(userGroupServiceClient.getRepGroupId(any()))
    // .thenReturn(UserGroupRole.builder().userGroupId(ATTORNEY_USER_GROUP_ID).build());

    // when(peepsService.verifyClientInformation(any(), any(), any(),
    // any())).thenReturn(true);

    // assertThrows(AddClientValidationException.class, () ->
    // service.addClient(ATTORNEY_ID, SUBMISSION_ID,
    // new AddClientRequestDetails(CLIENT_ID, name, A_NUMBER, DATE_OF_BIRTH)));

    // }
}
