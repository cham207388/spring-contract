package gov.dhs.uscis.submissionservice.controllers;

import static gov.dhs.uscis.intake.entities.submission.SubmissionState.ACCEPTED;
import static gov.dhs.uscis.intake.entities.submission.SubmissionState.REJECTED;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.PASS;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.CORE;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.ELIGIBILITY_CATEGORY;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.SIGNATURE;
import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;

import gov.dhs.uscis.intake.constants.DocumentType;
import gov.dhs.uscis.intake.constants.S3Constants;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.FormTypeDescription;
import gov.dhs.uscis.intake.enums.I131EligibilityCategory;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.N400EligibilityCategory;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import gov.dhs.uscis.intake.enums.ResidencyStatus;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.enums.eligibility.I751WaiverOrIndividualFilingSubcategory;
import gov.dhs.uscis.intake.models.EntityType;
import gov.dhs.uscis.intake.models.EsignData;
import gov.dhs.uscis.intake.models.EsignRequest;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.EvidenceType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest.SubmissionUpdate;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.intake.models.dto.SubmissionDto;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I751FormSpecificInfo;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;
import gov.dhs.uscis.intake.models.validation.Validation;
import gov.dhs.uscis.intake.models.validation.ValidationDetails;
import gov.dhs.uscis.intake.models.validation.ValidationStatusEnum;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResponse;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.SubmissionFactory;
import gov.dhs.uscis.submissionservice.converters.SubmissionParameterConverter;
import gov.dhs.uscis.submissionservice.exception.S3DeleteObjectException;
import gov.dhs.uscis.submissionservice.exception.SubmissionBadException;
import gov.dhs.uscis.submissionservice.models.UpdateFeeWaiverEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UpdateFormTypeRequest;
import gov.dhs.uscis.submissionservice.models.dto.AttestFormRequest;
import gov.dhs.uscis.submissionservice.models.dto.EligibilitySubcategoriesUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.EligibilityUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.FeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import gov.dhs.uscis.submissionservice.models.dto.HasReviewedSignatureUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.ImmviUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.PartialFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.dto.ReasonForFilingUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.SubmissionMapper;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AddClientRequest;
import gov.dhs.uscis.submissionservice.models.submissionStatus.ErrorGroup;
import gov.dhs.uscis.submissionservice.models.submissionStatus.SubmissionStatusResponse;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.services.PeepsService;
import gov.dhs.uscis.submissionservice.services.S3Service;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ValidationService;
import jakarta.validation.Validator;
import reactor.core.publisher.Mono;

@WebMvcTest(SubmissionController.class)
@AutoConfigureMockMvc
public class SubmissionControllerTest {

    private static final String MYUSCIS_ID = UUID.randomUUID().toString();
    private static final String ORG_MYUSCIS_ID = UUID.randomUUID().toString();
    private static final String SUBMISSION_ID = UUID.randomUUID().toString();
    private static final String MANIFEST_ID = UUID.randomUUID().toString();
    private static final String FORM_ID = UUID.randomUUID().toString();

    @MockitoBean(name = "lockboxWebClient")
    WebClient lockboxWebClient;

    @MockitoBean
    FormService service;

    @MockitoBean
    private S3Service s3service;

    @MockitoBean
    private SubmissionService submissionService;

    @MockitoBean
    private ValidationService validationService;

    @MockitoBean
    SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;

    @MockitoBean
    AuditService auditService;

    @MockitoBean
    PeepsService peepsService;

    @Autowired
    Validator validator;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private MockMvc mockMvc;

    private SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
            .updateType(EntityType.MANIFEST)
            .submissionUpdate(SubmissionUpdate.builder()
                    .lockboxId("54321")
                    .status(StatusEnum.ACCEPTED)
                    .totalCost(BigDecimal.valueOf(500))
                    .applicationStatuses(List.of(ApplicationStatus.builder()
                            .uscisId("applicationStatusId1")
                            .formType("I-765")
                            .status(StatusEnum.ACCEPTED)
                            .rejectionReasons(
                                    List.of(RejectionReason.builder().code("911").reason("Rejected").build()))
                            .build()))
                    .build())
            .manifestUpdate(SubmissionUpdateRequest.ManifestUpdate.builder()
                    .status(StatusEnum.COMPLETE)
                    .lockboxId("12345")
                    .errors(List.of(ManifestError.builder()
                            .id("98765")
                            .errorCode("E1")
                            .description("Manifest produced an error")
                            .build()))
                    .build())
            .build();

    @Test
    void ContextLoad() {
    }

    @Test
    void shouldRetrieveSubmissionIdWhenInitiallyCreateASubmission_I765() throws Exception {
        SubmissionRequest expected = SubmissionRequest.builder()
                .formType(FormType.I765)
                .formDescription(FormTypeDescription.I765.getDescription())
                .eligibilityCategory(I765EligibilityCategory.A12.getCategory())
                .accountType(AccountType.APPLICANT)
                .clientInformation(Optional.empty())
                .build();

        Submission submission = Instancio.create(Submission.class);
        when(submissionService.createInitialSubmission(MYUSCIS_ID, expected)).thenReturn(submission);

        this.mockMvc.perform(post("/api/v1/{myUscisId}/submissions/", MYUSCIS_ID)
                .with(jwt())
                .contentType(APPLICATION_JSON)
                .content(this.mapper.writeValueAsString(expected)))
                .andExpect(status().isOk())
                .andExpect(content().string(mapper.writeValueAsString(SubmissionMapper.toSubmissionDTO(submission))));
    }

    @Test
    void shouldRetrieveSubmissionIdWhenInitiallyCreateASubmission_N400() throws Exception {
        SubmissionRequest expected = SubmissionRequest.builder()
                .formType(FormType.N400)
                .formDescription(FormTypeDescription.N400.getDescription())
                .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION.getCategory())
                .accountType(AccountType.APPLICANT)
                .clientInformation(Optional.empty())
                .build();

        Submission submission = Instancio.create(Submission.class);
        when(submissionService.createInitialSubmission(MYUSCIS_ID, expected)).thenReturn(submission);

        this.mockMvc.perform(post("/api/v1/{myUscisId}/submissions/", MYUSCIS_ID)
                .with(jwt())
                .contentType(APPLICATION_JSON)
                .content(this.mapper.writeValueAsString(expected)))
                .andExpect(status().isOk())
                .andExpect(content().string(mapper.writeValueAsString(SubmissionMapper.toSubmissionDTO(submission))));
    }

    @Test
    void shouldRetrieveSubmissionByIdWhenFound() throws Exception {
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);

        SubmissionDto expected = SubmissionMapper.toSubmissionDTO(submission);
        expected = mapper.readValue(mapper.writeValueAsString(expected), SubmissionDto.class);

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(submission);
        when(submissionService.updateDraftSubmissionLock(any(Submission.class))).thenReturn(submission);

        ResultActions actions = mockMvc
                .perform(get("/api/v1/{myUscisId}/submissions/{submissionId}?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt()));
        SubmissionDto actual = mapper.readValue(actions.andReturn().getResponse().getContentAsString(),
                SubmissionDto.class);

        assertEquals(expected, actual);

        actions.andExpect(status().isOk())
                .andExpect(jsonPath("$.forms[0].url").doesNotExist())
                .andExpect(jsonPath("$.evidences[0].url").doesNotExist())
                .andExpect(jsonPath("$.feeWaiver.url").doesNotExist());
    }

    @Test
    void shouldRetrieveListOfSubmissionsDraftsById() throws Exception {
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        List<Submission> submissionList = List.of(submission);

        List<SubmissionDto> expected = List
                .of(SubmissionMapper.toSubmissionDTO(submission));
        expected = mapper.readValue(mapper.writeValueAsString(expected),
                new TypeReference<List<SubmissionDto>>() {
                });

        var myUscisId = "some-myuscis-id";
        when(submissionService.retrieveDraftSubmissions(myUscisId)).thenReturn(submissionList);

        ResultActions actions = mockMvc.perform(get("/api/v1/{myUscisId}/submissions/drafts", myUscisId)
                .with(jwt()));
        List<SubmissionDto> actual = mapper.readValue(actions.andReturn().getResponse().getContentAsString(),
                new TypeReference<List<SubmissionDto>>() {
                });

        assertEquals(expected, actual);

        actions.andExpect(status().isOk())
                .andExpect(jsonPath("$.forms[0].url").doesNotExist())
                .andExpect(jsonPath("$.evidences[0].url").doesNotExist())
                .andExpect(jsonPath("$.feeWaiver.url").doesNotExist());
    }

    @Test
    void shouldRetrieveEmptyListForSubmissionsDraftsById() throws Exception {
        List<Submission> expected = List.of();

        List<SubmissionDto> mockSubmissionDtoList = List.of();

        var myUscisId = "some-myuscis-id";
        when(submissionService.retrieveDraftSubmissions(myUscisId)).thenReturn(expected);

        ResultActions actions = this.mockMvc.perform(get("/api/v1/{myUscisId}/submissions/drafts", myUscisId)
                .with(jwt()));
        List<SubmissionDto> actual = this.mapper.readValue(actions.andReturn().getResponse().getContentAsString(),
                new TypeReference<List<SubmissionDto>>() {
                });

        assertEquals(mockSubmissionDtoList, actual);

        actions.andExpect(status().isOk())
                .andExpect(content().string("[]"));
    }

    @Test
    public void shouldCallServiceWithApplicantUUIDThrowException() throws Exception {

        this.mockMvc.perform(get("/api/v1/{myUscisId}/submissions/applicant?filters=REJECTED,ACCEPTED", MYUSCIS_ID)
                .with(jwt()))
                .andExpect(status().isNotFound());

    }

    @Test
    void shouldReturnNotFoundWithInvalidId() throws Exception {
        this.mockMvc.perform(get("/api/v1/{myUscisId}/submissions/{submissionId}", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                .with(jwt()))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldReturnSuccessfulUpdateForSubmissionStatus() throws Exception {
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);

        when(submissionService.updateSubmissionWithLockBoxStatus(anyString(), any(SubmissionUpdateRequest.class)))
                .thenReturn(submission);

        this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/lockbox-status", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(request)))
                .andExpect(status().isOk());

    }

    @Test
    void shouldReturnBadRequestWhenUpdateForSubmissionStatusFails() throws Exception {
        String expectedBody = "Encountered an error updating Submission with ID " + SUBMISSION_ID + ".";
        when(submissionService.updateSubmissionWithLockBoxStatus(anyString(), any(SubmissionUpdateRequest.class)))
                .thenReturn(null);

        this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/lockbox-status?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(expectedBody));
    }

    @Test
    public void submitSubmissionReturns200() throws Exception {
        final RequestBodyUriSpec requestBodyUriSpec = mock(RequestBodyUriSpec.class);
        final RequestHeadersSpec<?> requestHeadersSpec = mock(RequestHeadersSpec.class);
        final RequestBodySpec requestBodySpec = mock(RequestBodySpec.class);
        final ResponseSpec responseSpecMock = mock(ResponseSpec.class);
        FinalSubmissionDto finalSubmissionDto = FinalSubmissionDto.builder().attested(true)
                .type(FormType.I765)
                .category(I765EligibilityCategory.C11PAROLE)
                .submissionId(SUBMISSION_ID).userRequestedFeeWaiver(false)
                .status(SubmissionState.DRAFT)
                .forms(List.of(SubmissionForm.builder().build()))
                .evidences(List.of(SubmissionEvidence.builder().type("Passport").build()))
                .attested(true)
                .hasReviewedSignature(true)
                .signature("some signature")
                .validations(List.of(new ValidationDetails(CORE, PASS, null, null),
                        new ValidationDetails(SIGNATURE, PASS, null, null),
                        new ValidationDetails(ELIGIBILITY_CATEGORY, PASS, null, null)))
                .build();

        var map = new HashMap<String, String>();
        map.put("manifestId", "fakeManifestId");

        LockboxTransmission lockboxTransmission = Instancio.create(LockboxTransmission.class);
        when(submissionService.completeSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(Mono.just("manifestId"));
        when(submissionIdToFinalSubmissionDtoConverter.convert(SUBMISSION_ID)).thenReturn(finalSubmissionDto);
        when(lockboxWebClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("/api/v1/manifest")).thenReturn(requestBodySpec);
        doReturn(requestHeadersSpec).when(requestBodySpec).bodyValue(lockboxTransmission);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpecMock);
        when(responseSpecMock.onStatus(any(), any())).thenReturn(responseSpecMock);
        when(responseSpecMock.bodyToMono(Map.class)).thenReturn(Mono.just(map));
        when(service.retrieveEvidenceGroups(any(), any()))
                .thenReturn(List
                        .of(EvidenceGroup.builder()
                                .evidenceTypes(List.of(EvidenceType.builder().id("Passport").build())).build()));

        this.mockMvc.perform(post("/api/v1/{myUscisId}/submissions/{submissionId}?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                .with(jwt()))
                .andExpect(status().isOk());
    }

    @Test
    void shouldReturnValidationStatus() throws Exception {
        FinalSubmissionDto finalSubmissionDto = FinalSubmissionDto.builder().attested(true)
                .type(FormType.I131)
                .category(I131EligibilityCategory.TPS_BENEFICIARY)
                .submissionId(SUBMISSION_ID).userRequestedFeeWaiver(false)
                .status(SubmissionState.DRAFT)
                .forms(List.of(SubmissionForm.builder().build()))
                .evidences(List.of(SubmissionEvidence.builder().type("Passport").build()))
                .attested(true)
                .hasReviewedSignature(true)
                .signature("some signature")
                .validations(List.of(new ValidationDetails(CORE, PASS, null, null),
                        new ValidationDetails(SIGNATURE, PASS, null, null),
                        new ValidationDetails(ELIGIBILITY_CATEGORY, PASS, null, null)))
                .build();

        List<String> expectedResponse = new ArrayList<>();

        when(submissionIdToFinalSubmissionDtoConverter.convert(SUBMISSION_ID)).thenReturn(finalSubmissionDto);
        when(submissionService.getValidationStatus(MYUSCIS_ID, finalSubmissionDto)).thenReturn(expectedResponse);

        this.mockMvc.perform(get("/api/v1/{myUscisId}/submissions/{submissionId}/validations", MYUSCIS_ID, SUBMISSION_ID)
                .with(jwt()))
                .andExpect(status().isOk());
    }

    @Test
    void shouldReturnSubmissionStatus() throws Exception {
        SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                .submissionErrors(List.of("FeeWaiver is missing Name"))
                .formErrors(List.of(
                        ErrorGroup.builder()
                                .type(FormType.I765.getType())
                                .errors(List.of("Form is missing ID"))
                                .build()))
                .evidenceErrors(List.of(ErrorGroup.builder()
                        .type("FeeWaiver")
                        .errors(List.of("Form is missing ID",
                                "FeeWaiver is missing Name"))
                        .build()))
                .build();

        when(submissionService.retrieveSubmissionStatus(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(expected);

        this.mockMvc.perform(get("/api/v1/{myUscisId}/submissions/{submissionId}/status?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                .with(jwt())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void shouldReturnStatusNotFoundWithIncorrectSubmissionId() throws Exception {
        this.mockMvc.perform(get("/api/v1/{myUscisId}/submissions/{submissionId}/status", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                .with(jwt()))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldReturn200OKWhenDeletingAForm() throws Exception {
        var formId = "test.pdf";

        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        SubmissionDto expected = SubmissionMapper.toSubmissionDTO(submission);
        expected = mapper.readValue(mapper.writeValueAsString(expected), SubmissionDto.class);

        when(submissionService.deleteFormFromSubmission(MYUSCIS_ID, null, SUBMISSION_ID, formId)).thenReturn(submission);

        ResultActions actions = this.mockMvc.perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}/forms/{id}?=undefined",
                MYUSCIS_ID, SUBMISSION_ID, formId)
                .with(jwt()));

        SubmissionDto actual = this.mapper.readValue(actions.andReturn().getResponse().getContentAsString(),
                SubmissionDto.class);

        assertEquals(expected, actual);
        actions.andExpect(status().isOk());
    }

    @Test
    void shouldReturnNoContentWhenDeletingThrowsException() throws Exception {
        var formId = "formId";

        when(submissionService.deleteFormFromSubmission(MYUSCIS_ID, null, SUBMISSION_ID, formId))
                .thenThrow(NoSuchElementException.class);

        this.mockMvc
                .perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}/forms/{id}?=undefined", MYUSCIS_ID, SUBMISSION_ID,
                        formId)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void deleteFormByFormId_deleteObjectException() throws Exception {
        var formId = "formId";

        when(submissionService.deleteFormFromSubmission(MYUSCIS_ID, null, SUBMISSION_ID, formId))
                .thenThrow(S3DeleteObjectException.class);

        this.mockMvc
                .perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}/forms/{id}?=undefined", MYUSCIS_ID, SUBMISSION_ID,
                        formId)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
    }

    @Test
    void shouldDeleteEvidenceAndReturnOk() throws Exception {
        String evidenceId = "12345E";
        String s3Key = "evidence.pdf";

        when(submissionService.deleteEvidenceFromSubmission(MYUSCIS_ID, null, SUBMISSION_ID, evidenceId)).thenReturn(s3Key);
        when(s3service.deleteS3Object(evidenceId, true)).thenReturn(S3Constants.DELETION_SUCCESS_MESSAGE);

        this.mockMvc
                .perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}/evidence/{id}?=undefined", MYUSCIS_ID,
                        SUBMISSION_ID,
                        evidenceId)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(validationService, times(1)).deleteStatus(evidenceId);
        verify(auditService, times(1)).addEvent(MYUSCIS_ID, SUBMISSION_ID, ActionPerformed.EVIDENCE_DELETED_WITH_S3,
                s3Key);
    }

    @Test
    void shouldDeleteEvidenceOnlyFromDraftSubmissionAndReturnOk() throws Exception {
        String evidenceId = "12345E";

        when(submissionService.deleteEvidenceFromSubmission(MYUSCIS_ID, null, SUBMISSION_ID, evidenceId)).thenReturn(null);

        SubmissionService submissionService = mock(SubmissionService.class);
        S3Service s3Service = mock(S3Service.class);
        ValidationService validationService = mock(ValidationService.class);
        AuditService auditService = mock(AuditService.class);
        var mockController = MockMvcBuilders
                .standaloneSetup(
                        new SubmissionController(submissionService, s3Service, validationService, auditService,
                                peepsService, validator))
                .build();

        mockController
                .perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}/evidence/{id}?=undefined", MYUSCIS_ID,
                        SUBMISSION_ID,
                        evidenceId)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verifyNoInteractions(s3service);
        verify(auditService, times(1)).addEvent(MYUSCIS_ID, SUBMISSION_ID, ActionPerformed.EVIDENCE_DELETED_WITHOUT_S3,
                evidenceId);
    }

    @Test
    void shouldReturnInternalServerErrorWhenErrorsOccurs() throws Exception {
        String evidenceId = "12345E";
        String evidenceFileName = "evidence.pdf";

        when(submissionService.deleteEvidenceFromSubmission(MYUSCIS_ID, null, SUBMISSION_ID, evidenceId))
                .thenReturn(evidenceFileName);
        when(s3service.deleteS3Object(evidenceFileName, true)).thenThrow(S3DeleteObjectException.class);

        this.mockMvc
                .perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}/evidence/{id}?=undefined", MYUSCIS_ID,
                        SUBMISSION_ID,
                        evidenceId)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
    }

    @Test
    void shouldReturn200OKWhenDeletingWaiverFromSubmission() throws Exception {
        String feeWaiverId = "12345E";

        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        SubmissionDto expected = SubmissionMapper.toSubmissionDTO(submission);
        expected = mapper.readValue(mapper.writeValueAsString(expected), SubmissionDto.class);

        when(submissionService.deleteFeeWaiverFromSubmission(MYUSCIS_ID, null, SUBMISSION_ID, feeWaiverId))
                .thenReturn(submission);

        ResultActions actions = this.mockMvc
                .perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}/feeWaiver/{id}?=undefined",
                        MYUSCIS_ID, SUBMISSION_ID, feeWaiverId)
                        .with(jwt()));

        SubmissionDto actual = this.mapper.readValue(actions.andReturn().getResponse().getContentAsString(),
                SubmissionDto.class);

        assertEquals(expected, actual);
        actions.andExpect(status().isOk());

    }

    // TODO Investigate this scenario and handle error
    @Test
    void deleteFeeWaiverByFeeWaiverId_deleteObjectException() throws Exception {
        String feeWaiverId = "12345E";

        doThrow(new NoSuchElementException()).when(submissionService).deleteFeeWaiverFromSubmission(MYUSCIS_ID, null,
                SUBMISSION_ID,
                feeWaiverId);

        this.mockMvc
                .perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}/feeWaiver/{id}?=undefined", MYUSCIS_ID,
                        SUBMISSION_ID,
                        feeWaiverId)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldDeleteDraftSubmission() throws Exception {
        doNothing().when(submissionService).deleteDraftSubmission(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID);

        this.mockMvc.perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                .with(jwt())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    void shouldUpdateSubmissionEligibility() throws Exception {
        EligibilityUpdateRequest update = new EligibilityUpdateRequest();
        update.setEligibilityCategory(I765EligibilityCategory.A12);
        update.setBenefitTypeCode(63);
        update.setApplicationReasonCode(39);

        Submission original = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)).thenReturn(original);

        original.setEligibilityCategory(update.getEligibilityCategory());
        when(submissionService.updateEligibility(
                original.getMyUscisId(),
                original.getOrgMyUscisId(),
                original.getSubmissionId(),
                update))
                .thenReturn(original);

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/category", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON)
                        .content(this.mapper.writeValueAsString(update)));

        actions.andExpect(status().isOk());
    }

    @Test
    void shouldUpdateImmviForI765Submission() throws Exception {
        Submission original = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        ImmviUpdateRequest request = new ImmviUpdateRequest();
        request.setImmvi(true);

        Submission updatedSubmission = new Submission();
        updatedSubmission.setFormType(FormType.I765);

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)).thenReturn(original);
        when(submissionService.updateImmvi(SUBMISSION_ID, MYUSCIS_ID, ORG_MYUSCIS_ID, request.getImmvi()))
                .thenReturn(updatedSubmission);

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/immvi", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)));

        actions.andExpect(status().isOk());
    }

    @Test
    void shouldSucessfullySetResidencyStatus() throws Exception {
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I130);
        ResidencyStatus status = ResidencyStatus.LPR;
        when(submissionService.setResidencyStatus(SUBMISSION_ID, MYUSCIS_ID, null, status)).thenReturn(submission);

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/residency-status?residencyStatus=LPR", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)));

        actions.andExpect(status().isOk());
    }

    @Test
    void shouldSendBadRequestToSetResidencyStatus() throws Exception {
                Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I130);
        ResidencyStatus status = ResidencyStatus.LPR;
        when(submissionService.setResidencyStatus(SUBMISSION_ID, MYUSCIS_ID, null, status)).thenReturn(submission);

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/residency-status", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)));

        actions.andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturnBadRequestForNonI765Submission() throws Exception {
        ImmviUpdateRequest request = new ImmviUpdateRequest();
        request.setImmvi(true);

        when(submissionService.updateImmvi(SUBMISSION_ID, MYUSCIS_ID, null, request.getImmvi()))
                .thenThrow(new SubmissionBadException("IMMVI not applicable for this form type"));

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/immvi?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)));

        actions.andExpect(status().isBadRequest());
    }

    @Test
    void shouldUpdateReasonForFilingForI765Submission() throws Exception {
        Submission original = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        ReasonForFilingUpdateRequest request = new ReasonForFilingUpdateRequest();
        request.setReasonForFiling(ReasonForFiling.RENEWAL.toString());

        Submission updatedSubmission = new Submission();
        updatedSubmission.setFormType(FormType.I765);

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(original);
        when(submissionService.updateReasonForFiling(SUBMISSION_ID, MYUSCIS_ID, null, request.getReasonForFiling()))
                .thenReturn(updatedSubmission);

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/reason-for-filing", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)));

        actions.andExpect(status().isOk());
    }

    @Test
    void shouldReturnBadRequestForNonSupportedCategoryForReasonForFiling() throws Exception {
        ReasonForFilingUpdateRequest request = new ReasonForFilingUpdateRequest();
        request.setReasonForFiling(ReasonForFiling.INITIAL.toString());

        when(submissionService.updateReasonForFiling(SUBMISSION_ID, MYUSCIS_ID, null, request.getReasonForFiling()))
                .thenThrow(new SubmissionBadException("Reason for filing not applicable for eligibility category"));

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/reason-for-filing?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)));

        actions.andExpect(status().isBadRequest());
    }

    @Test
    void shouldUpdateHasReviewedSignatureForI765Submission() throws Exception {
        Submission original = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        HasReviewedSignatureUpdateRequest request = new HasReviewedSignatureUpdateRequest();
        request.setHasReviewedSignature(true);

        Submission updatedSubmission = new Submission();
        updatedSubmission.setFormType(FormType.I765);

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(original);
        when(submissionService.updateSignatureReviewed(SUBMISSION_ID, MYUSCIS_ID, null, request.getHasReviewedSignature()))
                .thenReturn(updatedSubmission);

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/review-signature", MYUSCIS_ID, ORG_MYUSCIS_ID,
                        SUBMISSION_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)));

        actions.andExpect(status().isOk());
    }

    @Test
    void shouldUpdateN400Submission() throws Exception {
        EligibilityUpdateRequest update = new EligibilityUpdateRequest();
        update.setEligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION);
        update.setBenefitTypeCode(63);
        update.setApplicationReasonCode(39);
        Submission original = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.N400);

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(original);

        original.setEligibilityCategory(update.getEligibilityCategory());
        when(submissionService.updateEligibility(
                original.getMyUscisId(),
                null,
                original.getSubmissionId(),
                update)).thenReturn(original);

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/category", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON)
                        .content(this.mapper.writeValueAsString(update)));

        actions.andExpect(status().isOk());
    }

    @Test
    void shouldUpdateDraftSubmissionLock_isOk() throws Exception {
        Submission expected = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, expected.getSubmissionId())).thenReturn(expected);
        when(submissionService.updateDraftSubmissionLock(expected)).thenReturn(expected);

        ResultActions actions = this.mockMvc
                .perform(patch("/api/v1/{myUscisId}/submissions/{submissionId}/lock?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON));

        actions.andExpect(status().isOk());

    }

    @Test
    void shouldUpdateDraftSubmissionLock_isBadRequest() throws Exception {

        when(submissionService.retrieveDraftSubmission(anyString(), eq(null), anyString())).thenReturn(null);
        when(submissionService.updateDraftSubmissionLock(any(Submission.class))).thenReturn(null);

        ResultActions actions = this.mockMvc
                .perform(patch("/api/v1/{myUscisId}/submissions/{submissionId}/lock", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON));

        actions.andExpect(status().isBadRequest());

    }

    @Test
    void updateFeeWaiverEvidence_shouldSucceed() throws Exception {
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(submission);
        when(submissionService.updateFeeWaiverEvidence(any(Submission.class), anyString(), anyBoolean()))
                .thenAnswer(call -> {
                    String type = call.getArgument(1);
                    submission.getFeeWaiver().setType(type);
                    return submission;
                });
        // when(validator.)

        String newType = DocumentType.FeeWaiver.FEE_DECLARATION;
        UpdateFeeWaiverEvidenceRequest request = UpdateFeeWaiverEvidenceRequest.builder().type(newType).build();
        mockMvc
                .perform(patch("/api/v1/{myUscisId}/submissions/{submissionId}/feeWaiver/{id}?=undefined", MYUSCIS_ID,
                        submission.getSubmissionId(), submission.getFeeWaiver().getId())
                        .with(jwt())
                        .contentType(APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.submission.feeWaiver.type").value(newType));
    }

    @Test
    public void shouldRetrieveValidationStatusWhenFound() throws Exception {

        String FORM_ID = UUID.randomUUID().toString();
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        submission.getForms().get(0).setId(FORM_ID);
        ValidationStatusResponse expectedValidation = ValidationStatusResponse.builder()
                .status(ValidationStatusEnum.COMPLETE)
                .formValidations(List.of(
                        Validation.builder()
                                .details(List.of(
                                        ValidationDetails.builder().validator(ValidatorEnum.CORE)
                                                .result(ValidationResultEnum.FAIL)
                                                .reasons(List
                                                        .of("Submitted form is missing the barcode. Rescan your document to proceed."))
                                                .warnings(Maps.newHashMap())
                                                .build(),
                                        ValidationDetails.builder().validator(ValidatorEnum.SIGNATURE)
                                                .result(ValidationResultEnum.FAIL)
                                                .reasons(List.of("Signature does not appear to be present"))
                                                .warnings(Maps.newHashMap())
                                                .build(),
                                        ValidationDetails.builder().validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                                                .result(ValidationResultEnum.WARN)
                                                .reasons(List.of())
                                                .warnings(Maps.newHashMap())
                                                .build()))
                                .build()))
                .build();

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(submission);
        when(validationService.retrieveValidationStatus(submission)).thenReturn(expectedValidation);

        ResultActions actions = this.mockMvc.perform(
                get("/api/v1/{myUscisId}/submissions/{submissionId}/validation-status?=undefined", MYUSCIS_ID,
                        SUBMISSION_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isOk());

        ValidationStatusResponse actual = this.mapper.readValue(actions.andReturn().getResponse().getContentAsString(),
                ValidationStatusResponse.class);

        assertEquals(expectedValidation, actual);
    }

    @Test
    public void shouldRetrieveI912ValidationStatusWhenFound() throws Exception {

        String FORM_ID = UUID.randomUUID().toString();
        ValidationStatusResponse expectedValidation = ValidationStatusResponse.builder()
                .status(ValidationStatusEnum.COMPLETE)
                .i912FeeWaiverValidation(
                        ValidationDetails.builder().validator(ValidatorEnum.I912)
                                .result(ValidationResultEnum.PASS)
                                .reasons(List.of())
                                .warnings(Maps.newHashMap())
                                .build())
                .build();

        Submission mockSubmission = mock(Submission.class);
        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(mockSubmission);
        when(validationService.retrieveI912ValidationStatus(FORM_ID, mockSubmission)).thenReturn(expectedValidation);

        ResultActions actions = this.mockMvc.perform(
                get("/api/v1/{myUscisId}/submissions/{submissionId}/forms/{formId}/i912-validation-status?=undefined", MYUSCIS_ID,
                        SUBMISSION_ID, FORM_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isOk());

        ValidationStatusResponse actual = this.mapper.readValue(actions.andReturn().getResponse().getContentAsString(),
                ValidationStatusResponse.class);

        assertEquals(expectedValidation, actual);
    }

    @Test
    public void shouldNotRetrieveI912ValidationStatusWhen() throws Exception {
        String FORM_ID = UUID.randomUUID().toString();
        when(validationService.retrieveI912ValidationStatus(anyString(), any(Submission.class))).thenReturn(null);
        this.mockMvc.perform(get("/api/v1/forms/{formId}/i912-validation-status", FORM_ID)
                .with(jwt()))
                .andExpect(status().isNotFound());
    }

    @Test
    public void shouldNotRetrieveValidationStatusWhen() throws Exception {
        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID))
                .thenThrow(NoSuchElementException.class);
        this.mockMvc
                .perform(get("/api/v1/{myUscisId}/submissions/{submissionId}/validation-status", MYUSCIS_ID, ORG_MYUSCIS_ID,
                        SUBMISSION_ID)
                        .with(jwt()))
                .andExpect(status().isNotFound());
    }

    @Test
    public void shouldCallServiceWithMappedParameters() throws Exception {
        SubmissionService submissionService = mock(SubmissionService.class);
        when(submissionService.findAllByMyUscisIdAndStatus(any(), any()))
                .thenReturn(asList(Instancio.create(Submission.class)));
        S3Service s3Service = mock(S3Service.class);
        ValidationService validationService = mock(ValidationService.class);
        AuditService auditService = mock(AuditService.class);
        var mockController = MockMvcBuilders
                .standaloneSetup(
                        new SubmissionController(submissionService, s3Service, validationService, auditService,
                                peepsService, validator))
                .build();
        String myUscisId = "fake-uscis-id";
        mockController.perform(get("/api/v1/{myUscisId}/submissions?filters=REJECTED,ACCEPTED", myUscisId))
                .andExpect(status().isOk());

        verify(submissionService).findAllByMyUscisIdAndStatus(myUscisId, asList(REJECTED, ACCEPTED));
    }

    @Test
    public void shouldCallServiceWithMappedParametersForOrgId() throws Exception {
        SubmissionService submissionService = mock(SubmissionService.class);
        when(submissionService.findAllByOrgMyUscisIdAndStatus(any(), any()))
                .thenReturn(asList(Instancio.create(Submission.class)));
        S3Service s3Service = mock(S3Service.class);
        ValidationService validationService = mock(ValidationService.class);
        AuditService auditService = mock(AuditService.class);
        var mockController = MockMvcBuilders
                .standaloneSetup(
                        new SubmissionController(submissionService, s3Service, validationService, auditService,
                                peepsService, validator))
                .build();
        String myUscisId = "fake-uscis-id";
        String orgMyUscisId = "fake-uscis-id";
        mockController.perform(get("/api/v1/{myUscisId}/submissions/org/{orgMyUscisId}?filters=REJECTED,ACCEPTED", myUscisId, orgMyUscisId))
                .andExpect(status().isOk());

        verify(submissionService).findAllByOrgMyUscisIdAndStatus(orgMyUscisId, asList(REJECTED, ACCEPTED));
    }

    @Test
    public void shouldCallServiceWithApplicantUUIDhMappedParameters() throws Exception {
        SubmissionService submissionService = mock(SubmissionService.class);
        when(submissionService.findAllByApplicantUscisIdAndStatus(any(), any()))
                .thenReturn(asList(Instancio.create(Submission.class)));
        S3Service s3Service = mock(S3Service.class);
        ValidationService validationService = mock(ValidationService.class);
        AuditService auditService = mock(AuditService.class);
        var mockController = MockMvcBuilders
                .standaloneSetup(
                        new SubmissionController(submissionService, s3Service, validationService, auditService,
                                peepsService, validator))
                .build();
        String myUscisId = "fake-uscis-id";
        mockController.perform(get("/api/v1/{myUscisId}/submissions/applicant?filters=REJECTED,ACCEPTED", myUscisId))
                .andExpect(status().isOk());

        verify(submissionService).findAllByApplicantUscisIdAndStatus(myUscisId, asList(REJECTED, ACCEPTED));
    }

    @Test
    public void shouldCallServiceWithMappedParametersAndEmptyResultSet() throws Exception {
        SubmissionService submissionService = mock(SubmissionService.class);
        S3Service s3Service = mock(S3Service.class);
        ValidationService validationService = mock(ValidationService.class);
        AuditService auditService = mock(AuditService.class);
        var mockController = MockMvcBuilders
                .standaloneSetup(
                        new SubmissionController(submissionService, s3Service, validationService, auditService,
                                peepsService, validator))
                .build();
        String myUscisId = "fake-uscis-id";
        var response = mockController
                .perform(get("/api/v1/{myUscisId}/submissions?filters=REJECTED,ACCEPTED", myUscisId))
                .andExpect(status().isOk())
                .andReturn();

        assertThat(response.getResponse().getContentAsString()).isEqualTo("[]");

        verify(submissionService).findAllByMyUscisIdAndStatus(myUscisId, asList(REJECTED, ACCEPTED));
    }

    @Test
    void shouldAttestSubmission() throws Exception {
        String attestationSignature = "john doe";
        String formId = "formId";

        AttestFormRequest request = AttestFormRequest.builder()
                .attested(true)
                .attestationSignature(attestationSignature)
                .build();

        ResultActions actions = this.mockMvc
                .perform(post("/api/v1/{myUscisId}/submissions/{submissionId}/attest/{formId}?=undefined", MYUSCIS_ID,
                        SUBMISSION_ID, formId)
                        .with(jwt())
                        .contentType(APPLICATION_JSON)
                        .content(this.mapper.writeValueAsString(request)));

        actions.andExpect(status().isOk())
                .andExpect(jsonPath("$.forms[0].url").doesNotExist())
                .andExpect(jsonPath("$.evidences[0].url").doesNotExist())
                .andExpect(jsonPath("$.feeWaiver.url").doesNotExist());

        verify(submissionService).attestForm(MYUSCIS_ID, null, SUBMISSION_ID, formId, true, attestationSignature);
    }

    @Test
    void shouldRetrieveAttestationStatus() throws Exception {
        String formId = "formId";

        ResultActions actions = this.mockMvc
                .perform(get("/api/v1/{myUscisId}/submissions/{submissionId}/forms/{formId}/attestation-status?=undefined",
                        MYUSCIS_ID, SUBMISSION_ID, formId)
                        .with(jwt())
                        .contentType(APPLICATION_JSON));

        actions.andExpect(status().isOk());

        verify(submissionService).getAttestationStatus(SUBMISSION_ID, formId);
    }

    @Test
    void updateUserRequestedFeeWaiver_shouldCallService() throws Exception {
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        submission.setUserRequestedFeeWaiver(true);

        when(submissionService.updateUserRequestedFeeWaiver(MYUSCIS_ID, null, SUBMISSION_ID, true)).thenReturn(submission);

        FeeWaiverRequest request = FeeWaiverRequest.builder().userRequestedFeeWaiver(true).build();
        mockMvc.perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/fee-waiver?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                .with(jwt())
                .contentType(APPLICATION_JSON)
                .content(mapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.submissionId").value(SUBMISSION_ID))
                .andExpect(jsonPath("$.userRequestedFeeWaiver").value(true));
        verify(submissionService).updateUserRequestedFeeWaiver(MYUSCIS_ID, null, SUBMISSION_ID, true);
    }

    @Test
    void updateUserRequestedPartialFeeWaiver_shouldCallService() throws Exception {
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I765);
        submission.setUserRequestedFeeWaiver(true);
        submission.setUserRequestedPartialFeeWaiver(true);

        when(submissionService.updateUserRequestedPartialFeeWaiver(MYUSCIS_ID, null, SUBMISSION_ID, true))
                .thenReturn(submission);

        PartialFeeWaiverRequest request = PartialFeeWaiverRequest.builder().userRequestedPartialFeeWaiver(true).build();
        mockMvc.perform(
                put("/api/v1/{myUscisId}/submissions/{submissionId}/partial-fee-waiver?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.submissionId").value(SUBMISSION_ID))
                .andExpect(jsonPath("$.userRequestedFeeWaiver").value(true));
        verify(submissionService).updateUserRequestedPartialFeeWaiver(MYUSCIS_ID, null, SUBMISSION_ID, true);
    }

    @Test
    void shouldCallRetrieveAccountType() throws Exception {
        String myUscisId = UUID.randomUUID().toString();
        PeepsService peepsService = mock(PeepsService.class);
        var controller = MockMvcBuilders
                .standaloneSetup(
                        new SubmissionController(submissionService, s3service, validationService, auditService,
                                peepsService, validator))
                .build();

        controller
                .perform(get("/api/v1/{myUscisId}/submissions/userRole", myUscisId)
                        .with(jwt())
                        .content(this.mapper.writeValueAsString(request))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        verify(peepsService, times(1)).retrieveAccountType(myUscisId);
    }

    @Test
    public void addClientShouldCallValidateClientEmail() {
        AddClientRequest request = Instancio.create(AddClientRequest.class);

        SubmissionController controller = new SubmissionController(submissionService, s3service, validationService,
                auditService, peepsService, validator);

        var expectedResponse = true;
        when(peepsService.validateClientEmailIsNotAttorneyEmail(MYUSCIS_ID, request.emailAddress()))
                .thenReturn(expectedResponse);
        var actualResponse = controller.addClient(MYUSCIS_ID, request);
        verify(peepsService, times(1)).validateClientEmailIsNotAttorneyEmail(MYUSCIS_ID, request.emailAddress());
        assertEquals(expectedResponse, actualResponse.getBody());
    }

    @Test
    void shouldInitiallyCreateARepresentativeBasedSubmission() throws Exception {
        String clientId = UUID.randomUUID().toString();
        String repGroupId = UUID.randomUUID().toString();

        SubmissionRequest expected = SubmissionRequest.builder()
                .formType(FormType.N400)
                .formDescription(FormTypeDescription.I765.getDescription())
                .eligibilityCategory(I765EligibilityCategory.A12.getCategory())
                .accountType(AccountType.REPRESENTATIVE)
                .clientInformation(Optional.of(ClientInformation.builder()
                        .attorneyId(MYUSCIS_ID)
                        .clientId(clientId)
                        .submissionId(null)
                        .name(new Name("Harry", null, "Potter"))
                        .userGroupIds(List.of(repGroupId))
                        .build()))
                .build();

        Submission submission = Instancio.create(Submission.class);
        when(submissionService.createInitialSubmission(anyString(), any(SubmissionRequest.class)))
                .thenReturn(submission);

        this.mockMvc.perform(post("/api/v1/{myUscisId}/submissions/", MYUSCIS_ID)
                .with(jwt())
                .contentType(APPLICATION_JSON)
                .content(this.mapper.writeValueAsString(expected)))
                .andExpect(status().isOk())
                .andExpect(content().string(mapper.writeValueAsString(SubmissionMapper.toSubmissionDTO(submission))));
    }

    @Test
    void esignForm() throws Exception {
    	EsignData edata = EsignData.builder()
				.applicantFullName("FullAppName")
				.browserInformation("browser")
				.esignDate(new Date()).build();

    	EsignRequest erequest = EsignRequest.builder()
    		.formId(FORM_ID)
    		.submissionId(SUBMISSION_ID)
    		.uuid(MYUSCIS_ID)
    		.role("PETITIONER")
    		.esignData(edata)
    		.build();



        this.mockMvc
                .perform(post("/api/v1/{myUscisId}/submissions/{submissionId}/esign/{formId}", MYUSCIS_ID, SUBMISSION_ID, FORM_ID)
                        .with(jwt())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(erequest)));


        verify(submissionService).esignForm(eq(MYUSCIS_ID), eq(null), eq(SUBMISSION_ID), eq(FORM_ID), any(EsignData.class));
    }

    @Test
    void shouldUpdateSubmissionEligibilitySubCategories() throws Exception {
        EligibilitySubcategoriesUpdateRequest update = new EligibilitySubcategoriesUpdateRequest();
        update.setEligibilitySubcategories(List.of(I751WaiverOrIndividualFilingSubcategory.DIVORCE_ANNULMENT, I751WaiverOrIndividualFilingSubcategory.EXTREME_HARDSHIP));

        Submission original = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I751);

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(original);

        original.setEligibilitySubcategories(update.getEligibilitySubcategories());
        when(submissionService.updateEligibilitySubcategories(
                original.getMyUscisId(),
                null,
                original.getSubmissionId(),
                update.getEligibilitySubcategories()))
                .thenReturn(original);

        ResultActions actions = this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/eligibility-subcategories", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON)
                        .content(this.mapper.writeValueAsString(update)));

        actions.andExpect(status().isOk());
    }

    @Test
    void shouldReturnUpdatedSubmissionForFormSpecificInfoPut() throws Exception {
        FormSpecificInfo body = new I751FormSpecificInfo(false);
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I751);

        when(submissionService.updateFormSpecificInfo(anyString(), any(FormSpecificInfo.class)))
                .thenReturn(submission);

        this.mockMvc
                .perform(put("/api/v1/{myUscisId}/submissions/{submissionId}/form-specific-info", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON)
                        .content(mapper.writeValueAsString(body)))
                .andExpect(status().isOk());

    }

    @Test
    void shouldReturnUpdatedSubmissionForFormSpecificInfoDelete() throws Exception {
        FormSpecificInfo body = new I751FormSpecificInfo(false);
        Submission submission = SubmissionFactory.forSubmissionId(SUBMISSION_ID, MANIFEST_ID, FormType.I751);

        when(submissionService.updateFormSpecificInfo(anyString(), any(FormSpecificInfo.class)))
                .thenReturn(submission);

        this.mockMvc
                .perform(delete("/api/v1/{myUscisId}/submissions/{submissionId}/delete-form-specific-info", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
                        .with(jwt())
                        .contentType(APPLICATION_JSON)
                        .content(mapper.writeValueAsString(body)))
                .andExpect(status().isOk());

    }

}
