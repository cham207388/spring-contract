package gov.dhs.uscis.submissionservice.validators.AttorneyProfileValidator;

import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.models.validation.ClientNameEmailResponse;
import gov.dhs.uscis.intake.models.validation.name_extract.ClientName;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.RepresentativeProfileResponseData;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.PeepsService;

@ExtendWith(MockitoExtension.class)
public class AttorneyNameMatchesFormValidatorTest {
    private static final String submissionId = UUID.randomUUID().toString();
    private static final String formId = UUID.randomUUID().toString();
    private static final String myUscisId = UUID.randomUUID().toString();
    private static final String lastName = "Doe";
    private static final String firstName = "John";
    private static final String message = "Logged in user does not match information on forms.";

    @Test
    public void validateAttorneyNameMatchesForm_ShouldFailIfNameDoesNotMatch() {
        final String messageFirstName = "Kilgore";
        final String messageLastName = "Trout";

        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusRepository = mock(ValidationStatusRepository.class);
        var attorneyNameMatchesFormValidator = new AttorneyNameMatchesFormValidator(peepsService, validationStatusRepository);
        ClientNameEmailResponse response = generateResponse(messageFirstName, messageLastName);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, lastName);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        attorneyNameMatchesFormValidator.validate(response);

        verify(validationStatusRepository).save(argThat(status -> status.getStatus() == ValidationResultEnum.FAIL
                && status.getFailureReasons().contains(message)));
    }

    @Test
    public void validateAttorneyNameMatchesForm_ShouldFailIfMessageNameIsNull() {
        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var attorneyNameMatchesFormValidator = new AttorneyNameMatchesFormValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(null, null);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, lastName);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        attorneyNameMatchesFormValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.FAIL
                && status.getFailureReasons().contains(message)));
    }

    @Test
    public void validateAttorneyNameMatchesForm_ShouldFailIfProfileNameIsNull() {
        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var attorneyNameMatchesFormValidator = new AttorneyNameMatchesFormValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(lastName, lastName);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(null, null);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        attorneyNameMatchesFormValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.FAIL
                && status.getFailureReasons().contains(message)));
    }

    @Test
    public void validateAttorneyNameMatchesForm_ShouldPassIfNamesMatch() {
        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var attorneyNameMatchesFormValidator = new AttorneyNameMatchesFormValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(firstName, lastName);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, lastName);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        attorneyNameMatchesFormValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.PASS
                && status.getFailureReasons().isEmpty()));
    }

    @Test
    public void shouldPassIfNamesMatchWithSpaces() {
        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var attorneyNameMatchesFormValidator = new AttorneyNameMatchesFormValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(String.format("  %s ", firstName), String.format("%s ", lastName));
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, lastName);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        attorneyNameMatchesFormValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.PASS
                && status.getFailureReasons().isEmpty()));
    }


    private ClientNameEmailResponse generateResponse(String firstName, String lastName) {
        ClientName clientName = ClientName.builder().familyName(lastName).givenName(firstName).build();
        return ClientNameEmailResponse.builder()
                .formId(formId)
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .clientName(clientName)
                .email(null)
                .build();
    }

    private RepresentativeProfileResponseData generateProfileResponse(String firstName, String lastName) {
        return RepresentativeProfileResponseData.builder()
                .firstName(firstName)
                .lastName(lastName)
                .email(null)
                .build();
    }
}
