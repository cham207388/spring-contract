package gov.dhs.uscis.submissionservice.validators.n400;

import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.testcontainers.shaded.com.google.common.collect.Maps;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.N400EligibilityCategory;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.validation.N400FormFieldResult;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.services.FormService;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;

@ExtendWith(MockitoExtension.class)
public class BasisOfEligibilityValidatorTest {

    @Mock
    DynamoDbTable<ValidationStatus> validationStatusTable;

    @Mock
    FormService formService;

    @InjectMocks
    private BasisOfEligibilityValidator validator;

    private List<EligibilityCategoryEnum> emptyList = List.of();
    private Map<String, String> emptyWarningMap = Maps.newHashMap();

    @Test
    void shouldFailValidationWhenBasisWasMissingOnForm() {

        var formId = UUID.randomUUID().toString();
        var submissionId = UUID.randomUUID().toString();
        var categories = N400FormFieldResult.builder().formId(formId).submissionId(submissionId)
                .selectedCategories(emptyList).build();

        var form = SubmissionForm.builder().build();
        var submission = Submission.builder()
                .submissionId(submissionId)
                .status(SubmissionState.DRAFT)
                .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                .formType(FormType.N400)
                .forms(List.of(form)).build();

        var expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .validationWarnings(emptyWarningMap)
                .failureReasons(List.of(String.format(BasisOfEligibilityValidator.NO_BASIS_DETECTED_MESSAGE, "N-400")))
                .build();

        validator.validate(submission, categories);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        MatcherAssert.assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenBasisNotSelectedInApplication() {
        var formId = UUID.randomUUID().toString();
        var submissionId = UUID.randomUUID().toString();
        var categories = N400FormFieldResult.builder().formId(formId).submissionId(submissionId)
                .selectedCategories(List.of(N400EligibilityCategory.GENERAL_PROVISION)).build();

        var form = SubmissionForm.builder().build();
        var submission = Submission.builder().submissionId(submissionId).status(SubmissionState.DRAFT)
                .forms(List.of(form))
                .build();

        var expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .validationWarnings(emptyWarningMap)
                .failureReasons(List.of(BasisOfEligibilityValidator.BASIS_OF_ELIGIBILITY_NOT_SELECTED))
                .build();

        validator.validate(submission, categories);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        MatcherAssert.assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenTooManyBasesSelectedInApplication() {
        var formId = UUID.randomUUID().toString();
        var submissionId = UUID.randomUUID().toString();
        var categories = N400FormFieldResult.builder()
                .formId(formId)
                .submissionId(submissionId)
                .selectedCategories(
                        List.of(N400EligibilityCategory.GENERAL_PROVISION,
                                N400EligibilityCategory.MILITARY_ONE_YEAR_HONORABLE))
                .build();

        var form = SubmissionForm.builder().build();
        var submission = Submission.builder()
                .submissionId(submissionId)
                .formType(FormType.N400)
                .status(SubmissionState.DRAFT)
                .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                .forms(List.of(form))
                .build();

        var expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .validationWarnings(emptyWarningMap)
                .failureReasons(List.of(BasisOfEligibilityValidator.MULTIPLE_BASES_DETECTED_MESSAGE))
                .build();

        validator.validate(submission, categories);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        MatcherAssert.assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldPassValidationWhenBasesMatchInApplication() {
        var formId = UUID.randomUUID().toString();
        var submissionId = UUID.randomUUID().toString();
        var categories = N400FormFieldResult.builder()
                .formId(formId)
                .submissionId(submissionId)
                .selectedCategories(
                        List.of(N400EligibilityCategory.MILITARY_ONE_YEAR_HONORABLE))
                .build();

        var form = SubmissionForm.builder().build();
        var submission = Submission.builder()
                .submissionId(submissionId)
                .status(SubmissionState.DRAFT)
                .formType(FormType.N400)
                .eligibilityCategory(N400EligibilityCategory.MILITARY_ONE_YEAR_HONORABLE)
                .forms(List.of(form))
                .build();

        var expectedPut = ValidationStatus.builder().status(ValidationResultEnum.PASS).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .validationWarnings(emptyWarningMap)
                .failureReasons(List.of())
                .build();

        validator.validate(submission, categories);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        MatcherAssert.assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenBasesMismatchedInApplication() {
        var formId = UUID.randomUUID().toString();
        var submissionId = UUID.randomUUID().toString();
        var categories = N400FormFieldResult.builder()
                .formId(formId)
                .submissionId(submissionId)
                .selectedCategories(
                        List.of(N400EligibilityCategory.MILITARY_ONE_YEAR_HONORABLE))
                .build();

        var form = SubmissionForm.builder().build();
        var submission = Submission.builder()
                .submissionId(submissionId)
                .status(SubmissionState.DRAFT)
                .formType(FormType.N400)
                .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                .forms(List.of(form))
                .build();

        var expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .validationWarnings(emptyWarningMap)
                .failureReasons(List.of(BasisOfEligibilityValidator.BASIS_OF_ELIGIBILITY_MISMATCH))
                .build();

        validator.validate(submission, categories);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        ArgumentCaptor<FormFields> formFieldsCaptor = ArgumentCaptor.forClass(FormFields.class);

        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        MatcherAssert.assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

}
