package gov.dhs.uscis.submissionservice.controllers;

import static java.util.UUID.randomUUID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.submissionservice.services.ClientManagementService;
import gov.dhs.uscis.submissionservice.services.SubmissionService;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

public class ClientControllerTest {

    private ClientManagementService clientManagementService = mock(ClientManagementService.class);
    private SubmissionService submissionService = mock(SubmissionService.class);

    @Test
    public void shouldAddClientOnPost() throws Exception {
        var controller = MockMvcBuilders
                .standaloneSetup(new ClientController(clientManagementService, submissionService))
                .build();

        var attorneyId = randomUUID().toString();
        var submissionId = randomUUID().toString();
        String emailAddress = "emailAddress";
        Submission testSubmission = Submission.builder()
            .submissionId(submissionId)
            .formType(FormType.I765)
        .build();

        when(submissionService.retrieveSubmission(anyString())).thenReturn(testSubmission);

        controller.perform(post("/api/v1/" + attorneyId + "/submissions/" + submissionId + "/clients/add-client")
                .content(new ObjectMapper().writeValueAsString(new AddClientRequestDetails(emailAddress,
                        new Name("firstName", "middleName", "lastName"), "111111111", "01/01/2011")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        ArgumentCaptor<AddClientRequestDetails> details = ArgumentCaptor.forClass(AddClientRequestDetails.class);
        ArgumentCaptor<String> attorneyIdCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Submission> submissionCaptor = ArgumentCaptor.forClass(Submission.class);

        verify(clientManagementService).addClient(attorneyIdCaptor.capture(), submissionCaptor.capture(),
                details.capture());

        assertThat(attorneyIdCaptor.getValue()).isEqualTo(attorneyId);
        assertThat(submissionCaptor.getValue()).isEqualTo(testSubmission);
        assertThat(details.getValue().emailAddress()).isEqualTo(emailAddress);
    }
}
