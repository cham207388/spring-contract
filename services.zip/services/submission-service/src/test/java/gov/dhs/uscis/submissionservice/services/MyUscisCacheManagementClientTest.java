package gov.dhs.uscis.submissionservice.services;

import java.io.IOException;
import java.time.ZonedDateTime;

import javax.net.ssl.SSLException;

import org.assertj.core.api.Assertions;
import org.instancio.Instancio;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.util.MimeType;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;

import gov.dhs.uscis.intake.converters.FromMimeTypeSerializer;
import gov.dhs.uscis.intake.converters.ToMimeTypeDeserializer;
import gov.dhs.uscis.intake.converters.ZonedDateTimeDeserializer;
import gov.dhs.uscis.intake.converters.ZonedDateTimeSerializer;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.models.Submission;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import reactor.netty.http.client.HttpClient;

public class MyUscisCacheManagementClientTest {

    static MockWebServer mockCacheUpdateService;
    MyUscisCacheManagementClient client;

    @BeforeEach
    void initialize() throws IOException {
        mockCacheUpdateService = new MockWebServer();
        mockCacheUpdateService.start();

        client = new MyUscisCacheManagementClient(
                WebClient.create(String.format("http://localhost:%s", mockCacheUpdateService.getPort())),
                getObjectMapper(), true);

    }

    @AfterAll
    static void tearDown() throws IOException {
        mockCacheUpdateService.shutdown();
    }

    @Test
    public void shouldUpdateStatusOfSubmission() {

        var submission = Instancio.create(Submission.class);
        submission.getApplicant().setAccountType(AccountType.REPRESENTATIVE);
        mockCacheUpdateService.enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                .setResponseCode(200).setBody("{}"));
        client.publishDraftChangeEvent(submission);
        Assertions.assertThat(mockCacheUpdateService.getRequestCount()).isEqualTo(1);
    }

    @Test
    public void shouldUpdateStatusOfDraft() throws InterruptedException, JsonProcessingException {

        var submission = Instancio.create(Submission.class);
        submission.getApplicant().setAccountType(AccountType.REPRESENTATIVE);
        mockCacheUpdateService.enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                .setResponseCode(200).setBody("{}"));
        client.publishCaseChangeEvent(submission);

        Assertions.assertThat(mockCacheUpdateService.getRequestCount()).isEqualTo(1);
        Assertions.assertThat(mockCacheUpdateService.takeRequest().getBody().readUtf8())
                .isEqualTo(getObjectMapper().writeValueAsString(submission));
    }

    @Test
    public void shouldNotUpdateStatusOfDraftForApplicant() {

        var submission = Instancio.create(Submission.class);
        submission.getApplicant().setAccountType(AccountType.APPLICANT);
        mockCacheUpdateService.enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                .setResponseCode(200).setBody("{}"));
        client.publishCaseChangeEvent(submission);

        Assertions.assertThat(mockCacheUpdateService.getRequestCount()).isEqualTo(0);
    }

    @Test
    public void shouldNotPublishAMessageForCreatedSubmissionIfDisabled() {
        client = new MyUscisCacheManagementClient(
                WebClient.create(String.format("http://localhost:%s", mockCacheUpdateService.getPort())),
                getObjectMapper(), false);

        var submission = Instancio.create(Submission.class);
        submission.getApplicant().setAccountType(AccountType.REPRESENTATIVE);
        client.publishDraftChangeEvent(submission);

        Assertions.assertThat(mockCacheUpdateService.getRequestCount()).isEqualTo(0);
    }

    @Test
    public void shouldNotPublishAMessageForDeletedDraftIfDisabled() {
        client = new MyUscisCacheManagementClient(
                WebClient.create(String.format("http://localhost:%s", mockCacheUpdateService.getPort())),
                getObjectMapper(), false);

        var submission = Instancio.create(Submission.class);
        submission.getApplicant().setAccountType(AccountType.REPRESENTATIVE);

        client.publishCaseChangeEvent(submission);

        Assertions.assertThat(mockCacheUpdateService.getRequestCount()).isEqualTo(0);
    }

    public MyUscisCacheManagementClient myUscisCacheManagementClient(
            @Value("${uscis.cacheupdate.url}") String url,
            @Value("${uscis.cacheupdate.username}") String username,
            @Value("${uscis.cacheupdate.password}") String password,
            @Value("${uscis.cacheupdate.enabled}") boolean enabled) throws SSLException {
        SslContext sslContext = SslContextBuilder
                .forClient()
                .trustManager(InsecureTrustManagerFactory.INSTANCE)
                .build();
        HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(sslContext));

        var webClient = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .defaultHeaders(headers -> headers.setBasicAuth(username, password))
                .baseUrl(url)
                .build();

        return new MyUscisCacheManagementClient(webClient, getObjectMapper(), enabled);
    }

    private ObjectMapper getObjectMapper() {
        final SimpleModule module = new SimpleModule();
        module.addSerializer(ZonedDateTime.class, new ZonedDateTimeSerializer());
        module.addDeserializer(ZonedDateTime.class, new ZonedDateTimeDeserializer());
        module.addSerializer(MimeType.class, new FromMimeTypeSerializer());
        module.addDeserializer(MimeType.class, new ToMimeTypeDeserializer());
        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        mapper.registerModule(module);
        mapper.registerModule(new Jdk8Module()); // support for Optional

        return mapper;
    }
}
