package gov.dhs.uscis.submissionservice.validators;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

class PdfDimensionValidatorTest {

    private final PdfDimensionValidator validator = new PdfDimensionValidator();

    @Test
    void shouldReturnTrueWhenPdfIsStandardSize() throws IOException {
        byte[] pdfBytes = createTestPdf(612, 792, 1.0f);
        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf", pdfBytes);

        assertThat(validator.isValid(file, null)).isTrue();
    }

    @Test
    void shouldReturnFalseWhenPdfIsTooLarge() throws IOException {
        byte[] pdfBytes = createTestPdf(10000, 10000, 1.0f);
        MockMultipartFile file = new MockMultipartFile("file", "huge.pdf", "application/pdf", pdfBytes);

        assertThat(validator.isValid(file, null)).isFalse();
    }

    @Test
    void shouldReturnFalseWhenPdfHasLargeUserUnit() throws IOException {
        byte[] pdfBytes = createTestPdf(100, 100, 100.0f);
        MockMultipartFile file = new MockMultipartFile("file", "scaled.pdf", "application/pdf", pdfBytes);

        assertThat(validator.isValid(file, null)).isFalse();
    }

    @Test
    void shouldReturnTrueWhenFileIsNotAPdf() {
        MockMultipartFile file = new MockMultipartFile("file", "photo.jpg", "image/jpeg", new byte[]{1, 2, 3});

        assertThat(validator.isValid(file, null)).isTrue();
    }

    @Test
    void shouldReturnTrueWhenFileIsNull() {
        assertThat(validator.isValid(null, null)).isTrue();
    }

    private byte[] createTestPdf(float width, float height, float userUnit) throws IOException {
        try (PDDocument document = new PDDocument(); ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            PDPage page = new PDPage(new PDRectangle(width, height));
            page.setUserUnit(userUnit);
            document.addPage(page);
            document.save(baos);
            return baos.toByteArray();
        }
    }
}
