package gov.dhs.uscis.submissionservice.controllers.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockPart;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.controllers.DocumentController;
import gov.dhs.uscis.submissionservice.converters.SubmissionParameterConverter;
import gov.dhs.uscis.submissionservice.exception.BackendValidationException;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;
import gov.dhs.uscis.submissionservice.services.ElisService;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.services.S3Service;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.validators.backend.UploadEvidenceValidator;

@WebMvcTest(DocumentController.class)
@AutoConfigureMockMvc
public class DocumentControllerDocsErrorTest {
        
        private static final String MYUSCIS_ID = UUID.randomUUID().toString();
        private static final String ORG_MYUSCIS_ID = UUID.randomUUID().toString();
        private static final String SUBMISSION_ID = UUID.randomUUID().toString();
        private static final String FORM_ID = "form_id";
        private static final String FORM_TYPE = "I-765";

        @Autowired
        private MockMvc mockMvc;

        @MockitoBean
        private SubmissionService submissionService;

        @MockitoBean
        ElisService elisService;

        @MockitoBean
        private S3Service s3Service;

        @MockitoBean
        private FormService formService;

        @MockitoBean
        private AuditService auditService;

        @MockitoBean
        SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;
        
        @MockitoBean
        private UploadEvidenceValidator uploadEvidenceValidator;
    
        @Test
        public void shouldShowErrorInAPIResponseForBackendValidationException() throws Exception {

                final String ERROR_MESSAGE = "evidence group photo cannot exceed 1 file(s)";

                doThrow(new BackendValidationException(ERROR_MESSAGE))
                    .when(uploadEvidenceValidator).validateEvidenceWithBackendData(any(), any());

                var s3ObjectKey = "moi.jpg";
                UploadEvidenceRequest evidenceRequest = UploadEvidenceRequest.builder()
                    .fileName(s3ObjectKey)
                    .type("photo")
                    .evidenceGroupType("form-i-94-passport")
                    .build();

                Submission priorUpdate = Submission.builder()
                                .formType(FormType.I765)
                                .eligibilityCategory(I765EligibilityCategory.C8)
                                .forms(List.of(SubmissionForm.builder().id(FORM_ID).build()))
                                .build();

                when(submissionService.retrieveSubmissionByIdAndUscisId(eq(SUBMISSION_ID), eq(MYUSCIS_ID), eq(null))).thenReturn(priorUpdate);

                MockPart file = new MockPart("files", "moi.jpg", "test content".getBytes(), MediaType.IMAGE_JPEG);
                MockPart request = new MockPart("uploadEvidenceRequests", new ObjectMapper().writeValueAsString(evidenceRequest).getBytes());

                mockMvc.perform(MockMvcRequestBuilders
                                .multipart("/api/v1/{myUscisId}/submissions/{submissionId}/evidence/{selectedFormType}?=undefined", MYUSCIS_ID, SUBMISSION_ID, FORM_TYPE)
                                .part(file, request)
                                .with(jwt()))
                                .andExpect(status().isBadRequest())
                                .andExpect(jsonPath("$.error").value(ERROR_MESSAGE));
        }

        @Test
        public void validateUploadForm() throws Exception {
          UploadRequest request = UploadRequest.builder().build();
      
          MockMultipartFile multipartFile = new MockMultipartFile(
              "file",
              "hello.pdf",
              MediaType.MULTIPART_FORM_DATA_VALUE,
              "Hello, World!".getBytes());
      
          MockMultipartFile multipartRequest = new MockMultipartFile("uploadRequest", "", "application/json",
              new ObjectMapper().writeValueAsString(request).getBytes());
      
          mockMvc.perform(MockMvcRequestBuilders
              .multipart("/api/v1/{myUscisId}/submissions/{submissionId}/form", MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)
              .file(multipartFile)
              .file(multipartRequest)
              .with(jwt()))
              .andExpect(status().isBadRequest());
        }
        
        @Test
        public void validateUploadEvidenceRequest() throws Exception {
          var EVIDENCE_ID = "54321";
          UploadEvidenceRequest evidenceRequest = UploadEvidenceRequest.builder().build(); // Populate as necessary
          Submission submission = Submission.builder()
              .forms(List.of(SubmissionForm.builder().id(FORM_ID).build()))
              .evidences(List.of(SubmissionEvidence.builder().id(EVIDENCE_ID).build()))
              .build();
          MockPart file = new MockPart("files", "moi.jpg", "test content".getBytes(), MediaType.APPLICATION_OCTET_STREAM);
          MockPart request = new MockPart("uploadEvidenceRequests",
              new ObjectMapper().writeValueAsString(evidenceRequest).getBytes());
          when(submissionService.retrieveSubmissionByIdAndUscisId(eq(SUBMISSION_ID), eq(MYUSCIS_ID), eq(null))).thenReturn(submission);
          mockMvc.perform(MockMvcRequestBuilders
              .multipart("/api/v1/{myUscisId}/submissions/{submissionId}/evidence/{selectedFormType}?=undefined", MYUSCIS_ID, SUBMISSION_ID, FORM_TYPE)
              .part(file, request)
              .with(jwt()))
              .andExpect(status().isBadRequest());
        }        

        @Test
        public void validateUploadFeeWaiverRequest() throws Exception {
          UploadFeeWaiverRequest feeWaiverRequest = UploadFeeWaiverRequest.builder().build();
      
          MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf",
              "test content".getBytes());
          MockMultipartFile multipartRequest = new MockMultipartFile("uploadFeeWaiverRequest", "",
              "application/json", new ObjectMapper().writeValueAsString(feeWaiverRequest).getBytes());
      
          mockMvc.perform(MockMvcRequestBuilders
              .multipart("/api/v1/{myUscisId}/submissions/{submissionId}/feeWaiver", MYUSCIS_ID, SUBMISSION_ID)
              .file(file)
              .file(multipartRequest)
              .with(jwt()))
              .andExpect(status().isBadRequest());
        }        

        @Test
    public void uploadFeeWaiverDisabled() throws Exception {
        var s3ObjectKey = "test.pdf";
        UploadFeeWaiverRequest feeWaiverRequest = new UploadFeeWaiverRequest(s3ObjectKey);

        Submission initialSubmission = Submission.builder().submissionId(SUBMISSION_ID).build();

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(initialSubmission);

        when(formService.isFeeWaiverEnabled(initialSubmission.getFormType())).thenReturn(false);
        
        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf",
                "test content".getBytes());
        MockMultipartFile multipartRequest = new MockMultipartFile("uploadFeeWaiverRequest", "",
                "application/json", new ObjectMapper().writeValueAsString(feeWaiverRequest).getBytes());

        mockMvc.perform(MockMvcRequestBuilders
                .multipart("/api/v1/{myUscisId}/submissions/{submissionId}/feeWaiver?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                .file(file)
                .file(multipartRequest)
                .with(jwt()))
                .andExpect(status().isBadRequest());
    }

}
