package gov.dhs.uscis.submissionservice.utils;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import gov.dhs.uscis.intake.services.formats.MagicBytes;

public class SubmissionEvidenceUtilTest {

    @Test
    void shouldMatchPDFDocument() {
        assertThat(SubmissionEvidenceUtil.isFileExtension("mydocument.pdf", MagicBytes.PDF )).isTrue();
    }
    @Test
    void shouldNotMatchNonPDFDocument() {
        assertThat(SubmissionEvidenceUtil.isFileExtension("myimage.jpg", MagicBytes.PDF )).isFalse();
    }

    @Test
    void shouldNotMatchNull() {
        assertThat(SubmissionEvidenceUtil.isFileExtension(null, MagicBytes.PDF )).isFalse();
    }

    @Test
    void shouldNotMatchEmptyString() {
        assertThat(SubmissionEvidenceUtil.isFileExtension("", MagicBytes.PDF )).isFalse();
    }


}
