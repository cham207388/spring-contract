package gov.dhs.uscis.submissionservice.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import static org.junit.jupiter.api.Assertions.*;

import java.net.URI;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.validation.address_extract.AddressExtract;
import gov.dhs.uscis.intake.models.validation.address_extract.ClientAddress;
import gov.dhs.uscis.submissionservice._testutils.LocalDbCreationRule;

import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;

import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.ScanRequest;

public class AddressExtractRepositoryTest {
    private static final String submissionId = UUID.randomUUID().toString();
    private static final String TABLE_NAME = "default-AddressExtract";

    @RegisterExtension
    static LocalDbCreationRule localDynamoDb = new LocalDbCreationRule();

    private static DynamoDbClient dynamoDbClient;
    private static DynamoDbEnhancedClient dynamoDbEnhancedClient;
    private static DynamoDbTable<AddressExtract> addressExtractTable;
    private static AddressExtractRepository addressExtractRepository;

    @BeforeAll
    private static void before() {

        dynamoDbClient = DynamoDbClient
        .builder()
        .endpointOverride(URI.create(String.format("http://localhost:%s", localDynamoDb.getPort())))
        .build();

        dynamoDbEnhancedClient = DynamoDbEnhancedClient
                .builder()
                .dynamoDbClient(dynamoDbClient)
                .build();

        addressExtractTable = dynamoDbEnhancedClient.table(TABLE_NAME, TableSchema.fromBean(AddressExtract.class));
        addressExtractTable.createTable();

        addressExtractRepository = new AddressExtractRepository(addressExtractTable);
    }

    @BeforeEach
    private void beforeEach() {
        dynamoDbClient.waiter().waitUntilTableExists(b -> b.tableName(addressExtractTable.tableName()));
    }

    @AfterEach
    private void afterEach() {
        addressExtractTable.deleteTable();
        addressExtractTable.createTable();
    }

    private int count() {
        ScanRequest request = ScanRequest.builder()
                .tableName(addressExtractTable.tableName())
                .select("COUNT").build();
        return dynamoDbClient.scan(request).count();
    }

    private void checkRawClientGetItem(String submissionId) {
        var item = dynamoDbClient.getItem(GetItemRequest.builder()
                .tableName(TABLE_NAME)
                .key(Map.of("submissionId", AttributeValue.fromS(submissionId)))
                .build()).item();
        assertThat(item.get("submissionId").s(), equalTo(submissionId));
    }

    @Test
    public void shouldSave() {
        AddressExtract addressExtract = AddressExtract.builder()
                .submissionId(submissionId)
                .formType(FormType.G28)
                .build();

        AddressExtract savedAddressExtract = addressExtractRepository.save(addressExtract);

        assertEquals(1, count());
        checkRawClientGetItem(submissionId);

        assertEquals(addressExtract, savedAddressExtract);
    }

    @Test
    public void shouldFindByIdShouldReturnEmptyWhenNotFound() {
        String TEST_SUBMISSION_ID_NOT_EXISTS = UUID.randomUUID().toString();

        Optional<AddressExtract> result = addressExtractRepository.getBySubmissionId(TEST_SUBMISSION_ID_NOT_EXISTS);

        assertFalse(result.isPresent());
    }

    @Test
    public void shouldDeleteById() {
        AddressExtract addressExtract = AddressExtract.builder().submissionId(submissionId).build();
        addressExtractRepository.save(addressExtract);
        addressExtractRepository.deleteBySubmissionId(submissionId);

        Optional<AddressExtract> addressExtractResult = addressExtractRepository.getBySubmissionId(submissionId);
        assertThat(addressExtractResult.isEmpty());
    }

    @Test
    public void shouldUpdate() {
        AddressExtract addressExtract = AddressExtract.builder().submissionId(submissionId).build();

        addressExtractRepository.save(addressExtract);
        AddressExtract originalAddressExtract = addressExtractRepository.getBySubmissionId(submissionId).get();
        addressExtract.setClientAddressOnForm(ClientAddress.builder()
                .cityOrTown("DC")
                .state("WA").build());

        addressExtractRepository.update(addressExtract);

        AddressExtract updatedAddressExtract = addressExtractRepository.getBySubmissionId(submissionId).get();

        assertThat(updatedAddressExtract).isNotEqualTo(originalAddressExtract);
        assertThat(updatedAddressExtract).isEqualTo(addressExtract);

        assertThat(count()).isEqualTo(1);
        checkRawClientGetItem(submissionId);
    }

}
