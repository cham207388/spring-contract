package gov.dhs.uscis.submissionservice.validators.i765;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.services.FeeService;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.fees.FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765Fees;
import gov.dhs.uscis.submissionservice.validators.i765.AbcBenefitsAppliedValidator;

@ExtendWith(MockitoExtension.class)
public class AbcBenefitsAppliedValidatorTest {

    @Mock
    SubmissionService submissionService;

    @Mock
    FeeService feeService;

    @InjectMocks
    private AbcBenefitsAppliedValidator validator;

    @Test
    void shouldCalculateFeeTotalAndUpdateSubmission() {
        String submissionId = "submissionId";
        boolean abcEligible = true;
        String reason = "1.a.";

        Submission expected = Submission.builder().feeTotal(I765Fees.FEE_470).userRequestedFeeWaiver(false).build();

        when(feeService.calculateFeeFor(FormType.I765, I765EligibilityCategory.C8,
                new I765FeeStrategyOptions(abcEligible, false, false, ReasonForFiling.INITIAL.toString(), false))).thenReturn(I765Fees.FEE_1030);

        validator.validate(expected, FormFields.builder().submissionId(submissionId)
                .abcBenefitsApplied(abcEligible).eligibilityCategory("C 8").reasonForApplySelection(reason).build());

        verify(submissionService, times(1)).updateFee(submissionId, I765Fees.FEE_1030);
    }

    @Test
    void shouldCalculateFeeTotalAndUpdateSubmissionOnlyForC8() {
        String submissionId = "submissionId";
        boolean abcEligible = true;

        Submission expected = Submission.builder().submissionId(submissionId).feeTotal(I765Fees.FEE_470).build();

        validator.validate(expected, FormFields.builder().submissionId(submissionId)
                .abcBenefitsApplied(abcEligible).eligibilityCategory("C 11").build());

        verify(submissionService, times(0)).updateFee(submissionId, I765Fees.FEE_470);
    }

    @Test
    void shouldCalculateFee550ForC8InitialNonSalvadorian() {
        String submissionId = "submissionId";
        boolean abcEligible = false;
        String reason = "1.a.";

        Submission expected = Submission.builder().feeTotal(I765Fees.FEE_EXEMPT).userRequestedFeeWaiver(false).build();

        when(feeService.calculateFeeFor(FormType.I765, I765EligibilityCategory.C8,
                new I765FeeStrategyOptions(abcEligible, false, false, ReasonForFiling.INITIAL.toString(), false))).thenReturn(I765Fees.FEE_560);

        validator.validate(expected, FormFields.builder().submissionId(submissionId)
                .abcBenefitsApplied(abcEligible).eligibilityCategory("C 08").reasonForApplySelection(reason).build());

        verify(feeService, times(1)).calculateFeeFor(any(FormType.class), any(I765EligibilityCategory.class), any(FeeStrategyOptions.class));
        verify(submissionService, times(1)).updateFee(submissionId, I765Fees.FEE_560);
    }

}
