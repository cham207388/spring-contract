package gov.dhs.uscis.submissionservice.controllers;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.get;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.restdocs.payload.JsonFieldType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.MimeType;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.EvidenceType;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.form.metadata.EligibilityCategory;
import gov.dhs.uscis.intake.models.form.metadata.FeeExemptQuestion;
import gov.dhs.uscis.intake.models.form.metadata.FormEdition;
import gov.dhs.uscis.intake.models.form.metadata.MetaData;
import gov.dhs.uscis.intake.models.form.metadata.Pages;
import gov.dhs.uscis.intake.models.form.metadata.SignaturePageMetadata;
import gov.dhs.uscis.intake.models.form.metadata.pages.CompleteYourForm;
import gov.dhs.uscis.intake.models.form.metadata.pages.ContentCategory;
import gov.dhs.uscis.submissionservice.configs.ObjectMapperConfiguration;
import gov.dhs.uscis.submissionservice.converters.SubmissionParameterConverter;
import gov.dhs.uscis.submissionservice.exception.SubmissionIndexException;
import gov.dhs.uscis.submissionservice.models.EligibilityCategoryResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.draftBenefits.AbleToFileResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AccountTypeResponse;
import gov.dhs.uscis.submissionservice.services.DraftBenefitsService;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.services.PeepsService;
import gov.dhs.uscis.submissionservice.services.SubmissionService;

@WebMvcTest(FormController.class)
@Import(ObjectMapperConfiguration.class)
@ExtendWith({ RestDocumentationExtension.class })
class FormControllerTest {

    static final String FORM_ID = "aabbcc-1234";
    static final String I765 = "I-765";
    static final String N400 = "N-400";
    static final String ELIGIBILITY_CATEGORY = "C11 - Parole";
    static final String ELIGIBILITY_CATEGORY_LABEL = "(c)(11) Parole";

    @Autowired
    private WebApplicationContext webApplicationContext;
    @Autowired
    private ObjectMapper mapper;

    private MockMvc mockMvc;

    @MockitoBean
    private SubmissionService service;

    @MockitoBean
    SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;

    @MockitoBean
    private FormService formService;

    @MockitoBean
    private DraftBenefitsService draftBenefitsService;

    @MockitoBean
    private PeepsService peepsService;

    private List<EvidenceGroup> expectedGroups = List.of(
            EvidenceGroup.builder().id("Applicant Photo")
                    .name("2\" x 2\" Photo of you")
                    .maxNumberOfFiles(1)
                    .allowMediaTypes(List.of(MimeType.valueOf("image/jpeg")))
                    .evidenceTypes(List.of(
                            EvidenceType.builder().id("Applicant Photo")
                                    .name("2\" x 2\" Photo of you")
                                    .build()))
                    .build());
    private FormMetaData expectedMetadata = FormMetaData.builder().formType(I765)
            .formDescription("Application for Employment Authorization").enabled(true).showBanner(false)
            .feeWaiverEnabled(true)
            .currentEdition("08/28/25")
            .representativeEnabled(true)
            .signaturePages(List.of(
                    SignaturePageMetadata.builder().entity(AccountType.APPLICANT).page(1).build(),
                    SignaturePageMetadata.builder().entity(AccountType.REPRESENTATIVE).page(1).build()))
            .editions(List
                    .of(FormEdition.builder().numberOfPages(7).edition("04/01/24").ombNo("12345")
                            .expires("09/30/2027")
                            .build()))
            .validations(
                    List.of(MetadataValidationEnum.CORE, MetadataValidationEnum.SIGNATURE,
                            MetadataValidationEnum.FORM_FIELDS))
            .eligibilityCategories(
                    List.of(EligibilityCategory.builder().category(ELIGIBILITY_CATEGORY)
                            .label(ELIGIBILITY_CATEGORY_LABEL).code(37)
                            .metaData(
                                    MetaData.builder()
                                            .feeWaivable(true)
                                            .feeExemptable(true)
                                            .evidenceGroups(expectedGroups)
                                            .feeExemptQuestions(List.of(
                                                    FeeExemptQuestion
                                                            .builder()
                                                            .question("What is your reason for applying?")
                                                            .answerRequired(
                                                                    "1a Initial permission to accept employment")
                                                            .build()))
                                            .build())
                            .build()))
            .landmarks(Map.of("signature_page_number", 11))
            .pages(Pages.builder()
                    .completeYourForm(CompleteYourForm.builder()
                            .title("Uploading Your Form Online")
                            .categories(List.of(ContentCategory.builder()
                                    .title("Filing by online PDF submission")
                                    .body("Filing online body")
                                    .build()))
                            .notices(List.of(ContentCategory.builder()
                                    .title("DHS Privacy Notice")
                                    .body("Privacy notice body")
                                    .build()))
                            .build())
                    .build())
            .build();
    private List<EligibilityCategoryResponse> categoryResponses = List
            .of(new EligibilityCategoryResponse(ELIGIBILITY_CATEGORY, true, true));

    @BeforeEach
    void setUp(RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders
                .webAppContextSetup(this.webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)).build();
    }

    @Test
    void shouldRetrieveFormMetadataWhenFound() throws Exception {
        when(formService.retrieveFormMetaData(I765)).thenReturn(expectedMetadata);

        ResultActions actions = this.mockMvc.perform(get("/api/v1/forms/{formType}/metadata", I765)
                .contentType(MediaType.APPLICATION_JSON));
        FormMetaData actual = this.mapper.readValue(actions.andReturn().getResponse().getContentAsString(),
                FormMetaData.class);

        assertEquals(expectedMetadata, actual);

        actions
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pages.completeYourForm.title").value("Uploading Your Form Online"))
                .andExpect(jsonPath("$.pages.completeYourForm.categories[0].title").value("Filing by online PDF submission"))
                .andExpect(jsonPath("$.pages.completeYourForm.notices[0].title").value("DHS Privacy Notice"));
    }

    @Test
    void shouldRetrieveNotFoundWhenFormMetadataNotFound() throws Exception {
        this.mockMvc.perform(get("/api/v1/forms/{formType}/metadata", I765))
                .andExpect(status().isNotFound())
                .andDo(document("retrieve_formMetaData"));
    }

    @Test
    void shouldRetrieveEvidenceGroupsWhenFoundForFormAndCategory() throws Exception {
        when(formService.retrieveEvidenceGroups(I765, ELIGIBILITY_CATEGORY))
                .thenReturn(this.expectedGroups);

        FieldDescriptor[] evidenceGroupFieldDescriptors = new FieldDescriptor[] {
                fieldWithPath("id").description("The evidence id"),
                fieldWithPath("name").description("The name of the evidence group"),
                fieldWithPath("maxNumberOfFiles")
                        .description("The maximum number of files per evidence group"),
                fieldWithPath("validations").description("Validations for evidence group"),
                fieldWithPath("allowMediaTypes")
                        .description("TThe allowed content type for evidence files"),
                fieldWithPath("evidenceTypes")
                        .description("The name of the evidence group"),
                fieldWithPath("evidenceTypes[].id")
                        .description("The id of the evidence type"),
                fieldWithPath("evidenceTypes[].name")
                        .description("The name of the evidence type"),
                fieldWithPath("evidenceTypes[].contentCategoryCode")
                        .description("The ELIS code associated with the evidence type, possibly null")
                        .type(JsonFieldType.NUMBER),
        };

        ResultActions actions = this.mockMvc
                .perform(get("/api/v1/forms/{formType}/metadata/{eligibilityCategory}/evidence",
                        I765, ELIGIBILITY_CATEGORY)
                        .contentType(MediaType.APPLICATION_JSON));

        List<EvidenceGroup> actual = this.mapper.readValue(
                actions.andReturn().getResponse().getContentAsString(),
                this.mapper.getTypeFactory().constructCollectionType(List.class, EvidenceGroup.class));
        assertEquals(this.expectedGroups, actual);

        actions.andExpect(status().isOk())
                .andDo(document("retrieve_evidencesGroups",
                        pathParameters(
                                parameterWithName("formType").description(
                                        "Type of form to retrieve evidence for"),
                                parameterWithName("eligibilityCategory")
                                        .description("Eligibility Category to retrieve evidence for")),
                        responseFields(
                                fieldWithPath("[]")
                                        .description("List of evidence groups"))
                                .andWithPrefix("[].", evidenceGroupFieldDescriptors)));
    }

    @Test
    void shouldRetrieveNotFoundWhenCategoryAndFormDoNotReturnAnyEvidenceGroup() throws Exception {
        when(formService.retrieveEvidenceGroups(I765, ELIGIBILITY_CATEGORY)).thenReturn(null);
        this.mockMvc
                .perform(get("/api/v1/forms/{formType}/metadata/{eligibilityCategory}/evidence",
                        I765,
                        ELIGIBILITY_CATEGORY))
                .andExpect(status().isNotFound())
                .andDo(document("retrieve_evidencesGroups"));
    }

    @Test
    void shouldReturnAListOfEligibilityCategoriesForAFormType() throws Exception {
        when(formService.retrieveEligibilityCategories(I765)).thenReturn(this.categoryResponses);

        ResultActions actions = this.mockMvc
                .perform(get("/api/v1/forms/{formType}/eligibilityCategories", I765)
                        .contentType(MediaType.APPLICATION_JSON));

        List<EligibilityCategoryResponse> actual = this.mapper.readValue(
                actions.andReturn().getResponse().getContentAsString(),
                this.mapper.getTypeFactory().constructCollectionType(List.class,
                        EligibilityCategoryResponse.class));

        assertEquals(this.categoryResponses, actual);

        FieldDescriptor[] eligibilityCategoriesFieldDescriptors = new FieldDescriptor[] {
                fieldWithPath("category").description("The name of the category"),
                fieldWithPath("feeWaivable")
                        .description("True if the fee for this category is waivable"),
                fieldWithPath("feeExemptable")
                        .description("True if the fee for this category is exemptible") };

        actions.andExpect(status().isOk())
                .andDo(document("retrieve eligibility_categories",
                        pathParameters(
                                parameterWithName("formType").description(
                                        "Type of form to retrieve evidence for")),
                        responseFields(fieldWithPath("[]")
                                .description("The list of eligibility categories"))
                                .andWithPrefix("[].",
                                        eligibilityCategoriesFieldDescriptors)));
    }

    @Test
    void shouldReturnAListOfEvidenceGroupValidations() throws Exception {
        String eligibility = I765EligibilityCategory.A12.getCategory();
        String groupId = "groupId";

        List<MetadataValidationEnum> validations = List.of(MetadataValidationEnum.NOA);
        when(formService.retrieveEvidenceGroupValidations(I765, eligibility, groupId))
                .thenReturn(validations);

        ResultActions actions = this.mockMvc
                .perform(get(
                        "/api/v1/forms/{formType}/metadata/{eligibilityCategory}/evidence/{evidenceGroupType}/validations",
                        I765, eligibility, groupId)
                        .contentType(MediaType.APPLICATION_JSON));

        List<EligibilityCategoryResponse> actual = this.mapper.readValue(
                actions.andReturn().getResponse().getContentAsString(),
                this.mapper.getTypeFactory().constructCollectionType(List.class,
                        MetadataValidationEnum.class));

        assertEquals(validations, actual);

        actions.andExpect(status().isOk())
                .andDo(document("retrieve evidence group validations",
                        pathParameters(
                                parameterWithName("formType")
                                        .description("Type of form to retrieve eligibility category for"),
                                parameterWithName("eligibilityCategory")
                                        .description("Eligibility category to fetch evidence group for"),
                                parameterWithName("evidenceGroupType")
                                        .description("Evidence group to fetch validations for")),
                        responseFields(fieldWithPath("[]")
                                .description("The list of validations"))));
    }

    @Test
    void shouldReturnUserCanFileForFormApplicant() throws Exception {
        String myUscisId = UUID.randomUUID().toString();

        when(peepsService.retrieveAccountType(myUscisId))
                .thenReturn(AccountTypeResponse.builder().accountType(AccountType.APPLICANT).build());
        when(formService.retrieveFormMetaData(I765))
                .thenReturn(FormMetaData.builder().formType(I765).representativeEnabled(false).build());
        when(draftBenefitsService.canApplicantFileFor(I765, myUscisId)).thenReturn(true);
        when(formService.canClientFile(myUscisId, I765)).thenReturn(true);

        ResultActions actions = this.mockMvc
                .perform(get("/api/v1/forms/{formType}/ableToFile/{myUscisId}", I765, myUscisId)
                        .contentType(MediaType.APPLICATION_JSON));

        AbleToFileResponse actual = this.mapper.readValue(
                actions.andReturn().getResponse().getContentAsString(),
                AbleToFileResponse.class);

        assertThat(actual.result()).isTrue();

        actions.andExpect(status().isOk())
                .andDo(document("retrieve if user is able to file from myUSCIS",
                        pathParameters(
                                parameterWithName("formType")
                                        .description("Type of form to retrieve eligibility category for"),
                                parameterWithName("myUscisId")
                                        .description("UUID for logged in user")),
                        responseFields(
                                fieldWithPath("result")
                                        .description("Whether the user is able to file for the specified form type")
                                        .type(JsonFieldType.BOOLEAN))));
    }

    @Test
    void shouldReturnUserCannotFileForFormApplicant() throws Exception {
        String myUscisId = UUID.randomUUID().toString();

        when(peepsService.retrieveAccountType(myUscisId))
                .thenReturn(AccountTypeResponse.builder().accountType(AccountType.APPLICANT).build());
        when(formService.retrieveFormMetaData(N400))
                .thenReturn(FormMetaData.builder().formType(N400).representativeEnabled(false).build());
        when(draftBenefitsService.canApplicantFileFor(N400, myUscisId)).thenReturn(false);
        when(formService.canClientFile(myUscisId, N400)).thenReturn(true);

        ResultActions actions = this.mockMvc
                .perform(get("/api/v1/forms/{formType}/ableToFile/{myUscisId}", N400, myUscisId)
                        .contentType(MediaType.APPLICATION_JSON));

        AbleToFileResponse actual = this.mapper.readValue(
                actions.andReturn().getResponse().getContentAsString(),
                AbleToFileResponse.class);

        assertThat(actual.result()).isFalse();
    }

    @Test
    void shouldReturnUserCannotFileForFormApplicantDueToDraft() throws Exception {
        String myUscisId = UUID.randomUUID().toString();

        when(peepsService.retrieveAccountType(myUscisId))
                .thenReturn(AccountTypeResponse.builder().accountType(AccountType.APPLICANT).build());
        when(formService.retrieveFormMetaData(N400))
                .thenReturn(FormMetaData.builder().formType(N400).representativeEnabled(false).build());
        when(draftBenefitsService.canApplicantFileFor(N400, myUscisId)).thenReturn(true);
        when(formService.canClientFile(myUscisId, N400)).thenReturn(false);

        ResultActions actions = this.mockMvc
                .perform(get("/api/v1/forms/{formType}/ableToFile/{myUscisId}", N400, myUscisId)
                        .contentType(MediaType.APPLICATION_JSON));

        AbleToFileResponse actual = this.mapper.readValue(
                actions.andReturn().getResponse().getContentAsString(),
                AbleToFileResponse.class);

        assertThat(actual.result()).isFalse();
    }

    @Test
    void shouldReturnUserCannotFileForFormAsRepresentativeDueToRepresentativeEnabledFlagOff() throws Exception {
        String myUscisId = UUID.randomUUID().toString();

        when(peepsService.retrieveAccountType(myUscisId))
                .thenReturn(AccountTypeResponse.builder().accountType(AccountType.REPRESENTATIVE).build());
        when(formService.retrieveFormMetaData(I765))
                .thenReturn(FormMetaData.builder().formType(I765).representativeEnabled(false).build());
        when(draftBenefitsService.canApplicantFileFor(I765, myUscisId)).thenReturn(true);
        when(formService.canClientFile(myUscisId, I765)).thenReturn(true);

        ResultActions actions = this.mockMvc
                .perform(get("/api/v1/forms/{formType}/ableToFile/{myUscisId}", I765, myUscisId)
                        .contentType(MediaType.APPLICATION_JSON));

        AbleToFileResponse actual = this.mapper.readValue(
                actions.andReturn().getResponse().getContentAsString(),
                AbleToFileResponse.class);

        assertThat(actual.result()).isFalse();

        actions.andExpect(status().isOk())
                .andDo(document("retrieve if user is able to file from myUSCIS",
                        pathParameters(
                                parameterWithName("formType")
                                        .description("Type of form to retrieve eligibility category for"),
                                parameterWithName("myUscisId")
                                        .description("UUID for logged in user")),
                        responseFields(
                                fieldWithPath("result")
                                        .description("Whether the user is able to file for the specified form type")
                                        .type(JsonFieldType.BOOLEAN))));
    }

    @Test
    void shouldReturnUserCanFileI765() throws Exception {
        String myUscisId = UUID.randomUUID().toString();

        when(peepsService.retrieveAccountType(myUscisId))
                .thenReturn(AccountTypeResponse.builder().accountType(AccountType.APPLICANT).build());
        when(formService.retrieveFormMetaData(I765))
                .thenReturn(FormMetaData.builder().formType(I765).representativeEnabled(true).build());
        when(draftBenefitsService.canApplicantFileFor(I765, myUscisId)).thenReturn(true);
        when(formService.canClientFile(myUscisId, I765)).thenReturn(true);

        ResultActions actions = this.mockMvc
                .perform(get("/api/v1/forms/{formType}/ableToFile/{myUscisId}", I765, myUscisId)
                        .contentType(MediaType.APPLICATION_JSON));

        AbleToFileResponse actual = this.mapper.readValue(
                actions.andReturn().getResponse().getContentAsString(),
                AbleToFileResponse.class);

        assertThat(actual.result()).isTrue();
    }

    @Test
    void shouldRetrieveConcurrentForms() throws Exception {
        String formType = FormType.I485.getType();
        List<String> concurrentFormTypes = List.of(FormType.I485A.getType(), FormType.I131.getType());
        when(formService.retrieveConcurrentForms(formType)).thenReturn(concurrentFormTypes);

        ResultActions actions = this.mockMvc
                .perform(get("/api/v1/forms/{formType}/concurrentForms", formType)
                        .contentType(MediaType.APPLICATION_JSON));

        List<String> actual = this.mapper.readValue(
                actions.andReturn().getResponse().getContentAsString(),
                this.mapper.getTypeFactory().constructCollectionType(List.class,
                        String.class));

        assertEquals(concurrentFormTypes, actual);
    }

}