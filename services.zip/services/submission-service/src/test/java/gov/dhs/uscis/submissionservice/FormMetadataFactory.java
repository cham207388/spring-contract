package gov.dhs.uscis.submissionservice;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.MimeType;

import gov.dhs.uscis.intake.models.form.metadata.MetaData;
import gov.dhs.uscis.intake.models.form.metadata.Pages;
import gov.dhs.uscis.intake.models.form.metadata.pages.AccordionCategory;
import gov.dhs.uscis.intake.models.form.metadata.pages.ContentCategory;
import gov.dhs.uscis.intake.models.form.metadata.pages.ContentSection;
import gov.dhs.uscis.intake.models.form.metadata.pages.DropdownContent;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.EvidenceType;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.form.metadata.EligibilityCategory;
import gov.dhs.uscis.intake.models.form.metadata.FeeExemptQuestion;
import gov.dhs.uscis.intake.models.form.metadata.FormEdition;

public class FormMetadataFactory {

    public static FormMetaData getFormMetadata() {

  /*
         * String formType;
            String formDescription;
            Boolean showBanner;
            Boolean enabled;
            List<FormEdition> editions;
            List<MetadataValidationEnum> validations;
            List<EligibilityCategory> eligibilityCategories;
            Pages pages;
            Map<String, Integer> landmarks;
        *
        */

        FormEdition editions = new FormEdition();
        editions.setNumberOfPages(0);
        editions.setExpires("string");
        editions.setEdition("string");
        editions.setOmbNo("string");

        List<MetadataValidationEnum> validations = Arrays.asList(MetadataValidationEnum.CORE);

        EligibilityCategory eligibilityCategories = new EligibilityCategory();
        MetaData metadata = new MetaData();
        EvidenceGroup evidenceGroup = new EvidenceGroup();
        FeeExemptQuestion feeExemptQuestion = new FeeExemptQuestion();
        EvidenceType evidenceType = new EvidenceType();
        MimeType allowMediaTypes = new MimeType("null");

        eligibilityCategories.setCategory("string");
        eligibilityCategories.setLabel("string");
        eligibilityCategories.setCode(0);
        metadata.setFeeWaivable(true);
        metadata.setFeeExemptable(true);
        evidenceGroup.setId("string");
        evidenceGroup.setName("string");
        evidenceType.setId("string");
        evidenceType.setName("string");
        evidenceType.setContentCategoryCode(0);
        evidenceGroup.setEvidenceTypes(List.of(evidenceType));
        evidenceGroup.setValidations(validations);
        evidenceGroup.setMaxNumberOfFiles(0);
        evidenceGroup.setAllowMediaTypes(List.of(allowMediaTypes));
        feeExemptQuestion.setQuestion("question");
        feeExemptQuestion.setAnswerRequired("answer");
        metadata.setEvidenceGroups(List.of(evidenceGroup));
        metadata.setFeeExemptQuestions(List.of(feeExemptQuestion));
        eligibilityCategories.setMetaData(metadata);

        Pages pages = new Pages();
        ContentSection beforeYouStart = new ContentSection();
        DropdownContent eligibility = new DropdownContent();
        ContentCategory beforeYouStartCategories = new ContentCategory();
        ContentCategory afterYouFileCategories = new ContentCategory();
        AccordionCategory accordionCategory = new AccordionCategory();
        beforeYouStart.setTitle("string");
        beforeYouStart.setDescription("string");
        beforeYouStartCategories.setTitle("string");
        beforeYouStartCategories.setBody("string");
        beforeYouStartCategories.setIcon("string");
        accordionCategory.setTitle("string");
        accordionCategory.setId("string");
        accordionCategory.setBody("string");
        beforeYouStartCategories.setAccordionCategories(List.of(accordionCategory));
        beforeYouStart.setBeforeYouStartCategories(List.of(beforeYouStartCategories));
        afterYouFileCategories.setTitle("string");
        afterYouFileCategories.setBody("string");
        afterYouFileCategories.setIcon("string");
        afterYouFileCategories.setAccordionCategories(List.of(accordionCategory));
        beforeYouStart.setAfterYouFileCategories(List.of(afterYouFileCategories));
        eligibility.setHeader("header");
        pages.setBeforeYouStart(beforeYouStart);
        pages.setEligibility(eligibility);

        Map<String, Integer> landmarks = new HashMap<>();
        landmarks.put("additionalProps1", 0);

        return FormMetaData.builder()
            .formType(FormType.I765.getType())
            .formDescription("string")
            .showBanner(true)
            .enabled(true)
            .editions(List.of(editions))
            .validations(validations)
            .eligibilityCategories(List.of(eligibilityCategories))
            .pages(pages)
            .landmarks(landmarks)
            .build();
    }

}
