package gov.dhs.uscis.submissionservice;

import static gov.dhs.uscis.intake.entities.submission.SubmissionState.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.*;
import static org.springframework.http.MediaType.*;

import java.util.UUID;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(webEnvironment = RANDOM_PORT, properties = {
    "application.security.enforce.oauth=true",
})
@AutoConfigureWebTestClient(timeout = "PT30S")
public class SecurityConfigurationTest extends BaseJourneyTest {
    
    private String myUscisId = UUID.randomUUID().toString();

    /* Do not use BaseJourneyTest.client, it is configured with JWT */
    @Autowired
    private WebTestClient client; 

    @Test
    @Disabled
    public void contextLoads () {}

    @Test
    public void getAllSubmissions_shouldPermitAll () throws Exception {
        client.get().uri("/api/v1/{myUscisId}/submissions?filters={filters}", myUscisId, DRAFT.name())
            .exchange()
            .expectStatus().isOk(); // returns 404 for zero results
    }

    /* Negative case to verify we didn't break security */
    @Test
    public void createSubmission_shouldBeUnauthorized () throws Exception {
        client.post().uri("/api/v1/{myUscisId}/submissions", myUscisId)
            .exchange()
            .expectStatus().isUnauthorized();
    }

    @Test
    public void getSubmissionByManifestId_shouldPermitAll () throws Exception {
        client.get().uri("/api/v1/submissions/manifest/{manifestId}", UUID.randomUUID().toString())
            .exchange()
            .expectStatus().isNotFound(); // returns 404 for zero results
    }

    @Test
    public void swagger_shouldPermitAll () throws Exception {
        client.get().uri("/swagger-ui/index.html")
            .exchange()
            .expectStatus().isOk()
            .expectHeader().contentType(TEXT_HTML);

        client.get().uri("/v3/api-docs")
            .exchange()
            .expectStatus().isOk()
            .expectHeader().contentType(APPLICATION_JSON);
    }
}
