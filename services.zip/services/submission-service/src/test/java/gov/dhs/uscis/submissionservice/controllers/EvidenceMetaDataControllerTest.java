package gov.dhs.uscis.submissionservice.controllers;

import static org.mockito.Mockito.when;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Map;
import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import gov.dhs.uscis.intake.models.core.metadata.EvidencePages;
import gov.dhs.uscis.intake.models.dto.EvidenceData;
import gov.dhs.uscis.submissionservice.configs.ObjectMapperConfiguration;
import gov.dhs.uscis.submissionservice.converters.SubmissionParameterConverter;
import gov.dhs.uscis.submissionservice.services.EvidenceMetaDataService;
import gov.dhs.uscis.submissionservice.services.SubmissionService;

@WebMvcTest(EvidenceMetaDataController.class)
@Import(ObjectMapperConfiguration.class)
@ExtendWith({ RestDocumentationExtension.class })
public class EvidenceMetaDataControllerTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    private final String URL = "/api/v1/metadata/evidence/test-evidence-id";

    @MockitoBean
    private EvidenceMetaDataService service;
    @MockitoBean
    private SubmissionService submissionService;
    @MockitoBean
    SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;

    @BeforeEach
    void setUp(RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders
                .webAppContextSetup(this.webApplicationContext)
                .apply(documentationConfiguration(restDocumentation)).build();
    }

    @Test
    void shouldRetrieveEvidenceMetadataWhenFound() throws Exception {
        EvidencePages evidencePages = Instancio.create(EvidencePages.class);
        EvidenceData expected = EvidenceData.builder()
                .evidencePages(Map.of("pageContents", evidencePages))
                .build();
        when(service.getEvidenceMetaData(ArgumentMatchers.anyString())).thenReturn(expected);

        ResultActions actions = this.mockMvc.perform(get(URL)
                .contentType(MediaType.APPLICATION_JSON));

        actions
                .andExpect(status().isOk());
    }

    @Test
    void shouldThrowWhenEvidenceMetadataNotFound() throws Exception {
        when(service.getEvidenceMetaData(ArgumentMatchers.anyString())).thenReturn(null);

        ResultActions actions = this.mockMvc.perform(get(URL)
                .contentType(MediaType.APPLICATION_JSON));

        actions
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldThrowWhenEvidenceMetadataIsEmpty() throws Exception {
        EvidenceData expected = EvidenceData.builder()
                .evidencePages(null).build();
        when(service.getEvidenceMetaData(ArgumentMatchers.anyString())).thenReturn(expected);

        ResultActions actions = this.mockMvc.perform(get(URL)
                .contentType(MediaType.APPLICATION_JSON));
        actions
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldThrowWhenEvidenceMetadataPageContentIsEmpty() throws Exception {
        EvidenceData expected = EvidenceData.builder()
                .evidencePages(Map.of())
                .build();
        when(service.getEvidenceMetaData(ArgumentMatchers.anyString())).thenReturn(expected);

        ResultActions actions = this.mockMvc.perform(get(URL)
                .contentType(MediaType.APPLICATION_JSON));
        actions
                .andExpect(status().isNotFound());
    }

}