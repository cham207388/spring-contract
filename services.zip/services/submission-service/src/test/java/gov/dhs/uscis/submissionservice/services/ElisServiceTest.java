package gov.dhs.uscis.submissionservice.services;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.submissionservice.models.elis.ElisPhotoValidationError;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;

public class ElisServiceTest {

    public static MockWebServer mockElis;
    public ElisService service;

    @BeforeAll
    static void setUp() throws IOException {
        mockElis = new MockWebServer();
        mockElis.start();
    }

    @BeforeEach
    void initialize() {
        service = new ElisService(WebClient.create(String.format("http://localhost:%s", mockElis.getPort())));
    }

    @AfterAll
    static void tearDown() throws IOException {
        mockElis.shutdown();
    }

    @Test
    void shouldValidatePhoto_Success() {
        mockElis.enqueue(new MockResponse().setResponseCode(200));
        Resource file = new InputStreamResource(new ByteArrayInputStream("Hello World".getBytes()));
        ResponseEntity<Void> response = service.validatePhoto(MediaType.IMAGE_JPEG, file);

        assertTrue(response.getStatusCode().is2xxSuccessful());

        try {
            RecordedRequest recordedRequest = mockElis.takeRequest();
            assertEquals("POST", recordedRequest.getMethod());
            assertEquals(ElisService.CASE_PHOTO_VALIDATE_PATH, recordedRequest.getPath());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    void shouldValidatePhoto_Fail() throws JsonProcessingException {
        var objectMapper = new ObjectMapper();
        ElisPhotoValidationError expectedErrorA = new ElisPhotoValidationError("PVS-400-6",
                "There may be too much contrast among the subject's facial features.", "6099875937189135936",
                "even_lighting_contrast");
        ElisPhotoValidationError expectedErrorB = new ElisPhotoValidationError("PVS-400-10",
                "The photo is not square in shape and may need to be cropped.", "6099875937189135936",
                "square_aspect_ratio");
        mockElis.enqueue(new MockResponse().setResponseCode(400)
                .setBody(objectMapper.writeValueAsString(List.of(expectedErrorA, expectedErrorB))));
        Resource file = new InputStreamResource(new ByteArrayInputStream("Hello World".getBytes()));

        WebClientResponseException thrownException = assertThrows(WebClientResponseException.class,
                () -> service.validatePhoto(MediaType.IMAGE_JPEG, file));

        String responseBody = thrownException.getResponseBodyAsString();
        List<ElisPhotoValidationError> errors = objectMapper.readValue(responseBody,
                new TypeReference<List<ElisPhotoValidationError>>() {
                });

        assertFalse(errors.isEmpty());
        assertTrue(errors.contains(expectedErrorA));
        assertTrue(errors.contains(expectedErrorB));
    }

}
