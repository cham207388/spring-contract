package gov.dhs.uscis.submissionservice.components;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ELISValidationResponse;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.WatermarkerStatus;
import gov.dhs.uscis.intake.models.additionalinformation.I131AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I485AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I907AdditionalInformation;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I907FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ToggleService;
import jakarta.jms.JMSException;
import jakarta.jms.TextMessage;
import software.amazon.awssdk.services.sqs.SqsClient;

@ExtendWith(MockitoExtension.class)
class ElisValidationResponseListenerTest {

    @Mock
    ValidationStatusRepository mockValidationStatusDAO;

    @Mock
    SubmissionRepository submissionDAO;

    @Mock
    SqsClient mockSqsClient;

    @Mock
    ToggleService toggleService;

    @Mock
    SubmissionService submissionService;

    @InjectMocks
    ElisValidationResponseListener listener;

    @Before
    public void setUp() {
    	when(toggleService.isToggleActive(eq(ToggleEnum.PFVS_I912), anyString())).thenReturn(false);
    }

    @Test
    void shouldUpdateValidationStatus() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType("I-131")
        		.pass(true)
        		.results(Arrays.asList(status))
        		.fee(new BigDecimal(100.0))
        		.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(Optional.of(Submission.builder().build()));

        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionDAO).save(any(Submission.class));
    }

    @Test
    void shouldUpdateValidationStatusForI907EsignFlow() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
			.submissionId(submissionId)
			.formId(formId)
			.validator(ValidatorEnum.ESIGN)
			.status(ValidationResultEnum.PASS)
			.failureReasons(new ArrayList<>())
			.build();
        List<ValidationStatus> validations = new ArrayList<>(Arrays.asList(status));

		ELISValidationResponse response = ELISValidationResponse.builder()
				.formId(formId)
				.submissionId(submissionId)
				.pass(true)
				.results(validations)
				.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(response));
        when(submissionDAO.getById(submissionId)).thenReturn(Optional.of(Submission.builder().build()));

        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionDAO).save(any(Submission.class));
    }

    @Test
    void shouldUpdateAttestationStatus() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.ESIGN)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType("I-131")
        		.pass(true)
        		.results(Arrays.asList(status))
        		.fee(new BigDecimal(100.0))
        		.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(
        		Optional.of(Submission
        						.builder()
        						.forms(Arrays.asList(
        								SubmissionForm
        								.builder()
        								.id(formId)
        								.attestationStatus(WatermarkerStatus.StatusEnum.IN_PROGRESS
        								).build()))
        						.userRequestedFeeWaiver(false)
                                .formType(FormType.I131)
        						.build()));

        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);

        ArgumentCaptor<Submission> submissionJail = ArgumentCaptor.forClass(Submission.class);
        verify(submissionDAO).save(submissionJail.capture());

        assertEquals(WatermarkerStatus.StatusEnum.SUCCESS, submissionJail.getValue().getForms().get(0).getAttestationStatus());
    }

    @Test
    void shouldUpdateValidationStatusCouldntFindSubmission() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType("I-131")
        		.pass(true)
        		.results(Arrays.asList(status))
        		.fee(new BigDecimal(100.0))
        		.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(Optional.empty());

        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionDAO, times(0)).save(any(Submission.class));
    }

    @Test
    void shouldUpdateValidationStatusNoFeeCalculatedS() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType("I-131")
        		.pass(true)
        		.results(Arrays.asList(status))
        		.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(Optional.empty());

        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionDAO, times(0)).save(any(Submission.class));
    }

    @Test
    void shouldUpdateFormFeeAndCalculateTotalFee() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String i131FormId = UUID.randomUUID().toString();
        String g28FormId = UUID.randomUUID().toString();

        SubmissionForm i131Form = SubmissionForm.builder()
            .id(i131FormId)
            .feeTotal(BigDecimal.valueOf(400.00))
            .build();

        SubmissionForm g28Form = SubmissionForm.builder()
            .id(g28FormId)
            .build();


        Optional<Submission> submission = Optional.of(Submission.builder()
            .forms(List.of(i131Form, g28Form))
            .userRequestedFeeWaiver(false)
            .formType(FormType.I131)
            .build());

        ValidationStatus status = ValidationStatus.builder()
                .formId(g28FormId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(g28FormId)
        		.submissionId(submissionId)
        		.formType("G-28")
        		.pass(true)
        		.results(Arrays.asList(status))
                .fee(BigDecimal.valueOf(100.00))
                .submissionFees(Map.of("I-131", i131Form.getFeeTotal()))
        		.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(submission);

        listener.onMessage(passValidationMessage);

        assertEquals(BigDecimal.valueOf(500.00), submission.get().getFeeTotal());
    }

    @Test
    void shouldUpdateParentFormFee() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String i131FormId = UUID.randomUUID().toString();
        String g28FormId = UUID.randomUUID().toString();

        SubmissionForm i131Form = SubmissionForm.builder()
            .id(i131FormId)
            .feeTotal(BigDecimal.valueOf(0.00))
            .type("I-131")
            .build();

        SubmissionForm g28Form = SubmissionForm.builder()
            .id(g28FormId)
            .type("G-28")
            .build();


        Optional<Submission> submission = Optional.of(Submission.builder()
            .forms(List.of(i131Form, g28Form))
            .userRequestedFeeWaiver(false)
            .formType(FormType.I131)
            .build());

        ValidationStatus status = ValidationStatus.builder()
                .formId(g28FormId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(g28FormId)
        		.submissionId(submissionId)
        		.formType("G-28")
        		.pass(true)
        		.results(Arrays.asList(status))
                .fee(BigDecimal.valueOf(100.00))
                .submissionFees(Map.of("I-131", BigDecimal.valueOf(400.00)))
        		.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(submission);

        listener.onMessage(passValidationMessage);

        assertEquals(BigDecimal.valueOf(400.00), submission.get().getForms().get(0).getFeeTotal());
    }

    @Test
    void shouldAddHR1FeeForI131WithEADandRequestedWaiver() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String i131FormId = UUID.randomUUID().toString();
        I131AdditionalInformation i131AdditionalInfo = new I131AdditionalInformation();
        i131AdditionalInfo.setRequestedEAD(true);

        SubmissionForm i131Form = SubmissionForm.builder()
            .id(i131FormId)
            .feeTotal(BigDecimal.valueOf(400.00))
            .type("I-131")
            .build();

        Optional<Submission> submission = Optional.of(Submission.builder()
            .forms(List.of(i131Form))
            .formType(FormType.I131)
            .userRequestedFeeWaiver(true)
            .build());

        ValidationStatus status = ValidationStatus.builder()
                .formId(i131FormId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(i131FormId)
        		.submissionId(submissionId)
        		.formType("I-131")
        		.pass(true)
        		.results(Arrays.asList(status))
                .fee(BigDecimal.valueOf(100.00))
                .submissionFees(Map.of("I-131", BigDecimal.valueOf(400.00)))
                .additionalInfo(i131AdditionalInfo)
        		.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(submission);

        listener.onMessage(passValidationMessage);

        assertEquals(BigDecimal.valueOf(400.00), submission.get().getForms().get(0).getFeeTotal());
    }

    @Test
    void shouldOverrideCalculatedFeeWithProvidedTotalFee() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String i131FormId = UUID.randomUUID().toString();
        I131AdditionalInformation i131AdditionalInfo = new I131AdditionalInformation();
        i131AdditionalInfo.setRequestedEAD(true);

        BigDecimal expectedFee = BigDecimal.valueOf(12345.67);

        SubmissionForm i131Form = SubmissionForm.builder()
            .id(i131FormId)
            .feeTotal(BigDecimal.valueOf(400.00))
            .type("I-131")
            .build();

        Optional<Submission> submission = Optional.of(Submission.builder()
            .forms(List.of(i131Form))
            .formType(FormType.I131)
            .userRequestedFeeWaiver(false)
            .build());

        ValidationStatus status = ValidationStatus.builder()
                .formId(i131FormId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(i131FormId)
        		.submissionId(submissionId)
        		.formType("I-131")
        		.pass(true)
        		.results(Arrays.asList(status))
                .fee(BigDecimal.valueOf(100.00))
                .submissionFees(Map.of("I-131", BigDecimal.valueOf(400.00)))
                .additionalInfo(i131AdditionalInfo)
                .totalFee(expectedFee)
        		.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(submission);

        listener.onMessage(passValidationMessage);

        assertEquals(expectedFee, submission.get().getFeeTotal());
    }

    @Test
    void shouldUpdateFormWhenFeeTotalIsZero() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String i485FormId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(i485FormId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        SubmissionForm i485Form = SubmissionForm.builder()
            .id(i485FormId)
            .feeTotal(BigDecimal.ZERO)
            .build();

        Optional<Submission> submission = Optional.of(Submission.builder()
            .forms(List.of(i485Form))
            .userRequestedFeeWaiver(false)
            .formType(FormType.I485)
            .build());



        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(i485FormId)
        		.submissionId(submissionId)
        		.formType("I-485")
        		.pass(true)
        		.results(List.of(status))
                .fee(BigDecimal.ZERO)
                .totalFee(BigDecimal.ZERO)
                .submissionFees(Map.of("I-485", i485Form.getFeeTotal()))
        		.build();

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(submission);
        when(toggleService.isToggleActive(ToggleEnum.PFVS_I912, "I-485")).thenReturn(false);
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, "I-485")).thenReturn(true);

        listener.onMessage(passValidationMessage);

        verify(submissionService).cleanupFeeWaiverForFeeExemptSubmission(any(Submission.class));
    }

        @Test
    void shouldSetFormSpecificInfoForI485() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        boolean under14 = true;
        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        I485AdditionalInformation i485AdditionalInfo = new I485AdditionalInformation();
        i485AdditionalInfo.setUnder14(under14);
        I485FormSpecificInfo i485FormSpecificInfo = new I485FormSpecificInfo();
        i485FormSpecificInfo.setUnder14(under14);

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType(FormType.I485.getType())
        		.pass(true)
        		.results(Arrays.asList(status))
        		.fee(new BigDecimal(100.0))
                .additionalInfo(i485AdditionalInfo)
        		.build();


        Optional<Submission> existingSubmission = Optional.of(Submission.builder()
                .formType(FormType.I485)
                .forms(Arrays.asList(SubmissionForm.builder()
                    .id(formId)
                    .formSpecificInfo(i485FormSpecificInfo)
                    .build()))
                .userRequestedFeeWaiver(false)
                .formSpecificInfo(i485FormSpecificInfo)
                .build());

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(existingSubmission);

        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionDAO).save(any(Submission.class));
        assertNotNull(existingSubmission.get().getFormSpecificInfo());
        assertEquals(under14, ((I485FormSpecificInfo) existingSubmission.get().getFormSpecificInfo()).isUnder14());
    }

    // Note this scenario should never happen in teh front end
               @Test
    void shouldSetFormSpecificInfoForI485AndFormSpecificInfoIsWrongType() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        boolean under14 = true;
        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        I485AdditionalInformation i485AdditionalInfo = new I485AdditionalInformation();
        i485AdditionalInfo.setUnder14(under14);

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType(FormType.I485.getType())
        		.pass(true)
        		.results(Arrays.asList(status))
        		.fee(new BigDecimal(100.0))
                .additionalInfo(i485AdditionalInfo)
        		.build();


        Optional<Submission> existingSubmission = Optional.of(Submission.builder()
                .formType(FormType.I485)
                .forms(Arrays.asList(SubmissionForm.builder()
                    .id(formId)
                    .build()))
                .formSpecificInfo(new I907FormSpecificInfo())
                .userRequestedFeeWaiver(false)
                .build());

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(existingSubmission);

        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionDAO).save(any(Submission.class));
        assertNotNull(existingSubmission.get().getFormSpecificInfo());
        boolean isCorrectType = existingSubmission.get().getFormSpecificInfo() instanceof I485FormSpecificInfo;
        assertEquals(false, isCorrectType, "The form info should not be of type I485FormSpecificInfo");
    }

           @Test
    void shouldSetFormSpecificInfoForI485AndFormSpecificInfoIsNotNull() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        boolean under14 = true;
        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        I485AdditionalInformation i485AdditionalInfo = new I485AdditionalInformation();
        i485AdditionalInfo.setUnder14(under14);

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType(FormType.I485.getType())
        		.pass(true)
        		.results(Arrays.asList(status))
        		.fee(new BigDecimal(100.0))
                .additionalInfo(i485AdditionalInfo)
        		.build();


        Optional<Submission> existingSubmission = Optional.of(Submission.builder()
                .formType(FormType.I485)
                .forms(Arrays.asList(SubmissionForm.builder()
                    .id(formId)
                    .build()))
                .formSpecificInfo(new I485FormSpecificInfo(false, false, true))
                .userRequestedFeeWaiver(false)
                .build());

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(existingSubmission);

        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionDAO).save(any(Submission.class));
        assertNotNull(existingSubmission.get().getFormSpecificInfo());
        assertEquals(under14, ((I485FormSpecificInfo) existingSubmission.get().getFormSpecificInfo()).isUnder14());
    }

    @Test
    void shouldSetFormSpecificInfoForI907() throws JMSException, JsonProcessingException {
        TextMessage passValidationMessage = mock(TextMessage.class);

        String testUnderlyingReceiptNumber = "IOE1234567890";
        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationStatus status = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .status(ValidationResultEnum.PASS)
                .validator(ValidatorEnum.PFVS)
                .failureReasons(null)
                .validationWarnings(null)
                .build();

        I907AdditionalInformation i907AdditionalInfo = new I907AdditionalInformation();
        i907AdditionalInfo.setUnderlyingPetitionReceiptNumber(testUnderlyingReceiptNumber);

        ELISValidationResponse results = ELISValidationResponse.builder()
        		.formId(formId)
        		.submissionId(submissionId)
        		.formType(FormType.I907.getType())
        		.pass(true)
        		.results(Arrays.asList(status))
        		.fee(new BigDecimal(100.0))
                .additionalInfo(i907AdditionalInfo)
        		.build();


        Optional<Submission> existingSubmission = Optional.of(Submission.builder()
                .formType(FormType.I907)
                .forms(Arrays.asList(SubmissionForm.builder()
                    .id(formId)
                    .build()))
                .userRequestedFeeWaiver(false)
                .build());

        when(passValidationMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(existingSubmission);

        listener.onMessage(passValidationMessage);

        verify(mockValidationStatusDAO).update(status);
        verify(submissionDAO).save(any(Submission.class));
        assertNotNull(existingSubmission.get().getFormSpecificInfo());
        assertEquals(testUnderlyingReceiptNumber, ((I907FormSpecificInfo) existingSubmission.get().getFormSpecificInfo()).getUnderlyingPetitionReceiptNumber());
    }

    @Test
    void shouldNotSetSubmissionFeeForValidationResponseWithInvalidFormId() throws JMSException, JsonProcessingException {
        TextMessage mockMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = "invalidFormId";
        BigDecimal existingSubmissionFee = new BigDecimal(999.0);
        BigDecimal validationStatusFee = new BigDecimal(100.0);

        ValidationStatus status = ValidationStatus.builder()
            .formId(formId)
            .submissionId(submissionId)
            .status(ValidationResultEnum.PASS)
            .validator(ValidatorEnum.PFVS)
            .failureReasons(null)
            .validationWarnings(null)
            .build();

        ELISValidationResponse results = ELISValidationResponse.builder()
            .formId(formId)
            .submissionId(submissionId)
            .formType(FormType.I485.getType())
            .pass(true)
            .results(Arrays.asList(status))
            .fee(validationStatusFee)
            .build();

        Optional<Submission> existingSubmission = Optional.of(Submission.builder()
            .formType(FormType.I485)
            .forms(Arrays.asList(SubmissionForm.builder()
                .id("valid-form-id")
                .build()))
            .formSpecificInfo(new I485FormSpecificInfo(false, false, true))
            .userRequestedFeeWaiver(false)
            .feeTotal(existingSubmissionFee)
            .build());

        when(mockMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(results));
        when(submissionDAO.getById(submissionId)).thenReturn(existingSubmission);

        listener.onMessage(mockMessage);

        assertEquals(existingSubmissionFee, existingSubmission.get().getFeeTotal());
        verify(submissionDAO).getById(submissionId);
        verifyNoMoreInteractions(submissionDAO);
    }

}