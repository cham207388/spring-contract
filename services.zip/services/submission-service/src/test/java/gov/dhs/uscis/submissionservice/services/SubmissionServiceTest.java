package gov.dhs.uscis.submissionservice.services;

import static gov.dhs.uscis.intake.constants.DocumentType.FeeWaiver.FEE_DECLARATION;
import static gov.dhs.uscis.intake.constants.FeeWaiverErrors.FORM_TYPE_NOT_PRESENT_MESSAGE;
import static gov.dhs.uscis.intake.entities.audit.ActionPerformed.FEE_WAIVER_REQUESTED;
import static gov.dhs.uscis.intake.entities.submission.SubmissionState.DRAFT;
import static gov.dhs.uscis.intake.enums.I765EligibilityCategory.A12;
import static gov.dhs.uscis.intake.enums.I765EligibilityCategory.C9;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.FAIL;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.PASS;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.CORE;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.ELIGIBILITY_CATEGORY;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.PFVS;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.SIGNATURE;
import static gov.dhs.uscis.submissionservice.services.SubmissionService.FEE_WAIVER_EVIDENCE_GROUP;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.instancio.Select.field;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.testcontainers.shaded.com.google.common.collect.Lists;

import software.amazon.awssdk.services.sns.model.InvalidStateException;

import gov.dhs.uscis.intake.clients.AccountsDataClient;
import gov.dhs.uscis.intake.clients.UserGroupServiceClient;
import gov.dhs.uscis.intake.constants.S3Constants;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.FormTypeDescription;
import gov.dhs.uscis.intake.enums.I129H2AEligibilityCategory;
import gov.dhs.uscis.intake.enums.I130EligibilityCategory;
import gov.dhs.uscis.intake.enums.I131EligibilityCategory;
import gov.dhs.uscis.intake.enums.I140EligibilityCategory;
import gov.dhs.uscis.intake.enums.I485AEligibilityCategory;
import gov.dhs.uscis.intake.enums.I485EligibilityCategory;
import gov.dhs.uscis.intake.enums.I751EligibilityCategory;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.enums.N400EligibilityCategory;
import gov.dhs.uscis.intake.enums.PFVSEvidenceType;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import gov.dhs.uscis.intake.enums.RequestedAction;
import gov.dhs.uscis.intake.enums.ResidencyStatus;
import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.enums.eligibility.I131AdvancedParoleEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I131ParoleInPlaceEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I751WaiverOrIndividualFilingSubcategory;
import gov.dhs.uscis.intake.exceptions.S3DeleteObjectException;
import gov.dhs.uscis.intake.models.ConcurrentForm;
import gov.dhs.uscis.intake.models.EntityType;
import gov.dhs.uscis.intake.models.EsignData;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.EvidenceType;
import gov.dhs.uscis.intake.models.FinalTransmissionStatus;
import gov.dhs.uscis.intake.models.LockboxStatuses;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest.ManifestUpdate;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest.SubmissionUpdate;
import gov.dhs.uscis.intake.models.ValidationRequest;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.WatermarkerStatus;
import gov.dhs.uscis.intake.models.additionalinformation.I129H2AAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I130AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I140AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I485AAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I485AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I765AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I912AdditionalInformation;
import gov.dhs.uscis.intake.models.core.ClientAssociation;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.dto.C9Options;
import gov.dhs.uscis.intake.models.dto.C9UpdateRequest;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.intake.models.submission.ExtractedFormEntries;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I140FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485AFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I751FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I765FormSpecificInfo;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;
import gov.dhs.uscis.intake.models.validation.ValidationDetails;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.intake.services.SystemClockService;
import gov.dhs.uscis.intake.util.SubmissionUtils;
import gov.dhs.uscis.submissionservice.SubmissionFactory;
import gov.dhs.uscis.submissionservice.components.UuidGenerator;
import gov.dhs.uscis.submissionservice.exception.SubmissionBadException;
import gov.dhs.uscis.submissionservice.exception.SubmissionDeleteException;
import gov.dhs.uscis.submissionservice.exception.SubmissionIndexException;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;
import gov.dhs.uscis.submissionservice.models.dto.EligibilitySubcategoriesUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.EligibilityUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import gov.dhs.uscis.submissionservice.models.dto.S3FileInfo;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AccountTypeResponse;
import gov.dhs.uscis.submissionservice.models.submissionStatus.ErrorGroup;
import gov.dhs.uscis.submissionservice.models.submissionStatus.SubmissionStatusResponse;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.repository.ClientInformationRepository;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.fees.FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i130.I130Fees;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i131.I131Fees;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765C11FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765C9FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765Fees;
import gov.dhs.uscis.submissionservice.services.fees.strategies.n400.N400Fees;
import gov.dhs.uscis.submissionservice.services.utils.Constants;
import gov.dhs.uscis.submissionservice.validators.i765.EligibilityCategoryValidator;
import gov.dhs.uscis.submissionservice.validators.i765.ReasonForFilingValidator;
import gov.dhs.uscis.submissionservice.validators.n400.BasisOfEligibilityValidator;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@ExtendWith(MockitoExtension.class)
class SubmissionServiceTest {

    @Mock
    private DynamoDbTable<Submission> mockDynamoDbTable;

    @Mock
    private DynamoDbIndex<Submission> myUscisIndex;

    @Mock
    private SdkIterable<Page<Submission>> iterableSubmissionPage;

    @Mock
    private Page<Submission> mockSubmissionPage;

    @Mock
    private MyUscisCacheManagementClient myUscisCacheManagementClient;

    @Mock
    UpdateItemEnhancedRequest<Submission> mockSubmissionUpdateItemEnhancedRequest;

    @Mock
    private S3Service s3Service;

    @Mock
    private FeeService feeService;

    @Mock
    private FormService formService;

    @Mock
    private AuditService auditService;

    @Mock
    private SubmissionRepository submissionDao;

    @Mock
    private DraftBenefitsService draftBenefitsService;

    @Mock
    private ValidationStatusRepository validationStatusRepository;

    @Spy
    private Function<String, String> uuid = new UuidGenerator();

    @Mock
    private PaymentServiceClient paymentServiceClient;

    @Mock
    private LockboxGatewayClient lockboxGatewayClient;

    @Mock
    private WebClient lockboxWebClient;

    @Mock
    private EligibilityCategoryValidatorFactory categoryValidatorFactory;

    @Mock
    private ReasonForFilingValidator reasonForFilingValidator;

    @Mock
    private ClientInformationRepository clientInformationRepository;

    @Mock
    private UserGroupServiceClient userGroupServiceClient;

    @Mock
    private ToggleService toggleService;

    @Spy
    private SystemClockService systemClockService = new SystemClockService() {

        @Override
        public ZonedDateTime getSystemTime() {
            return ZonedDateTime.of(2024, 9, 9, 0, 0, 0, 0, ZoneId.of("Z"));
        }
    };

    @Mock
    private ValidationService validationService;

    @Mock
    private SqsService sqsService;

    @Mock
    private PeepsService peepsService;

    @Mock
    private AccountsDataClient accountsDataClient;

    @InjectMocks
    private SubmissionService service;

    String myUscisId;
    String orgMyUscisId;
    String formId;
    String submissionId;
    FormType i765FormType;
    FormType n400FormType;
    FormType i131FormType;
    FormType i130FormType;
    FormType i140FormType;
    FormType i751FormType;

    @BeforeEach
    public void setUp() {
        myUscisId = UUID.randomUUID().toString();
        orgMyUscisId = UUID.randomUUID().toString();
        formId = UUID.randomUUID().toString();
        submissionId = UUID.randomUUID().toString();
        i765FormType = FormType.I765;
        n400FormType = FormType.N400;
        i131FormType = FormType.I131;
        i130FormType = FormType.I130;
        i751FormType = FormType.I751;
        i140FormType = FormType.I140;
    }

    @Nested
    class I765Tests {
        @Test
        void retrieveSubmission_shouldSucceed() {
            Submission submission = Instancio.create(Submission.class);
            submission.setSubmissionId(UUID.randomUUID().toString());
            submission.setUserRequestedFeeWaiver(false);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            Submission response = service.retrieveDraftSubmission(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());
            assertEquals(submission, response);
        }

        @Test
        void retrieveSubmissionByIdAndUscisId_shouldSucceed() {
            String submissionId = UUID.randomUUID().toString();
            Submission expected = Instancio.of(Submission.class)
                    .set(field(Submission::getMyUscisId), myUscisId)
                    .set(field(Submission::getSubmissionId), submissionId)
                    .create();
            when(submissionDao.findBySubmissionIdAndUscisId(submissionId, myUscisId, orgMyUscisId))
                    .thenReturn(Optional.of(expected));
            Submission actual = service.retrieveSubmissionByIdAndUscisId(submissionId, myUscisId, orgMyUscisId);
            assertEquals(expected, actual);
        }

        @Test
        void retrieveSubmissionByIdAndUscisId_shouldThrow() {
            String submissionId = UUID.randomUUID().toString();
            when(submissionDao.findBySubmissionIdAndUscisId(submissionId, myUscisId, orgMyUscisId))
                    .thenReturn(Optional.empty());
            assertThrows(NoSuchElementException.class,
                    () -> service.retrieveSubmissionByIdAndUscisId(submissionId, myUscisId, orgMyUscisId));
        }

        @Test
        void shouldRetrieveSubmissionByManifestId() {
            Submission submission = Instancio.create(Submission.class);
            String manifestId = "manifestId";
            String id = "submissionId";

            when(lockboxGatewayClient.mapManifestToSubmissionId(any())).thenReturn(Mono.just(id));
            when(submissionDao.getById(id)).thenReturn(Optional.of(submission));
            Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

            assertTrue(response.isPresent());
            assertEquals(submission, response.get());
        }

        @Test
        void shouldRetrieveSubmissionByManifestIdWhenSubmissionManifestIdFieldIsNull() {
            Submission submission = Instancio.create(Submission.class);
            submission.setManifestId(null);
            String manifestId = "manifestId";
            String id = "submissionId";

            when(lockboxGatewayClient.mapManifestToSubmissionId(any())).thenReturn(Mono.just(id));
            when(submissionDao.getById(id)).thenReturn(Optional.of(submission));
            Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

            assertTrue(response.isPresent());
            assertThat(response.get().getManifestId()).isNotNull();
            assertEquals(submission, response.get());
        }

        @Test
        void shouldRetrieveSubmissionByManifestIdWhenEvidenceIsNull() {
            Submission submission = Instancio.create(Submission.class);
            submission.setEvidences(null);
            String manifestId = "manifestId";
            var id = "submissionId";

            when(lockboxGatewayClient.mapManifestToSubmissionId(any())).thenReturn(Mono.just(id));
            when(submissionDao.getById(id)).thenReturn(Optional.of(submission));
            Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

            assertTrue(response.isPresent());
            Submission actual = response.get();
            assertNull(actual.getEvidences());
        }

        @Test
        void shouldRetrieveSubmissionByManifestIdAndRemovedEvidenceGroupType() {
            Submission submission = Instancio.create(Submission.class);
            submission.getEvidences()
                    .add(SubmissionEvidence.builder().id(UUID.randomUUID().toString())
                            .type("Form-797")
                            .evidenceGroupType("Form-797").build());
            submission.getEvidences()
                    .add(SubmissionEvidence.builder().id(UUID.randomUUID().toString())
                            .type("Form-797c")
                            .evidenceGroupType("Form-797c").build());
            String manifestId = "manifestId";

            var id = "submissionId";
            when(lockboxGatewayClient.mapManifestToSubmissionId(any())).thenReturn(Mono.just(id));
            when(submissionDao.getById(id)).thenReturn(Optional.of(submission));
            Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

            assertTrue(response.isPresent());
            Submission actual = response.get();
            assertEquals(0,
                    actual.getEvidences().stream()
                            .filter(evidence -> evidence.getEvidenceGroupType() != null)
                            .count());
        }

        @Test
        void shouldRetrieveSubmissionByManifestandAdjustBIA() {
            Submission submission = Instancio.create(Submission.class);
            submission.getEvidences()
                    .add(SubmissionEvidence.builder().id(UUID.randomUUID().toString())
                            .type("BIA Order")
                            .evidenceGroupType("eoir-bia-order").build());
            String manifestId = "manifestId";
            var id = "submissionId";

            when(lockboxGatewayClient.mapManifestToSubmissionId(any())).thenReturn(Mono.just(id));
            when(submissionDao.getById(id)).thenReturn(Optional.of(submission));
            Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

            assertTrue(response.isPresent());
            Submission actual = response.get();
            assertEquals(0,
                    actual.getEvidences().stream()
                            .filter(evidence -> evidence.getEvidenceGroupType() != null)
                            .count());
            assertEquals(1, actual.getEvidences().stream()
                    .filter(submissionEvidence -> submissionEvidence.getType().equals("Other")).count());
        }

        @Test
        void shouldRetrieveSubmissionByManifestandAdjustEOIR() {
            Submission submission = Instancio.create(Submission.class);
            submission.getEvidences()
                    .add(SubmissionEvidence.builder().id(UUID.randomUUID().toString())
                            .type("EOIR")
                            .evidenceGroupType("eoir-bia-order").build());
            String manifestId = "manifestId";
            var id = "submissionId";

            when(lockboxGatewayClient.mapManifestToSubmissionId(any())).thenReturn(Mono.just(id));
            when(submissionDao.getById(id)).thenReturn(Optional.of(submission));
            Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

            assertTrue(response.isPresent());
            Submission actual = response.get();
            assertEquals(0,
                    actual.getEvidences().stream()
                            .filter(evidence -> evidence.getEvidenceGroupType() != null)
                            .count());
            assertEquals(1, actual.getEvidences().stream()
                    .filter(submissionEvidence -> submissionEvidence.getType().equals("Other")).count());
        }

        @Test
        void shouldUpdateSubmissionWithForm() throws IOException {
            String fileName = "fileName";

            String submissionId = UUID.randomUUID().toString();
            ZonedDateTime uploadedAt = ZonedDateTime.now();
            String baseUrl = "https://downloader.uscis.dhs.gov";
            ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);

            UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                    Constants.MD5HASH, "I-765");
            S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
            MockMultipartFile file = new MockMultipartFile(
                    fileName,
                    fileName,
                    MediaType.MULTIPART_FORM_DATA_VALUE,
                    "Hello, World!".getBytes());

            I765EligibilityCategory eligibilityCategory = I765EligibilityCategory.C11PAROLE;
            List<SubmissionForm> forms = List.of(SubmissionForm.builder().id(formId)
                    .type(uploadRequest.formType())
                    .name(uploadRequest.fileName()).eligibilityCategory(eligibilityCategory)
                    .md5Hash("checksum123").s3Key(s3FileInfo.s3Key())
                    .url(baseUrl + "/" + s3FileInfo.s3Key())
                    .uploadedAt(uploadedAt).build());

            Submission expected = Submission.builder().myUscisId(myUscisId)
                    .submissionId(submissionId).eligibilityCategory(eligibilityCategory)
                    .forms(forms).build();

            Submission submission = Submission.builder().myUscisId(myUscisId)
                    .eligibilityCategory(eligibilityCategory).submissionId(submissionId)
                    .forms(forms)
                    .build();
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            // doReturn(submissionId).when(log).info();
            when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                    any(UploadRequest.class))).thenReturn(s3FileInfo);
            Submission actual = service.updateSubmissionWithForm(submission, uploadRequest, file);

            assertThat(actual, samePropertyValuesAs(expected, "forms", "updatedAt"));
            assertThat(actual.getForms(), hasSize(1));
            assertThat(actual.getForms().get(0),
                    samePropertyValuesAs(expected.getForms().get(0), "uploadedAt"));
        }

        @Test
        void shouldUpdateSubmissionWithFormForI131() throws IOException {
            String fileName = "fileName";
            Integer appReasonCode = 205;
            Integer benefitTypeCode = 145;

            String submissionId = UUID.randomUUID().toString();
            ZonedDateTime uploadedAt = ZonedDateTime.now();
            String baseUrl = "https://downloader.uscis.dhs.gov";
            ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);

            UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                    Constants.MD5HASH, "I-131");
            S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
            MockMultipartFile file = new MockMultipartFile(
                    fileName,
                    fileName,
                    MediaType.MULTIPART_FORM_DATA_VALUE,
                    "Hello, World!".getBytes());

            I131EligibilityCategory eligibilityCategory = I131EligibilityCategory.ADVANCE_PAROLE;
            List<SubmissionForm> forms = List.of(SubmissionForm.builder().id(formId)
                    .type(uploadRequest.formType())
                    .name(uploadRequest.fileName()).eligibilityCategory(eligibilityCategory)
                    .eligibilitySubcategory(I131AdvancedParoleEligibilitySubcategory.APPROVED_817)
                    .md5Hash("checksum123").s3Key(s3FileInfo.s3Key())
                    .url(baseUrl + "/" + s3FileInfo.s3Key())
                    .uploadedAt(uploadedAt).build());

            Submission expected = Submission.builder().myUscisId(myUscisId)
                    .submissionId(submissionId).eligibilityCategory(eligibilityCategory)
                    .eligibilitySubcategory(I131AdvancedParoleEligibilitySubcategory.APPROVED_817)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .formType(FormType.I131)
                    .forms(forms).build();

            Submission submission = Submission.builder().myUscisId(myUscisId)
                    .eligibilityCategory(eligibilityCategory).submissionId(submissionId)
                    .eligibilitySubcategory(I131AdvancedParoleEligibilitySubcategory.APPROVED_817)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .formType(FormType.I131)
                    .forms(forms)
                    .build();
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);
            when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                    any(UploadRequest.class))).thenReturn(s3FileInfo);

            Submission actual = service.updateSubmissionWithForm(submission, uploadRequest, file);

            ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);
            verify(sqsService).sendValidationRequest(valRequest.capture());

            ValidationRequest resultingRequest = valRequest.getValue();
            assertEquals(s3FileInfo.s3Key(), resultingRequest.s3Key());
            assertEquals(submissionId, resultingRequest.submissionId());
            assertEquals(formId, resultingRequest.formId());
            assertEquals(appReasonCode, submission.getApplicationReaonCode());
            assertEquals(benefitTypeCode, submission.getBenefitTypeCode());

            assertThat(actual, samePropertyValuesAs(expected, "forms", "updatedAt"));
            assertThat(actual.getForms(), hasSize(1));
            assertThat(actual.getForms().get(0),
                    samePropertyValuesAs(expected.getForms().get(0), "uploadedAt", "eligibilitySubcategory"));
        }

        @Test
        void shouldReconnectEvidenceWhenAnExistingFormIsReplaced() throws IOException {
            String fileName = "fileName";
            Integer appReasonCode = 205;
            Integer benefitTypeCode = 145;

            String submissionId = UUID.randomUUID().toString();
            ZonedDateTime uploadedAt = ZonedDateTime.now();
            String baseUrl = "https://downloader.uscis.dhs.gov";
            ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);

            UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                    Constants.MD5HASH, "I-131");

            String newS3Key = "/path/" + fileName;
            MockMultipartFile file = new MockMultipartFile(
                    fileName,
                    fileName,
                    MediaType.MULTIPART_FORM_DATA_VALUE,
                    "Hello, World!".getBytes());

            I131EligibilityCategory eligibilityCategory = I131EligibilityCategory.ADVANCE_PAROLE;
            List<SubmissionForm> forms = List.of(SubmissionForm.builder().id(formId)
                    .type(uploadRequest.formType())
                    .name(uploadRequest.fileName()).eligibilityCategory(eligibilityCategory)
                    .eligibilitySubcategory(I131AdvancedParoleEligibilitySubcategory.APPROVED_817)
                    .md5Hash("checksum123").s3Key(newS3Key)
                    .url(baseUrl + "/" + newS3Key)
                    .uploadedAt(uploadedAt)
                    .build());

            List<SubmissionEvidence> evidence = List.of(
                    SubmissionEvidence.builder()
                            .formId(forms.get(0).getId())
                            .evidenceGroupType("someevidencetype")
                            .id(UUID.randomUUID().toString())
                            .name("evidence1")
                            .build());

            Submission submission = Submission.builder().myUscisId(myUscisId)
                    .eligibilityCategory(eligibilityCategory).submissionId(submissionId)
                    .eligibilitySubcategory(I131AdvancedParoleEligibilitySubcategory.APPROVED_817)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .formType(FormType.I131)
                    .forms(forms)
                    .evidences(evidence)
                    .build();

            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);
            when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                    any(UploadRequest.class)))
                    .thenAnswer(call -> {
                        String newFormId = call.getArgument(1);
                        return new S3FileInfo(newFormId, "checksum123", "artifactId", newS3Key);
                    });

            Submission actual = service.updateSubmissionWithForm(submission, uploadRequest, file);

            ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);
            verify(sqsService).sendValidationRequest(valRequest.capture());

            System.out.println("actional {}: " + actual);
            assertEquals(actual.getForms().get(0).getId(), actual.getEvidences().get(0).getFormId());
        }

        @Test
        void shouldUpdateSubmissionWithFormForI131NoSubcategory() throws IOException {
            String fileName = "fileName";
            Integer benefitTypeCode = 20;

            String submissionId = UUID.randomUUID().toString();
            ZonedDateTime uploadedAt = ZonedDateTime.now();
            String baseUrl = "https://downloader.uscis.dhs.gov";
            ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);

            UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                    Constants.MD5HASH, "I-131");
            S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
            MockMultipartFile file = new MockMultipartFile(
                    fileName,
                    fileName,
                    MediaType.MULTIPART_FORM_DATA_VALUE,
                    "Hello, World!".getBytes());

            I131EligibilityCategory eligibilityCategory = I131EligibilityCategory.REENTRY_PERMIT;
            List<SubmissionForm> forms = List.of(SubmissionForm.builder().id(formId)
                    .type(uploadRequest.formType())
                    .name(uploadRequest.fileName()).eligibilityCategory(eligibilityCategory)
                    .benefitTypeCode(20)
                    .md5Hash("checksum123").s3Key(s3FileInfo.s3Key())
                    .url(baseUrl + "/" + s3FileInfo.s3Key())
                    .uploadedAt(uploadedAt).build());

            Submission expected = Submission.builder().myUscisId(myUscisId)
                    .submissionId(submissionId).eligibilityCategory(eligibilityCategory)
                    .benefitTypeCode(benefitTypeCode)
                    .formType(FormType.I131)
                    .forms(forms).build();

            Submission submission = Submission.builder().myUscisId(myUscisId)
                    .eligibilityCategory(eligibilityCategory).submissionId(submissionId)
                    .benefitTypeCode(benefitTypeCode)
                    .formType(FormType.I131)
                    .forms(forms)
                    .build();
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);
            when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                    any(UploadRequest.class))).thenReturn(s3FileInfo);

            Submission actual = service.updateSubmissionWithForm(submission, uploadRequest, file);

            ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);
            verify(sqsService).sendValidationRequest(valRequest.capture());

            ValidationRequest resultingRequest = valRequest.getValue();
            assertEquals(s3FileInfo.s3Key(), resultingRequest.s3Key());
            assertEquals(submissionId, resultingRequest.submissionId());
            assertEquals(formId, resultingRequest.formId());
            assertNull(resultingRequest.applicationReasonCode());
            assertEquals(benefitTypeCode, resultingRequest.benefitTypeCode());

            assertThat(actual, samePropertyValuesAs(expected, "forms", "updatedAt"));
            assertThat(actual.getForms(), hasSize(1));
            assertThat(actual.getForms().get(0),
                    samePropertyValuesAs(expected.getForms().get(0), "benefitTypeCode", "uploadedAt"));
        }

        @Test
        void shouldUpdateSubmissionWithFormForI131SubcategoryOverride() throws IOException {
            String fileName = "fileName";
            Integer benefitTypeCode = 150;

            String submissionId = UUID.randomUUID().toString();
            ZonedDateTime uploadedAt = ZonedDateTime.now();
            String baseUrl = "https://downloader.uscis.dhs.gov";
            ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);

            UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                    Constants.MD5HASH, "I-131");
            S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
            MockMultipartFile file = new MockMultipartFile(
                    fileName,
                    fileName,
                    MediaType.MULTIPART_FORM_DATA_VALUE,
                    "Hello, World!".getBytes());
            I131EligibilityCategory eligibilityCategory = I131EligibilityCategory.PAROLE_IN_PLACE;
            List<SubmissionForm> forms = List.of(SubmissionForm.builder().id(formId)
                    .type(uploadRequest.formType())
                    .name(uploadRequest.fileName()).eligibilityCategory(eligibilityCategory)
                    .eligibilitySubcategory(I131ParoleInPlaceEligibilitySubcategory.NON_SPECIFIC)
                    .md5Hash("checksum123").s3Key(s3FileInfo.s3Key())
                    .url(baseUrl + "/" + s3FileInfo.s3Key())
                    .uploadedAt(uploadedAt).build());

            Submission expected = Submission.builder().myUscisId(myUscisId)
                    .submissionId(submissionId).eligibilityCategory(eligibilityCategory)
                    .eligibilitySubcategory(I131ParoleInPlaceEligibilitySubcategory.NON_SPECIFIC)
                    .benefitTypeCode(benefitTypeCode)
                    .formType(FormType.I131)
                    .forms(forms).build();

            Submission submission = Submission.builder().myUscisId(myUscisId)
                    .eligibilityCategory(eligibilityCategory).submissionId(submissionId)
                    .eligibilitySubcategory(I131ParoleInPlaceEligibilitySubcategory.NON_SPECIFIC)
                    .benefitTypeCode(benefitTypeCode)
                    .formType(FormType.I131)
                    .forms(forms)
                    .build();
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);
            when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                    any(UploadRequest.class))).thenReturn(s3FileInfo);

            Submission actual = service.updateSubmissionWithForm(submission, uploadRequest, file);

            ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);
            verify(sqsService).sendValidationRequest(valRequest.capture());

            ValidationRequest resultingRequest = valRequest.getValue();
            assertEquals(s3FileInfo.s3Key(), resultingRequest.s3Key());
            assertEquals(submissionId, resultingRequest.submissionId());
            assertEquals(formId, resultingRequest.formId());
            assertEquals(null, submission.getApplicationReaonCode());
            assertEquals(benefitTypeCode, submission.getBenefitTypeCode());

            assertThat(actual, samePropertyValuesAs(expected, "forms", "updatedAt"));
            assertThat(actual.getForms().get(0),
                    samePropertyValuesAs(expected.getForms().get(0), "uploadedAt", "eligibilitySubcategory"));
        }

        @Test
        void shouldUpdateSubmissionWithG28IfFormDoesntExist() throws IOException {
            String fileName = "fileName";

            String submissionId = UUID.randomUUID().toString();
            ZonedDateTime uploadedAt = ZonedDateTime.now();
            String baseUrl = "https://downloader.uscis.dhs.gov";
            ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);

            UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                    Constants.MD5HASH, "G-28");
            S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
            MockMultipartFile file = new MockMultipartFile(
                    fileName,
                    fileName,
                    MediaType.MULTIPART_FORM_DATA_VALUE,
                    "Hello, World!".getBytes());

            I765EligibilityCategory eligibilityCategory = I765EligibilityCategory.C11PAROLE;
            List<SubmissionForm> forms = List.of(SubmissionForm.builder().id(formId)
                    .type(FormType.I131.getType())
                    .name(uploadRequest.fileName()).eligibilityCategory(eligibilityCategory)
                    .md5Hash("checksum123").s3Key(s3FileInfo.s3Key())
                    .url(baseUrl + "/" + s3FileInfo.s3Key())
                    .uploadedAt(uploadedAt).build());

            Submission expected = Submission.builder().myUscisId(myUscisId)
                    .submissionId(submissionId).eligibilityCategory(eligibilityCategory)
                    .forms(forms).build();

            Submission submission = Submission.builder().myUscisId(myUscisId)
                    .eligibilityCategory(eligibilityCategory).submissionId(submissionId)
                    .forms(forms)
                    .build();
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                    any(UploadRequest.class))).thenReturn(s3FileInfo);
            Submission actual = service.updateSubmissionWithForm(submission, uploadRequest, file);

            assertThat(actual, samePropertyValuesAs(expected, "forms", "updatedAt"));
            assertThat(actual.getForms(), hasSize(2));
            assertNotNull(actual.getForms().stream().filter(form -> form.getType().equals(FormType.G28.getType()))
                    .findFirst());
        }

        @Test
        void shouldUpdateSubmissionWithEvidenceWhenSubmissionHasNoEvidenceYet() {
            String documentId = UUID.randomUUID().toString();
            String submissionId = UUID.randomUUID().toString();

            UploadEvidenceRequest uploadEvidenceRequest = new UploadEvidenceRequest("Drivers License",
                    "Evidence",
                    "EvidenceGroup");
            String evidenceId = "evidenceId";
            String s3ObjectKey = "dir/dir/evidence.pdf";
            var s3FileInfo = new S3FileInfo(evidenceId, "checksum123", "artifactId", s3ObjectKey);

            Submission submission = Instancio.create(Submission.class);
            submission.setEvidences(null);
            submission.setSubmissionId(submissionId);
            SubmissionForm submissionForm = Instancio.create(SubmissionForm.class);
            submission.setUserRequestedFeeWaiver(false);
            submissionForm.setId(documentId);
            submission.setForms(List.of(submissionForm));

            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            Submission actual = service.updateSubmissionWithEvidence(myUscisId, orgMyUscisId, submissionId, null,
                    uploadEvidenceRequest,
                    s3FileInfo, FormType.I131.getType());

            assertThat(actual.getEvidences()).hasSize(1);
            SubmissionEvidence actualEv = actual.getEvidences().stream()
                    .filter(e -> e.getId().equals(evidenceId))
                    .findFirst().orElseThrow();
            assertEquals("Evidence", actualEv.getType());
            verify(submissionDao, times(1)).update(any(Submission.class));
        }

        @Test
        void shouldUpdateSubmissionWithEvidenceWhenSubmissionWitEvidenceToBeValidated() {
            String documentId = UUID.randomUUID().toString();
            String submissionId = UUID.randomUUID().toString();

            UploadEvidenceRequest uploadEvidenceRequest = new UploadEvidenceRequest("Drivers License",
                    "Evidence",
                    "EvidenceGroup");
            String evidenceId = "evidenceId";
            String s3ObjectKey = "dir/dir/evidence.pdf";
            var s3FileInfo = new S3FileInfo(evidenceId, "checksum123", "artifactId", s3ObjectKey);
            EvidenceGroup evidenceGroup = EvidenceGroup.builder()
                    .validations(Arrays.asList(MetadataValidationEnum.PFVS)).build();

            Submission submission = Instancio.create(Submission.class);
            submission.setEvidences(null);
            submission.setSubmissionId(submissionId);
            submission.setEligibilityCategory(null);
            SubmissionForm submissionForm = Instancio.create(SubmissionForm.class);
            submission.setUserRequestedFeeWaiver(false);
            submissionForm.setId(documentId);
            submission.setForms(List.of(submissionForm));
            FormSpecificInfo formSpecificInfo = new I140FormSpecificInfo("123", false);
            submission.setFormSpecificInfo(formSpecificInfo);
            submission.setEvidences(Lists.newArrayList());
            submission.setFormType(FormType.I140);
            submission.setForms(List.of());
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            Submission actual = service.updateSubmissionWithEvidence(myUscisId, orgMyUscisId, submissionId, "formid",
                    uploadEvidenceRequest,
                    s3FileInfo, FormType.I140.getType());

            assertThat(actual.getEvidences()).hasSize(1);
            SubmissionEvidence actualEv = actual.getEvidences().stream()
                    .filter(e -> e.getId().equals(evidenceId))
                    .findFirst().orElseThrow();
            assertEquals("Evidence", actualEv.getType());
            verify(submissionDao, times(1)).update(any(Submission.class));
        }

        @Test
        void shouldCreateInitialSubmissionWithNoEligibility() {
            final AccountType accountType = AccountType.APPLICANT;

            SubmissionRequest request = new SubmissionRequest(i765FormType, FormTypeDescription.I765.getDescription(),
                    null, accountType, Optional.empty(), List.of(), null);

            Submission mockReturn = Submission.builder().build();
            when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(UserGroupRole.builder().userGroupId("fakeUserGroupid").build());
            Submission response = service.createInitialSubmission(myUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).save(captor.capture());

            Submission actualSubmission = captor.getValue();

            assertEquals(mockReturn, response);
            assertEquals(myUscisId, actualSubmission.getMyUscisId());
            assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
            assertThat(actualSubmission.getApplicant().getEmail()).isNull();
            assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
            assertEquals(SubmissionState.DRAFT, actualSubmission.getStatus());
            assertNull(actualSubmission.getEligibilityCategory());
            // assertEquals(BigDecimal.ZERO, actualSubmission.getFeeTotal());
            assertNotNull(actualSubmission.getTimestamp());
            assertFalse(actualSubmission.getImmvi());
            assertNull(actualSubmission.getReasonForFiling());
            assertFalse(actualSubmission.getUserRequestedFeeWaiver());
            assertFalse(actualSubmission.getUserRequestedPartialFeeWaiver());
            assertFalse(actualSubmission.getAttested());

            verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
        }

        @Test
        void shouldCreateInitialSubmissionWithEligibility() {
            final I765EligibilityCategory eligibilityCategory = I765EligibilityCategory.A12;
            final AccountType accountType = AccountType.APPLICANT;

            SubmissionRequest request = new SubmissionRequest(i765FormType, FormTypeDescription.I765.getDescription(),
                    eligibilityCategory.getCategory(),
                    accountType, Optional.empty(), List.of(), null);

            Submission mockReturn = Submission.builder().build();
            when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(UserGroupRole.builder().userGroupId("fakeUserGroupid").build());
            Submission response = service.createInitialSubmission(myUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).save(captor.capture());

            Submission actualSubmission = captor.getValue();

            assertEquals(mockReturn, response);
            assertEquals(myUscisId, actualSubmission.getMyUscisId());
            assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
            assertThat(actualSubmission.getApplicant().getEmail()).isNull();
            assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
            assertEquals(BigDecimal.ZERO, actualSubmission.getFeeTotal());
            assertEquals(SubmissionState.DRAFT, actualSubmission.getStatus());
            assertEquals(eligibilityCategory, actualSubmission.getEligibilityCategory());
            assertNotNull(actualSubmission.getTimestamp());

            verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
        }

        @Test
        void shouldCreateInitialSubmissionWithEligibilityRep() {
            final I765EligibilityCategory eligibilityCategory = I765EligibilityCategory.A12;
            final AccountType accountType = AccountType.REPRESENTATIVE;

            SubmissionRequest request = new SubmissionRequest(i765FormType, FormTypeDescription.I765.getDescription(),
                    eligibilityCategory.getCategory(),
                    accountType, Optional.empty(), List.of(), null);

            Submission mockReturn = Submission.builder().build();
            when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(UserGroupRole.builder().userGroupId("fakeUserGroupid").build());
            Submission response = service.createInitialSubmission(myUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).save(captor.capture());

            Submission actualSubmission = captor.getValue();

            assertEquals(mockReturn, response);
            assertEquals(myUscisId, actualSubmission.getMyUscisId());
            assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
            assertThat(actualSubmission.getApplicant().getEmail()).isNull();
            assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
            assertEquals(BigDecimal.ZERO, actualSubmission.getFeeTotal());
            assertEquals(SubmissionState.DRAFT, actualSubmission.getStatus());
            assertEquals(eligibilityCategory, actualSubmission.getEligibilityCategory());
            assertNotNull(actualSubmission.getTimestamp());

            verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
        }

        @Test
        void shouldCreateInitialSubmissionWithEligibilityC9() {
            final I765EligibilityCategory eligibilityCategory = I765EligibilityCategory.C9;
            final AccountType accountType = AccountType.APPLICANT;

            SubmissionRequest request = new SubmissionRequest(i765FormType, FormTypeDescription.I765.getDescription(),
                    eligibilityCategory.getCategory(),
                    accountType, Optional.empty(), List.of(), null);

            Submission mockReturn = Submission.builder().build();
            when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(UserGroupRole.builder().userGroupId("fakeUserGroupid").build());
            Submission response = service.createInitialSubmission(myUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).save(captor.capture());

            Submission actualSubmission = captor.getValue();

            assertEquals(mockReturn, response);
            assertEquals(myUscisId, actualSubmission.getMyUscisId());
            assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
            assertThat(actualSubmission.getApplicant().getEmail()).isNull();
            assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
            assertEquals(eligibilityCategory, actualSubmission.getEligibilityCategory());
            assertNotNull(actualSubmission.getTimestamp());

            verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
        }

        @Test
        void shouldCreateInitialSubmissionWithEligibility_N400() {
            final N400EligibilityCategory eligibilityCategory = N400EligibilityCategory.GENERAL_PROVISION;
            final AccountType accountType = AccountType.APPLICANT;

            SubmissionRequest request = new SubmissionRequest(n400FormType, FormTypeDescription.N400.getDescription(),
                    eligibilityCategory.getCategory(),
                    accountType, Optional.empty(), List.of(), null);

            Submission mockReturn = Submission.builder().build();
            when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);
            BigDecimal fullFee = N400Fees.FULL_FEE;
            when(feeService.calculateN400FeeFor(n400FormType, eligibilityCategory)).thenReturn(fullFee);
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(UserGroupRole.builder().userGroupId("fakeUserGroupid").build());
            Submission response = service.createInitialSubmission(myUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).save(captor.capture());

            Submission actualSubmission = captor.getValue();

            assertEquals(mockReturn, response);
            assertEquals(myUscisId, actualSubmission.getMyUscisId());
            assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
            assertThat(actualSubmission.getApplicant().getEmail()).isNull();
            assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
            assertEquals(fullFee, actualSubmission.getFeeTotal());
            assertEquals(SubmissionState.DRAFT, actualSubmission.getStatus());
            assertEquals(eligibilityCategory, actualSubmission.getEligibilityCategory());
            assertNotNull(actualSubmission.getTimestamp());

            verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
        }

        @Test
        void shouldCreateInitialSubmissionWithEligibility_I131() {
            final I131EligibilityCategory eligibilityCategory = I131EligibilityCategory.ADVANCE_PAROLE;
            final AccountType accountType = AccountType.APPLICANT;

            SubmissionRequest request = new SubmissionRequest(i131FormType, FormTypeDescription.I131.getDescription(),
                    eligibilityCategory.getCategory(),
                    accountType, Optional.empty(), List.of(), null);

            Submission mockReturn = Submission.builder().build();
            when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);
            BigDecimal fullFee = I131Fees.FULL_FEE;
            when(feeService.calculateI131FeeFor(i131FormType, eligibilityCategory)).thenReturn(fullFee);
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(UserGroupRole.builder().userGroupId("fakeUserGroupid").build());
            Submission response = service.createInitialSubmission(myUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).save(captor.capture());

            Submission actualSubmission = captor.getValue();

            assertEquals(mockReturn, response);
            assertEquals(myUscisId, actualSubmission.getMyUscisId());
            assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
            assertThat(actualSubmission.getApplicant().getEmail()).isNull();
            assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
            assertEquals(fullFee, actualSubmission.getFeeTotal());
            assertEquals(SubmissionState.DRAFT, actualSubmission.getStatus());
            assertEquals(eligibilityCategory, actualSubmission.getEligibilityCategory());
            assertNotNull(actualSubmission.getTimestamp());

            verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
        }

        @Test
        void shouldCreateInitialSubmissionWithEligibility_I130() {
            final I130EligibilityCategory eligibilityCategory = I130EligibilityCategory.PETITION_FOR_SPOUSE;
            final AccountType accountType = AccountType.APPLICANT;

            SubmissionRequest request = new SubmissionRequest(i130FormType, FormTypeDescription.I130.getDescription(),
                    eligibilityCategory.getCategory(),
                    accountType, Optional.empty(), List.of(), null);

            Submission mockReturn = Submission.builder().build();
            when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);
            BigDecimal fullFee = I130Fees.FULL_FEE;
            when(feeService.calculateI130FeeFor(i130FormType, eligibilityCategory)).thenReturn(fullFee);
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(UserGroupRole.builder().userGroupId("fakeUserGroupid").build());
            Submission response = service.createInitialSubmission(myUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).save(captor.capture());

            Submission actualSubmission = captor.getValue();

            assertEquals(mockReturn, response);
            assertEquals(myUscisId, actualSubmission.getMyUscisId());
            assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
            assertThat(actualSubmission.getApplicant().getEmail()).isNull();
            assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
            assertEquals(fullFee, actualSubmission.getFeeTotal());
            assertEquals(SubmissionState.DRAFT, actualSubmission.getStatus());
            assertEquals(eligibilityCategory, actualSubmission.getEligibilityCategory());
            assertNotNull(actualSubmission.getTimestamp());

            verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
        }

        @Test
        void shouldUpdateSubmissionWithFeeWaiver() {
            String feeWaiverId = UUID.randomUUID().toString();
            String submissionId = UUID.randomUUID().toString();
            String fileName = "I 912.pdf";
            S3FileInfo s3FileInfo = new S3FileInfo(feeWaiverId, "checksum123", "artifactId",
                    String.format("%s/%s/%s", submissionId, myUscisId, fileName));

            UploadFeeWaiverRequest request = new UploadFeeWaiverRequest(fileName);

            Submission submission = Instancio.create(Submission.class);
            submission.setSubmissionId(submissionId);
            submission.setUserRequestedFeeWaiver(false);

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            Submission actual = service.updateSubmissionWithFeeWaiver(myUscisId, orgMyUscisId, submissionId, request,
                    s3FileInfo);

            verify(submissionDao, times(1)).update(any(Submission.class));
            var submittedFeeWaiver = actual.getFeeWaiver();
            assertEquals(feeWaiverId, submittedFeeWaiver.getId());
            assertEquals(fileName, submittedFeeWaiver.getName());
            assertTrue(
                    submittedFeeWaiver.getUrl()
                            .contains(String.format("/evidence/%s/%s/I 912.pdf",
                                    submissionId, myUscisId)));
        }

        @Test
        void deleteEvidenceFromSubmission_shouldSucceed() {

            var documentId = UUID.randomUUID().toString();
            var submissionId = UUID.randomUUID().toString();
            var evidenceId = UUID.randomUUID().toString();
            var s3Key = "s3/key/forFile";

            Submission submission = new Submission();
            submission.setSubmissionId(submissionId);
            SubmissionForm submissionForm = new SubmissionForm();
            submissionForm.setId(documentId);
            submission.setForms(List.of(submissionForm));
            var evidence = SubmissionEvidence.builder().id(evidenceId).s3Key(s3Key).build();
            submission.setEvidences(new ArrayList<>(List.of(evidence)));
            submission.setUserRequestedFeeWaiver(false);
            submission.setUserRequestedPartialFeeWaiver(false);

            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            var evidenceS3Key = service.deleteEvidenceFromSubmission(myUscisId, orgMyUscisId, submissionId, evidenceId);
            verify(submissionDao, times(1)).update(any(Submission.class));

            assertTrue(submission.getEvidences().isEmpty());
            assertEquals(s3Key, evidenceS3Key);
        }

        @Test
        void deleteEvidenceFromSubmission_returnsNullWhenNotFound() {

            var documentId = UUID.randomUUID().toString();
            var submissionId = UUID.randomUUID().toString();
            var evidenceId = UUID.randomUUID().toString();
            var s3Key = "s3/key/forFile";

            Submission submission = new Submission();
            submission.setSubmissionId(submissionId);
            SubmissionForm submissionForm = new SubmissionForm();
            submissionForm.setId(documentId);
            submission.setForms(List.of(submissionForm));
            submission.setUserRequestedPartialFeeWaiver(false);
            var evidence = SubmissionEvidence.builder().id("otherId").s3Key(s3Key).build();
            submission.setEvidences(new ArrayList<>(List.of(evidence)));

            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            var evidenceS3Key = service.deleteEvidenceFromSubmission(myUscisId, orgMyUscisId, submissionId, evidenceId);
            verify(submissionDao, times(1)).update(any(Submission.class));

            assertEquals(null, evidenceS3Key);
        }

        @Test
        void deleteEvidenceFromSubmission_throwsExceptionOnError() {
            var submissionId = UUID.randomUUID().toString();
            var evidenceId = UUID.randomUUID().toString();

            Submission submission = Submission.builder().submissionId(submissionId).build();
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenThrow(NoSuchElementException.class);

            assertThrows(NoSuchElementException.class,
                    () -> service.deleteEvidenceFromSubmission(myUscisId, orgMyUscisId, submissionId,
                            evidenceId));
        }

        @Test
        void shouldOnlyDeleteEvidenceFromSubmissionIfEvidenceIsUsedInOtherEvidenceCategory() {

            var documentId = UUID.randomUUID().toString();
            var submissionId = UUID.randomUUID().toString();
            var evidenceId = UUID.randomUUID().toString();
            var evidenceId2 = UUID.randomUUID().toString();
            var evidenceId3 = UUID.randomUUID().toString();
            var s3Key = "s3/key/forFile";

            Submission submission = new Submission();
            submission.setSubmissionId(submissionId);
            SubmissionForm submissionForm = new SubmissionForm();
            submissionForm.setId(documentId);
            submission.setForms(List.of(submissionForm));
            submission.setUserRequestedFeeWaiver(false);
            submission.setUserRequestedPartialFeeWaiver(false);
            var evidence = SubmissionEvidence.builder().id(evidenceId).s3Key(s3Key).build();
            var evidence2 = SubmissionEvidence.builder().id(evidenceId2).s3Key(s3Key).build();
            var evidence3 = SubmissionEvidence.builder().id(evidenceId3).s3Key("other/key").build();
            submission.setEvidences(new ArrayList<>(List.of(evidence, evidence2, evidence3)));

            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            var evidenceS3Key = service.deleteEvidenceFromSubmission(myUscisId, orgMyUscisId, submissionId, evidenceId);
            verify(submissionDao, times(1)).update(any(Submission.class));

            var evidences = submission.getEvidences();
            assertFalse(evidences.isEmpty());
            assertEquals(2, evidences.size());
            assertNull(evidenceS3Key);
        }

        @Test
        void shouldOnlyDeleteEvidenceFromSubmissionIfDocumentIsAlsoUsedInFeeWaiverUpload() {

            var documentId = UUID.randomUUID().toString();
            var submissionId = UUID.randomUUID().toString();
            var evidenceId = UUID.randomUUID().toString();
            var feeWaiverId = UUID.randomUUID().toString();
            var s3Key = "s3/key/forFile";

            Submission submission = new Submission();
            submission.setSubmissionId(submissionId);
            SubmissionForm submissionForm = new SubmissionForm();
            submissionForm.setId(documentId);
            submission.setForms(List.of(submissionForm));
            var evidence = SubmissionEvidence.builder().id(evidenceId).s3Key(s3Key).build();
            var feeWaiver = SubmissionEvidence.builder().id(feeWaiverId).s3Key(s3Key).build();
            submission.setEvidences(new ArrayList<>(List.of(evidence)));
            submission.setFeeWaiver(feeWaiver);
            submission.setUserRequestedFeeWaiver(true);
            submission.setUserRequestedPartialFeeWaiver(false);

            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            var evidenceS3Key = service.deleteEvidenceFromSubmission(myUscisId, orgMyUscisId, submissionId, evidenceId);
            verify(submissionDao, times(1)).update(any(Submission.class));

            var evidences = submission.getEvidences();
            assertTrue(evidences.isEmpty());
            assertNull(evidenceS3Key);
        }

        @Test
        @Disabled
        void shouldThrowExceptionWhenEvidenceIsNonExistent() {
            Submission submission = Instancio.create(Submission.class);
            submission.setSubmissionId(UUID.randomUUID().toString());
            submission.setForms(emptyList());

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            assertThrows(NoSuchElementException.class,
                    () -> service.deleteEvidenceFromSubmission(myUscisId, orgMyUscisId,
                            submission.getSubmissionId(), "NONEXISTENT_ID"));
        }

        @Test
        void shouldDeleteFormFromSubmissionWhenEligibilityCategoryIsC8() {
            String submissionId = UUID.randomUUID().toString();
            String feeWaiverId = UUID.randomUUID().toString();
            String feeWaiverS3key = UUID.randomUUID().toString();
            String formS3Key = UUID.randomUUID().toString();
            SubmissionForm submissionForm = SubmissionForm.builder().id(formId)
                    .eligibilityCategory(I765EligibilityCategory.C8)
                    .extractedData(
                            ExtractedFormEntries.builder().eligibilityCategory("C8")
                                    .isSalvadorianABCEligible(true).build())
                    .s3Key(formS3Key).build();
            SubmissionEvidence feeWaiver = SubmissionEvidence.builder().id(feeWaiverId)
                    .s3Key(feeWaiverS3key).build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(i765FormType)
                    .eligibilityCategory(I765EligibilityCategory.C8)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .forms(new ArrayList<SubmissionForm>(List.of(submissionForm)))
                    .feeWaiver(feeWaiver)
                    .build();

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);

            service.deleteFormFromSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId(),
                    submissionForm.getId());

            verify(s3Service, times(1)).deleteS3Object(formS3Key, false);
            verify(submissionDao, times(1)).update(captor.capture());
            verify(validationService, times(1)).deleteStatus(formId);

            assertEquals(1, captor.getValue().getForms().size());
            assertEquals(1, submission.getForms().size());
            // assertEquals(I765Fees.FEE_560, submission.getFeeTotal());
        }

        @Test
        @Disabled("There is no C9 IMMVI, and this behavior may have changed. Need to investigate further.")
        void shouldDeleteFormFromSubmissionAndResetFeeToZeroFeeWhenEligibilityCategoryIsC9AndImmviIsTrue() {
            String submissionId = UUID.randomUUID().toString();
            String formS3Key = UUID.randomUUID().toString();
            SubmissionForm submissionForm = SubmissionForm.builder().id(formId)
                    .eligibilityCategory(I765EligibilityCategory.C9)
                    .extractedData(
                            ExtractedFormEntries.builder()
                                    .eligibilityCategory("C9")
                                    .isSalvadorianABCEligible(false)
                                    .build())
                    .s3Key(formS3Key).build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(i765FormType)
                    .eligibilityCategory(I765EligibilityCategory.C9)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .forms(new ArrayList<SubmissionForm>(List.of(submissionForm)))
                    .immvi(true)
                    .build();

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.deleteFormFromSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId(),
                    submissionForm.getId());

            verify(s3Service, times(1)).deleteS3Object(formS3Key, false);
            verify(submissionDao, times(1)).update(captor.capture());
            verify(validationService, times(1)).deleteStatus(formId);

            assertEquals(0, captor.getValue().getForms().size());
            assertEquals(0, submission.getForms().size());
            assertNull(submission.getFeeWaiver());
            assertFalse(submission.getUserRequestedFeeWaiver());
        }

        @Test
        void shouldDeleteFormFromSubmission_I765() {
            String submissionId = UUID.randomUUID().toString();
            String s3Key = UUID.randomUUID().toString();
            SubmissionForm submissionForm = SubmissionForm.builder().id(formId).s3Key(s3Key).build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(i765FormType)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .immvi(false)
                    .eligibilityCategory(I765EligibilityCategory.C11AFGHAN)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .forms(new ArrayList<SubmissionForm>(List.of(submissionForm)))
                    .build();

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.deleteFormFromSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId(),
                    submissionForm.getId());
            verify(s3Service, times(1)).deleteS3Object(s3Key, false);
            verify(submissionDao, times(1)).update(captor.capture());
            verify(validationService, times(1)).deleteStatus(formId);

            assertEquals(1, submission.getForms().size());
            assertEquals(1, captor.getValue().getForms().size());
            // assertEquals(I765Fees.FEE_470, submission.getFeeTotal());
        }

        @Test
        void shouldDeleteFormFromSubmission_I765_errorScenario() {
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, "submissionId"))
                    .thenThrow(NoSuchElementException.class);

            assertThrows(NoSuchElementException.class,
                    () -> service.deleteFormFromSubmission(myUscisId, orgMyUscisId, "submissionId",
                            "submissionFormId"));
        }

        @Test
        void shouldDeleteFormFromSubmissionAndUpdateC11Fee() {
            String submissionId = UUID.randomUUID().toString();
            String s3Key = UUID.randomUUID().toString();
            SubmissionForm submissionForm = SubmissionForm.builder().id(formId).s3Key(s3Key).build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(i765FormType)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .eligibilityCategory(I765EligibilityCategory.C11AFGHAN)
                    .forms(new ArrayList<SubmissionForm>(List.of(submissionForm)))
                    .build();

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.deleteFormFromSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId(),
                    submissionForm.getId());
            verify(s3Service, times(1)).deleteS3Object(s3Key, false);
            verify(submissionDao, times(1)).update(captor.capture());
            verify(validationService, times(1)).deleteStatus(formId);

            Submission savedSubmission = captor.getValue();
            assertEquals(1, savedSubmission.getForms().size());
            // assertEquals(I765Fees.FEE_470, savedSubmission.getFeeTotal());
        }

        @Test
        void shouldDeleteFormFromSubmissionWithExtractedDataAndUpdateC11Fee() {
            String submissionId = UUID.randomUUID().toString();
            String s3Key = UUID.randomUUID().toString();
            SubmissionForm submissionForm = SubmissionForm.builder().id(formId).s3Key(s3Key).build();
            submissionForm.setExtractedData(ExtractedFormEntries.builder().build());

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(i765FormType)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .immvi(false)
                    .eligibilityCategory(I765EligibilityCategory.C11AFGHAN)
                    .forms(new ArrayList<SubmissionForm>(List.of(submissionForm)))
                    .build();

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.deleteFormFromSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId(),
                    submissionForm.getId());
            verify(s3Service, times(1)).deleteS3Object(s3Key, false);
            verify(submissionDao, times(1)).update(captor.capture());
            verify(validationService, times(1)).deleteStatus(formId);

            Submission savedSubmission = captor.getValue();
            assertEquals(1, savedSubmission.getForms().size());
            // assertEquals(I765Fees.FEE_470, savedSubmission.getFeeTotal());
        }

        @Test
        void shouldRetrieveSubmissionStatusWithoutMissingFieldErrorsWhenFeeWaiverIsFalse() {

            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .eligibilityCategory(I765EligibilityCategory.C11UKRAINE)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .formType(i765FormType)
                    .forms(asList(
                            SubmissionForm
                                    .builder().id("formId").name("formName")
                                    .type(i765FormType.getType())
                                    .md5Hash(Constants.MD5HASH).url("someURL")
                                    .build()))
                    .evidences(
                            asList(
                                    SubmissionEvidence.builder()
                                            .type("driversLicense")
                                            .name("evidenceName")
                                            .md5Hash(Constants.MD5HASH)
                                            .formId("formId")
                                            .url("someURL").s3Key("s3ky")
                                            .id("evidenceId").build()))
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse
                    .builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(i765FormType.getType())
                                    .errors(List.of())
                                    .build()))
                    .evidenceErrors(
                            asList(ErrorGroup.builder()
                                    .type("driversLicense")
                                    .formType(i765FormType.getType())
                                    .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldRetrieveSubmissionStatusWithoutMissingFieldErrorsWhenFeeWaiverIsTrue() {

            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .eligibilityCategory(I765EligibilityCategory.C11UKRAINE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .formType(i765FormType)
                    .forms(asList(
                            SubmissionForm
                                    .builder().id("formId").name("formName")
                                    .type(i765FormType.getType())
                                    .md5Hash(Constants.MD5HASH).url("someURL")
                                    .build()))
                    .evidences(
                            asList(
                                    SubmissionEvidence.builder()
                                            .type("driversLicense")
                                            .name("evidenceName")
                                            .md5Hash(Constants.MD5HASH)
                                            .formId("formId")
                                            .url("someURL").s3Key("s3Key")
                                            .id("evidenceId").build(),
                                    SubmissionEvidence.builder()
                                            .type("Other")
                                            .evidenceGroupType(
                                                    SubmissionService.FEE_WAIVER_EVIDENCE_GROUP)
                                            .name("evidenceName")
                                            .md5Hash(Constants.MD5HASH)
                                            .url("someURL").s3Key("s3Key")
                                            .formId("formId")
                                            .id("evidenceId")
                                            .build()))
                    .feeWaiver(SubmissionEvidence.builder().id("feeWaiverId").name("Fee Waiver")
                            .s3Key("s3key")
                            .formId("formId")
                            .type("I-912").build())
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse
                    .builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(i765FormType.getType())
                                    .errors(List.of())
                                    .build()))
                    .evidenceErrors(
                            asList(
                                    ErrorGroup.builder()
                                            .type("I-912")
                                            .errors(List.of("I-912 is missing Md5Hash",
                                                    "I-912 is missing URL"))
                                            .formType(FormType.I765.getType())
                                            .build(),
                                    ErrorGroup.builder()
                                            .type("driversLicense")
                                            .formType(FormType.I765.getType())
                                            .errors(List.of()).build(),
                                    ErrorGroup.builder()
                                            .type("Other")
                                            .formType(FormType.I765.getType())
                                                .errors(List.of()).build()))
                                                                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldRetrieveSubmissionStatusWithMissingFeeWaiverSupportWhenFeeWaiverIsTrue() {

            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .formType(i765FormType)
                    .forms(asList(
                            SubmissionForm.builder()
                                    .id("formId")
                                    .name("formName")
                                    .type(i765FormType.getType())
                                    .md5Hash(Constants.MD5HASH)
                                    .url("someURL")
                                    .build()))
                    .evidences(asList(
                            SubmissionEvidence.builder()
                                    .type("driversLicense")
                                    .evidenceGroupType("evidence_group")
                                    .name("evidenceName")
                                    .md5Hash(Constants.MD5HASH)
                                    .formId("formId")
                                    .url("someURL").s3Key("s3Key")
                                    .id("evidenceId")
                                    .build()))
                    .feeWaiver(SubmissionEvidence.builder()
                            .id("feeWaiverId")
                            .md5Hash(Constants.MD5HASH)
                            .url("someURL")
                            .formId("formId")
                            .name("Fee Waiver")
                            .s3Key("s3key")
                            .type("I-912")
                            .build())
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(i765FormType.getType())
                                    .errors(List.of())
                                    .build()))
                    .evidenceErrors(asList(
                            ErrorGroup.builder().type("I-912")
                                     .formType(FormType.I765.getType())
                                    .errors(List.of()).build(),
                            ErrorGroup.builder().type(
                                    SubmissionService.FEE_WAIVER_EVIDENCE_GROUP)
                                    .errors(List.of("Fee waiver evidence is missing"))
                                    .build(),
                            ErrorGroup.builder()
                                    .type("driversLicense")
                                    .formType(FormType.I765.getType())
                                    .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldRetrieveSubmissionStatusWithMissingFieldEvidenceErrors() {

            Submission submission = Submission
                    .builder()
                    .submissionId(UUID.randomUUID().toString())
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .formType(i765FormType)
                    .forms(
                            asList(
                                    SubmissionForm
                                            .builder()
                                            .type(i765FormType.getType())
                                            .name(null)
                                            .id("formId")
                                            .build()))
                    .evidences(
                            asList(SubmissionEvidence
                                    .builder()
                                    .type("Evidence")
                                    .formId("formId")
                                    .s3Key("s3Key")
                                    .build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of(
                            "An Eligibility Category was not selected",
                            "Provide Form I-912 or a signed letter to submit your fee waiver request."))
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(i765FormType.getType())
                                    .errors(List.of(
                                            "Your form I-765 is missing"))

                                    .build()))
                    .evidenceErrors(
                            asList(ErrorGroup.builder()
                                    .type("Evidence")
                                     .formType(FormType.I765.getType())

                                    .errors(List.of("Evidence is missing ID",
                                            "Evidence is missing Name",
                                            "Evidence is missing Md5Hash",
                                            "Evidence is missing URL"))
                                    .build()))
                    .build();

            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(1, expected.formErrors().get(0).errors().size());
        }

        @Test
        void shouldGetFailingStatusForI912FeeWaiver_nullFields() {
            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I765)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(List.of())
                    .feeWaiver(SubmissionEvidence.builder()
                            .id(null)
                            .md5Hash(null)
                            .url(null)
                            .name(null)
                            .s3Key("s3key")
                            .type("I-912")
                            .build())
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.I765.getType())
                                    .errors(List.of("Your Form I-765 is missing"))
                                    .build()))
                    .evidenceErrors(asList(
                            ErrorGroup.builder().type("I-912")
                                    .errors(List.of("I-912 is missing ID",
                                            "I-912 is missing Name",
                                            "I-912 is missing Md5Hash",
                                            "I-912 is missing URL"))
                                    .build(),
                            ErrorGroup.builder()
                                    .type(SubmissionService.FEE_WAIVER_EVIDENCE_GROUP)
                                    .errors(List.of("Fee waiver evidence is missing"))
                                    .build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);

            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldRetrieveSubmissionStatusWithFormValidationErrors() {
            String formName = "formName";

            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .eligibilityCategory(I765EligibilityCategory.C11UKRAINE)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .formType(i765FormType)
                    .forms(asList(
                            SubmissionForm
                                    .builder().id(formId).name(formName)
                                    .type(i765FormType.getType())
                                    .md5Hash(Constants.MD5HASH).url("someURL")
                                    .build()))
                    .evidences(
                            asList(
                                    SubmissionEvidence.builder()
                                            .type("driversLicense")
                                            .name("evidenceName")
                                            .md5Hash(Constants.MD5HASH)
                                            .url("someURL").s3Key("s3Key")
                                            .formId(formId)
                                            .id("evidenceId").build()))
                    .build();

            String eligibilityError = "Eligibility Category on the form is not supported.";
            String coreError = "The correct PDF page count should be 7. Your uploaded page count is 6.";
            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.I765.getType())
                                    .errors(List.of(eligibilityError, coreError))
                                    .build()))
                    .evidenceErrors(
                            asList(ErrorGroup.builder()
                                    .type("driversLicense")
                                    .formType(FormType.I765.getType())
                                    .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(validationService.queryValidationStatus(formId)).thenReturn(List.of(
                    ValidationStatus.builder()
                            .formId(formId)
                            .status(ValidationResultEnum.FAIL)
                            .validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                            .failureReasons(List.of(eligibilityError)).build(),
                    ValidationStatus.builder()
                            .formId(formId)
                            .status(ValidationResultEnum.FAIL)
                            .validator(ValidatorEnum.SIGNATURE)
                            .failureReasons(List.of("Signature was not detected.")).build(),
                    ValidationStatus.builder()
                            .formId(formId)
                            .status(ValidationResultEnum.FAIL)
                            .validator(ValidatorEnum.CORE)
                            .failureReasons(
                                    List.of(coreError))
                            .build()));

            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldRetrieveSubmissionStatusWithN400FormValidationErrorsForFormMissing() {
            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .formType(n400FormType)
                    .evidences(
                            asList(
                                    SubmissionEvidence.builder()
                                            .type("driversLicense")
                                            .name("evidenceName")
                                            .md5Hash(Constants.MD5HASH)
                                            .url("someURL").s3Key("s3Key")
                                            .id("evidenceId").build()))
                    .build();

            String coreError = "Your Form N-400 is missing";
            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.N400.getType())
                                    .errors(List.of(coreError))
                                    .build()))
                    .evidenceErrors(
                            asList(ErrorGroup.builder()
                                    .type("driversLicense")
                                    .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);

            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            org.assertj.core.api.Assertions.assertThat(actual).isEqualTo(expected);
        }

        @Test
        void shouldRetrieveSubmissionStatusWithI765FormValidationErrorsForFormMissing() {
            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .eligibilityCategory(I765EligibilityCategory.C11UKRAINE)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .formType(i765FormType)
                    .evidences(
                            asList(
                                    SubmissionEvidence.builder()
                                            .type("driversLicense")
                                            .name("evidenceName")
                                            .md5Hash(Constants.MD5HASH)
                                            .url("someURL").s3Key("s3Key")
                                            .id("evidenceId").build()))
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.I765.getType())
                                    .errors(List.of("Your Form I-765 is missing"))
                                    .build()))
                    .evidenceErrors(
                            asList(ErrorGroup.builder()
                                    .type("driversLicense")
                                    .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);

            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            org.assertj.core.api.Assertions.assertThat(actual).isEqualTo(expected);
        }

        @Test
        void shouldGetPassingStatusForFeeDeclaration() {

            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I765)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(asList(
                            SubmissionEvidence.builder()
                                    .type("driversLicense")
                                    .evidenceGroupType("evidence_group")
                                    .name("evidenceName")
                                    .md5Hash(Constants.MD5HASH)
                                    .url("someURL").s3Key("s3Key")
                                    .id("evidenceId")
                                    .build()))
                    .feeWaiver(SubmissionEvidence.builder()
                            .id("feeWaiverId")
                            .md5Hash(Constants.MD5HASH)
                            .url("someURL")
                            .name("Fee Waiver")
                            .s3Key("s3key")
                            .type("Fee Declaration")
                            .build())
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.I765.getType())
                                    .errors(List.of("Your Form I-765 is missing"))
                                    .build()))
                    .evidenceErrors(asList(
                            ErrorGroup.builder()
                                    .type("Fee Declaration")
                                    .errors(List.of()).build(),
                            ErrorGroup.builder().type(
                                    SubmissionService.FEE_WAIVER_EVIDENCE_GROUP)
                                    .errors(List.of("Fee waiver evidence is missing"))
                                    .build(),
                            ErrorGroup.builder()
                                    .type("driversLicense")
                                    .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(validationService.queryValidationStatus("feeWaiverId")).thenReturn(List.of(
                    ValidationStatus.builder()
                            .formId("feeWaiverId")
                            .status(ValidationResultEnum.FAIL)
                            .validator(ValidatorEnum.I912)
                            .failureReasons(List.of(FORM_TYPE_NOT_PRESENT_MESSAGE))
                            .build()));
            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
            verify(validationService, times(1)).queryValidationStatus("feeWaiverId");
        }

        @Test
        void shouldGetFailingStatusForI912FeeWaiver() {

            String feeWaiverId = "feeWaiverId";
            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I765)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(asList(
                            SubmissionEvidence.builder()
                                    .type("driversLicense")
                                    .evidenceGroupType("evidence_group")
                                    .name("evidenceName")
                                    .md5Hash(Constants.MD5HASH)
                                    .url("someURL").s3Key("s3Key")
                                    .id("evidenceId")
                                    .build()))
                    .feeWaiver(SubmissionEvidence.builder()
                            .id(feeWaiverId)
                            .md5Hash(Constants.MD5HASH)
                            .url("someURL")
                            .name("Fee Waiver")
                            .s3Key("s3key")
                            .type("I-912")
                            .build())
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.I765.getType())
                                    .errors(List.of("Your Form I-765 is missing"))
                                    .build()))
                    .evidenceErrors(asList(
                            ErrorGroup.builder().type("I-912")
                                    .errors(List.of("I912 Signature was not detected."))
                                    .build(),
                            ErrorGroup.builder().type(
                                    SubmissionService.FEE_WAIVER_EVIDENCE_GROUP)
                                    .errors(List.of("Fee waiver evidence is missing"))
                                    .build(),
                            ErrorGroup.builder()
                                    .type("driversLicense")
                                    .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(validationService.queryValidationStatus(feeWaiverId)).thenReturn(List.of(
                    ValidationStatus.builder()
                            .formId(feeWaiverId)
                            .status(ValidationResultEnum.FAIL)
                            .validator(ValidatorEnum.I912)
                            .failureReasons(List.of("I912 Signature was not detected."))
                            .build()));

            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldGetFailingStatusForFeeDeclarationFeeWaiver() {

            String feeWaiverId = "feeWaiverId";
            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I765)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(asList(
                            SubmissionEvidence.builder()
                                    .type("driversLicense")
                                    .evidenceGroupType("evidence_group")
                                    .name("evidenceName")
                                    .md5Hash(Constants.MD5HASH)
                                    .url("someURL").s3Key("s3Key")
                                    .id("evidenceId")
                                    .build()))
                    .feeWaiver(SubmissionEvidence.builder()
                            .id(feeWaiverId)
                            .md5Hash(Constants.MD5HASH)
                            .url("someURL")
                            .name("Fee Waiver")
                            .s3Key("s3key")
                            .type("Fee Declaration")
                            .build())
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()

                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.I765.getType())
                                    .errors(List.of("Your Form I-765 is missing"))
                                    .build()))
                    .evidenceErrors(asList(
                            ErrorGroup.builder().type("Fee Declaration")
                                    .errors(List.of("I912 Signature was not detected."))
                                    .build(),
                            ErrorGroup.builder().type(
                                    SubmissionService.FEE_WAIVER_EVIDENCE_GROUP)
                                    .errors(List.of("Fee waiver evidence is missing"))
                                    .build(),
                            ErrorGroup.builder()
                                    .type("driversLicense")
                                    .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(validationService.queryValidationStatus(feeWaiverId)).thenReturn(List.of(
                    ValidationStatus.builder()
                            .formId(feeWaiverId)
                            .status(ValidationResultEnum.FAIL)
                            .validator(ValidatorEnum.I912)
                            .failureReasons(List.of("I912 Signature was not detected."))
                            .build()));

            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldGetFailingStatusForI912FeeWaiver_blankFeeWaiverType() {
            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I765)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(List.of())
                    .feeWaiver(SubmissionEvidence.builder()
                            .id("feeWaiverId")
                            .md5Hash(Constants.MD5HASH)
                            .url("someURL")
                            .name("Fee Waiver")
                            .s3Key("s3key")
                            .type("")
                            .build())
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.I765.getType())
                                    .errors(List.of(
                                            "Your Form I-765 is missing"))
                                    .build()))
                    .evidenceErrors(asList(
                            ErrorGroup.builder().type("")
                                    .errors(List.of("Select the category for your fee waiver evidence"))
                                    .build(),
                            ErrorGroup.builder()
                                    .type(SubmissionService.FEE_WAIVER_EVIDENCE_GROUP)
                                    .errors(List.of("Fee waiver evidence is missing"))
                                    .build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);

            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldThrowNoSuchElementExceptionWhenSubmissionFormIsEmpty() {
            Submission submission = Submission.builder().forms(Collections.emptyList()).build();

            assertThrows(NoSuchElementException.class,
                    () -> service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                            submission.getSubmissionId()));

        }

        @Test
        public void completeSubmission_shouldRemoveUnusedFeeWaiver() throws Exception {

            Submission submission = Submission.builder()
                    .myUscisId(myUscisId)
                    .submissionId(submissionId)
                    .applicant(Instancio.create(UserInformation.class))
                    .formType(i765FormType)
                    .forms(singletonList(SubmissionForm.builder().build()))
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .feeWaiver(SubmissionEvidence.builder().s3Key("fee-waiver-s3-key").build())
                    .build();

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            when(submissionDao.getDraftById(any(), any(), any())).thenReturn(Optional.of(submission));
            when(paymentServiceClient.isAuthorized(any(), any(), any())).thenReturn(true);
            when(lockboxGatewayClient.sendTransmission(any())).thenReturn(Mono.just("manifestId"));
            service.completeSubmission(myUscisId, orgMyUscisId, submissionId).block();

            verify(submissionDao, times(2)).update(captor.capture());
            Submission captured = captor.getValue();
            assertEquals(LockboxStatuses.PENDING, captured.getLockboxStatus());
            assertEquals(SubmissionState.RECEIVED, captured.getStatus());
            assertNull(captured.getFeeWaiver());
            assertEquals(systemClockService.getSystemTime(), captured.getSubmittedAt());

            verify(s3Service).deleteS3Object("fee-waiver-s3-key", true);
            verify(myUscisCacheManagementClient).publishCaseChangeEvent(any(Submission.class));
        }

        @Test
        void completeSubmission_shouldUpdateFinalSubmission_FeeDeclarationTransformation()
                throws PaymentRequiredException {

            Submission submission = Submission.builder()
                    .myUscisId(myUscisId)
                    .submissionId(submissionId)
                    .applicant(Instancio.create(UserInformation.class))
                    .formType(i765FormType)
                    .forms(singletonList(SubmissionForm.builder().build()))
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .feeWaiver(SubmissionEvidence.builder().type("Fee Declaration").build())
                    .build();

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            when(submissionDao.getDraftById(any(), any(), any())).thenReturn(Optional.of(submission));
            when(paymentServiceClient.isAuthorized(any(), any(), any())).thenReturn(true);
            when(lockboxGatewayClient.sendTransmission(any())).thenReturn(Mono.just("manifestId"));
            service.completeSubmission(myUscisId, orgMyUscisId, submissionId).block();

            verify(submissionDao, times(2)).update(captor.capture());
            Submission captured = captor.getValue();
            assertNotNull(captured.getManifestId());
            assertEquals(LockboxStatuses.PENDING, captured.getLockboxStatus());
            assertEquals(SubmissionState.RECEIVED, captured.getStatus());
            assertEquals("I-912", captured.getFeeWaiver().getType());
            assertEquals(systemClockService.getSystemTime(), captured.getSubmittedAt());

            verify(myUscisCacheManagementClient).publishCaseChangeEvent(any(Submission.class));

            verifyNoInteractions(s3Service);
        }

        @Test
        void getValidationStatus_returnsNoErrors()
                throws PaymentRequiredException {
            FinalSubmissionDto finalSubmissionDto = FinalSubmissionDto.builder()
                    .attested(true)
                    .type(FormType.I131)
                    .category(I131EligibilityCategory.TPS_BENEFICIARY)
                    .submissionId("submissionId").userRequestedFeeWaiver(false)
                    .status(SubmissionState.DRAFT)
                    .forms(List.of(SubmissionForm.builder().build()))
                    .evidences(List.of(SubmissionEvidence.builder().type("Passport").build()))
                    .attested(true)
                    .hasReviewedSignature(true)
                    .signature("some signature")
                    .validations(List.of(new ValidationDetails(PFVS, PASS, null, null),
                            new ValidationDetails(CORE, PASS, null, null),
                            new ValidationDetails(SIGNATURE, FAIL, List.of("Applicant signature is missing"), null),
                            new ValidationDetails(ELIGIBILITY_CATEGORY, PASS, null, null)))
                    .build();
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);

            assertEquals(service.getValidationStatus(myUscisId, finalSubmissionDto), new ArrayList<>());
        }

        @Test
        void getValidationStatus_returnsValidationErrors()
                throws PaymentRequiredException {
            FinalSubmissionDto finalSubmissionDto = FinalSubmissionDto.builder()
                    .attested(true)
                    .type(FormType.I131)
                    .category(I131EligibilityCategory.TPS_BENEFICIARY)
                    .submissionId("submissionId").userRequestedFeeWaiver(false)
                    .status(SubmissionState.DRAFT)
                    .forms(List.of(SubmissionForm.builder().build()))
                    .evidences(List.of(SubmissionEvidence.builder().type("Passport").build()))
                    .attested(true)
                    .hasReviewedSignature(true)
                    .signature("some signature")
                    .validations(List.of(new ValidationDetails(PFVS, PASS, null, null),
                            new ValidationDetails(CORE, FAIL,
                                    List.of("Not all pages are present", "Pages are not in correct order"), null),
                            new ValidationDetails(SIGNATURE, FAIL, List.of("Applicant signature is missing"), null),
                            new ValidationDetails(ELIGIBILITY_CATEGORY, FAIL,
                                    List.of("Selected eligibility category does not match form"), null)))
                    .build();
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);

            List<String> expectedResponse = List.of(
                    List.of("Not all pages are present", "Pages are not in correct order").toString(),
                    List.of("Selected eligibility category does not match form").toString());

            assertEquals(service.getValidationStatus(myUscisId, finalSubmissionDto), expectedResponse);
        }

        @Test
        void getValidationStatus_returnsPFVSNotFoundError()
                throws PaymentRequiredException {
            FinalSubmissionDto finalSubmissionDto = FinalSubmissionDto.builder()
                    .attested(true)
                    .type(FormType.I131)
                    .category(I131EligibilityCategory.TPS_BENEFICIARY)
                    .submissionId("submissionId").userRequestedFeeWaiver(false)
                    .status(SubmissionState.DRAFT)
                    .forms(List.of(SubmissionForm.builder().build()))
                    .evidences(List.of(SubmissionEvidence.builder().type("Passport").build()))
                    .attested(true)
                    .hasReviewedSignature(true)
                    .signature("some signature")
                    .validations(List.of(new ValidationDetails(CORE, PASS, null, null),
                            new ValidationDetails(SIGNATURE, FAIL, List.of("Applicant signature is missing"), null),
                            new ValidationDetails(ELIGIBILITY_CATEGORY, PASS, null, null)))
                    .build();
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);

            List<String> expectedResponse = List.of("PFVS Validation status could not be retrieved");

            assertEquals(service.getValidationStatus(myUscisId, finalSubmissionDto), expectedResponse);
        }

        @Test
        void getValidationStatus_passesForNonPFVSSupportedFormType()
                throws PaymentRequiredException {
            FinalSubmissionDto finalSubmissionDto = FinalSubmissionDto.builder()
                    .attested(true)
                    .type(FormType.I765)
                    .category(I765EligibilityCategory.A12)
                    .submissionId("submissionId").userRequestedFeeWaiver(false)
                    .status(SubmissionState.DRAFT)
                    .forms(List.of(SubmissionForm.builder().build()))
                    .evidences(List.of(SubmissionEvidence.builder().type("Passport").build()))
                    .attested(true)
                    .hasReviewedSignature(true)
                    .signature("some signature")
                    .validations(List.of(new ValidationDetails(PFVS, PASS, null, null),
                            new ValidationDetails(CORE, FAIL,
                                    List.of("Not all pages are present", "Pages are not in correct order"), null),
                            new ValidationDetails(SIGNATURE, FAIL, List.of("Applicant signature is missing"), null),
                            new ValidationDetails(ELIGIBILITY_CATEGORY, FAIL,
                                    List.of("Selected eligibility category does not match form"), null)))
                    .build();
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I765.getType())).thenReturn(false);

            assertEquals(service.getValidationStatus(myUscisId, finalSubmissionDto), new ArrayList<>());
        }

        @Test
        void testUpdateSubmissionWithLockBoxStatusAccepted() {
            Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                    .applicant(Instancio.create(UserInformation.class)).build();
            submission.getApplicant().setAccountType(AccountType.APPLICANT);
            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.SUBMISSION)
                    .submissionUpdate(SubmissionUpdate.builder()
                            .status(StatusEnum.ACCEPTED)
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertEquals(LockboxStatuses.ACCEPTED, submission.getLockboxStatus());
            assertEquals(SubmissionState.ACCEPTED, submission.getStatus());
        }

        @Test
        void testUpdateSubmissionWithLockBoxStatusRejected() {
            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString()).applicant(Instancio.create(UserInformation.class))
                    .build();
            submission.getApplicant().setAccountType(AccountType.APPLICANT);
            var request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.SUBMISSION)
                    .submissionUpdate(SubmissionUpdate.builder()
                            .status(StatusEnum.REJECTED)
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            when(submissionDao.update(submission)).thenReturn(submission);

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertEquals(LockboxStatuses.REJECTED, submission.getLockboxStatus());
            assertEquals(SubmissionState.REJECTED, submission.getStatus());
        }

        @Test
        @DisplayName("When the Manifest status is RECEIVED, the Lockbox Status is set to RECEIVED")
        void testUpdateSubmissionWithLockBoxStatusReceived() {
            Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                    .applicant(Instancio.create(UserInformation.class)).build();
            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.MANIFEST)
                    .manifestUpdate(ManifestUpdate.builder()
                            .status(StatusEnum.RECEIVED)
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            when(submissionDao.update(submission)).thenReturn(submission);

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertEquals(LockboxStatuses.RECEIVED, submission.getLockboxStatus());
        }

        @Test
        @DisplayName("When the Manifest status is COMPLETE, the Lockbox Status is set to PROCESSING")
        void testUpdateSubmissionWithLockBoxStatusProcessing() {
            Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                    .applicant(Instancio.create(UserInformation.class)).build();
            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.MANIFEST)
                    .manifestUpdate(ManifestUpdate.builder()
                            .status(StatusEnum.COMPLETE)
                            .build())
                    .build();

            when(submissionDao.getById(anyString())).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertEquals(LockboxStatuses.PROCESSING, submission.getLockboxStatus());
        }

        @Test
        @DisplayName("When the Manifest status is ERROR, the Lockbox Status is set to ERROR")
        void testUpdateSubmissionWithLockBoxStatusError() {
            Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                    .applicant(Instancio.create(UserInformation.class)).build();
            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.MANIFEST)
                    .manifestUpdate(ManifestUpdate.builder()
                            .status(StatusEnum.ERROR)
                            .errors(List.of(ManifestError.builder()
                                    .id("98765")
                                    .errorCode("E1")
                                    .description("Manifest produced an error")
                                    .build()))
                            .build())
                    .build();

            when(submissionDao.getById(anyString())).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertEquals(LockboxStatuses.ERROR, submission.getLockboxStatus());
            assertThat(submission.getLockboxErrors(),
                    contains(hasProperty("description", equalTo("Manifest produced an error"))));
        }

        @Test
        @DisplayName("When the submission ID is INVALID, error is thrown")
        void testUpdateSubmissionWithInvalidSubmissionId() {
            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder().build();

            when(submissionDao.getById(anyString())).thenReturn(Optional.empty());
            assertThrows(NoSuchElementException.class,
                    () -> service.updateSubmissionWithLockBoxStatus("54321", request));
        }

        @Test
        void testRetrieveDraftSubmissions() {
            when(submissionDao.findAllDraftsByMyUscisId(myUscisId)).thenReturn(emptyList());
            List<Submission> actualResult = service.retrieveDraftSubmissions(myUscisId);

            List<Submission> expectedResult = new ArrayList<>();
            assertEquals(expectedResult, actualResult);
        }

        @Test
        void testRetrieveDraftSubmissions_whenErrorIsThrown() {
            when(submissionDao.findAllDraftsByMyUscisId(myUscisId))
                    .thenThrow(new RuntimeException("Not found"));

            assertThrows(SubmissionIndexException.class,
                    () -> service.retrieveDraftSubmissions(myUscisId));
        }

        @Test
        @DisplayName("Retrieve Draft Submissions | Audit files")
        void testRetrieveDraftSubmissionsAndUpdateFilesThatHaveBeenRemoved() {
            String submissionId = UUID.randomUUID().toString();
            var documentId = UUID.randomUUID().toString();
            var evidenceId = UUID.randomUUID().toString();
            var feeWaiverId = UUID.randomUUID().toString();
            var s3Key = "s3/key/forFile";

            Submission submission = new Submission();
            submission.setSubmissionId(submissionId);
            SubmissionForm submissionForm = new SubmissionForm();
            submissionForm.setId(documentId);
            submission.setForms(List.of(submissionForm));
            var evidence = SubmissionEvidence.builder().id(evidenceId).s3Key(s3Key).build();
            var feeWaiver = SubmissionEvidence.builder().id(feeWaiverId).s3Key("s3Key").build();
            submission.setEvidences(new ArrayList<>(List.of(evidence)));
            submission.setFeeWaiver(feeWaiver);
            submission.setUserRequestedFeeWaiver(true);

            when(s3Service.checkIfFileExists(evidence.getS3Key(), false)).thenReturn(false);
            when(s3Service.checkIfFileExists(feeWaiver.getS3Key(), false)).thenReturn(true);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            Submission returnedFromUpdate = Submission.builder().build();
            when(submissionDao.update(any(Submission.class))).thenReturn(returnedFromUpdate);

            Submission actualResult = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

            assertEquals(actualResult, returnedFromUpdate);

            var captor = ArgumentCaptor.forClass(Submission.class);
            verify(submissionDao, times(1)).update(captor.capture());
            Submission value = captor.getValue();
            assertEquals(0, value.getEvidences().size());
            assertNotNull(value.getFeeWaiver());
        }

        @Test
        @DisplayName("Retrieve Draft Submissions, fee waiver doesn't exist in S3")
        void testRetrieveDraftSubmissionsAndUpdateFilesThatHaveBeenRemoved_feeWaiverDoesntExistInS3() {
            String submissionId = UUID.randomUUID().toString();
            var evidenceId = UUID.randomUUID().toString();
            var feeWaiverId = UUID.randomUUID().toString();
            var s3Key = "s3/key/forFile";

            SubmissionForm submissionForm = new SubmissionForm();
            SubmissionEvidence evidence = SubmissionEvidence.builder().id(evidenceId).s3Key(s3Key).build();
            SubmissionEvidence feeWaiver = SubmissionEvidence.builder().id(feeWaiverId).s3Key("s3Key")
                    .build();
            Submission submission = Submission.builder().submissionId(submissionId)
                    .forms(List.of(submissionForm))
                    .evidences(new ArrayList<>(List.of(evidence))).userRequestedFeeWaiver(true)
                    .feeWaiver(feeWaiver).build();

            when(s3Service.checkIfFileExists(evidence.getS3Key(), false)).thenReturn(false);
            when(s3Service.checkIfFileExists(feeWaiver.getS3Key(), false)).thenReturn(false);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            Submission returnedFromUpdate = Submission.builder().build();
            when(submissionDao.update(any(Submission.class))).thenReturn(returnedFromUpdate);

            Submission actualResult = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

            assertEquals(actualResult, returnedFromUpdate);

            var captor = ArgumentCaptor.forClass(Submission.class);
            verify(submissionDao, times(1)).update(captor.capture());
            Submission value = captor.getValue();
            assertEquals(0, value.getEvidences().size());
        }

        @Test
        @DisplayName("Retrieve Draft Submissions | Audit files")
        void testRetrieveDraftSubmissionsAndAndDontUpdateAnythingBecauseAllFilesAreAvailable() {
            String submissionId = UUID.randomUUID().toString();
            var documentId = UUID.randomUUID().toString();
            var evidenceId = UUID.randomUUID().toString();
            var feeWaiverId = UUID.randomUUID().toString();
            var s3Key = "s3/key/forFile";

            SubmissionForm submissionForm = SubmissionForm.builder().id(documentId).build();
            SubmissionEvidence evidence = SubmissionEvidence.builder().id(evidenceId).s3Key(s3Key).build();
            SubmissionEvidence feeWaiver = SubmissionEvidence.builder().id(feeWaiverId).s3Key("s3Key")
                    .build();
            Submission submission = Submission.builder().submissionId(submissionId)
                    .forms(List.of(submissionForm))
                    .evidences(new ArrayList<>(List.of(evidence))).feeWaiver(feeWaiver)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .build();

            when(s3Service.checkIfFileExists(evidence.getS3Key(), false)).thenReturn(true);
            when(s3Service.checkIfFileExists(feeWaiver.getS3Key(), false)).thenReturn(true);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            Submission actualResult = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

            assertEquals(submission, actualResult);

            verify(submissionDao, times(0)).update(any(Submission.class));
        }

        // @Test
        public void shouldDeleteClientInformationIfSubmissionIsDeleted() {
            String submissionId = UUID.randomUUID().toString();
            String formS3Key = UUID.randomUUID().toString();
            String evidenceS3Key = UUID.randomUUID().toString();
            SubmissionEvidence evidence = SubmissionEvidence.builder().s3Key(evidenceS3Key).build();
            SubmissionForm form = SubmissionForm.builder().s3Key(formS3Key).build();
            Submission submission = Submission.builder().userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .applicant(UserInformation.builder().accountType(AccountType.REPRESENTATIVE).build())
                    .submissionId(submissionId).forms(List.of(form))
                    .evidences(List.of(evidence)).feeWaiver(evidence).build();

            var clientInformation = mock(ClientInformation.class);
            when(clientInformationRepository.findBySubmissionId(any())).thenReturn(clientInformation);

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(s3Service.deleteS3Object(formS3Key, false))
                    .thenReturn(S3Constants.DELETION_SUCCESS_MESSAGE);
            when(s3Service.deleteS3Object(evidenceS3Key, true))
                    .thenReturn(S3Constants.DELETION_SUCCESS_MESSAGE);

            service.deleteDraftSubmission(myUscisId, orgMyUscisId, submissionId);
            verify(submissionDao, times(1)).deleteById(submission.getSubmissionId());
            verify(clientInformationRepository, times(1)).delete(clientInformation);
        }

        @Test
        public void shouldNotAttemptToDeleteClientInformationIfApplicantTypeisApplicant() {
            String submissionId = UUID.randomUUID().toString();
            String formS3Key = UUID.randomUUID().toString();
            String evidenceS3Key = UUID.randomUUID().toString();
            SubmissionEvidence evidence = SubmissionEvidence.builder().s3Key(evidenceS3Key).build();
            SubmissionForm form = SubmissionForm.builder().s3Key(formS3Key).build();
            Submission submission = Submission.builder().userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .applicant(UserInformation.builder().accountType(AccountType.APPLICANT).build())
                    .submissionId(submissionId).forms(List.of(form))
                    .evidences(List.of(evidence)).feeWaiver(evidence).build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(s3Service.deleteS3Object(formS3Key, false))
                    .thenReturn(S3Constants.DELETION_SUCCESS_MESSAGE);
            when(s3Service.deleteS3Object(evidenceS3Key, true))
                    .thenReturn(S3Constants.DELETION_SUCCESS_MESSAGE);

            service.deleteDraftSubmission(myUscisId, orgMyUscisId, submissionId);
            verify(submissionDao, times(1)).deleteById(submission.getSubmissionId());
            verify(clientInformationRepository, never()).delete(any());
        }

        @Test
        public void shouldNotAttempToDeleteClientInformationIfClientInformationisNull() {
            String submissionId = UUID.randomUUID().toString();
            String formS3Key = UUID.randomUUID().toString();
            String evidenceS3Key = UUID.randomUUID().toString();
            SubmissionEvidence evidence = SubmissionEvidence.builder().s3Key(evidenceS3Key).build();
            SubmissionForm form = SubmissionForm.builder().s3Key(formS3Key).build();
            Submission submission = Submission.builder().userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .applicant(UserInformation.builder().accountType(AccountType.REPRESENTATIVE).build())
                    .submissionId(submissionId).forms(List.of(form))
                    .evidences(List.of(evidence)).feeWaiver(evidence).build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(s3Service.deleteS3Object(formS3Key, false))
                    .thenReturn(S3Constants.DELETION_SUCCESS_MESSAGE);
            when(s3Service.deleteS3Object(evidenceS3Key, true))
                    .thenReturn(S3Constants.DELETION_SUCCESS_MESSAGE);

            service.deleteDraftSubmission(myUscisId, orgMyUscisId, submissionId);
            verify(submissionDao, times(1)).deleteById(submission.getSubmissionId());
            verify(clientInformationRepository, never()).delete(any());
        }

        @Test
        void shouldDeleteDraftSubmissionWithFormAndEvidenceAndFeeWaiver() {

            String submissionId = UUID.randomUUID().toString();
            String formS3Key = UUID.randomUUID().toString();
            String evidenceS3Key = UUID.randomUUID().toString();
            SubmissionEvidence evidence = SubmissionEvidence.builder().s3Key(evidenceS3Key).build();
            SubmissionForm form = SubmissionForm.builder().s3Key(formS3Key).build();
            Submission submission = Submission.builder().userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .submissionId(submissionId).forms(List.of(form))
                    .evidences(List.of(evidence)).feeWaiver(evidence).build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(s3Service.deleteS3Object(formS3Key, false))
                    .thenReturn(S3Constants.DELETION_SUCCESS_MESSAGE);
            when(s3Service.deleteS3Object(evidenceS3Key, true))
                    .thenReturn(S3Constants.DELETION_SUCCESS_MESSAGE);

            service.deleteDraftSubmission(myUscisId, orgMyUscisId, submissionId);
            verify(submissionDao, times(1)).deleteById(submission.getSubmissionId());
        }

        @Test
        void shouldDeleteDraftSubmissionWithNoEvidenceNoFormNoFeeWaiver() {

            String submissionId = UUID.randomUUID().toString();
            Submission submission = Submission.builder().userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .submissionId(submissionId).build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.deleteDraftSubmission(myUscisId, orgMyUscisId, submissionId);
            verify(submissionDao, times(1)).deleteById(submission.getSubmissionId());
        }

        @Test
        void shouldThrowSubmissionDeleteException() {
            String submissionId = UUID.randomUUID().toString();

            assertThrows(SubmissionDeleteException.class,
                    () -> service.deleteDraftSubmission(myUscisId, orgMyUscisId, submissionId));
        }

        @Test
        void updateFeeWaiverRequested_false_shouldUpdateI765Submission() {
            final Submission original = Submission.builder()
                    .myUscisId(myUscisId)
                    .submissionId(submissionId)
                    .formType(i765FormType)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .attested(true)
                    .attestationSignature("signature")
                    .status(SubmissionState.DRAFT)
                    .attestedAt(ZonedDateTime.now())
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            Submission result = service.updateUserRequestedFeeWaiver(myUscisId, orgMyUscisId, submissionId, false);
            assertFalse(result.getUserRequestedFeeWaiver());
            assertFalse(result.getAttested());
            assertNull(result.getAttestationSignature());
            assertNull(result.getAttestedAt());

            verify(submissionDao, times(1)).update(same(result));
            verify(auditService, times(1)).addEvent(myUscisId, submissionId, FEE_WAIVER_REQUESTED, "false");
        }

        @Test
        void updateFeeWaiverRequested_false_shouldRecalculateFees() {
            final Submission original = Submission.builder()
                    .myUscisId(myUscisId)
                    .submissionId(submissionId)
                    .formType(i131FormType)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .attested(true)
                    .attestationSignature("signature")
                    .status(SubmissionState.DRAFT)
                    .attestedAt(ZonedDateTime.now())
                    .forms(List.of(SubmissionForm.builder().id(formId).type(i131FormType.getType()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            when(toggleService.isToggleActive(PFVSEvidenceType.I912.getToggle(), i131FormType.getType()))
                    .thenReturn(true);
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, i131FormType.getType())).thenReturn(true);

            Submission result = service.updateUserRequestedFeeWaiver(myUscisId, orgMyUscisId, submissionId, false);
            assertFalse(result.getUserRequestedFeeWaiver());
            assertFalse(result.getAttested());
            assertNull(result.getAttestationSignature());
            assertNull(result.getAttestedAt());

            verify(validationService).deleteStatus(formId);
            verify(sqsService).sendValidationRequest(any(ValidationRequest.class));
            verify(submissionDao, times(1)).update(same(result));
            verify(auditService, times(1)).addEvent(myUscisId, submissionId, FEE_WAIVER_REQUESTED, "false");
        }

        @Test
        void shouldUpdateSubmissionWithSelectedEligibilityCategory() {
            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    // .feeTotal(I765Fees.FEE_470)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .build();
            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(I765EligibilityCategory.C11PAROLE);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.updateEligibility(submission.getSubmissionId(), submission.getMyUscisId(),
                    submission.getOrgMyUscisId(), request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(auditService, times(1)).addEvent(anyString(), anyString(), any(ActionPerformed.class),
                    anyString());
            verify(feeService, times(1)).calculateFeeFor(i765FormType, request.getEligibilityCategory(),
                    new I765C11FeeStrategyOptions(false, false, false, ReasonForFiling.INITIAL.toString(), false));
            assertEquals(request.getEligibilityCategory(), captor.getValue().getEligibilityCategory());
        }

        @Test
        void shouldUpdateSubmissionWithSelectedEligibilityCategoryWithSubCategory() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            String s3Key = "fake-key";
            SubmissionForm form = SubmissionForm.builder()
                    .id(formId)
                    .name(i131FormType.getType())
                    .type(i131FormType.getType())
                    .uploadedAt(ZonedDateTime.now())
                    .s3Key(s3Key).build();
            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i131FormType)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .feeTotal(I131Fees.FULL_FEE)
                    .myUscisId(myUscisId)
                    .forms(asList(form))
                    .build();
            var newEligibilityCategory = I131EligibilityCategory.ADVANCE_PAROLE;
            var newEligibilitySubcategory = I131AdvancedParoleEligibilitySubcategory.APPROVED_817;
            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(newEligibilityCategory);
            request.setEligibilitySubcategory(newEligibilitySubcategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i131FormType.getType());

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, i131FormType.getType())).thenReturn(true);

            service.updateEligibility(submission.getSubmissionId(), submission.getMyUscisId(),
                    submission.getOrgMyUscisId(), request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(auditService, times(1)).addEvent(anyString(), anyString(), any(ActionPerformed.class),
                    anyString());
            verify(sqsService, times(1))
                    .sendValidationRequest(new ValidationRequest(submission.getSubmissionId(), formId, formId,
                            submission.getMyUscisId(), null, null, s3Key, submission.getFormType().getType(),
                            submission.getFormType().getType(), benefitTypeCode, appReasonCode, null, List.of(formId),
                            List.of(), null));
            assertEquals(newEligibilityCategory, captor.getValue().getEligibilityCategory());
            assertEquals(newEligibilitySubcategory, captor.getValue().getEligibilitySubcategory());
        }

        @Test
        void shouldUpdateConcurrentEligibilityCategoryIfFormDoesntExist() {
            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i130FormType)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I130.getType())
                            .build()))
                    .build();
            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(I131EligibilityCategory.TPS_BENEFICIARY);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i131FormType.getType());

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.updateEligibility(submission.getSubmissionId(), submission.getMyUscisId(),
                    submission.getOrgMyUscisId(), request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            assertNotNull(captor.getValue().getForms().stream()
                    .filter(form -> form.getType().equals(FormType.I131.getType())).findFirst());
        }

        @Test
        void shouldUpdateSubmissionWithImmviSelectionOfTrue() {
            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .feeWaiver(SubmissionEvidence.builder().s3Key("s3key").build())
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .userRequestedFeeWaiver(true)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .myUscisId(myUscisId)
                    .build();
            final var updatedSubmission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .immvi(true)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .feeWaiver(null)
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .userRequestedFeeWaiver(false)
                    .myUscisId(myUscisId)
                    .build();
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, i765FormType.getType())).thenReturn(true);

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenReturn(updatedSubmission);

            var resultingSubmission = service.updateImmvi(submission.getSubmissionId(), submission.getMyUscisId(),
                    submission.getOrgMyUscisId(),
                    true);

            assertTrue(resultingSubmission.getImmvi());
            assertNull(resultingSubmission.getFeeWaiver());
            assertFalse(resultingSubmission.getUserRequestedFeeWaiver());
        }

        @Test
        void shouldUpdateSubmissionWithImmviSelectionOfFalse() {
            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(true)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .userRequestedFeeWaiver(false)
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .myUscisId(myUscisId)
                    .orgMyUscisId(orgMyUscisId)
                    .build();

            final var updatedSubmission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .userRequestedFeeWaiver(false)
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .myUscisId(myUscisId)
                    .build();

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenReturn(updatedSubmission);

            var resultingSubmission = service.updateImmvi(submission.getSubmissionId(), submission.getMyUscisId(),
                    submission.getOrgMyUscisId(),
                    false);

            assertFalse(resultingSubmission.getImmvi());
        }

        @Test
        void shouldThrowErrorWhenTryingToUpdateImmviWithNonI765FormType() {
            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(n400FormType)
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .feeTotal(N400Fees.FULL_FEE)
                    .myUscisId(myUscisId)
                    .build();

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenReturn(submission);

          String submissionIdString = submission.getSubmissionId();
            String myUscisIdString = submission.getMyUscisId();
            String orgId = submission.getOrgMyUscisId();

            assertThrows(SubmissionBadException.class,
                () -> service.updateImmvi(submissionIdString, myUscisIdString, orgId, false)
            );
        }

        @Test
        void shouldResetImmviSelectionWhenEligibilityCategoryIsNotC11Parole() {
            String reasonForFiling = "1.a.";
            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .reasonForFiling(reasonForFiling)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(true)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .myUscisId(myUscisId)
                    .userRequestedPartialFeeWaiver(false)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(I765EligibilityCategory.A12);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.updateEligibility(submission.getSubmissionId(), submission.getMyUscisId(),
                    submission.getOrgMyUscisId(), request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            assertFalse(captor.getValue().getImmvi());
        }

        @Test
        void shouldUpdateSubmissionWithReasonForFilingSelectionOfInitial() {
            final String originalReasonForFiling = ReasonForFiling.RENEWAL.toString();
            final String newReasonForFiling = ReasonForFiling.INITIAL.toString();
            SubmissionForm submissionForm = SubmissionForm.builder()
                    .type(FormType.I765.getType())
                    .build();

            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .forms(List.of(submissionForm))
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(true)
                    .reasonForFiling(originalReasonForFiling)
                    .userRequestedFeeWaiver(false)
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .myUscisId(myUscisId)
                    .build();

            final var updatedSubmission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .forms(List.of(submissionForm))
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(true)
                    .reasonForFiling(newReasonForFiling)
                    .userRequestedFeeWaiver(false)
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .myUscisId(myUscisId)
                    .build();

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class)))
                    .thenReturn(updatedSubmission);

            var resultingSubmission = service.updateReasonForFiling(submission.getSubmissionId(),
                    submission.getMyUscisId(), submission.getOrgMyUscisId(), newReasonForFiling);

            assertEquals(resultingSubmission.getReasonForFiling(), newReasonForFiling);
            assertEquals(ReasonForFiling.INITIAL.getBenefitTypeCode(), resultingSubmission.getBenefitTypeCode());
            assertEquals(ReasonForFiling.INITIAL.getBenefitTypeCode(), submissionForm.getBenefitTypeCode());
        }

        @Test
        void shouldUpdateSubmissionWithReasonForFilingSelectionOfReplacement() {
            final String originalReasonForFiling = ReasonForFiling.RENEWAL.toString();
            final String newReasonForFiling = ReasonForFiling.REPLACEMENT.toString();
            SubmissionForm submissionForm = SubmissionForm.builder()
                    .type(FormType.I765.getType())
                    .build();

            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .forms(List.of(submissionForm))
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(true)
                    .userRequestedFeeWaiver(false)
                    .reasonForFiling(originalReasonForFiling)
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .myUscisId(myUscisId)
                    .build();
            final var updatedSubmission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .forms(List.of(submissionForm))
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(true)
                    .userRequestedFeeWaiver(false)
                    .reasonForFiling(newReasonForFiling)
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .myUscisId(myUscisId)
                    .build();

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class)))
                    .thenReturn(updatedSubmission);

            var resultingSubmission = service.updateReasonForFiling(submission.getSubmissionId(),
                    submission.getMyUscisId(), submission.getOrgMyUscisId(), newReasonForFiling);

            assertEquals(resultingSubmission.getReasonForFiling(), newReasonForFiling);
            assertEquals(ReasonForFiling.REPLACEMENT.getBenefitTypeCode(), resultingSubmission.getBenefitTypeCode());
            assertEquals(ReasonForFiling.REPLACEMENT.getBenefitTypeCode(), submissionForm.getBenefitTypeCode());
        }

        @Test
        void shouldUpdateSubmissionWithReasonForFilingSelectionOfRenewal() {
            final String originalReasonForFiling = ReasonForFiling.INITIAL.toString();
            final String newReasonForFiling = ReasonForFiling.RENEWAL.toString();
            SubmissionForm submissionForm = SubmissionForm.builder()
                    .type(FormType.I765.getType())
                    .build();

            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .forms(List.of(submissionForm))
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(true)
                    .reasonForFiling(originalReasonForFiling)
                    .userRequestedFeeWaiver(false)
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .myUscisId(myUscisId)
                    .build();
            final var updatedSubmission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .forms(List.of(submissionForm))
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(true)
                    .reasonForFiling(newReasonForFiling)
                    .userRequestedFeeWaiver(false)
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder()
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .s3Key("s3Key")
                                    .build()))
                    .myUscisId(myUscisId)
                    .build();

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class)))
                    .thenReturn(updatedSubmission);

            var resultingSubmission = service.updateReasonForFiling(submission.getSubmissionId(),
                    submission.getMyUscisId(), submission.getOrgMyUscisId(), newReasonForFiling);

            assertEquals(resultingSubmission.getReasonForFiling(), newReasonForFiling);
            assertEquals(ReasonForFiling.RENEWAL.getBenefitTypeCode(), resultingSubmission.getBenefitTypeCode());
            assertEquals(ReasonForFiling.RENEWAL.getBenefitTypeCode(), submissionForm.getBenefitTypeCode());
        }

        @Test
        void shouldResetReasonForFilingSelectionWhenEligibilityCategoryIsNotApplicable() {
            SubmissionForm submissionForm = SubmissionForm.builder()
                    .type(FormType.I765.getType())
                    .build();
            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .forms(List.of(submissionForm))
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .immvi(true)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .myUscisId(myUscisId)
                    .userRequestedPartialFeeWaiver(false)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(I765EligibilityCategory.C9);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.updateEligibility(submission.getSubmissionId(), submission.getMyUscisId(),
                    submission.getOrgMyUscisId(), request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            // We always default to Initial for resason for filing
            assertEquals(captor.getValue().getReasonForFiling(), "Initial");
        }

        @Test
        void shouldRevalidateReasonForFilingSelectionWhenFileUploadExistsAndSelectionChanged() {
            final ReasonForFiling originalReason = ReasonForFiling.INITIAL;
            final ReasonForFiling newReason = ReasonForFiling.REPLACEMENT;

            final Submission originalSubmission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .forms(asList(SubmissionForm
                            .builder().id(formId).name("formName")
                            .md5Hash(Constants.MD5HASH).url("someURL")
                            .type(i765FormType.getType())
                            .s3Key("mock-s3key")
                            .extractedData(ExtractedFormEntries.builder()
                                    .reasonForFiling("1.a.") // 1.a. = Initial
                                    .build())
                            .build()))
                    .status(SubmissionState.DRAFT)
                    // .feeTotal(I765Fees.FEE_470)
                    .eligibilityCategory(I765EligibilityCategory.C19)
                    .immvi(false)
                    .reasonForFiling(originalReason.toString())
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .myUscisId(myUscisId)
                    .build();

            final Submission newSubmission = SubmissionUtils.copySubmission(originalSubmission);
            newSubmission.setReasonForFiling(newReason.toString());

            when(submissionDao.getDraftById(originalSubmission.getMyUscisId(), originalSubmission.getOrgMyUscisId(),
                    originalSubmission.getSubmissionId()))
                    .thenReturn(Optional.of(originalSubmission));
            when(submissionDao.update(any(Submission.class))).thenReturn(newSubmission);

            service.updateReasonForFiling(originalSubmission.getSubmissionId(), originalSubmission.getMyUscisId(),
                    originalSubmission.getOrgMyUscisId(), newReason.toString());

            verify(submissionDao, times(1)).update(any(Submission.class));
            verify(reasonForFilingValidator, times(1)).validate(any(Submission.class), any(FormFields.class));
        }

        @Test
        void shouldNotRevalidateReasonForFilingSelectionWhenFileUploadDoesNotExist() {
            final ReasonForFiling originalReason = ReasonForFiling.INITIAL;
            final ReasonForFiling newReason = ReasonForFiling.REPLACEMENT;
            SubmissionForm submissionForm = SubmissionForm.builder()
                    .type(FormType.I765.getType())
                    .build();

            final Submission originalSubmission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .forms(List.of(submissionForm))
                    .immvi(false)
                    .status(SubmissionState.DRAFT)
                    .feeTotal(I765Fees.FEE_470)
                    .eligibilityCategory(I765EligibilityCategory.C19)
                    .reasonForFiling(originalReason.toString())
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .myUscisId(myUscisId)
                    .build();

            final Submission newSubmission = SubmissionUtils.copySubmission(originalSubmission);
            newSubmission.setReasonForFiling(newReason.toString());

            when(submissionDao.getDraftById(originalSubmission.getMyUscisId(), originalSubmission.getOrgMyUscisId(),
                    originalSubmission.getSubmissionId()))
                    .thenReturn(Optional.of(originalSubmission));
            when(submissionDao.update(any(Submission.class))).thenReturn(newSubmission);

            service.updateReasonForFiling(originalSubmission.getSubmissionId(), originalSubmission.getMyUscisId(),
                    originalSubmission.getOrgMyUscisId(), newReason.toString());

            verify(submissionDao, times(1)).update(any(Submission.class));
            verify(reasonForFilingValidator, never()).validate(any(Submission.class), any(FormFields.class));
        }

        @Test
        void shouldUpdateSubmissionWithHasReviewedSignatureOfTrue() {
            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .status(SubmissionState.DRAFT)
                    .myUscisId(myUscisId)
                    .build();
            final var updatedSubmission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .status(SubmissionState.DRAFT)
                    .myUscisId(myUscisId)
                    .build();

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenReturn(updatedSubmission);

            var resultingSubmission = service.updateSignatureReviewed(submission.getSubmissionId(),
                    submission.getMyUscisId(), submission.getOrgMyUscisId(), true);

            assertTrue(resultingSubmission.getHasReviewedSignature());
            assertTrue(resultingSubmission.getAttested());
            assertNotNull(resultingSubmission.getAttestedAt());
        }

        @Test
        void shouldCalculateFeeForAnyC11sUsingTheC11SpecificOptions() {
            String reasonForFiling = "Initial";
            final String submissionId = UUID.randomUUID().toString();
            ExtractedFormEntries extractedData = ExtractedFormEntries.builder()
                    .reasonForFiling(reasonForFiling).build();
            final var submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(FormType.I765)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .reasonForFiling(reasonForFiling)
                    .feeTotal(I765Fees.FEE_470)
                    .eligibilityCategory(I765EligibilityCategory.A12)
                    .forms(List.of(
                            SubmissionForm.builder().type(i765FormType.getType()).extractedData(extractedData).build()))
                    .immvi(true)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .myUscisId(myUscisId)
                    .orgMyUscisId(orgMyUscisId)
                    .userRequestedPartialFeeWaiver(false)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .build();

            final var updatedSubmission = Submission.builder()
                    .submissionId(submissionId)
                    .status(SubmissionState.DRAFT)
                    .formType(FormType.I765)
                    .userRequestedFeeWaiver(false)
                    .reasonForFiling(reasonForFiling)
                    .eligibilityCategory(I765EligibilityCategory.C11AFGHAN)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(I765EligibilityCategory.C11AFGHAN);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(FormType.I765.getType());

            EligibilityCategoryValidator validatorMock = mock(EligibilityCategoryValidator.class);
            // when(categoryValidatorFactory.getValidator(i765FormType)).thenReturn(validatorMock);

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenReturn(updatedSubmission);

            service.updateEligibility(submissionId, myUscisId, orgMyUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(feeService, times(1)).calculateFeeFor(i765FormType, I765EligibilityCategory.C11AFGHAN,
                    new I765C11FeeStrategyOptions(false, true, false, reasonForFiling, false));
            assertFalse(captor.getValue().getImmvi());
            assertEquals(ReasonForFiling.INITIAL.toString(), captor.getValue().getReasonForFiling());
        }

        @Test
        void shouldUpdateSubmissionWhenFormDoesNotExist() {
            var newEligibilityCategory = I765EligibilityCategory.C11PAROLE;

            final var original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(newEligibilityCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            assertEquals(newEligibilityCategory, captor.getValue().getEligibilityCategory());
        }

        @Test
        @DisplayName("After a form is deleted, submission should be updated with selected eligibility category")
        void shouldUpdateSubmissionWithSelectedEligibilityCategoryAfterFormIsRemoved() {
            var newEligibilityCategory = I765EligibilityCategory.C11PAROLE;

            final var submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .status(SubmissionState.DRAFT)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I765.getType())
                            .build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(newEligibilityCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                    submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.updateEligibility(submission.getSubmissionId(), submission.getMyUscisId(),
                    submission.getOrgMyUscisId(), request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            assertEquals(newEligibilityCategory, captor.getValue().getEligibilityCategory());
        }

        @Test
        void shouldUpdateSubmissionToOnlyRemoveFeeWaiverFromSubmission() {
            String feeWaiverId = UUID.randomUUID().toString();
            String evidenceId = UUID.randomUUID().toString();
            String s3Key = "s3/key";
            String supportS3Key = "s3/supportkey";

            SubmissionEvidence evidence = SubmissionEvidence.builder().evidenceGroupType("Other")
                    .id(evidenceId)
                    .s3Key(supportS3Key).build();
            final var original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .myUscisId(myUscisId)
                    .feeWaiver(SubmissionEvidence.builder().id(feeWaiverId).s3Key(s3Key).build())
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(Lists.newArrayList(evidence))
                    .forms(List.of())
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, i765FormType.getType())).thenReturn(false);
            service.deleteFeeWaiverFromSubmission(myUscisId, orgMyUscisId, original.getSubmissionId(), feeWaiverId);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(s3Service, times(1)).deleteS3Object(s3Key, true);
            verify(s3Service, times(0)).deleteS3Object(supportS3Key, true);
            Submission value = captor.getValue();
            org.assertj.core.api.Assertions.assertThat(value.getFeeWaiver()).isNull();
            org.assertj.core.api.Assertions.assertThat(value.getEvidences()).isNotEmpty();

        }

        @Test
        void shouldUpdateSubmissionToRemoveFeeWaiverSupportOnlyFromSubmission() {
            String feeWaiverId = UUID.randomUUID().toString();
            String feeWaiverEvidenceId = UUID.randomUUID().toString();
            String evidenceId = UUID.randomUUID().toString();
            String s3Key = "s3feewaiver/key";

            SubmissionEvidence feeWaiverEvidence = SubmissionEvidence.builder()
                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                    .id(feeWaiverEvidenceId).s3Key(s3Key).build();
            SubmissionEvidence evidence = SubmissionEvidence.builder().evidenceGroupType("Other")
                    .id(evidenceId)
                    .s3Key("s3Key").build();
            String feeWaiverS3Key = "s3Key feewaiver";
            final var original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .myUscisId(myUscisId)
                    .feeWaiver(SubmissionEvidence.builder().id(feeWaiverId).s3Key(feeWaiverS3Key)
                            .build())
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(Lists.newArrayList(feeWaiverEvidence, evidence))
                    .forms(List.of())
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            service.deleteFeeWaiverFromSubmission(myUscisId, orgMyUscisId, original.getSubmissionId(), feeWaiverId);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(s3Service, times(1)).deleteS3Object(feeWaiverS3Key, true);
            verify(s3Service, times(1)).deleteS3Object(s3Key, true);
            Submission value = captor.getValue();
            org.assertj.core.api.Assertions.assertThat(value.getFeeWaiver()).isNull();
            org.assertj.core.api.Assertions.assertThat(value.getEvidences()).isNotEmpty();
        }

        // TODO: finish this one
        @Test
        void shouldUpdateSubmissionWhenFormExistsButValidationDoesNotExist() {
            var eligibilityCategory = I765EligibilityCategory.C11PAROLE;
            final var form = SubmissionForm.builder().type(i765FormType.getType()).id(formId).extractedData(
                    ExtractedFormEntries.builder().eligibilityCategory(eligibilityCategory.getCategory()).build())
                    .build();
            final var original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .myUscisId(myUscisId)
                    .orgMyUscisId(orgMyUscisId)
                    .forms(new ArrayList<SubmissionForm>(List.of(form)))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(eligibilityCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            EligibilityCategoryValidator validatorMock = mock(EligibilityCategoryValidator.class);
            // when(categoryValidatorFactory.getValidator(i765FormType)).thenReturn(validatorMock);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            assertEquals(eligibilityCategory, captor.getValue().getEligibilityCategory());
            // assertNotNull(update.getForms());
        }

        @Test
        void shouldRemoveFeeWaiverWhenUserChangesEligibilityFromAFeeBasedToAFeeExempt() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;
            SubmissionEvidence feeWaiver = SubmissionEvidence.builder().s3Key("fee/waiver/Key").build();
            ExtractedFormEntries extractedData = ExtractedFormEntries.builder().eligibilityCategory("A 1 2")
                    .isSalvadorianABCEligible(false).reasonForFiling(ReasonForFiling.INITIAL.toString()).build();

            String supportEvidenceKey = "Key";
            final Submission original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .myUscisId(myUscisId)
                    .orgMyUscisId(orgMyUscisId)
                    .eligibilityCategory(I765EligibilityCategory.A12)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .forms(List.of(
                            SubmissionForm.builder().type(i765FormType.getType()).extractedData(extractedData)
                                    .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode).build()))
                    .userRequestedFeeWaiver(true)
                    .feeTotal(I765Fees.FEE_EXEMPT)
                    .status(SubmissionState.DRAFT)
                    .attested(true)
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .evidences(Lists.newArrayList(
                            SubmissionEvidence.builder().s3Key(supportEvidenceKey)
                                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                                    .build()))
                    .attestedAt(ZonedDateTime.now())
                    .attestationSignature("signature")
                    .feeWaiver(feeWaiver)
                    .userRequestedPartialFeeWaiver(false)
                    .build();

            final Submission updated = Submission.builder()
                    .submissionId(original.getSubmissionId())
                    .formType(i765FormType)
                    .myUscisId(myUscisId)
                    .orgMyUscisId(orgMyUscisId)
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.C11AFGHAN)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .evidences(List.of())
                    .forms(List.of(
                            SubmissionForm.builder().type(i765FormType.getType())
                                    .eligibilityCategory(I765EligibilityCategory.C11AFGHAN).extractedData(extractedData)
                                    .benefitTypeCode(benefitTypeCode)
                                    .applicationReasonCode(appReasonCode)
                                    .build()))
                    .feeTotal(I765Fees.FEE_EXEMPT)
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .attested(false)
                    .attestationSignature(null)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .userIsEligibleForFeeWaiver(false)
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(I765EligibilityCategory.C11AFGHAN);
            request.setBenefitTypeCode(benefitTypeCode);
            request.setApplicationReasonCode(appReasonCode);
            request.setFormType(i765FormType.getType());

            EligibilityCategoryValidator validatorMock = mock(EligibilityCategoryValidator.class);

            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenReturn(updated);
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(feeService.calculateFeeFor(i765FormType, I765EligibilityCategory.C11AFGHAN,
                    new I765C11FeeStrategyOptions(false, true, false,
                            ReasonForFiling.INITIAL.toString(), original.getUserRequestedFeeWaiver())))
                    .thenReturn(I765Fees.FEE_EXEMPT);

            service.updateEligibility(original.getSubmissionId(), myUscisId, orgMyUscisId, request);

            verify(s3Service, times(1)).deleteS3Object(feeWaiver.getS3Key(), true);
            verify(s3Service, times(1)).deleteS3Object(supportEvidenceKey, true);
            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            assertThat(captor.getValue(), samePropertyValuesAs(updated, "updatedAt", "formSpecificInfo",
                    "userRequestedPartialFeeWaiver", "userIsEligibleForFeeWaiver", "benefitTypeCode", "forms"));
        }

        @Test
        void shouldCalculateFeeForC8WithABCBenefitsToBeCorrect() {
            String reason = ReasonForFiling.INITIAL.toString();
            final var newCategory = I765EligibilityCategory.C8;
            final var original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .myUscisId(myUscisId)
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .feeTotal(I765Fees.FEE_EXEMPT)
                    .reasonForFiling(reason)
                    .forms(List.of(SubmissionForm.builder().type(i765FormType.getType())
                            .extractedData(ExtractedFormEntries.builder()
                                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                                    .eligibilityCategory("C8")
                                    .isSalvadorianABCEligible(false).build())
                            .build()))
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .userRequestedPartialFeeWaiver(false)
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(newCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            EligibilityCategoryValidator validatorMock = mock(EligibilityCategoryValidator.class);
            // when(categoryValidatorFactory.getValidator(i765FormType)).thenReturn(validatorMock);
            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(feeService.calculateFeeFor(i765FormType, newCategory,
                    new I765FeeStrategyOptions(false, false, false, reason, original.getUserRequestedFeeWaiver())))
                    .thenReturn(I765Fees.FEE_1030);

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(feeService, times(1)).calculateFeeFor(i765FormType, newCategory,
                    new I765FeeStrategyOptions(false, false, false, reason, false));
            assertEquals(I765Fees.FEE_1030, captor.getValue().getFeeTotal());
        }

        @Test
        void shouldCalculateFeeForC8WithoutABCBenefitsToBe550() {
            String reason = ReasonForFiling.INITIAL.toString();
            var updatedSelectionOfEligibilityCategory = I765EligibilityCategory.C8;
            final var original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .feeTotal(I765Fees.FEE_470)
                    .reasonForFiling(reason)
                    .forms(List.of(SubmissionForm.builder().type(i765FormType.getType())
                            .extractedData(ExtractedFormEntries.builder()
                                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                                    .eligibilityCategory("C8")
                                    .isSalvadorianABCEligible(false).build())
                            .build()))
                    .myUscisId(myUscisId)
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(updatedSelectionOfEligibilityCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            EligibilityCategoryValidator validatorMock = mock(EligibilityCategoryValidator.class);
            // when(categoryValidatorFactory.getValidator(i765FormType)).thenReturn(validatorMock);
            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(feeService.calculateFeeFor(i765FormType, I765EligibilityCategory.C8,
                    new I765FeeStrategyOptions(false, false, false, reason, false)))
                    .thenReturn(I765Fees.FEE_560);

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);
            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(feeService, times(1)).calculateFeeFor(i765FormType, I765EligibilityCategory.C8,
                    new I765FeeStrategyOptions(false, false, false, reason, false));
            assertEquals(I765Fees.FEE_560, captor.getValue().getFeeTotal());
        }

        @Test
        void shouldCalculateFeeForC9ToBe260() {
            final var eligibilityCategory = I765EligibilityCategory.C9;
            final var original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .feeTotal(I765Fees.FEE_470)
                    .status(SubmissionState.DRAFT)
                    .forms(List.of(SubmissionForm.builder().type(i765FormType.getType())
                            .extractedData(ExtractedFormEntries.builder()
                                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                                    .eligibilityCategory("C9").build())
                            .build()))
                    .myUscisId(myUscisId)
                    .orgMyUscisId(orgMyUscisId)
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(eligibilityCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            EligibilityCategoryValidator validatorMock = mock(EligibilityCategoryValidator.class);
            // when(categoryValidatorFactory.getValidator(i765FormType)).thenReturn(validatorMock);
            when(feeService.calculateFeeFor(i765FormType, eligibilityCategory,
                    new I765C9FeeStrategyOptions(new C9Options(true, false), original.getUserRequestedFeeWaiver())))
                    .thenReturn(I765Fees.FEE_260);

            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(feeService, times(1)).calculateFeeFor(i765FormType, eligibilityCategory,
                    new I765C9FeeStrategyOptions(new C9Options(true, false), original.getUserRequestedFeeWaiver()));
            // assertEquals(I765Fees.FEE_260, captor.getValue().getFeeTotal());
        }

        @Test
        void shouldCalculateFeeForC19ToBe1030() {
            final var eligibilityCategory = I765EligibilityCategory.C19;
            final var original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .feeTotal(BigDecimal.ZERO)
                    .forms(List.of(SubmissionForm.builder().type(i765FormType.getType())
                            .extractedData(ExtractedFormEntries.builder()
                                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                                    .eligibilityCategory("C19").build())
                            .build()))
                    .myUscisId(myUscisId)
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(eligibilityCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            when(feeService.calculateFeeFor(i765FormType, eligibilityCategory,
                    new I765FeeStrategyOptions(false, false, false, original.getReasonForFiling(),
                            original.getUserRequestedFeeWaiver())))
                    .thenReturn(I765Fees.FEE_1030);
            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(feeService, times(1)).calculateFeeFor(i765FormType, eligibilityCategory,
                    new I765FeeStrategyOptions(false, false, false, original.getReasonForFiling(),
                            original.getUserRequestedFeeWaiver()));
            assertEquals(I765Fees.FEE_1030, captor.getValue().getFeeTotal());
        }

        @Test
        void updateUserRequestedFeeWaiver_false_shouldUpdateSubmissionWithFeeUpdateWithOptions() {
            SubmissionEvidence feeWaiver = SubmissionEvidence.builder().s3Key("fee/waiver/Key").build();
            ExtractedFormEntries extractedData = ExtractedFormEntries.builder().eligibilityCategory("A 1 2")
                    .isSalvadorianABCEligible(false).build();

            final Submission original = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765FormType)
                    .myUscisId(myUscisId)
                    .eligibilityCategory(I765EligibilityCategory.A12)
                    .attested(true)
                    .status(SubmissionState.DRAFT)
                    .attestedAt(ZonedDateTime.now())
                    .attestationSignature("signature")
                    .forms(List.of(SubmissionForm.builder().extractedData(extractedData).build()))
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .feeTotal(I765Fees.FEE_EXEMPT)
                    .feeWaiver(feeWaiver)
                    .build();

            I765FeeStrategyOptions expectedOptions = I765FeeStrategyOptions.builder()
                    .isSalvadorianABCEligible(false)
                    .hasPendingI589(false)
                    .i485PaidInFull(false)
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(feeService.calculateFeeFor(i765FormType, I765EligibilityCategory.A12,
                    expectedOptions)).thenReturn(I765Fees.FEE_470);

            Submission result = service.updateUserRequestedFeeWaiver(myUscisId, orgMyUscisId, submissionId, false);
            assertFalse(result.getUserRequestedFeeWaiver());
            assertEquals(I765Fees.FEE_470, result.getFeeTotal());
            assertFalse(result.getAttested());
            assertNull(result.getAttestedAt());
            assertNull(result.getAttestationSignature());

            verify(s3Service).deleteS3Object(feeWaiver.getS3Key(), true);
            verify(feeService).calculateFeeFor(i765FormType, A12, expectedOptions);
            verify(submissionDao).update(result);
        }

        @Test
        void deleteFeeWaiverFromSubmission_shouldSucceed() {

            String documentId = UUID.randomUUID().toString();
            String submissionId = UUID.randomUUID().toString();
            String feeWaiverId = UUID.randomUUID().toString();
            String s3Key = UUID.randomUUID().toString();

            SubmissionEvidence feeWaiver = SubmissionEvidence.builder().id(feeWaiverId).s3Key(s3Key)
                    .build();
            SubmissionForm submissionForm = SubmissionForm.builder().id(documentId).build();
            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(i765FormType)
                    .eligibilityCategory(I765EligibilityCategory.A12)
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeTotal(BigDecimal.valueOf(0))
                    .forms(List.of(submissionForm))
                    .feeWaiver(feeWaiver)
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            service.deleteFeeWaiverFromSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId(),
                    feeWaiver.getId());

            verify(submissionDao, times(1)).update(any(Submission.class));
            verify(s3Service, times(1)).deleteS3Object(s3Key, true);

            assertNull(submission.getFeeWaiver());
            assertEquals(true, submission.getUserRequestedFeeWaiver());
        }

        @Test
        void deleteFeeWaiverFromSubmission_shouldSucceedAndResendToPFVS() {

            String documentId = UUID.randomUUID().toString();
            String submissionId = UUID.randomUUID().toString();
            String feeWaiverId = UUID.randomUUID().toString();
            String s3Key = UUID.randomUUID().toString();

            SubmissionEvidence feeWaiver = SubmissionEvidence.builder().id(feeWaiverId).s3Key(s3Key).build();

            SubmissionForm submissionForm = SubmissionForm
                    .builder()
                    .id(documentId)
                    .type(FormType.I131.getType())
                    .s3Key(s3Key + "-form")
                    .build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(FormType.I131)
                    .immvi(false)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeTotal(BigDecimal.valueOf(0))
                    .forms(List.of(submissionForm))
                    .feeWaiver(feeWaiver)
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);

            service.deleteFeeWaiverFromSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId(),
                    feeWaiver.getId());

            verify(submissionDao, times(1)).update(any(Submission.class));
            verify(s3Service, times(1)).deleteS3Object(s3Key, true);
            verify(validationService).deleteStatus(documentId);

            ArgumentCaptor<ValidationRequest> validationRequestJail = ArgumentCaptor.forClass(ValidationRequest.class);
            verify(sqsService).sendValidationRequest(validationRequestJail.capture());

            assertFalse(validationRequestJail.getValue().evidenceIds().contains(feeWaiverId));
            assertNull(submission.getFeeWaiver());
            assertEquals(true, submission.getUserRequestedFeeWaiver());
        }

        @Test
        void deleteFeeWaiverFromSubmission_shouldSucceedAndNotResendToPFVS() {

            String documentId = UUID.randomUUID().toString();
            String submissionId = UUID.randomUUID().toString();
            String feeWaiverId = UUID.randomUUID().toString();
            String s3Key = UUID.randomUUID().toString();

            SubmissionEvidence feeWaiver = SubmissionEvidence.builder().id(feeWaiverId).s3Key(s3Key).build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(FormType.I131)
                    .immvi(false)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeTotal(BigDecimal.valueOf(0))
                    .forms(List.of())
                    .feeWaiver(feeWaiver)
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);

            service.deleteFeeWaiverFromSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId(),
                    feeWaiver.getId());

            verify(submissionDao, times(1)).update(any(Submission.class));
            verify(s3Service, times(1)).deleteS3Object(s3Key, true);
            verify(validationService, times(0)).deleteStatus(documentId);
            verify(sqsService, times(0)).sendValidationRequest(any(ValidationRequest.class));

            assertNull(submission.getFeeWaiver());
            assertEquals(true, submission.getUserRequestedFeeWaiver());
        }

        @Test
        void shouldThrowFeeWaiverDeleteException() {
            String submissionId = UUID.randomUUID().toString();
            String feeWaiverId = UUID.randomUUID().toString();

            assertThrows(NoSuchElementException.class,
                    () -> service.deleteFeeWaiverFromSubmission(myUscisId, orgMyUscisId, submissionId,
                            feeWaiverId));
        }

        @Test
        void updateFeeWaiverEvidence_shouldSucceed() {
            Submission submission = SubmissionFactory.forSubmissionId(
                    UUID.randomUUID().toString(), UUID.randomUUID().toString(), FormType.I765);
            submission.getFeeWaiver().setType(null);

            when(submissionDao.update(submission)).thenReturn(submission);
            service.updateFeeWaiverEvidence(submission, FEE_DECLARATION, false);

            assertEquals(FEE_DECLARATION, submission.getFeeWaiver().getType());
            verify(submissionDao, times(1)).update(submission);
        }

        @Test
        void updateFeeWaiverEvidence_shouldReturnSubmissionIfFeeWavierIsNotEditable() {
            Submission submission = SubmissionFactory.forSubmissionId(
                    UUID.randomUUID().toString(), UUID.randomUUID().toString(), FormType.I765);
            submission.getFeeWaiver().setIsEditable(false);

            Submission actual = service.updateFeeWaiverEvidence(submission, FEE_DECLARATION, false);

            assertEquals(submission, actual);
        }

        @Test
        void updateFeeWaiverEvidence_shouldThrowNoSuchElementException() {
            Submission submission = Submission.builder().feeWaiver(null).build();

            assertThrows(NoSuchElementException.class, () -> {
                service.updateFeeWaiverEvidence(submission, FormType.I765.getType(), false);
            });

        }

        @Test
        void updateEvidence_shouldSucceedWhenNoEvidences() {
            // given
            String type = "Passport";
            String evidenceId = UUID.randomUUID().toString();
            Submission submission = Submission.builder().evidences(null).build();
            // when
            when(submissionDao.update(submission)).thenReturn(submission);
            Submission actual = service.updateEvidence(submission, evidenceId, type);
            // then
            assertEquals(submission, actual);
        }

        @Test
        void updateEvidence_shouldSucceedWhenNoMatchExists() {
            // given
            String type = "Passport";
            String evidenceId = UUID.randomUUID().toString();
            SubmissionEvidence evidence = SubmissionEvidence.builder().id(evidenceId)
                    .type("Application Photo").build();
            Submission submission = Submission.builder().evidences(List.of(evidence)).build();
            // when
            when(submissionDao.update(submission)).thenReturn(submission);
            Submission actual = service.updateEvidence(submission, evidenceId, type);
            // then
            assertEquals(submission, actual);
        }

        @Test
        void updateEvidence_shouldSucceedWhenEvidencesMatch() {
            // given
            String type = "Passport";
            String evidenceId = UUID.randomUUID().toString();
            SubmissionEvidence evidence = SubmissionEvidence.builder().id(evidenceId).build();
            Submission submission = Submission.builder().evidences(List.of(evidence)).build();
            // when
            when(submissionDao.update(submission)).thenReturn(submission);
            Submission actual = service.updateEvidence(submission, evidenceId, type);
            // then
            assertEquals(type, actual.getEvidences().get(0).getType());
        }

        @Test
        void shouldUpdateSubmissionFormWithFormFields_nonDraftSubmission() {
            String submissionId = UUID.randomUUID().toString();

            Submission submission = Instancio.create(Submission.class);
            submission.setFeeWaiver(null);
            submission.setUserRequestedFeeWaiver(false);
            submission.setFeeTotal(BigDecimal.ZERO);
            submission.setStatus(SubmissionState.ACCEPTED);
            submission.setEligibilityCategory(I765EligibilityCategory.C8);
            submission.setSubmissionId(submissionId);
            submission.setFormType(FormType.I765);
            submission.setForms(asList(
                    SubmissionForm.builder().id(formId)
                            .eligibilityCategory(submission.getEligibilityCategory())
                            .build()));

            String category = I765EligibilityCategory.C9.getCategory();
            String reasonForApplySelection = "1.a.";
            FormFields formFields = FormFields.builder().submissionId(submission.getSubmissionId())
                    .formId(formId)
                    .eligibilityCategory(category).abcBenefitsApplied(true)
                    .reasonForApplySelection(reasonForApplySelection)
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));

            assertThrows(InvalidStateException.class,
                    () -> service.updateSubmissionWithFormFields(formFields, submission.getFormType()));
        }

        @Test
        void shouldUpdateSubmissionFormWithFormFieldsAndUpdateFeeAndFeeWaiverStateBasedOnRecalculatedFee() {

            String submissionId = UUID.randomUUID().toString();

            Submission submission = Instancio.create(Submission.class);
            String reasonForApplySelection = "1.a.";
            String reasonForFiling = ReasonForFiling.INITIAL.toString();
            SubmissionEvidence feeWaiver = SubmissionEvidence.builder().id(UUID.randomUUID().toString())
                    .s3Key("s3Key")
                    .build();
            submission.setFeeWaiver(feeWaiver);
            submission.setUserRequestedFeeWaiver(true);
            submission.setFeeTotal(BigDecimal.ZERO);
            submission.setImmvi(false);
            submission.setReasonForFiling(reasonForFiling);
            submission.setEligibilityCategory(I765EligibilityCategory.C11UKRAINE);
            submission.setSubmissionId(submissionId);
            submission.setStatus(DRAFT);
            submission.setFormType(FormType.I765);
            submission.setForms(asList(
                    SubmissionForm.builder().id(formId)
                            .eligibilityCategory(submission.getEligibilityCategory())
                            .build()));
            var fee = BigDecimal.ZERO;

            String category = I765EligibilityCategory.C11UKRAINE.getCategory();
            FormFields formFields = FormFields.builder().submissionId(submission.getSubmissionId())
                    .formId(formId)
                    .eligibilityCategory(category).abcBenefitsApplied(true)
                    .reasonForApplySelection(reasonForApplySelection)
                    .build();

            var options = new I765C11FeeStrategyOptions(false, false, true, reasonForFiling,
                    submission.getUserRequestedFeeWaiver());
            when(submissionDao.getById(anyString())).thenReturn(Optional.of(submission));
            when(feeService.calculateFeeFor(i765FormType,
                    (I765EligibilityCategory) submission.getEligibilityCategory(),
                    options)).thenReturn(fee);
            service.updateSubmissionWithFormFields(formFields, submission.getFormType());

            ArgumentCaptor<Submission> captor = ArgumentCaptor.forClass(Submission.class);
            verify(submissionDao, times(1)).update(captor.capture());
            verify(feeService, times(1)).calculateFeeFor(any(FormType.class),
                    any(I765EligibilityCategory.class),
                    any(FeeStrategyOptions.class));

            Submission entityToSave = captor.getValue();
            assertFalse(entityToSave.getUserRequestedFeeWaiver());
            assertNull(entityToSave.getFeeWaiver());
            assertEquals(fee, entityToSave.getFeeTotal());
        }

        @Test
        void shouldRemoveIrrelevantEvidenceForNewEligibilityCategory() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            String submissionid = UUID.randomUUID().toString();
            String evidenceGroupType = "evidenceGroup";
            I765EligibilityCategory updatedCategory = I765EligibilityCategory.C11PAROLE;

            SubmissionEvidence relevantEvidence = SubmissionEvidence.builder()
                    .id(UUID.randomUUID().toString())
                    .s3Key("evidence/Key").evidenceGroupType(evidenceGroupType).type("evidenceType")
                    .build();
            SubmissionEvidence irrelevantEvidence = SubmissionEvidence.builder()
                    .id(UUID.randomUUID().toString())
                    .s3Key("irrelevant/evidence/Key").evidenceGroupType("irrelevant")
                    .type("evidenceType").build();
            SubmissionEvidence feeWaiveSupport = SubmissionEvidence.builder()
                    .id(UUID.randomUUID().toString())
                    .s3Key("feeWaiver/Key").evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                    .type("evidenceType").build();

            EvidenceGroup evidenceGroup = EvidenceGroup.builder().id(evidenceGroupType).build();
            ExtractedFormEntries extractedData = ExtractedFormEntries.builder().eligibilityCategory("A 1 2")
                    .isSalvadorianABCEligible(false).reasonForFiling(ReasonForFiling.INITIAL.toString()).build();

            final Submission original = Submission.builder()
                    .submissionId(submissionid)
                    .formType(i765FormType)
                    .myUscisId(myUscisId)
                    .eligibilityCategory(I765EligibilityCategory.A12)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .status(SubmissionState.DRAFT)
                    .forms(List.of(
                            SubmissionForm.builder().type(i765FormType.getType()).extractedData(extractedData)
                                    .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode).build()))
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(Lists.newArrayList(relevantEvidence, irrelevantEvidence,
                            feeWaiveSupport))
                    .feeTotal(I765Fees.FEE_EXEMPT)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .attested(false)
                    .build();

            final Submission updated = Submission.builder()
                    .submissionId(submissionid)
                    .formType(i765FormType)
                    .myUscisId(myUscisId)
                    .eligibilityCategory(updatedCategory)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .forms(List.of(
                            SubmissionForm.builder().type(i765FormType.getType()).eligibilityCategory(updatedCategory)
                                    .benefitTypeCode(benefitTypeCode)
                                    .applicationReasonCode(appReasonCode)
                                    .extractedData(extractedData).build()))
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .userIsEligibleForFeeWaiver(false)
                    .evidences(Lists.newArrayList(relevantEvidence, feeWaiveSupport))
                    .feeTotal(I765Fees.FEE_EXEMPT)
                    .status(SubmissionState.DRAFT)
                    .attested(false)
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(updatedCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            EligibilityCategoryValidator validatorMock = mock(EligibilityCategoryValidator.class);

            when(feeService.calculateFeeFor(i765FormType, updatedCategory,
                    new I765C11FeeStrategyOptions(false, false, false, ReasonForFiling.INITIAL.toString(), false)))
                    .thenReturn(I765Fees.FEE_EXEMPT);
            when(formService.retrieveEvidenceGroups(original.getFormType().getType(),
                    updatedCategory.getCategory()))
                    .thenReturn(List.of(evidenceGroup));

            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(s3Service.checkIfFileExists(anyString(), eq(false))).thenReturn(true);

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);
            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(formService, times(1)).retrieveEvidenceGroups(anyString(), anyString());
            verify(submissionDao, times(1)).update(captor.capture());
            assertThat(captor.getValue(), samePropertyValuesAs(updated, "updatedAt", "feeTotal", "formSpecificInfo",
                    "benefitTypeCode", "forms"));

            verify(s3Service, times(1)).deleteS3Object(irrelevantEvidence.getS3Key(), true);
        }

        @Test
        void shouldNotAttemptToRemoveEvidenceWhenNoneExists() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;
            String submissionid = UUID.randomUUID().toString();
            I765EligibilityCategory updatedCategory = I765EligibilityCategory.C11PAROLE;

            ExtractedFormEntries extractedData = ExtractedFormEntries.builder().eligibilityCategory("A 1 2")
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .isSalvadorianABCEligible(false).build();

            final Submission original = Submission.builder()
                    .submissionId(submissionid)
                    .formType(i765FormType)
                    .myUscisId(myUscisId)
                    .status(SubmissionState.DRAFT)
                    .eligibilityCategory(I765EligibilityCategory.A12)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .forms(List.of(
                            SubmissionForm.builder()
                                    .type(i765FormType.getType())
                                    .extractedData(extractedData)
                                    .eligibilityCategory(updatedCategory)
                                    .benefitTypeCode(63)
                                    .applicationReasonCode(39)
                                    .build()))
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(null)
                    .feeTotal(I765Fees.FEE_EXEMPT)
                    .attested(false)
                    .build();
            final Submission updated = Submission.builder()
                    .submissionId(submissionid)
                    .formType(i765FormType)
                    .status(SubmissionState.DRAFT)
                    .myUscisId(myUscisId)
                    .eligibilityCategory(updatedCategory)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .forms(List.of(
                            SubmissionForm.builder()
                                    .type(i765FormType.getType())
                                    .extractedData(extractedData)
                                    .eligibilityCategory(updatedCategory)
                                    .benefitTypeCode(63)
                                    .applicationReasonCode(39)
                                    .build()))
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .userIsEligibleForFeeWaiver(false)
                    .evidences(null)
                    .feeTotal(I765Fees.FEE_EXEMPT)
                    .attested(false)
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(updatedCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(i765FormType.getType());

            EligibilityCategoryValidator validatorMock = mock(EligibilityCategoryValidator.class);
            when(feeService.calculateFeeFor(i765FormType, updatedCategory,
                    new I765C11FeeStrategyOptions(false, false, false, ReasonForFiling.INITIAL.toString(), false)))
                    .thenReturn(I765Fees.FEE_EXEMPT);
            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verifyNoInteractions(s3Service);
            verify(submissionDao, times(1)).update(captor.capture());
            assertThat(captor.getValue(), samePropertyValuesAs(updated, "updatedAt", "benefitTypeCode", "totalFee",
                    "benefitTypeCode", "formSpecificInfo", "reasonForFiling", "feeTotal", "forms"));

        }

        @Test
        void shouldPassFilterParametersToSubmissionDao() {
            List<SubmissionState> states = asList(SubmissionState.ACCEPTED);
            service.findAllByMyUscisIdAndStatus("myUscis", states);
            verify(submissionDao).findAllByMyUscisIdAndStatus("myUscis", states);
        }

        @Test
        void shouldPassFilterParametersToSubmissionDaoFindByApplicant() {
            List<SubmissionState> states = asList(SubmissionState.ACCEPTED);
            service.findAllByApplicantUscisIdAndStatus("myUscis", states);
            verify(submissionDao).findAllByMyUscisIdAndStatuswithApplicant("myUscis", states);
        }

        @Test
        void shouldThrowSubmissionIndexExceptionWhenDaoThrowsException() {
            List<SubmissionState> states = asList(SubmissionState.ACCEPTED);

            when(submissionDao.findAllByMyUscisIdAndStatuswithApplicant("myUscis", states))
                    .thenThrow(new RuntimeException("Simulated DAO failure"));

            SubmissionIndexException thrown = assertThrows(
                    SubmissionIndexException.class,
                    () -> service.findAllByApplicantUscisIdAndStatus("myUscis", states));

            assertEquals("Simulated DAO failure", thrown.getMessage());

            verify(submissionDao).findAllByMyUscisIdAndStatuswithApplicant("myUscis", states);
        }

        @Test
        void shouldThrowSubmissionIndexExceptionWhenSubmissionDaoErrors() {
            List<SubmissionState> submissionStateList = List.of(SubmissionState.ACCEPTED);
            RuntimeException mockException = new RuntimeException("Database connection error");

            doThrow(mockException).when(submissionDao).findAllByMyUscisIdAndStatus(myUscisId,
                    submissionStateList);

            SubmissionIndexException thrownException = assertThrows(SubmissionIndexException.class,
                    () -> service.findAllByMyUscisIdAndStatus(myUscisId, submissionStateList));

            assertInstanceOf(SubmissionIndexException.class, thrownException);
        }

        @Test
        void updateDraftSubmissionLock_shouldSucceed() {
            Submission submission = SubmissionFactory.forSubmissionId(
                    UUID.randomUUID().toString(), UUID.randomUUID().toString(), FormType.I765);

            service.updateDraftSubmissionLock(submission);
            verify(submissionDao, times(1)).updateSubmissionLock(submission);
        }

        @Test
        void shouldNotSubmitIfPaymentIsNotAuthorized() throws PaymentRequiredException {
            Submission baseSubmission = mock(Submission.class);
            when(baseSubmission.getFeeTotal()).thenReturn(BigDecimal.TEN);
            when(baseSubmission.getFormType()).thenReturn(FormType.I765);
            var submission = Optional.of(baseSubmission);
            String submissionId = "fakeId";
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(submission);

            // WebClient lockBoxWebClient = spy(WebClient.class);
            DraftBenefitsService draftBenefitsService = mock(DraftBenefitsService.class);
            UserGroupServiceClient userGroupServiceClient = mock(UserGroupServiceClient.class);
            var submissionService = new SubmissionService(submissionDao, s3Service, feeService,
                    auditService,
                    uuid, formService, validationService, lockboxGatewayClient,
                    systemClockService, paymentServiceClient, sqsService, draftBenefitsService,
                    categoryValidatorFactory, reasonForFilingValidator, clientInformationRepository,
                    mock(MyUscisCacheManagementClient.class),
                    userGroupServiceClient, peepsService, accountsDataClient, toggleService);
            assertThrows(HttpServerErrorException.class,
                    () -> submissionService.completeSubmission(myUscisId, orgMyUscisId, submissionId));
            verify(paymentServiceClient).isAuthorized(submissionId, BigDecimal.TEN, i765FormType.getType());
            verify(lockboxGatewayClient, never()).sendTransmission(any());

        }

        @Test
        @Disabled("Disabling while we investigate the monomap transformation issue.")
        void test() throws PaymentRequiredException {
            String submissionId = "fakeId";

            Submission submission = Submission.builder()
                    .formType(i765FormType)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .submissionId(submissionId).userRequestedFeeWaiver(false)
                    .status(SubmissionState.DRAFT)
                    .forms(List.of(SubmissionForm.builder().build()))
                    .evidences(List.of(SubmissionEvidence.builder().type("Passport").build()))
                    .attested(true)
                    .attestationSignature("some signature")
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(submission));
            AuditService auditService = mock(AuditService.class);

            final RequestBodyUriSpec requestBodyUriSpec = mock(RequestBodyUriSpec.class);
            final RequestHeadersSpec<?> requestHeadersSpec = mock(RequestHeadersSpec.class);
            final RequestBodySpec requestBodySpec = mock(RequestBodySpec.class);
            final ResponseSpec responseSpecMock = mock(ResponseSpec.class);

            LockboxTransmission lockboxTransmission = Instancio.create(LockboxTransmission.class);
            Mono<LockboxTransmission> lockboxTransmissionMono = Mono.just(lockboxTransmission);
            when(lockboxWebClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri("/api/v1/manifest")).thenReturn(requestBodySpec);
            doReturn(requestHeadersSpec).when(requestBodySpec).body(eq(lockboxTransmissionMono),
                    eq(LockboxTransmission.class));
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpecMock);
            when(responseSpecMock.onStatus(any(), any())).thenReturn(responseSpecMock);
            when(responseSpecMock.bodyToMono(ResponseEntity.class))
                    .thenReturn(Mono.just(ResponseEntity.ok().build()));

            when(paymentServiceClient.isAuthorized(any(), any(), any())).thenReturn(true);
            service.completeSubmission(myUscisId, orgMyUscisId, submissionId);
            verify(auditService, times(1)).addEvent(myUscisId, submissionId, ActionPerformed.MANIFEST_SENT,
                    SubmissionState.PUBLISHED, null);
            verify(paymentServiceClient).isAuthorized("fakeId", BigDecimal.TEN, i765FormType.getType());
        }

        @Test
        void attestForm_shouldResetAttestationFields() {
            Submission submission = Instancio.create(Submission.class);
            String submissionId = submission.getSubmissionId();
            String submissionFormId = submission.getForms().get(0).getId();
            submission.setUserRequestedFeeWaiver(true);
            submission.setFormType(FormType.I765);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenReturn(submission);
            when(s3Service.checkIfFileExists(anyString(), eq(false))).thenReturn(true);
            when(s3Service.checkIfFileExists(anyString(), eq(false))).thenReturn(true);

            service.attestForm(myUscisId, orgMyUscisId, submissionId, submissionFormId, false, "signature");

            verify(submissionDao, times(1)).update(submission);
        }

        @Test
        void shouldGetAttestationStatus() {
            WatermarkerStatus.StatusEnum expected = WatermarkerStatus.StatusEnum.FAILURE;
            Submission submission = Instancio.create(Submission.class);
            String submissionId = submission.getSubmissionId();
            String submissionFormId = submission.getForms().get(0).getId();
            submission.getForms().get(0).setAttestationStatus(expected);

            when(submissionDao.getById(submissionId)).thenReturn(Optional.of(submission));

            WatermarkerStatus.StatusEnum status = service.getAttestationStatus(submissionId,
                    submissionFormId);

            assertEquals(expected, status);
        }

        @Test
        void shouldGetFinalTransmissionStatus() {
            FinalTransmissionStatus expected = FinalTransmissionStatus.builder().message("")
                    .status(FinalTransmissionStatus.StatusEnum.SUCCESS).build();
            Submission submission = Instancio.create(Submission.class);
            String submissionId = submission.getSubmissionId();
            submission.setTransmissionStatus(expected);

            when(submissionDao.getById(submissionId)).thenReturn(Optional.of(submission));

            FinalTransmissionStatus status = service.getFinalTransmissionStatus(myUscisId, submissionId);

            assertEquals(expected, status);
        }

        @Test
        void shouldReturnInProgressWhenFinalTransmissionStatusIsNull() {
            FinalTransmissionStatus expected = FinalTransmissionStatus.builder().message(null)
                    .status(FinalTransmissionStatus.StatusEnum.IN_PROGRESS).build();
            Submission submission = Instancio.create(Submission.class);
            String submissionId = submission.getSubmissionId();
            submission.setTransmissionStatus(null);

            when(submissionDao.getById(submissionId)).thenReturn(Optional.of(submission));

            FinalTransmissionStatus status = service.getFinalTransmissionStatus(myUscisId, submissionId);

            assertEquals(expected, status);
        }

        @Test
        void testUpdateTransmissionStatus_updatesSubmissionWithCorrectStatus() {
            String submissionId = "12345";
            FinalTransmissionStatus.StatusEnum status = FinalTransmissionStatus.StatusEnum.SUCCESS;
            String message = "Transmission successful";

            Submission submission = Submission.builder().submissionId(submissionId).build();
            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));

            service.updateTransmissionStatus(submissionId, status, message);

            ArgumentCaptor<Submission> submissionCaptor = ArgumentCaptor.forClass(Submission.class);
            verify(submissionDao).update(submissionCaptor.capture());

            Submission updatedSubmission = submissionCaptor.getValue();
            FinalTransmissionStatus updatedStatus = updatedSubmission.getTransmissionStatus();

            assertNotNull(updatedStatus);
            assertEquals(status, updatedStatus.getStatus());
            assertEquals(message, updatedStatus.getMessage());
        }

        @Test
        void testUpdateFee_updatesFeeWhenSubmissionIsDraft() {
            String submissionId = "12345";
            BigDecimal feeTotal = BigDecimal.valueOf(100.00);

            Submission submission = Submission.builder().submissionId(submissionId)
                    .status(SubmissionState.DRAFT).build();
            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));

            service.updateFee(submissionId, feeTotal);

            verify(submissionDao).update(submission);
        }

        @Test
        void testUpdateFee_doesNotUpdateFeeWhenSubmissionIsNotDraft() {
            String submissionId = "12345";
            BigDecimal feeTotal = BigDecimal.valueOf(100.00);

            Submission submission = Submission.builder().submissionId(submissionId)
                    .status(SubmissionState.ACCEPTED)
                    .build();
            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));

            service.updateFee(submissionId, feeTotal);

            verify(submissionDao, never()).update(any());
        }

        @Test
        void testUpdateSubmissionWithLockBoxStatus_G28And765Accepted() {
            Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                    .applicant(Instancio.create(UserInformation.class))
                    .forms(List.of(SubmissionForm.builder().build(), SubmissionForm.builder().build()))
                    .build();
            ApplicationStatus formStatus = ApplicationStatus.builder()
                    .formType(FormType.I765.getType())
                    .status(StatusEnum.ACCEPTED)
                    .build();
            ApplicationStatus g28Status = ApplicationStatus.builder()
                    .formType(FormType.G28.getType())
                    .status(StatusEnum.ACCEPTED)
                    .build();

            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.SUBMISSION)
                    .submissionUpdate(SubmissionUpdate.builder()
                            .status(StatusEnum.ACCEPTED)
                            .applicationStatuses(List.of(formStatus, g28Status))
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertThat(submission.getLockboxStatus()).isEqualTo(LockboxStatuses.ACCEPTED);
            assertThat(submission.getStatus()).isEqualTo(SubmissionState.ACCEPTED);
            assertThat(submission.getForms().size()).isEqualTo(2);
        }

        @Test
        void testUpdateSubmissionWithLockBoxStatus765Accepted() {
            Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                    .applicant(Instancio.create(UserInformation.class))
                    .forms(List.of(SubmissionForm.builder().build(), SubmissionForm.builder().build()))
                    .build();
            ApplicationStatus formStatus = ApplicationStatus.builder()
                    .formType(FormType.I765.getType())
                    .status(StatusEnum.ACCEPTED)
                    .build();

            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.SUBMISSION)
                    .submissionUpdate(SubmissionUpdate.builder()
                            .status(StatusEnum.ACCEPTED)
                            .applicationStatuses(List.of(formStatus))
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertThat(submission.getLockboxStatus()).isEqualTo(LockboxStatuses.ACCEPTED);
            assertThat(submission.getStatus()).isEqualTo(SubmissionState.ACCEPTED);
            assertThat(submission.getForms().size()).isEqualTo(2);
        }

        @Test
        void shouldNotPerformG28StatusChecksOnManifestUpdate() {
            Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                    .status(SubmissionState.RECEIVED).applicant(Instancio.create(UserInformation.class)).build();
            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.MANIFEST)
                    .manifestUpdate(ManifestUpdate.builder()
                            .status(StatusEnum.COMPLETE)
                            .errors(List.of())
                            .lockboxId("manifestId")
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertEquals(LockboxStatuses.PROCESSING, submission.getLockboxStatus());
            assertEquals(SubmissionState.RECEIVED, submission.getStatus());

            verify(submissionDao, times(0)).save(any(Submission.class));
        }

        @Test
        void testUpdateSubmissionWithLockBoxStatus_G28AcceptedAnd765Rejected() {
            FormType i765 = FormType.I765;

            Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString()).formType(i765)
                    .applicant(Instancio.create(UserInformation.class)).build();

            ApplicationStatus formStatus = ApplicationStatus.builder()
                    .formType(i765.getType())
                    .status(StatusEnum.REJECTED)
                    .build();
            ApplicationStatus g28Status = ApplicationStatus.builder()
                    .formType(FormType.G28.getType())
                    .status(StatusEnum.ACCEPTED)
                    .build();

            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.SUBMISSION)
                    .submissionUpdate(SubmissionUpdate.builder()
                            .status(StatusEnum.MIXED)
                            .applicationStatuses(List.of(formStatus, g28Status))
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertEquals(LockboxStatuses.REJECTED, submission.getLockboxStatus());
            assertEquals(SubmissionState.REJECTED, submission.getStatus());
        }

        @Test
        void testUpdateSubmissionWithLockBoxStatus_G28RejectedAnd765Rejected() {
            FormType i765 = FormType.I765;

            Submission submission = Submission.builder()
                    .submissionId(UUID.randomUUID().toString())
                    .formType(i765)
                    .applicant(Instancio.create(UserInformation.class))
                    .forms(List.of(SubmissionForm.builder().type(FormType.I765.getType()).build(),
                            SubmissionForm.builder().type(FormType.G28.getType()).build()))
                    .build();

            ApplicationStatus formStatus = ApplicationStatus.builder()
                    .formType(i765.getType())
                    .status(StatusEnum.REJECTED)
                    .build();
            ApplicationStatus g28Status = ApplicationStatus.builder()
                    .formType(FormType.G28.getType())
                    .status(StatusEnum.REJECTED)
                    .build();

            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.SUBMISSION)
                    .submissionUpdate(SubmissionUpdate.builder()
                            .status(StatusEnum.MIXED)
                            .applicationStatuses(List.of(formStatus, g28Status))
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertEquals(LockboxStatuses.REJECTED, submission.getLockboxStatus());
            assertEquals(SubmissionState.REJECTED, submission.getStatus());
            assertThat(submission.getForms().size()).isEqualTo(2);
        }

        @Test
        void testUpdateSubmissionWithLockBoxStatus_G28RejectedAnd765Accepted() {
            FormType g28FormType = FormType.G28;
            SubmissionForm i765Form = SubmissionForm.builder().type(i765FormType.getType()).id("765Form").build();
            SubmissionForm g28Form = SubmissionForm.builder().type(g28FormType.getType()).id("g28Form").build();

            Submission submission = Submission.builder()
                    .applicant(UserInformation.builder().accountType(AccountType.REPRESENTATIVE).build())
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I765)
                    .forms(Lists.newArrayList(i765Form, g28Form))
                    .evidences(Lists.newArrayList(SubmissionEvidence.builder().build()))
                    .build();

            ApplicationStatus formStatus = ApplicationStatus.builder()
                    .formType(i765FormType.getType())
                    .status(StatusEnum.ACCEPTED)
                    .build();
            ApplicationStatus g28Status = ApplicationStatus.builder()
                    .formType(g28FormType.getType())
                    .status(StatusEnum.REJECTED)
                    .build();

            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.SUBMISSION)
                    .submissionUpdate(SubmissionUpdate.builder()
                            .status(StatusEnum.MIXED)
                            .applicationStatuses(List.of(formStatus, g28Status))
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(submissionDao.save(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request);

            assertEquals(LockboxStatuses.ACCEPTED, submission.getLockboxStatus());
            assertEquals(SubmissionState.ACCEPTED, submission.getStatus());
            assertThat(submission.getForms().size()).isEqualTo(1);
            assertThat(submission.getForms().getFirst().getType()).isEqualTo(i765FormType.getType());

            ArgumentCaptor<Submission> captor = ArgumentCaptor.forClass(Submission.class);
            verify(submissionDao, times(1)).save(captor.capture());

            var g28Submission = captor.getValue();
            var forms = g28Submission.getForms();

            assertThat(g28Submission.getSubmissionId()).isNotEqualTo(submission.getSubmissionId());
            assertThat(g28Submission.getManifestId()).isNull();
            assertThat(g28Submission.getFormType()).isEqualTo(FormType.G28);
            assertThat(g28Submission.getFormName()).isEqualTo(FormTypeDescription.G28.getDescription());
            assertThat(g28Submission.getStatus()).isEqualTo(SubmissionState.REJECTED);
            assertThat(g28Submission.getLockboxStatus()).isEqualTo(LockboxStatuses.REJECTED);
            assertThat(forms.size()).isEqualTo(1);
            assertThat(forms.getFirst().getType()).isEqualTo(FormType.G28.getType());
        }

        @Test
        void shouldThrowSubmissionBadExceptionWhenManifestStatusIsInvalid() {
            Submission submission = Submission.builder()
                    .applicant(UserInformation.builder().accountType(AccountType.REPRESENTATIVE).build())
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I765)
                    .evidences(Lists.newArrayList(SubmissionEvidence.builder().build()))
                    .build();

            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.MANIFEST)
                    .manifestUpdate(ManifestUpdate.builder()
                            .status(StatusEnum.REJECTED)
                            .lockboxId(UUID.randomUUID().toString())
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));

            assertThrows(SubmissionBadException.class,
                    () -> service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request));
        }

        @Test
        void shouldThrowSubmissionBadExceptionWhenSubmissionStatusIsInvalid() {
            Submission submission = Submission.builder()
                    .applicant(UserInformation.builder().accountType(AccountType.REPRESENTATIVE).build())
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I765)
                    .evidences(Lists.newArrayList(SubmissionEvidence.builder().build()))
                    .build();

            SubmissionUpdateRequest request = SubmissionUpdateRequest.builder()
                    .updateType(EntityType.SUBMISSION)
                    .submissionUpdate(SubmissionUpdate.builder()
                            .status(StatusEnum.ERROR)
                            .lockboxId(UUID.randomUUID().toString())
                            .build())
                    .build();

            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));

            assertThrows(SubmissionBadException.class,
                    () -> service.updateSubmissionWithLockBoxStatus(submission.getSubmissionId(), request));
        }

        @Test
        void shouldCreateInitialSubmissionWithClientInformation() {
            final I765EligibilityCategory eligibilityCategory = I765EligibilityCategory.A12;
            final AccountType accountType = AccountType.APPLICANT;

            String clientId = UUID.randomUUID().toString();
            Name clientName = new Name("Harry", null, "Potter");
            List<String> userGroupIds = new ArrayList<String>(List.of(UUID.randomUUID().toString()));
            ClientInformation clientInfo = ClientInformation.builder()
                    .attorneyId(myUscisId)
                    .clientId(clientId)
                    .name(clientName)
                    .userGroupIds(userGroupIds)
                    .build();

            SubmissionRequest request = new SubmissionRequest(i765FormType, FormTypeDescription.I765.getDescription(),
                    eligibilityCategory.getCategory(),
                    accountType, Optional.of(clientInfo), List.of(), 0);

            Submission mockReturn = Submission.builder().build();
            when(userGroupServiceClient.isClientAssociated(any(), any()))
                    .thenReturn(new gov.dhs.uscis.intake.models.core.ClientAssociation(true, "fakeClientId"));
            when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);

            Submission response = service.createInitialSubmission(myUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).save(captor.capture());

            Submission actualSubmission = captor.getValue();

            assertEquals(mockReturn, response);
            assertEquals(myUscisId, actualSubmission.getMyUscisId());
            assertEquals(i765FormType, actualSubmission.getFormType());
            assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
            assertThat(actualSubmission.getApplicant().getEmail()).isNull();
            assertThat(actualSubmission.getFormName()).isEqualTo(FormTypeDescription.I765.getDescription());
            assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
            // Initial fee is zero in the "createInitialSubmission" method because a reason
            // for filing is required to determine fee amount.
            assertEquals(BigDecimal.ZERO, actualSubmission.getFeeTotal());
            assertEquals(SubmissionState.DRAFT, actualSubmission.getStatus());
            assertEquals(eligibilityCategory, actualSubmission.getEligibilityCategory());
            assertNotNull(actualSubmission.getTimestamp());

            userGroupIds.add("fakeClientId");

            verify(clientInformationRepository, times(1)).save(myUscisId, clientId, actualSubmission.getSubmissionId(),
                    clientName, userGroupIds);

            verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
        }

        @Test
        void shouldRetrieveSubmissionAndEnhanceWithClientInformationUpperCase() {
            Submission submission = Instancio.create(Submission.class);
            submission.getApplicant().setAccountType(AccountType.REPRESENTATIVE);
            ClientInformation clientInformation = Instancio.create(ClientInformation.class);
            submission.setClientInformation(clientInformation);
            submission.setApplicant(UserInformation.builder().accountType(AccountType.REPRESENTATIVE).build());
            String manifestId = "MANIFESTID";

            when(lockboxGatewayClient.mapManifestToSubmissionId(any()))
                    .thenReturn(Mono.just(submission.getSubmissionId()));
            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

            assertTrue(response.isPresent());
            Submission actual = response.get();

            assertThat(actual.getApplicant().getAccountType()).isEqualTo(AccountType.APPLICANT);
            assertThat(actual.getApplicant().getMyUscisId()).isEqualTo(clientInformation.getClientId());
            assertThat(actual.getClientInformation()).isNull();
            assertThat(actual.getFormName()).isNull();

            verify(lockboxGatewayClient).mapManifestToSubmissionId(manifestId.toLowerCase());
        }

        @Test
        void shouldRetrieveSubmissionAndEnhanceWithClientInformationNormal() {
            Submission submission = Instancio.create(Submission.class);
            submission.getApplicant().setAccountType(AccountType.REPRESENTATIVE);
            ClientInformation clientInformation = Instancio.create(ClientInformation.class);
            submission.setClientInformation(clientInformation);
            submission.setApplicant(UserInformation.builder().accountType(AccountType.REPRESENTATIVE).build());
            String manifestId = "manifestId";

            when(lockboxGatewayClient.mapManifestToSubmissionId(any()))
                    .thenReturn(Mono.just(submission.getSubmissionId()));
            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

            assertTrue(response.isPresent());
            Submission actual = response.get();

            assertThat(actual.getApplicant().getAccountType()).isEqualTo(AccountType.APPLICANT);
            assertThat(actual.getApplicant().getMyUscisId()).isEqualTo(clientInformation.getClientId());
            assertThat(actual.getClientInformation()).isNull();
            assertThat(actual.getFormName()).isNull();

            verify(lockboxGatewayClient).mapManifestToSubmissionId(manifestId.toLowerCase());
        }

        @Test
        void shouldRetrieveSubmissionAndEnhanceWithClientInformationEvenWhenNoClientInformationExists() {
            Submission submission = Instancio.create(Submission.class);
            submission.setClientInformation(null);
            submission.getApplicant().setAccountType(AccountType.REPRESENTATIVE);

            String manifestId = "manifestId";

            when(lockboxGatewayClient.mapManifestToSubmissionId(any()))
                    .thenReturn(Mono.just(submission.getSubmissionId()));
            when(submissionDao.getById(submission.getSubmissionId())).thenReturn(Optional.of(submission));
            Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

            assertTrue(response.isPresent());
            Submission actual = response.get();

            assertThat(actual.getApplicant().getAccountType()).isEqualTo(AccountType.APPLICANT);
            assertThat(actual.getApplicant().getMyUscisId()).isNull();
            assertThat(actual.getClientInformation()).isNull();
            assertThat(actual.getFormName()).isNull();
        }
    }

    @Nested
    class N400Tests {
        private Submission.SubmissionBuilder submissionBuilder;

        @BeforeEach
        void setUp() {
            submissionBuilder = Submission.builder()
                    .myUscisId(myUscisId)
                    .formType(FormType.N400)
                    .forms(List.of())
                    .submissionId(submissionId)
                    .status(SubmissionState.DRAFT)
                    .userRequestedFeeWaiver(Boolean.FALSE)
                    .userRequestedPartialFeeWaiver(Boolean.FALSE)
                    .evidences(Lists.newArrayList())
                    .immvi(Boolean.FALSE)
                    .attested(false)
                    .feeTotal(N400Fees.FEE_EXEMPT)
                    .attested(Boolean.FALSE);
        }

        @Test
        void retrieveSubmission_SetPartialFeeWaiverToFalseWhenNull() {
            Submission submission = submissionBuilder.build();
            submission.setSubmissionId(UUID.randomUUID().toString());
            submission.setStatus(DRAFT);
            submission.setUserRequestedPartialFeeWaiver(null);
            submission.setFormType(i765FormType);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId());

            ArgumentCaptor<Submission> captor = ArgumentCaptor.forClass(Submission.class);
            verify(submissionDao, times(1)).update(captor.capture());
            var update = captor.getValue();
            org.assertj.core.api.Assertions.assertThat(update.getStatus()).isEqualTo(DRAFT);
            org.assertj.core.api.Assertions.assertThat(update.getUserRequestedPartialFeeWaiver()).isFalse();
            org.assertj.core.api.Assertions.assertThat(update.getSubmissionId())
                    .isEqualTo(submission.getSubmissionId());
        }

        @Test
        void shouldCreateInitialSubmissionWithEligibility() {
            final N400EligibilityCategory eligibilityCategory = N400EligibilityCategory.GENERAL_PROVISION;
            final String email = "email";
            final AccountType accountType = AccountType.APPLICANT;

            SubmissionRequest request = new SubmissionRequest(n400FormType, FormTypeDescription.N400.getDescription(),
                    eligibilityCategory.getCategory(),
                    accountType, Optional.empty(), List.of(), null);

            Submission mockReturn = Submission.builder().build();
            when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);
            BigDecimal fullFee = N400Fees.FULL_FEE;
            when(feeService.calculateN400FeeFor(n400FormType, eligibilityCategory)).thenReturn(fullFee);
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(UserGroupRole.builder().userGroupId("fakeUserGroupid").build());
            Submission response = service.createInitialSubmission(myUscisId, request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).save(captor.capture());

            Submission actualSubmission = captor.getValue();

            assertEquals(mockReturn, response);
            assertEquals(myUscisId, actualSubmission.getMyUscisId());
            assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
            assertThat(actualSubmission.getApplicant().getEmail()).isNull();
            assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
            assertEquals(fullFee, actualSubmission.getFeeTotal());
            assertEquals(SubmissionState.DRAFT, actualSubmission.getStatus());
            assertEquals(eligibilityCategory, actualSubmission.getEligibilityCategory());
            assertNotNull(actualSubmission.getTimestamp());

            verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
        }

        @Test
        void shouldUpdatedN400SubmissionFeeTotalOnEligibilityChange() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            final var newEligibilityCategory = N400EligibilityCategory.GENERAL_PROVISION;
            final Submission original = submissionBuilder
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .userRequestedFeeWaiver(false)
                    .myUscisId(myUscisId)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode)
                            .eligibilityCategory(newEligibilityCategory).build()))
                    .build();

            final Submission updated = submissionBuilder
                    .submissionId(original.getSubmissionId())
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .formType(FormType.N400)
                    .feeTotal(N400Fees.FULL_FEE)
                    .myUscisId(myUscisId)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode)
                            .eligibilityCategory(newEligibilityCategory).build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(newEligibilityCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(FormType.N400.getType());

            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenReturn(original).thenReturn(updated);
            when(feeService.calculateFeeFor(original.getFormType(), updated.getEligibilityCategory(), null))
                    .thenReturn(N400Fees.FULL_FEE);

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(feeService, times(1)).calculateFeeFor(original.getFormType(),
                    updated.getEligibilityCategory(), null);
            org.assertj.core.api.Assertions.assertThat(captor.getValue()).usingRecursiveComparison()
                    .ignoringFields("updatedAt").isEqualTo(updated);
        }

        @Test
        void shouldDeleteFeeWaiverWhenEligibilityChangedToFeeExemptType_N400() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            final var feeExemptEligibility = N400EligibilityCategory.MILITARY_DURING_HOSTILITIES;
            final Submission original = submissionBuilder
                    .formType(FormType.N400)
                    .userRequestedFeeWaiver(true)
                    .feeWaiver(SubmissionEvidence.builder().s3Key("fee-waiver-s3-key").build())
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .myUscisId(myUscisId)
                    .feeTotal(N400Fees.FEE_EXEMPT)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode)
                            .applicationReasonCode(appReasonCode)
                            .eligibilityCategory(feeExemptEligibility)
                            .build()))
                    .build();

            final Submission updated = submissionBuilder
                    .attested(false)
                    .eligibilityCategory(feeExemptEligibility)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .userRequestedFeeWaiver(false)
                    .feeWaiver(null)
                    .formType(FormType.N400)
                    .myUscisId(myUscisId)
                    .feeTotal(N400Fees.FEE_EXEMPT)
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode)
                            .applicationReasonCode(appReasonCode)
                            .eligibilityCategory(feeExemptEligibility)
                            .build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(feeExemptEligibility);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(FormType.N400.getType());

            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenReturn(updated);
            when(s3Service.checkIfFileExists(original.getFeeWaiver().getS3Key(), false)).thenReturn(true);
            when(feeService.calculateFeeFor(n400FormType,
                    feeExemptEligibility, null))
                    .thenReturn(BigDecimal.ZERO);

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(s3Service, times(1)).deleteS3Object("fee-waiver-s3-key", true);
            org.assertj.core.api.Assertions.assertThat(captor.getValue()).usingRecursiveComparison()
                    .ignoringFields("updatedAt", "feeTotal").isEqualTo(updated);
        }

        @Test
        void shouldDeletePartialFeeWaiverEvidenceWhenEligibilityChangedToFeeExemptType_N400() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            final var feeExemptEligibility = N400EligibilityCategory.MILITARY_DURING_HOSTILITIES;
            String id = UUID.randomUUID().toString();
            String s3Key = "fee-waiver-s3-key";
            SubmissionEvidence partialFeeWaiverEvidence = SubmissionEvidence.builder()
                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                    .id(id).s3Key(s3Key).build();

            final Submission original = submissionBuilder
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .evidences(Lists.newArrayList(partialFeeWaiverEvidence))
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .myUscisId(myUscisId)
                    .feeTotal(BigDecimal.ZERO)
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode)
                            .eligibilityCategory(feeExemptEligibility).build()))
                    .build();
            final Submission expected = submissionBuilder
                    .submissionId(original.getSubmissionId())
                    .attested(false)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .eligibilityCategory(feeExemptEligibility)
                    .formType(FormType.N400)
                    .myUscisId(myUscisId)
                    .feeTotal(BigDecimal.ZERO.setScale(2))
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode)
                            .eligibilityCategory(feeExemptEligibility).build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(feeExemptEligibility);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(FormType.N400.getType());

            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(s3Service.checkIfFileExists(s3Key, false)).thenReturn(true);
            when(submissionDao.update(original)).thenReturn(expected);
            when(feeService.calculateFeeFor(n400FormType,
                    feeExemptEligibility, null))
                    .thenReturn(BigDecimal.ZERO);

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            verify(s3Service, times(1)).deleteS3Object(s3Key, true);

            org.assertj.core.api.Assertions.assertThat(captor.getValue()).usingRecursiveComparison()
                    .ignoringFields("updatedAt", "feeTotal").isEqualTo(expected);
        }

        @Test
        void updateUserRequestedPartialFeeWaiver_true() {

            String feeWaiverS3Key = "fee-waiver-s3-key";
            String supportS3Key = "fee-waiver-support-s3-key";

            SubmissionEvidence partialFeeWaiverEvidence = SubmissionEvidence.builder()
                    .id(UUID.randomUUID().toString())
                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                    .s3Key(supportS3Key).build();

            // Given a valid N400
            Submission original = submissionBuilder
                    .myUscisId(myUscisId)
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .feeWaiver(SubmissionEvidence.builder().s3Key(feeWaiverS3Key).build())
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .feeTotal(N400Fees.FULL_FEE)
                    .evidences(Lists.newArrayList(partialFeeWaiverEvidence))
                    .attested(true)
                    .attestedAt(ZonedDateTime.now())
                    .attestationSignature("signature")
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(formService.isFeeWaiverEnabled(n400FormType)).thenReturn(true);
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);

            // When I request a partial fee waiver
            Submission result = service.updateUserRequestedPartialFeeWaiver(myUscisId, orgMyUscisId, submissionId,
                    true);

            assertSame(original, result);
            assertTrue(result.getUserRequestedPartialFeeWaiver()); // Then the partial fee waiver should be active
            assertEquals(N400Fees.PARTIAL_FEE, result.getFeeTotal()); // And the fee total should be set
            assertFalse(result.getAttested()); // And the attestation should be cleared
            assertNull(result.getAttestedAt());
            assertNull(result.getAttestationSignature());
            assertNull(result.getFeeWaiver()); // And the fee waiver form and evidence should be deleted

            verify(submissionDao, times(1)).update(same(result));
            verify(s3Service, times(1)).deleteS3Object(feeWaiverS3Key, true);
            verify(s3Service, times(1)).deleteS3Object(supportS3Key, true);
        }

        @Test
        void updateUserRequestedPartialFeeWaiver_false_shouldDeletePartialFeeWaiverEvidenceWhenPartialFeeWaiverRequestHasChangedToFeeWaiverRequest_N400() {

            String feeWaiverS3Key = "fee-waiver-s3-key";
            String supportS3Key = "fee-waiver-support-s3-key";

            SubmissionEvidence partialFeeWaiverEvidence = SubmissionEvidence.builder()
                    .id(UUID.randomUUID().toString())
                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                    .s3Key(supportS3Key).build();

            // Given a valid N400
            final Submission original = submissionBuilder
                    .myUscisId(myUscisId)
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .feeWaiver(SubmissionEvidence.builder().s3Key(feeWaiverS3Key).build())
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .evidences(Lists.newArrayList(partialFeeWaiverEvidence))
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .feeTotal(N400Fees.PARTIAL_FEE)
                    .attested(true)
                    .attestedAt(ZonedDateTime.now())
                    .attestationSignature("signature")
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(formService.isFeeWaiverEnabled(n400FormType)).thenReturn(true);
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);

            // When I change from partial fee waiver to full fee waiver
            Submission result = service.updateUserRequestedPartialFeeWaiver(myUscisId, orgMyUscisId, submissionId,
                    false);

            assertSame(original, result);
            assertFalse(result.getUserRequestedPartialFeeWaiver()); // Then the partial fee waiver should not be active
            assertTrue(result.getUserRequestedFeeWaiver()); // But the fee waiver should still be active
            assertEquals(N400Fees.FULL_FEE, result.getFeeTotal()); // And the fee total should be reset to full
            assertFalse(result.getAttested()); // And the attestation should be cleared
            assertNull(result.getAttestedAt());
            assertNull(result.getAttestationSignature());
            assertThat(result.getEvidences()).isEmpty(); // And the fee waiver evidence should be deleted
            assertNotNull(result.getFeeWaiver().getS3Key()); // But the fee waiver form should not

            verify(submissionDao, times(1)).update(same(result));
            verify(s3Service, times(1)).deleteS3Object(supportS3Key, true);
            verify(s3Service, times(0)).deleteS3Object(feeWaiverS3Key, true);
        }

        @Test
        void updateUserRequestedPartialFeeWaiver_shouldThrowWhenNotSupportedFormType() {
            final Submission original = submissionBuilder
                    .myUscisId(myUscisId)
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I765)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .eligibilityCategory(I765EligibilityCategory.C11PAROLE)
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(formService.isFeeWaiverEnabled(i765FormType)).thenReturn(true);

            // When I change from partial fee waiver to full fee waiver
            assertThrows(SubmissionBadException.class, () -> {
                service.updateUserRequestedPartialFeeWaiver(myUscisId, orgMyUscisId, submissionId, false);
            });

        }

        @Test
        void updateUserRequestedPartialFeeWaiver_shouldThrowWhenFeewaiverFeatureIsDisabled() {
            final Submission original = submissionBuilder
                    .myUscisId(myUscisId)
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .feeTotal(N400Fees.FULL_FEE)
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(formService.isFeeWaiverEnabled(n400FormType)).thenReturn(false);

            // When I change from partial fee waiver to full fee waiver
            assertThrows(SubmissionBadException.class, () -> {
                service.updateUserRequestedPartialFeeWaiver(myUscisId, orgMyUscisId, submissionId, false);
            });

        }

        @Test
        void updateUserRequestedFeeWaiver_true_shouldSetPartialFeeWaiverToFalse_N400() {
            final Submission original = submissionBuilder
                    .myUscisId(myUscisId)
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .feeTotal(N400Fees.FULL_FEE)
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            // When I request a fee waiver
            Submission result = service.updateUserRequestedFeeWaiver(myUscisId, orgMyUscisId, submissionId, true);

            assertTrue(result.getUserRequestedFeeWaiver());
            assertFalse(result.getUserRequestedPartialFeeWaiver()); // Then the partial fee waiver should be initialized
                                                                    // to false
            assertEquals(N400Fees.FULL_FEE, result.getFeeTotal());
            assertFalse(result.getAttested());
            assertNull(result.getAttestedAt());
            assertNull(result.getAttestationSignature());

            verify(submissionDao, times(1)).update(same(result));
        }

        @Test
        void updateUserRequestedFeeWaiver_false_shouldResetFeeWaiverAndDeleteFeeWaiverAndSupportingEvidences_N400() {

            String evidenceS3Key = "s3-key";
            String feeWaiverS3Key = "fee-waiver-s3-key";

            SubmissionEvidence supportingEvidence = SubmissionEvidence.builder()
                    .id(UUID.randomUUID().toString())
                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                    .s3Key(evidenceS3Key).build();

            final Submission original = submissionBuilder
                    .myUscisId(myUscisId)
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .userRequestedFeeWaiver(true)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .feeWaiver(SubmissionEvidence.builder().s3Key(feeWaiverS3Key).build())
                    .evidences(Lists.newArrayList(supportingEvidence))
                    .feeTotal(N400Fees.PARTIAL_FEE)
                    .attested(true)
                    .attestedAt(ZonedDateTime.now())
                    .attestationSignature("signature")
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(feeService.calculateFeeFor(FormType.N400, original.getEligibilityCategory(), null))
                    .thenReturn(N400Fees.FULL_FEE);
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);

            Submission result = service.updateUserRequestedFeeWaiver(myUscisId, orgMyUscisId, submissionId, false);

            assertFalse(result.getUserRequestedFeeWaiver());
            assertFalse(result.getUserRequestedPartialFeeWaiver());
            assertNull(result.getFeeWaiver());
            assertEquals(N400Fees.FULL_FEE, result.getFeeTotal());
            assertFalse(result.getAttested());
            assertNull(result.getAttestedAt());
            assertNull(result.getAttestationSignature());

            verify(submissionDao, times(1)).update(same(result));
            verify(feeService, times(1)).calculateFeeFor(any(), any(), any());
            verify(s3Service, times(1)).deleteS3Object(evidenceS3Key, true);
            verify(s3Service, times(1)).deleteS3Object(feeWaiverS3Key, true);
        }

        @Test
        void updateUserRequestedFeeWaiver_true_shouldUpdateFeeWaiver_N400() {
            final Submission original = submissionBuilder
                    .myUscisId(myUscisId)
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .feeTotal(N400Fees.FULL_FEE)
                    .build();
            final Submission updated = submissionBuilder
                    .submissionId(original.getSubmissionId())
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .feeTotal(N400Fees.FULL_FEE)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .formType(FormType.N400)
                    .myUscisId(myUscisId)
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

            Submission result = service.updateUserRequestedFeeWaiver(myUscisId, orgMyUscisId, submissionId, true);

            assertTrue(result.getUserRequestedFeeWaiver());
            assertFalse(result.getUserRequestedPartialFeeWaiver());
            assertEquals(N400Fees.FULL_FEE, result.getFeeTotal());
            assertFalse(result.getAttested());
            assertNull(result.getAttestedAt());
            assertNull(result.getAttestationSignature());

            verify(submissionDao, times(1)).update(same(result));
        }

        @Test
        void updateUserRequestedFeeWaiver_false_shouldRecalculateTotalFee_I131() {
            SubmissionForm i131Form = SubmissionForm.builder()
                    .type("I-131")
                    .feeTotal(I131Fees.FULL_FEE)
                    .build();

            final Submission original = submissionBuilder
                    .myUscisId(myUscisId)
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.I131)
                    .forms(List.of(i131Form))
                    .eligibilityCategory(I131EligibilityCategory.TPS_BENEFICIARY)
                    .feeTotal(BigDecimal.ZERO)
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
            when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I131.getType())).thenReturn(true);

            Submission result = service.updateUserRequestedFeeWaiver(myUscisId, orgMyUscisId, submissionId, false);

            assertEquals(I131Fees.FULL_FEE, result.getFeeTotal());
        }

        @Test
        void shouldDeleteFormFromSubmission_N400() {
            String submissionId = UUID.randomUUID().toString();
            String s3Key = UUID.randomUUID().toString();
            SubmissionForm submissionForm = SubmissionForm.builder().id(formId).s3Key(s3Key).build();

            Submission submission = submissionBuilder
                    .submissionId(submissionId)
                    .formType(FormType.N400)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .immvi(false)
                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .forms(new ArrayList<SubmissionForm>(List.of(submissionForm)))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));

            service.deleteFormFromSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId(),
                    submissionForm.getId());
            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(s3Service, times(1)).deleteS3Object(s3Key, false);
            verify(submissionDao, times(1)).update(captor.capture());
            verify(validationService, times(1)).deleteStatus(formId);

            assertEquals(1, submission.getForms().size());
            assertEquals(1, captor.getValue().getForms().size());
        }

        @Test
        void shouldRevalidateBasisOfEligibilityWhenEligibilityChanged_N400() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            final N400EligibilityCategory newEligibilityCategory = N400EligibilityCategory.MILITARY_DURING_HOSTILITIES;
            String extractedCategory = N400EligibilityCategory.GENERAL_PROVISION.getCategory();
            final Submission original = submissionBuilder
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .userRequestedFeeWaiver(false)
                    .forms(asList(SubmissionForm
                            .builder().id(formId).name("formName")
                            .md5Hash(Constants.MD5HASH).url("someURL")
                            .s3Key("mock-s3key")
                            .type(n400FormType.getType())
                            .benefitTypeCode(benefitTypeCode)
                            .applicationReasonCode(appReasonCode)
                            .eligibilityCategory(newEligibilityCategory)
                            .extractedData(ExtractedFormEntries.builder()
                                    .eligibilityCategory(extractedCategory)
                                    .build())
                            .build()))
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .myUscisId(myUscisId)
                    .feeTotal(N400Fees.FULL_FEE)
                    .build();
            final Submission updated = submissionBuilder
                    .submissionId(original.getSubmissionId())
                    .attested(false)
                    .forms(asList(SubmissionForm
                            .builder().id(formId).type(n400FormType.getType()).name("formName")
                            .eligibilityCategory(newEligibilityCategory)
                            .md5Hash(Constants.MD5HASH).url("someURL")
                            .s3Key("mock-s3key")
                            .benefitTypeCode(benefitTypeCode)
                            .applicationReasonCode(appReasonCode)
                            .eligibilityCategory(newEligibilityCategory)
                            .extractedData(ExtractedFormEntries.builder()
                                    .eligibilityCategory(extractedCategory)
                                    .build())
                            .build()))
                    .eligibilityCategory(newEligibilityCategory)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .formType(FormType.N400)
                    .myUscisId(myUscisId)
                    .feeTotal(N400Fees.FEE_EXEMPT)
                    .build();

            BasisOfEligibilityValidator validatorMock = mock(BasisOfEligibilityValidator.class);
            when(categoryValidatorFactory.getValidator(n400FormType)).thenReturn(validatorMock);
            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenReturn(updated);
            when(feeService.calculateFeeFor(n400FormType,
                    newEligibilityCategory, null))
                    .thenReturn(N400Fees.FEE_EXEMPT);

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(newEligibilityCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(n400FormType.getType());

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> submissionCaptor = ArgumentCaptor
                    .forClass(Submission.class);
            verify(submissionDao, times(1)).update(submissionCaptor.capture());
            verify(validatorMock, times(1)).validate(updated,
                    FormFields.builder().formId(formId).eligibilityCategory(extractedCategory).build());

            org.assertj.core.api.Assertions.assertThat(submissionCaptor.getValue())
                    .usingRecursiveComparison().ignoringFields("updatedAt").isEqualTo(updated);
        }

        @Test
        void shouldRemoveIrrelevantEvidenceForNewEligibilityCategory() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            String submissionid = UUID.randomUUID().toString();
            String evidenceGroupType = "evidenceGroup";
            N400EligibilityCategory updatedCategory = N400EligibilityCategory.SPOUSE_OF_US_CITIZEN;

            SubmissionEvidence relevantEvidence = SubmissionEvidence.builder()
                    .id(UUID.randomUUID().toString())
                    .s3Key("evidence/Key").evidenceGroupType(evidenceGroupType).type("evidenceType")
                    .build();
            SubmissionEvidence irrelevantEvidence = SubmissionEvidence.builder()
                    .id(UUID.randomUUID().toString())
                    .s3Key("irrelevant/evidence/Key").evidenceGroupType("irrelevant")
                    .type("evidenceType").build();

            EvidenceGroup evidenceGroup = EvidenceGroup.builder().id(evidenceGroupType).build();

            final Submission original = submissionBuilder
                    .submissionId(submissionid)
                    .formType(n400FormType)
                    .myUscisId(myUscisId)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .status(SubmissionState.DRAFT)
                    .forms(List.of(SubmissionForm.builder().type(n400FormType.getType())
                            .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                            .extractedData(ExtractedFormEntries.builder()
                                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION.getCategory())
                                    .build())
                            .benefitTypeCode(benefitTypeCode)
                            .applicationReasonCode(appReasonCode)
                            .build()))
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(Lists.newArrayList(relevantEvidence, irrelevantEvidence))
                    .feeTotal(N400Fees.FEE_EXEMPT)
                    .attested(false)
                    .build();
            final Submission updated = submissionBuilder
                    .submissionId(submissionid)
                    .formType(n400FormType)
                    .myUscisId(myUscisId)
                    .eligibilityCategory(updatedCategory)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .forms(List.of(SubmissionForm.builder().type(n400FormType.getType())
                            .eligibilityCategory(updatedCategory)
                            .extractedData(ExtractedFormEntries.builder()
                                    .reasonForFiling(ReasonForFiling.INITIAL.toString())
                                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION.getCategory())
                                    .build())
                            .benefitTypeCode(benefitTypeCode)
                            .applicationReasonCode(appReasonCode)
                            .build()))
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .evidences(Lists.newArrayList(relevantEvidence))
                    .feeTotal(N400Fees.FULL_FEE)
                    .status(SubmissionState.DRAFT)
                    .attested(false)
                    .build();

            BasisOfEligibilityValidator validatorMock = mock(BasisOfEligibilityValidator.class);
            // when(categoryValidatorFactory.getValidator(n400FormType)).thenReturn(validatorMock);
            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(s3Service.checkIfFileExists(anyString(), eq(false))).thenReturn(true);
            when(feeService.calculateFeeFor(FormType.N400, updatedCategory, null))
                    .thenReturn(N400Fees.FULL_FEE);
            when(formService.retrieveEvidenceGroups(original.getFormType().getType(),
                    updatedCategory.getCategory()))
                    .thenReturn(List.of(evidenceGroup));

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(updatedCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(n400FormType.getType());

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(formService, times(1)).retrieveEvidenceGroups(anyString(), anyString());
            verify(submissionDao, times(1)).update(captor.capture());
            assertThat(captor.getValue(), samePropertyValuesAs(updated, "updatedAt"));

            verify(s3Service, times(1)).deleteS3Object(irrelevantEvidence.getS3Key(), true);
        }

        @Test
        void shouldUpdateSubmissionFormWithFormFields() {

            String submissionId = UUID.randomUUID().toString();

            N400EligibilityCategory generalProvision = N400EligibilityCategory.GENERAL_PROVISION;
            Submission submission = Instancio.create(Submission.class);
            String reasonForApply = "1.a.";
            submission.setUserRequestedFeeWaiver(false);
            submission.setFeeTotal(N400Fees.FULL_FEE);
            submission.setImmvi(false);
            submission.setReasonForFiling(ReasonForFiling.INITIAL.toString());
            submission.setEligibilityCategory(generalProvision);
            submission.setSubmissionId(submissionId);
            submission.setStatus(DRAFT);
            submission.setFormType(FormType.N400);
            submission.setForms(asList(
                    SubmissionForm.builder().id(formId)
                            .eligibilityCategory(submission.getEligibilityCategory())
                            .build()));

            FormFields formFields = FormFields.builder()
                    .submissionId(submission.getSubmissionId())
                    .formId(formId)
                    .abcBenefitsApplied(false)
                    .reasonForApplySelection(reasonForApply)
                    .eligibilityCategory(generalProvision.getCategory())
                    .build();

            when(submissionDao.getById(anyString())).thenReturn(Optional.of(submission));
            service.updateSubmissionWithFormFields(formFields, submission.getFormType());

            ArgumentCaptor<Submission> captor = ArgumentCaptor.forClass(Submission.class);
            verify(submissionDao, times(1)).update(captor.capture());
            verifyNoInteractions(feeService);

            Submission entityToSave = captor.getValue();
            ExtractedFormEntries extractedData = entityToSave.getForms().getFirst().getExtractedData();
            org.assertj.core.api.Assertions.assertThat(extractedData).isNotNull();
            org.assertj.core.api.Assertions.assertThat(extractedData.getEligibilityCategory())
                    .isEqualTo(generalProvision.getCategory());

        }

        @Test
        void shouldRetrieveSubmissionStatusWithoutMissingFieldErrorsWhenPartialFeeWaiverIsTrue() {

            Submission submission = submissionBuilder
                    .submissionId(UUID.randomUUID().toString())
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeTotal(N400Fees.PARTIAL_FEE)
                    .formType(FormType.N400)
                    .forms(asList(
                            SubmissionForm
                                    .builder().id("formId").name("formName")
                                    .type(n400FormType.getType())
                                    .md5Hash(Constants.MD5HASH).url("someURL")
                                    .build()))
                    .evidences(
                            asList(
                                    SubmissionEvidence.builder()
                                            .type("driversLicense")
                                            .name("evidenceName")
                                            .md5Hash(Constants.MD5HASH)
                                            .formId("id")
                                            .url("someURL").s3Key("s3Key")
                                            .id("evidenceId").build(),
                                    SubmissionEvidence.builder()
                                            .type("Other")
                                            .formId("id")

                                            .evidenceGroupType(
                                                    SubmissionService.FEE_WAIVER_EVIDENCE_GROUP)
                                            .name("evidenceName")
                                            .md5Hash(Constants.MD5HASH)
                                            .url("someURL").s3Key("s3Key")
                                            .id("evidenceId")
                                            .build()))
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse
                    .builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.N400.getType())
                                    .errors(List.of())
                                    .build()))
                    .evidenceErrors(
                            asList(
                                    ErrorGroup.builder()
                                            .type("driversLicense")
                                            .formType("N-400")
                                            .errors(List.of()).build(),
                                    ErrorGroup.builder()
                                            .type("Other")
                                            .formType("N-400")
                                            .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldRetrieveSubmissionStatusWithMissingSupportingEvidenceErrorWhenPartialFeeWaiverIsTrue() {

            Submission submission = submissionBuilder
                    .submissionId(UUID.randomUUID().toString())
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeTotal(N400Fees.PARTIAL_FEE)
                    .formType(FormType.N400)
                    .forms(asList(
                            SubmissionForm.builder()
                                    .id("formId")
                                    .type(n400FormType.getType())
                                    .name("formName")
                                    .md5Hash(Constants.MD5HASH)
                                    .url("someURL")
                                    .build()))
                    .evidences(asList(
                            SubmissionEvidence.builder()
                                    .type("driversLicense")
                                    .evidenceGroupType("evidence_group")
                                    .name("evidenceName")
                                    .md5Hash(Constants.MD5HASH)
                                    .url("someURL").s3Key("s3Key")
                                    .id("evidenceId")
                                    .formId("formId")
                                    .build()))
                    .build();

            SubmissionStatusResponse expected = SubmissionStatusResponse.builder()
                    .submissionErrors(List.of())
                    .formErrors(List.of(
                            ErrorGroup.builder()
                                    .type(FormType.N400.getType())
                                    .errors(List.of())
                                    .build()))
                    .evidenceErrors(asList(
                            ErrorGroup.builder().type(
                                    SubmissionService.FEE_WAIVER_EVIDENCE_GROUP)
                                    .errors(List.of("Partial Fee waiver evidence is missing"))
                                    .build(),
                            ErrorGroup.builder()
                                    .type("driversLicense")
                                    .formType(FormType.N400.getType())
                                    .errors(List.of()).build()))
                    .build();

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            assertEquals(expected, actual);
        }

        @Test
        void shouldNotUpdateFeeForFeeWaiverRequestedSubmissionWhenEligibilityCategoryChanges() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            final Submission original = submissionBuilder
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .feeTotal(N400Fees.FEE_EXEMPT)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .feeWaiver(SubmissionEvidence.builder().build())
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode).build()))
                    .build();
            N400EligibilityCategory updatedCategory = N400EligibilityCategory.SPOUSE_OF_US_CITIZEN;

            final Submission updated = submissionBuilder
                    .submissionId(original.getSubmissionId())
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(false)
                    .feeTotal(N400Fees.FEE_EXEMPT)
                    .userRequestedFeeWaiver(true)
                    .feeWaiver(SubmissionEvidence.builder().build())
                    .eligibilityCategory(updatedCategory)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .formType(FormType.N400)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode)
                            .eligibilityCategory(updatedCategory).build()))
                    .build();

            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(s3Service.checkIfFileExists(original.getFeeWaiver().getS3Key(), false)).thenReturn(true);
            when(feeService.calculateFeeFor(FormType.N400, updatedCategory, null))
                    .thenReturn(N400Fees.FULL_FEE);
            when(submissionDao.update(any(Submission.class))).thenReturn(updated);

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(updatedCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(FormType.N400.getType());

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());
            var updatedSubmission = captor.getValue();

            assertThat(updatedSubmission, samePropertyValuesAs(updated, "updatedAt"));
            // verifyNoInteractions(s3Service);
        }

        @Test
        void shouldNotUpdateFeeForPartialFeeWaiverRequestedSubmissionWhenEligibilityCategoryChanges() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            final Submission original = submissionBuilder
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .feeTotal(N400Fees.PARTIAL_FEE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode).build()))
                    .build();
            N400EligibilityCategory updatedCategory = N400EligibilityCategory.SPOUSE_OF_US_CITIZEN;
            final Submission updated = submissionBuilder
                    .submissionId(original.getSubmissionId())
                    .feeTotal(N400Fees.PARTIAL_FEE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .eligibilityCategory(updatedCategory)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .formType(FormType.N400)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode)
                            .eligibilityCategory(updatedCategory).build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(updatedCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(FormType.N400.getType());

            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenReturn(updated);
            when(feeService.calculateFeeFor(n400FormType, updatedCategory, null)).thenReturn(N400Fees.FULL_FEE);
            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());

            assertThat(captor.getValue(), samePropertyValuesAs(updated, "updatedAt"));
            verifyNoInteractions(s3Service);
        }

        @Test
        void shouldUpdateFeeFromPartialFeeWaiverRequestedSubmissionWhenEligibilityCategoryChangesToFeeExemptCategory() {
            Integer benefitTypeCode = 63;
            Integer appReasonCode = 39;

            final Submission original = submissionBuilder
                    .submissionId(UUID.randomUUID().toString())
                    .formType(FormType.N400)
                    .eligibilityCategory(N400EligibilityCategory.GENERAL_PROVISION)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .feeTotal(N400Fees.PARTIAL_FEE)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode).build()))
                    .build();
            N400EligibilityCategory updatedCategory = N400EligibilityCategory.MILITARY_DURING_HOSTILITIES;
            final Submission updated = submissionBuilder
                    .submissionId(original.getSubmissionId())
                    .feeTotal(N400Fees.FEE_EXEMPT)
                    .userRequestedPartialFeeWaiver(false)
                    .userRequestedFeeWaiver(false)
                    .eligibilityCategory(updatedCategory)
                    .benefitTypeCode(benefitTypeCode)
                    .applicationReaonCode(appReasonCode)
                    .formType(FormType.N400)
                    .myUscisId(myUscisId)
                    .forms(List.of(SubmissionForm.builder().id("mock-id").type(FormType.N400.getType())
                            .benefitTypeCode(benefitTypeCode).applicationReasonCode(appReasonCode)
                            .eligibilityCategory(updatedCategory).build()))
                    .build();
            when(submissionDao.getDraftById(original.getMyUscisId(), original.getOrgMyUscisId(),
                    original.getSubmissionId()))
                    .thenReturn(Optional.of(original));
            when(submissionDao.update(any(Submission.class))).thenReturn(updated);
            when(feeService.calculateFeeFor(n400FormType, updatedCategory, null)).thenReturn(N400Fees.FEE_EXEMPT);

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(updatedCategory);
            request.setBenefitTypeCode(63);
            request.setApplicationReasonCode(39);
            request.setFormType(FormType.N400.getType());

            service.updateEligibility(original.getSubmissionId(), original.getMyUscisId(), original.getOrgMyUscisId(),
                    request);

            ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
            verify(submissionDao, times(1)).update(captor.capture());

            assertThat(captor.getValue(), samePropertyValuesAs(updated, "updatedAt"));
            verifyNoInteractions(s3Service);
        }

        @Test
        void retrieveSubmission_DoNotSetFeeToZeroWhenPartialFeeWaiverRequested() {
            Submission submission = Instancio.create(Submission.class);
            submission.setSubmissionId(UUID.randomUUID().toString());
            submission.setStatus(DRAFT);
            submission.setUserRequestedFeeWaiver(true);
            submission.setUserRequestedPartialFeeWaiver(true);
            submission.setFeeTotal(N400Fees.PARTIAL_FEE);
            submission.setFormType(FormType.N400);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            when(s3Service.checkIfFileExists(anyString(), anyBoolean())).thenReturn(true);
            var update = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submission.getSubmissionId());

            verify(submissionDao, times(0)).update(any(Submission.class));

            org.assertj.core.api.Assertions.assertThat(update.getStatus()).isEqualTo(DRAFT);
            org.assertj.core.api.Assertions.assertThat(update.getFeeTotal())
                    .isEqualTo(N400Fees.PARTIAL_FEE);
            org.assertj.core.api.Assertions.assertThat(update.getSubmissionId())
                    .isEqualTo(submission.getSubmissionId());
        }

    }

    @Nested
    class I140Tests {
        private Submission.SubmissionBuilder submissionBuilder;

        @BeforeEach
        void setUp() {
            submissionBuilder = Submission.builder()
                    .myUscisId(myUscisId)
                    .formType(FormType.I140)
                    .forms(List.of())
                    .submissionId(submissionId)
                    .status(SubmissionState.DRAFT)
                    .evidences(Lists.newArrayList())
                    .userRequestedPartialFeeWaiver(false)
                    .immvi(Boolean.FALSE)
                    .attested(false)
                    .attested(Boolean.FALSE);
        }

        @Test
        void shouldAddErrorWhenScheduleAIsFalseButDolNumberIsMissing() {
            Submission submission = submissionBuilder.build();
            submission.setFormSpecificInfo(new I140FormSpecificInfo("", false));
            submission.setFormType(FormType.I140);
            submission.setEligibilityCategory(I140EligibilityCategory.SKILLED_WORKER);
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            org.assertj.core.api.Assertions.assertThat(actual.submissionErrors().size()).isEqualTo(1);
            org.assertj.core.api.Assertions.assertThat(actual.evidenceErrors().size()).isEqualTo(1);
            org.assertj.core.api.Assertions.assertThat(actual.formErrors().size()).isEqualTo(1);

        }

        @Test
        void shouldIgnoreDolNumberIsMissingWhenScheduleAIsTrue() {
            Submission submission = submissionBuilder.build();
            submission.setFormType(FormType.I140);

            submission.setFormSpecificInfo(new I140FormSpecificInfo("", true));
            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            org.assertj.core.api.Assertions.assertThat(actual.submissionErrors().size()).isEqualTo(1);
            org.assertj.core.api.Assertions.assertThat(actual.evidenceErrors().size()).isEqualTo(0);

        }

        @Test
        void shouldIgnoreDolNumberIsMissingWhenScheduleAIsFalse() {
            Submission submission = submissionBuilder.build();
            submission.setEligibilityCategory(I140EligibilityCategory.PROFESSIONAL);
            submission.setFormSpecificInfo(new I140FormSpecificInfo("", false));

            when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submission.getSubmissionId()))
                    .thenReturn(Optional.of(submission));
            SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                    submission.getSubmissionId());

            org.assertj.core.api.Assertions.assertThat(actual.submissionErrors().size()).isEqualTo(1);
        }
    }

    @Test
    public void shouldHandleSubmissionAsApplicantWhenAnApplicantAccountTypeIsNull() {
        Submission submission = Instancio.create(Submission.class);
        submission.getApplicant().setAccountType(null);
        String manifestId = "manifestId";
        String id = "submissionId";

        when(lockboxGatewayClient.mapManifestToSubmissionId(any())).thenReturn(Mono.just(id));
        when(submissionDao.getById(id)).thenReturn(Optional.of(submission));
        Optional<Submission> response = service.retrieveSubmissionByManifestId(manifestId);

        assertTrue(response.isPresent());
        assertEquals(submission, response.get());
        assertEquals(submission.getApplicant().getAccountType(), AccountType.APPLICANT);
    }

    @Test
    public void shouldStillCreateClientInformationWithAttorneyDetailsIfRequestDoesNotContainClientDetails() {
        final I765EligibilityCategory eligibilityCategory = I765EligibilityCategory.A12;
        final AccountType accountType = AccountType.APPLICANT;
        SubmissionRequest request = new SubmissionRequest(i765FormType, FormTypeDescription.I765.getDescription(),
                eligibilityCategory.getCategory(),
                accountType, Optional.empty(), List.of(), 0);

        Submission mockReturn = Submission.builder().build();

        String attorneyGroupid = "userGroupid";
        when(userGroupServiceClient.getRepGroupId(myUscisId))
                .thenReturn(UserGroupRole.builder().userGroupId(attorneyGroupid).build());
        when(submissionDao.save(any(Submission.class))).thenReturn(mockReturn);

        Submission response = service.createInitialSubmission(myUscisId, request);

        ArgumentCaptor<Submission> captor = ArgumentCaptor.captor();
        verify(submissionDao, times(1)).save(captor.capture());

        Submission actualSubmission = captor.getValue();

        assertEquals(mockReturn, response);
        assertEquals(myUscisId, actualSubmission.getMyUscisId());
        assertEquals(i765FormType, actualSubmission.getFormType());
        assertEquals(myUscisId, actualSubmission.getApplicant().getMyUscisId());
        assertThat(actualSubmission.getApplicant().getEmail()).isNull();
        assertThat(actualSubmission.getFormName()).isEqualTo(FormTypeDescription.I765.getDescription());
        assertEquals(accountType, actualSubmission.getApplicant().getAccountType());
        assertEquals(BigDecimal.ZERO, actualSubmission.getFeeTotal());
        assertEquals(SubmissionState.DRAFT, actualSubmission.getStatus());
        assertEquals(eligibilityCategory, actualSubmission.getEligibilityCategory());
        assertNotNull(actualSubmission.getTimestamp());

        verify(clientInformationRepository, times(1)).save(myUscisId, null, actualSubmission.getSubmissionId(),
                null, List.of(attorneyGroupid));

        verify(userGroupServiceClient, never()).isClientAssociated(any(), any());
        verify(auditService, times(1)).createAudit(myUscisId, actualSubmission.getSubmissionId());
    }

    @Test
    void shouldSetResidencyStatusForSubmission() {
        List<SubmissionForm> forms = List.of(
                SubmissionForm.builder()
                        .type(i130FormType.getType())
                        .id("formId")
                        .s3Key("s3Key")
                        .build());

        final var submission = Submission.builder()
                .submissionId(UUID.randomUUID().toString())
                .status(SubmissionState.DRAFT)
                .myUscisId(myUscisId)
                .formType(i130FormType)
                .forms(forms)
                .build();
        final var updatedSubmission = Submission.builder()
                .submissionId(UUID.randomUUID().toString())
                .status(SubmissionState.DRAFT)
                .myUscisId(myUscisId)
                .formType(i130FormType)
                .forms(forms)
                .build();
        ResidencyStatus status = ResidencyStatus.LPR;

        when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                submission.getSubmissionId()))
                .thenReturn(Optional.of(submission));
        when(submissionDao.update(any(Submission.class))).thenReturn(updatedSubmission);

        var resultingSubmission = service.setResidencyStatus(submission.getSubmissionId(),
                submission.getMyUscisId(), submission.getOrgMyUscisId(), status);

        assertTrue(resultingSubmission.getIsUSCitizen().equals(ResidencyStatus.LPR));

        verify(sqsService).sendValidationRequest(any(ValidationRequest.class));
        verify(validationService).deleteStatus("formId");
    }

    @Test
    void shouldSetAdditionalInfoforI130WhenResidencyStatusIsSet() throws IOException {
        String fileName = "fileName";
        String submissionId = UUID.randomUUID().toString();
        String baseUrl = "https://downloader.uscis.dhs.gov";

        ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);
        UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                Constants.MD5HASH, "I-130");
        S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
        MockMultipartFile file = new MockMultipartFile(
                fileName,
                fileName,
                MediaType.MULTIPART_FORM_DATA_VALUE,
                "Hello, World!".getBytes());
        I130EligibilityCategory eligibilityCategory = I130EligibilityCategory.PETITION_FOR_CHILD;

        I130AdditionalInformation addtionalInfo = new I130AdditionalInformation();
        addtionalInfo.setIsUSCitizen(ResidencyStatus.USC);

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .formType(i130FormType)
                .eligibilityCategory(eligibilityCategory).submissionId(submissionId)
                .isUSCitizen(ResidencyStatus.USC)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I130.getType())
                        .build()))
                .build();
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I130.getType())).thenReturn(true);
        when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                any(UploadRequest.class))).thenReturn(s3FileInfo);

        service.updateSubmissionWithForm(submission, uploadRequest, file);
        ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);

        verify(sqsService).sendValidationRequest(valRequest.capture());
        ValidationRequest resultingRequest = valRequest.getValue();
        assertNotNull(resultingRequest.additionalInfo());
    }

    @Test
    void shouldgetOrgDrafts() {
        String orgMyUscisId = "O-ORGUUID";
        List<SubmissionState> submissionStateList = List.of(SubmissionState.DRAFT);

        List<Submission> expected = List.of(
                Submission.builder()
                        .submissionId("fakeSubId")
                        .build());

        when(submissionDao.findAllByOrgMyUscisIdAndStatus(myUscisId, submissionStateList)).thenReturn(expected);

        List<Submission> actual = service.findAllByOrgMyUscisIdAndStatus(myUscisId, submissionStateList);

        assertEquals(expected, actual);
    }

    @Test
    void shouldHandleExceptionOnOrgDrafts() {
        String orgMyUscisId = "O-ORGUUID";
        List<SubmissionState> submissionStateList = List.of(SubmissionState.DRAFT);

        when(submissionDao.findAllByOrgMyUscisIdAndStatus(myUscisId, submissionStateList))
                .thenThrow(new RuntimeException("Oh no!"));

        assertThrows(SubmissionIndexException.class,
                () -> service.findAllByOrgMyUscisIdAndStatus(myUscisId, submissionStateList));
    }

    @Test
    void shouldSetAdditionalInfoforI140WhenScheduleAIsSet() throws IOException {
        String fileName = "fileName";
        String submissionId = UUID.randomUUID().toString();
        String baseUrl = "https://downloader.uscis.dhs.gov";

        ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);
        UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                Constants.MD5HASH, "I-140");
        S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
        MockMultipartFile file = new MockMultipartFile(
                fileName,
                fileName,
                MediaType.MULTIPART_FORM_DATA_VALUE,
                "Hello, World!".getBytes());
        I140EligibilityCategory eligibilityCategory = I140EligibilityCategory.EXTRAORDINARY_ABILITY;

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .formType(i140FormType)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I140.getType())
                        .formSpecificInfo(new I140FormSpecificInfo("test-dol-number", true))
                        .build()))
                .formSpecificInfo(new I140FormSpecificInfo("test-dol-number", true))
                .build();
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I140.getType())).thenReturn(true);
        when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                any(UploadRequest.class))).thenReturn(s3FileInfo);

        service.updateSubmissionWithForm(submission, uploadRequest, file);
        ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);

        verify(sqsService).sendValidationRequest(valRequest.capture());
        ValidationRequest resultingRequest = valRequest.getValue();
        I140AdditionalInformation capturedAdditionalInfo = (I140AdditionalInformation) resultingRequest
                .additionalInfo();

        assertTrue(capturedAdditionalInfo.isScheduleA());
    }

    @Test
    void shouldSetAdditionalInfoforI485() throws IOException {
        String fileName = "fileName";
        String submissionId = UUID.randomUUID().toString();
        String baseUrl = "https://downloader.uscis.dhs.gov";

        ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);
        UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                Constants.MD5HASH, "I-485");
        S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
        MockMultipartFile file = new MockMultipartFile(
                fileName,
                fileName,
                MediaType.MULTIPART_FORM_DATA_VALUE,
                "Hello, World!".getBytes());
        I485EligibilityCategory eligibilityCategory = I485EligibilityCategory.DERIVATIVE_APPLICANT;

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .formType(FormType.I485)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485.getType())
                        .formSpecificInfo(new I485FormSpecificInfo(true, false, false))
                        .build()))
                .formSpecificInfo(new I485FormSpecificInfo(true, false, false))
                .build();
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I485.getType())).thenReturn(true);
        when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                any(UploadRequest.class))).thenReturn(s3FileInfo);

        service.updateSubmissionWithForm(submission, uploadRequest, file);
        ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);

        verify(sqsService).sendValidationRequest(valRequest.capture());
        ValidationRequest resultingRequest = valRequest.getValue();
        I485AdditionalInformation capturedAdditionalInfo = (I485AdditionalInformation) resultingRequest
                .additionalInfo();

        assertTrue(capturedAdditionalInfo.isMilitaryVeteran());
        assertFalse(capturedAdditionalInfo.isUnder14());
    }

    @Test
    void shouldSetAdditionalInfoforI485A() throws IOException {
        String fileName = "fileName";
        String submissionId = UUID.randomUUID().toString();
        String baseUrl = "https://downloader.uscis.dhs.gov";

        ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);
        UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                Constants.MD5HASH, FormType.I485A.getType());
        S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
        MockMultipartFile file = new MockMultipartFile(
                fileName,
                fileName,
                MediaType.MULTIPART_FORM_DATA_VALUE,
                "Hello, World!".getBytes());
        I485AEligibilityCategory eligibilityCategory = I485AEligibilityCategory.DERIVATIVE_BENEFICIARY_OF_IMMIGRANT_PETITION_01141998;

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .formType(FormType.I485A)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485A.getType())
                        .formSpecificInfo(new I485AFormSpecificInfo(true, false, true))
                        .build()))
                .formSpecificInfo(new I485AFormSpecificInfo(true, false, true))
                .build();
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I485A.getType())).thenReturn(true);
        when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                any(UploadRequest.class))).thenReturn(s3FileInfo);

        service.updateSubmissionWithForm(submission, uploadRequest, file);
        ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);

        verify(sqsService).sendValidationRequest(valRequest.capture());
        ValidationRequest resultingRequest = valRequest.getValue();
        I485AAdditionalInformation capturedAdditionalInfo = (I485AAdditionalInformation) resultingRequest
                .additionalInfo();

        assertTrue(capturedAdditionalInfo.isI817Beneficiary());
    }

    @Test
    void shouldSetAdditionalInfoforConcurrentlyFiledI485A() throws IOException {
        String fileName = "fileName";
        String submissionId = UUID.randomUUID().toString();
        String baseUrl = "https://downloader.uscis.dhs.gov";

        ReflectionTestUtils.setField(service, "downloaderBaseUrl", baseUrl);
        UploadRequest uploadRequest = new UploadRequest(fileName, true, "type",
                Constants.MD5HASH, FormType.I485A.getType());
        S3FileInfo s3FileInfo = new S3FileInfo(formId, "checksum123", "artifactId", fileName);
        MockMultipartFile file = new MockMultipartFile(
                fileName,
                fileName,
                MediaType.MULTIPART_FORM_DATA_VALUE,
                "Hello, World!".getBytes());
        I485AEligibilityCategory eligibilityCategory = I485AEligibilityCategory.DERIVATIVE_BENEFICIARY_OF_IMMIGRANT_PETITION_01141998;

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .formType(FormType.I485)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485A.getType())
                        .formSpecificInfo(new I485AFormSpecificInfo(true, false, true))
                        .build()))
                .build();
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I485.getType())).thenReturn(true);
        when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class),
                any(UploadRequest.class))).thenReturn(s3FileInfo);

        service.updateSubmissionWithForm(submission, uploadRequest, file);
        ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);

        verify(sqsService).sendValidationRequest(valRequest.capture());
        ValidationRequest resultingRequest = valRequest.getValue();
        I485AAdditionalInformation capturedAdditionalInfo = (I485AAdditionalInformation) resultingRequest
                .additionalInfo();

        assertTrue(capturedAdditionalInfo.isI817Beneficiary());
    }

    @Test
    void shouldEsignForm() {
        String signature = "EsignSignature";
        EsignData esignData = EsignData.builder()
                .applicantFullName(signature)
                .build();

        final var submission = Submission.builder()
                .submissionId(submissionId)
                .status(SubmissionState.DRAFT)
                .myUscisId(myUscisId)
                .userRequestedPartialFeeWaiver(false)
                .forms(new ArrayList<>())
                .build();

        when(submissionDao.getDraftById(submission.getMyUscisId(), null, submission.getSubmissionId()))
                .thenReturn(Optional.of(submission));

        service.esignForm(myUscisId, null, submissionId, formId, esignData);

        ArgumentCaptor<Submission> subJail = ArgumentCaptor.forClass(Submission.class);
        verify(submissionDao).update(subJail.capture());

        assertNotNull(subJail.getValue().getAttestedAt());
        assertEquals(signature, subJail.getValue().getAttestationSignature());
    }

    @Test
    void testUpdateReasonForFilingH2A() {
        String reasonForFiling = RequestedAction.AMEND_STAY.toString();
        Submission submission = Submission.builder()
                .applicant(UserInformation.builder()
                        .userGroupId("O-MOCK")
                        .build())
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .formType(FormType.I129H2A)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .s3Key("mock-s3key")
                        .type(FormType.I129H2A.getType())
                        .build()))
                .eligibilityCategory(I129H2AEligibilityCategory.NEW_EMPLOYMENT)
                .userRequestedPartialFeeWaiver(false)
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getDraftById(myUscisId, orgMyUscisId, submissionId);
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I129H2A.getType())).thenReturn(true);

        service.updateReasonForFiling(submissionId, myUscisId, orgMyUscisId, reasonForFiling);

        ArgumentCaptor<ValidationRequest> validationRequestCaptor = ArgumentCaptor.forClass(ValidationRequest.class);
        verify(sqsService).sendValidationRequest(validationRequestCaptor.capture());
        ValidationRequest validationRequest = validationRequestCaptor.getValue();
        assertEquals("O-MOCK", validationRequest.userGroupId());
        assertNotNull(validationRequest.additionalInfo());
        I129H2AAdditionalInformation i129H2AAdditionalInformation = ((I129H2AAdditionalInformation) validationRequest
                .additionalInfo());
        assertEquals(RequestedAction.AMEND_STAY, i129H2AAdditionalInformation.getRequestedAction());
        verify(validationService).deleteStatus("mock-id");
        verify(auditService).addEvent(myUscisId, submissionId, ActionPerformed.SELECT_REASON_FOR_FILING,
                reasonForFiling);
        verify(submissionDao).update(submission);
        assertEquals(reasonForFiling, submission.getReasonForFiling());
    }

    @Test
    void createInitialSubmissionOrganization() {
        SubmissionRequest request = SubmissionRequest.builder()
                .accountType(AccountType.REGISTRANT)
                .formType(FormType.I129H2A)
                .clientInformation(Optional.empty())
                .build();
        UserGroupRole userGroupRole = UserGroupRole.builder()
                .userGroupId("O-mockUserGroupId")
                .build();
        doReturn(userGroupRole).when(userGroupServiceClient).getOrganizationGroupRole(myUscisId);

        service.createInitialSubmission(myUscisId, request);

        verify(userGroupServiceClient).getOrganizationGroupRole(myUscisId);
        ArgumentCaptor<Submission> submissionCaptor = ArgumentCaptor.forClass(Submission.class);
        verify(submissionDao).save(submissionCaptor.capture());

        Submission actual = submissionCaptor.getValue();

        assertEquals("O-mockUserGroupId", actual.getApplicant().getUserGroupId());

    }

    @Test
    void canPayAndSubmit_NonOrganizationalForm() {
        Submission submission = Submission.builder()
                .formType(FormType.I765)
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);

        assertTrue(service.canUserPayAndSubmit(myUscisId, submissionId));

    }

    @Test
    void canPayAndSubmit_Organizational_Representative() {
        Submission submission = Submission.builder()
                .formType(FormType.I129H2A)
                .build();
        AccountTypeResponse response = AccountTypeResponse.builder()
                .accountType(AccountType.REPRESENTATIVE)
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);
        doReturn(response).when(peepsService).retrieveAccountType(myUscisId);

        assertTrue(service.canUserPayAndSubmit(myUscisId, submissionId));
    }

    @Test
    void canPayAndSubmit_Organizational_Non_Admin() {
        Submission submission = Submission.builder()
                .formType(FormType.I129H2A)
                .build();
        AccountTypeResponse response = AccountTypeResponse.builder()
                .accountType(AccountType.REGISTRANT)
                .build();
        UserGroupRole userGroupRole = UserGroupRole.builder()
                .roles(List.of("user_group_org_member"))
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);
        doReturn(response).when(peepsService).retrieveAccountType(myUscisId);
        doReturn(userGroupRole).when(userGroupServiceClient).getOrganizationGroupRole(myUscisId);

        assertFalse(service.canUserPayAndSubmit(myUscisId, submissionId));
    }

    @Test
    void canPayAndSubmit_Organizational_Admin() {
        Submission submission = Submission.builder()
                .formType(FormType.I129H2A)
                .build();
        AccountTypeResponse response = AccountTypeResponse.builder()
                .accountType(AccountType.REGISTRANT)
                .build();
        UserGroupRole userGroupRole = UserGroupRole.builder()
                .roles(List.of("user_group_org_admin"))
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);
        doReturn(response).when(peepsService).retrieveAccountType(myUscisId);
        doReturn(userGroupRole).when(userGroupServiceClient).getOrganizationGroupRole(myUscisId);

        assertTrue(service.canUserPayAndSubmit(myUscisId, submissionId));
    }

    @Test
    void canPayAndSubmitApplicant() {
        Submission submission = Submission.builder()
                .formType(FormType.I907)
                .build();
        AccountTypeResponse response = AccountTypeResponse.builder()
                .accountType(AccountType.APPLICANT)
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);
        doReturn(response).when(peepsService).retrieveAccountType(myUscisId);

        assertTrue(service.canUserPayAndSubmit(myUscisId, submissionId));
    }

    @Test
    void canPayAndSubmitApplicantI140() {
        Submission submission = Submission.builder()
                .formType(FormType.I140)
                .build();
        AccountTypeResponse response = AccountTypeResponse.builder()
                .accountType(AccountType.APPLICANT)
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);
        doReturn(response).when(peepsService).retrieveAccountType(myUscisId);

        assertTrue(service.canUserPayAndSubmit(myUscisId, submissionId));
    }

    @Test
    void canPayAndSubmitRepresentativeI140() {
        Submission submission = Submission.builder()
                .formType(FormType.I140)
                .build();
        AccountTypeResponse response = AccountTypeResponse.builder()
                .accountType(AccountType.REPRESENTATIVE)
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);
        doReturn(response).when(peepsService).retrieveAccountType(myUscisId);

        assertTrue(service.canUserPayAndSubmit(myUscisId, submissionId));
    }

    @Test
    void canPayAndSubmit_Organizational_Non_Admin_I140() {
        Submission submission = Submission.builder()
                .formType(FormType.I140)
                .build();
        AccountTypeResponse response = AccountTypeResponse.builder()
                .accountType(AccountType.REGISTRANT)
                .build();
        UserGroupRole userGroupRole = UserGroupRole.builder()
                .roles(List.of("user_group_org_member"))
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);
        doReturn(response).when(peepsService).retrieveAccountType(myUscisId);
        doReturn(userGroupRole).when(userGroupServiceClient).getOrganizationGroupRole(myUscisId);

        assertFalse(service.canUserPayAndSubmit(myUscisId, submissionId));
    }

    @Test
    void canPayAndSubmit_Organizational_Admin_I140() {
        Submission submission = Submission.builder()
                .formType(FormType.I140)
                .build();
        AccountTypeResponse response = AccountTypeResponse.builder()
                .accountType(AccountType.REGISTRANT)
                .build();
        UserGroupRole userGroupRole = UserGroupRole.builder()
                .roles(List.of("user_group_org_admin"))
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);
        doReturn(response).when(peepsService).retrieveAccountType(myUscisId);
        doReturn(userGroupRole).when(userGroupServiceClient).getOrganizationGroupRole(myUscisId);

        assertTrue(service.canUserPayAndSubmit(myUscisId, submissionId));
    }

    @Test
    void getAdministrators_No_User_Group_Id() {
        Submission submission = Submission.builder()
                .formType(FormType.I129H2A)
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);

        assertTrue(service.getAdministrators("mock-myUscisId", submissionId).isEmpty());
    }

    @Test
    void getAdministratorsFromApplicantInformation() {
        Submission submission = Submission.builder()
                .formType(FormType.I129H2A)
                .applicant(UserInformation.builder()
                        .userGroupId("O-MOCK")
                        .build())
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);

        service.getAdministrators(myUscisId, submissionId);
        verify(accountsDataClient).getAdministrators(myUscisId, "O-MOCK");
    }

    @Test
    void getAdministratorsFromClientInformation() {
        String myUscisId = "mock-myUscisId";
        Submission submission = Submission.builder()
                .formType(FormType.I129H2A)
                .clientInformation(ClientInformation.builder()
                        .clientId("O-MOCK")
                        .build())
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);

        service.getAdministrators(myUscisId, submissionId);
        verify(accountsDataClient).getAdministrators(myUscisId, "O-MOCK");
    }

    @Test
    void getOrgId() {
        UserGroupRole userGroupRole = UserGroupRole.builder()
                .userGroupId("MOCK_USER_GROUP_ID")
                .build();

        doReturn(userGroupRole).when(userGroupServiceClient).getOrganizationGroupRole(myUscisId);

        assertTrue(service.getOrgId(myUscisId).equals("MOCK_USER_GROUP_ID"));
    }

    @Test
    void sendNotificationToAdministrator() {
        List<String> uuids = List.of("mock-uuid");
        Submission submission = Submission.builder()
                .formType(FormType.I129H2A)
                .clientInformation(ClientInformation.builder()
                        .clientId("O-MOCK")
                        .build())
                .build();

        doReturn(Optional.of(submission)).when(submissionDao).getById(submissionId);
        service.sendNotificationToAdministrator(myUscisId, submissionId, uuids);
        verify(accountsDataClient).notifyAdministrators(myUscisId, submissionId, uuids);
    }

    @Test
    void sendEvidenceValidationRequest() {
        String evidenceId = UUID.randomUUID().toString();
        SubmissionForm form = SubmissionForm.builder()
                .id(formId)
                .build();
        SubmissionEvidence evidence = SubmissionEvidence.builder()
                .id(evidenceId)
                .build();

        Submission sub = Submission.builder()
                .formType(i130FormType)
                .forms(List.of(form))
                .evidences(List.of(evidence))
                .build();

        PFVSEvidenceType evidenceType = PFVSEvidenceType.I912;
        I912AdditionalInformation additionalInfo = new I912AdditionalInformation(false);

        when(toggleService.isToggleActive(ToggleEnum.PFVS_I912, i130FormType.getType())).thenReturn(true);

        service.sendEvidencePFVSValidationRequest(sub, evidence, evidenceType, additionalInfo);

        ArgumentCaptor<ValidationRequest> requestJail = ArgumentCaptor.forClass(ValidationRequest.class);
        verify(sqsService).sendEvidenceValidationRequest(requestJail.capture());

        assertTrue(requestJail.getValue().evidenceIds().contains(evidenceId));
        assertTrue(requestJail.getValue().submissionFormIds().contains(formId));
        assertEquals(evidenceId, requestJail.getValue().formId());
        assertEquals(PFVSEvidenceType.I912.getType(), requestJail.getValue().formType());
    }

    @Test
    void pfvsEvidenceValidationRequestUsesFormTypeOverride() {
        String evidenceId = UUID.randomUUID().toString();
        SubmissionForm form = SubmissionForm.builder()
                .id(formId)
                .build();
        SubmissionEvidence evidence = SubmissionEvidence.builder()
                .id(evidenceId)
                .build();

        Submission sub = Submission.builder()
                .formType(i130FormType)
                .forms(List.of(form))
                .evidences(List.of(evidence))
                .build();

        PFVSEvidenceType evidenceType = PFVSEvidenceType.I797C;

        when(toggleService.isToggleActive(ToggleEnum.PFVS_797C, i130FormType.getType())).thenReturn(true);

        service.sendEvidencePFVSValidationRequest(sub, evidence, evidenceType, null);

        ArgumentCaptor<ValidationRequest> requestJail = ArgumentCaptor.forClass(ValidationRequest.class);
        verify(sqsService).sendEvidenceValidationRequest(requestJail.capture());

        assertTrue(requestJail.getValue().evidenceIds().contains(evidenceId));
        assertTrue(requestJail.getValue().submissionFormIds().contains(formId));
        assertEquals(evidenceId, requestJail.getValue().formId());
        assertEquals(PFVSEvidenceType.I797C.getPFVSFormTypeOverride(), requestJail.getValue().formType());
    }

    @Test
    void sendEvidenceValidationRequestNoForms() {
        String evidenceId = UUID.randomUUID().toString();
        SubmissionEvidence evidence = SubmissionEvidence.builder()
                .id(evidenceId)
                .build();

        Submission sub = Submission.builder()
                .formType(i130FormType)
                .evidences(List.of(evidence))
                .build();

        PFVSEvidenceType evidenceType = PFVSEvidenceType.I912;
        I912AdditionalInformation additionalInfo = new I912AdditionalInformation(false);

        when(toggleService.isToggleActive(ToggleEnum.PFVS_I912, i130FormType.getType())).thenReturn(true);

        service.sendEvidencePFVSValidationRequest(sub, evidence, evidenceType, additionalInfo);

        ArgumentCaptor<ValidationRequest> requestJail = ArgumentCaptor.forClass(ValidationRequest.class);
        verify(sqsService).sendEvidenceValidationRequest(requestJail.capture());

        assertTrue(requestJail.getValue().evidenceIds().contains(evidenceId));
        assertEquals(evidenceId, requestJail.getValue().formId());
        assertEquals(PFVSEvidenceType.I912.getType(), requestJail.getValue().formType());
    }

    @Nested
    class I751Tests {
        @Test
        public void shouldUpdateEligibilitySubcategoriesOfSameGroup() {
            I751WaiverOrIndividualFilingSubcategory divorceAnnulment = I751WaiverOrIndividualFilingSubcategory.DIVORCE_ANNULMENT;
            I751WaiverOrIndividualFilingSubcategory extremeHardship = I751WaiverOrIndividualFilingSubcategory.SPOUSE_DECEASED;
            Submission expected = Submission.builder()
                    .submissionId(submissionId)
                    .myUscisId(myUscisId)
                    .formType(i751FormType)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .eligibilityCategory(I751EligibilityCategory.WAIVER_OR_INDIVIDUAL_FILING)
                    .eligibilitySubcategories(List.of(divorceAnnulment, extremeHardship))
                    .forms(List.of(SubmissionForm.builder()
                            .id("mock-id")
                            .type(FormType.I751.getType())
                            .build()))
                    .build();

            EligibilityUpdateRequest request = new EligibilityUpdateRequest();
            request.setEligibilityCategory(I751EligibilityCategory.WAIVER_OR_INDIVIDUAL_FILING);
            request.setBenefitTypeCode(0);
            request.setApplicationReasonCode(0);
            request.setFormType(FormType.I751.getType());

            expected.setEligibilitySubcategories(List.of(divorceAnnulment, extremeHardship));

            var subrequest = EligibilitySubcategoriesUpdateRequest.builder()
                    .eligibilitySubcategories(List.of(divorceAnnulment, extremeHardship)).build();

            when(submissionDao.getDraftById(expected.getMyUscisId(), expected.getOrgMyUscisId(),
                    expected.getSubmissionId())).thenReturn(Optional.of(expected));

            service.updateEligibility(submissionId, myUscisId, null, request);

            service.updateEligibilitySubcategories(submissionId, myUscisId, null,
                    subrequest.getEligibilitySubcategories());

            ArgumentCaptor<Submission> captor = ArgumentCaptor.forClass(Submission.class);
            verify(submissionDao, times(2)).update(captor.capture());

            Submission actual = captor.getValue();
            assertTrue(actual.getUserIsEligibleForFeeWaiver());
            assertThat(actual.getEligibilitySubcategories()).isNotNull();
            assertThat(actual.getEligibilitySubcategories().size())
                    .isEqualTo(2);
            assertEquals(expected.getEligibilitySubcategories(), actual.getEligibilitySubcategories());
        }

        @Test
        public void shouldThrowABadExceptionWhenEligibilitySubcategoriesAreFromDifferentGroups() {
            I751WaiverOrIndividualFilingSubcategory divorceAnnulment = I751WaiverOrIndividualFilingSubcategory.DIVORCE_ANNULMENT;
            I751WaiverOrIndividualFilingSubcategory parentGoodFaithExtremeCruelty = I751WaiverOrIndividualFilingSubcategory.PARENT_GOOD_FAITH_EXTREME_CRUELTY;
            Submission expected = Submission.builder()
                    .submissionId(submissionId)
                    .myUscisId(myUscisId)
                    .formType(i751FormType)
                    .userRequestedFeeWaiver(false)
                    .userRequestedPartialFeeWaiver(false)
                    .eligibilityCategory(I751EligibilityCategory.WAIVER_OR_INDIVIDUAL_FILING)
                    .eligibilitySubcategories(List.of(divorceAnnulment, parentGoodFaithExtremeCruelty))
                    .build();

            expected.setEligibilitySubcategories(List.of(divorceAnnulment, parentGoodFaithExtremeCruelty));

            var request = EligibilitySubcategoriesUpdateRequest.builder()
                    .eligibilitySubcategories(List.of(divorceAnnulment, parentGoodFaithExtremeCruelty)).build();

                            // 1. Extract the method call that is not being tested
                    var subcategories = request.getEligibilitySubcategories();

                    // 2. Pass the pre-fetched variable into the lambda
                    assertThrows(SubmissionBadException.class, () ->
                        service.updateEligibilitySubcategories(submissionId, myUscisId, orgMyUscisId, subcategories)
                );
        }
    }

    @Test
    public void shouldRestSubmissionStatus() {

        Submission initial = Submission.builder()
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .status(SubmissionState.RECEIVED)
                .build();

        Submission expected = Submission.builder()
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .status(SubmissionState.DRAFT)
                .build();

        when(submissionDao.getById(anyString())).thenReturn(Optional.of(initial));
        when(submissionDao.update(any())).thenReturn(expected);
        Submission actual = service.resetSubmissionToDraft(submissionId);
        assertEquals(actual.getSubmissionId(), expected.getSubmissionId());
        assertEquals(actual.getStatus(), expected.getStatus());

    }

    @Test
    void shouldUpdateSubmissionWithFormSpecificInfoForI751() {
        EligibilityCategoryEnum eligibilityCategory = I751EligibilityCategory.MY_PARENT_SPOUSE;

        String submissionId = UUID.randomUUID().toString();
        FormSpecificInfo formSpecificInfo = new I751FormSpecificInfo(false);
        Submission expected = Submission.builder().myUscisId(myUscisId)
                .submissionId(submissionId)
                .eligibilityCategory(eligibilityCategory)
                .formType(FormType.I751)
                .formSpecificInfo(formSpecificInfo)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I751.getType())
                        .formSpecificInfo(formSpecificInfo)
                        .build()))
                .build();

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .formType(FormType.I751)
                .formSpecificInfo(new I751FormSpecificInfo(true))
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I751.getType())
                        .formSpecificInfo(formSpecificInfo)
                        .build()))
                .build();

        when(submissionDao.getById(submissionId)).thenReturn(Optional.of(submission));
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

        Submission actual = service.updateFormSpecificInfo(submissionId, formSpecificInfo);

        assertThat(actual, samePropertyValuesAs(expected));
    }

    @Test
    void shouldResetFormSpecificInfo() {
        EligibilityCategoryEnum eligibilityCategory = I140EligibilityCategory.PROFESSIONAL;
        String dolNumber = "G-100-12345-123456";
        FormSpecificInfo formSpecificInfo = new I140FormSpecificInfo(dolNumber, true);
        SubmissionEvidence evidence9089FD = SubmissionEvidence.builder().evidenceGroupType("labor-certification")
                .build();
        Submission expected = Submission.builder().myUscisId(myUscisId)
                .submissionId(submissionId)
                .eligibilityCategory(eligibilityCategory)
                .formType(FormType.I140)
                .formSpecificInfo(formSpecificInfo)
                .evidences(List.of(evidence9089FD))
                .build();

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .formType(FormType.I140)
                .evidences(List.of(evidence9089FD))
                .formSpecificInfo(new I140FormSpecificInfo("", false))
                .build();

        when(submissionDao.getById(submissionId)).thenReturn(Optional.of(submission));
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

        Submission actual = service.resetFormSpecificInfo(submissionId);
        assertTrue(actual.getFormSpecificInfo() == null);

    }

    @Test
    void shouldUpdateSubmissionWithFormSpecificInfoForI140() {
        EligibilityCategoryEnum eligibilityCategory = I140EligibilityCategory.PROFESSIONAL;

        String submissionId = UUID.randomUUID().toString();
        String dolNumber = "G-100-12345-123456";
        FormSpecificInfo formSpecificInfo = new I140FormSpecificInfo(dolNumber, true);
        SubmissionEvidence evidence9089FD = SubmissionEvidence.builder().evidenceGroupType("labor-certification")
                .build();
        Submission expected = Submission.builder().myUscisId(myUscisId)
                .submissionId(submissionId)
                .eligibilityCategory(eligibilityCategory)
                .formType(FormType.I140)
                .formSpecificInfo(formSpecificInfo)
                .evidences(List.of(evidence9089FD))
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I140.getType())
                        .formSpecificInfo(formSpecificInfo)
                        .build()))
                .build();

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .formType(FormType.I140)
                .evidences(List.of(evidence9089FD))
                .formSpecificInfo(new I140FormSpecificInfo("", false))
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I140.getType())
                        .formSpecificInfo(formSpecificInfo)
                        .build()))
                .build();

        when(submissionDao.getById(submissionId)).thenReturn(Optional.of(submission));
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

        Submission actual = service.updateFormSpecificInfo(submissionId, formSpecificInfo);

        assertThat(actual, samePropertyValuesAs(expected));
    }

    @Test
    void shouldTriggerPFVSValidationOnFormSpecificInfoUpdateForI485() {
        EligibilityCategoryEnum eligibilityCategory = I485EligibilityCategory.PRINCIPAL_APPLICANT;

        String submissionId = UUID.randomUUID().toString();
        FormSpecificInfo formSpecificInfo = new I485FormSpecificInfo(true, false, false);
        Submission expected = Submission.builder().myUscisId(myUscisId)
                .submissionId(submissionId)
                .eligibilityCategory(eligibilityCategory)
                .formType(FormType.I485)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485.getType())
                        .s3Key("mock-s3Key")
                        .formSpecificInfo(formSpecificInfo)
                        .build()))
                .formSpecificInfo(formSpecificInfo)
                .build();

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485.getType())
                        .s3Key("mock-s3Key")
                        .formSpecificInfo(formSpecificInfo)
                        .build()))
                .formType(FormType.I485)
                .formSpecificInfo(new I485FormSpecificInfo(true, false, false))
                .build();

        when(submissionDao.getById(submissionId)).thenReturn(Optional.of(submission));
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I485.getType())).thenReturn(true);

        Submission actual = service.updateFormSpecificInfo(submissionId, formSpecificInfo);

        assertThat(actual, samePropertyValuesAs(expected));

        ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);

        verify(sqsService).sendValidationRequest(valRequest.capture());

        ValidationRequest resultingRequest = valRequest.getValue();
        assertTrue(((I485AdditionalInformation) resultingRequest.additionalInfo()).isMilitaryVeteran());

        assertThat(actual, samePropertyValuesAs(expected, "forms", "updatedAt"));
        assertThat(actual.getForms(), hasSize(1));
        assertThat(actual.getForms().get(0),
                samePropertyValuesAs(expected.getForms().get(0), "uploadedAt"));
    }

    @Test
    void shouldTriggerPFVSValidationOnFormSpecificInfoUpdateForI485A() {
        EligibilityCategoryEnum eligibilityCategory = I485AEligibilityCategory.SPOUSE_OR_CHILD_OF_APPLICANT;

        String submissionId = UUID.randomUUID().toString();
        FormSpecificInfo formSpecificInfo = new I485AFormSpecificInfo(true, true, true);
        Submission expected = Submission.builder().myUscisId(myUscisId)
                .submissionId(submissionId)
                .eligibilityCategory(eligibilityCategory)
                .formType(FormType.I485A)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485A.getType())
                        .s3Key("mock-s3Key")
                        .formSpecificInfo(formSpecificInfo)
                        .build()))
                .formSpecificInfo(formSpecificInfo)
                .build();

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485A.getType())
                        .s3Key("mock-s3Key")
                        .formSpecificInfo(formSpecificInfo)
                        .build()))
                .formType(FormType.I485A)
                .formSpecificInfo(new I485AFormSpecificInfo(true, false, true))
                .build();

        when(submissionDao.getById(submissionId)).thenReturn(Optional.of(submission));
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I485A.getType())).thenReturn(true);

        Submission actual = service.updateFormSpecificInfo(submissionId, formSpecificInfo);

        assertThat(actual, samePropertyValuesAs(expected));

        ArgumentCaptor<ValidationRequest> valRequest = ArgumentCaptor.forClass(ValidationRequest.class);

        verify(sqsService).sendValidationRequest(valRequest.capture());

        ValidationRequest resultingRequest = valRequest.getValue();
        assertTrue(((I485AAdditionalInformation) resultingRequest.additionalInfo()).isI817Beneficiary());

        assertThat(actual, samePropertyValuesAs(expected, "forms", "updatedAt"));
        assertThat(actual.getForms(), hasSize(1));
        assertThat(actual.getForms().get(0),
                samePropertyValuesAs(expected.getForms().get(0), "uploadedAt"));
    }

    @Test
    void shouldNotTriggerPFVSValidationOnFormSpecificInfoUpdateForI485AWithEmptyForm() {
        EligibilityCategoryEnum eligibilityCategory = I140EligibilityCategory.PROFESSIONAL;

        String submissionId = UUID.randomUUID().toString();
        FormSpecificInfo formSpecificInfo = new I485AFormSpecificInfo(true, true, true);
        Submission expected = Submission.builder().myUscisId(myUscisId)
                .submissionId(submissionId)
                .eligibilityCategory(eligibilityCategory)
                .formType(FormType.I485A)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485A.getType())
                        .formSpecificInfo(formSpecificInfo)
                        .build()))
                .formSpecificInfo(formSpecificInfo)
                .build();

        Submission submission = Submission.builder().myUscisId(myUscisId)
                .eligibilityCategory(eligibilityCategory)
                .submissionId(submissionId)
                .forms(List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485A.getType())
                        .build()))
                .formType(FormType.I485A)
                .formSpecificInfo(new I485AFormSpecificInfo(true, false, true))
                .build();

        when(submissionDao.getById(submissionId)).thenReturn(Optional.of(submission));
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

        service.updateFormSpecificInfo(submissionId, formSpecificInfo);

        verifyNoInteractions(sqsService);
    }

    @Test
    void updateFormSpecificInformation_I765_No_SQS() {
        SubmissionForm submissionForm = SubmissionForm.builder()
                .type(FormType.I765.getType())
                .build();
        Submission submission = Submission.builder()
                .formType(FormType.I765)
                .forms(List.of(submissionForm))
                .build();
        I765FormSpecificInfo fsi = new I765FormSpecificInfo();
        fsi.setOnOrAfterApril012024(false);
        fsi.setBefore04012024(true);
        fsi.setFormType(FormType.I765);
        fsi.setImmvi(true);

        Submission actual = service.updateFormSpecificInfo(submission, fsi);

        assertNotNull(actual.getFormSpecificInfo());
        I765FormSpecificInfo actualFsi = (I765FormSpecificInfo) actual.getFormSpecificInfo();
        assertFalse(actualFsi.isOnOrAfterApril012024());
        assertTrue(actualFsi.isBefore04012024());
        assertTrue(actualFsi.isImmvi());
        SubmissionForm actualSubmissionForm = actual.getForms().getFirst();
        I765FormSpecificInfo actualSubmissionFsi = (I765FormSpecificInfo) actualSubmissionForm.getFormSpecificInfo();
        assertFalse(actualSubmissionFsi.isOnOrAfterApril012024());
        assertTrue(actualSubmissionFsi.isBefore04012024());
        assertTrue(actualSubmissionFsi.isImmvi());

        verifyNoInteractions(sqsService);
    }

    @Test
    void updateFormSpecificInformation_I765_SQS() {
        SubmissionForm submissionForm = SubmissionForm.builder()
                .id("mock-id")
                .s3Key("mock-s3-key")
                .type(FormType.I765.getType())
                .eligibilityCategory(I765EligibilityCategory.C9)
                .build();
        Submission submission = Submission.builder()
                .formType(FormType.I765)
                .forms(List.of(submissionForm))
                .eligibilityCategory(I765EligibilityCategory.C9)
                .userRequestedFeeWaiver(true)
                .build();
        I765FormSpecificInfo fsi = new I765FormSpecificInfo();
        fsi.setOnOrAfterApril012024(false);
        fsi.setBefore04012024(true);
        fsi.setFormType(FormType.I765);
        fsi.setImmvi(true);

        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I765.getType())).thenReturn(true);

        Submission actual = service.updateFormSpecificInfo(submission, fsi);

        assertNotNull(actual.getFormSpecificInfo());
        I765FormSpecificInfo actualFsi = (I765FormSpecificInfo) actual.getFormSpecificInfo();
        assertFalse(actualFsi.isOnOrAfterApril012024());
        assertTrue(actualFsi.isBefore04012024());
        assertTrue(actualFsi.isImmvi());
        SubmissionForm actualSubmissionForm = actual.getForms().getFirst();
        I765FormSpecificInfo actualSubmissionFsi = (I765FormSpecificInfo) actualSubmissionForm.getFormSpecificInfo();
        assertFalse(actualSubmissionFsi.isOnOrAfterApril012024());
        assertTrue(actualSubmissionFsi.isBefore04012024());
        assertTrue(actualSubmissionFsi.isImmvi());

        ArgumentCaptor<ValidationRequest> requestCaptor = ArgumentCaptor.forClass(ValidationRequest.class);
        verify(sqsService).sendValidationRequest(requestCaptor.capture());
        ValidationRequest actualRequest = requestCaptor.getValue();
        I765AdditionalInformation additionalInformation = ((I765AdditionalInformation) actualRequest.additionalInfo());
        assertFalse(additionalInformation.isOnOrAfterApril012024());
        assertTrue(additionalInformation.isBefore04012024());
        assertTrue(additionalInformation.isImmvi());
    }

    @Test
    void shouldRetrieveSubmissionStatusResponseWithErrorWhenEvidence9089FDIsMissing() {
        Submission submission = Submission.builder()
                .submissionId(UUID.randomUUID().toString())
                .eligibilityCategory(I140EligibilityCategory.PROFESSIONAL)
                .userRequestedFeeWaiver(false)
                .userRequestedPartialFeeWaiver(false)
                .formType(FormType.I140)
                .evidences(List.of())
                .formSpecificInfo(new I140FormSpecificInfo("G-100-12345-123456", true))
                .build();

        SubmissionStatusResponse expected = SubmissionStatusResponse
                .builder()
                .submissionErrors(List.of())
                .formErrors(List.of(
                        ErrorGroup.builder()
                                .type(i765FormType.getType())
                                .errors(List.of())
                                .build()))
                .evidenceErrors(
                        asList(ErrorGroup.builder()
                                .type("labor-certification")
                                .errors(List.of("Form ETA-9089 Final Determination is missing")).build()))
                .build();

        when(submissionDao.getDraftById(anyString(), anyString(), anyString()))
                .thenReturn(Optional.of(submission));
        SubmissionStatusResponse actual = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                submission.getSubmissionId());

        assertThat(actual, samePropertyValuesAs(expected, "formErrors", "submissionErrors"));

    }

    @Test
    void validateSubmission() {
        Submission submission = Submission.builder()
                .submissionId(submissionId)
                .forms(List.of(SubmissionForm.builder()
                        .type(FormType.I129H2A.getType())
                        .id("mock-id")
                        .build()))
                .formType(FormType.I129H2A)
                .reasonForFiling(RequestedAction.AMEND_STAY.name())
                .build();

        when(submissionDao.findBySubmissionIdAndUscisId(submissionId, myUscisId, null))
                .thenReturn(Optional.of(submission));
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I129H2A.getType())).thenReturn(true);

        service.validateSubmission(myUscisId, submissionId);

        verify(sqsService).sendValidationRequest(isA(ValidationRequest.class));
    }

    @Test
    void validateSubmissionNotPFVSSupported() {
        Submission submission = Submission.builder()
                .submissionId(submissionId)
                .forms(List.of(SubmissionForm.builder()
                        .type(FormType.I765.getType())
                        .build()))
                .formType(FormType.I765)
                .build();

        when(submissionDao.findBySubmissionIdAndUscisId(submissionId, myUscisId, null))
                .thenReturn(Optional.of(submission));

        service.validateSubmission(myUscisId, submissionId);

        verifyNoInteractions(sqsService);
    }

    @Nested
    @DisplayName("cleanupFeeWaiverForFeeExemptSubmission")
    class CleanupFeeWaiverForFeeExemptSubmissionTests {

        @Test
        @DisplayName("should cleanup fee waiver for I-485 form and set partial fee waiver to false")
        void shouldCleanupFeeWaiverForI485Form() {
            // given
            String submissionId = UUID.randomUUID().toString();
            String feeWaiverId = UUID.randomUUID().toString();
            String feeWaiverS3Key = UUID.randomUUID().toString();
            String supportDocId = UUID.randomUUID().toString();
            String supportDocS3Key = UUID.randomUUID().toString();

            SubmissionEvidence feeWaiver = SubmissionEvidence.builder()
                    .id(feeWaiverId)
                    .s3Key(feeWaiverS3Key)
                    .build();

            SubmissionEvidence supportDoc = SubmissionEvidence.builder()
                    .id(supportDocId)
                    .s3Key(supportDocS3Key)
                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                    .build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(FormType.I485)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeWaiver(feeWaiver)
                    .evidences(new ArrayList<>(List.of(supportDoc)))
                    .build();

            // when
            service.cleanupFeeWaiverForFeeExemptSubmission(submission);

            // then
            assertFalse(submission.getUserRequestedFeeWaiver());
            assertNull(submission.getFeeWaiver());
            assertTrue(submission.getEvidences().isEmpty());
            verify(s3Service, times(1)).deleteS3Object(feeWaiverS3Key, true);
            verify(s3Service, times(1)).deleteS3Object(supportDocS3Key, true);
        }

        @Test
        @DisplayName("should cleanup fee waiver for non-I-485 form without touching partial fee waiver")
        void shouldCleanupFeeWaiverForNonI485Form() {
            // given
            String submissionId = UUID.randomUUID().toString();
            String feeWaiverId = UUID.randomUUID().toString();
            String feeWaiverS3Key = UUID.randomUUID().toString();
            String supportDocId = UUID.randomUUID().toString();
            String supportDocS3Key = UUID.randomUUID().toString();

            SubmissionEvidence feeWaiver = SubmissionEvidence.builder()
                    .id(feeWaiverId)
                    .s3Key(feeWaiverS3Key)
                    .build();

            SubmissionEvidence supportDoc = SubmissionEvidence.builder()
                    .id(supportDocId)
                    .s3Key(supportDocS3Key)
                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                    .build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(FormType.I765)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeWaiver(feeWaiver)
                    .evidences(new ArrayList<>(List.of(supportDoc)))
                    .build();

            // when
            service.cleanupFeeWaiverForFeeExemptSubmission(submission);

            // then
            assertFalse(submission.getUserRequestedFeeWaiver());
            assertNull(submission.getFeeWaiver());
            assertTrue(submission.getEvidences().isEmpty());
            verify(s3Service, times(1)).deleteS3Object(feeWaiverS3Key, true);
            verify(s3Service, times(1)).deleteS3Object(supportDocS3Key, true);
        }

        @Test
        @DisplayName("should handle submission with no fee waiver gracefully")
        void shouldHandleSubmissionWithNoFeeWaiver() {
            // given
            String submissionId = UUID.randomUUID().toString();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(FormType.I485)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeWaiver(null)
                    .evidences(new ArrayList<>())
                    .build();

            // when
            service.cleanupFeeWaiverForFeeExemptSubmission(submission);

            // then
            assertFalse(submission.getUserRequestedFeeWaiver());
            assertNull(submission.getFeeWaiver());
            verify(s3Service, never()).deleteS3Object(anyString(), anyBoolean());
        }

        @Test
        @DisplayName("should only delete fee waiver evidence group documents, not other evidence")
        void shouldOnlyDeleteFeeWaiverEvidenceGroup() {
            // given
            String submissionId = UUID.randomUUID().toString();
            String feeWaiverId = UUID.randomUUID().toString();
            String feeWaiverS3Key = UUID.randomUUID().toString();
            String feeWaiverSupportDocId = UUID.randomUUID().toString();
            String feeWaiverSupportDocS3Key = UUID.randomUUID().toString();
            String otherEvidenceId = UUID.randomUUID().toString();
            String otherEvidenceS3Key = UUID.randomUUID().toString();

            SubmissionEvidence feeWaiver = SubmissionEvidence.builder()
                    .id(feeWaiverId)
                    .s3Key(feeWaiverS3Key)
                    .build();

            SubmissionEvidence feeWaiverSupportDoc = SubmissionEvidence.builder()
                    .id(feeWaiverSupportDocId)
                    .s3Key(feeWaiverSupportDocS3Key)
                    .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                    .build();

            SubmissionEvidence otherEvidence = SubmissionEvidence.builder()
                    .id(otherEvidenceId)
                    .s3Key(otherEvidenceS3Key)
                    .evidenceGroupType("passport")
                    .build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(FormType.I485)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeWaiver(feeWaiver)
                    .evidences(new ArrayList<>(List.of(feeWaiverSupportDoc, otherEvidence)))
                    .build();

            // when
            service.cleanupFeeWaiverForFeeExemptSubmission(submission);

            // then
            assertFalse(submission.getUserRequestedFeeWaiver());
            assertNull(submission.getFeeWaiver());
            assertEquals(1, submission.getEvidences().size());
            assertEquals(otherEvidenceId, submission.getEvidences().get(0).getId());
            verify(s3Service, times(1)).deleteS3Object(feeWaiverS3Key, true);
            verify(s3Service, times(1)).deleteS3Object(feeWaiverSupportDocS3Key, true);
            verify(s3Service, never()).deleteS3Object(otherEvidenceS3Key, true);
        }

        @Test
        @DisplayName("should handle S3 deletion failure gracefully")
        void shouldHandleS3DeletionFailure() {
            // given
            String submissionId = UUID.randomUUID().toString();
            String feeWaiverId = UUID.randomUUID().toString();
            String feeWaiverS3Key = UUID.randomUUID().toString();

            SubmissionEvidence feeWaiver = SubmissionEvidence.builder()
                    .id(feeWaiverId)
                    .s3Key(feeWaiverS3Key)
                    .build();

            Submission submission = Submission.builder()
                    .submissionId(submissionId)
                    .formType(FormType.I485)
                    .userRequestedFeeWaiver(true)
                    .userRequestedPartialFeeWaiver(true)
                    .feeWaiver(feeWaiver)
                    .evidences(new ArrayList<>())
                    .build();

            doThrow(new S3DeleteObjectException("S3 deletion failed"))
                    .when(s3Service).deleteS3Object(feeWaiverS3Key, true);

            // when
            service.cleanupFeeWaiverForFeeExemptSubmission(submission);

            // then
            assertFalse(submission.getUserRequestedFeeWaiver());
            assertNull(submission.getFeeWaiver()); // Should still be removed from submission even if S3 deletion fails
            verify(s3Service, times(1)).deleteS3Object(feeWaiverS3Key, true);
        }
    }

    @Test
    @DisplayName("should Update C9 Fee")
    void shouldUpdateC9Fee_PFVSEnabled() {
        // given
        C9Options c9Options = C9Options.builder().onOrAfterApril012024(true).build();
        C9UpdateRequest c9request = C9UpdateRequest.builder().isFeeWaiverEligible(true).options(c9Options).build();

        SubmissionForm form = SubmissionForm.builder().id("123").type(FormType.I765.getType())
                .build();

        Submission submission = Submission.builder()
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .orgMyUscisId(orgMyUscisId)
                .formType(FormType.I765)
                .eligibilityCategory(I765EligibilityCategory.C9)
                .userRequestedFeeWaiver(false)
                .userRequestedPartialFeeWaiver(false)
                .forms(List.of(form))
                .evidences(new ArrayList<>())
                .reasonForFiling("Initial")
                .build();

        // when
        when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(submission));
        when(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, submission.getFormType().getType()))
                .thenReturn(true);
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

        Submission actual = service.updateC9Fee(submissionId, myUscisId, orgMyUscisId, c9request);
        assertEquals(submission, actual);
    }

    @Test
    @DisplayName("should Update C9 Fee")
    void shouldUpdateC9Fee_PFVSDisabled() {
        // given
        C9Options c9Options = C9Options.builder().onOrAfterApril012024(true).build();
        C9UpdateRequest c9request = C9UpdateRequest.builder().isFeeWaiverEligible(true).options(c9Options).build();
        ExtractedFormEntries extractedData = ExtractedFormEntries.builder()
                .eligibilityCategory(I765EligibilityCategory.C9.getCategory()).isSalvadorianABCEligible(false)
                .reasonForFiling("Initial").build();
        SubmissionForm form = SubmissionForm.builder().id("123").extractedData(extractedData)
                .type(FormType.I765.getType())
                .build();

        Submission submission = Submission.builder()
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .orgMyUscisId(orgMyUscisId)
                .formType(FormType.I765)
                .eligibilityCategory(C9)
                .userRequestedFeeWaiver(false)
                .userRequestedPartialFeeWaiver(false)
                .forms(List.of(form))
                .evidences(new ArrayList<>())
                .build();

        // when
        when(submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)).thenReturn(Optional.of(submission));
        when(submissionDao.update(any(Submission.class))).thenAnswer(call -> call.getArgument(0));

        Submission actual = service.updateC9Fee(submissionId, myUscisId, orgMyUscisId, c9request);

        // then
        verify(auditService, times(1)).addEvent(submission.getMyUscisId(), submission.getSubmissionId(),
                ActionPerformed.SELECT_C9_OPTION, "");
        System.out.println("LOG" + submission.getC9updateRequest());
        assertThat(actual, samePropertyValuesAs(submission, "c9updateRequest"));
        assertEquals(submission, actual);
    }

    @Test
    @DisplayName("should Not Update C9 Fee For Non I765 Forms")
    void shouldUpdateC9Fee_NotSucceed() {
        C9Options c9Options = C9Options.builder().onOrAfterApril012024(true).build();
        C9UpdateRequest c9request = C9UpdateRequest.builder().isFeeWaiverEligible(true).options(c9Options).build();

        Submission submission = Submission.builder()
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .orgMyUscisId(orgMyUscisId)
                .formType(FormType.I485)
                .userRequestedFeeWaiver(false)
                .userRequestedPartialFeeWaiver(false)
                .forms(List.of())
                .evidences(new ArrayList<>())
                .build();

        when(submissionDao.getDraftById(submission.getMyUscisId(), submission.getOrgMyUscisId(),
                submission.getSubmissionId()))
                .thenReturn(Optional.of(submission));

        assertThrows(SubmissionBadException.class,
                () -> service.updateC9Fee(submission.getSubmissionId(), submission.getMyUscisId(),
                        submission.getOrgMyUscisId(), c9request));

    }

    @Test
    @DisplayName("Should successfully add evidence and trigger PFVS for generic form type")
    void updateSubmissionWithEvidence_Success_TriggersPFVS() {
        // Arrange
        String myUscisId = "user123";
        String submissionId = "sub456";
        String formType = "I-765";
        Integer appCode = 12345;
        Integer benefitCode = 54321;

        UploadEvidenceRequest request = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), "Form-797c")
                .set(field(UploadEvidenceRequest::type), "Form-797c")
                .create();
        S3FileInfo s3Info = Instancio.create(S3FileInfo.class);
        SubmissionForm form = Instancio.of(SubmissionForm.class)
                .set(field(SubmissionForm::getType), formType)
                .set(field(SubmissionForm::getId), formId)
                .set(field(SubmissionForm::getBenefitTypeCode), benefitCode)
                .set(field(SubmissionForm::getApplicationReasonCode), appCode)
                .create();
        form.setEligibilityCategory(I765EligibilityCategory.C11AFGHAN);

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getFormType), FormType.I765)
                .set(field(Submission::getForms), singletonList(form))
                .set(field(Submission::getEvidences), new ArrayList<>())
                .create();

        EvidenceGroup mockGroup = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getId), "form-i-797c")
                .set(field(EvidenceGroup::getEvidenceTypes), List.of(
                        EvidenceType.builder()
                                .id("Form-797c")
                                .name("Name")
                                .contentCategoryCode(123)
                                .build()))
                .create();

        when(submissionDao.getDraftById(myUscisId, null, submissionId)).thenReturn(Optional.of(submission));
        when(submissionDao.update(submission)).thenReturn(submission);
        when(toggleService.isToggleActive(ToggleEnum.PFVS_797C, "I-765")).thenReturn(true);
        when(formService.retrieveEvidenceGroup(eq(formType), anyString(), eq("Form-797c"))).thenReturn(mockGroup);

        // Act
        Submission result = service.updateSubmissionWithEvidence(myUscisId, null, submissionId, formId, request, s3Info,
                formType);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getEvidences().size());
        verify(submissionDao, times(2)).update(submission);

        ArgumentCaptor<ValidationRequest> requestCaptor = ArgumentCaptor.forClass(ValidationRequest.class);
        verify(sqsService).sendEvidenceValidationRequest(requestCaptor.capture());
        ValidationRequest capturedRequest = requestCaptor.getValue();

        assertNotNull(capturedRequest);
        assertEquals(appCode, capturedRequest.applicationReasonCode());
        assertEquals(benefitCode, capturedRequest.benefitTypeCode());
    }

    @Test
    @DisplayName("Should skip PFVS if evidence group is Fee Waiver")
    void updateSubmissionWithEvidence_SkipsPFVS_WhenFeeWaiver() {
        // Arrange
        UploadEvidenceRequest request = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), FEE_WAIVER_EVIDENCE_GROUP)
                .create();
        SubmissionForm form = Instancio.of(SubmissionForm.class)
                .set(field(SubmissionForm::getType), "I-765")
                .create();
        form.setEligibilityCategory(I765EligibilityCategory.C9);

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getForms), singletonList(form))
                .set(field(Submission::getEvidences), new ArrayList<>())
                .create();

        when(submissionDao.getDraftById(anyString(), any(), anyString())).thenReturn(Optional.of(submission));
        when(submissionDao.update(submission)).thenReturn(submission);

        // Act
        service.updateSubmissionWithEvidence("id", null, "sid", "fid", request, Instancio.create(S3FileInfo.class),
                "I-765");

        // Assert
        verify(formService, never()).retrieveEvidenceGroup(any(), any(), any());
        verify(sqsService, never()).sendEvidenceValidationRequest(any());
    }

    @Test
    @DisplayName("Should handle I-140 specific PFVS logic for non-Schedule A")
    void updateSubmissionWithEvidence_I140_NotScheduleA_SendsPFVS() {
        // Arrange
        String formType = FormType.I140.getType();
        UploadEvidenceRequest request = Instancio.create(UploadEvidenceRequest.class);
        S3FileInfo s3Info = Instancio.create(S3FileInfo.class);

        I140FormSpecificInfo i140Info = Instancio.of(I140FormSpecificInfo.class)
                .set(field(I140FormSpecificInfo::getIsScheduleA), false)
                .set(field(I140FormSpecificInfo::getDolNumber), "DOL123")
                .create();
        SubmissionForm form = Instancio.of(SubmissionForm.class)
                .set(field(SubmissionForm::getType), formType)
                .create();
        form.setEligibilityCategory(I140EligibilityCategory.ALIEN_APPLYING_FOR_NIW);

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getForms), singletonList(form))
                .set(field(Submission::getEvidences), new ArrayList<>())
                .create();

        submission.setFormSpecificInfo(i140Info);

        EvidenceGroup mockGroup = Instancio.create(EvidenceGroup.class);
        when(submissionDao.getDraftById(any(), any(), any())).thenReturn(Optional.of(submission));
        when(formService.retrieveEvidenceGroup(any(), any(), any())).thenReturn(mockGroup);
        when(submissionDao.update(submission)).thenReturn(submission);

        // Act
        service.updateSubmissionWithEvidence("id", null, "sid", "fid", request, s3Info, formType);

        // Assert
        verify(sqsService).sendEvidenceValidationRequest(any());
    }

    @Test
    void testCreateInitialSubmissionConcurrentAttorneyFiling() {
        SubmissionRequest request = SubmissionRequest.builder()
                .accountType(AccountType.REPRESENTATIVE)
                .formType(FormType.I140)
                .clientInformation(Optional.of(ClientInformation.builder()
                        .clientId("O-mock-client-id")
                        .name(new Name("Company", null, null))
                        .userGroupIds(List.of())
                        .build()))
                .concurrentForms(List.of(ConcurrentForm.builder()
                        .formType("I-131")
                        .clientInformation(Optional.of(ClientInformation.builder()
                                .clientId("mock-client-id")
                                .name(new Name("First", null, "Last"))
                                .build()))
                        .build()))
                .build();

        ClientAssociation clientAssociation = new ClientAssociation(true, "client-user-group-id");
        doReturn(clientAssociation).when(userGroupServiceClient).isClientAssociated(myUscisId, "O-mock-client-id");

        service.createInitialSubmission(myUscisId, request);

        ArgumentCaptor<Submission> submissionCaptor = ArgumentCaptor.forClass(Submission.class);
        verify(submissionDao).save(submissionCaptor.capture());

        Submission actual = submissionCaptor.getValue();
        SubmissionForm i140SF = actual.getForms()
                .stream()
                .filter(sf -> FormType.I140.getType().equals(sf.getType()))
                .findFirst()
                .orElse(null);
        assertNotNull(i140SF);
        assertEquals("O-mock-client-id", i140SF.getClientId());
        SubmissionForm i131SF = actual.getForms()
                .stream()
                .filter(sf -> FormType.I131.getType().equals(sf.getType()))
                .findFirst()
                .orElse(null);
        assertNotNull(i131SF);
        assertEquals("mock-client-id", i131SF.getClientId());
    }

    @Test
    void testGetSubmissionICAMUUIDs() {
        String applicantClientId = "applicant-client-uuid";
        String orgClientId = "org-client-uuid";
        SubmissionForm i485form = SubmissionForm.builder()
            .id("123")
            .type(FormType.I485.getType())
            .clientId(applicantClientId)
            .build();

        SubmissionForm i140form = SubmissionForm.builder()
            .id("124")
            .type(FormType.I140.getType())
            .clientId(orgClientId)
            .build();

        SubmissionForm i129E3Form = SubmissionForm.builder()
            .id("125")
            .type(FormType.I129E3.getType())
            .clientId(applicantClientId)
            .build();

        Submission submission = Submission.builder()
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .orgMyUscisId(orgMyUscisId)
                .formType(FormType.I485)
                .forms(List.of(i485form, i140form, i129E3Form))
                .evidences(new ArrayList<>())
                .build();

        Map<String, String> expectedMap = Map.of(
            "I-485", applicantClientId,
            "I-140", orgClientId,
            "I-129", applicantClientId
        );

        Map<String, String> actualMap = service.getSubmissionICAMUUIDs(submission);

        assertEquals(expectedMap, actualMap);
    }
    
    @Test
    void shouldSendSumbissionFormClientId() throws Exception {
    	Submission submission = Submission.builder()
    			.submissionId("mock-submission-id")
    			.formType(FormType.I485)
    			.forms(List.of(SubmissionForm.builder()
    						.id("mock-id-i140")
    						.clientId("i-1485-client-id")
    						.type(FormType.I485.getType())
    						.build(),
    					SubmissionForm.builder()
    						.id("mock-id-i130")
    						.clientId("i-130-client-id")
    						.type(FormType.I130.getType())
    						.build()))
    			.selectedConcurrentForms(List.of(FormType.I130))
    			.build();
    	UploadRequest uploadRequest = UploadRequest.builder()
    			.formType(FormType.I130.getType())
    			.build();
    	MultipartFile file = mock(MultipartFile.class);
    	S3FileInfo s3FileInfo = S3FileInfo.builder()
    			.id("mock-id-i130")
    			.checksum("mock-checksum")
    			.artifactId("mock-artifact-id")
    			.s3Key("mock-s3-key")
    			.build();
    	
    	doReturn(s3FileInfo).when(s3Service).uploadForm(eq(submission), isA(String.class), eq(file), eq(uploadRequest));
    	doReturn(submission).when(submissionDao).update(submission);
    	doReturn(true).when(toggleService).isToggleActive(ToggleEnum.PFVS_ENABLED, FormType.I485.getType());
    	
    	service.updateSubmissionWithForm(submission, uploadRequest, file);
    
    	ArgumentCaptor<ValidationRequest> validationRequestCaptor = ArgumentCaptor.forClass(ValidationRequest.class);
    	verify(sqsService).sendValidationRequest(validationRequestCaptor.capture());
    	assertEquals("i-130-client-id", validationRequestCaptor.getValue().clientUuid());
    }

}
