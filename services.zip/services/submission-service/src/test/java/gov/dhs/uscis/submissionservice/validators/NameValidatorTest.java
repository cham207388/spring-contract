package gov.dhs.uscis.submissionservice.validators;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.validation.name_extract.ClientName;
import gov.dhs.uscis.intake.models.validation.name_extract.NameExtract;
import gov.dhs.uscis.intake.models.validation.name_extract.NameValidationResult;
import gov.dhs.uscis.submissionservice.repository.NameExtractRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;


@ExtendWith(MockitoExtension.class)
public class NameValidatorTest {

    NameExtractRepository nameExtractRepository = mock(NameExtractRepository.class);
    ValidationStatusRepository statusRepository = mock(ValidationStatusRepository.class);
    SubmissionRepository submissionRepository  = mock(SubmissionRepository.class);
    NameValidator nameValidator = new NameValidator(nameExtractRepository, statusRepository, submissionRepository);

    String submissionId = UUID.randomUUID().toString();
    String formId = UUID.randomUUID().toString();
    String g28FormId = UUID.randomUUID().toString();
    FormType formType = FormType.I765;
    FormType g28FormType = FormType.G28;
    ClientName formClientName = ClientName.builder().givenName("Bob").familyName("Triboni").build();
    ClientName g28ClientName = ClientName.builder().givenName("Bob").familyName("Triboni").build();

    SubmissionForm g28 = SubmissionForm.builder().id(formId).build();
    SubmissionForm I765 = SubmissionForm.builder().id(g28FormId).build();
    Submission submission = Submission.builder().submissionId(submissionId).forms(List.of(g28, I765)).build();

    @BeforeEach
    void setUp() {
        reset(nameExtractRepository, statusRepository);
    }

    @Test
    public void shouldValidateWhenANameExtractAlreadyExists() {
        ClientName clientName = mock(ClientName.class);
        FormType formType = FormType.I765;

        NameValidationResult result = mock(NameValidationResult.class);
        when(result.getSubmissionId()).thenReturn(submissionId);
        when(result.getFormType()).thenReturn(formType.getType());
        when(result.getFormId()).thenReturn(formId);
        when(result.getClientName()).thenReturn(clientName);

        NameExtract existingNameExtract = mock(NameExtract.class);
        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.of(existingNameExtract));
        when(existingNameExtract.updateClientName(formType,
                clientName, formId)).thenReturn(existingNameExtract);
        when(existingNameExtract.hasAllNamesForValidation()).thenReturn(true);
        when(existingNameExtract.getClientNameOnG28()).thenReturn(clientName);
        when(existingNameExtract.getClientNameOnForm()).thenReturn(clientName);
        when(existingNameExtract.getSubmissionId()).thenReturn(submissionId);
        when(submissionRepository.getById(submissionId)).thenReturn(Optional.of(submission));

        nameValidator.validate(result);
        verify(nameExtractRepository).update(existingNameExtract);
        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(nameExtractRepository, times(0)).deleteBySubmissionId(submissionId);
        verify(statusRepository, times(2)).save(argThat(
                status -> status.getStatus() == ValidationResultEnum.PASS && status.getFailureReasons().isEmpty()));
    }

    @Test
    public void shouldDeleteClientNameWhenDocumentDoesNotExist_G28MissingSubmissionForm() {
        FormType formType = FormType.I765;
        FormType g28FormType = FormType.G28;
        ClientName formClientName = ClientName.builder().givenName("Bob").familyName("Triboni").build();
        ClientName g28ClientName = ClientName.builder().givenName("Bob").familyName("Triboni").build();

        SubmissionForm I765 = SubmissionForm.builder().id(formId).build();

        Submission submission = Submission.builder().submissionId(submissionId).forms(List.of(I765)).build();

        NameValidationResult result = NameValidationResult.builder().submissionId(submissionId).formType(formType.getType()).formId(formId).clientName(formClientName).build();

        NameExtract existingNameExtract = NameExtract.builder()
                .submissionId(submissionId)
                .g28FormId(g28FormId)
                .form(g28FormType)
                .clientNameOnG28(g28ClientName)
                .build();

        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.of(existingNameExtract));
        when(submissionRepository.getById(submissionId)).thenReturn(Optional.of(submission));

        nameValidator.validate(result);
        verify(nameExtractRepository).update(existingNameExtract);
        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(nameExtractRepository, times(0)).deleteBySubmissionId(submissionId);
        verify(statusRepository, times(1)).save(any());
    }

    @Test
    public void shouldCreateNewEntryWhenOneNotExistsAndClientInformationIsFound_I765() {
        ClientName clientName = Instancio.create(ClientName.class);
        FormType formType = FormType.I765;

        NameValidationResult result = NameValidationResult.builder().submissionId(submissionId).formId(formId)
                .formType(formType.getType()).clientName(clientName).build();

        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.empty());
        when(nameExtractRepository.save(any())).thenAnswer(i -> i.getArguments()[0]);

        nameValidator.validate(result);

        ArgumentCaptor<NameExtract> captor = ArgumentCaptor.forClass(NameExtract.class);
        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(nameExtractRepository, times(1)).save(captor.capture());

        verify(statusRepository, times(1)).save(ValidationStatus.builder().submissionId(submissionId)
                .formId(formId)
                .isMultipart(true)
                .validator(ValidatorEnum.G28_COMP_NAME)
                .status(ValidationResultEnum.PENDING)
                .failureReasons(Collections.emptyList()).build());

        NameExtract savedName = captor.getValue();

        assertThat(savedName.getSubmissionId()).isEqualTo(submissionId);
        assertThat(savedName.getFormId()).isEqualTo(formId);
        assertThat(savedName.getG28FormId()).isNull();
        assertThat(savedName.getClientNameOnG28()).isNull();
        assertThat(savedName.getClientNameOnForm()).isEqualTo(clientName);
    }

    @Test
    public void shouldCreateNewEntryWhenOneNotExistsAndClientInformationIsFound_G28() {
        ClientName clientName = Instancio.create(ClientName.class);
        FormType formType = FormType.G28;

        NameValidationResult result = NameValidationResult.builder().submissionId(submissionId).formId(formId)
                .formType(formType.getType()).clientName(clientName).build();

        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.empty());
        when(nameExtractRepository.save(any())).thenAnswer(i -> i.getArguments()[0]);

        nameValidator.validate(result);

        ArgumentCaptor<NameExtract> captor = ArgumentCaptor.forClass(NameExtract.class);
        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(nameExtractRepository, times(1)).save(captor.capture());

        verify(statusRepository, times(1)).save(ValidationStatus.builder().submissionId(submissionId)
                .formId(formId)
                .isMultipart(true)
                .validator(ValidatorEnum.G28_COMP_NAME)
                .status(ValidationResultEnum.PENDING)
                .failureReasons(Collections.emptyList()).build());

        NameExtract savedName = captor.getValue();

        assertThat(savedName.getSubmissionId()).isEqualTo(submissionId);
        assertThat(savedName.getFormId()).isNull();
        assertThat(savedName.getG28FormId()).isEqualTo(formId);
        assertThat(savedName.getClientNameOnForm()).isNull();
        assertThat(savedName.getClientNameOnG28()).isEqualTo(clientName);
    }

    @Test
    public void shouldCreateNewEntryWhenOneNotExistsAndSaveFailedStatusWhenFamilyNameIsNotFound() {
        ClientName clientName = mock(ClientName.class);
        FormType formType = FormType.I765;

        NameValidationResult result = mock(NameValidationResult.class);
        NameExtract nameExtract = mock(NameExtract.class);

        when(result.getSubmissionId()).thenReturn(submissionId);
        when(result.getFormId()).thenReturn(formId);
        when(result.getFormType()).thenReturn(formType.getType());
        when(result.getClientName()).thenReturn(clientName);
        when(clientName.getFamilyName()).thenReturn(null);
        when(nameExtractRepository.save(any())).thenReturn(nameExtract);

        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.empty());

        nameValidator.validate(result);

        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(nameExtractRepository, times(1)).save(any());
        verify(statusRepository, times(1)).save(ValidationStatus.builder().submissionId(submissionId)
                .formId(formId)
                .isMultipart(true)
                .validator(ValidatorEnum.G28_COMP_NAME)
                .status(ValidationResultEnum.FAIL)
                .failureReasons(List.of(NameValidator.MISSING_FAILURE_MESSAGE)).build());
    }

    @Test
    public void shouldCreateNewEntryWhenOneNotExistsAndSaveFailedStatusWhenGivenNameIsNotFound() {
        ClientName clientName = mock(ClientName.class);
        FormType formType = FormType.I765;

        NameValidationResult result = mock(NameValidationResult.class);
        NameExtract nameExtract = mock(NameExtract.class);

        when(result.getSubmissionId()).thenReturn(submissionId);
        when(result.getFormId()).thenReturn(formId);
        when(result.getFormType()).thenReturn(formType.getType());
        when(result.getClientName()).thenReturn(clientName);
        when(clientName.getFamilyName()).thenReturn("Family");
        when(clientName.getGivenName()).thenReturn(null);
        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.empty());
        when(nameExtractRepository.save(any())).thenReturn(nameExtract);

        nameValidator.validate(result);

        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(nameExtractRepository, times(1)).save(any());
        verify(statusRepository, times(1)).save(ValidationStatus.builder().submissionId(submissionId)
                .formId(formId)
                .isMultipart(true)
                .validator(ValidatorEnum.G28_COMP_NAME)
                .status(ValidationResultEnum.FAIL)
                .failureReasons(List.of(NameValidator.MISSING_FAILURE_MESSAGE)).build());
    }

    @Test
    public void shouldReturnFailingStatusWhenNamesNotMatch() {
        FormType formType = FormType.I765;

        ClientName clientNameOnForm = mock(ClientName.class);
        ClientName clientNameOnG28 = mock(ClientName.class);
        NameValidationResult result = mock(NameValidationResult.class);
        NameExtract existingNameExtract = mock(NameExtract.class);

        when(result.getSubmissionId()).thenReturn(submissionId);
        when(result.getFormType()).thenReturn(formType.getType());
        when(result.getClientName()).thenReturn(clientNameOnForm);

        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.of(existingNameExtract));
        when(submissionRepository.getById(submissionId)).thenReturn(Optional.of(submission));

        when(existingNameExtract.hasAllNamesForValidation()).thenReturn(true);
        when(existingNameExtract.getClientNameOnG28()).thenReturn(clientNameOnG28);
        when(existingNameExtract.getClientNameOnForm()).thenReturn(clientNameOnForm);
        when(existingNameExtract.getSubmissionId()).thenReturn(submissionId);

        nameValidator.validate(result);

        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(statusRepository, times(2)).save(argThat(status -> status.getStatus() == ValidationResultEnum.FAIL
                && status.getFailureReasons()
                        .contains(NameValidator.DEFAULT_FAILURE_MESSAGE)));
    }

    @Test
    public void shouldSetStatusAsPassingForBothForms() {
        ClientName clientName = Instancio.create(ClientName.class);
        FormType formType = FormType.I765;

        NameValidationResult g28Result = NameValidationResult.builder().submissionId(submissionId)
                .formId(g28FormId)
                .formType(FormType.G28.getType()).clientName(clientName).build();

        NameExtract existing = NameExtract.builder().submissionId(submissionId).form(formType)
                .formId(formId).clientNameOnForm(clientName).build();
        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.of(existing));
        when(nameExtractRepository.save(any())).thenAnswer(i -> i.getArguments()[0]);
        when(submissionRepository.getById(submissionId)).thenReturn(Optional.of(submission));

        nameValidator.validate(g28Result);

        ArgumentCaptor<NameExtract> nameExtractCaptor = ArgumentCaptor.forClass(NameExtract.class);
        ArgumentCaptor<ValidationStatus> statusCaptor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(nameExtractRepository, times(1)).update(nameExtractCaptor.capture());
        verify(statusRepository, times(2)).save(statusCaptor.capture());

        NameExtract savedName = nameExtractCaptor.getValue();

        assertThat(savedName.getSubmissionId()).isEqualTo(submissionId);
        assertThat(savedName.getFormId()).isEqualTo(existing.getFormId());
        assertThat(savedName.getG28FormId()).isEqualTo(g28Result.getFormId());
        assertThat(savedName.getClientNameOnForm()).isEqualTo(clientName);
        assertThat(savedName.getClientNameOnG28()).isEqualTo(clientName);
        assertThat(savedName.getForm()).isEqualTo(formType);

        List<ValidationStatus> statuses = statusCaptor.getAllValues();
        assertThat(statuses).hasSize(2);
        assertThat(statuses).contains(
                ValidationStatus.builder().submissionId(submissionId)
                        .formId(existing.getFormId())
                        .isMultipart(true)
                        .validator(ValidatorEnum.G28_COMP_NAME)
                        .status(ValidationResultEnum.PASS)
                        .failureReasons(Collections.emptyList()).build(),
                ValidationStatus.builder().submissionId(submissionId)
                        .formId(g28Result.getFormId())
                        .isMultipart(true)
                        .validator(ValidatorEnum.G28_COMP_NAME)
                        .status(ValidationResultEnum.PASS)
                        .failureReasons(Collections.emptyList()).build());
    }

    @Test
    public void shouldSetStatusAsFailingForBothFormsWithRespectiveErrorMessageForBlankG28() {
        ClientName clientNameI765 = Instancio.create(ClientName.class);
        ClientName clientNameG28 = ClientName.builder().build();
        FormType formType = FormType.I765;

        NameValidationResult g28Result = NameValidationResult.builder().submissionId(submissionId)
                .formId(g28FormId)
                .formType(FormType.G28.getType()).clientName(clientNameG28).build();

        NameExtract existing = NameExtract.builder().submissionId(submissionId).form(formType)
                .formId(formId).clientNameOnForm(clientNameI765).build();
        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.of(existing));
        when(nameExtractRepository.save(any())).thenAnswer(i -> i.getArguments()[0]);
        when(submissionRepository.getById(submissionId)).thenReturn(Optional.of(submission));

        nameValidator.validate(g28Result);

        ArgumentCaptor<NameExtract> nameExtractCaptor = ArgumentCaptor.forClass(NameExtract.class);
        ArgumentCaptor<ValidationStatus> statusCaptor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(nameExtractRepository, times(1)).update(nameExtractCaptor.capture());
        verify(statusRepository, times(2)).save(statusCaptor.capture());

        NameExtract savedName = nameExtractCaptor.getValue();

        assertThat(savedName.getSubmissionId()).isEqualTo(submissionId);
        assertThat(savedName.getFormId()).isEqualTo(existing.getFormId());
        assertThat(savedName.getG28FormId()).isEqualTo(g28Result.getFormId());
        assertThat(savedName.getClientNameOnForm()).isEqualTo(clientNameI765);
        assertThat(savedName.getClientNameOnG28()).isEqualTo(clientNameG28);
        assertThat(savedName.getForm()).isEqualTo(formType);

        List<ValidationStatus> statuses = statusCaptor.getAllValues();
        assertThat(statuses).hasSize(2);
        assertThat(statuses).contains(
                ValidationStatus.builder().submissionId(submissionId)
                        .formId(g28Result.getFormId())
                        .isMultipart(true)
                        .validator(ValidatorEnum.G28_COMP_NAME)
                        .status(ValidationResultEnum.FAIL)
                        .failureReasons(List.of(NameValidator.MISSING_FAILURE_MESSAGE)).build());
        assertThat(statuses).contains(
                ValidationStatus.builder().submissionId(submissionId)
                        .formId(existing.getFormId())
                        .isMultipart(true)
                        .validator(ValidatorEnum.G28_COMP_NAME)
                        .status(ValidationResultEnum.FAIL)
                        .failureReasons(List.of(NameValidator.DEFAULT_FAILURE_MESSAGE)).build());
    }

    @Test
    public void shouldSetStatusAsFailingForBothFormsWithRespectiveErrorMessageWhenTheExistingNameWasMatchingForBlank765() {
        ClientName clientNameI765 = ClientName.builder().build();
        ClientName clientNameG28 = Instancio.create(ClientName.class);
        FormType formType = FormType.I765;

        NameValidationResult i765Result = NameValidationResult.builder().submissionId(submissionId)
                .formId(formId)
                .formType(FormType.I765.getType()).clientName(clientNameI765).build();

        NameExtract existing = NameExtract.builder().submissionId(submissionId).form(formType)
                .g28FormId(g28FormId).formId(formId).clientNameOnForm(clientNameG28).clientNameOnG28(clientNameG28).build();
        when(nameExtractRepository.getBySubmissionId(submissionId)).thenReturn(Optional.of(existing));
        when(nameExtractRepository.save(any())).thenAnswer(i -> i.getArguments()[0]);
        when(submissionRepository.getById(submissionId)).thenReturn(Optional.of(submission));


        nameValidator.validate(i765Result);

        ArgumentCaptor<NameExtract> nameExtractCaptor = ArgumentCaptor.forClass(NameExtract.class);
        ArgumentCaptor<ValidationStatus> statusCaptor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(nameExtractRepository).getBySubmissionId(submissionId);
        verify(nameExtractRepository, times(1)).update(nameExtractCaptor.capture());
        verify(statusRepository, times(2)).save(statusCaptor.capture());

        NameExtract savedName = nameExtractCaptor.getValue();

        assertThat(savedName.getSubmissionId()).isEqualTo(submissionId);
        assertThat(savedName.getFormId()).isEqualTo(i765Result.getFormId());
        assertThat(savedName.getG28FormId()).isEqualTo(existing.getG28FormId());
        assertThat(savedName.getClientNameOnForm()).isEqualTo(clientNameI765);
        assertThat(savedName.getClientNameOnG28()).isEqualTo(clientNameG28);
        assertThat(savedName.getForm()).isEqualTo(formType);

        List<ValidationStatus> statuses = statusCaptor.getAllValues();
        assertThat(statuses).hasSize(2);
        assertThat(statuses).contains(
                ValidationStatus.builder().submissionId(submissionId)
                        .formId(i765Result.getFormId())
                        .isMultipart(true)
                        .validator(ValidatorEnum.G28_COMP_NAME)
                        .status(ValidationResultEnum.FAIL)
                        .failureReasons(List.of(NameValidator.MISSING_FAILURE_MESSAGE)).build());
        assertThat(statuses).contains(
                ValidationStatus.builder().submissionId(submissionId)
                        .formId(existing.getG28FormId())
                        .isMultipart(true)
                        .validator(ValidatorEnum.G28_COMP_NAME)
                        .status(ValidationResultEnum.FAIL)
                        .failureReasons(List.of(NameValidator.DEFAULT_FAILURE_MESSAGE)).build());
    }

}
