package gov.dhs.uscis.submissionservice;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Duration;
import static java.util.Arrays.asList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static org.awaitility.Awaitility.await;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.reactive.server.WebTestClient.ResponseSpec;
import org.springframework.test.web.servlet.client.MockMvcWebTestClient;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.reactive.function.BodyInserters;
import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.containers.localstack.LocalStackContainer.Service;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;
import org.testcontainers.utility.MountableFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static com.github.tomakehurst.wiremock.client.WireMock.aMultipart;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.binaryEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.ok;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import com.github.tomakehurst.wiremock.junit5.WireMockExtension;

import gov.dhs.uscis.intake.daos.AuditDAO;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import static gov.dhs.uscis.intake.entities.audit.ActionPerformed.SIGNATURE_DETECTED;
import static gov.dhs.uscis.intake.entities.audit.ActionPerformed.SIGNATURE_NOT_DETECTED;
import gov.dhs.uscis.intake.entities.audit.Audit;
import gov.dhs.uscis.intake.entities.audit.Audit.Event;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.PASS;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.SIGNATURE;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.intake.models.UpdateSubmissionResponse;
import gov.dhs.uscis.intake.models.UploadResponse;
import gov.dhs.uscis.intake.models.dto.SubmissionDto;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResult;
import gov.dhs.uscis.submissionservice.models.UpdateEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceResponse;
import gov.dhs.uscis.submissionservice.models.dto.AttestFormRequest;
import gov.dhs.uscis.submissionservice.models.dto.C9FeeUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.EligibilityUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.FeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.dto.ImmviUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.PartialFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.dto.ReasonForFilingUpdateRequest;
import gov.dhs.uscis.submissionservice.models.myUscis.draftBenefits.ApplicantFileableFormsData;
import gov.dhs.uscis.submissionservice.models.myUscis.draftBenefits.ApplicantFileableFormsResponse;
import gov.dhs.uscis.submissionservice.repository.ClientInformationRepository;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.services.DraftBenefitsService;
import gov.dhs.uscis.submissionservice.services.LockboxGatewayClient;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import static software.amazon.awssdk.auth.credentials.StaticCredentialsProvider.create;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.ListObjectsRequest;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.GetQueueAttributesRequest;
import software.amazon.awssdk.services.sqs.model.QueueAttributeName;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;

@Testcontainers
@Slf4j
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
public abstract class BaseJourneyTest {

    private static final DockerImageName localstackImage = DockerImageName
            .parse("nexus-nonprod-gss.uscis.dhs.gov:8132/localstack/localstack:3.4")
            .asCompatibleSubstituteFor("localstack/localstack");
    protected final String MYUSCIS_ID = UUID.randomUUID().toString();
    protected static final String FORM_BUCKET = "form-staging";
    protected static final String EVIDENCE_BUCKET = "evidence";
    protected static final String VALIDATION_QUEUE = "validation-results";
    protected static final String ELIS_VALIDATION_RESULT_QUEUE = "elis-validation-results";
    protected static final String ELIS_VALIDATION_REQUEST_QUEUE = "elis-validation-request";
    protected static final String ELIS_EVIDENCE_VALIDATION_RESULT_QUEUE = "elis-evidence-validation-results";
    protected static final String ELIS_EVIDENCE_VALIDATION_REQUEST_QUEUE = "elis-evidence-validation-request";
    protected static final String FIELD_VALIDATION_QUEUE = "field-validation-results";
    protected static final String ELIGIBILITY_VALIDATION_QUEUE = "eligibility-validation-results";
    protected static final String NAME_VALIDATION_QUEUE = "name-validation-results";
    protected static final String ADDRESS_VALIDATION_QUEUE = "address-validation-results";
    protected static final String PERSON_VALIDATION_QUEUE = "person-validation-results";
    protected static final String CLIENT_NAME_EMAIL_VALIDATION_QUEUE = "profile-validation-results";
    protected static final String ATTORNEY_NAME_VALIDATION_QUEUE = "attorney-name-validation-results";
    protected static final String I912_VALIDATION_QUEUE = "i912-validation-results";
    protected static final String REPLAY_SUBMISSION_QUEUE = "replay-submission-request";

    protected WebTestClient client;
    @Autowired
    private WebApplicationContext applicationContext;
    @Autowired
    protected Clock clock;
    @Autowired
    protected ObjectMapper mapper;
    @Autowired
    protected S3Client s3Client;
    @Autowired
    protected ClientInformationRepository clientInformationRepository;
    @Autowired
    protected SubmissionRepository submissionDAO;
    @Autowired
    protected LockboxGatewayClient lockboxGatewayClient;
    @Autowired
    private SqsClient sqsClient;
    @Autowired
    protected DraftBenefitsService draftBenefitsService;

    @Value("${uscis.dynamodb.prefix}")
    private String tablePrefix;

    private DynamoDbClient rawClient;
    private DynamoDbTable<Audit> table;
    private String tableName;
    private AuditDAO auditDAO;
    @LocalServerPort
    private int port;

    @Container
    @SuppressWarnings("resource")
    private static final LocalStackContainer container = new LocalStackContainer(localstackImage)
            .withCopyFileToContainer(MountableFile.forHostPath("init-aws-local.sh"),
                    "/etc/localstack/init/ready.d/1.init-aws-local.sh")
            .withCopyFileToContainer(MountableFile.forHostPath("init-seed-metadata.sh"),
                    "/etc/localstack/init/ready.d/2.init-seed-metadata.sh")

            .withCopyFileToContainer(MountableFile.forHostPath("db_seed_script.sh"), "/usr/local/bin/db_seed_script.sh")
            .withCopyFileToContainer(MountableFile.forHostPath("_db_metadata/forms"), "/opt/_db_metadata/forms")

            .withEnv("DEBUG", "1")
            .withStartupAttempts(10)
            .withServices(
                    Service.S3,
                    Service.SQS,
                    Service.DYNAMODB)
            .waitingFor(Wait.forLogMessage(".*SEEDING METADATA COMPLETE.*", 1));

    @RegisterExtension
    protected static WireMockExtension server = WireMockExtension.newInstance()
            .options(wireMockConfig().dynamicPort()).build();

    @DynamicPropertySource
    static void applicationProperties(DynamicPropertyRegistry registry) {
        registry.add("uscis.sqs.fixedDelay", () -> 1);
        registry.add("uscis.sqs.initialDelay", () -> 1);
        registry.add("uscis.elis.enable", () -> true);
        registry.add("uscis.elis.baseUrl", () -> "http://localhost:" + server.getPort());
        registry.add("uscis.lockbox.baseUrl", () -> "http://localhost:" + server.getPort());

        // update this.
        registry.add("uscis.draftbenefits.url", () -> "http://localhost:" + server.getPort());

        registry.add("uscis.dynamodb.endpoint", container::getEndpoint);
        registry.add("uscis.s3.endpoint", container::getEndpoint);
        registry.add("uscis.sqs.endpoint", container::getEndpoint);
        registry.add("uscis.s3.buckets.form", () -> FORM_BUCKET);
        registry.add("uscis.s3.buckets.evidence", () -> EVIDENCE_BUCKET);
        registry.add("uscis.payments.baseUrl", () -> "http://localhost:" + server.getPort());
        // TOTOD uncomment when enabling PFVS
        registry.add("uscis.sqs.validation.elisRequest.queueUrl",
        () -> container.getEndpoint().toString() + "/000000000000/" + ELIS_VALIDATION_REQUEST_QUEUE);
        registry.add("uscis.sqs.validation.elisResponse.queueUrl",
        () -> container.getEndpoint().toString() + "/000000000000/" + ELIS_VALIDATION_RESULT_QUEUE);

        registry.add("uscis.sqs.evidence.validation.elisRequest.queueUrl",
        () -> container.getEndpoint().toString() + "/000000000000/" + ELIS_EVIDENCE_VALIDATION_REQUEST_QUEUE);
        registry.add("uscis.sqs.evidence.validation.elisResponse.queueUrl",
        () -> container.getEndpoint().toString() + "/000000000000/" + ELIS_EVIDENCE_VALIDATION_RESULT_QUEUE);
        
        registry.add("uscis.sqs.validation.queueUrl",
                () -> container.getEndpoint().toString() + "/000000000000/" + VALIDATION_QUEUE);
        registry.add("uscis.sqs.validation.field.queueUrl",
                () -> container.getEndpoint().toString() + "/000000000000/" + FIELD_VALIDATION_QUEUE);
        registry.add("uscis.sqs.validation.eligibility.queueUrl",
                () -> container.getEndpoint().toString() + "/000000000000/" + ELIGIBILITY_VALIDATION_QUEUE);
        registry.add("uscis.sqs.validation.name.queueUrl",
                () -> container.getEndpoint().toString() + "/000000000000/" + NAME_VALIDATION_QUEUE);
        registry.add("uscis.sqs.validation.name.queueUrl",
                () -> container.getEndpoint().toString() + "/000000000000/" + ADDRESS_VALIDATION_QUEUE);
        registry.add("uscis.sqs.validation.attorneyName.queueUrl",
                () -> container.getEndpoint().toString() + "/000000000000/" + ATTORNEY_NAME_VALIDATION_QUEUE);
        registry.add("uscis.sqs.validation.person.queueUrl",
                () -> container.getEndpoint().toString() + "/000000000000/" + PERSON_VALIDATION_QUEUE);
        registry.add("uscis.sqs.validation.i912.queueUrl",
                () -> container.getEndpoint().toString() + "/000000000000/" + I912_VALIDATION_QUEUE);
        registry.add("uscis.sqs.validation.clientNameEmail.queueUrl",
                () -> container.getEndpoint().toString() + "/000000000000/" + CLIENT_NAME_EMAIL_VALIDATION_QUEUE);
        registry.add("uscis.sqs.validation.submission.queueUrl",
                () -> REPLAY_SUBMISSION_QUEUE);
    }

    @BeforeEach
    void setUp() throws IOException {
        this.rawClient = DynamoDbClient.builder()
        .endpointOverride(container.getEndpoint())
        .credentialsProvider(
                create(AwsBasicCredentials.create(container.getAccessKey(),
                        container.getSecretKey())))
        .region(Region.of(container.getRegion()))
        .build();
        this.tableName = "%s-Audit".formatted(tablePrefix);

        this.table = DynamoDbEnhancedClient.builder().dynamoDbClient(rawClient)
        .build().table(tableName, TableSchema.fromBean(Audit.class));
        auditDAO = new AuditDAO(table);

        System.setProperty("aws.accessKeyId", container.getAccessKey());
        System.setProperty("aws.secretAccessKey", container.getSecretKey());

        /* FIXME: WebTestClient is poorly supported against a traditional
         * (non-WebFlux) WebMvc app. Switch back to using MockMvc instead.
         *  https://github.com/spring-projects/spring-security/issues/9257
         *  https://github.com/spring-projects/spring-security/issues/9304
         */
        client = MockMvcWebTestClient.bindToApplicationContext(applicationContext)
            .apply(SecurityMockMvcConfigurers.springSecurity())
            // workaround instead of using .mockJwt(), which throws NPE
            .defaultRequest(MockMvcRequestBuilders.get("/").with(SecurityMockMvcRequestPostProcessors.jwt()))
            .configureClient()
            .build();
    }

    @AfterEach
    void cleanUp() {
        table.deleteTable();
        table.createTable();
        server.resetAll();
    }

    protected void sendMessageToValidationQueue(String formId, String submissionId, String myUscisId,
                                        ValidationResultEnum status, ValidatorEnum validator,
                                        List<Map<String, String>> exceptions) throws JsonProcessingException {

        ValidationStatusResult body = ValidationStatusResult.builder()
                .formId(formId)
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .status(status)
                .validator(validator)
                .failureReasons(exceptions)
                .build();

        SendMessageRequest sendMsgRequest = SendMessageRequest.builder()
                .queueUrl(container.getEndpoint() + "/000000000000/" + VALIDATION_QUEUE)
                .messageBody(mapper.writeValueAsString(body))
                .build();

        sqsClient.sendMessage(sendMsgRequest);
    }

    protected boolean isEmpty() {
        GetQueueAttributesRequest request = GetQueueAttributesRequest.builder()
                .attributeNames(List.of(QueueAttributeName.APPROXIMATE_NUMBER_OF_MESSAGES))
                .queueUrl(container.getEndpoint() + "/000000000000/" + VALIDATION_QUEUE)
                .build();
        String response = sqsClient.getQueueAttributes(request).attributes()
                .get(QueueAttributeName.APPROXIMATE_NUMBER_OF_MESSAGES);
        return response.equals("0");
    }

    protected Callable<Boolean> hasEventByAction(String myUscisId, String submissionId, List<ActionPerformed> actions) {
        return () -> {
            Audit audit = this.auditDAO.find(myUscisId, submissionId);
            return audit.getEvents().stream()
                    .anyMatch((e) -> actions.contains(e.getActionPerformed()));
        };
    }

    protected List<Event> findEventByExpectedAction(Audit audit, ActionPerformed expectedAction) {
        return audit.getEvents().stream()
                .filter((e) -> e.getActionPerformed().equals(expectedAction)).toList();
    }

    // TODO improve stubbing to make it more precise and validate what we are
    // sending
    protected void withSuccessfulManifest(String submissionId, String uscisId) throws JsonProcessingException {
        server.stubFor(post("/api/v1/manifest")
                .withHeader("Content-Type", equalTo(MediaType.APPLICATION_JSON_VALUE))
                .willReturn(ok()));
    }

    protected void withFileableSubmission(String uscisId) throws JsonProcessingException {
        var body = new ApplicantFileableFormsResponse(
                new ApplicantFileableFormsData(asList("I-765"), asList("N-400"), false), null);
        server.stubFor(get("/api/applicant-fileable-forms")
                .withHeader("ICAM-UUID", equalTo(uscisId))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                        .withBody(new ObjectMapper().writeValueAsString(body))));
    }

    protected Event findEventByExpectedAction(Audit audit, ActionPerformed expectedAction, String evidenceId) {
        return audit.getEvents().stream()
                .filter((e) -> e.getActionPerformed().equals(expectedAction) && e.getMetadata().equals(evidenceId))
                .findFirst().orElse(null);
    }

    protected void withSuccessfulPaymentFor(String submissionId, BigDecimal fee, String formType) {
        String url = "/api/v1/payments/" + submissionId + "/authorization/status?feeTotal=" + fee.toString() + "&formType=" + formType;
        server.stubFor(get(urlEqualTo(url))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                        .withBody("{\"status\":\"Authorized\"}")));
    }

    protected void withSuccessfulElisValidation(String file) throws IOException {
        ClassPathResource resource = new ClassPathResource(file);
        server.stubFor(post(urlEqualTo("/v1/case/photo/validate"))
                .withHeader("ELISExternalUserName", containing("PDF-Intake"))
                .withHeader("Content-Type", containing(MediaType.MULTIPART_FORM_DATA_VALUE))
                .withHeader("Accept", equalTo(MediaType.APPLICATION_JSON_VALUE))
                .withMultipartRequestBody(
                        aMultipart()
                                .withName("file")
                                .withHeader("Content-Type", equalTo(MediaType.IMAGE_JPEG_VALUE))
                                .withBody(binaryEqualTo(resource.getContentAsByteArray())))
                .willReturn(ok()));
    }

    protected void assertAuditTrail(String myUscisId, String submissionId, Consumer<Audit> assertion) {
        Audit audit = auditDAO.find(myUscisId, submissionId);
        assertNotNull(audit);
        assertion.accept(audit);
    }


    protected String createInitialSubmission(String myUscisId, final SubmissionRequest request) {
        String submissionId = this.client.post()
                .uri("/api/v1/{myUscisId}/submissions/", myUscisId)
                .contentType(APPLICATION_JSON)
                .bodyValue(request)
                .exchange()
                .expectStatus().is2xxSuccessful()
                .expectBody(Submission.class)
                .returnResult()
                .getResponseBody().getSubmissionId();

        assertAuditTrail(myUscisId, submissionId, (audit) -> {
            assertEquals(myUscisId, audit.getMyUscisId());
            assertEquals(submissionId, audit.getSubmissionId());
            assertEquals(1, audit.getEvents().size());
            assertEquals(ActionPerformed.DRAFT_CREATED, audit.getEvents().get(0).getActionPerformed());
            assertEquals(SubmissionState.DRAFT, audit.getEvents().get(0).getSubmissionState());
            assertEquals(this.clock.instant(), audit.getEvents().get(0).getTimestamp());
        });

        return submissionId;
    }

    protected String uploadForm(String myUscisId, String submissionId, String filename,
            MultiValueMap<String, HttpEntity<?>> form) {
        var responseBody = this.client.post()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/form", myUscisId, submissionId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(form))
                .exchange()
                .expectStatus().is2xxSuccessful()
                .expectBody(UploadResponse.class)
                .returnResult()
                .getResponseBody();
        var formId = responseBody.formId();
        var artifactId = responseBody.artifactId();

        String s3Key = String.format("%s/%s/%s", submissionId, MYUSCIS_ID, artifactId);
        assertTrue(fileExists(FORM_BUCKET, s3Key, formId));

        assertAuditTrail(myUscisId, submissionId, (audit) -> {
            Event event = findEventByExpectedAction(audit, ActionPerformed.FORM_UPLOADED).stream()
                    .filter(e -> e.getMetadata().equals(formId))
                    .findFirst()
                    .orElse(null);
            assertNotNull(event);
            assertEquals(myUscisId, audit.getMyUscisId());
            assertEquals(submissionId, audit.getSubmissionId());
            assertEquals(formId, event.getMetadata());
        });

        return formId;
    }

    protected boolean fileExists(String bucket, String key, String id) {
        try {
            var tokens = key.split("/");
            var objects = s3Client.listObjects(
                    ListObjectsRequest.builder().bucket(bucket).prefix(tokens[0] + "/" + tokens[1]).build());
            for (var thing : objects.contents()) {
                System.out.println(thing.key());
            }
            var ids = objects.contents().stream().map(o -> s3Client.headObject(HeadObjectRequest.builder()
                    .bucket(bucket).key(o.key()).build()))
                    .map(f -> f.metadata().get("id"))
                    .filter(f -> f != null)
                    .collect(Collectors.toList());

            return ids.contains(id);
        } catch (NoSuchKeyException e) {
            return false;
        }
    }

    protected void deleteFormByFormId(String myUscisId, String submissionId, String id, String filename) {
        this.client.delete()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/forms/{id}", myUscisId, submissionId, id)
                .exchange()
                .expectStatus().is2xxSuccessful();

        String s3Key = String.format("%s/%s/%s", submissionId, MYUSCIS_ID, filename);
        assertFalse(fileExists(FORM_BUCKET, s3Key, id));
    }

    protected void withFeeWaiver(String myUscisId, String submissionId, MultiValueMap<String, HttpEntity<?>> form) {
        this.updateUserRequestedFeeWaiver(myUscisId, submissionId, true);
        this.uploadFeeWaiver(myUscisId, submissionId, form);
    }

    protected String uploadFeeWaiver(String myUscisId, String submissionId,
            MultiValueMap<String, HttpEntity<?>> form) {
        UpdateSubmissionResponse response = this.client.post()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/feeWaiver", myUscisId, submissionId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(form))
                .exchange()
                .expectStatus().is2xxSuccessful()
                .expectBody(UpdateSubmissionResponse.class)
                .returnResult()
                .getResponseBody();

        assertAuditTrail(myUscisId, submissionId, (audit) -> {
            Event event = findEventByExpectedAction(audit, ActionPerformed.FEE_WAIVER_UPLOADED).stream()
                    .filter((element) -> element.getMetadata().equals(response.submission().feeWaiver().id()))
                    .findFirst().orElse(null);
            assertNotNull(event);
            assertEquals(myUscisId, audit.getMyUscisId());
            assertEquals(submissionId, audit.getSubmissionId());
        });

        return response.submission().feeWaiver().id();
    }

    protected List<String> uploadEvidence(String myUscisId, String submissionId, String selectedFormType,
            MultiValueMap<String, HttpEntity<?>> form, 
            Consumer<ResponseSpec> assertion) {
        ResponseSpec response = this.client.post()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/evidence/{selectedFormType}", myUscisId, submissionId, selectedFormType)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(form))
                .exchange();

        assertion.accept(response);

        // TODO: This works because the response body in case of an error is empty and
        // it maps to the class
        // TODO: But is not the correct way.
        List<String> evidenceIds = response.expectBodyList(UploadEvidenceResponse.class).returnResult()
                .getResponseBody().stream().filter(e -> e.id() != null).map(e -> e.id()).toList();

        assertAuditTrail(myUscisId, submissionId, (audit) -> {
            if (evidenceIds != null && !evidenceIds.isEmpty()) {
                Event event = findEventByExpectedAction(audit, ActionPerformed.EVIDENCE_UPLOADED)
                        .stream().filter((element) -> evidenceIds.contains(element.getMetadata()))
                        .findFirst().orElse(null);
                assertNotNull(event);
                assertEquals(myUscisId, audit.getMyUscisId());
                assertEquals(submissionId, audit.getSubmissionId());
            }

        });

        return evidenceIds;
    }

    protected void updateEvidence(String myUscisId, String submissionId, String evidenceId, String type) {
        this.client.patch()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/evidence/{evidenceId}", myUscisId, submissionId,
                        evidenceId)
                .contentType(APPLICATION_JSON)
                .bodyValue(new UpdateEvidenceRequest(type))
                .exchange()
                .expectStatus().is2xxSuccessful();
    }

    protected void waitForSignatureAnalysis(String myUscisId, String submissionId, String formId,
            ValidationResultEnum status) throws JsonProcessingException {
                // TODO uncomment when enabling PFVS
        sendMessageToValidationQueue(formId, submissionId, myUscisId, status, SIGNATURE,
                Collections.emptyList());
        await().atMost(Duration.ofSeconds(10)).until(this::isEmpty);
        await().atMost(Duration.ofSeconds(10))
                .until(hasEventByAction(myUscisId, submissionId, List.of(SIGNATURE_DETECTED, SIGNATURE_NOT_DETECTED)));
        assertAuditTrail(myUscisId, submissionId, (audit) -> {
            Event event = findEventByExpectedAction(audit, status == PASS ? SIGNATURE_DETECTED : SIGNATURE_NOT_DETECTED)
                    .stream().findFirst().orElse(null);
            assertNotNull(event);
            assertEquals(this.clock.instant(), event.getTimestamp());
        });
    }

    protected void waitForValidation(String formId, String submissionId, String myUscisId,
            ValidationResultEnum status, ValidatorEnum validator) throws JsonProcessingException {
                // TODO coment for PFVS
        sendMessageToValidationQueue(formId, submissionId, myUscisId, status, validator, Collections.emptyList());
        await().atMost(Duration.ofSeconds(560000)).until(this::isEmpty);
    }

    protected void updateEligibility(String myUscisId, String submissionId, I765EligibilityCategory category) {
        var updatedEligibility = new EligibilityUpdateRequest();
        updatedEligibility.setEligibilityCategory(category);
        updatedEligibility.setFormType(FormType.I765.getType());
        updateSubmissionEligibility(myUscisId, submissionId, updatedEligibility);
        assertAuditTrail(myUscisId, submissionId, (audit) -> {
            Event event = findEventByExpectedAction(audit, ActionPerformed.SELECT_ELIGIBILITY_CATEGORY)
                    .stream()
                    .findFirst().orElse(null);
            assertNotNull(event);
            assertEquals(SubmissionState.DRAFT, event.getSubmissionState());
            assertEquals(category.toString(), event.getMetadata());
            assertEquals(this.clock.instant(), event.getTimestamp());
        });
    }

    protected void updateEligibilityAndFormType(String myUscisId, String submissionId, I765EligibilityCategory category, String formType) {
        var updatedEligibility = new EligibilityUpdateRequest();
        updatedEligibility.setEligibilityCategory(category);
        updatedEligibility.setFormType(formType);
        updateSubmissionEligibility(myUscisId, submissionId, updatedEligibility);
        assertAuditTrail(myUscisId, submissionId, (audit) -> {
            Event event = findEventByExpectedAction(audit, ActionPerformed.SELECT_ELIGIBILITY_CATEGORY)
                    .stream()
                    .findFirst().orElse(null);
            assertNotNull(event);
            assertEquals(SubmissionState.DRAFT, event.getSubmissionState());
            assertEquals(category.toString(), event.getMetadata());
            assertEquals(this.clock.instant(), event.getTimestamp());
        });
    }

    protected SubmissionDto updateSubmissionEligibility(String myUscisId, String submissionId,
            EligibilityUpdateRequest requestingEligibility) {
        return this.client.put()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/category", myUscisId, submissionId)
                .contentType(APPLICATION_JSON)
                .bodyValue(requestingEligibility)
                .exchange()
                .expectStatus().isOk()
                .expectBody(SubmissionDto.class)
                .returnResult()
                .getResponseBody();
    }

    protected SubmissionDto updateUserRequestedFeeWaiver(String myUscisId, String submissionId,
            boolean userRequestedFeeWaiver) {
        return client.put()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/fee-waiver", myUscisId, submissionId)
                .contentType(APPLICATION_JSON)
                .bodyValue(FeeWaiverRequest.builder().userRequestedFeeWaiver(userRequestedFeeWaiver).build())
                .exchange()
                .expectStatus().isOk()
                .expectBody(SubmissionDto.class)
                .returnResult()
                .getResponseBody();
    }

    protected SubmissionDto updateUserRequestedPartialFeeWaiver(String myUscisId, String submissionId,
            boolean userRequestedPartialFeeWaiver) {
        return client.put()
                .uri("/api/v1/{myUscisId}/submission/{submissionId}/partial-fee-waiver", myUscisId, submissionId)
                .contentType(APPLICATION_JSON)
                .bodyValue(PartialFeeWaiverRequest.builder()
                        .userRequestedPartialFeeWaiver(userRequestedPartialFeeWaiver).build())
                .exchange()
                .expectStatus().isOk()
                .expectBody(SubmissionDto.class)
                .returnResult()
                .getResponseBody();
    }

    protected SubmissionDto updateImmvi(String myUscisId, String submissionId, ImmviUpdateRequest requestingImmvi) {
        return this.client.put()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/immvi", myUscisId, submissionId)
                .contentType(APPLICATION_JSON)
                .bodyValue(requestingImmvi)
                .exchange()
                .expectStatus().isOk()
                .expectBody(SubmissionDto.class)
                .returnResult()
                .getResponseBody();
    }

    protected SubmissionDto updateC9fee(String myUscisId, String submissionId, C9FeeUpdateRequest requestingC9fee) {
        return this.client.put()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/c9fee", myUscisId, submissionId)
                .contentType(APPLICATION_JSON)
                .bodyValue(requestingC9fee)
                .exchange()
                .expectStatus().isOk()
                .expectBody(SubmissionDto.class)
                .returnResult()
                .getResponseBody();
    }

    protected SubmissionDto updateReasonForFiling(String myUscisId, String submissionId, String reasonForFiling) {
        ReasonForFilingUpdateRequest request = new ReasonForFilingUpdateRequest();
        request.setReasonForFiling(reasonForFiling);
        return this.client.put()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/reason-for-filing", myUscisId, submissionId)
                .contentType(APPLICATION_JSON)
                .bodyValue(request)
                .exchange()
                .expectStatus().isOk()
                .expectBody(SubmissionDto.class)
                .returnResult()
                .getResponseBody();
    }

    protected SubmissionDto getSubmissionById(String myUscisId, String submissionId) {
        return this.client.get()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}", myUscisId, submissionId)
                .exchange().expectStatus().is2xxSuccessful()
                .expectBody(SubmissionDto.class)
                .returnResult()
                .getResponseBody();
    }

    protected SubmissionDto attestForm(String myUscisId, String submissionId, String formId,
            AttestFormRequest request) {
        return client.post()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/attest/{formId}",
                        myUscisId, submissionId, formId)
                .contentType(APPLICATION_JSON)
                .bodyValue(request)
                .exchange()
                .expectStatus().isOk()
                .expectBody(SubmissionDto.class)
                .returnResult()
                .getResponseBody();
    }

    protected void submitSubmission(String myUscisId, String submissionId, Consumer<ResponseSpec> assertion) {
        ResponseSpec response = this.client.post()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}", myUscisId, submissionId)
                .contentType(APPLICATION_JSON)
                .exchange();
        assertion.accept(response);
    }

    protected void deleteFeeWaiver(String myUscisId, String submissionId, String id, String filename, boolean shouldNotExist) {
        this.client.delete()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/feeWaiver/{id}", myUscisId, submissionId, id)
                .exchange()
                .expectStatus().is2xxSuccessful();

        String s3Key = String.format("%s/%s/%s", submissionId, MYUSCIS_ID, filename);
        if (shouldNotExist)
            assertFalse(fileExists(EVIDENCE_BUCKET, s3Key, id));
        else
            assertTrue(fileExists(EVIDENCE_BUCKET, s3Key, id));
    }

    protected void deleteEvidenceByEvidenceId(String myUscisId, String submissionId, String id, String filename,
            boolean shouldNotExist) {
        this.client.delete()
                .uri("/api/v1/{myUscisId}/submissions/{submissionId}/evidence/{id}", myUscisId, submissionId, id)
                .exchange()
                .expectStatus().is2xxSuccessful();

        String s3Key = String.format("%s/%s/%s", submissionId, MYUSCIS_ID, filename);
        if (shouldNotExist)
            assertFalse(fileExists(EVIDENCE_BUCKET, s3Key, id));
        else
            assertTrue(fileExists(EVIDENCE_BUCKET, s3Key, id));
    }
}
