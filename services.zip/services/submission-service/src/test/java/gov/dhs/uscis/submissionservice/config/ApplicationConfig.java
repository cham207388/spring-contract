package gov.dhs.uscis.submissionservice.config;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.UUID;
import java.util.function.Function;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.test.context.jdbc.Sql;

import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.submissionservice.entity.Toggle;
import gov.dhs.uscis.submissionservice.repository.ToggleRepository;

@TestConfiguration
@Sql(scripts = "classpath:data-seed.sql")
public class ApplicationConfig {
    public final static Instant DEFAULT = Instant.parse("2024-09-10T12:00:00Z");

    @Bean("uuid")
    @Primary
    public Function<String, String> uuid() {
        return (val) -> {
            return UUID.randomUUID().toString();
        };
    }

    @Bean
    @Primary
    public Clock clock() {
        return Clock.fixed(DEFAULT, ZoneOffset.UTC);
    }
    
    /* Ideally, we would separate out int tests from unit tests and require a postgres docker image running only for int tests
     * and then set that up in the pipeline. But as an alternative, the data structures are created automatically based on the jpa files
     * and this seems the most straightforward way to seed the data needed.
     */
    @Bean
    public ToggleRepository seedToggleData(ToggleRepository toggleRepository) {
    	toggleRepository.save(new Toggle(ToggleEnum.PFVS_I912.getName(), ToggleEnum.PFVS_I912.getName(), false));
    	toggleRepository.save(new Toggle(ToggleEnum.PFVS_ENABLED.getName(), ToggleEnum.PFVS_ENABLED.getName(), false));
    	return toggleRepository;
    }
    
}