package gov.dhs.uscis.submissionservice.validators.backend;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Collections;
import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.exception.BackendValidationException;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import gov.dhs.uscis.submissionservice.services.FormService;
import jakarta.servlet.http.Part;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.instancio.Select.field;

@ExtendWith(MockitoExtension.class)
public class UploadEvidenceValidatorNotExceedsEvidencesTest {

    @Mock
    FormService formService;

    @InjectMocks
    UploadEvidenceValidator uploadEvidenceValidator;

    @Test
    void shouldPassWhenSubmissionHaveNullEvidences() {
        List<Part> files = Instancio.ofList(Part.class).size(1).create();
        EvidenceGroup group = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getMaxNumberOfFiles), 1)
                .set(field(EvidenceGroup::getId), "form-i-94-passport")
                .create();
        UploadEvidenceRequest evidence = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), "form-i-94-passport")
                .create();
        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), null)
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                .set(field(Submission::getFormType), FormType.I765)
                .set(field(Submission::getForms), List.of())
                .create();
        EvidenceRequest request = new EvidenceRequest(List.of(evidence), files, submission);

        assertDoesNotThrow(() -> {
            uploadEvidenceValidator.validateEvidenceWithBackendData(request, null);
        });
    }

    @Test
    void shouldPassTrueWhenSubmissionDoesNotHaveEvidences() {
        List<Part> files = Instancio.ofList(Part.class).size(1).create();
        EvidenceGroup group = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getMaxNumberOfFiles), 1)
                .set(field(EvidenceGroup::getId), "form-i-94-passport")
                .create();
        UploadEvidenceRequest evidence = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), "form-i-94-passport")
                .create();
        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), Collections.emptyList())
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                .set(field(Submission::getFormType), FormType.I765)
                .set(field(Submission::getForms), List.of())
                .create();

        EvidenceRequest request = new EvidenceRequest(List.of(evidence), files, submission);

        assertDoesNotThrow(() -> {
            uploadEvidenceValidator.validateEvidenceWithBackendData(request, null);
        });
    }

    @Test
    void shouldPassWhenSubmissionHaveEvidencesButNotFromTheSameType() {
        List<Part> files = Instancio.ofList(Part.class).size(1).create();
        EvidenceGroup group = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getMaxNumberOfFiles), 1)
                .set(field(EvidenceGroup::getId), "form-i-94-passport")
                .create();
        UploadEvidenceRequest newEvidence = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), "form-i-94-passport")
                .create();

        SubmissionEvidence evidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getEvidenceGroupType), "applicant-photo")
                .create();

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), List.of(evidence))
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                .set(field(Submission::getFormType), FormType.I765)
                .set(field(Submission::getForms), List.of())
                .create();

        EvidenceRequest request = new EvidenceRequest(List.of(newEvidence), files, submission);

        assertDoesNotThrow(() -> {
            uploadEvidenceValidator.validateEvidenceWithBackendData(request, null);
        });
    }

    
    @Test
    void shouldThrowErrorWhenSubmissionDoesNotAllowMoreEvidencesForNewEvidence() {
        List<Part> files = Instancio.ofList(Part.class).size(1).create();
        EvidenceGroup group = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getMaxNumberOfFiles), 1)
                .set(field(EvidenceGroup::getId), "form-i-94-passport")
                .create();
        UploadEvidenceRequest newEvidence = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), "form-i-94-passport")
                .create();
        SubmissionEvidence evidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getEvidenceGroupType), "form-i-94-passport")
                .create();

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), List.of(evidence))
                .set(field(Submission::getEligibilityCategory), null)
                .set(field(Submission::getFormType), FormType.I765)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I765.getType())
                        .eligibilityCategory(I765EligibilityCategory.A12)
                    .build()))
                .create();
        EvidenceRequest request = new EvidenceRequest(List.of(newEvidence), files, submission);

        given(formService.retrieveEvidenceGroup(any(),
                any(), any())).willReturn(group);

        assertThrows(BackendValidationException.class, () -> {
            uploadEvidenceValidator.validateEvidenceWithBackendData(request, FormType.I765.getType());
        });

    }

    @Test
    void shouldThrowErrorWhenSubmissionDoesNotAllowMoreEvidencesWhenMultipleAreProvidedForNewEvidence() {
        String groupType = "form-i-94-passport";
        List<Part> files = Instancio.ofList(Part.class).size(2).create();
        EvidenceGroup group = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getMaxNumberOfFiles), 1)
                .set(field(EvidenceGroup::getId), groupType)
                .create();
        List<UploadEvidenceRequest> newEvidence = Instancio.ofList(UploadEvidenceRequest.class).size(2)
                .set(field(UploadEvidenceRequest::evidenceGroupType), groupType)
                .create();
        SubmissionEvidence evidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getEvidenceGroupType), groupType)
                .create();

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), List.of(evidence))
                .set(field(Submission::getEligibilityCategory), null)
                .set(field(Submission::getFormType), FormType.I765)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I765.getType())
                        .eligibilityCategory(I765EligibilityCategory.A12)
                    .build()))
                .create();
        EvidenceRequest request = new EvidenceRequest(newEvidence, files, submission);

        given(formService.retrieveEvidenceGroup(any(),
                any(), any())).willReturn(group);

        assertThrows(BackendValidationException.class, () -> {
            uploadEvidenceValidator.validateEvidenceWithBackendData(request, FormType.I765.getType());
        });
    }

    @Test
    void shouldThrowErrorWhenExistingEvidenceAndNewEvidenceExceedsEvidenceLimit() {
        String groupType = "form-i-94-passport";
        int newEvidenceSize = 2;
        List<Part> files = Instancio.ofList(Part.class).size(newEvidenceSize).create();
        EvidenceGroup group = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getMaxNumberOfFiles), 2)
                .set(field(EvidenceGroup::getId), groupType)
                .create();
        List<UploadEvidenceRequest> newEvidence = Instancio.ofList(UploadEvidenceRequest.class).size(newEvidenceSize)
                .set(field(UploadEvidenceRequest::evidenceGroupType), groupType)
                .create();
        SubmissionEvidence evidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getEvidenceGroupType), groupType)
                .create();

        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), List.of(evidence))
                .set(field(Submission::getEligibilityCategory), null)
                .set(field(Submission::getFormType), FormType.I765)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I765.getType())
                        .eligibilityCategory(I765EligibilityCategory.A12)
                    .build()))
                .create();
        EvidenceRequest request = new EvidenceRequest(newEvidence, files, submission);

        given(formService.retrieveEvidenceGroup(any(),
                any(), any())).willReturn(group);

        assertThrows(BackendValidationException.class, () -> {
            uploadEvidenceValidator.validateEvidenceWithBackendData(request, FormType.I765.getType());
        });
    }
    

}
