package gov.dhs.uscis.submissionservice.validators;

import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I485EligibilityCategory;
import gov.dhs.uscis.intake.enums.I485AEligibilityCategory;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.EvidenceType;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import gov.dhs.uscis.submissionservice.services.FormService;

import static org.instancio.Select.field;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
class EvidenceValidatorTest {

    @Mock
    private FormService formService;

    @InjectMocks
    private EvidenceValidator validator;

    @Test
    void isValid_shouldReturnTrue_whenEvidenceTypeMatchesService() {
        String validEvidenceId = "PASSPORT_PAGE";
        I765EligibilityCategory category = I765EligibilityCategory.C8;
        FormType type = FormType.I765;

        EvidenceType evidenceType = new EvidenceType();
        evidenceType.setId(validEvidenceId);
        
        EvidenceGroup group = new EvidenceGroup();
        group.setEvidenceTypes(List.of(evidenceType));

        given(formService.retrieveEvidenceGroups(type.getType(), category.getCategory()))
            .willReturn(List.of(group));

        SubmissionForm submissionForm = Instancio.of(SubmissionForm.class)
            .set(field("type"), type.getType())
            .set(field("eligibilityCategory"), category)
            .create();

        SubmissionEvidence submissionEvidence = new SubmissionEvidence();
        submissionEvidence.setType(validEvidenceId);

        FinalSubmissionDto submission = Instancio.of(FinalSubmissionDto.class)
            .set(field("type"), type)
            .set(field("forms"), List.of(submissionForm))
            .set(field("evidences"), List.of(submissionEvidence))
            .set(field("category"), category)
            .create();

        assertTrue(validator.isValid(submission, null));
    }

    @Test
    void isValid_shouldReturnFalse_whenEvidenceTypeIsInvalid() {
        I765EligibilityCategory category = I765EligibilityCategory.C8;
        FormType type = FormType.I765;

        given(formService.retrieveEvidenceGroups(any(), any())).willReturn(List.of());

        SubmissionForm submissionForm = Instancio.of(SubmissionForm.class)
            .set(field("type"), type.getType())
            .set(field("eligibilityCategory"), category)
            .create();

        SubmissionEvidence invalidEvidence = new SubmissionEvidence();
        invalidEvidence.setType("MALICIOUS_TYPE");

        FinalSubmissionDto submission = Instancio.of(FinalSubmissionDto.class)
            .set(field("type"), type)
            .set(field("forms"), List.of(submissionForm))
            .set(field("evidences"), List.of(invalidEvidence))
            .set(field("category"), category)
            .create();

        assertFalse(validator.isValid(submission, null));
    }

    @Test
    void isValid_shouldReturnTrue_forI907FormsRegardlessOfEvidence() {
        FinalSubmissionDto submission = Instancio.of(FinalSubmissionDto.class)
            .set(field(FinalSubmissionDto::getType), FormType.I907)
            .create();

        assertTrue(validator.isValid(submission, null));
    }

    @Test
    void isValid_shouldReturnTrue_whenEvidenceTypeMatchesService_CONCURRENTFLOW() {
        String primaryValidEvidenceId = "PASSPORT_PAGE";
        EvidenceType primaryEvidenceType = new EvidenceType();
        primaryEvidenceType.setId(primaryValidEvidenceId);

        String secondaryValidEvidenceId = "form-750";
        EvidenceType secondaryEvidenceType = new EvidenceType();
        secondaryEvidenceType.setId(secondaryValidEvidenceId);

        I485EligibilityCategory primaryCat = I485EligibilityCategory.PRINCIPAL_APPLICANT;
        I485AEligibilityCategory secondaryCat = I485AEligibilityCategory.PRINCIPAL_BENEFICIARY_OF_IMMIGRANT_PETITION_01141998;
        FormType primaryType = FormType.I485;
        FormType secondaryType = FormType.I485A;
        
        EvidenceGroup primaryGroup = new EvidenceGroup();
        primaryGroup.setEvidenceTypes(List.of(primaryEvidenceType));

        EvidenceGroup secondaryGroup = new EvidenceGroup();
        secondaryGroup.setEvidenceTypes(List.of(secondaryEvidenceType));

        given(formService.retrieveEvidenceGroups(primaryType.getType(), primaryCat.getCategory()))
            .willReturn(List.of(primaryGroup));
        given(formService.retrieveEvidenceGroups(secondaryType.getType(), secondaryCat.getCategory()))
            .willReturn(List.of(secondaryGroup));

        SubmissionForm primaryForm = Instancio.of(SubmissionForm.class)
            .set(field("type"), primaryType.getType())
            .set(field("eligibilityCategory"), primaryCat)
            .create();
        SubmissionForm secondaryForm = Instancio.of(SubmissionForm.class)
            .set(field("type"), secondaryType.getType())
            .set(field("eligibilityCategory"), secondaryCat)
            .create();

        SubmissionEvidence submissionEvidence = new SubmissionEvidence();
        submissionEvidence.setType(primaryValidEvidenceId);

        FinalSubmissionDto submission = Instancio.of(FinalSubmissionDto.class)
            .set(field("type"), primaryType)
            .set(field("forms"), List.of(primaryForm, secondaryForm))
            .set(field("evidences"), List.of(submissionEvidence))
            .set(field("category"), primaryCat)
            .create();

        assertTrue(validator.isValid(submission, null));
    }
}
