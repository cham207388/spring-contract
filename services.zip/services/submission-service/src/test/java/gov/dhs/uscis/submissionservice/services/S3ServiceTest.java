package gov.dhs.uscis.submissionservice.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.multipart.MultipartFile;

import software.amazon.awssdk.services.cloudwatch.model.InvalidFormatException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.constants.MetadataConstants;
import gov.dhs.uscis.intake.constants.S3Constants;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.intake.services.FileFormatValidator;
import gov.dhs.uscis.intake.services.formats.MagicBytes;
import gov.dhs.uscis.submissionservice.exception.FormProtectedException;
import gov.dhs.uscis.submissionservice.exception.S3DeleteObjectException;
import gov.dhs.uscis.submissionservice.exception.S3PutObjectException;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;
import gov.dhs.uscis.submissionservice.models.dto.S3FileInfo;
import gov.dhs.uscis.submissionservice.utilities.TestFileGeneration;
import jakarta.servlet.http.Part;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.core.exception.SdkException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.CopyObjectRequest;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class S3ServiceTest {

    S3Client s3Client = mock(S3Client.class);

    AuditService auditService = mock(AuditService.class);

    S3KeyFileNameGenerator fileNameGenerator = mock(S3KeyFileNameGenerator.class);

    ObjectMapper objectMapper = mock(ObjectMapper.class);
    
    ToggleService toggleService = mock(ToggleService.class);

    FileFormatValidator fileFormatValidator = mock(FileFormatValidator.class);
    private String formBucket = "form";
    private String evidenceBucket = "evidence";
    private String backupBucket = "form-backup";
    private String SUBMISSION_ID = UUID.randomUUID().toString();
    private String MYUSCIS_ID = UUID.randomUUID().toString();
    private UserInformation userInfo = UserInformation.builder().accountType(AccountType.APPLICANT).build();
    private Submission submission = Submission.builder().submissionId(SUBMISSION_ID).myUscisId(MYUSCIS_ID)
            .applicant(userInfo).formType(FormType.I765)
            .eligibilityCategory(I765EligibilityCategory.A12).build();
    private String generatedFileName = "";

    S3Service service = new S3Service(s3Client, auditService, fileNameGenerator, fileFormatValidator, objectMapper, toggleService,
            formBucket, evidenceBucket, backupBucket);

    UploadRequest request;

    UploadEvidenceRequest uploadEvidenceRequest;

    UploadFeeWaiverRequest uploadFeeWaiverRequest;

    MultipartFile file;

    Map<String, String> metaData = new HashMap<>();
    String currDir = System.getProperty("user.dir");
    byte[] magicBytes = TestFileGeneration.randomPdf();

    @Nested
    class S3PutObject {

        @BeforeEach
        void setUp() {
            reset(fileFormatValidator);

            request = UploadRequest.builder()
                    .fileName("fileName")
                    .isForm(true)
                    .formType("formType")
                    .build();

            uploadEvidenceRequest = UploadEvidenceRequest.builder()
                    .fileName("fileName")
                    .type("type")
                    .build();

            metaData.put("id", "formId");
            metaData.put("submissionId", SUBMISSION_ID);
            metaData.put("myuscisid", MYUSCIS_ID);
            metaData.put("formType", request.formType());
            file = new MockMultipartFile(
                    "file",
                    "hello.pdf",
                    MediaType.MULTIPART_FORM_DATA_VALUE,
                    magicBytes);

            Map<String, List<String>> signedHeaders = new HashMap<>();
            signedHeaders.put("Content-Type", new ArrayList<>());

            Mockito.lenient().when(s3Client.putObject(any(PutObjectRequest.class), any(RequestBody.class)))
                    .thenReturn(PutObjectResponse.builder().build());

            ReflectionTestUtils.setField(service, "formBucket", formBucket);
            ReflectionTestUtils.setField(service, "evidenceBucket", evidenceBucket);
            generatedFileName = UUID.randomUUID().toString();
            when(fileNameGenerator.generateName(anyString())).thenReturn(generatedFileName);
        }

        @Test
        void shouldCallPutObjectRequestWithSpecificDetails() throws IOException {
            MultipartFile mockFile = mock(MultipartFile.class);
            PDDocument mockPdfDocument = mock(PDDocument.class);
            InputStream anyInputStream = new ByteArrayInputStream(TestFileGeneration.randomPdf());
            when(mockFile.getInputStream()).thenReturn(anyInputStream);
            try (MockedStatic<Loader> mock = mockStatic(Loader.class)) {
                mock.when(() -> Loader.loadPDF(any(byte[].class))).thenReturn(mockPdfDocument);

                String formId = UUID.randomUUID().toString(); 
                
                when(fileFormatValidator.isSupportedFile(TestFileGeneration.randomPdf())).thenReturn(MagicBytes.PDF);
                service.uploadForm(submission, formId, file, request);

                ArgumentCaptor<PutObjectRequest> captor = ArgumentCaptor
                        .forClass(PutObjectRequest.class);

                ArgumentCaptor<RequestBody> captorRequestBody = ArgumentCaptor
                        .forClass(RequestBody.class);

                verify(s3Client, times(1)).putObject(captor.capture(),
                        captorRequestBody.capture());

                PutObjectRequest actual = captor.getValue();

                assertEquals(formBucket, actual.bucket());
                assertEquals(String.format("%s/%s/%s", SUBMISSION_ID,
                        MYUSCIS_ID, generatedFileName),
                        actual.key());
                assertNotNull(actual.metadata().get(MetadataConstants.ID));
                assertNotNull(actual.metadata().get(MetadataConstants.SUBMISSIONID));
                assertEquals(MYUSCIS_ID, actual.metadata().get(MetadataConstants.MYUSCISID));
                assertEquals(request.formType(), actual.metadata().get(MetadataConstants.FORMTYPE));
            }
        }

        @Test
        void shouldErrorOnUploadFormObject_sdkException() {
            MultipartFile mockFile = mock(MultipartFile.class);
            PDDocument mockPdfDocument = mock(PDDocument.class);

            try (MockedStatic<Loader> mock = mockStatic(Loader.class)) {
            	String formId = UUID.randomUUID().toString(); 
            	
                when(s3Client.putObject(any(PutObjectRequest.class),
                        any(RequestBody.class))).thenThrow(SdkException.class);

                mock.when(() -> Loader.loadPDF(any(byte[].class)))
                        .thenAnswer(invocation -> mockPdfDocument);
                assertThrows(S3PutObjectException.class, () -> {
                    when(fileFormatValidator.isSupportedFile(file.getBytes())).thenReturn(MagicBytes.PDF);
                    service.uploadForm(submission, formId, file, request);
                });
            }
        }

        @Test
        void shouldErrorOnUploadFormObject_InvalidPasswordException() throws IOException {
            MultipartFile mockFile = mock(MultipartFile.class);
            byte[] bytes = TestFileGeneration.protectedPdf();
            when(mockFile.getBytes()).thenReturn(bytes);

            assertThrows(FormProtectedException.class, () -> {
                var service = new S3Service(s3Client, auditService, fileNameGenerator, new FileFormatValidator(),
                        objectMapper, toggleService, formBucket, evidenceBucket, backupBucket);
                service.validateFormCanLoad(mockFile);
            });

        }

        @Test
        void shouldErrorOnUploadFormObject_UnsupportedMediaType() throws IOException {
            MultipartFile mockFile = mock(MultipartFile.class);
            byte[] unsupportedFileBytes = TestFileGeneration.randomUnsupportedFile();
            PDDocument mockPdfDocument = mock(PDDocument.class);

            when(mockFile.getBytes()).thenReturn(unsupportedFileBytes);

            FileFormatValidator mockValidator = mock(FileFormatValidator.class);
            try (MockedStatic<Loader> mock = mockStatic(Loader.class)) {
            	String formId = UUID.randomUUID().toString(); 
                mock.when(() -> Loader.loadPDF(any(byte[].class))).thenReturn(mockPdfDocument);

                when(mockValidator.isSupportedFile(TestFileGeneration.randomUnsupportedFile()))
                        .thenReturn(MagicBytes.UNSUPPORTED);

                var service = new S3Service(s3Client, auditService, fileNameGenerator, mockValidator, objectMapper, toggleService,
                        formBucket, evidenceBucket, backupBucket);

                assertThrows(InvalidFormatException.class, () -> {
                    service.uploadForm(submission, formId, mockFile, request);
                });
            }
        }

        @Test
        void shouldRetrieveEvidencePutObject() throws IOException {
            Part file = mock(Part.class);
            byte[] randomPdf = TestFileGeneration.randomPdf();
            when(file.getInputStream()).thenReturn(new ByteArrayInputStream(randomPdf));
            UploadEvidenceRequest evidenceRequest = Instancio.create(UploadEvidenceRequest.class);
            FileFormatValidator fileFormatValidator = mock(FileFormatValidator.class);
            when(fileFormatValidator.isSupportedFile(randomPdf)).thenReturn(MagicBytes.PDF);

            service = new S3Service(s3Client, auditService, fileNameGenerator, fileFormatValidator, objectMapper, toggleService,
                    formBucket, evidenceBucket, backupBucket);
            S3FileInfo actual = service.uploadEvidence(MYUSCIS_ID, SUBMISSION_ID, file, evidenceRequest, submission, FormType.I765.getType());
            ArgumentCaptor<PutObjectRequest> captor = ArgumentCaptor.forClass(PutObjectRequest.class);

            verify(s3Client, times(1)).putObject(captor.capture(), any(RequestBody.class));
            assertInstanceOf(S3FileInfo.class, actual);

            PutObjectRequest actualPut = captor.getValue();

            assertEquals(evidenceBucket, actualPut.bucket());
            assertEquals(String.format("%s/%s/%s", SUBMISSION_ID, MYUSCIS_ID,
                    generatedFileName), actualPut.key());
            assertNotNull(actualPut.metadata().get(MetadataConstants.ID));
            assertNotNull(actualPut.metadata().get(MetadataConstants.SUBMISSIONID));
            assertNotNull(actualPut.metadata().get(MetadataConstants.FORMTYPE));
            assertNotNull(actualPut.metadata().get(MetadataConstants.ELIGIBILITYCATEGORY));
            assertNotNull(actualPut.metadata().get(MetadataConstants.EVIDENCETYPE));
            assertNotNull(actualPut.metadata().get(MetadataConstants.SENT_TO_PFVS));
            assertEquals(MYUSCIS_ID, actualPut.metadata().get(MetadataConstants.MYUSCISID));
            assertEquals(SUBMISSION_ID, actualPut.metadata().get(MetadataConstants.SUBMISSIONID));
            assertEquals(evidenceRequest.type(), actualPut.metadata().get(MetadataConstants.EVIDENCETYPE));
        }

        @Test
        void shouldErrorOnUploadEvidenceObject_sdkException() throws IOException {
            Part file = mock(Part.class);
            when(file.getInputStream()).thenReturn(new ByteArrayInputStream(TestFileGeneration.randomJpg()));
            when(fileFormatValidator.isSupportedFile(TestFileGeneration.randomJpg())).thenReturn(MagicBytes.JPG);

            when(s3Client.putObject(any(PutObjectRequest.class), any(RequestBody.class))).thenThrow(SdkException.class);

            assertThrows(S3PutObjectException.class, () -> {
                service.uploadEvidence(MYUSCIS_ID, SUBMISSION_ID, file, uploadEvidenceRequest, submission, FormType.I765.getType());
            });
        }

        @Test
        void shouldRetrieveFeeWaiverPutObject() throws IOException {
            UploadFeeWaiverRequest uploadRequest = Instancio.create(UploadFeeWaiverRequest.class);
            Submission initialSubmission = Instancio.create(Submission.class);
            initialSubmission.setEligibilityCategory(I765EligibilityCategory.C11PAROLE);
            // FileFormatValidator fileFormatValidator = mock(FileFormatValidator.class);
            when(fileFormatValidator.isSupportedFile(file.getBytes())).thenReturn(MagicBytes.JPG);
            // service = new S3Service(s3Client, auditService, fileNameGenerator,
            // fileFormatValidator, objectMapper,formBucket,evidenceBucket);
            S3FileInfo actual = service.uploadFeeWaiver(MYUSCIS_ID, SUBMISSION_ID, file, uploadRequest,
                    initialSubmission);

            ArgumentCaptor<PutObjectRequest> captor = ArgumentCaptor.forClass(PutObjectRequest.class);
            verify(s3Client, times(1)).putObject(captor.capture(), any(RequestBody.class));
            assertInstanceOf(S3FileInfo.class, actual);

            PutObjectRequest actualPut = captor.getValue();

            assertEquals(evidenceBucket, actualPut.bucket());
            assertEquals(
                    String.format("%s/%s/%s", SUBMISSION_ID, MYUSCIS_ID,
                            generatedFileName),
                    actualPut.key());
            assertNotNull(actualPut.metadata().get(MetadataConstants.ID));
            assertNotNull(actualPut.metadata().get(MetadataConstants.SUBMISSIONID));
            assertEquals(MYUSCIS_ID, actualPut.metadata().get(MetadataConstants.MYUSCISID));
        }

    }

    @Test
    void shouldErrorOnUploadFeeWaiverObject_sdkException() {

        uploadFeeWaiverRequest = UploadFeeWaiverRequest.builder()
                .fileName("fileName")
                .build();

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "hello.pdf",
                MediaType.MULTIPART_FORM_DATA_VALUE,
                TestFileGeneration.randomPdf());

        Submission initialSubmission = Instancio.create(Submission.class);
        initialSubmission.setSubmissionId("submissionId");
        initialSubmission.setEligibilityCategory(I765EligibilityCategory.A12);
        when(fileFormatValidator.isSupportedFile(TestFileGeneration.randomPdf())).thenReturn(MagicBytes.PDF);

        when(s3Client.putObject(any(PutObjectRequest.class), any(RequestBody.class))).thenThrow(SdkException.class);

        assertThrows(S3PutObjectException.class, () -> {
            service.uploadFeeWaiver(MYUSCIS_ID, SUBMISSION_ID, file, uploadFeeWaiverRequest, initialSubmission);
        });
    }

    @Nested
    class DeleteObject {

        @Test
        void shouldDeleteFormObject() {
            String fileName = "I765-form.pdf";
            String formBucket = "formBucket";

            ReflectionTestUtils.setField(service, "formBucket", formBucket);

            DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                    .bucket(formBucket)
                    .key(fileName)
                    .build();

            var actualResult = service.deleteS3Object(fileName, false);

            var expectedResult = S3Constants.DELETION_SUCCESS_MESSAGE;
            assertEquals(expectedResult, actualResult);

            verify(s3Client, times(1)).deleteObject(deleteObjectRequest);
            verify(s3Client, times(1)).copyObject(any(CopyObjectRequest.class));
        }

        @Test
        void shouldErrorOnDeleteFormObject_awsServiceException() {
            String fileName = "I765-form.pdf";

            when(s3Client.deleteObject(any(DeleteObjectRequest.class))).thenThrow(AwsServiceException.class);

            assertThrows(S3DeleteObjectException.class, () -> {
                service.deleteS3Object(fileName, false);
            });
        }

        @Test
        void shouldErrorOnDeleteFormObject_sdkClientException() {
            String fileName = "I765-form.pdf";

            when(s3Client.deleteObject((any(DeleteObjectRequest.class)))).thenThrow(SdkClientException.class);

            assertThrows(S3DeleteObjectException.class, () -> {
                service.deleteS3Object(fileName, false);
            });

        }

        @Test
        void shouldDeleteEvidenceObject() {
            String fileName = "photoOfYou.png";
            String evidenceBucket = "evidenceBucket";

            ReflectionTestUtils.setField(service, "evidenceBucket", evidenceBucket);

            DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                    .bucket(evidenceBucket)
                    .key(fileName)
                    .build();

            var actualResult = service.deleteS3Object(fileName, true);

            var expectedResult = S3Constants.DELETION_SUCCESS_MESSAGE;
            assertEquals(expectedResult, actualResult);

            verify(s3Client, times(1)).deleteObject(deleteObjectRequest);
        }

        @Test
        void shouldErrorOnDeleteEvidenceObject_awsServiceException() {
            String fileName = "photoOfYou.png";

            when(s3Client.deleteObject(any(DeleteObjectRequest.class))).thenThrow(AwsServiceException.class);

            assertThrows(S3DeleteObjectException.class, () -> {
                service.deleteS3Object(fileName, true);
            });
        }

        @Test
        void shouldErrorOnDeleteEvidenceObject_sdkClientException() {
            String fileName = "photoOfYou.png";

            when(s3Client.deleteObject((any(DeleteObjectRequest.class)))).thenThrow(SdkClientException.class);

            assertThrows(S3DeleteObjectException.class, () -> {
                service.deleteS3Object(fileName, true);
            });

        }
    }


    @Test
    void shouldGetFileDataForForm() {
        String s3Key = "s3Key";
        String formBucket = "formBucket";
        ReflectionTestUtils.setField(service, "formBucket", formBucket);

        byte[] objectContent = "test-file".getBytes();
        ResponseBytes<?> responseBytes = ResponseBytes.fromByteArray(GetObjectRequest.builder().build(), objectContent);
        ArgumentCaptor<GetObjectRequest> captor = ArgumentCaptor.forClass(GetObjectRequest.class);

        doReturn(responseBytes).when(s3Client).getObjectAsBytes(any(GetObjectRequest.class));

        byte[] actual = service.getFileData(s3Key, true);

        verify(s3Client, times(1)).getObjectAsBytes(captor.capture());
        assertInstanceOf(byte[].class, actual);
    }

    @Test
    void shouldGetFileDataForEvidence() {
        String s3Key = "s3Key";
        String evidenceBucket = "evidenceBucket";
        ReflectionTestUtils.setField(service, "evidenceBucket", evidenceBucket);

        byte[] objectContent = "test-file".getBytes();
        ResponseBytes<?> responseBytes = ResponseBytes.fromByteArray(GetObjectRequest.builder().build(), objectContent);
        ArgumentCaptor<GetObjectRequest> captor = ArgumentCaptor.forClass(GetObjectRequest.class);

        doReturn(responseBytes).when(s3Client).getObjectAsBytes(any(GetObjectRequest.class));

        byte[] actual = service.getFileData(s3Key, false);

        verify(s3Client, times(1)).getObjectAsBytes(captor.capture());
        assertInstanceOf(byte[].class, actual);
    }

    @Test
    void shouldBeTrueWhenCallHeadObjectWithNoErrorToCheckIfFormExists() {
        assertTrue(service.checkIfFileExists("key", true));
        verify(s3Client, times(1)).headObject(any(HeadObjectRequest.class));
    }

    @Test
    void shouldBeTrueWhenCallHeadObjectWithNoErrorToCheckIfEvidenceExists() {
        assertTrue(service.checkIfFileExists("key", false));
        verify(s3Client, times(1)).headObject(any(HeadObjectRequest.class));
    }

    @Test
    void shouldBeFalseWhenCallHeadObjectWithErrorToCheckIfFormExists() {
        when(s3Client.headObject(any(HeadObjectRequest.class))).thenThrow(NoSuchKeyException.class);
        assertFalse(service.checkIfFileExists("key", true));
        verify(s3Client, times(1)).headObject(any(HeadObjectRequest.class));
    }

}
