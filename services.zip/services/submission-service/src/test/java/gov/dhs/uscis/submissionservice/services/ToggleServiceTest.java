package gov.dhs.uscis.submissionservice.services;

import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.submissionservice.entity.Toggle;
import gov.dhs.uscis.submissionservice.entity.ToggleFormTypeOverride;
import gov.dhs.uscis.submissionservice.repository.ToggleFormTypeOverrideRepository;
import gov.dhs.uscis.submissionservice.repository.ToggleRepository;

@ExtendWith(MockitoExtension.class)
public class ToggleServiceTest {

	@Mock
	ToggleRepository toggleRepository;

	@Mock
	ToggleFormTypeOverrideRepository toggleFormTypeOverrideRepository;

	@InjectMocks
	private ToggleService service;

	@Test
	void toggleFormTypeExists() {
		FormType formType = FormType.I765;
		ToggleEnum toggle = ToggleEnum.PFVS_I912;
		
		when(toggleFormTypeOverrideRepository.findByIdToggleNameAndIdFormType(toggle.getName(), formType.getType())).thenReturn(
				Optional.of(new ToggleFormTypeOverride(toggle.getName(), formType.getType(), true)));
		
		assertTrue(service.isToggleActive(toggle, formType.getType()));
		
		verify(toggleRepository, times(0)).findById(toggle.getName());
	}
	   	@Test
	void toggleFormTypeExistsString() {
		FormType formType = FormType.I765;
		ToggleEnum toggle = ToggleEnum.PFVS_I912;
		
		when(toggleFormTypeOverrideRepository.findByIdToggleNameAndIdFormType(toggle.getName(), formType.getType())).thenReturn(
				Optional.of(new ToggleFormTypeOverride(toggle.getName(), formType.getType(), true)));
		
		assertTrue(service.isToggleActive(toggle.getName(), formType.getType()));
		
		verify(toggleRepository, times(0)).findById(toggle.getName());
	}
	
	@Test
	void toggledefaultString() {
		FormType formType = FormType.I130;
		ToggleEnum toggle = ToggleEnum.PFVS_I912;
		
		when(toggleFormTypeOverrideRepository.findByIdToggleNameAndIdFormType(toggle.getName(), formType.getType())).thenReturn(Optional.empty());
		
		when(toggleRepository.findById(toggle.getName())).thenReturn(Optional.of(new Toggle(toggle.getName(), "",  false)));
		
		assertFalse(service.isToggleActive(toggle.getName(), formType.getType()));
	}
	@Test
	void toggledefault() {
		FormType formType = FormType.I130;
		ToggleEnum toggle = ToggleEnum.PFVS_I912;
		
		when(toggleFormTypeOverrideRepository.findByIdToggleNameAndIdFormType(toggle.getName(), formType.getType())).thenReturn(Optional.empty());
		
		when(toggleRepository.findById(toggle.getName())).thenReturn(Optional.of(new Toggle(toggle.getName(), "",  false)));
		
		assertFalse(service.isToggleActive(toggle, formType.getType()));
	}

}
