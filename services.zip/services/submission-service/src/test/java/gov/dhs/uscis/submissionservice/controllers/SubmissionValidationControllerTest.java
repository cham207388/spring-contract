package gov.dhs.uscis.submissionservice.controllers;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.get;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import gov.dhs.uscis.submissionservice.exception.BackendValidationException;
import gov.dhs.uscis.submissionservice.exception.NoFormInSubmissionException;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ValidationService;

@WebMvcTest(SubmissionValidationController.class)
@AutoConfigureMockMvc
class SubmissionValidationControllerTest {
		
	@MockitoBean
	private SubmissionService submissionService;
	
	@MockitoBean
    private ValidationService validationService;
	
	@Autowired
	private MockMvc mockMvc;
	
	private static final String SUBMISSION_ID = "MOCK-SUBMISSION-ID";
	private static final String MY_USCIS_ID = "MOCK-MYUSCIS-ID";
	
	@Test
	void shouldSendPFVSValidationRequest() throws Exception {
		mockMvc.perform(get("/api/v1/{myUscisId}/submissions/{submissionId}/pfvs/validate", MY_USCIS_ID, SUBMISSION_ID)
				.with(jwt()))
				.andExpect(status().isOk());
		verify(submissionService).validateSubmission(MY_USCIS_ID, SUBMISSION_ID);
	}
	
	@Test
	void shouldFailDueToMissingForm() throws Exception {
		doThrow(new NoFormInSubmissionException("Cannot find primary form in the submission."))
			.when(submissionService).validateSubmission(MY_USCIS_ID, SUBMISSION_ID);
		
		mockMvc.perform(get("/api/v1/{myUscisId}/submissions/{submissionId}/pfvs/validate", MY_USCIS_ID, SUBMISSION_ID)
				.with(jwt()))
				.andExpect(status().is5xxServerError());
	}
	
	@Test
	void shouldFailDueToNonPFVSForm() throws Exception {
		doThrow(new BackendValidationException("The submission is not supported by PFVS."))
			.when(submissionService).validateSubmission(MY_USCIS_ID, SUBMISSION_ID);
		
		mockMvc.perform(get("/api/v1/{myUscisId}/submissions/{submissionId}/pfvs/validate", MY_USCIS_ID, SUBMISSION_ID)
				.with(jwt()))
				.andExpect(status().is5xxServerError());
	}
	
}
