package gov.dhs.uscis.submissionservice;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.submissionservice.config.ApplicationConfig;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, 
            classes = {ApplicationConfig.class},
            properties = "spring.main.allow-bean-definition-overriding=true")
public class EvidenceGroupIntegrationTest extends BaseJourneyTest {
    @Test
    void shouldReturnEvidenceGroupsForTemporaryProtectedStatusGranted() {
        List<String> expected = List.of("applicant-photo", "form-i-94-passport", "employment", "identity-travel-documents",
                                        "eoir-bia-order", "form-i-821", "form-i-797", "additional-evidence");
        List<EvidenceGroup> groups = this.client.get().uri("/api/v1/forms/I-765/metadata/A12/evidence")
                                        .exchange()
                                        .expectStatus().is2xxSuccessful()
                                        .expectBodyList(EvidenceGroup.class)
                                        .returnResult()
                                        .getResponseBody();
        List<String> actuals = groups.stream().map((group) -> group.getId()).toList();
        assertEquals(expected, actuals);
    }

    @Test
    void shouldReturnEvidenceGroupsForAsylumPending() {
        List<String> expected = List.of("applicant-photo", "form-i-94-passport", "employment", "form-i-589",
                                        "bia-remand-order", "form-i-797c", "criminal-history", "additional-evidence");
        List<EvidenceGroup> groups = this.client.get().uri("/api/v1/forms/I-765/metadata/C8/evidence")
                                        .exchange()
                                        .expectStatus().is2xxSuccessful()
                                        .expectBodyList(EvidenceGroup.class)
                                        .returnResult()
                                        .getResponseBody();
        List<String> actuals = groups.stream().map((group) -> group.getId()).toList();
        assertEquals(expected, actuals);
    }

    @Test
    void shouldReturnEvidenceGroupsForApplicantUnderSection245() {
        List<String> expected = List.of("applicant-photo", "form-i-94-passport", "employment", "form-i-485",
                                        "form-i-797c", "additional-evidence");
        List<EvidenceGroup> groups = this.client.get().uri("/api/v1/forms/I-765/metadata/C9/evidence")
                                        .exchange()
                                        .expectStatus().is2xxSuccessful()
                                        .expectBodyList(EvidenceGroup.class)
                                        .returnResult()
                                        .getResponseBody();
        List<String> actuals = groups.stream().map((group) -> group.getId()).toList();
        assertEquals(expected, actuals);
    }

}
