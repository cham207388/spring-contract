package gov.dhs.uscis.submissionservice.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersUriSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

import gov.dhs.uscis.intake.enums.FormType;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class PaymentServiceClientTest {

    @Mock
    RequestBodyUriSpec requestBodyUriSpec;
    @Mock
    RequestBodySpec requestBodySpec;
    @Mock
    ResponseSpec responseSpec;
    @Mock
    RequestHeadersSpec<?> requestHeadersSpec;
    @Mock
    RequestHeadersUriSpec<?> requestHeadersUriSpec;
    private String testSubmissionId = "submissionId";

    @Test
    public void testIsAuthorized() {
        WebClient webClient = mock(WebClient.class);
        var paymentServiceClient = new PaymentServiceClient(webClient);

        doReturn(requestHeadersUriSpec).when(webClient).get();
        doReturn(requestHeadersSpec).when(requestHeadersUriSpec)
            .uri("/api/v1/payments/submissionId/authorization/status?feeTotal=10&formType=I-765");
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        var responseMap = new HashMap<String, String>();
        responseMap.put("status", "Authorized");
        when(responseSpec.bodyToMono(Map.class))
                .thenReturn(Mono.just(responseMap));
        var authorized = paymentServiceClient.isAuthorized(testSubmissionId, BigDecimal.TEN, FormType.I765.getType());
        assertTrue(authorized);
    }

    @Test
    public void shouldNotBeAuthorized(){
        var webClient = mock(WebClient.class);
        var paymentServiceClient = new PaymentServiceClient(webClient);

        doReturn(requestHeadersUriSpec).when(webClient).get();
        doReturn(requestHeadersSpec).when(requestHeadersUriSpec)
            .uri("/api/v1/payments/submissionId/authorization/status?feeTotal=10&formType=I-765");
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        var responseMap = new HashMap<String, String>();
        responseMap.put("status", "NotAuthorized");
        when(responseSpec.bodyToMono(Map.class))
                .thenReturn(Mono.just(responseMap));
        var authorized = paymentServiceClient.isAuthorized(testSubmissionId, BigDecimal.TEN, FormType.I765.getType());
        assertFalse(authorized);
    }

    @Test
    public void testStartAuthorization() throws URISyntaxException {
        var webClient = mock(WebClient.class);
        var paymentServiceClient = new PaymentServiceClient(webClient);

        doReturn(requestHeadersUriSpec).when(webClient).get();
        doReturn(requestHeadersSpec).when(requestHeadersUriSpec)
            .uri("/api/v1/payments/submissionId/authorization?feeTotal=10.00&formType=I-765");
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        var responseEntity = mock(ResponseEntity.class);
        HttpHeaders headers = mock(org.springframework.http.HttpHeaders.class);
        var testHeader = new URI("http://test");
        when(headers.getLocation()).thenReturn( testHeader );
        when(responseEntity.getHeaders()).thenReturn(headers);
        when(responseSpec.toBodilessEntity()).thenReturn(Mono.just(responseEntity));
        var url = paymentServiceClient.startAuthorization(testSubmissionId, FormType.I765, new BigDecimal("10.00"));
        assertEquals(url, testHeader);
    }
}
