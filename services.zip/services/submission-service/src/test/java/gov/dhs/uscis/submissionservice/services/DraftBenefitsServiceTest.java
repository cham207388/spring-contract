package gov.dhs.uscis.submissionservice.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersUriSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.amazonaws.lambda.thirdparty.com.fasterxml.jackson.core.JsonProcessingException;
import com.amazonaws.lambda.thirdparty.com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.submissionservice.models.myUscis.draftBenefits.ApplicantFileableFormsResponse;
import reactor.core.publisher.Mono;

public class DraftBenefitsServiceTest {

    ResponseSpec responseSpec = Mockito.mock(ResponseSpec.class);
    RequestHeadersSpec requestHeadersSpec = Mockito.mock(RequestHeadersSpec.class);
    RequestHeadersUriSpec requestHeadersUriSpec = Mockito.mock(RequestHeadersUriSpec.class);

    WebClient webClient;
    String myUscisId;
    DraftBenefitsService service;

    @BeforeEach
    public void setup() {
        myUscisId = UUID.randomUUID().toString();
        webClient = Mockito.mock(WebClient.class);
        service = new DraftBenefitsService(webClient);
        
        ReflectionTestUtils.setField(service, "draftBenefitsServiceEnabled", true);
    }

    @Test
    void shouldReturnTrueWhenUserAbleToApplyForN400() {
    
        ApplicantFileableFormsResponse response = Instancio.create(ApplicantFileableFormsResponse.class);
        response.getData().setApplicantFileableForms(List.of("N-400"));

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(DraftBenefitsService.APPLICANT_FILEABLE_FORMS_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ApplicantFileableFormsResponse.class)).thenReturn(Mono.just(responseEntity));

        assertThat(service.canApplicantFileFor(FormType.N400.getType(), myUscisId)).isTrue();
    }

    @Test
    void shouldReturnFalseWhenUserNotAbleToApplyForN400() {
    
        ApplicantFileableFormsResponse response = Instancio.create(ApplicantFileableFormsResponse.class);
        response.getData().setApplicantFileableForms(List.of("I-765"));

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(DraftBenefitsService.APPLICANT_FILEABLE_FORMS_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ApplicantFileableFormsResponse.class)).thenReturn(Mono.just(responseEntity));

        assertThat(service.canApplicantFileFor(FormType.N400.getType(), myUscisId)).isFalse();
    }

    @Test
    void shouldReturnMockValueWhenNotEnabled() {
        ReflectionTestUtils.setField(service, "draftBenefitsServiceEnabled", false);
        ReflectionTestUtils.setField(service, "draftBenefitsTestMockResponse", false);
        
        assertThat(service.canApplicantFileFor(FormType.I765.getType(), myUscisId)).isTrue();
        assertThat(service.canApplicantFileFor(FormType.N400.getType(), myUscisId)).isFalse();
    }

    @Test
    void shouldReturnFalseWhenDraftBenefitServiceClientThrowsWebClientResponseException() throws JsonProcessingException {
    
        ApplicantFileableFormsResponse response = Instancio.create(ApplicantFileableFormsResponse.class);
        response.setData(null);

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(DraftBenefitsService.APPLICANT_FILEABLE_FORMS_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        Map<String, List<String>> headerMap = new HashMap<String, List<String>>();
        headerMap.put("content-type", List.of("application/json; charset=utf-8"));
        when(responseSpec.toEntity(ApplicantFileableFormsResponse.class)).thenThrow(WebClientResponseException.create(400, "Error: response status is 400", new HttpHeaders(), new ObjectMapper().writeValueAsBytes(response), Charset.forName("UTF-8")));

        assertThat(service.canApplicantFileFor(FormType.N400.getType(), myUscisId)).isFalse();
    }

    @Test
    void shouldReturnFalseWhenDraftBenefitServiceClientDoesNotReturn200() throws JsonProcessingException {
    
        ApplicantFileableFormsResponse response = Instancio.create(ApplicantFileableFormsResponse.class);
        response.setData(null);

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(DraftBenefitsService.APPLICANT_FILEABLE_FORMS_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.badRequest().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ApplicantFileableFormsResponse.class)).thenReturn(Mono.just(responseEntity));

        assertThat(service.canApplicantFileFor(FormType.N400.getType(), myUscisId)).isFalse();
    }
}
