package gov.dhs.uscis.submissionservice.validators.i765;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.testcontainers.shaded.com.google.common.collect.Maps;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;

@ExtendWith(MockitoExtension.class)
public class ReasonForFilingValidatorTest {

    @Mock
    DynamoDbTable<ValidationStatus> validationStatusTable;

    @InjectMocks
    private ReasonForFilingValidator validator;

    @Test
    void shouldFailValidationWhenReasonForFilingAreDifferent() {
        String formId = UUID.randomUUID().toString();
        String eligibilityCategoryOnForm = "C 11";
        String submissionId = UUID.randomUUID().toString();
        String formReasonForFiling = "1.b.";

        FormFields formFields = FormFields.builder().submissionId(submissionId).formId(formId)
                .reasonForApplySelection(formReasonForFiling)
                .eligibilityCategory(eligibilityCategoryOnForm)
                .build();

        SubmissionForm form = SubmissionForm.builder().build();
        Submission submission = Submission.builder()
                .reasonForFiling(ReasonForFiling.INITIAL.toString())
                .submissionId(submissionId).formType(FormType.I765)
                .status(SubmissionState.DRAFT)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms(List.of(form)).build();

        HashMap<String, String> warnings = Maps.newHashMap();
        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.REASON_FOR_FILING)
                .validationWarnings(warnings)
                .failureReasons(List.of(ReasonForFilingValidator.REASON_FOR_FILING_MISMATCH))
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenSubmissionReasonIsEmpty() {
        String formId = UUID.randomUUID().toString();
        String eligibilityCategoryOnForm = "C 11";
        String submissionId = UUID.randomUUID().toString();
        String formReasonForFiling = "1.b.";

        FormFields formFields = FormFields.builder().submissionId(submissionId).formId(formId)
                .reasonForApplySelection(formReasonForFiling)
                .eligibilityCategory(eligibilityCategoryOnForm)
                .build();

        SubmissionForm form = SubmissionForm.builder().build();
        Submission submission = Submission.builder()
                .reasonForFiling(StringUtils.EMPTY)
                .submissionId(submissionId).formType(FormType.I765)
                .status(SubmissionState.DRAFT)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms(List.of(form)).build();

        HashMap<String, String> warnings = Maps.newHashMap();
        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.REASON_FOR_FILING)
                .validationWarnings(warnings)
                .failureReasons(List.of(ReasonForFilingValidator.REASON_FOR_FILING_NOT_DETECTED))
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldFailValidationWhenErrorOccurs() {
        String formId = UUID.randomUUID().toString();
        String eligibilityCategoryOnForm = "C 11";
        String submissionId = UUID.randomUUID().toString();
        String formBadReasonForFiling = "notSupported";

        FormFields formFields = FormFields.builder().submissionId(submissionId).formId(formId)
                .reasonForApplySelection(formBadReasonForFiling)
                .eligibilityCategory(eligibilityCategoryOnForm)
                .build();

        SubmissionForm form = SubmissionForm.builder().build();
        Submission submission = Submission.builder()
                .reasonForFiling(ReasonForFiling.INITIAL.toString())
                .submissionId(submissionId).formType(FormType.I765)
                .status(SubmissionState.DRAFT)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms(List.of(form)).build();

        HashMap<String, String> warnings = Maps.newHashMap();
        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.FAIL).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.REASON_FOR_FILING)
                .validationWarnings(warnings)
                .failureReasons(List.of(ReasonForFilingValidator.REASON_FOR_FILING_UNDEFINED))
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }

    @Test
    void shouldPassWhenReasonsMatch() {
        String formId = UUID.randomUUID().toString();
        String eligibilityCategoryOnForm = "C 11";
        String submissionId = UUID.randomUUID().toString();
        String formReasonForFiling = "1.a.";
        List<String> emptyList = List.of();

        FormFields formFields = FormFields.builder().submissionId(submissionId).formId(formId)
                .reasonForApplySelection(formReasonForFiling)
                .eligibilityCategory(eligibilityCategoryOnForm)
                .build();

        SubmissionForm form = SubmissionForm.builder().build();
        Submission submission = Submission.builder()
                .reasonForFiling(ReasonForFiling.INITIAL.toString())
                .submissionId(submissionId).formType(FormType.I765)
                .status(SubmissionState.DRAFT)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms(List.of(form)).build();

        HashMap<String, String> warnings = Maps.newHashMap();
        ValidationStatus expectedPut = ValidationStatus.builder().status(ValidationResultEnum.PASS).formId(formId)
                .submissionId(submissionId).validator(ValidatorEnum.REASON_FOR_FILING)
                .validationWarnings(warnings)
                .failureReasons(emptyList)
                .build();

        validator.validate(submission, formFields);

        ArgumentCaptor<PutItemEnhancedRequest<ValidationStatus>> putItemCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(validationStatusTable, times(1)).putItem(putItemCaptor.capture());

        PutItemEnhancedRequest<ValidationStatus> actualPut = putItemCaptor.getValue();
        assertThat(actualPut.item(), samePropertyValuesAs(expectedPut, "timestamp"));
    }
}
