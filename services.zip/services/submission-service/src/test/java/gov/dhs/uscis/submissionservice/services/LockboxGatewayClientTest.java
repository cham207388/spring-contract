package gov.dhs.uscis.submissionservice.services;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.models.dto.LockboxSubmission;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import reactor.netty.http.client.HttpClient;
import reactor.test.StepVerifier;

public class LockboxGatewayClientTest {

    public static MockWebServer mockLockboxGateway;
    private LockboxGatewayClient lockboxGatewayClient;
    private LockboxSubmission submission;

    @BeforeEach
    public void setup() throws IOException {
        mockLockboxGateway = new MockWebServer();
        mockLockboxGateway.start();
        submission = new LockboxSubmission();
        submission.setSubmissionId("fakeSubmissionId");

        HttpClient httpClient = HttpClient.create().responseTimeout(Duration.ofSeconds(1));

        WebClient lockboxWebClient = WebClient.builder()
                .baseUrl(String.format("http://localhost:%s", mockLockboxGateway.getPort()))
                .clientConnector(new ReactorClientHttpConnector(httpClient))

                .build();

        lockboxGatewayClient = new LockboxGatewayClient(lockboxWebClient,2,2);
    }

    @Test
    public void shouldReturnAJsonObjectWithManifestId() throws JsonProcessingException {
        var responseBody = new HashMap<String, String>();
        responseBody.put("manifestId", "fakeId");
        mockLockboxGateway.enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                .setBody(new ObjectMapper().writeValueAsString(responseBody)).setResponseCode(200));

        var transmission = new LockboxTransmission();
        transmission.setSubmission(submission);

        var response = lockboxGatewayClient.sendTransmission(transmission);
        var out = response.block();
        assertThat(out).isEqualTo("fakeId");
    }

    @Test
    public void shouldHandleAnErrorResponse() {
        mockLockboxGateway.enqueue(new MockResponse()
                .setResponseCode(500)
                .addHeader("Content-Type", "application/json")
                .setBody("{\"error\": \"500 Error While Processing\"}"));

        var transmission = new LockboxTransmission();
        transmission.setSubmission(submission);

        var response = lockboxGatewayClient.sendTransmission(transmission);

        RuntimeException exception = assertThrows(RuntimeException.class,
                response::block);

        assertTrue(exception.getMessage().contains("Retries exhausted: 2/2"));
    }

    @Test
    public void shouldTryARetry() throws JsonProcessingException {
        var responseBody = new HashMap<String, String>();
        responseBody.put("manifestId", "fakeId");
        mockLockboxGateway
                .enqueue(new MockResponse().setBodyDelay(2, SECONDS).addHeader("Content-Type", "application/json")
                        .setBody(new ObjectMapper().writeValueAsString(responseBody)).setResponseCode(200));
        mockLockboxGateway
                .enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                        .setBody(new ObjectMapper().writeValueAsString(responseBody)).setResponseCode(200));

        var transmission = new LockboxTransmission();
        transmission.setSubmission(submission);

        var response = lockboxGatewayClient.sendTransmission(transmission);
        StepVerifier.create(response)
                .expectNext("fakeId")
                .verifyComplete();
        assertThat(mockLockboxGateway.getRequestCount()).isEqualTo(2);
    }

    @Test
    public void shouldRetrieveManifestIdFromLockboxGateway() throws JsonProcessingException {
        var responseBody = new HashMap<String, String>();
        responseBody.put("manifestId", "fakeId");
        responseBody.put("submissionId", "fakeSubmissionId");
        mockLockboxGateway
                .enqueue(new MockResponse().addHeader("Content-Type", "application/json")
                        .setBody(new ObjectMapper().writeValueAsString(responseBody)).setResponseCode(200));

        var transmission = new LockboxTransmission();
        transmission.setSubmission(submission);

        var response = lockboxGatewayClient.mapManifestToSubmissionId("manifestId");
        StepVerifier.create(response)
                .expectNext("fakeSubmissionId")
                .verifyComplete();
        assertThat(mockLockboxGateway.getRequestCount()).isEqualTo(1);
    }
}
