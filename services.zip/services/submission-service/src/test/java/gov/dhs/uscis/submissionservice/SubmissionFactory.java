package gov.dhs.uscis.submissionservice;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.util.MultiValueMap;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.N400EligibilityCategory;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.models.LockboxStatuses;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.intake.models.dto.SubmissionDto;
import gov.dhs.uscis.intake.models.dto.SubmissionEvidenceDto;
import gov.dhs.uscis.intake.models.dto.SubmissionFormDto;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;

public class SubmissionFactory {

    private static String feeWaiverId = UUID.randomUUID().toString();
    private static String s3Key = "s3Key";

    public static Submission forSubmissionId(String submissionId, String manifestId, FormType formType) {

        EligibilityCategoryEnum eligibilityCategory = formType.equals(FormType.I765) ? I765EligibilityCategory.C11PAROLE
            : N400EligibilityCategory.OTHER;

        ManifestError manifestError = new ManifestError();
        manifestError.setId(UUID.randomUUID().toString());
        manifestError.setErrorCode("404");
        manifestError.setDescription("Bad Request");

        RejectionReason rejectionReason = new RejectionReason();
        rejectionReason.setCode("R-02");
        rejectionReason.setReason("Missing required Data: Applicant Last Name");

        SubmissionEvidence submissionEvidence = new SubmissionEvidence();
        submissionEvidence.setS3Key(s3Key);
        submissionEvidence.setType("type");
        submissionEvidence.setId(UUID.randomUUID().toString());
        submissionEvidence.setMd5Hash("d0bd89fa0d3498d72346c42ab2cf055b");
        submissionEvidence.setName("2x2Photo.png");
        submissionEvidence.setEvidenceGroupType("feeWaiver");
        submissionEvidence.setUploadedAt(ZonedDateTime.now());
        submissionEvidence.setUrl(
                "http://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov/72ab1987-6718-3943-933f-25ddd29d7e34/d02e82b4-8ffa-4917-a263-313ec645d38c/2x2Photo.png");

        SubmissionEvidence feeWaiver = new SubmissionEvidence();
        feeWaiver.setType("type");
        feeWaiver.setId(feeWaiverId);
        feeWaiver.setMd5Hash("e0bd89fa0d3498d72346c42ab2cf011c");
        feeWaiver.setEvidenceGroupType("feeWaiver");
        feeWaiver.setName("I-912.pdf");
        feeWaiver.setUploadedAt(ZonedDateTime.now());
        feeWaiver.setUrl(
                "http://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov/92ab1987-6718-3943-933f-25ddd29d7e34/d02e82b4-8ffa-4917-a263-313ec645d38f/I-912.pdf");

        SubmissionForm submissionForm = new SubmissionForm();
        submissionForm.setFeeTotal(new BigDecimal(100.00));
        submissionForm.setType(formType.getType());
        submissionForm.setEligibilityCategory(eligibilityCategory);
        submissionForm.setId(UUID.randomUUID().toString());
        submissionForm.setMd5Hash("54edee59a60ca972acacdfbea1b2c25");
        submissionForm.setName("2x2Photo.png");
        submissionForm.setValidations(List.of("CORE", "SIGNATURE"));
        submissionForm.setLockboxStatus("PENDING");
        submissionForm.setRejectionReasons(List.of(rejectionReason));
        submissionForm.setPaymentTrackingId("54edee59a60ca972acacdfbea1b2c25");
        submissionForm.setUploadedAt(ZonedDateTime.now());
        submissionForm.setS3Key(s3Key);
        submissionForm.setAttestedS3Key(s3Key);
        submissionForm.setUrl(
                "http://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov/62ab1987-6718-3943-933f-25ddd29d7e34/d02e82b4-8ffa-4917-a263-313ec645d38b/I765.pdf");

        final Submission submission = new Submission();
        submission.setFormType(formType);
        submission.setEvidences(List.of(submissionEvidence));
        submission.setMyUscisId(UUID.randomUUID().toString());
        submission.setSubmissionId(submissionId);
        submission.setManifestId(manifestId);
        submission.setEligibilityCategory(eligibilityCategory);
        submission.setStatus(SubmissionState.DRAFT);
        submission.setLockboxStatus(LockboxStatuses.PENDING);
        submission.setLockboxErrors(List.of(manifestError));
        submission.setFeeTotal(new BigDecimal(100.00));
        submission.setForms(new ArrayList<SubmissionForm>(List.of(submissionForm)));
        submission.setFeeWaiver(feeWaiver);
        submission.setUserRequestedFeeWaiver(true);
        submission.setLockedAt(ZonedDateTime.now());
        submission.setTimestamp(ZonedDateTime.now());
        submission.setUpdatedAt(ZonedDateTime.now());
        submission.setSubmittedAt(ZonedDateTime.now());
        submission.setLockedAt(ZonedDateTime.now());
        submission.setApplicant(UserInformation.builder().myUscisId(UUID.randomUUID().toString()).accountType(AccountType.APPLICANT)
                .email("some-email").build());
        submission.setAttested(true);
        submission.setAttestedAt(ZonedDateTime.now());
        submission.setImmvi(true);
        submission.setReasonForFiling(ReasonForFiling.INITIAL.toString());
        submission.setAttestationSignature("signature");
        submission.setHasReviewedSignature(true);
        submission.setUserRequestedPartialFeeWaiver(false);
        submission.setUserIsEligibleForFeeWaiver(false);
        return submission;
    }

    public static SubmissionRequest aNewSubmission(String myUscisId) {
        return SubmissionRequest.builder()
                .accountType(AccountType.APPLICANT)
                .formType(FormType.I765)
                .build();
    }

    public static MultiValueMap<String, HttpEntity<?>> attachedForm(String fileName,
            String uscisId,
            String submissionId, 
            String formType) {
        UploadRequest uploadRequest = new UploadRequest(fileName, true,"FORM", "md5Hash", formType);
        MultipartBodyBuilder formRequest = new MultipartBodyBuilder();
        formRequest.part("file", new ClassPathResource(fileName));
        formRequest.part("uploadRequest", uploadRequest);
        return formRequest.build();
    }

    public static MultiValueMap<String, HttpEntity<?>> attachedFeeWaiver(String fileName,
            String myUscisId,
            String submissionId) {
        UploadFeeWaiverRequest uploadRequest = new UploadFeeWaiverRequest(fileName);
        MultipartBodyBuilder formRequest = new MultipartBodyBuilder();
        formRequest.part("file", new ClassPathResource(fileName));
        formRequest.part("uploadFeeWaiverRequest", uploadRequest);
        return formRequest.build();
    }

    public static MultiValueMap<String, HttpEntity<?>> attachedEvidence(
            String uscisId,
            String submissionId,
            String type,
            String evidenceGroupType,
            String ...files) {
        List<UploadEvidenceRequest> uploadRequests = Arrays.stream(files)
            .map(file -> new UploadEvidenceRequest(file, type, evidenceGroupType))
            .toList();
        List<ClassPathResource> resources = Arrays.stream(files)
            .map(file -> new ClassPathResource(file))
            .toList();
        MultipartBodyBuilder formRequest = new MultipartBodyBuilder();
        resources.forEach(resource -> formRequest.part("files", resource, MediaType.APPLICATION_OCTET_STREAM));
        uploadRequests.forEach(request -> formRequest.part("uploadEvidenceRequests", request));
        return formRequest.build();
    }

    public static SubmissionDto forSubmissionDtoId(String submissionId, String manifestId, FormType formType) {
        EligibilityCategoryEnum eligibilityCategory = formType.equals(FormType.I765) ? I765EligibilityCategory.C11PAROLE
        : N400EligibilityCategory.OTHER;

        ManifestError manifestError = new ManifestError();
        manifestError.setId("manifestId");
        manifestError.setErrorCode("404");
        manifestError.setDescription("Bad Request");

        RejectionReason rejectionReason = new RejectionReason();
        rejectionReason.setCode("R-02");
        rejectionReason.setReason("Missing required Data: Applicant Last Name");

        SubmissionEvidenceDto evidence = SubmissionEvidenceDto.builder().id("345345")
                .id("345345")
                .evidenceGroupType("type")
                .uploadedAt(ZonedDateTime.now())
                .type(manifestId)
                .md5Hash("d0bd89fa0d3498d72346c42ab2cf055b")
                .name("2x2Photo.png").build();

        SubmissionEvidenceDto feeWaiver = SubmissionEvidenceDto.builder().id(feeWaiverId)
                .type("type")
                .id(feeWaiverId)
                .evidenceGroupType("type")
                .uploadedAt(ZonedDateTime.now())
                .md5Hash("e0bd89fa0d3498d72346c42ab2cf011c")
                .name("I-912.pdf").build();

        SubmissionFormDto submissionForm = SubmissionFormDto.builder().feeTotal(new BigDecimal(100))
                .feeTotal(new BigDecimal(100))
                .eligibilityCategory(eligibilityCategory)
                .id("123123")
                .name("2x2Photo.png")
                .rejectionReasons(List.of(rejectionReason))
                .paymentTrackingId("54edee59a60ca972acacdfbea1b2c25")
                .uploadedAt(ZonedDateTime.now())
                .type(formType.getType()).eligibilityCategory(eligibilityCategory).id("123123")
                .md5Hash("54edee59a60ca972acacdfbea1b2c25").name("2x2Photo.png")
                .validations(List.of("CORE", "SIGNATURE"))
                .lockboxStatus("PENDING").rejectionReasons(List.of(rejectionReason)).build();

        final SubmissionDto submission = SubmissionDto.builder().myUscisId("anonymousUser").submissionId(submissionId)
                .myUscisId("anonymousUser")
                .submissionId(submissionId)
                .eligibilityCategory(eligibilityCategory)
                .lockboxErrors(List.of(manifestError))
                .forms(List.of(submissionForm))
                .userRequestedFeeWaiver(true)
                .timestamp(ZonedDateTime.now())
                .updatedAt(ZonedDateTime.now())
                .submittedAt(ZonedDateTime.now())
                .attested(true)
                .attestedAt(ZonedDateTime.now())
                .immvi(true)
                .reasonForFiling(ReasonForFiling.INITIAL.toString())
                .attestationSignature("signature")
                .hasReviewedSignature(true)
                .userRequestedPartialFeeWaiver(true)
                .userIsEligibleForFeeWaiver(true)
                .formType(formType)
                .evidences(List.of(evidence))
                .manifestId(manifestId).eligibilityCategory(eligibilityCategory)
                .status(SubmissionState.DRAFT)
                .lockboxStatus(LockboxStatuses.PENDING).lockboxErrors(List.of(manifestError))
                .feeTotal(new BigDecimal(100)).forms(List.of(submissionForm))
                .feeWaiver(feeWaiver).userRequestedFeeWaiver(true)
                .applicant(UserInformation.builder().myUscisId("some-id").accountType(AccountType.APPLICANT)
                        .email("some-email").build())
                .build();
        return submission;
    }
}