package gov.dhs.uscis.submissionservice.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

import gov.dhs.uscis.submissionservice._testutils.LocalDbCreationRule;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import com.google.common.collect.Maps;

import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ValidationStatus;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.ScanRequest;

public class ValidationStatusRepositoryTest {
  private static final String TABLE_NAME = "default-ValidationStatus";

  private final String submissionId = UUID.randomUUID().toString();
  private final String formId = UUID.randomUUID().toString();
  private static final HashMap<String, String> emptyHashMap = Maps.newHashMap();

  @RegisterExtension
  static LocalDbCreationRule localDynamoDb = new LocalDbCreationRule();

  private static DynamoDbClient dynamoDbClient;
  private static DynamoDbEnhancedClient dynamoDbEnhancedClient;
  private static DynamoDbTable<ValidationStatus> validationStatusTable;
  private static ValidationStatusRepository validationStatusRepository;    

  @BeforeAll
  private static void before() {

    dynamoDbClient = DynamoDbClient
    .builder()
    .endpointOverride(URI.create(String.format("http://localhost:%s", localDynamoDb.getPort())))
    .build();

    dynamoDbEnhancedClient = DynamoDbEnhancedClient
            .builder()
            .dynamoDbClient(dynamoDbClient)
            .build();

    validationStatusTable = dynamoDbEnhancedClient.table(TABLE_NAME, TableSchema.fromBean(ValidationStatus.class));
    validationStatusTable.createTable();

    validationStatusRepository = new ValidationStatusRepository(validationStatusTable);

  }

  @BeforeEach
  private void beforeEach() {
    dynamoDbClient.waiter().waitUntilTableExists(b -> b.tableName(TABLE_NAME));
  }

  @AfterEach
  private void afterEach() {
    validationStatusTable.deleteTable();
    validationStatusTable.createTable();
  }

  @Test
  void getByFormId_shouldSucceed() {
    ValidationStatus s = validationStatusRepository.save(generate());
    List<ValidationStatus> actual = validationStatusRepository.getByFileId(s.getFormId());
    assertThat(actual.get(0), samePropertyValuesAs(s));
  }

  @Test
  void save_shouldSucceed() {
    ValidationStatus actual = validationStatusRepository.save(generate());
    assertEquals(generate(), actual);
  }

  @Test
  void update_shouldSucceed() {
    ValidationStatus expected = validationStatusRepository.save(generate());
    expected.setStatus(ValidationResultEnum.FAIL);
    expected.setFailureReasons(List.of("There is an error"));

    ValidationStatus actual = validationStatusRepository.update(expected);

    assertEquals(1, count());
    assertEquals(expected, actual);
  }

  @Test
  void deleteById_shouldAlwaysSucceed() {
    List<ValidationStatus> vStatusList = saveList();
    String docId = vStatusList.get(0).getFormId();
    ValidatorEnum validator = vStatusList.get(0).getValidator();
    assertEquals(3, count());
    validationStatusRepository.deleteById(docId, validator);
    assertEquals(2, count());
    assertDoesNotThrow(() -> validationStatusRepository.deleteById(docId, validator));
  }

  private int count() {
    ScanRequest request = ScanRequest.builder()
        .tableName(validationStatusTable.tableName())
        .select("COUNT").build();
    return dynamoDbClient.scan(request).count();
  }

  private List<ValidationStatus> saveList() {
    List<ValidationStatus> vStatusList = generateList();
    for (ValidationStatus vStatus : vStatusList) {
      validationStatusRepository.save(vStatus);
    }
    return vStatusList;
  }

  private ValidationStatus generate() {
    return ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
        .failureReasons(List.of()).validationWarnings(emptyHashMap).build();
  }

  private List<ValidationStatus> generateList() {
    ValidationStatus eligibilityCategory = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
        .failureReasons(List.of()).validationWarnings(emptyHashMap).build();
    ValidationStatus core = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.PASS).validator(ValidatorEnum.CORE)
        .failureReasons(List.of()).validationWarnings(emptyHashMap).build();
    ValidationStatus signature = ValidationStatus.builder().formId(formId).submissionId(submissionId)
        .status(ValidationResultEnum.FAIL).validator(ValidatorEnum.SIGNATURE)
        .failureReasons(List.of("Signature does not seem to be present")).validationWarnings(emptyHashMap)
        .build();
    return Arrays.asList(eligibilityCategory, core, signature);
  }

}
