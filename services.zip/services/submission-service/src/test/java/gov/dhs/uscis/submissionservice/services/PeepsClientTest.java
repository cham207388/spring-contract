package gov.dhs.uscis.submissionservice.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.time.Duration;

import org.junit.jupiter.api.Test;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.intake.exceptions.MyUscisProcessingException;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import reactor.netty.http.client.HttpClient;

public class PeepsClientTest {

    private static final String ATTORNEY_ID = "attorneyId";
    private static final String RETRIEVE_USER_PROFILE_LATEST_REPSONSE = "{\n" + //
            "  \"data\": {\n" + //
            "      \"firstName\": \"carlyle@test.com\",\n" + //
            "      \"middleName\": \"8ef5257f-3d64-484c-8a18-94eddbfd51c7\",\n" + //
            "      \"lastName\": null,\n" + //
            "      \"alienNumber\": \"123456789\",\n" + //
            "      \"dateOfBirth\": \"01/01/1990\"\n" + //
            "  },\n" + //
            "  \"error\": null\n" + //
            "}";
    @Test
    public void shouldFindUserProfileWhenExists() throws IOException {
        String alienNumber = "123456789";
        var mockPeepsService = new MockWebServer();
        mockPeepsService.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
                .setBody(RETRIEVE_USER_PROFILE_LATEST_REPSONSE));
        mockPeepsService.start();

        HttpClient httpClient = HttpClient.create().responseTimeout(Duration.ofSeconds(1));

        WebClient peepsWebClient = WebClient.builder()
                .baseUrl(String.format("http://localhost:%s", mockPeepsService.getPort()))
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();

        var peepsClient = new PeepsClient(peepsWebClient);
        var response = peepsClient.retrieveUserInfo(ATTORNEY_ID);
        assertThat(response.data().getAlienNumber()).isEqualTo(alienNumber);
        // assertThat(response.data().get(0).accountUUID()).isEqualTo("8ef5257f-3d64-484c-8a18-94eddbfd51c7");

        mockPeepsService.close();
    }

    @Test
    public void shouldThrowWhen404() throws IOException {
        var mockPeepsService = new MockWebServer();
        mockPeepsService.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(404));
        mockPeepsService.start();

        HttpClient httpClient = HttpClient.create().responseTimeout(Duration.ofSeconds(1));

        WebClient peepsWebClient = WebClient.builder()
                .baseUrl(String.format("http://localhost:%s", mockPeepsService.getPort()))
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();

        var peepsClient = new PeepsClient(peepsWebClient);
        assertThrows(MyUscisProcessingException.class, () -> peepsClient.retrieveUserInfo(ATTORNEY_ID));
        mockPeepsService.close();
    }

    // @Test
    // public void shouldSendRequestToMyUSCISToAddICAMUser() throws IOException {
    // var mockPeepsService = new MockWebServer();
    // mockPeepsService.enqueue(new MockResponse().addHeader("Content-Type",
    // "application/json").setResponseCode(200)
    // .setBody(INVITE_USER_RESPONSE));
    // mockPeepsService.start();

    // HttpClient httpClient =
    // HttpClient.create().responseTimeout(Duration.ofSeconds(1));

    // WebClient peepsWebClient = WebClient.builder()
    // .baseUrl(String.format("http://localhost:%s", mockPeepsService.getPort()))
    // .clientConnector(new ReactorClientHttpConnector(httpClient))
    // .build();

    // var peepsClient = new PeepsClient(peepsWebClient);
    // var response = peepsClient.inviteClient(ATTORNEY_ID, EMAIL_ADDRESS,
    // "fakeSubmissionId");

    // assertThat(response.getClientId()).isEqualTo("219657e9-b173-48b9-8ece-5955092812ea");
    // mockPeepsService.close();
    // }

    // @Test
    // public void shouldThrowExceptionIfNoDataIsPresentInResponse() throws
    // IOException {
    // var mockPeepsService = new MockWebServer();
    // mockPeepsService.enqueue(new MockResponse().addHeader("Content-Type",
    // "application/json").setResponseCode(400)
    // .setBody("{ \"data\": null }"));
    // mockPeepsService.start();

    // HttpClient httpClient =
    // HttpClient.create().responseTimeout(Duration.ofSeconds(1));

    // WebClient peepsWebClient = WebClient.builder()
    // .baseUrl(String.format("http://localhost:%s", mockPeepsService.getPort()))
    // .clientConnector(new ReactorClientHttpConnector(httpClient))
    // .build();

    // var peepsClient = new PeepsClient(peepsWebClient);
    // assertThrows(MyUscisProcessingException.class,
    // () -> peepsClient.inviteClient(ATTORNEY_ID, EMAIL_ADDRESS,
    // "fakeSubmissionId"));
    // }

}
