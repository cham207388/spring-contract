package gov.dhs.uscis.submissionservice.controllers;

import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;

public class ElISDownloaderUrlMapperTest {

    @Test
    public void shouldReplaceUrlWithProviedUrl(){
        var mapper = new ElISDownloaderUrlMapper("http://fake");
        Submission submission = Submission.builder().build();
        var evidence = SubmissionEvidence.builder().build();
        var feeWaiver = SubmissionEvidence.builder().build();
        var form = SubmissionForm.builder().build();

        evidence.setUrl("http://original-url/csai-intake-downloader/evidence");
        feeWaiver.setUrl("http://original-url/csai-intake-downloader/feeWaiver");
        form.setUrl("http://original-url/csai-intake-downloader/form");

        submission.setEvidences(asList(evidence));
        submission.setFeeWaiver(feeWaiver);
        submission.setForms(asList(form));

        mapper.transform(submission);

        assertThat( evidence.getUrl()).isEqualTo("http://fake/evidence");
        assertThat( feeWaiver.getUrl()).isEqualTo("http://fake/feeWaiver");
        assertThat( form.getUrl()).isEqualTo("http://fake/form");
    }

    @Test
    public void shouldReplaceWithTestUrlLikeProductionEnvironment(){
        var mapper = new ElISDownloaderUrlMapper("https://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov");
        Submission submission = Submission.builder().build();
        var evidence = SubmissionEvidence.builder().build();
        var feeWaiver = SubmissionEvidence.builder().build();
        var form = SubmissionForm.builder().build();

        evidence.setUrl("https://uscis-dev.api-nonprod.uscis.dhs.gov/csai-intake-downloader/evidence/16aaf5f5-677e-3622-ad81-3180425ac2d8/1f1af74d-e6a1-437b-ae90-d0f2a14aa3ba/a9acea12c.jpeg");
        feeWaiver.setUrl("https://uscis-dev.api-nonprod.uscis.dhs.gov/csai-intake-downloader/evidence/16aaf5f5-677e-3622-ad81-3180425ac2d8/1f1af74d-e6a1-437b-ae90-d0f2a14aa3ba/97d6aa7e6.png");
        form.setUrl("https://uscis-dev.api-nonprod.uscis.dhs.gov/csai-intake-downloader/16aaf5f5-677e-3622-ad81-3180425ac2d8/1f1af74d-e6a1-437b-ae90-d0f2a14aa3ba/9210e8fe2.pdf");

        submission.setEvidences(asList(evidence));
        submission.setFeeWaiver(feeWaiver);
        submission.setForms(asList(form));

        mapper.transform(submission);

        assertThat( evidence.getUrl()).isEqualTo("https://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov/evidence/16aaf5f5-677e-3622-ad81-3180425ac2d8/1f1af74d-e6a1-437b-ae90-d0f2a14aa3ba/a9acea12c.jpeg");
        assertThat( feeWaiver.getUrl()).isEqualTo("https://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov/evidence/16aaf5f5-677e-3622-ad81-3180425ac2d8/1f1af74d-e6a1-437b-ae90-d0f2a14aa3ba/97d6aa7e6.png");
        assertThat( form.getUrl()).isEqualTo("https://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov/16aaf5f5-677e-3622-ad81-3180425ac2d8/1f1af74d-e6a1-437b-ae90-d0f2a14aa3ba/9210e8fe2.pdf");
    }
}