package gov.dhs.uscis.submissionservice.validators;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import jakarta.validation.ConstraintValidatorContext;

@ExtendWith(MockitoExtension.class)
public class RequestedFeeWaiverValidatorTest {
    @Mock
    FeeWaiverEvidenceRequired constraintAnnotation;

    @Mock
    private ConstraintValidatorContext constraintValidatorContext;

    @Test
    public void shouldFailWhenFeeWaiverRequestedAndFeeWaiverIsNull() {

        FeeWaiverEvidenceRequiredValidator RequestedFeeWaiverValidator = new FeeWaiverEvidenceRequiredValidator();
        RequestedFeeWaiverValidator.initialize(constraintAnnotation);

        FinalSubmissionDto finalSubmissionDto = Instancio.create(FinalSubmissionDto.class);
        finalSubmissionDto.setUserRequestedFeeWaiver(true);
        finalSubmissionDto.setFeeWaiver(null);
        
        boolean result = RequestedFeeWaiverValidator.isValid(finalSubmissionDto, constraintValidatorContext);
        assertFalse(result);
    }

    @Test
    public void shouldPassWhenFeeWaiverRequestedFalse() {

        FeeWaiverEvidenceRequiredValidator RequestedFeeWaiverValidator = new FeeWaiverEvidenceRequiredValidator();
        RequestedFeeWaiverValidator.initialize(constraintAnnotation);

        FinalSubmissionDto finalSubmissionDto = Instancio.create(FinalSubmissionDto.class);
        finalSubmissionDto.setUserRequestedFeeWaiver(false);
        finalSubmissionDto.setFeeWaiver(null);

        boolean result = RequestedFeeWaiverValidator.isValid(finalSubmissionDto, constraintValidatorContext);
        assertTrue(result);
    }
    @Test
    public void shouldPassWhenFeeWaiverRequestedFalseAndFeeWaiverNotNull() {

        FeeWaiverEvidenceRequiredValidator RequestedFeeWaiverValidator = new FeeWaiverEvidenceRequiredValidator();
        RequestedFeeWaiverValidator.initialize(constraintAnnotation);

        FinalSubmissionDto finalSubmissionDto = Instancio.create(FinalSubmissionDto.class);
        finalSubmissionDto.setUserRequestedFeeWaiver(false);
        finalSubmissionDto.setFeeWaiver(Instancio.create(SubmissionEvidence.class));

        boolean result = RequestedFeeWaiverValidator.isValid(finalSubmissionDto, constraintValidatorContext);
        assertTrue(result);
    }
}
