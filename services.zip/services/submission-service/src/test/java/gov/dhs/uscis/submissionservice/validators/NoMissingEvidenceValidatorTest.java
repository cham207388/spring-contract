package gov.dhs.uscis.submissionservice.validators;

import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import jakarta.servlet.http.Part;

import static org.mockito.BDDMockito.given;
import static org.instancio.Select.field;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

public class NoMissingEvidenceValidatorTest {

    NoMissingEvidenceValidator validator = new NoMissingEvidenceValidator();
    

    @Test
    void shouldReturnTrueWhenEvidenceAndFilesMatch() {
        String filename = "matching.pdf";
        Part mockPart = mock(Part.class);
        given(mockPart.getSubmittedFileName()).willReturn(filename);
        List<Part> files = List.of(mockPart);
        List<UploadEvidenceRequest> evidences = Instancio.ofList(UploadEvidenceRequest.class).size(1)
                                                .set(field(UploadEvidenceRequest::fileName), filename)
                                                .create();
        Submission submission = Instancio.of(Submission.class)
                            .set(field(Submission::getEvidences), null)
                            .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                            .set(field(Submission::getFormType), FormType.I765)
                            .create();
        EvidenceRequest request = new EvidenceRequest(evidences, files, submission);

        assertTrue(validator.isValid(request, null));
    }

    @Test
    void shouldReturnFalseWhenEvidenceAndFilesMismatchNames() {
        String filename = "matching.pdf";
        String otherFilename = "mismatch.pdf";
        Part mockPart = mock(Part.class);
        given(mockPart.getSubmittedFileName()).willReturn(filename);
        List<Part> files = List.of(mockPart);
        List<UploadEvidenceRequest> evidences = Instancio.ofList(UploadEvidenceRequest.class).size(1)
                                                .set(field(UploadEvidenceRequest::fileName), otherFilename)
                                                .create();
        Submission submission = Instancio.of(Submission.class)
                            .set(field(Submission::getEvidences), null)
                            .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                            .set(field(Submission::getFormType), FormType.I765)
                            .create();
        EvidenceRequest request = new EvidenceRequest(evidences, files, submission);

        assertFalse(validator.isValid(request, null));
    }

    @Test
    void shouldReturnFalseWhenEvidenceAndFilesMismatch() {
        String filename = "matching.pdf";
        Part mockPart = mock(Part.class);
        given(mockPart.getSubmittedFileName()).willReturn(filename);
        List<Part> files = List.of(mockPart);
        List<UploadEvidenceRequest> evidences = Instancio.ofList(UploadEvidenceRequest.class).size(2)
                                                .set(field(UploadEvidenceRequest::fileName), filename)
                                                .create();
        Submission submission = Instancio.of(Submission.class)
                            .set(field(Submission::getEvidences), null)
                            .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                            .set(field(Submission::getFormType), FormType.I765)
                            .create();
        EvidenceRequest request = new EvidenceRequest(evidences, files, submission);

        assertFalse(validator.isValid(request, null));
    }

    //This case correspond to how Opera Browser sends the part filenames
    //which contains the full path on the host 
    //in this case we only want to compare that it contains not that they are the same
    @Test
    void shouldReturnTrueWhenEvidenceAndFileAreSimilar() {
        String filename = "matching.pdf";
        String fullPath = "/some/path/to/" + filename;
        Part mockPart = mock(Part.class);
        given(mockPart.getSubmittedFileName()).willReturn(fullPath);
        List<Part> files = List.of(mockPart);
        List<UploadEvidenceRequest> evidences = Instancio.ofList(UploadEvidenceRequest.class).size(1)
                                                .set(field(UploadEvidenceRequest::fileName), filename)
                                                .create();
        Submission submission = Instancio.of(Submission.class)
                            .set(field(Submission::getEvidences), null)
                            .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                            .set(field(Submission::getFormType), FormType.I765)
                            .create();
        EvidenceRequest request = new EvidenceRequest(evidences, files, submission);

        assertTrue(validator.isValid(request, null));
    }

    //This case correspond to how Opera Browser sends the part filenames
    //which contains the full path on the host 
    //in this case we only want to compare that it contains not that they are the same
    @Test
    void shouldReturnTrueWhenEvidencesAndFilesAreSimilar() {
        String firstFile = "matching.pdf";
        String secondFile = "second.pdf";
        String fullPath = "/some/path/to/";
        String otherPath = "/some/other/path/";
        Part firstPart = mock(Part.class);
        given(firstPart.getSubmittedFileName()).willReturn(fullPath + firstFile);
        Part secondPart = mock(Part.class);
        given(secondPart.getSubmittedFileName()).willReturn(otherPath + secondFile);
        List<Part> files = List.of(firstPart, secondPart);
        UploadEvidenceRequest firstRequest = Instancio.of(UploadEvidenceRequest.class)
                                                .set(field(UploadEvidenceRequest::fileName), firstFile)
                                                .create();
        UploadEvidenceRequest secondRequest = Instancio.of(UploadEvidenceRequest.class)
                                                .set(field(UploadEvidenceRequest::fileName), secondFile)
                                                .create();
        List<UploadEvidenceRequest> evidences = List.of(firstRequest, secondRequest);
        Submission submission = Instancio.of(Submission.class)
                            .set(field(Submission::getEvidences), null)
                            .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.C8)
                            .set(field(Submission::getFormType), FormType.I765)
                            .create();
        EvidenceRequest request = new EvidenceRequest(evidences, files, submission);

        assertTrue(validator.isValid(request, null));
    }
}
