package gov.dhs.uscis.submissionservice.services;

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.ActionRequested;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.RequestedAction;
import gov.dhs.uscis.intake.enums.ResidencyStatus;
import gov.dhs.uscis.intake.enums.eligibility.I129EEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I129REligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I129TNEligibilitySubcategory;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.additionalinformation.AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129EAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129H1BAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129H2AAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129RAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129TNAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I130AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I140AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I485AAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I485AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I751AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I765AdditionalInformation;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I129EFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I129H1BFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I129RFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I129TNFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I140FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485AFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I765FormSpecificInfo;
import lombok.extern.slf4j.Slf4j;

@ExtendWith(MockitoExtension.class)
@Slf4j
class AdditionalInformationFactoryTest {

    @Mock
    private FormService formService;

    private Submission mockSubmission(FormType type, FormSpecificInfo specificInfo) {
        Submission submission = mock(Submission.class);
        SubmissionForm form = SubmissionForm.builder()
                .type(type.getType())
                .formSpecificInfo(specificInfo)
                .build();
        List<SubmissionForm> forms = List.of(form);
        submission.setFormSpecificInfo(specificInfo);
        when(submission.getForms()).thenReturn(forms);
        return submission;
    }

    @Test
    @DisplayName("Should create I130 Additional Information Correctly")
    void shouldCreateI130AdditionalInfo() {
        Submission submission = mockSubmission(FormType.I130, null);
        when(submission.getIsUSCitizen()).thenReturn(ResidencyStatus.USC);
        FormType formType = FormType.I130;

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I130AdditionalInformation);
        I130AdditionalInformation info = (I130AdditionalInformation) result.get();
        assertEquals(info.getIsUSCitizen(), ResidencyStatus.USC);
        assertEquals(FormType.I130.getType(), info.getFormType());

        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should create I129H2 Additional Information Correctly")
    void shouldCreateI129H2AdditionalInfo() {
        Submission submission = mockSubmission(FormType.I129H2A, null);
        when(submission.getReasonForFiling()).thenReturn(RequestedAction.NOTIFY_OFFICE.toString());
        FormType formType = FormType.I129H2A;

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I129H2AAdditionalInformation);
        I129H2AAdditionalInformation info = (I129H2AAdditionalInformation) result.get();
        assertEquals(info.getRequestedAction(), RequestedAction.NOTIFY_OFFICE);
        assertEquals(FormType.I129H2A.getType(), info.getFormType());

        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should create I129H1B Additional Information Correctly")
    void shouldCreateI1129H1BAdditionalInfo() {
        I129H1BFormSpecificInfo formSpecificInfo = new I129H1BFormSpecificInfo();
        formSpecificInfo.setActionRequested(ActionRequested.NOTIFY_CONSULATE);

        Submission submission = mockSubmission(FormType.I129H1B, formSpecificInfo);
        FormType formType = FormType.I129H1B;

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I129H1BAdditionalInformation);
        I129H1BAdditionalInformation info = (I129H1BAdditionalInformation) result.get();
        assertEquals(info.getActionRequested(), ActionRequested.NOTIFY_CONSULATE);
        assertEquals(FormType.I129H1B.getType(), info.getFormType());

        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should create I129E Additional Information Correctly")
    void shouldCreateI1129EAdditionalInfo() {
    	FormType formType = FormType.I129E;
        Submission submission = mockSubmission(formType, null);
        submission.getForms().get(0).setEligibilitySubcategory(I129EEligibilitySubcategory.E1_TREATY_TRADER);

        I129EFormSpecificInfo formSpecificInfo = new I129EFormSpecificInfo(ActionRequested.NOTIFY_CONSULATE);
        submission.getForms().get(0).setFormSpecificInfo(formSpecificInfo);

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission, formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I129EAdditionalInformation);
        I129EAdditionalInformation info = (I129EAdditionalInformation) result.get();
        assertEquals(I129EEligibilitySubcategory.E1_TREATY_TRADER, info.getImmigrationClassCode());
        assertEquals(ActionRequested.NOTIFY_CONSULATE, info.getActionRequested());
        assertEquals(formType.getType(), info.getFormType());

        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should create I129R Additional Information Correctly")
    void shouldCreateI1129RAdditionalInfo() {
    	FormType formType = FormType.I129R;
        Submission submission = mockSubmission(formType, null);
        submission.getForms().get(0).setEligibilitySubcategory(I129REligibilitySubcategory.R1_RELIGIOUS_WORKER);

        I129RFormSpecificInfo formSpecificInfo = new I129RFormSpecificInfo(ActionRequested.NOTIFY_CONSULATE);
        submission.getForms().get(0).setFormSpecificInfo(formSpecificInfo);

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission, formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I129RAdditionalInformation);
        I129RAdditionalInformation info = (I129RAdditionalInformation) result.get();
        assertEquals(I129REligibilitySubcategory.R1_RELIGIOUS_WORKER, info.getImmigrationClassCode());
        assertEquals(ActionRequested.NOTIFY_CONSULATE, info.getActionRequested());
        assertEquals(formType.getType(), info.getFormType());

        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should create I129TN Additional Information Correctly")
    void shouldCreateI1129TNAdditionalInfo() {
    	FormType formType = FormType.I129TN;
        Submission submission = mockSubmission(formType, null);
        submission.getForms().get(0).setEligibilitySubcategory(I129TNEligibilitySubcategory.TN1_FREE_TRADE_CANADA);

        I129TNFormSpecificInfo formSpecificInfo = new I129TNFormSpecificInfo(ActionRequested.NOTIFY_CONSULATE);
        submission.getForms().get(0).setFormSpecificInfo(formSpecificInfo);

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission, formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I129TNAdditionalInformation);
        I129TNAdditionalInformation info = (I129TNAdditionalInformation) result.get();
        assertEquals(I129TNEligibilitySubcategory.TN1_FREE_TRADE_CANADA, info.getImmigrationClassCode());
        assertEquals(ActionRequested.NOTIFY_CONSULATE, info.getActionRequested());
        assertEquals(formType.getType(), info.getFormType());

        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should create I751 Additional Information Correctly")
    void shouldCreateI751AdditionalInfo() {
        Submission submission = mockSubmission(FormType.I751, null);
        FormType formType = FormType.I751;
        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I751AdditionalInformation);
        I751AdditionalInformation info = (I751AdditionalInformation) result.get();
        assertEquals(FormType.I751.getType(), info.getFormType());

        verify(formService, times(1)).addApplicationReasonCodes(submission, FormType.I751);
    }

    @Test
    @DisplayName("Should create I140 Additional Information Correctly")
    void shouldCreateI140AdditionalInfo() {
        I140FormSpecificInfo specificInfo = new I140FormSpecificInfo("12345", false);
        FormType formType = FormType.I140;

        Submission submission = mockSubmission(FormType.I140, specificInfo);

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I140AdditionalInformation);
        I140AdditionalInformation info = (I140AdditionalInformation) result.get();
        assertEquals(FormType.I140.getType(), info.getFormType());

        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should return empty for I140 additional info if specific info is null")
    void shouldReturnEmptyI140AdditionalInfoIsNull() {

        Submission submission = mockSubmission(FormType.I140, null);
        FormType formType = FormType.I140;

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertFalse(result.isPresent());
        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should return empty for I485 additional info if specific info is null")
    void shouldReturnEmptyI485AdditionalInfoIsNull() {

        Submission submission = mockSubmission(FormType.I485, null);
        FormType formType = FormType.I485;

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertFalse(result.isPresent());
        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should create I485 Additional Information Correctly")
    void shouldCreateI485AdditionalInfo() {
        I485FormSpecificInfo specificInfo = new I485FormSpecificInfo();
        specificInfo.setMilitaryVeteran(true);

        Submission submission = mockSubmission(FormType.I485, specificInfo);
        FormType formType = FormType.I485;

        // when(submission.getFormSpecificInfo()).thenReturn(specificInfo);

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I485AdditionalInformation);
        I485AdditionalInformation info = (I485AdditionalInformation) result.get();
        assertTrue(info.isMilitaryVeteran());
        assertEquals(FormType.I485.getType(), info.getFormType());

        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should create I485A Additional Information Correctly")
    void shouldCreateI485AAdditionalInfo() {
        I485AFormSpecificInfo specificInfo = new I485AFormSpecificInfo();
        specificInfo.setApplicantUnder17Unmarried(true);
        FormType formType = FormType.I485A;
        specificInfo.setFormType(formType);

        SubmissionForm form = SubmissionForm.builder()
                .type(formType.getType())
                .formSpecificInfo(specificInfo)
                .build();
        Submission submission = Submission.builder()
                .forms(List.of(form))
                .build();

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertTrue(result.isPresent());
        assertTrue(result.get() instanceof I485AAdditionalInformation);
        I485AAdditionalInformation info = (I485AAdditionalInformation) result.get();
        assertTrue(info.isI817Beneficiary());

        // NOTE: The line below fails due to FormType mismatch in
        // I485AAdditionalInformation
        // assertEquals(FormType.I485A.getType(), info.getFormType());

        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should return empty for I485A additional info if specific info is null")
    void shouldReturnEmptyI485AAdditionalInfoIsNull() {
        FormType formType = FormType.I485A;

        Submission submission = mockSubmission(formType, null);

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertFalse(result.isPresent());
        verifyNoInteractions(formService);
    }

    @Test
    @DisplayName("Should return empty Optional for an unknown form type")
    void shouldReturnEmptyForUnknownFormType() {

        Submission submission = mockSubmission(FormType.G28, null);
        FormType formType = FormType.G28;

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);

        assertFalse(result.isPresent());
        verifyNoInteractions(formService);
    }

    @Test
    void createsI765AdditionalInformation() {
        I765FormSpecificInfo specificInfo = new I765FormSpecificInfo();
        specificInfo.setOnOrAfterApril012024(true);
                specificInfo.setBefore04012024(true);

        specificInfo.setImmvi(true);

        Submission submission = mockSubmission(FormType.I765, specificInfo);
        submission.getForms().get(0).setEligibilityCategory(I765EligibilityCategory.C9);
        FormType formType = FormType.I765;

        Optional<AdditionalInformation> result = AdditionalInformationFactory.createAdditionalInformation(submission,
                formService, formType);
        assertTrue(result.isPresent());
        AdditionalInformation actual = result.get();
        assertInstanceOf(I765AdditionalInformation.class, actual);
        assertEquals(true, ((I765AdditionalInformation) actual).isOnOrAfterApril012024());
        assertEquals(true, ((I765AdditionalInformation) actual).isImmvi());
        assertEquals(true, ((I765AdditionalInformation) actual).isBefore04012024());


        verifyNoInteractions(formService);

    }

}