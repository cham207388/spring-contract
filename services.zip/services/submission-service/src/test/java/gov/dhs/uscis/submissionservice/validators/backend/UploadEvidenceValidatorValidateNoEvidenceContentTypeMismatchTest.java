package gov.dhs.uscis.submissionservice.validators.backend;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.MimeType;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.exception.BackendValidationException;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import gov.dhs.uscis.submissionservice.services.FormService;
import jakarta.servlet.http.Part;

import static gov.dhs.uscis.intake.enums.I765EligibilityCategory.*;
import static gov.dhs.uscis.intake.enums.FormType.I765;
import static gov.dhs.uscis.submissionservice.services.SubmissionService.FEE_WAIVER_EVIDENCE_GROUP;

import static org.instancio.Select.field;


@ExtendWith(MockitoExtension.class)
public class UploadEvidenceValidatorValidateNoEvidenceContentTypeMismatchTest {

    @Mock
    FormService formService;

    @InjectMocks
    UploadEvidenceValidator uploadEvidenceValidator;

    @Test
    void shouldPassForValidFeeWaiverEvidence() {
        List<Part> files = Instancio.ofList(Part.class).size(1).create();
        UploadEvidenceRequest evidence = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::evidenceGroupType), FEE_WAIVER_EVIDENCE_GROUP)
                .create();
        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), null)
                .set(field(Submission::getEligibilityCategory), C8)
                .set(field(Submission::getFormType), I765)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I765.getType())
                        .eligibilityCategory(C8)
                    .build()))
                .create();
        EvidenceRequest request = new EvidenceRequest(List.of(evidence), files, submission);


        assertDoesNotThrow(() -> {
            uploadEvidenceValidator.validateEvidenceWithBackendData(request, FormType.I765.getType());
        });

    }

    @Test
    void shouldPassWhenFileContentTypeMatchWithValidTypes() {
        String groupType = "form-i-94-passport";
        EvidenceGroup group = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getAllowMediaTypes), 
                    List.of(MimeType.valueOf("image/jpg"), MimeType.valueOf("image/jpeg"), MimeType.valueOf("image/png")))
                .create();
        List<Part> files = List.of(
                mock(Part.class),
                mock(Part.class),
                mock(Part.class));
        given(files.get(0).getContentType()).willReturn("image/jpeg");
        given(files.get(1).getContentType()).willReturn("image/jpg");
        given(files.get(2).getContentType()).willReturn("image/png");
        List<UploadEvidenceRequest> evidences = Instancio.ofList(UploadEvidenceRequest.class)
                        .set(field(UploadEvidenceRequest::evidenceGroupType), groupType)
                        .create();
        Submission submission = Instancio.of(Submission.class)
                        .set(field(Submission::getEvidences), null)
                        .set(field(Submission::getEligibilityCategory), C8)
                        .set(field(Submission::getFormType), I765)
                        .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                                .id("mock-id")
                                .type(FormType.I765.getType())
                                .eligibilityCategory(C8)
                            .build()))
                        .create();
        EvidenceRequest request = new EvidenceRequest(evidences, files, submission);

        given(formService.retrieveEvidenceGroup(submission.getFormType().getType(),
                        submission.getEligibilityCategory().getCategory(),
                        groupType)).willReturn(group);
        
        assertDoesNotThrow(() -> {
            uploadEvidenceValidator.validateEvidenceWithBackendData(request, FormType.I765.getType());
        });
    }

    @Test
    void shouldThrowErrorWhenFileContentTypeDoNotMatchWithValidTypes() {
        String groupType = "form-i-94-passport";
        EvidenceGroup group = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getAllowMediaTypes), 
                    List.of(MimeType.valueOf("image/jpg"), MimeType.valueOf("image/jpeg"), MimeType.valueOf("image/png")))
                .create();
        List<Part> files = List.of(
                mock(Part.class),
                mock(Part.class),
                mock(Part.class));
        given(files.get(0).getContentType()).willReturn("image/jpeg");
        given(files.get(1).getContentType()).willReturn("image/jpg");
        given(files.get(2).getContentType()).willReturn("application/pdf");
        List<UploadEvidenceRequest> evidences = Instancio.ofList(UploadEvidenceRequest.class)
                        .set(field(UploadEvidenceRequest::evidenceGroupType), groupType)
                        .create();
        Submission submission = Instancio.of(Submission.class)
                        .set(field(Submission::getEvidences), null)
                        .set(field(Submission::getEligibilityCategory), C8)
                        .set(field(Submission::getFormType), I765)
                        .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                                .id("mock-id")
                                .type(FormType.I765.getType())
                                .eligibilityCategory(C8)
                            .build()))
                        .create();
        EvidenceRequest request = new EvidenceRequest(evidences, files, submission);

        given(formService.retrieveEvidenceGroup(submission.getFormType().getType(),
                        submission.getEligibilityCategory().getCategory(),
                        groupType)).willReturn(group);
        
        assertThrows(BackendValidationException.class, () -> {
            uploadEvidenceValidator.validateEvidenceWithBackendData(request, FormType.I765.getType());
        });
    }
    

}
