package gov.dhs.uscis.submissionservice.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.PFVSEvidenceType;
import gov.dhs.uscis.intake.models.EsignRequest;
import gov.dhs.uscis.intake.models.ValidationRequest;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

@ExtendWith(MockitoExtension.class)
public class SqsServiceTest {
  private SqsClient sqsClient = mock(SqsClient.class);
  private ObjectMapper objectMapper = new ObjectMapper();
  private SqsService sqsService = new SqsService(sqsClient, objectMapper);

  private String validationRequestQueueUrl = "validationRequestQueueUrl";
  private String evidenceValidationRequestQueueUrl = "evidenceValidationRequestQueueUrl";
  private String esignRequestQueueUrl = "esignRequestQueueUrl";
  


  @BeforeEach
    void setUp() {
      ReflectionTestUtils.setField(sqsService, validationRequestQueueUrl, validationRequestQueueUrl);
      ReflectionTestUtils.setField(sqsService, esignRequestQueueUrl, esignRequestQueueUrl);
      ReflectionTestUtils.setField(sqsService, evidenceValidationRequestQueueUrl, evidenceValidationRequestQueueUrl);
    }

  @Test
  void shouldSendValidationRequestMessage() throws JsonMappingException, JsonProcessingException {
    ValidationRequest myMessage = new ValidationRequest("submissionId", "formId", "formId", "myUSCISId", null, null, "s3Key", "I-131", "I-131", 111, 222, null, null, null, List.of());
  
    when(sqsClient.sendMessage(any(SendMessageRequest.class)))
    	.thenReturn(SendMessageResponse.builder().messageId("sfaf23r32fsd").build());
    sqsService.sendValidationRequest(myMessage);
    ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
    verify(sqsClient, times(1)).sendMessage(captor.capture());

    ValidationRequest response = new ObjectMapper().readValue(captor.getValue().messageBody(), ValidationRequest.class);
    
    assertEquals(response, myMessage);
    assertEquals(captor.getValue().queueUrl(), validationRequestQueueUrl);
  }
  
  @Test
  void shouldSendEvidenceValidationRequestMessage() throws JsonMappingException, JsonProcessingException {
    ValidationRequest myMessage = new ValidationRequest("submissionId", "formId", "formId", "myUSCISId", null, null, "s3Key", PFVSEvidenceType.I912.getType(), PFVSEvidenceType.I912.getType(), null, null, null, null, List.of("i-912-form-id"), List.of());
  
    when(sqsClient.sendMessage(any(SendMessageRequest.class)))
    	.thenReturn(SendMessageResponse.builder().messageId("sfaf23r32fsd").build());
    sqsService.sendEvidenceValidationRequest(myMessage);
    ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
    verify(sqsClient, times(1)).sendMessage(captor.capture());

    ValidationRequest response = new ObjectMapper().readValue(captor.getValue().messageBody(), ValidationRequest.class);
    
    assertEquals(response, myMessage);
    assertEquals(captor.getValue().queueUrl(), evidenceValidationRequestQueueUrl);
  }
  
  @Test
  void shouldSendEsignRequestMessage() throws JsonMappingException, JsonProcessingException {
	EsignRequest myMessage = EsignRequest.builder()
								.formId("formId")
								.submissionId("submissionId")
								.role("Petitioner").build();
  
    when(sqsClient.sendMessage(any(SendMessageRequest.class)))
    	.thenReturn(SendMessageResponse.builder().messageId("sfaf23r32fsd").build());
    sqsService.sendEsignRequest(myMessage);
    ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
    verify(sqsClient, times(1)).sendMessage(captor.capture());

    EsignRequest response = new ObjectMapper().readValue(captor.getValue().messageBody(), EsignRequest.class);
    
    assertEquals(response, myMessage);
    assertEquals(captor.getValue().queueUrl(), esignRequestQueueUrl);
  }
  
  @Test
  void shouldFailToSendEsignRequestMessage() throws JsonMappingException, JsonProcessingException {
	  
	ObjectMapper om = Mockito.mock(ObjectMapper.class);
	when(om.writeValueAsString(any())).thenThrow(JsonProcessingException.class);
	
	SqsService mockedOMSqsService = new SqsService(sqsClient, om);
	  
	EsignRequest myMessage = EsignRequest.builder()
								.formId("formId")
								.submissionId("submissionId")
								.role("Petitioner").build();
  
    when(sqsClient.sendMessage(any(SendMessageRequest.class)))
    	.thenReturn(SendMessageResponse.builder().messageId("sfaf23r32fsd").build());
    
    mockedOMSqsService.sendEsignRequest(myMessage);
    
    verify(sqsClient, times(0)).sendMessage(any(SendMessageRequest.class));
  }
  
  @Test
  void shouldFailToSendValidationRequestMessage() throws JsonMappingException, JsonProcessingException {
	  
	ObjectMapper om = Mockito.mock(ObjectMapper.class);
	when(om.writeValueAsString(any())).thenThrow(JsonProcessingException.class);
	
	SqsService mockedOMSqsService = new SqsService(sqsClient, om);
	  
	ValidationRequest myMessage = new ValidationRequest("submissionId", "formId", "formId", "myUSCISId", null, null, "s3Key", "I-131", "I-131", 111, 222, null, null, null, List.of());
	  
    when(sqsClient.sendMessage(any(SendMessageRequest.class)))
    	.thenReturn(SendMessageResponse.builder().messageId("sfaf23r32fsd").build());
    mockedOMSqsService.sendValidationRequest(myMessage);
    
    verify(sqsClient, times(0)).sendMessage(any(SendMessageRequest.class));
  }
  
}
