package gov.dhs.uscis.submissionservice.controllers;

import static java.util.Collections.emptyList;
import static org.instancio.Select.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.exception.NoFormInSubmissionException;
import gov.dhs.uscis.submissionservice.io.MultipartInputStreamFileResource;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceResponse;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import gov.dhs.uscis.submissionservice.models.dto.S3FileInfo;
import gov.dhs.uscis.submissionservice.models.elis.ElisPhotoValidationError;
import gov.dhs.uscis.submissionservice.services.ElisService;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.services.S3Service;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.validators.backend.UploadEvidenceValidator;
import jakarta.servlet.http.Part;
import jakarta.validation.Validator;

@ExtendWith(OutputCaptureExtension.class)
class DocumentControllerTest {

    S3Service s3Service = mock(S3Service.class);
    UploadEvidenceValidator uploadEvidenceValidator = mock(UploadEvidenceValidator.class);
    SubmissionService submissionService = mock(SubmissionService.class);
    ElisService elisService = mock(ElisService.class);
    AuditService auditService = mock(AuditService.class);
    FormService formService = mock(FormService.class);
    Validator validator = mock(Validator.class);
    DocumentController controller = new DocumentController(
            s3Service,
            uploadEvidenceValidator,
            submissionService,
            elisService,
            new ObjectMapper(),
            auditService,
            formService,
            validator);

    private static final String MYUSCIS_ID = UUID.randomUUID().toString();
    private static final String ORG_MYUSCIS_ID = UUID.randomUUID().toString();
    private static final String SUBMISSION_ID = "12345";
    private static final String FORM_ID = "formId";
    

    @BeforeEach
    void setup() {
        when(formService.retrieveEvidenceGroup(anyString(), anyString(), anyString()))
                .thenReturn(EvidenceGroup.builder().maxNumberOfFiles(20).build());
    }

    @Test
    void shouldUpdateSubmissionFromResponseFromPutObjectCall() throws IOException {
        String formId = "formId";
        UploadRequest request = UploadRequest.builder().formType(FormType.I485J.getType()).build();

        Submission originalSubmission = Instancio.of(Submission.class)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485J.getType())
                    .build()))
                .create();
        Submission updatedSubmission = Instancio.of(Submission.class)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485J.getType())
                    .build()))
                .create();
        // Submission submission = Instancio.create(Submission.class);
        SubmissionForm submissionForm = Instancio.create(SubmissionForm.class);
        submissionForm.setId(formId);
        submissionForm.setType(FormType.I485J.getType());
        List<SubmissionForm> forms = new ArrayList<>();
        forms.add(submissionForm);
        updatedSubmission.setForms(forms);

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "hello.pdf",
                MediaType.MULTIPART_FORM_DATA_VALUE,
                "Hello, World!".getBytes());

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)).thenReturn(originalSubmission);
        when(submissionService.updateSubmissionWithForm(originalSubmission, request, file)).thenReturn(updatedSubmission);

        controller.uploadForm(file, request, MYUSCIS_ID, SUBMISSION_ID, ORG_MYUSCIS_ID);

        verify(submissionService, times(1)).retrieveDraftSubmission(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID);
        verify(submissionService, times(1)).updateSubmissionWithForm(originalSubmission, request, file);
    }

    @Test
    void shouldUpdateSubmissionWithEvidence() throws IOException {
        String evidenceId = "evidenceId";
        String s3ObjectKey = "hello.pdf";
        S3FileInfo s3FileInfo = new S3FileInfo(evidenceId, "checksum123", "artifactId", s3ObjectKey);
        SubmissionEvidence submissionEvidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getId), evidenceId)
                .create();
        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getSubmissionId), SUBMISSION_ID)
                .set(field(Submission::getMyUscisId), MYUSCIS_ID)
                .set(field(Submission::getEvidences), List.of(submissionEvidence))
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.A12)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485J.getType())
                        .eligibilityCategory(I765EligibilityCategory.A12)
                    .build()))
                .create();
        UploadEvidenceRequest upload = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::fileName), s3ObjectKey)
                .set(field(UploadEvidenceRequest::evidenceGroupType),
                        submission.getEvidences().get(0).getEvidenceGroupType())
                .create();
        Part file = mock(Part.class);
        when(file.getSubmittedFileName()).thenReturn(s3ObjectKey);
        submission.setEligibilityCategory(I765EligibilityCategory.A12);
        EvidenceRequest request = new EvidenceRequest(List.of(upload), List.of(file), submission);

        when(s3Service.uploadEvidence(MYUSCIS_ID, SUBMISSION_ID, file, upload, submission, FormType.I485J.getType())).thenReturn(s3FileInfo);
        when(submissionService.updateSubmissionWithEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, FORM_ID, upload, s3FileInfo, FormType.I485J.getType()))
                .thenReturn(submission);
        controller.uploadEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, FormType.I485J.getType(), FORM_ID, request);

        verify(s3Service, times(1)).uploadEvidence(MYUSCIS_ID, SUBMISSION_ID, file, upload, submission, FormType.I485J.getType());
        verify(submissionService, times(1)).updateSubmissionWithEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, FORM_ID, upload, s3FileInfo, FormType.I485J.getType());
        verify(auditService, times(1)).addEvent(MYUSCIS_ID, SUBMISSION_ID, ActionPerformed.EVIDENCE_UPLOADED,
                evidenceId);
    }

    @Test
    void shouldUpdateSubmissionWithPhotoEvidence() throws IOException {
        String evidenceId = "evidenceId";
        String s3ObjectKey = "hello.pdf";
        String formId = "fomrId";
        S3FileInfo s3FileInfo = new S3FileInfo(evidenceId, "checksum123", "artifactId", s3ObjectKey);
        SubmissionEvidence submissionEvidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getId), evidenceId)
                .create();
        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), List.of(submissionEvidence))
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.A12)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485J.getType())
                        .eligibilityCategory(I765EligibilityCategory.A12)
                    .build()))
                .create();
        UploadEvidenceRequest upload = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::fileName), s3ObjectKey)
                .set(field(UploadEvidenceRequest::type), "Applicant Photo")
                .set(field(UploadEvidenceRequest::evidenceGroupType), "applicant-photo")
                .create();
        MediaType type = MediaType.IMAGE_JPEG;
        InputStream stream = new ByteArrayInputStream("hello".getBytes());

        Part file = mock(Part.class);
        when(file.getSubmittedFileName()).thenReturn(s3ObjectKey);
        when(file.getContentType()).thenReturn(type.toString());
        when(file.getInputStream()).thenReturn(stream);

        EvidenceRequest request = new EvidenceRequest(List.of(upload), List.of(file), submission);

        when(s3Service.uploadEvidence(MYUSCIS_ID, SUBMISSION_ID, file, upload, submission, FormType.I485J.getType())).thenReturn(s3FileInfo);
        when(submissionService.updateSubmissionWithEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, FORM_ID, upload, s3FileInfo, FormType.I485J.getType()))
                .thenReturn(submission);
        controller.uploadEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, FormType.I485J.getType(), FORM_ID, request);
        verify(elisService, times(1)).validatePhoto(type, new MultipartInputStreamFileResource(stream, s3ObjectKey));
        verify(submissionService, times(1)).updateSubmissionWithEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, FORM_ID, upload, s3FileInfo, FormType.I485J.getType());
    }

    @Test
    void shouldReturnErrorObjectWhenPhotoEvidenceValidationFails(CapturedOutput output) throws IOException {
        String evidenceId = "evidenceId";
        String s3ObjectKey = "hello.pdf";
        S3FileInfo s3FileInfo = new S3FileInfo(evidenceId, "checksum123", "artifactId", s3ObjectKey);
        SubmissionEvidence submissionEvidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getId), evidenceId)
                .create();
        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getEvidences), List.of(submissionEvidence))
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.A12)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485J.getType())
                        .eligibilityCategory(I765EligibilityCategory.A12)
                    .build()))
                .create();
        UploadEvidenceRequest upload = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::fileName), s3ObjectKey)
                .set(field(UploadEvidenceRequest::type), "Applicant Photo")
                .set(field(UploadEvidenceRequest::evidenceGroupType), "applicant-photo")
                .create();

        Part file = mock(Part.class);
        when(file.getSubmittedFileName()).thenReturn(s3ObjectKey);
        when(file.getContentType()).thenReturn("image/jpeg");
        when(file.getInputStream()).thenReturn(new ByteArrayInputStream("hello".getBytes()));

        EvidenceRequest request = new EvidenceRequest(List.of(upload), List.of(file), submission);

        ElisPhotoValidationError expectedErrorA = Instancio.create(ElisPhotoValidationError.class);
        ElisPhotoValidationError expectedErrorB = Instancio.create(ElisPhotoValidationError.class);
        List<ElisPhotoValidationError> errorList = List.of(expectedErrorA, expectedErrorB);

        when(elisService.validatePhoto(any(), any()))
                .thenThrow(
                        new WebClientResponseException(400, null, null, new ObjectMapper().writeValueAsBytes(errorList),
                                null));
        when(s3Service.uploadEvidence(MYUSCIS_ID, SUBMISSION_ID, file, upload, submission, FormType.I485J.getType())).thenReturn(s3FileInfo);
        when(submissionService.updateSubmissionWithEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, FORM_ID, upload, s3FileInfo, FormType.I485J.getType()))
                .thenReturn(submission);

        ResponseEntity<List<UploadEvidenceResponse>> responseEntity = controller.uploadEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, 
                SUBMISSION_ID, FormType.I485J.getType(), FORM_ID, request);
        List<UploadEvidenceResponse> response = responseEntity.getBody();

        assertTrue(response.get(0).hasError());
        List<ElisPhotoValidationError> responseErrors = response.get(0).errors();
        assertFalse(responseErrors.isEmpty());
        assertTrue(responseErrors.contains(expectedErrorA));
        assertTrue(responseErrors.contains(expectedErrorB));

        assertFalse(output.getOut().contains("ERROR"));
    }

    @Test
    void shouldUploadMaxOf5AtATime() throws IOException {
        String evidenceId = "evidenceId";
        String s3ObjectKey = "hello.pdf";
        String formId = "formId";
        S3FileInfo s3FileInfo = new S3FileInfo(evidenceId, "checksum123", "artifactId", s3ObjectKey);
        SubmissionEvidence submissionEvidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getId), evidenceId)
                .create();
        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getSubmissionId), SUBMISSION_ID)
                .set(field(Submission::getMyUscisId), MYUSCIS_ID)
                .set(field(Submission::getEvidences), List.of(submissionEvidence))
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.A12)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485J.getType())
                        .eligibilityCategory(I765EligibilityCategory.A12)
                    .build()))
                .create();
        UploadEvidenceRequest upload = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::fileName), s3ObjectKey)
                .set(field(UploadEvidenceRequest::evidenceGroupType),
                        submission.getEvidences().get(0).getEvidenceGroupType())
                .create();
        Part file = mock(Part.class);
        when(file.getSubmittedFileName()).thenReturn(s3ObjectKey);

        EvidenceRequest request = new EvidenceRequest(List.of(upload, upload, upload, upload, upload, upload),
                List.of(file, file, file, file, file, file), submission);

        when(s3Service.uploadEvidence(anyString(), anyString(), any(Part.class), any(UploadEvidenceRequest.class),
                any(Submission.class), anyString())).thenReturn(s3FileInfo);
        when(submissionService.updateSubmissionWithEvidence(anyString(), anyString(), anyString(), anyString(), any(UploadEvidenceRequest.class),
                any(S3FileInfo.class), anyString())).thenReturn(submission);
        controller.uploadEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, FormType.I485J.getType(), FORM_ID, request);

        verify(s3Service, times(5)).uploadEvidence(MYUSCIS_ID, SUBMISSION_ID, file, upload, submission, FormType.I485J.getType());
        verify(submissionService, times(5)).updateSubmissionWithEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, formId, upload, s3FileInfo, FormType.I485J.getType());
        verify(auditService, times(5)).addEvent(MYUSCIS_ID, SUBMISSION_ID, ActionPerformed.EVIDENCE_UPLOADED,
                evidenceId);
    }

    @Test
    void shouldErrorAfter20OfTheSameEvidenceUploaded() throws IOException {
        String evidenceId = "evidenceId";
        String s3ObjectKey = "hello.pdf";
        String type = "evidenceType";
        S3FileInfo s3FileInfo = new S3FileInfo(evidenceId, "checksum123", "artifactId", s3ObjectKey);
        SubmissionEvidence submissionEvidence = Instancio.of(SubmissionEvidence.class)
                .set(field(SubmissionEvidence::getId), evidenceId)
                .set(field(SubmissionEvidence::getType), type)
                .create();
        Submission submission = Instancio.of(Submission.class)
                .set(field(Submission::getSubmissionId), SUBMISSION_ID)
                .set(field(Submission::getMyUscisId), MYUSCIS_ID)
                .set(field(Submission::getEvidences), Collections.nCopies(20, submissionEvidence))
                .set(field(Submission::getEligibilityCategory), I765EligibilityCategory.A12)
                .set(field(Submission::getForms), List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I485J.getType())
                        .eligibilityCategory(I765EligibilityCategory.A12)
                    .build()))
                .create();
        UploadEvidenceRequest upload = Instancio.of(UploadEvidenceRequest.class)
                .set(field(UploadEvidenceRequest::fileName), s3ObjectKey)
                .set(field(UploadEvidenceRequest::evidenceGroupType), submissionEvidence.getEvidenceGroupType())
                .set(field(UploadEvidenceRequest::type), submissionEvidence.getType())
                .create();
        Part file = mock(Part.class);
        when(file.getSubmittedFileName()).thenReturn(s3ObjectKey);

        EvidenceRequest request = new EvidenceRequest(List.of(upload, upload, upload, upload, upload, upload),
                List.of(file, file, file, file, file, file), submission);

        when(s3Service.uploadEvidence(anyString(), anyString(), any(Part.class), any(UploadEvidenceRequest.class),
                any(Submission.class), anyString())).thenReturn(s3FileInfo);
        when(submissionService.updateSubmissionWithEvidence(anyString(), anyString(), anyString(), eq(null), any(UploadEvidenceRequest.class),
                any(S3FileInfo.class), anyString())).thenReturn(submission);
        ResponseEntity<List<UploadEvidenceResponse>> response = controller.uploadEvidence(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, FormType.I485J.getType(),
            FORM_ID, request);

        verifyNoInteractions(s3Service);
        verifyNoInteractions(submissionService);
        verifyNoInteractions(auditService);

        assertTrue(response.getBody().isEmpty());
    }

    @Test
    void shouldUpdateSubmissionWithFeeWaiver() throws IOException {
        UploadFeeWaiverRequest request = Instancio.create(UploadFeeWaiverRequest.class);

        String feeWaiverId = "feeWaiverId";
        String s3ObjectKey = "hello.pdf";
        S3FileInfo s3FileInfo = new S3FileInfo(feeWaiverId, "checksum123", "artifactId", s3ObjectKey);
        Submission initialSubmission = Instancio.create(Submission.class);
        Submission submission = Instancio.create(Submission.class);

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "hello.pdf",
                MediaType.MULTIPART_FORM_DATA_VALUE,
                "Hello, World!".getBytes());

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)).thenReturn(initialSubmission);
        when(formService.isFeeWaiverEnabled(initialSubmission.getFormType())).thenReturn(true);
        when(s3Service.uploadFeeWaiver(MYUSCIS_ID, SUBMISSION_ID, file, request, initialSubmission))
                .thenReturn(s3FileInfo);
        when(submissionService.updateSubmissionWithFeeWaiver(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, request, s3FileInfo))
                .thenReturn(submission);

        controller.uploadFeeWaiver(file, request, MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, UriComponentsBuilder.newInstance());

        verify(s3Service, times(1)).uploadFeeWaiver(MYUSCIS_ID, SUBMISSION_ID, file, request, initialSubmission);
        verify(submissionService, times(1)).updateSubmissionWithFeeWaiver(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, request,
                s3FileInfo);
    }

    @Test
    void shouldNotUpdateSubmissionWithFeeWaiver() throws IOException {
        UploadFeeWaiverRequest request = Instancio.create(UploadFeeWaiverRequest.class);

        S3FileInfo s3FileInfo = new S3FileInfo("feeWaiverId", "checksum123", "artifactId", "hello.pdf");
        Submission initialSubmission = Instancio.create(Submission.class);

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "hello.pdf",
                MediaType.MULTIPART_FORM_DATA_VALUE,
                "Hello, World!".getBytes());

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID)).thenReturn(initialSubmission);
        when(formService.isFeeWaiverEnabled(initialSubmission.getFormType())).thenReturn(false);

        controller.uploadFeeWaiver(file, request, MYUSCIS_ID, ORG_MYUSCIS_ID,  SUBMISSION_ID, UriComponentsBuilder.newInstance());

        verifyNoInteractions(s3Service);
        verify(submissionService, times(0)).updateSubmissionWithFeeWaiver(MYUSCIS_ID, ORG_MYUSCIS_ID, SUBMISSION_ID, request,
                s3FileInfo);
    }

    @Test
    void shouldGetFormDocumentFromS3AndReturn200() {
        final String fileName = "i765.pdf";
        final String formId = "testID";
        Submission submission = Submission.builder().forms(List.of(SubmissionForm.builder().id(formId).name(fileName).s3Key(fileName).build()))
                .build();
        byte[] fileContent = "fileContent".getBytes();

        when(submissionService.retrieveSubmission(anyString())).thenReturn(submission);
        when(s3Service.getFileData(anyString(), anyBoolean())).thenReturn(fileContent);

        ResponseEntity<byte[]> response = controller.downloadForm(MYUSCIS_ID, SUBMISSION_ID, formId);

        var expectedStatus = HttpStatusCode.valueOf(200);
        var actualStatus = response.getStatusCode();
        assertEquals(expectedStatus, actualStatus);

        assertEquals(fileContent, response.getBody());
    }

    @Test
    void shouldThrowExceptionWhenNoFormInSubmission() {
        var fileName = "i765.pdf";
        Submission submission = Submission.builder().forms(List.of(SubmissionForm.builder().s3Key(fileName).build()))
                .build();
        submission.setForms(emptyList());

        when(submissionService.retrieveSubmission(anyString())).thenReturn(submission);

        NoFormInSubmissionException formException = assertThrows(NoFormInSubmissionException.class, () -> {
            controller.downloadForm(MYUSCIS_ID, SUBMISSION_ID, fileName);
        });

        assertTrue("No such form in this submission".contains(formException.getMessage()));
    }

    @Test
    void shouldGetAttestedFormDocumentFromS3AndReturn200() {
        var fileName = "i765.pdf";
        Submission submission = Submission.builder()
                .forms(List.of(SubmissionForm.builder().attestedS3Key(fileName).build()))
                .build();
        byte[] fileContent = "fileContent".getBytes();

        when(submissionService.retrieveSubmission(anyString())).thenReturn(submission);
        when(s3Service.getFileData(anyString(), anyBoolean())).thenReturn(fileContent);

        ResponseEntity<byte[]> response = controller.downloadAttestedForm(MYUSCIS_ID, SUBMISSION_ID);

        var expectedStatus = HttpStatusCode.valueOf(200);
        var actualStatus = response.getStatusCode();
        assertEquals(expectedStatus, actualStatus);

        assertEquals(fileContent, response.getBody());
    }

    @Test
    void shouldDownloadNonFeeWaiverEvidenceAndReturn200() {
        var evidenceId = "12345";
        var fileName = "photo.jpg";
        Submission submission = Submission.builder()
                .evidences(List.of(SubmissionEvidence.builder().id(evidenceId).s3Key(fileName).build())).build();
        byte[] fileContent = "fileContent".getBytes();

        when(submissionService.retrieveSubmission(anyString())).thenReturn(submission);
        when(s3Service.getFileData(anyString(), anyBoolean())).thenReturn(fileContent);

        ResponseEntity<byte[]> response = controller.downloadEvidence(MYUSCIS_ID, SUBMISSION_ID, evidenceId, fileName);

        var expectedStatus = HttpStatusCode.valueOf(200);
        var actualStatus = response.getStatusCode();
        assertEquals(expectedStatus, actualStatus);

        assertEquals(fileContent, response.getBody());
    }

    @Test
    void shouldDownloadFeeWaiverEvidenceAndReturn200() {
        var evidenceId = "12345";
        var fileName = "feeWaiver.pdf";
        Submission submission = Submission.builder()
                .feeWaiver(SubmissionEvidence.builder().id(evidenceId).s3Key(fileName).build()).build();
        byte[] fileContent = "fileContent".getBytes();

        when(submissionService.retrieveSubmission(anyString())).thenReturn(submission);
        when(s3Service.getFileData(anyString(), anyBoolean())).thenReturn(fileContent);

        ResponseEntity<byte[]> response = controller.downloadEvidence(MYUSCIS_ID, SUBMISSION_ID, evidenceId, fileName);

        var expectedStatus = HttpStatusCode.valueOf(200);
        var actualStatus = response.getStatusCode();
        assertEquals(expectedStatus, actualStatus);

        assertEquals(fileContent, response.getBody());
    }

}
