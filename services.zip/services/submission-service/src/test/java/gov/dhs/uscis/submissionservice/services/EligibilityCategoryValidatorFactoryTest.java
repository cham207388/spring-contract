package gov.dhs.uscis.submissionservice.services;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.submissionservice.validators.n400.BasisOfEligibilityValidator;

public class EligibilityCategoryValidatorFactoryTest {

    BasisOfEligibilityValidator basisOfEligibilityValidator = Mockito.mock(BasisOfEligibilityValidator.class);
    
    EligibilityCategoryValidatorFactory factory = new EligibilityCategoryValidatorFactory(basisOfEligibilityValidator);


    @Test
    void shouldReturnEligibilityValidatorForN400() {
        assertThat(factory.getValidator(FormType.N400)).isEqualTo(basisOfEligibilityValidator);
    }
}
