
package gov.dhs.uscis.submissionservice.validators;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersUriSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import gov.dhs.uscis.intake.models.ErrorType;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.form.metadata.ErrorMap;
import gov.dhs.uscis.intake.models.form.metadata.SignaturePageMetadata;
import gov.dhs.uscis.intake.models.validation.FormFieldResult;
import gov.dhs.uscis.intake.models.validation.N400FormFieldResult;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.validators.PersonValidator;
import gov.dhs.uscis.submissionservice.validators.ProfileResponse;
import reactor.core.publisher.Mono;

class PersonValidatorTest {

    ResponseSpec responseSpec = Mockito.mock(ResponseSpec.class);
    RequestHeadersSpec requestHeadersSpec = Mockito.mock(RequestHeadersSpec.class);
    RequestHeadersUriSpec requestHeadersUriSpec = Mockito.mock(RequestHeadersUriSpec.class);

    ValidationStatusRepository statusRepository;
    SubmissionRepository submissionDAO;
    WebClient webClient;
    PersonValidator validator;
    FormService formService;
    String submissionId;
    FormMetaData formMetaData = FormMetaData.builder()
            .signaturePages(List.of(SignaturePageMetadata.builder().entity(AccountType.APPLICANT).page(11).build()))
            .errorMap(List.of(ErrorMap.builder()
                    .errorType(ErrorType.A_NUMBER_ERROR)
                    .errorMessage(
                            "A-Number missing: Please add your A-Number on your I-751 form in order to continue.")
                    .build(),
                    ErrorMap.builder().errorType(ErrorType.DOB_ERROR)
                            .errorMessage(
                                    "Date of Birth missing: Please add your Date of Birth on your I-751 form (Question #6 on Page 2) in order to continue.")
                            .build()))
            .build();

    @BeforeEach
    public void setup() {
        submissionId = UUID.randomUUID().toString();
        statusRepository = Mockito.mock(ValidationStatusRepository.class);
        submissionDAO = Mockito.mock(SubmissionRepository.class);
        formService = Mockito.mock(FormService.class);
        webClient = Mockito.mock(WebClient.class);
        validator = new PersonValidator(webClient, statusRepository, formService, submissionDAO);
        var submission = new Submission();
        submission.setSubmissionId(submissionId);
        submission.setStatus(SubmissionState.DRAFT);
        submission.setFormType(FormType.N400);
        when(submissionDAO.getById(submissionId)).thenReturn(Optional.of(submission));
        when(formService.retrieveFormMetaData(anyString())).thenReturn(formMetaData);

    }

    @Test
    void shouldReturnPASSWhenANumbersIsNotDetectedAndPeepsHasNoAnumber() {
        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(UUID.randomUUID().toString())
                .submissionId(submissionId)
                .dateOfBirth(LocalDate.now().format(DateTimeFormatter.ISO_DATE))
                .build();

        ProfileResponse response = Instancio.create(ProfileResponse.class);
        response.getData().setAlienNumber(null);

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidatorEnum.PERSON, savedStatus.getValidator());
        assertEquals(ValidationResultEnum.PASS, savedStatus.getStatus());
        assertEquals(formFields.getFormId(), savedStatus.getFormId());
        assertEquals(formFields.getSubmissionId(), savedStatus.getSubmissionId());
    }

    @Test
    void shouldReturnPASSWhenANumbersAndDobMatch() {
        LocalDate dob = LocalDate.now();
        ProfileResponse response = Instancio.create(ProfileResponse.class);
        response.getData().setDateOfBirth(dob.format(DateTimeFormatter.ISO_DATE));
        response.getData().setAlienNumber("124482781237");

        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(submissionId)
                .submissionId(submissionId)
                .alienNumber(response.getData().getAlienNumber())
                .dateOfBirth(dob.format(DateTimeFormatter.ofPattern(PersonValidator.FORM_FIELD_DOB_FORMAT)))
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();

        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());
        verify(submissionDAO, times(1)).getById(formFields.getSubmissionId());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.PASS, savedStatus.getStatus());
    }

    @Test
    void shouldReturnFAILWhenANumbersMatchAndDobDoesNotMatchWithin1DayTolerance() {
        LocalDate dob = LocalDate.now();
        ProfileResponse response = Instancio.create(ProfileResponse.class);
        response.getData().setDateOfBirth(dob.format(DateTimeFormatter.ISO_DATE));
        response.getData().setAlienNumber("124482781237");

        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(submissionId)
                .submissionId(submissionId)
                .alienNumber(response.getData().getAlienNumber())
                .dateOfBirth(
                        dob.plusWeeks(2).format(DateTimeFormatter.ofPattern(PersonValidator.FORM_FIELD_DOB_FORMAT)))
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();

        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());
        verify(submissionDAO, times(1)).getById(formFields.getSubmissionId());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.FAIL, savedStatus.getStatus());
    }

    @Test
    void shouldReturnPASSWhenANumbersAndDobMatch_WithADash() {
        LocalDate dob = LocalDate.now();

        ProfileResponse response = Instancio.create(ProfileResponse.class);
        response.getData().setDateOfBirth(dob.format(DateTimeFormatter.ISO_DATE));
        String alienNumber = "124482781237";
        response.getData().setAlienNumber(alienNumber);

        String formId = UUID.randomUUID().toString();
        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(formId)
                .submissionId(submissionId)
                .alienNumber(String.format("A - %s", alienNumber))
                .dateOfBirth(dob.format(DateTimeFormatter.ofPattern(PersonValidator.FORM_FIELD_DOB_FORMAT)))
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());
        verify(submissionDAO, times(1)).getById(formFields.getSubmissionId());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.PASS, savedStatus.getStatus());
    }

    @Test
    void shouldReturnPASSWhenANumbersMatchAndDobIsWithinDay() {
        ProfileResponse response = Instancio.create(ProfileResponse.class);
        LocalDate now = LocalDate.now();
        response.getData().setDateOfBirth(now.format(DateTimeFormatter.ISO_DATE));
        String alienNumber = "124482781237";
        response.getData().setAlienNumber(alienNumber);

        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(UUID.randomUUID().toString())
                .submissionId(submissionId)
                .alienNumber(response.getData().getAlienNumber())
                .dateOfBirth(
                        now.plusDays(1).format(DateTimeFormatter.ofPattern(PersonValidator.FORM_FIELD_DOB_FORMAT)))
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.PASS, savedStatus.getStatus());
    }

    @Test
    void shouldReturnPASSWhenANumbersMatchAndDobNotDetected() {
        ProfileResponse response = Instancio.create(ProfileResponse.class);
        response.getData().setDateOfBirth(LocalDate.now().format(DateTimeFormatter.ISO_DATE));
        String alienNumber = "124482781237";
        response.getData().setAlienNumber(alienNumber);

        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(UUID.randomUUID().toString())
                .submissionId(submissionId)
                .alienNumber(response.getData().getAlienNumber())
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.FAIL, savedStatus.getStatus());
    }

    @Test
    void shouldReturnFailIfFormDoesNotHaveANumberButPeepsHasANumber() {
        ProfileResponse response = Instancio.create(ProfileResponse.class);
        response.getData().setDateOfBirth(null);
        String alienNumber = "124482781";
        response.getData().setAlienNumber(alienNumber);
        response.getData().setDateOfBirth("01/12/1902");

        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(UUID.randomUUID().toString())
                .submissionId(submissionId)
                .alienNumber(null)
                .dateOfBirth("01/12/1902")
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.FAIL, savedStatus.getStatus());
    }

    @Test
    @Disabled
    void shouldReturnPASSWhenANumbersMatchAndProfileDobIsNull() {
        ProfileResponse response = Instancio.create(ProfileResponse.class);
        response.getData().setDateOfBirth(null);
        String alienNumber = "124482781237";
        response.getData().setAlienNumber(alienNumber);
        response.getData().setDateOfBirth("1980-01-12");

        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(UUID.randomUUID().toString())
                .submissionId(submissionId)
                .alienNumber(response.getData().getAlienNumber())
                .dateOfBirth("09/09/2022")
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.PASS, savedStatus.getStatus());
    }

    @Test
    void shouldReturnPASSWhenProfileANumbersIsNull() {
        ProfileResponse response = Instancio.create(ProfileResponse.class);
        response.getData().setAlienNumber(null);

        FormFieldResult formFields = N400FormFieldResult.builder()
                .submissionId(submissionId)
                .alienNumber("alien").build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.PASS, savedStatus.getStatus());
    }

    @Test
    @DisplayName("Testing the final else case where setFail is called, since Regex replaces the whole A number on form fields")
    void shouldReturnFAILWhenFinalElseIsHit() {
        ProfileResponse response = Instancio.create(ProfileResponse.class);
        response.getData().setDateOfBirth(LocalDate.now().toString());

        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(UUID.randomUUID().toString())
                .submissionId(submissionId)
                .alienNumber(response.getData().getAlienNumber())
                .dateOfBirth(LocalDate.now()
                        .format(DateTimeFormatter.ofPattern(PersonValidator.FORM_FIELD_DOB_FORMAT)))
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.FAIL, savedStatus.getStatus());
        assertEquals("There was a discrepancy between the A-Number on your form and the one we have on file.",
                savedStatus.getFailureReasons().get(0));
    }

    @Test
    void shouldReturnFAILWhenANumbersDoNotMatch() {
        ProfileResponse response = Instancio.create(ProfileResponse.class);

        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(UUID.randomUUID().toString())
                .submissionId(submissionId)
                .alienNumber("alien")
                .dateOfBirth(LocalDate.now().plusMonths(1)
                        .format(DateTimeFormatter.ofPattern(PersonValidator.FORM_FIELD_DOB_FORMAT)))
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        var responseEntity = ResponseEntity.ok().body(response);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(ProfileResponse.class)).thenReturn(Mono.just(responseEntity));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.FAIL, savedStatus.getStatus());
    }

    @Test
    void shouldReturnFAILWhenPeepsIsUnavailable() {
        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(UUID.randomUUID().toString())
                .alienNumber("alien")
                .submissionId(submissionId)
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve())
                .thenThrow(new WebClientResponseException(503, "Service Unavailable", null, null, null));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.FAIL, savedStatus.getStatus());
    }

    @Test
    void shouldReturnPASSWhen404FromPeeps() { // Probably unnecessary
        FormFieldResult formFields = N400FormFieldResult.builder()
                .formId(UUID.randomUUID().toString())
                .alienNumber("alien")
                .submissionId(submissionId)
                .build();

        doReturn(requestHeadersUriSpec).when(webClient).get();
        when(requestHeadersUriSpec.uri(PersonValidator.PROFILE_URL)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(), any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenThrow(new WebClientResponseException(404,
                "Error fetching Latest profile by receipts for user 1aedb8d9-dc47-31e2-a9a3-35e371db8058 - not_found",
                null, null, null));

        validator.validate(formFields.getAlienNumber(), formFields.getDateOfBirth(), formFields.getFormId(),
                formFields.getSubmissionId(), FormType.N400);

        ArgumentCaptor<ValidationStatus> captor = ArgumentCaptor.forClass(ValidationStatus.class);
        verify(statusRepository, times(1)).save(captor.capture());

        ValidationStatus savedStatus = captor.getValue();
        assertEquals(ValidationResultEnum.PASS, savedStatus.getStatus());
    }

}
