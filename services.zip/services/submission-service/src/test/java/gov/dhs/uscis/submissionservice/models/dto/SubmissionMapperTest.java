package gov.dhs.uscis.submissionservice.models.dto;

import static org.junit.jupiter.api.Assertions.*;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.dto.SubmissionDto;

class SubmissionMapperTest {

    @Test
    void shouldMapToSubmissionDto() {
        Submission submission = Instancio.create(Submission.class);

        SubmissionDto submissionDto = SubmissionMapper.toSubmissionDTO(submission);
        assertEquals(submission.getMyUscisId(), submissionDto.myUscisId());
        assertEquals(submission.getSubmissionId(), submissionDto.submissionId());
        assertEquals(submission.getFormType(), submissionDto.formType());
        assertEquals(submission.getEligibilityCategory(), submissionDto.eligibilityCategory());
        assertEquals(submission.getManifestId(), submissionDto.manifestId());
        assertEquals(submission.getStatus(), submissionDto.status());
        assertEquals(submission.getLockboxStatus(), submissionDto.lockboxStatus());
        assertEquals(submission.getLockboxErrors(), submissionDto.lockboxErrors());
        assertEquals(submission.getFeeTotal(), submissionDto.feeTotal());
        assertEquals(submission.getTimestamp(), submissionDto.timestamp());
        assertEquals(submission.getUpdatedAt(), submissionDto.updatedAt());
        assertEquals(submission.getUpdatedAt().plusDays(30), submissionDto.expireDate());
        assertEquals(submission.getForms().size(), submissionDto.forms().size());
        assertEquals(submission.getFeeWaiver().getId(), submissionDto.feeWaiver().id());
        assertEquals(submission.getFeeWaiver().getType(), submissionDto.feeWaiver().type());
        assertEquals(submission.getEvidences().size(), submissionDto.evidences().size());
        assertEquals(submission.getUserRequestedFeeWaiver(), submissionDto.userRequestedFeeWaiver());
        assertEquals(submission.getAttested(), submissionDto.attested());
        assertEquals(submission.getAttestedAt(), submissionDto.attestedAt());
        assertEquals(submission.getAttestationSignature(), submissionDto.attestationSignature());
        assertEquals(submission.getApplicant(), submissionDto.applicant());
        assertEquals(submission.getSubmittedAt(), submissionDto.submittedAt());
        assertEquals(submission.getClientInformation(), submissionDto.clientInformation());
    }
}
