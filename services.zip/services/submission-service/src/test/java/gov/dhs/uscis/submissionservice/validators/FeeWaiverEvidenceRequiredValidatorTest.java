package gov.dhs.uscis.submissionservice.validators;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;

import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;

public class FeeWaiverEvidenceRequiredValidatorTest {

  FeeWaiverEvidenceRequiredValidator validator = new FeeWaiverEvidenceRequiredValidator();

  @Test
  void shouldReturnTrueWhenUserRequestsFeeWaiverAndUploadsAllDocumentsNeeded() {
    FinalSubmissionDto dto = Instancio.create(FinalSubmissionDto.class);
    dto.setUserRequestedFeeWaiver(true);
    dto.setUserRequestedPartialFeeWaiver(false);
    dto.setEvidences(List.of(SubmissionEvidence.builder().evidenceGroupType("feeWaiver").build()));
    assertThat(validator.isValid(dto, null)).isTrue();
  }

  @Test
  void shouldReturnFalseWhenUserRequestsFeeWaiverAndNoFeewaiverIsUploaded() {
    FinalSubmissionDto dto = Instancio.create(FinalSubmissionDto.class);
    dto.setUserRequestedFeeWaiver(true);
    dto.setFeeWaiver(null);
    assertThat(validator.isValid(dto, null)).isFalse();
  }

  @Test
  void shouldReturnFalseWhenUserRequestsFeeWaiverAndNoEvidenceUploaded() {
    FinalSubmissionDto dto = Instancio.create(FinalSubmissionDto.class);
    dto.setUserRequestedFeeWaiver(true);
    assertThat(validator.isValid(dto, null)).isFalse();
  }

  @Test
  void shouldReturnTrueWhenUserRequestsPartialFeeWaiverAndUploadsEvidence() {
    FinalSubmissionDto dto = Instancio.create(FinalSubmissionDto.class);
    dto.setUserRequestedFeeWaiver(true);
    dto.setFeeWaiver(null);
    dto.setUserRequestedPartialFeeWaiver(true);
    dto.setEvidences(List.of(SubmissionEvidence.builder().evidenceGroupType("feeWaiver").build()));
    assertThat(validator.isValid(dto, null)).isTrue();
  }

  @Test
  void shouldReturnFalseWhenUserRequestsPartialFeeWaiverAndUploadsNoEvidence() {
    FinalSubmissionDto dto = Instancio.create(FinalSubmissionDto.class);
    dto.setUserRequestedFeeWaiver(true);
    dto.setUserRequestedPartialFeeWaiver(true);
    assertThat(validator.isValid(dto, null)).isFalse();
  }

  @Test
  void shouldReturnTrueWhenNoFeeWaiverOrPartialFeeWaiverIsRequested() {
    FinalSubmissionDto dto = Instancio.create(FinalSubmissionDto.class);
    dto.setUserRequestedFeeWaiver(false);
    dto.setUserRequestedPartialFeeWaiver(false);
    assertThat(validator.isValid(dto, null)).isTrue();
  }
  
  
}
