package gov.dhs.uscis.submissionservice.services;

import static gov.dhs.uscis.intake.enums.ValidatorEnum.SIGNATURE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.UUID;
import java.util.Optional;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.util.MimeType;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I751EligibilityCategory;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I751WaiverOrIndividualFilingSubcategory;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.EvidenceType;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.form.metadata.EligibilityCategory;
import gov.dhs.uscis.intake.models.form.metadata.EligibilitySubcategory;
import gov.dhs.uscis.intake.models.form.metadata.MetaData;
import gov.dhs.uscis.submissionservice.entity.ConcurrentForms;
import gov.dhs.uscis.submissionservice.models.EligibilityCategoryResponse;
import gov.dhs.uscis.submissionservice.repository.ConcurrentFormsRepository;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.services.s3.S3Client;

@ExtendWith(MockitoExtension.class)
class FormServiceTest {

    @Mock
    DynamoDbTable<FormMetaData> mockDynamoDbTable;

    @Mock
    private S3Client s3Client;

    @Mock
    private ClientManagementService clientManagementService;

    @Mock
    private SubmissionRepository submissionRepository;

    @Mock
    private ConcurrentFormsRepository concurrentFormsRepository;

    @InjectMocks
    private FormService service;

    static final String FORM_TYPE = "I765";
    static final String MYUSCISID = UUID.randomUUID().toString();
    static final String N400 = "N-400";
    static final String ELIGIBILITY_CATEGORY = "C11";
    static final String ELIGIBILITY_CATEGORY_LABEL = "C1 - PAROLE";
    static final String BENEFIT_TYPE_CODE = "145";
    static final String APP_REASON_CODE = "39";
    static final Integer CODE = 37;

    private FormMetaData formMetaData;
    private GetItemEnhancedRequest request;

    @BeforeEach
    void setUp() {
        formMetaData = Instancio.create(FormMetaData.class);

        Key key = Key.builder().partitionValue(FORM_TYPE).build();
        request = GetItemEnhancedRequest.builder().key(key).build();
    }

    @Test
    void shouldRetrieveFormMetaData() {
        when(mockDynamoDbTable.getItem(request)).thenReturn(formMetaData);
        FormMetaData response = service.retrieveFormMetaData(FORM_TYPE);

        assertEquals(formMetaData, response);

    }

    @Test
    void shouldRetrieveEvidencesGroupsNoSubcategories() {
        MetaData metaData = MetaData.builder()
                .feeWaivable(false)
                .feeExemptable(false)
                .evidenceGroups(List.of(Instancio.create(EvidenceGroup.class)))
                .feeExemptQuestions(null)
                .subCategoryHeader(null)
                .subcategories(null)
                .disabled(false)
                .build();
        EligibilityCategory eligibilityCategoryData = new EligibilityCategory(ELIGIBILITY_CATEGORY,
                ELIGIBILITY_CATEGORY_LABEL, CODE, BENEFIT_TYPE_CODE, APP_REASON_CODE,
                metaData, List.of());
        formMetaData.setEligibilityCategories(List.of(eligibilityCategoryData));

        when(mockDynamoDbTable.getItem(request)).thenReturn(formMetaData);
        List<EvidenceGroup> actual = service.retrieveEvidenceGroups(FORM_TYPE, ELIGIBILITY_CATEGORY);

        assertEquals(eligibilityCategoryData.getMetaData().getEvidenceGroups(), actual);
    }

    @Test
    void shouldRetrieveEvidencesGroupsWithSubcategoryEvidenceGroups() {
        MetaData metaData = MetaData.builder()
                .feeWaivable(false)
                .feeExemptable(false)
                .evidenceGroups(List.of(Instancio.create(EvidenceGroup.class)))
                .feeExemptQuestions(null)
                .subCategoryHeader(null)
                .subcategories(null)
                .disabled(false)
                .build();
        EligibilityCategory eligibilityCategoryData = new EligibilityCategory(ELIGIBILITY_CATEGORY,
                ELIGIBILITY_CATEGORY_LABEL, CODE, BENEFIT_TYPE_CODE, APP_REASON_CODE,
                metaData, List.of());
        formMetaData.setEligibilityCategories(List.of(eligibilityCategoryData));

        when(mockDynamoDbTable.getItem(request)).thenReturn(formMetaData);
        List<EvidenceGroup> actual = service.retrieveEvidenceGroups(FORM_TYPE, ELIGIBILITY_CATEGORY);

        assertEquals(eligibilityCategoryData.getMetaData().getEvidenceGroups(), actual);
    }

    @Test
    void tesRetrieveBenefitTypeCode() {
                MetaData metaData = MetaData.builder()
                .feeWaivable(false)
                .feeExemptable(false)
                .evidenceGroups(List.of(Instancio.create(EvidenceGroup.class)))
                .feeExemptQuestions(null)
                .subCategoryHeader(null)
                .subcategories(null)
                .disabled(false)
                .build();
        EligibilityCategory eligibilityCategoryData = new EligibilityCategory(I765EligibilityCategory.C11PAROLE.getCategory(),
                ELIGIBILITY_CATEGORY_LABEL, CODE, BENEFIT_TYPE_CODE, APP_REASON_CODE,
                metaData, List.of());
        formMetaData.setEligibilityCategories(List.of(eligibilityCategoryData));
        when(service.retrieveFormMetaData(FormType.I765.getType())).thenReturn(formMetaData);

        Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                .myUscisId(UUID.randomUUID().toString())
                .formType(FormType.I765)
                .eligibilityCategory(EligibilityCategoryEnum.fromString(I765EligibilityCategory.C11PAROLE.getCategory()))
                .build();

                Integer benefitTypeCode = service.retrieveBenefitTypeCodeByEligiblityCategory(FormType.I765.getType(), submission);
                Integer BENEFIT_TYPE_CODE_CONSTANT = Integer.valueOf(BENEFIT_TYPE_CODE);

                assertEquals(BENEFIT_TYPE_CODE_CONSTANT, benefitTypeCode);

    }
    @Test
    void shouldRetrieveEligibilityCategories() {
        MetaData metaData = MetaData.builder()
                .feeWaivable(false)
                .feeExemptable(false)
                .evidenceGroups(List.of(Instancio.create(EvidenceGroup.class)))
                .feeExemptQuestions(null)
                .subCategoryHeader(null)
                .subcategories(null)
                .disabled(false)
                .build();
        EligibilityCategory eligibilityCategoryData = new EligibilityCategory(ELIGIBILITY_CATEGORY,
                ELIGIBILITY_CATEGORY_LABEL, CODE, BENEFIT_TYPE_CODE, APP_REASON_CODE,
                metaData, List.of());
        List<EligibilityCategoryResponse> expected = List.of(new EligibilityCategoryResponse(ELIGIBILITY_CATEGORY,
                metaData.isFeeWaivable(),
                metaData.isFeeExemptable()));
        formMetaData.setEligibilityCategories(List.of(eligibilityCategoryData));

        when(mockDynamoDbTable.getItem(request)).thenReturn(formMetaData);
        List<EligibilityCategoryResponse> actual = service.retrieveEligibilityCategories(FORM_TYPE);
        assertEquals(expected, actual);
    }

    @Test
    void shouldRetrieveEligibilityCategories_noMetadata() {
        List<EligibilityCategoryResponse> actual = service.retrieveEligibilityCategories("");
        assertThat(actual).hasSize(0);
    }

    @Test
    void shouldReturnEmptyListWhenRetrieveEvidencesGroups() {
        when(mockDynamoDbTable.getItem(request)).thenReturn(null);
        List<EvidenceGroup> response = service.retrieveEvidenceGroups(FORM_TYPE, ELIGIBILITY_CATEGORY);

        assertThat(response).isEmpty();
        ;
    }

    @Test
    void shouldRetrieveValidationsForEvidenceGroupType() {
        EvidenceGroup evidenceGroupA = EvidenceGroup.builder().id("A")
                    .name("2\" x 2\" Photo of you1")
                    .maxNumberOfFiles(1)
                    .allowMediaTypes(List.of(MimeType.valueOf("image/jpeg")))
                    .validations(List.of())
                    .evidenceTypes(List.of(
                            EvidenceType.builder().id("Applicant Photo1")
                                    .name("2\" x 2\" Photo of you1")
                                    .build()))
                    .build();
         EvidenceGroup evidenceGroupB = EvidenceGroup.builder().id("B")
                    .name("2\" x 2\" Photo of you2")
                    .maxNumberOfFiles(1)
                    .allowMediaTypes(List.of(MimeType.valueOf("image/jpeg")))
                    .validations(List.of(MetadataValidationEnum.FORM_FIELDS, MetadataValidationEnum.SIGNATURE))
                    .evidenceTypes(List.of(
                            EvidenceType.builder().id("Applicant Photo2")
                                    .name("2\" x 2\" Photo of yo2u")
                                    .build()))
                    .build();
        EvidenceGroup evidenceGroupC = EvidenceGroup.builder().id("C")
            .name("2\" x 2\" Photo of you3")
            .maxNumberOfFiles(1)
            .allowMediaTypes(List.of(MimeType.valueOf("image/jpeg")))
            .validations(List.of())
            .evidenceTypes(List.of(
                    EvidenceType.builder().id("Applicant Photo3")
                            .name("2\" x 2\" Photo of you3")
                            .build()))
                    .build();
        String eCode = "A12";
        MetaData metaDataA = MetaData.builder()
                .feeWaivable(false)
                .feeExemptable(false)
                .evidenceGroups(List.of(evidenceGroupA))
                .feeExemptQuestions(null)
                .subCategoryHeader(null)
                .subcategories(null)
                .disabled(false)
                .build();
        MetaData metaDataB = MetaData.builder()
                .feeWaivable(false)
                .feeExemptable(false)
                .evidenceGroups(List.of(evidenceGroupB))
                .feeExemptQuestions(null)
                .subCategoryHeader(null)
                .subcategories(null)
                .disabled(false)
                .build();
        MetaData metaDataC = MetaData.builder()
                .feeWaivable(false)
                .feeExemptable(false)
                .evidenceGroups(List.of(evidenceGroupC))
                .feeExemptQuestions(null)
                .subCategoryHeader(null)
                .subcategories(null)
                .disabled(false)
                .build();

        EligibilityCategory eligibilityCategoryDataA = new EligibilityCategory(ELIGIBILITY_CATEGORY,
                ELIGIBILITY_CATEGORY_LABEL, CODE, BENEFIT_TYPE_CODE, APP_REASON_CODE, metaDataA, List.of());
        EligibilityCategory eligibilityCategoryDataB = new EligibilityCategory(eCode, ELIGIBILITY_CATEGORY_LABEL, CODE,
                BENEFIT_TYPE_CODE, APP_REASON_CODE, metaDataB, List.of());
        EligibilityCategory eligibilityCategoryDataC = new EligibilityCategory("C9", "C9 - Certain family", CODE,
                BENEFIT_TYPE_CODE, APP_REASON_CODE, metaDataC, List.of());
        List<MetadataValidationEnum> expected = evidenceGroupB.getValidations();
        formMetaData.setEligibilityCategories(
                List.of(eligibilityCategoryDataA, eligibilityCategoryDataB, eligibilityCategoryDataC));

        when(mockDynamoDbTable.getItem(request)).thenReturn(formMetaData);
        List<MetadataValidationEnum> actual = service.retrieveEvidenceGroupValidations(FORM_TYPE, eCode,
                evidenceGroupB.getId());
        verify(mockDynamoDbTable, times(1)).getItem(any(GetItemEnhancedRequest.class));
        assertEquals(expected, actual);
    }

    @Test
    void shouldRetrieveWhetherFeeWaiverIsEnabled() {
        formMetaData.setFeeWaiverEnabled(true);
        when(mockDynamoDbTable.getItem(any(GetItemEnhancedRequest.class))).thenReturn(formMetaData);

        assertThat(service.isFeeWaiverEnabled(FormType.I765)).isTrue();
    }

    @Test
    void shouldReturnFalseWhenClientInformationExistForADraft() {
        when(clientManagementService.getListOfClientInformation(MYUSCISID))
                .thenReturn(List.of(ClientInformation.builder().submissionId("id").build()));
        when(submissionRepository.getById("id")).thenReturn(
                Optional.of(Submission.builder().formType(FormType.N400).status(SubmissionState.DRAFT).build()));
        assertThat(service.canClientFile(MYUSCISID, N400)).isFalse();
    }

    @Test
    void shouldReturnFalseWhenClientInformationExistForAPendingSubmission() {
        when(clientManagementService.getListOfClientInformation(MYUSCISID))
                .thenReturn(List.of(ClientInformation.builder().submissionId("id").build()));
        when(submissionRepository.getById("id")).thenReturn(
                Optional.of(Submission.builder().formType(FormType.N400).status(SubmissionState.RECEIVED).build()));
        assertThat(service.canClientFile(MYUSCISID, N400)).isFalse();
    }

    @Test
    void shouldReturnFalseWhenApplicantHasADraftSubmission() {
        when(clientManagementService.getListOfClientInformation(MYUSCISID))
                .thenReturn(List.of(ClientInformation.builder().submissionId("id").build()));
        when(submissionRepository.getById("id")).thenReturn(
                Optional.of(Submission.builder().formType(FormType.N400).status(SubmissionState.DRAFT).build()));
        assertThat(service.canClientFile(MYUSCISID, N400)).isFalse();
    }

    @Test
    void shouldReturnFalseWhenApplicantHasAPendingSubmission() {
        when(clientManagementService.getListOfClientInformation(MYUSCISID))
                .thenReturn(List.of(ClientInformation.builder().submissionId("id").build()));
        when(submissionRepository.getById("id")).thenReturn(
                Optional.of(Submission.builder().formType(FormType.N400).status(SubmissionState.RECEIVED).build()));
        assertThat(service.canClientFile(MYUSCISID, N400)).isFalse();
    }

    @Test
    void shouldReturnTrueWhenClientInformationExistForAnAcceptedCase() {
        when(clientManagementService.getListOfClientInformation(MYUSCISID))
                .thenReturn(List.of(ClientInformation.builder().submissionId("id").build()));
        when(submissionRepository.getById("id")).thenReturn(
                Optional.of(Submission.builder().formType(FormType.N400).status(SubmissionState.ACCEPTED).build()));
        assertThat(service.canClientFile(MYUSCISID, N400)).isTrue();
    }

    @Test
    void shouldRetrieveSubcategoryEvidencesGroups() {
        EvidenceGroup evidenceGroup = EvidenceGroup.builder().id("passport-id").build();
        MetaData metaData = MetaData.builder()
                .feeWaivable(false)
                .feeExemptable(false)
                .evidenceGroups(List.of(evidenceGroup))
                .feeExemptQuestions(null)
                .subCategoryHeader(null)
                .subcategories(null)
                .disabled(false)
                .build();
        
        EligibilitySubcategory subCategory = EligibilitySubcategory.builder()
                .evidenceGroupsToInclude(List.of(evidenceGroup)).build();
        metaData.setSubcategories(List.of(subCategory));
        EligibilityCategory eligibilityCategoryData = new EligibilityCategory(ELIGIBILITY_CATEGORY,
                ELIGIBILITY_CATEGORY_LABEL, CODE, BENEFIT_TYPE_CODE, APP_REASON_CODE,
                metaData, List.of(subCategory));
        formMetaData.setEligibilityCategories(List.of(eligibilityCategoryData));
        List<EvidenceGroup> expected = new ArrayList<>();
        expected.addAll(eligibilityCategoryData.getMetaData().getEvidenceGroups());
        expected.addAll(eligibilityCategoryData.getMetaData().getSubcategories().get(0).getEvidenceGroupsToInclude());

        when(mockDynamoDbTable.getItem(request)).thenReturn(formMetaData);
        List<EvidenceGroup> actual = service.retrieveEvidenceGroups(FORM_TYPE, ELIGIBILITY_CATEGORY);

        assertEquals(expected, actual);
        assertEquals(2, actual.size());

    }

    @Test
    void TestApplicationReasonCodesForI751WaiverOrIndividualFiling() {

        Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                .myUscisId(UUID.randomUUID().toString())
                .formType(FormType.I751)
                .eligibilitySubcategories(List.of(
                        EligibilitySubcategoryEnum
                                .fromString(I751WaiverOrIndividualFilingSubcategory.DIVORCE_ANNULMENT.getCategory()),
                        EligibilitySubcategoryEnum
                                .fromString(I751WaiverOrIndividualFilingSubcategory.GOOD_FAITH_SPOUSE_EXTREME_CRUELTY
                                        .getCategory())))
                .eligibilityCategory(I751EligibilityCategory.WAIVER_OR_INDIVIDUAL_FILING)
                .build();
        formMetaData.setEligibilityCategories(
                List.of(EligibilityCategory.builder().applicationReasonCode("111").benefitTypeCode("111")
                        .category(I751EligibilityCategory.WAIVER_OR_INDIVIDUAL_FILING.getCategory())
                        .metaData(MetaData.builder().subcategories(List.of(
                                EligibilitySubcategory
                                        .builder()
                                        .category(
                                                I751WaiverOrIndividualFilingSubcategory.DIVORCE_ANNULMENT.getCategory())
                                        .applicationReasonCode("134").build(),
                                EligibilitySubcategory.builder().category(
                                        I751WaiverOrIndividualFilingSubcategory.GOOD_FAITH_SPOUSE_EXTREME_CRUELTY
                                                .getCategory())
                                        .applicationReasonCode("135").benefitTypeCodeOverride("135").build()))
                                .build())
                        .build()));

        when(service.retrieveFormMetaData(FormType.I751.getType())).thenReturn(formMetaData);
        List<Integer> reasonCodeList = service.addApplicationReasonCodes(submission, FormType.I751);

        assertEquals(reasonCodeList.size(), 2);
        assertTrue(reasonCodeList.contains(134));
        assertTrue(reasonCodeList.contains(135));
        assertTrue(!reasonCodeList.contains(136));
    }

    @Test
    void TestApplicationReasonCodesForI751WaiverOrIndividualFilingAndNoSubCategories() {

        Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                .myUscisId(UUID.randomUUID().toString())
                .formType(FormType.I751)
                .eligibilityCategory(I751EligibilityCategory.WAIVER_OR_INDIVIDUAL_FILING)
                .eligibilitySubcategories(new ArrayList<>())
                .build();
        formMetaData.setEligibilityCategories(
                List.of(EligibilityCategory.builder().applicationReasonCode("111").benefitTypeCode("111")
                        .category(I751EligibilityCategory.WAIVER_OR_INDIVIDUAL_FILING.getCategory())
                        .metaData(MetaData.builder().subcategories(List.of(
                                EligibilitySubcategory
                                        .builder()
                                        .category(
                                                I751WaiverOrIndividualFilingSubcategory.DIVORCE_ANNULMENT.getCategory())
                                        .applicationReasonCode("134").build(),
                                EligibilitySubcategory.builder().category(
                                        I751WaiverOrIndividualFilingSubcategory.GOOD_FAITH_SPOUSE_EXTREME_CRUELTY
                                                .getCategory())
                                        .applicationReasonCode("135").benefitTypeCodeOverride("135").build()))
                                .build())
                        .build()));

        when(service.retrieveFormMetaData(FormType.I751.getType())).thenReturn(formMetaData);
        List<Integer> reasonCodeList = service.addApplicationReasonCodes(submission, FormType.I751);

        assertEquals(reasonCodeList.size(), 0);
    }

    @Test
    void TestApplicationReasonCodesForI75JointFiling() {

        Submission submission = Submission.builder().submissionId(UUID.randomUUID().toString())
                .myUscisId(UUID.randomUUID().toString())
                .formType(FormType.I751)
                .eligibilityCategory(I751EligibilityCategory.MY_PARENT_SPOUSE)
                .build();
        formMetaData.setEligibilityCategories(
                List.of(EligibilityCategory.builder().applicationReasonCode("132").benefitTypeCode("132")
                        .category(I751EligibilityCategory.MY_PARENT_SPOUSE.getCategory())
                        .metaData(MetaData.builder().build())
                        .build()));

        when(service.retrieveFormMetaData(FormType.I751.getType())).thenReturn(formMetaData);
        List<Integer> reasonCodeList = service.addApplicationReasonCodes(submission, FormType.I751);

        assertEquals(reasonCodeList.size(), 1);
        assertTrue(reasonCodeList.contains(132));
    }

    @Test 
    void ShouldRetrieveConcurrentForms() {
        String formType = FormType.I485.getType();
        String concurrentFormType = FormType.I485A.getType();
        List<ConcurrentForms> concurrentForms = List.of(new ConcurrentForms(formType, concurrentFormType, true));
        when(concurrentFormsRepository.findByIdPrimaryFormTypeAndActiveIsTrue(formType)).thenReturn(concurrentForms);
        
        List<String> returnedFormTypes = service.retrieveConcurrentForms(formType);
        assertEquals(List.of(concurrentFormType), returnedFormTypes);
    }

}