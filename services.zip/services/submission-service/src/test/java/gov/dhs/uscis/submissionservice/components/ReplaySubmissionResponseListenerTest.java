package gov.dhs.uscis.submissionservice.components;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.models.ReplaySubmissionRequest;
import gov.dhs.uscis.submissionservice.services.PaymentRequiredException;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import jakarta.jms.JMSException;
import jakarta.jms.TextMessage;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class ReplaySubmissionResponseListenerTest {

	@Mock
    private SubmissionService mockService;
    @Mock
    private AuditService auditService;
	private ObjectMapper mapper = null;
	@InjectMocks
	private ReplaySubmissionResponseListener listener;
	TextMessage message = null;
	ReplaySubmissionRequest request = null;

	@BeforeEach
    public void setup(){
        mapper = new ObjectMapper();
		request = new ReplaySubmissionRequest("11111111", "2222222");
		message = mock(TextMessage.class);
    }
	
    @Test
    void shouldProcessMessageSuccessFully() throws JsonProcessingException, JMSException, PaymentRequiredException {
    	when(auditService.addEvent(any(), any(), any(), any(), any())).thenReturn(null);
    	when(message.getText()).thenReturn(mapper.writeValueAsString(request));
    	when(mockService.completeSubmission(anyString(), isNull(), anyString()))
    	.thenReturn(Mono.just("Success"));
    	listener.onMessage(message);
    	verify(mockService,times(1)).resetSubmissionToDraft(anyString());
    	verify(mockService,times(1)).completeSubmission(anyString(), isNull(), anyString());
        verify(auditService).addEvent(any(), any(), any(), any(), any());
    }
    
    @Disabled
    @Test
    void shouldThrowExceptionWhenUnableToParseMessage() throws JsonProcessingException, JMSException {
        when(message.getText()).thenThrow(Exception.class);
    	assertThrows(Exception.class, ()-> listener.onMessage(message));
    }
}
