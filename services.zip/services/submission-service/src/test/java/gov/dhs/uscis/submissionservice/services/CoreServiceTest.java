package gov.dhs.uscis.submissionservice.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.models.CoreMetaData;
import gov.dhs.uscis.intake.models.core.metadata.BetaBanner;
import gov.dhs.uscis.intake.models.core.metadata.DropzoneProps;
import gov.dhs.uscis.intake.models.core.metadata.EvidencePages;
import gov.dhs.uscis.intake.models.dto.CoreData;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;

@SuppressWarnings("unchecked")
public class CoreServiceTest {

    DynamoDbTable<CoreMetaData> mockDynamoDbTable = mock(DynamoDbTable.class);
    private CoreService service = new CoreService(mockDynamoDbTable);
    private GetItemEnhancedRequest request;

    @BeforeEach
    void setUp() {
        request = GetItemEnhancedRequest.builder().key(Key.builder().partitionValue(CoreService.CORE_ID).build())
                .build();
    }

    @Test
    void shouldRetrieveWithPaygovMaintenanceWindowEnabled_OnStart() {
        CoreMetaData coreMetaData = Instancio.create(CoreMetaData.class);
        coreMetaData.getPaygovMaintenanceWindow().setStart(ZonedDateTime.now());
        coreMetaData.getPaygovMaintenanceWindow().setEnd(ZonedDateTime.now().plus(1, ChronoUnit.HOURS));
        coreMetaData.setBetaBanners(null);
        when(mockDynamoDbTable.getItem(request)).thenReturn(coreMetaData);

        CoreData response = service.getCoreMetaData();

        ArgumentCaptor<GetItemEnhancedRequest> captor = ArgumentCaptor.forClass(GetItemEnhancedRequest.class);
        verify(mockDynamoDbTable, times(1)).getItem(captor.capture());
        assertThat(response).isEqualTo(CoreData.builder().paygovMaintenanceEnabled(true).build());

        GetItemEnhancedRequest enhancedRequest = captor.getValue();

        assertThat(enhancedRequest.key().partitionKeyValue().s()).isEqualTo(CoreService.CORE_ID);
    }

    @Test
    void shouldRetrieveWithPaygovMaintenanceWindowEnabled_InMiddle() {
        CoreMetaData coreMetaData = Instancio.create(CoreMetaData.class);
        coreMetaData.getPaygovMaintenanceWindow().setStart(ZonedDateTime.now().minus(1, ChronoUnit.HOURS));
        coreMetaData.getPaygovMaintenanceWindow().setEnd(ZonedDateTime.now().plus(3, ChronoUnit.HOURS));
        coreMetaData.setBetaBanners(null);
        when(mockDynamoDbTable.getItem(request)).thenReturn(coreMetaData);

        CoreData response = service.getCoreMetaData();

        assertThat(response).isEqualTo(CoreData.builder().paygovMaintenanceEnabled(true).build());
    }

    @Test
    void shouldRetrieveWithPaygovMaintenanceWindowDisabled_Before() {
        CoreMetaData coreMetaData = Instancio.create(CoreMetaData.class);
        coreMetaData.getPaygovMaintenanceWindow().setStart(ZonedDateTime.now().plus(1, ChronoUnit.HOURS));
        coreMetaData.getPaygovMaintenanceWindow().setEnd(ZonedDateTime.now().plus(2, ChronoUnit.HOURS));
        coreMetaData.setBetaBanners(null);
        when(mockDynamoDbTable.getItem(request)).thenReturn(coreMetaData);

        CoreData response = service.getCoreMetaData();

        assertThat(response).isEqualTo(CoreData.builder().paygovMaintenanceEnabled(false).build());
    }

    @Test
    void shouldRetrieveWithPaygovMaintenanceWindowDisabled_After() {
        CoreMetaData coreMetaData = Instancio.create(CoreMetaData.class);
        coreMetaData.getPaygovMaintenanceWindow().setStart(ZonedDateTime.now().minus(2, ChronoUnit.HOURS));
        coreMetaData.getPaygovMaintenanceWindow().setEnd(ZonedDateTime.now().minus(1, ChronoUnit.HOURS));
        coreMetaData.setBetaBanners(null);
        when(mockDynamoDbTable.getItem(request)).thenReturn(coreMetaData);

        CoreData response = service.getCoreMetaData();

        assertThat(response).isEqualTo(CoreData.builder().paygovMaintenanceEnabled(false).build());
    }

    @Test
    void shouldRetrieveWithBetaBanners() {
        CoreMetaData coreMetaData = Instancio.create(CoreMetaData.class);
        BetaBanner banner = BetaBanner.builder().bannerText("test banner").showBanner(false)
                .showBannerFor(AccountType.REPRESENTATIVE).build();
        coreMetaData.setBetaBanners(List.of(banner));
        when(mockDynamoDbTable.getItem(request)).thenReturn(coreMetaData);

        CoreData response = service.getCoreMetaData();

        assertThat(response.betaBanners()).isEqualTo(List.of(banner));
    }
}
