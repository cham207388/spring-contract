package gov.dhs.uscis.submissionservice.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import static org.junit.Assert.assertSame;
import static org.junit.jupiter.api.Assertions.*;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.submissionservice._testutils.LocalDbCreationRule;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.ScanRequest;

public class ClientInformationRepositoryTest {

    private static final String TABLE_NAME = "default-ClientInformation";
    @RegisterExtension
    static LocalDbCreationRule localDynamoDb = new LocalDbCreationRule();
  
    private static DynamoDbClient dynamoDbClient;
    private static DynamoDbEnhancedClient dynamoDbEnhancedClient;
    private static DynamoDbTable<ClientInformation> clientInformationTable;
    private static ClientInformationRepository clientInformationRepository;    

    @BeforeAll
    private static void before() {

        dynamoDbClient = DynamoDbClient
        .builder()
        .endpointOverride(URI.create(String.format("http://localhost:%s", localDynamoDb.getPort())))
        .build();

        dynamoDbEnhancedClient = DynamoDbEnhancedClient
                .builder()
                .dynamoDbClient(dynamoDbClient)
                .build();

        clientInformationTable = dynamoDbEnhancedClient.table(TABLE_NAME, TableSchema.fromBean(ClientInformation.class));
        clientInformationTable.createTable();

        clientInformationRepository = new ClientInformationRepository(clientInformationTable);

    }

    @BeforeEach
    private void beforeEach() {
        dynamoDbClient.waiter().waitUntilTableExists(b -> b.tableName(clientInformationTable.tableName()));
    }

    @AfterEach
    private void afterEach() {
        clientInformationTable.deleteTable();
        clientInformationTable.createTable();
    }

    private ClientInformation generateClientInformation() {
        return ClientInformation.builder()
                .clientId(UUID.randomUUID().toString())
                .attorneyId(UUID.randomUUID().toString())
                .submissionId(UUID.randomUUID().toString())
                .name(
                    new Name(
                    "TEST_FIRST_NAME", 
                    "TEST_MIDDLE_NAME", 
                    "TEST_LAST_NAME"
                    )
                )
                .userGroupIds(List.of(
                    UUID.randomUUID().toString(),
                    UUID.randomUUID().toString()
                ))
                .build();
    }

    private int count() {
        ScanRequest request = ScanRequest.builder()
                .tableName(clientInformationTable.tableName())
                .select("COUNT").build();
        return dynamoDbClient.scan(request).count();
    }

    private void checkRawClientGetItem(String submissionId) {
        var item = dynamoDbClient.getItem(GetItemRequest.builder()
        .tableName(TABLE_NAME)
        .key(Map.of("submissionId", AttributeValue.fromS(submissionId)))
        .build()).item();
        assertThat(item.get("submissionId").s(), equalTo(submissionId));
    }

    @Test
    public void save_shouldPersist() {
        ClientInformation clientInformation = generateClientInformation();
        ClientInformation savedClientInformation = clientInformationRepository.save(clientInformation);
        assertEquals(1, count());
        assertSame(clientInformation, savedClientInformation);

        checkRawClientGetItem(clientInformation.getSubmissionId());
    }

    @Test
    public void save_shouldPersistMultiple() {
        ClientInformation clientInformationA = generateClientInformation();
        ClientInformation clientInformationB = generateClientInformation();

        ClientInformation savedClientInformationA = clientInformationRepository.save(clientInformationA);
        ClientInformation savedClientInformationB = clientInformationRepository.save(clientInformationB);
        assertEquals(2, count());

        checkRawClientGetItem(clientInformationA.getSubmissionId());
        checkRawClientGetItem(clientInformationB.getSubmissionId());

        assertSame(clientInformationA, savedClientInformationA);
        assertSame(clientInformationB, savedClientInformationB);

        assertNotEquals(clientInformationA, clientInformationB);
        assertNotEquals(savedClientInformationA, savedClientInformationB);

    }

    @Test
    public void save_shouldPersistArgsMethod() {
        ClientInformation clientInformation = generateClientInformation();
        ClientInformation savedClientInformation = clientInformationRepository.save(
            clientInformation.getAttorneyId(), 
            clientInformation.getClientId(), 
            clientInformation.getSubmissionId(), 
            clientInformation.getName(), 
            clientInformation.getUserGroupIds()
        );

        assertEquals(1, count());
        assertEquals(clientInformation, savedClientInformation);

        checkRawClientGetItem(clientInformation.getSubmissionId());
    }

    @Test
    public void save_shouldPersistWithEmptyUserGroupIdsForNullArgument() {
        ClientInformation clientInformation = generateClientInformation();
        ClientInformation savedClientInformation = clientInformationRepository.save(
            clientInformation.getAttorneyId(), 
            clientInformation.getClientId(), 
            clientInformation.getSubmissionId(), 
            clientInformation.getName(), 
            null
        );

        clientInformation.setUserGroupIds(List.of());
        assertEquals(1, count());
        assertEquals(clientInformation, savedClientInformation);

        checkRawClientGetItem(clientInformation.getSubmissionId());
    }

    @Test
    public void save_shouldPersistArgsNoUserGroupIdsMethod() {
        ClientInformation clientInformation = generateClientInformation();
        List<String> groups = List.of("clientGroupId", "lawFirmGroupId");
        ClientInformation savedClientInformation = clientInformationRepository.save(
            clientInformation.getAttorneyId(), 
            clientInformation.getClientId(), 
            clientInformation.getSubmissionId(), 
            clientInformation.getName(), 
            groups
        );

        assertEquals(1, count());

        clientInformation.setUserGroupIds(groups);
        assertEquals(clientInformation, savedClientInformation);

        checkRawClientGetItem(clientInformation.getSubmissionId());
    }

    @Test
    public void shouldRetrieveClientByClientId(){

        ClientInformation clientInformation = generateClientInformation();
        ClientInformation savedClientInformation = clientInformationRepository.save(clientInformation);
        ClientInformation fetchedClientInformation = clientInformationRepository.findBySubmissionId(clientInformation.getSubmissionId());

        Assertions.assertThat(savedClientInformation).usingRecursiveComparison().isEqualTo(clientInformation);
        Assertions.assertThat(fetchedClientInformation).usingRecursiveComparison().isEqualTo(clientInformation);
    }

    @Test
    public void shouldQueryForAllRecordsForAClientId() {
        ClientInformation clientInformationA = generateClientInformation();
        ClientInformation clientInformationA2 = generateClientInformation();
        clientInformationA2.setClientId(clientInformationA.getClientId());

        clientInformationRepository.save(clientInformationA);
        clientInformationRepository.save(clientInformationA2);

        List<ClientInformation> allByClientId = clientInformationRepository.findAllByClientId(clientInformationA.getClientId());
        assertThat(allByClientId.size()).isEqualTo(2);
    }

    @Test 
    public void shouldDeleteClientInformation(){

        ClientInformation clientInformation = generateClientInformation();
        ClientInformation savedClientInformation = clientInformationRepository.save(clientInformation);
        ClientInformation fetchedClientInformation = clientInformationRepository.findBySubmissionId(clientInformation.getSubmissionId());

        Assertions.assertThat(savedClientInformation).usingRecursiveComparison().isEqualTo(clientInformation);
        Assertions.assertThat(fetchedClientInformation).usingRecursiveComparison().isEqualTo(clientInformation);

        clientInformationRepository.delete(clientInformation);

        ClientInformation deletedClientInformation = clientInformationRepository.findBySubmissionId(clientInformation.getSubmissionId());
        assertThat(deletedClientInformation).isNull();

    }

}
