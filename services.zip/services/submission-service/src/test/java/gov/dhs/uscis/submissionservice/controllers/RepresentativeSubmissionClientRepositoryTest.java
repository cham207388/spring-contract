package gov.dhs.uscis.submissionservice.controllers;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.submissionservice.repository.ClientInformationRepository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;

public class RepresentativeSubmissionClientRepositoryTest {

    private static final String ATTORNEY_ID = "attorneyId";
    private static final String SUBMISSION_ID = "submissionId";
    private static final String CLIENT_ID = "clientId";
    private static final List<String> USER_GROUP_IDS = List.of(UUID.randomUUID().toString());

    @Test
    public void shouldPersistRepresentativeMappingToDatabaseWhenNoneExist() {
        DynamoDbTable<ClientInformation> clientInformationTable = mock(DynamoDbTable.class);
        var repository = new ClientInformationRepository(clientInformationTable);

        var name = new Name("first", "middle", "last");
        ArgumentCaptor<PutItemEnhancedRequest<ClientInformation>> putCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        List<String> groups = List.of("fakeId");
        repository.save(ATTORNEY_ID, CLIENT_ID, SUBMISSION_ID, name, groups);

        when(clientInformationTable.getItem(any(GetItemEnhancedRequest.class))).thenReturn(null);

        verify(clientInformationTable, times(1)).putItem(putCaptor.capture());
        var put = putCaptor.getValue();

        assertThat(put.item().getClientId()).isEqualTo(CLIENT_ID);
        assertThat(put.item().getSubmissionId()).isEqualTo(SUBMISSION_ID);
        assertThat(put.item().getAttorneyId()).isEqualTo(ATTORNEY_ID);
        assertThat(put.item().getName()).isEqualTo(name);
        assertThat(put.item().getUserGroupIds()).containsExactlyElementsOf(groups);
    }

    @Test
    public void shouldPersistRepresentativeMappingToDatabaseWithUserGroupIds() {
        DynamoDbTable<ClientInformation> clientInformationTable = mock(DynamoDbTable.class);
        var repository = new ClientInformationRepository(clientInformationTable);

        var name = new Name("first", "middle", "last");
        var userGroupIds = List.of(UUID.randomUUID().toString());
        repository.save(ATTORNEY_ID, CLIENT_ID, SUBMISSION_ID, name, userGroupIds);

        ArgumentCaptor<PutItemEnhancedRequest<ClientInformation>> putCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(clientInformationTable, times(1)).putItem(putCaptor.capture());
        var put = putCaptor.getValue();

        assertThat(put.item().getClientId()).isEqualTo(CLIENT_ID);
        assertThat(put.item().getSubmissionId()).isEqualTo(SUBMISSION_ID);
        assertThat(put.item().getAttorneyId()).isEqualTo(ATTORNEY_ID);
        assertThat(put.item().getName()).isEqualTo(name);
        assertThat(put.item().getUserGroupIds()).isEqualTo(userGroupIds);
    }

    @Test
    public void shouldPersistRepresentativeMappingToDatabaseWhenOneExists() {
        DynamoDbTable<ClientInformation> clientInformationTable = mock(DynamoDbTable.class);
        var repository = new ClientInformationRepository(clientInformationTable);

        var name = new Name("first", "middle", "last");
        when(clientInformationTable.getItem(any(GetItemEnhancedRequest.class))).thenReturn(ClientInformation.builder()
                .attorneyId(ATTORNEY_ID)
                .submissionId(SUBMISSION_ID)
                .userGroupIds(USER_GROUP_IDS)
                .build());

        repository.save(ATTORNEY_ID, CLIENT_ID, SUBMISSION_ID, name, USER_GROUP_IDS);

        ArgumentCaptor<PutItemEnhancedRequest<ClientInformation>> putCaptor = ArgumentCaptor
                .forClass(PutItemEnhancedRequest.class);
        verify(clientInformationTable, times(1)).putItem(putCaptor.capture());
        var put = putCaptor.getValue();

        assertThat(put.item().getClientId()).isEqualTo(CLIENT_ID);
        assertThat(put.item().getSubmissionId()).isEqualTo(SUBMISSION_ID);
        assertThat(put.item().getAttorneyId()).isEqualTo(ATTORNEY_ID);
        assertThat(put.item().getName()).isEqualTo(name);
        assertThat(put.item().getUserGroupIds()).isEqualTo(USER_GROUP_IDS);
    }
}
