package gov.dhs.uscis.submissionservice.controllers.MockMvc;

import static org.instancio.Select.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockPart;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.util.MimeType;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.UploadResponse;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.controllers.DocumentController;
import gov.dhs.uscis.submissionservice.converters.SubmissionParameterConverter;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceResponse;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;
import gov.dhs.uscis.submissionservice.models.dto.S3FileInfo;
import gov.dhs.uscis.submissionservice.services.ElisService;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.services.S3Service;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.validators.backend.UploadEvidenceValidator;
import jakarta.servlet.http.Part;

@WebMvcTest(DocumentController.class)
@AutoConfigureMockMvc
public class DocumentControllerDocsTest {

    private static final String MYUSCIS_ID = UUID.randomUUID().toString();
    private static final String ORG_MYUSCIS_ID = UUID.randomUUID().toString();
    private static final String SUBMISSION_ID = UUID.randomUUID().toString();
    private static final String FORM_ID = "form_id";
    private static final String FORM_TYPE ="I-765";

    @MockitoBean
    ElisService elisService;

    @MockitoBean
    private UploadEvidenceValidator uploadEvidenceValidator;

    @MockitoBean
    private SubmissionService submissionService;

    @MockitoBean
    private S3Service s3Service;

    @MockitoBean
    private FormService formService;

    @MockitoBean
    private AuditService auditService;

    @MockitoBean
    SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void uploadForm() throws Exception {
        var s3ObjectKey = "test_file.pdf";
        UploadRequest request = UploadRequest.builder()
            .fileName(s3ObjectKey).formType("I765")
                .md5Hash("md5Hash")
                .build();
        UploadResponse response = new UploadResponse(FORM_ID, "artifactId", null);

        MockMultipartFile multipartFile = new MockMultipartFile(
                "file",
                "hello.pdf",
                MediaType.MULTIPART_FORM_DATA_VALUE,
                "Hello, World!".getBytes());

        MockMultipartFile multipartRequest = new MockMultipartFile("uploadRequest", "", "application/json",
                new ObjectMapper().writeValueAsString(request).getBytes());

        List<SubmissionForm> originalForms = new ArrayList<>();
        originalForms.add(SubmissionForm.builder().id("some-id").s3Key(s3ObjectKey).type("I765").build());
        Submission originalSubmission = Submission.builder()
                .forms(originalForms)
                .build();

        List<SubmissionForm> forms = new ArrayList<>();
        forms.add(SubmissionForm.builder().id(FORM_ID).s3Key(s3ObjectKey).type("I765").build());

        Submission submission = Submission.builder()
                .forms(forms)
                .build();

        S3FileInfo s3FileInfo = new S3FileInfo(FORM_ID, "checksum123", "artifactId", s3ObjectKey);
        when(s3Service.uploadForm(any(Submission.class), anyString(), any(MultipartFile.class), any(UploadRequest.class)))
                .thenReturn(s3FileInfo);
        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(originalSubmission);
        when(submissionService.updateSubmissionWithForm(any(Submission.class), any(UploadRequest.class),
                any(MultipartFile.class)))
                .thenReturn(submission);

        mockMvc.perform(MockMvcRequestBuilders
                .multipart("/api/v1/{myUscisId}/submissions/{submissionId}/form?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                .file(multipartFile)
                .file(multipartRequest)
                .with(jwt()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.formId").value(response.formId()));
    }

    @Test
    public void uploadEvidence() throws Exception {
        var EVIDENCE_ID = "54321";
        var s3ObjectKey = "moi.jpg";
        UploadEvidenceRequest evidenceRequest = UploadEvidenceRequest.builder()
                .fileName(s3ObjectKey)
                .type("photo")
                .evidenceGroupType("form-i-94-passport")
                .build();
        UploadEvidenceResponse evidenceResponse = new UploadEvidenceResponse(EVIDENCE_ID, "name", FORM_ID, null, null, null);

        Submission priorUpdate = Submission.builder()
                .formType(FormType.I765)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .evidences(List.of())
                .forms( List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I765.getType())
                        .eligibilityCategory(I765EligibilityCategory.C8)
                    .build()))
                .build();

        Submission afterUpdate = Submission.builder()
                .formType(FormType.I765)
                .eligibilityCategory(I765EligibilityCategory.C8)
                .forms( List.of(SubmissionForm.builder()
                        .id("mock-id")
                        .type(FormType.I765.getType())
                        .eligibilityCategory(I765EligibilityCategory.C8)
                    .build()))
                .evidences(List.of(SubmissionEvidence.builder().id(EVIDENCE_ID).formId(FORM_ID).build()))
                .build();

        EvidenceGroup group = Instancio.of(EvidenceGroup.class)
                .set(field(EvidenceGroup::getAllowMediaTypes), List.of(MimeType.valueOf("image/jpeg")))
                .set(field(EvidenceGroup::getMaxNumberOfFiles), 1)
                .set(field(EvidenceGroup::getId), "form-i-94-passport")
                .create();
        when(formService.retrieveEvidenceGroup(any(), any(), any())).thenReturn(group);
        when(submissionService.retrieveSubmissionByIdAndUscisId(eq(SUBMISSION_ID), eq(MYUSCIS_ID), eq(null)))
                .thenReturn(priorUpdate);
        when(elisService.validatePhoto(any(), any())).thenReturn(ResponseEntity.ok().build());
        when(s3Service.uploadEvidence(anyString(), anyString(), any(Part.class), any(UploadEvidenceRequest.class),
                any(Submission.class), anyString()))
                .thenReturn(new S3FileInfo(EVIDENCE_ID, "checksum123", "artifactId", s3ObjectKey));
        when(submissionService.updateSubmissionWithEvidence(anyString(), isNull(), anyString(), anyString(), any(UploadEvidenceRequest.class),
                any(S3FileInfo.class), anyString())).thenReturn(afterUpdate);

        MockPart file = new MockPart("files", "moi.jpg", "test content".getBytes(), MediaType.IMAGE_JPEG);
        MockPart request = new MockPart("uploadEvidenceRequests",
                new ObjectMapper().writeValueAsString(evidenceRequest).getBytes());

        mockMvc.perform(MockMvcRequestBuilders
                .multipart("/api/v1/{myUscisId}/submissions/{submissionId}/evidence/{selectedFormType}?=undefined&formId=form_id", MYUSCIS_ID, SUBMISSION_ID, FORM_TYPE)
                .part(file, request)
                .with(jwt()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(evidenceResponse.id()));
    }

    @Test
    public void uploadFeeWaiver() throws Exception {
        var feeWaiverId = UUID.randomUUID().toString();
        var s3ObjectKey = "test.pdf";
        UploadFeeWaiverRequest feeWaiverRequest = new UploadFeeWaiverRequest(s3ObjectKey);

        Submission initialSubmission = Submission.builder().submissionId(SUBMISSION_ID).build();

        Submission submission = Submission.builder()
                .feeWaiver(SubmissionEvidence.builder().id(feeWaiverId).build())
                .build();

        when(submissionService.retrieveDraftSubmission(MYUSCIS_ID, null, SUBMISSION_ID)).thenReturn(initialSubmission);

        when(formService.isFeeWaiverEnabled(initialSubmission.getFormType())).thenReturn(true);
        when(s3Service.uploadFeeWaiver(anyString(), anyString(), any(MultipartFile.class),
                any(UploadFeeWaiverRequest.class), any(Submission.class)))
                .thenReturn(new S3FileInfo(feeWaiverId, "checksum123", "artifactId", s3ObjectKey));
        when(submissionService.updateSubmissionWithFeeWaiver(anyString(), isNull(), anyString(),
                any(UploadFeeWaiverRequest.class),
                any(S3FileInfo.class))).thenReturn(submission);

        MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "application/pdf",
                createTestPdf(612, 792, 1.0f));
        MockMultipartFile multipartRequest = new MockMultipartFile("uploadFeeWaiverRequest", "",
                "application/json", new ObjectMapper().writeValueAsString(feeWaiverRequest).getBytes());

        mockMvc.perform(MockMvcRequestBuilders
                .multipart("/api/v1/{myUscisId}/submissions/{submissionId}/feeWaiver?=undefined", MYUSCIS_ID, SUBMISSION_ID)
                .file(file)
                .file(multipartRequest)
                .with(jwt()))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.submission.feeWaiver.id").value(feeWaiverId));
    }

    private byte[] createTestPdf(float width, float height, float userUnit) throws IOException {
        try (PDDocument document = new PDDocument(); ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            PDPage page = new PDPage(new PDRectangle(width, height));
            page.setUserUnit(userUnit);
            document.addPage(page);
            document.save(baos);
            return baos.toByteArray();
        }
    }
}