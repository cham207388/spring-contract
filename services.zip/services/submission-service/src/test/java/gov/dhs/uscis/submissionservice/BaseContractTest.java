package gov.dhs.uscis.submissionservice;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.format.support.FormattingConversionService;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.MimeType;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.EvidenceType;
import gov.dhs.uscis.intake.models.FinalTransmissionStatus;
import gov.dhs.uscis.intake.models.FinalTransmissionStatus.StatusEnum;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest;
import gov.dhs.uscis.intake.models.WatermarkerStatus;
import gov.dhs.uscis.intake.models.validation.ValidationDetails;
import gov.dhs.uscis.intake.models.validation.Validation;
import gov.dhs.uscis.intake.models.validation.ValidationStatusEnum;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResponse;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.services.FeeService;
import gov.dhs.uscis.submissionservice.controllers.DocumentController;
import gov.dhs.uscis.submissionservice.controllers.ElisDataEnrichmentPipeline;
import gov.dhs.uscis.submissionservice.controllers.FormController;
import gov.dhs.uscis.submissionservice.controllers.SubmissionController;
import gov.dhs.uscis.submissionservice.controllers.SubmissionManifestController;
import gov.dhs.uscis.submissionservice.converters.SubmissionParameterConverter;
import gov.dhs.uscis.submissionservice.models.EligibilityCategoryResponse;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.dto.S3FileInfo;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AccountTypeResponse;
import gov.dhs.uscis.submissionservice.models.submissionStatus.ErrorGroup;
import gov.dhs.uscis.submissionservice.models.submissionStatus.SubmissionStatusResponse;
import gov.dhs.uscis.submissionservice.services.DraftBenefitsService;
import gov.dhs.uscis.submissionservice.services.ElisService;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.services.PeepsService;
import gov.dhs.uscis.submissionservice.services.S3Service;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ValidationService;
import gov.dhs.uscis.submissionservice.services.fees.handlers.I765Handler;
import gov.dhs.uscis.submissionservice.validators.backend.UploadEvidenceValidator;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import reactor.core.publisher.Mono;

@SpringBootTest
public abstract class BaseContractTest {
    @Autowired
    private ApplicationContext context;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private FormService formService;
    @MockitoBean
    private S3Service s3Service;
    @MockitoBean
    private ValidationService validationService;
    @MockitoBean
    private SubmissionService submissionService;
    @MockitoBean
    private ElisDataEnrichmentPipeline elisDataEnrichmentPipeline;
    @MockitoBean
    private UploadEvidenceValidator uploadEvidenceValidator;
    @MockitoBean
    private ElisService elisService;
    @MockitoBean
    private DraftBenefitsService draftBenefitsService;
    @MockitoBean
    private PeepsService peepsService;
    @MockitoBean
    private AuditService auditService;
    @MockitoBean
    private FeeService feeService;
    @Autowired
    private SubmissionManifestController submissionManifestController;
    @Autowired
    private SubmissionController submissionController;
    @MockitoBean
    private I765Handler i765Handler;
    @Autowired
    private DocumentController documentController;
    @Autowired
    private FormController formController;
    @Autowired
    private SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;

    Map<String, BigDecimal> fees = new HashMap<String, BigDecimal>() {{
        put("C8ABCINITIALFEE", new BigDecimal("1030"));
        put("C8INITIALFEE", new BigDecimal("560"));
        put("C8INITIALFEEWAIVER", new BigDecimal("0"));
        put("C8ABCINITIALFEEWAIVER", new BigDecimal("470"));
        put("C8REPLACEMENTFEE", new BigDecimal("470"));
        put("C8REPLACEMENTFEEWAIVER", new BigDecimal("0"));
        put("C8RENEWALFEE", new BigDecimal("745"));
        put("C8RENEWALFEEWAIVER", new BigDecimal("470"));
        put("A19C19INITALFEE", new BigDecimal("1030"));
        put("A19C19INITALFEEWAIVER", new BigDecimal("470"));
        put("A19C19RENEWALFEEWAIVER", new BigDecimal("470"));
        put("A19C19RENEWALFEE", new BigDecimal("745"));
        put("C11INITIALUKRAINEFEE", new BigDecimal("560"));
        put("C11INITIALUKRAINEFEEWAIVER", new BigDecimal("470"));
        put("C11INITIALFAGHANFEE", new BigDecimal("1030"));
        put("C11INITIALFAGHANFEEWAIVER", new BigDecimal("470"));
        put("C11INITIALIMVIFEEWAIVER", new BigDecimal("0"));
        put("C11IMMVIINITIALFEE", new BigDecimal("280"));
        put("C11INITIALFEE", new BigDecimal("1030"));
        put("C11INITIALFEEWAIVER", new BigDecimal("470"));
        put("C11REPLACEMENTFAGHANFEE", new BigDecimal("470"));
        put("C11REPLACEMENTFAGHANFEEWAIVER", new BigDecimal("470"));
        put("C11IMMVIRENEWALFEE", new BigDecimal("280"));
        put("C11IMMVIRENEWALFEEWAIVER", new BigDecimal("0"));
        put("C11RENEWALFEE", new BigDecimal("745"));
        put("C11RENEWALFEEWAIVER", new BigDecimal("470"));
    }};
    @BeforeEach
    void setUp() throws Exception {
        LocalValidatorFactoryBean validatorFactoryBean = new LocalValidatorFactoryBean();
        validatorFactoryBean.setApplicationContext(context);
        validatorFactoryBean.afterPropertiesSet();

        FormattingConversionService formattingConversionService = new FormattingConversionService();
        formattingConversionService.addConverter(submissionIdToFinalSubmissionDtoConverter);

        MockMvc mockMvc = MockMvcBuilders.standaloneSetup(submissionManifestController, submissionController, documentController, formController)
        .setMessageConverters(new MappingJackson2HttpMessageConverter(objectMapper), new ByteArrayHttpMessageConverter())
        .setValidator(validatorFactoryBean)
        .setConversionService(formattingConversionService)
        .build();


        RestAssuredMockMvc.mockMvc(mockMvc);

        byte[] bytes = Files.readAllBytes(Path.of(
            System.getProperty("user.dir")
                    + "/src/contractTest/resources/contracts/mock-files/response.pdf"));
        when(submissionService.retrieveSubmission(anyString()))
                .thenReturn(getSubmission("formId","evidenceId"));

        when(submissionService.retrieveSubmissionByManifestId(anyString()))
                .thenReturn(Optional.of(getSubmission()));

        when(submissionService.retrieveDraftSubmission(anyString(), anyString(), anyString()))
                .thenReturn(getSubmission());


        when(elisDataEnrichmentPipeline.enrich(any(Submission.class)))
                .thenReturn(getSubmission());

        when(submissionService.attestForm(anyString(), anyString(), anyString(), anyString(), anyBoolean(), anyString()))
                .thenReturn(getSubmission());

        when(submissionService.createInitialSubmission(anyString(), any(SubmissionRequest.class)))
                .thenReturn(getSubmission());

        doNothing().when(submissionService).deleteDraftSubmission(anyString(), anyString(), anyString());

        when(submissionService.retrieveSubmissionStatus(anyString(), anyString(), anyString()))
                .thenReturn(getSubmissionStatusResponse());

        when(submissionService.getAttestationStatus(anyString(), anyString()))
                .thenReturn(WatermarkerStatus.StatusEnum.SUCCESS);

        when(i765Handler.retrieveFees(anyString())).thenReturn(fees);
        when(submissionService.retrieveDraftSubmissions(anyString()))
                .thenReturn(List.of(getSubmission()));

        when(submissionService.deleteFormFromSubmission(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(getSubmission());

        when(submissionService.updateSubmissionWithForm(any(Submission.class), any(), any()))
                .thenReturn(getSubmission("s3FileId","s3FileId"));

        when(s3Service.uploadForm(any(), any(), any(), any()))
                .thenReturn(getS3FileInfo());

        when(s3Service.getFileData(anyString(), anyBoolean()))
                .thenReturn("Mock PDF".getBytes());

        when(submissionService.getFinalTransmissionStatus(anyString(), anyString()))
                .thenReturn(FinalTransmissionStatus.builder()
                    .status(StatusEnum.SUCCESS)
                    .message("successful")
                    .build());

        when(validationService.retrieveValidationStatus(any(Submission.class)))
                .thenReturn(getValidationStatusResponse());

        when(validationService.retrieveI912ValidationStatus(anyString(), any(Submission.class)))
                .thenReturn(getI912FeeWaiverValidationStatusResponse());

        when(draftBenefitsService.canApplicantFileFor(anyString(),anyString()))
                .thenReturn(true);

        when(peepsService.retrieveAccountType(anyString())).thenReturn(AccountTypeResponse.builder().accountType(AccountType.APPLICANT).build());

        when(formService.retrieveEligibilityCategories(anyString()))
                .thenReturn(List.of(new EligibilityCategoryResponse("category", true, true)));

        when(submissionService.updateDraftSubmissionLock(any(Submission.class)))
                .thenReturn(getSubmission());

        when(submissionService.deleteFeeWaiverFromSubmission(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(getSubmission());

        when(submissionService.updateFeeWaiverEvidence(any(Submission.class), anyString(), anyBoolean()))
                .thenReturn(getSubmission());

        when(validationService.validateUpdateSubmission(any(Submission.class), any(FormType.class)))
                .thenReturn(true);

        when(submissionService.deleteEvidenceFromSubmission(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(null);

        doNothing().when(validationService).deleteStatus(anyString());

        when(submissionService.updateEvidence(any(Submission.class), anyString(), anyString()))
                .thenReturn(getSubmission());

        when(submissionService.findAllByMyUscisIdAndStatus(anyString(), anyList()))
                .thenReturn(List.of(getSubmission()));

        when(submissionService.updateSubmissionWithLockBoxStatus(anyString(), any(SubmissionUpdateRequest.class)))
                .thenReturn(getSubmission());

        when(s3Service.getFileData(anyString(), anyBoolean()))
                .thenReturn(bytes);

        when(formService.retrieveEvidenceGroupValidations(anyString(), anyString(), anyString()))
                .thenReturn(List.of(MetadataValidationEnum.CORE));

        when(submissionService.completeSubmission(anyString(), anyString(), anyString()))
                .thenReturn(Mono.just("someId"));

        when(formService.retrieveFormMetaData(anyString()))
            .thenReturn(getFormTypeMetadata());

        when(formService.retrieveEvidenceGroups(anyString(), anyString()))
                .thenReturn(List.of(
                        EvidenceGroup.builder()
                        .id("id")
                        .name("name")
                        .allowMediaTypes(List.of(new MimeType("null")))
                        .maxNumberOfFiles(1)
                        .validations(List.of(MetadataValidationEnum.CORE))
                        .evidenceTypes(List.of(EvidenceType.builder()
                            .id("type")
                            .name("name")
                            .contentCategoryCode(0)
                            .build()))
                        .build())
                    );

        when(s3Service.deleteS3Object(anyString(), anyBoolean()))
            .thenReturn("Deletion successful");

        when(formService.isFeeWaiverEnabled(any(FormType.class)))
            .thenReturn(true);

        when(s3Service.uploadFeeWaiver(anyString(), anyString(), any(MultipartFile.class), any(UploadFeeWaiverRequest.class), any(Submission.class)))
            .thenReturn(S3FileInfo.builder().id("id").checksum("checksum").artifactId("artifactId").s3Key("s3Key").build());

        when(submissionService.updateSubmissionWithFeeWaiver(anyString(), anyString(), anyString(),  any(UploadFeeWaiverRequest.class), any(S3FileInfo.class)))
            .thenReturn(getSubmission());
    }

    private Submission getSubmission() {
        return SubmissionFactory.forSubmissionId(UUID.randomUUID().toString(), UUID.randomUUID().toString(),
            FormType.I765);
    }

    private Submission getSubmission(String formId, String evidenceId) {
        Submission submission = getSubmission();
        submission.getForms().forEach(form -> form.setId(formId));
        submission.getEvidences().forEach(evidence -> evidence.setId(evidenceId));
        return submission;
    }

    private SubmissionStatusResponse getSubmissionStatusResponse() {
        return SubmissionStatusResponse.builder()
            .submissionErrors(List.of("error1"))
            .formErrors(List.of(
                ErrorGroup.builder()
                    .type(FormType.I765.getType())
                    .errors(List.of("error1"))
                .build()
            ))
            .evidenceErrors(List.of(ErrorGroup.builder()
                        .type("photo")
                        .errors(List.of("error1"))
                        .build()))
            .build();
    }

    private ValidationStatusResponse getValidationStatusResponse() {
        return ValidationStatusResponse.builder()
                .status(ValidationStatusEnum.IN_PROGRESS)
                .formValidations(List.of(
                    Validation.builder()
                                .groupType("contract testing")
                                .id("producer123")
                                .status(ValidationStatusEnum.IN_PROGRESS)
                                .details(getValidationDetails())
                                .build())
                )
                .evidenceValidations(List.of(
                        Validation.builder()
                                .groupType("contract testing")
                                .id("producer123")
                                .status(ValidationStatusEnum.IN_PROGRESS)
                                .details(getValidationDetails())
                                .build())
                        )
                .build();
    }

    private ValidationStatusResponse getI912FeeWaiverValidationStatusResponse() {
        return ValidationStatusResponse.builder()
                .status(ValidationStatusEnum.IN_PROGRESS)
                .i912FeeWaiverValidation(getValidationDetails().get(0))
                .build();
    }

    private List<ValidationDetails> getValidationDetails() {
        return List.of(ValidationDetails.builder()
                .validator(ValidatorEnum.SIGNATURE)
                .result(ValidationResultEnum.PASS)
                .reasons(List.of("signature check"))
                .warnings(null)
                .build());
    }

    private S3FileInfo getS3FileInfo() {
        return new S3FileInfo("s3FileId", "checksum", "artifacId", "info");
    }

    private FormMetaData getFormTypeMetadata() {
        /*
         * String formType;
            String formDescription;
            Boolean showBanner;
            Boolean enabled;
            List<FormEdition> editions;
            List<MetadataValidationEnum> validations;
            List<EligibilityCategory> eligibilityCategories;
            Pages pages;
            Map<String, Integer> landmarks;
        *
        */

        return FormMetadataFactory.getFormMetadata();
    }

}
