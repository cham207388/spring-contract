package gov.dhs.uscis.submissionservice.validators.AttorneyProfileValidator;

import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.models.validation.ClientNameEmailResponse;
import gov.dhs.uscis.intake.models.validation.name_extract.ClientName;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.RepresentativeProfileResponseData;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.PeepsService;

@ExtendWith(MockitoExtension.class)
public class ClientNameEmailValidatorTest {
    private static final String submissionId = UUID.randomUUID().toString();
    private static final String formId = UUID.randomUUID().toString();
    private static final String myUscisId = UUID.randomUUID().toString();
    private static final String givenName = "Doe";
    private static final String firstName = "John";
    private static final String email = "j.doe@uscis.dhs.gov";

    @Test
    public void validateClientAttorneyNameEmail_ShouldFailIfNameAndEmailMatch() {
        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var clientNameEmailValidator = new ClientNameEmailValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(firstName, givenName, email);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, givenName, email);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        clientNameEmailValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.FAIL
                && status.getFailureReasons().contains(
                        "You cannot use your name and/or email address in the client information name and email address fields")));
    }

    @Test
    public void validateClientAttorneyNameEmail_ShouldPassIfNameIsNull() {
        final String newEmail = "ktrout@ilium.edu";
        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var clientNameEmailValidator = new ClientNameEmailValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(null, null, newEmail);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, givenName, email);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        clientNameEmailValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.PASS));
    }

    @Test
    public void validateClientAttorneyNameEmail_ShouldPassIfEmailIsNull() {
        String newFirstName = "Kilgore";
        String newLastName = "Trout";

        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var clientNameEmailValidator = new ClientNameEmailValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(newFirstName, newLastName, null);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, givenName, email);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        clientNameEmailValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.PASS));
    }

    @Test
    public void validateClientAttorneyNameEmail_ShouldPassIfEmailAndEmailAreNull() {
        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var clientNameEmailValidator = new ClientNameEmailValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(null, null, null);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, givenName, email);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        clientNameEmailValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.PASS));
    }

    @Test
    public void validateClientAttorneyNameEmail_ShouldFailIfOnlyEmailMatches() {
        String newFirstName = "Kilgore";
        String newLastName = "Trout";

        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var clientNameEmailValidator = new ClientNameEmailValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(newFirstName, newLastName, email);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, givenName, email);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        clientNameEmailValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.FAIL
                && status.getFailureReasons().contains(
                        "You cannot use your name and/or email address in the client information name and email address fields")));
    }

    @Test
    public void validateClientAttorneyNameEmail_ShouldFailIfOnlyNameMatches() {
        String newEmail = "ktrout@uscis.dhs.gov";

        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var clientNameEmailValidator = new ClientNameEmailValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(firstName, givenName, newEmail);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, givenName, email);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        clientNameEmailValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.FAIL
                && status.getFailureReasons().contains(
                        "You cannot use your name and/or email address in the client information name and email address fields")));
    }

    @Test
    public void validateClientAttorneyNameEmail_ShouldPassIfNameAndEmailNotMatch() {
        String newFirstName = "Kilgore";
        String newLastName = "Trout";
        String newEmail = "ktrout@uscis.dhs.gov";

        PeepsService peepsService = mock(PeepsService.class);
        ValidationStatusRepository validationStatusDAO = mock(ValidationStatusRepository.class);
        var clientNameEmailValidator = new ClientNameEmailValidator(peepsService, validationStatusDAO);
        ClientNameEmailResponse response = generateResponse(newFirstName, newLastName, newEmail);
        RepresentativeProfileResponseData peepsResponse = generateProfileResponse(firstName, givenName, email);

        when(peepsService.retrieveRepresentativeProfile(myUscisId)).thenReturn(peepsResponse);

        clientNameEmailValidator.validate(response);

        verify(validationStatusDAO).save(argThat(status -> status.getStatus() == ValidationResultEnum.PASS
                && status.getFailureReasons().isEmpty()));
    }

    private ClientNameEmailResponse generateResponse(String firstName, String lastName, String email) {
        ClientName clientName = ClientName.builder().familyName(lastName).givenName(firstName).build();
        return ClientNameEmailResponse.builder()
                .formId(formId)
                .submissionId(submissionId)
                .myUscisId(myUscisId)
                .clientName(clientName)
                .email(email)
                .build();
    }

    private RepresentativeProfileResponseData generateProfileResponse(String firstName, String lastName, String email) {
        return RepresentativeProfileResponseData.builder()
                .firstName(firstName)
                .lastName(lastName)
                .email(email)
                .build();
    }
}
