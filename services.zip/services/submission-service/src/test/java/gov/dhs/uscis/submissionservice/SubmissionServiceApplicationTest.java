package gov.dhs.uscis.submissionservice;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.hamcrest.Matchers.matchesPattern;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;

import com.fasterxml.jackson.core.JsonProcessingException;

import static gov.dhs.uscis.intake.entities.submission.SubmissionState.DRAFT;
import static gov.dhs.uscis.intake.entities.submission.SubmissionState.PUBLISHED;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import static gov.dhs.uscis.intake.enums.I765EligibilityCategory.A12;
import static gov.dhs.uscis.intake.enums.I765EligibilityCategory.C11PAROLE;
import static gov.dhs.uscis.intake.enums.I765EligibilityCategory.C8;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.FAIL;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.PASS;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.CORE;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.ELIGIBILITY_CATEGORY;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.intake.models.dto.SubmissionDto;
import static gov.dhs.uscis.submissionservice.SubmissionFactory.aNewSubmission;
import static gov.dhs.uscis.submissionservice.SubmissionFactory.attachedEvidence;
import static gov.dhs.uscis.submissionservice.SubmissionFactory.attachedFeeWaiver;
import static gov.dhs.uscis.submissionservice.SubmissionFactory.attachedForm;
import gov.dhs.uscis.submissionservice.config.ApplicationConfig;
import gov.dhs.uscis.submissionservice.models.dto.EligibilityUpdateRequest;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = {
        ApplicationConfig.class }, properties = "spring.main.allow-bean-definition-overriding=true")
@AutoConfigureWebTestClient(timeout = "600000")
class SubmissionServiceApplicationTest extends BaseJourneyTest {

    @BeforeEach
    public void setup() throws JsonProcessingException {
        this.withFileableSubmission(MYUSCIS_ID);
    }

    @Test
    void shouldCreateSubmissionAndUpdateEligibilityCategory() {
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        updateEligibility(MYUSCIS_ID, submissionId, C8);
    }

    @Test
    void shouldReturnOkWhenUpdatingEvidenceWithAValidType() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);

        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);

        List<String> evidenceIds = this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.updateEvidence(MYUSCIS_ID, submissionId, evidenceIds.get(0), "Form I-94");
    }

    @Test
    void shouldReturnOkWhenADraftIsDeleted() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
     //   this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
   //     this.waitForSignatureAnalysis(MYUSCIS_ID, submissionId, formId, FAIL);
     //   this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, ELIGIBILITY_CATEGORY);
        this.deleteFormByFormId(MYUSCIS_ID, submissionId, formId, fileName);
    }

    @Test
    void shouldNotRetrieveDraftsWhenThereAreNone() {
        client.get()
                .uri("/api/v1/{MYUSCIS_ID}/submissions/drafts", MYUSCIS_ID)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(APPLICATION_JSON)
                .expectBody().json("[]");
    }

    @Test
    void shouldRetrieveDraftsWhenUserHasCreatedDrafts() {
        // FIXME: These dates should always be UTC
        String ISO_8601 = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}.+";

        // Given a draft submission
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);

        // When I get the list of drafts
        client.get()
                .uri("/api/v1/{MYUSCIS_ID}/submissions/drafts", MYUSCIS_ID)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.[0].myUscisId").isEqualTo(MYUSCIS_ID)
                .jsonPath("$.[0].submissionId").isEqualTo(submissionId)
                .jsonPath("$.[0].status").isEqualTo(DRAFT.name())
                .jsonPath("$.[0].timestamp").value(matchesPattern(ISO_8601))
                .jsonPath("$.[0].updatedAt").value(matchesPattern(ISO_8601))
                .jsonPath("$.[0].expireDate").value(matchesPattern(ISO_8601));
    }

    @Test
    void shouldUploadingMultipleEvidenceForFormI94() {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        List<String> evidenceIds = this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());

        org.assertj.core.api.Assertions.assertThat(evidenceIds.isEmpty()).isFalse();
    }

    @Test
    void shouldReturnOkWhenUploadingMultipleFilesForFormI589() {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Other", "form-i-589", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
    }

    @Test
    void shouldReturnOkWhenUploadingMultipleFilesAtOnceForFormI589() {
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Other", "form-i-589", "i-756-with-signature.pdf", "i-756.pdf");
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
    }

    @Test
    void shouldSuccessfullyDeleteAnUploadedForm() throws JsonProcessingException {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        String formId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
      //  this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, CORE);
    //    this.waitForSignatureAnalysis(MYUSCIS_ID, submissionId, formId, FAIL);
     //   this.waitForValidation(formId, submissionId, MYUSCIS_ID, PASS, ELIGIBILITY_CATEGORY);
        this.deleteFormByFormId(MYUSCIS_ID, submissionId, formId, fileName);
    }

    @Test
    void shouldDeleteEvidenceFromSubmissionAndS3() throws JsonProcessingException {
        String fileName = "empty.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        String evidenceId = this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful()).get(0);
        this.deleteEvidenceByEvidenceId(MYUSCIS_ID, submissionId, evidenceId, fileName, true);
    }

    @Test
    void shouldDeleteEvidenceFromSubmissionOnlyWithFeeWaiver() throws JsonProcessingException {
        String fileName = "empty.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        String evidenceId = this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful()).get(0);
        var feeWaiverId = this.uploadFeeWaiver(MYUSCIS_ID, submissionId,
                attachedFeeWaiver(fileName, MYUSCIS_ID, submissionId));
        this.deleteEvidenceByEvidenceId(MYUSCIS_ID, submissionId, evidenceId, fileName, true);
        String s3Key = String.format("%s/%s/%s", submissionId, MYUSCIS_ID, fileName);
        assertTrue(fileExists(EVIDENCE_BUCKET, s3Key, feeWaiverId));
    }

    @Test
    void shouldDeleteFeeWaiverFromSubmissionAndS3() throws JsonProcessingException {
        String fileName = "empty.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, A12);
        String feeWaiverId = this.uploadFeeWaiver(MYUSCIS_ID, submissionId,
                attachedFeeWaiver(fileName, MYUSCIS_ID, submissionId));
        this.deleteFeeWaiver(MYUSCIS_ID, submissionId, feeWaiverId, fileName, true);
    }

    @Test
    void shouldOnlyDeleteFeeWaiverFromSubmission() throws JsonProcessingException {
        String fileName = "empty.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);

        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Passport", "form-i-94-passport", fileName);
        var evidenceId = this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());

        String feeWaiverId = this.uploadFeeWaiver(MYUSCIS_ID, submissionId,
                attachedFeeWaiver(fileName, MYUSCIS_ID, submissionId));
        this.deleteFeeWaiver(MYUSCIS_ID, submissionId, feeWaiverId, fileName, true);

        String s3Key = String.format("%s/%s/%s", submissionId, MYUSCIS_ID, fileName);
        assertTrue(fileExists(EVIDENCE_BUCKET, s3Key, evidenceId.get(0)));
    }

    @Test
    void updateSubmission_shouldRejectPublished() {
        // Given a published submission
        Submission sub = SubmissionFactory.forSubmissionId(UUID.randomUUID().toString(), UUID.randomUUID().toString(),
                FormType.I765);
        sub.setStatus(PUBLISHED);
        submissionDAO.save(sub);

        // When I try to update the submission
        client.put()
                .uri("/api/v1/{myUscisId}/submissions/{id}/category", sub.getMyUscisId(), sub.getSubmissionId())
                .contentType(APPLICATION_JSON)
                .bodyValue(new EligibilityUpdateRequest(I765EligibilityCategory.A12, null, 63, 39, FormType.I765.getType()))
                .exchange()
                // Then the request should be rejected
                .expectStatus().isNotFound();
    }

    @Test
    void shouldReturnNotFoundWhenUploadingAFormForAPublishedSubmission() {
        // Given a published submission
        Submission sub = SubmissionFactory.forSubmissionId(UUID.randomUUID().toString(), UUID.randomUUID().toString(),
                FormType.I765);
        sub.setStatus(PUBLISHED);
        submissionDAO.save(sub);

        var form = attachedForm("i-756-with-signature.pdf", sub.getMyUscisId(), sub.getSubmissionId(),
                FormType.I765.getType());

        // When I try to upload a form
        client.post()
                .uri("/api/v1/{myUscisId}/submissions/{id}/form", sub.getMyUscisId(), sub.getSubmissionId())
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(form))
                .exchange()
                // Then the request should be rejected
                .expectStatus().isNotFound();
    }

    @Test
    void shouldSetZeroForInitialSubmission() {
        SubmissionRequest request = SubmissionRequest.builder()
                .accountType(AccountType.APPLICANT)
                .formType(FormType.I765)
                .eligibilityCategory(C11PAROLE.getCategory())
                .build();
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        SubmissionDto submission = getSubmissionById(MYUSCIS_ID, submissionId);

        assertTrue(BigDecimal.ZERO.compareTo(submission.feeTotal()) == 0);
    }





    @Test
    void shouldReturnOkWhenUploadingAValidPhoto() throws InterruptedException, IOException {
        String fileName = "2x2Photo.jpg";
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, aNewSubmission(MYUSCIS_ID));
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        this.withSuccessfulElisValidation(fileName);
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Applicant Photo", "applicant-photo", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().is2xxSuccessful());
    }

    @Test
    void shouldReturnBadRequestWhenUploadingIncorrectFileTypeForACategory() {
        String fileName = "empty.pdf";
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, aNewSubmission(MYUSCIS_ID));
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        MultiValueMap<String, HttpEntity<?>> evidenceRequest = attachedEvidence(MYUSCIS_ID,
                submissionId, "Applicant Photo", "applicant-photo", fileName);
        this.uploadEvidence(MYUSCIS_ID, submissionId, FormType.I765.getType(), evidenceRequest,
                (response) -> response.expectStatus().isBadRequest());
    }

    @Test
    void shouldDeletePreviousFormOfSameTypeWhenUploadingANewOne() {
        String fileName = "i-756-with-signature.pdf";
        SubmissionRequest request = aNewSubmission(MYUSCIS_ID);
        String submissionId = this.createInitialSubmission(MYUSCIS_ID, request);
        this.updateEligibility(MYUSCIS_ID, submissionId, C8);
        var originalFormId = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        fileName = "i-756.pdf";
        var id = this.uploadForm(MYUSCIS_ID, submissionId, fileName,
                attachedForm(fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
        String s3Key = String.format("%s/%s/%s", submissionId, MYUSCIS_ID, "i-756-with-signature.pdf");
        assertFalse(fileExists(FORM_BUCKET, s3Key, originalFormId));
    }

  @Test
  void shouldAllowMultipleFormsOfDifferentTypes() {

    SubmissionRequest newSubmissionRequest = aNewSubmission(MYUSCIS_ID);
    String submissionId = this.createInitialSubmission(MYUSCIS_ID, newSubmissionRequest);
    this.updateEligibility(MYUSCIS_ID, submissionId, C8);

    String I765fileName = "i-756.pdf";
    var I765formId = this.uploadForm(MYUSCIS_ID, submissionId, I765fileName,
    attachedForm(I765fileName, MYUSCIS_ID, submissionId, FormType.I765.getType()));
    String I765s3Key = String.format("%s/%s/%s", submissionId, MYUSCIS_ID, I765fileName);
    assertTrue(fileExists(FORM_BUCKET, I765s3Key, I765formId));

    SubmissionRequest g28SubmissionRequest = SubmissionRequest.builder()
            .accountType(AccountType.APPLICANT)
            .formType(FormType.G28)
            .build();
    String g28submissionId = this.createInitialSubmission(MYUSCIS_ID, g28SubmissionRequest);
    this.updateEligibilityAndFormType(MYUSCIS_ID, g28submissionId, C8, FormType.G28.getType());
    String G28fileName = "g-28.pdf";
    var G28formId = this.uploadForm(MYUSCIS_ID, g28submissionId, G28fileName,
            attachedForm(G28fileName, MYUSCIS_ID, g28submissionId, FormType.G28.getType()));
    String G28s3Key = String.format("%s/%s/%s", g28submissionId, MYUSCIS_ID, G28fileName);
    assertTrue(fileExists(FORM_BUCKET, G28s3Key, G28formId));
    }

}