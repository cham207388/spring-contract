package gov.dhs.uscis.submissionservice.components;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.ValidationRequest;
import jakarta.jms.JMSException;
import jakarta.jms.TextMessage;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;

@ExtendWith(MockitoExtension.class)
class MockElisValidationListenerTest {

    @Mock
    SqsClient mockSqsClient;

    @InjectMocks
    MockElisValidationListener listener;

    @Test
    void shouldSendAMockMessage() throws JMSException, JsonProcessingException {
        TextMessage mockMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationRequest message = ValidationRequest.builder()
                .formId(formId)
                .submissionId(submissionId)
                .formType(FormType.I130.getType())
                .build();

        when(mockMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(message));

        listener.onMessage(mockMessage);

        ArgumentCaptor<SendMessageRequest> sendResponseJail = ArgumentCaptor.forClass(SendMessageRequest.class);
        
        verify(mockSqsClient).sendMessage(sendResponseJail.capture());
        
        assertTrue(sendResponseJail.getValue().messageBody().contains(submissionId));
        assertTrue(sendResponseJail.getValue().messageBody().contains(formId));
    }

    @Test
    void shouldSendAMockMessageGot751() throws JMSException, JsonProcessingException {
        TextMessage mockMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationRequest message = ValidationRequest.builder()
                .formId(formId)
                .submissionId(submissionId)
                .formType(FormType.I751.getType())
                .build();

        when(mockMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(message));

        listener.onMessage(mockMessage);

        ArgumentCaptor<SendMessageRequest> sendResponseJail = ArgumentCaptor.forClass(SendMessageRequest.class);
        
        verify(mockSqsClient).sendMessage(sendResponseJail.capture());
        
        assertTrue(sendResponseJail.getValue().messageBody().contains(submissionId));
        assertTrue(sendResponseJail.getValue().messageBody().contains(formId));
    }

    @Test
    void shouldSendAMockMessageGotG28() throws JMSException, JsonProcessingException {
        TextMessage mockMessage = mock(TextMessage.class);

        String submissionId = UUID.randomUUID().toString();
        String formId = UUID.randomUUID().toString();

        ValidationRequest message = ValidationRequest.builder()
                .formId(formId)
                .submissionId(submissionId)
                .formType(FormType.G28.getType())
                .build();

        when(mockMessage.getText()).thenReturn(new ObjectMapper().writeValueAsString(message));

        listener.onMessage(mockMessage);

        ArgumentCaptor<SendMessageRequest> sendResponseJail = ArgumentCaptor.forClass(SendMessageRequest.class);
        
        verify(mockSqsClient).sendMessage(sendResponseJail.capture());
        
        assertTrue(sendResponseJail.getValue().messageBody().contains(submissionId));
        assertTrue(sendResponseJail.getValue().messageBody().contains(formId));
    }
}