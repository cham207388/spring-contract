package gov.dhs.uscis.submissionservice.configs;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class CommonsConfigTest {
    @Test
    void shouldGenerateUUIDNameWithExtensionAppended() {
        var config = new CommonsConfig();
        var name = config.s3KeyFileNameGenerator().generateName(".pdf");

        String[] tokens = name.split("\\.");
        assertEquals("pdf", tokens[1]);
        assertEquals(9, tokens[0].length());
    }
}
