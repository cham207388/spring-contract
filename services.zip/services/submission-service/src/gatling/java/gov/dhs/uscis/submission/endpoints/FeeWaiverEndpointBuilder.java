package gov.dhs.uscis.submission.endpoints;

import gov.dhs.uscis.AbstractSimulationSetup;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.http.HttpDsl;

import static io.gatling.javaapi.http.HttpDsl.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import static io.gatling.javaapi.core.CoreDsl.*;

import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FeeWaiverEndpointBuilder extends AbstractSimulationSetup {

        private static Logger logger = LoggerFactory.getLogger(FeeWaiverEndpointBuilder.class);
        private static ObjectMapper mapper = new ObjectMapper();

        public static ChainBuilder deleteFeeWaiverById = exec(
                        http("Delete Fee Waiver by ID")
                                        .delete("/#{submissionID}/feeWaiver/#{formId}"));

        public static ChainBuilder UPLOAD_FEE_WAIVER_FOR_SUBMISSION_ID = exec(session -> {
                UploadFeeWaiverRequest feeRequest = new UploadFeeWaiverRequest("feewaiver.pdf");
                String jsonString = null;
                try {
                        jsonString = mapper.writeValueAsString(feeRequest);
                } catch (JsonProcessingException exception) {
                        logger.info("Issues Processing JSON {}", exception.getMessage());
                }
                if (session.isFailed()) {
                        logger.info("FeeWaiver BODY: {}", jsonString);
                }
                return session.set("feeWaiverRequest", jsonString);
        })
                        .exec(
                                        http("Upload Fee Waiver For Submission with ID")
                                                        .post("/#{submissionID}/feeWaiver")
                                                        .header("Content-Type", "multipart/form-data")
                                                        .bodyPart(HttpDsl
                                                                        .RawFileBodyPart("file",
                                                                                        Paths.get("i765-C11.pdf")
                                                                                                        .toString())
                                                                        .contentType("application/pdf"))
                                                        .bodyPart(HttpDsl
                                                                        .StringBodyPart("uploadFeeWaiverRequest",
                                                                                        "#{feeWaiverRequest}")
                                                                        .contentType("application/json"))
                                                        .asJson()
                                                        .check(bodyString().saveAs("feeWaiverResponseBody")))
                        .exec(session -> {
                                if (session.isFailed()) {
                                        logger.info("Fee Waiver Response: "
                                                        + session.getString("feeWaiverResponseBody"));
                                }
                                return session;
                        });
}
