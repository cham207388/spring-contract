package gov.dhs.uscis.submission.endpoints;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;

import java.util.Optional;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.AbstractSimulationSetup;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.FormTypeDescription;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;
import io.gatling.javaapi.core.ChainBuilder;

public class SubmissionEndpointBuilder extends AbstractSimulationSetup {

        private static Logger logger = LoggerFactory.getLogger(SubmissionEndpointBuilder.class);
        private static ObjectMapper mapper = new ObjectMapper();

        public static ChainBuilder CREATE_SUBMISSION_REFACTORED = exec(
                        http("Create Submission")
                                        .post("/").header("Content-Type", "application/json")
                                        .body(ElFileBody("jsonTemplates/createSubmission.json"))
                                        .check(status().is(200))
                                        // .check(bodyString().saveAs("submissionID")))
                                        .check(jsonPath("$.submissionId").saveAs("submissionID")))
                        .exec(session -> {
                                logger.info("submissionID: {}", session.getString("submissionID"));
                                if (session.isFailed()) {
                                        logger.info(
                                                        "Failed Create Request: {}", session.getString("submissionID"));
                                }
                                return session;
                        });

        public static ChainBuilder CREATE_SUBMISSION = exec(session -> {
                SubmissionRequest request = generateRandomSubmissionRequest();
                String createRequestJsonString = null;
                try {
                        createRequestJsonString = mapper.writeValueAsString(request);
                } catch (JsonProcessingException ex) {
                        logger.error("Issues Processing JSON {}", ex.getMessage());
                }
                logger.info("Request Body: {}", createRequestJsonString);
                return session.set("createRequestBody", createRequestJsonString);
        }).exec(
                        http("Create Submission")
                                        .post("/").header("Content-Type", "application/json")
                                        .body(StringBody("#{createRequestBody}")).asJson()
                                        .check(status().is(200))
                                        .check(jsonPath("$.submissionId").saveAs("submissionID")))
                        .exec(session -> {
                                logger.info("submissionID: {}", session.getString("submissionID"));
                                if (session.isFailed()) {
                                        logger.error(
                                                        "Failed Create Request: {}", session.getString("submissionID"));
                                }
                                return session;
                        });

        public static ChainBuilder FETCH_SUBMISSION_BY_ID = exec(session -> {
                logger.info("Fetch Submission: {}", session.getString("submissionID"));
                return session;
        }).exec(
                        http("Fetch Submission By ID")
                                        .get("/#{submissionID}")
                                        .check(status().is(200))
                                        .check(bodyString().saveAs("submissionFetchedFromApi")));

        public static ChainBuilder DELETE_SUBMISSION_BY_ID = exec(
                        http("Delete Submission by ID")
                                        .delete("/#{submissionID}"));

        public static ChainBuilder UPLOAD_FORM_FOR_SUBMISSION_ID = exec(session -> {
                UploadRequest uploadRequest = new UploadRequest("random-test.pdf", true, session.getString("myUSCISID"),
                                "Document", "1765");
                String jsonString = null;
                try {
                        jsonString = mapper.writeValueAsString(uploadRequest);
                } catch (JsonProcessingException exception) {
                        logger.error("Issues Processing JSON: {}", exception.getMessage());
                }
                return session.set("uploadRequest", jsonString).set("formFileName", uploadRequest.fileName());
        }).exec(postWithMultipart("/#{submissionID}/form",
                        "Upload Document For Submission", "i765-C11.pdf", "file", "uploadRequest")
                        .check(jmesPath("formId").saveAs("formId")).check(bodyString().saveAs("formResponseBody")))
                        .exec(session -> {
                                if (session.isFailed()) {
                                        logger.error("Failed Document Upload: {}",
                                                        session.getString("formResponseBody"));
                                }
                                return session;
                        });

        public static ChainBuilder FETCH_DRAFT_FOR_MYUSCIS_ID = exec(
                        http("Fetch Draft For MYUSCIS ID")
                                        .get("/drafts")
                                        .check(status().is(200)));

        public static ChainBuilder FETCH_SUBMISSIONS_FOR_MYUSCIS_ID = exec(
                        http("Fetch Submissions for MYUSCIS ID")
                                        .get("?filters=RECEIVED,ACCEPTED,REJECTED")
                                        .check(status().in(200, 404 /* no data */)));

        public static ChainBuilder FETCH_STATUS_FOR_SUBMISSION = exec(
                        http("Fetch Status For Submission with ID")
                                        .get("/#{submissionID}/status")
                                        .check(status().is(200)));

        public static ChainBuilder FETCH_FORM_BY_SUBMISSION_ID_AND_FORM_ID = exec(
                        http("Fetch Form By Submission ID and name")
                                        .get("/#{submissionID}/form/#{formId}")
                                        .check(status().is(200)));

        public static SubmissionRequest generateRandomSubmissionRequest() {
                Random random = new Random();
                String[] myUSCISIDs = { "MYUSCIS100", "MYUSCIS101", "MYUSCIS102", "MYUSCIS103", "MYUSCIS104",
                                "MYUSCIS105",
                                "MYUSCIS106" };
                I765EligibilityCategory[] eligibilityCategories = { I765EligibilityCategory.A12,
                                I765EligibilityCategory.C11AFGHAN, I765EligibilityCategory.C11PAROLE,
                                I765EligibilityCategory.C11UKRAINE,
                                // I765EligibilityCategory.C19,
                                I765EligibilityCategory.C8,
                                I765EligibilityCategory.C9 };
                String[] emails = { "test@test.com", "test10@test.com", "test20@test.com", "test30@test.com",
                                "test30@test.com",
                                "test40@test.com", "test50@test.com" };

                SubmissionRequest request = new SubmissionRequest(
                                FormType.I765,
                                FormTypeDescription.I765.getDescription(),
                                eligibilityCategories[random.nextInt(eligibilityCategories.length)].getCategory(), AccountType.REPRESENTATIVE, null);
                return request;
        }
}
