package gov.dhs.uscis.submission;

import static gov.dhs.uscis.submission.endpoints.SubmissionEndpointBuilder.CREATE_SUBMISSION;
import static gov.dhs.uscis.submission.endpoints.SubmissionEndpointBuilder.FETCH_DRAFT_FOR_MYUSCIS_ID;
import static gov.dhs.uscis.submission.endpoints.SubmissionEndpointBuilder.FETCH_SUBMISSIONS_FOR_MYUSCIS_ID;
import static gov.dhs.uscis.submission.endpoints.SubmissionEndpointBuilder.UPLOAD_FORM_FOR_SUBMISSION_ID;
import static io.gatling.javaapi.core.CoreDsl.constantUsersPerSec;
import static io.gatling.javaapi.core.CoreDsl.exec;
import static io.gatling.javaapi.core.CoreDsl.scenario;

import java.time.Duration;

import gov.dhs.uscis.AbstractSimulationSetup;
import io.gatling.javaapi.core.ScenarioBuilder;

public class FetchSubmissionsForUser extends AbstractSimulationSetup {
    
    private int NUMBER_OF_USERS = Integer.parseInt(System.getProperty("numberOfUsers", "10"));
    private int RAMP_TIME = Integer.parseInt(System.getProperty("rampTime", "5"));
    private int SESSION_DURATION = Integer.parseInt(System.getProperty("sessionDuration", "60"));

    private ScenarioBuilder fromBrowser = scenario("User Browser")
        .exec(CREATE_SUBMISSION)
        .exec(UPLOAD_FORM_FOR_SUBMISSION_ID)
        .during(Duration.ofSeconds(SESSION_DURATION)).on(
            exec(FETCH_DRAFT_FOR_MYUSCIS_ID)
        );

    private ScenarioBuilder fromApi = scenario("MyUSCIS Services")
        .during(Duration.ofSeconds(SESSION_DURATION)).on(
            exec(FETCH_SUBMISSIONS_FOR_MYUSCIS_ID));

    {
        var ramp = constantUsersPerSec(NUMBER_OF_USERS).during(RAMP_TIME);
        setUp(
            fromBrowser.injectOpen(ramp).protocols(viaEdgeProxy),
            fromApi.injectOpen(ramp).protocols(directSubmissionSvc)
        );
    }
}
