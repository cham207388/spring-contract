package gov.dhs.uscis.submission;

import static io.gatling.javaapi.core.CoreDsl.nothingFor;
import static io.gatling.javaapi.core.CoreDsl.rampUsersPerSec;
import static io.gatling.javaapi.core.CoreDsl.scenario;
import static io.gatling.javaapi.core.CoreDsl.stressPeakUsers;

import gov.dhs.uscis.AbstractSimulationSetup;
import gov.dhs.uscis.submission.endpoints.FeeWaiverEndpointBuilder;
import gov.dhs.uscis.submission.endpoints.SubmissionEndpointBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;

public class SubmissionControllerTest extends AbstractSimulationSetup {
        private int REPEAT_COUNT = Integer.parseInt(System.getProperty("repeatCount", "1"));
        private int NUMBER_OF_USERS = Integer.parseInt(System.getProperty("numberOfUsers", "40"));
        private int DURATION_TO_INJECT_USERS_IN_SECONDS = Integer.parseInt(System.getProperty("durationRate", "5"));
        private int PAUSE_TIME = Integer.parseInt(System.getProperty("pauseTime", "5"));
        private ScenarioBuilder scn = scenario("Load Test Submission Flow")
                        .exec(SubmissionEndpointBuilder.CREATE_SUBMISSION)
                        .exec(SubmissionEndpointBuilder.FETCH_SUBMISSION_BY_ID)
        .exec(SubmissionEndpointBuilder.FETCH_DRAFT_FOR_MYUSCIS_ID)
        .exec(SubmissionEndpointBuilder.FETCH_STATUS_FOR_SUBMISSION)
        .exec(SubmissionEndpointBuilder.UPLOAD_FORM_FOR_SUBMISSION_ID)
        .pause(PAUSE_TIME)
        .exec(FeeWaiverEndpointBuilder.UPLOAD_FEE_WAIVER_FOR_SUBMISSION_ID)
        .pause(PAUSE_TIME)
        // .exec(EvidenceEndpointBuilder.UPLOAD_EVIDENCE_FOR_SUBMISSION)
        // .pause(PAUSE_TIME)
        .exec(SubmissionEndpointBuilder.FETCH_FORM_BY_SUBMISSION_ID_AND_FORM_ID)
        .pause(PAUSE_TIME)
        // .exec(EvidenceEndpointBuilder.FETCH_EVIDENCE_BY_SUBMISSION_ID_AND_FILENAME)
        // .exec(EvidenceEndpointBuilder.deleteEvidenceBySubmissionAndEvidenceID)
        .exec(FeeWaiverEndpointBuilder.deleteFeeWaiverById)
        .exec(SubmissionEndpointBuilder.DELETE_SUBMISSION_BY_ID)
        ;
        {
                setUp(
                                scn.injectOpen(
                                                nothingFor(10),
                                                rampUsersPerSec(1).to(30).during(5),
                                                stressPeakUsers(NUMBER_OF_USERS)
                                                                .during(DURATION_TO_INJECT_USERS_IN_SECONDS)
                                                )
                                                .protocols(viaEdgeProxy));

        }
}
