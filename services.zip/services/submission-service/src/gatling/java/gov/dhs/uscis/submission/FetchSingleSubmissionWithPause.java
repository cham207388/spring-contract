package gov.dhs.uscis.submission;

import java.text.MessageFormat;
import java.time.Duration;

import static io.gatling.javaapi.core.CoreDsl.atOnceUsers;
import static io.gatling.javaapi.core.CoreDsl.scenario;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import static io.gatling.javaapi.http.HttpDsl.http;
import static io.gatling.javaapi.http.HttpDsl.status;
import io.gatling.javaapi.http.HttpProtocolBuilder;

public class FetchSingleSubmissionWithPause extends Simulation {
        private static final String SINGLE_SUBMISSION_ENDPOINT = "/api/v1/submissions/76c866f7-9afd-37bd-a0af-fcee404ec706";
        private HttpProtocolBuilder httpProtocol = http
                        .baseUrl("http://localhost:8081")
                        .acceptHeader("application/json");

        private ScenarioBuilder scn = scenario("Fetch Submissions By ID  With Pause")
                        .exec(
                                        http("Fetch Single Submisison")
                                                        .get(SINGLE_SUBMISSION_ENDPOINT)
                                                        .check(status().is(200))
                        )
                        .pause(5)
                        .exec(
                                        http("Fetch Single Submisison Status By ID")
                                                        .get(MessageFormat.format("{0}/{1}", SINGLE_SUBMISSION_ENDPOINT,
                                                                        "status"))
                                                        .check(status().in(200, 201, 202)))
                        .pause(1, 10)
                        .exec(
                                        http("2nd Call to Fetch Submission By ID")
                                                        .get(SINGLE_SUBMISSION_ENDPOINT)
                                                        .check(
                                                                        status().not(404),
                                                                        status().not(500)))
                        .pause(Duration.ofMillis(4000));

        // Load the simulation / execute it
        {
                setUp(scn.injectOpen(atOnceUsers(1))).protocols(httpProtocol);
        }

}
