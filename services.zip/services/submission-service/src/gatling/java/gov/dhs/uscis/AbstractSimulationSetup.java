package gov.dhs.uscis;

import static io.gatling.javaapi.core.CoreDsl.StringBody;
import static io.gatling.javaapi.http.HttpDsl.http;

import java.nio.file.Paths;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpDsl;
import io.gatling.javaapi.http.HttpProtocolBuilder;
import io.gatling.javaapi.http.HttpRequestActionBuilder;
public abstract class AbstractSimulationSetup extends Simulation {
    
    private static final String BASE_URL = System.getProperty("baseUrl", 
        "http://localhost:8383/pdf-intake/api/intake/anonymousUser/submissions");
    private static final String SUBMISSION_SERVICE_URL = System.getProperty("submissionServiceUrl", 
        "http://localhost:8081/api/v1/anonymousUser/submissions");
    private static final ObjectMapper mapper = new ObjectMapper();

    protected HttpProtocolBuilder viaEdgeProxy = HttpDsl.http
            .baseUrl(BASE_URL)
            .acceptHeader("application/json");

    protected HttpProtocolBuilder directSubmissionSvc = HttpDsl.http
        .baseUrl(SUBMISSION_SERVICE_URL)
        .acceptHeader("application/json");

    protected <T> HttpRequestActionBuilder postWithJson(String endpoint, T payload, String testName) {
        try {
            return http(testName)
                    .post(endpoint)
                    .header("Content-Type", "application/json")
                    .body(StringBody(mapper.writeValueAsString(payload))).asJson()
                    .check(HttpDsl.status().is(200));
        } catch (JsonProcessingException ex) {
            return null;
        }
    }

    public static HttpRequestActionBuilder postWithMultipart(String endpoint, String testName,String filePath, String fileIdentifier, String requestIdentifier) {
            return http(testName)
                    .post(endpoint)
                    .header("Content-Type", "multipart/form-data")
                    .bodyPart(HttpDsl.RawFileBodyPart(fileIdentifier, Paths.get(filePath).toString()).contentType("application/pdf"))
                    .bodyPart(HttpDsl.StringBodyPart(requestIdentifier,"#{uploadRequest}").contentType("application/json")).asJson();
      
    }
}
