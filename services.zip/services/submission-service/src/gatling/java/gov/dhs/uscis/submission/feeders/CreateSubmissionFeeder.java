package gov.dhs.uscis.submission.feeders;

import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.function.Supplier;
import java.util.stream.Stream;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;

public class CreateSubmissionFeeder {
    private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final I765EligibilityCategory[] eligibilityCategorys = { I765EligibilityCategory.A12,
        I765EligibilityCategory.C11AFGHAN, I765EligibilityCategory.C11PAROLE,
        I765EligibilityCategory.C11UKRAINE, 
        // I765EligibilityCategory.C19,
        I765EligibilityCategory.C8,
        I765EligibilityCategory.C9 };

    private static String generateAlphaNumericString(int count) {
        StringBuilder builder = new StringBuilder();
        while (count-- != 0) {
            int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
        }
        return builder.toString();
    }

    private static int randomNumberGenerator() {
        return (int) (Math.random() * (1000 - 100 + 1)) + 100;
    }

    public static Iterator<Map<String, Object>> createSubmission() {
        Random random = new Random();
        Iterator<Map<String, Object>> iterator = Stream.generate((Supplier<Map<String, Object>>) () -> {
            int randomGeneratedNumber = randomNumberGenerator();
            String myUscisID = "MYUSCIS" + randomGeneratedNumber;
            FormType formType = FormType.I765;
            I765EligibilityCategory category = eligibilityCategorys[random.nextInt(eligibilityCategorys.length)];
            String email = new StringBuilder("test").append("randomGeneratedNumber").append("@gmail.com").toString();
            String accountType = generateAlphaNumericString(3) + "-Account";

            return Map.of(
                "myUscisId", myUscisID,
                "formType",formType.getType(),
                "eligibilityCategory",category.getCategory(),
                "email",email,
                "accountType",accountType
            );
        }).iterator();
        return iterator;
    }
}
