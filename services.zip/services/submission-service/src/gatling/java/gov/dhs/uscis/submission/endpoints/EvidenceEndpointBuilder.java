package gov.dhs.uscis.submission.endpoints;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;

import java.nio.file.Paths;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.AbstractSimulationSetup;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import io.gatling.javaapi.core.ChainBuilder;

public class EvidenceEndpointBuilder extends AbstractSimulationSetup {

        private static Logger logger = LoggerFactory.getLogger(EvidenceEndpointBuilder.class);

        private static ObjectMapper mapper = new ObjectMapper();

        public static ChainBuilder deleteEvidenceBySubmissionAndEvidenceID = exec(
                        http("Delete Evidence By Submission ID and Evidence ID")
                                        .delete("/#{submissionID}/evidence/#{evidenceID}")
                                        .check(bodyString().saveAs("deleteEvidenceBody")))
                        .exec(session -> {
                                if (session.isFailed()) {
                                        logger.error("DELETE EVIDENCE Response: {}",
                                                        session.getString("deleteEvidenceBody"));
                                }
                                return session;
                        });

        public static ChainBuilder FETCH_EVIDENCE_BY_SUBMISSION_ID_AND_FILENAME = exec(
                        http("Fetch Evidence For Submission with fileName")
                                        .get("/#{submissionID}/evidences/#{evidenceID}/#{evidenceFileName}")
                                        .check(status().is(200)));

        public static ChainBuilder UPLOAD_EVIDENCE_FOR_SUBMISSION = exec(session -> {
                String submissionFetchedFromApiAsString = session.getString("submissionFetchedFromApi");

                UploadEvidenceRequest evidenceRequest = new UploadEvidenceRequest(
                                "i765-C11.pdf", "TBD_Evidence_Type", "Evidence_Group_Type");
                String jsonString = null;
                try {
                        Submission submission = mapper.readValue(submissionFetchedFromApiAsString, Submission.class);
                        EvidenceRequest request = new EvidenceRequest(List.of(evidenceRequest), null, submission);
                        jsonString = mapper.writeValueAsString(request);
                } catch (JsonProcessingException exception) {
                        logger.error("Issues Processing JSON {}", exception.getMessage());
                }
                return session
                                .set("evidenceRequest", jsonString)
                                .set("evidenceFileName", evidenceRequest.fileName());
        })
                        .exec(
                                        http("Upload Evidence For Submission")
                                                        .post("/#{submissionID}/evidence")
                                                        .header("Content-Type", "multipart/form-data")
                                                        .body(StringBody("#{createRequestBody}")).asJson()
                                                        .asMultipartForm()
                                                        .formUpload("i765-C11.pdf",
                                                                        Paths.get("i765-C11.pdf").toString())
                                                        // .bodyPart(HttpDsl
                                                        // .RawFileBodyPart("file",
                                                        // Paths.get("i765-C11.pdf")
                                                        // .toString())
                                                        // .contentType("application/pdf"))
                                                        // .bodyPart(HttpDsl
                                                        // .StringBodyPart("uploadEvidenceRequest",
                                                        // "#{evidenceRequest}")
                                                        // .contentType("application/json"))
                                                        .check(jmesPath("id").saveAs("evidenceID"))
                                                        .check(bodyString().saveAs("evidenceBody")))
                        .exec(session -> {
                                if (session.isFailed()) {
                                        logger.error("Evidence Response: {}", session.getString("evidenceBody"));
                                }
                                return session;
                        });

}
