package gov.dhs.uscis.submissionservice.models.myUscis;

public record Error(String developerMessage, String userMessage, String failureCode) {}
