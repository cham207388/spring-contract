package gov.dhs.uscis.submissionservice.models.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class C9FeeUpdateRequest {
    private boolean isFeeWaiverEligible;
    private C9FeeOptions options;
}
