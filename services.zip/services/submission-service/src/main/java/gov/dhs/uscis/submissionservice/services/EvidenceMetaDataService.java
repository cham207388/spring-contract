package gov.dhs.uscis.submissionservice.services;

import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.models.EvidenceMetaData;
import gov.dhs.uscis.intake.models.dto.EvidenceData;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;

@Service
public class EvidenceMetaDataService {

    private DynamoDbTable<EvidenceMetaData> evidenceMetaDataTable;

    public EvidenceMetaDataService(DynamoDbTable<EvidenceMetaData> evidenceMetaDataTable) {
        this.evidenceMetaDataTable = evidenceMetaDataTable;
    }

    public EvidenceData getEvidenceMetaData(String evidenceId) {
        Key key = Key.builder().partitionValue(evidenceId).build();
        GetItemEnhancedRequest request = GetItemEnhancedRequest.builder().key(key).build();
        EvidenceMetaData item = evidenceMetaDataTable.getItem(request);

        return EvidenceData.builder()
                .evidencePages(item.getEvidencePages())
                .build();
    }
}
