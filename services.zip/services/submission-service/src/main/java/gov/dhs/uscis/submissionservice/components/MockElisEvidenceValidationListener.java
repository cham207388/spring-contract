package gov.dhs.uscis.submissionservice.components;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ELISValidationResponse;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;
@Component
@Profile("mock_elis")
public class MockElisEvidenceValidationListener implements MessageListener{

	private final SqsClient sqsClient;
	private final FormService formService;
	private final SubmissionService submissionService;

    @Value("${uscis.sqs.evidence.validation.elisResponse.queueUrl}")
	private String elisResponseQueueName;

    @Value("${uscis.sqs.validation.elisResponse.defaultFeeTotal:999}")
	private int elisResponseDefaultFeeTotal;
	ObjectMapper mapper = new ObjectMapper();
	private static final Logger logger = LoggerFactory.getLogger(MockElisEvidenceValidationListener.class);
	private static final int i751Fee = 700;
    private static final int i140Fee = 665;

	@Autowired
	public MockElisEvidenceValidationListener(SqsClient sqsClient, FormService formService, SubmissionService submissionService) {
		this.sqsClient = sqsClient;
		this.formService = formService;
		this.submissionService = submissionService;
	}

	@Override
	public void onMessage(Message message) {
		TextMessage textMessage = (TextMessage) message;
		try {
            ELISValidationResponse request = mapper.readValue(textMessage.getText(), ELISValidationResponse.class);

            logger.info("MOCK ELIS EVIDENCE, recieved Message: " + request.toString());

			ValidationStatus mockUpdatedStatus = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
					.isMultipart(false)
					.validator(ValidatorEnum.PFVS)
					.build();

			ValidationStatus mockCoreStatus = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
					.isMultipart(false)
					.validator(ValidatorEnum.CORE)
					.build();

			List<ValidationStatus> statusResponses = new ArrayList<>();
			statusResponses.addAll(Arrays.asList(mockUpdatedStatus, mockCoreStatus));
/*
			Submission submission = submissionService.retrieveById(request.submissionId());
			  EvidenceGroup evidenceGroup = formService.retrieveEvidenceGroup(submission.getFormType().getType(),
            submission.getEligibilityCategory().getCategory(),
            request.evidenceGroupType());
			*/	
			//TODO make this analyze the evidence prior to
            int feeTotal = elisResponseDefaultFeeTotal;

			ELISValidationResponse elisValidationResponse = ELISValidationResponse.builder()
					.results(statusResponses)
					.formId(request.formId())
					.formType("ETA9089 FD")
                    .fee(BigDecimal.valueOf(i140Fee))
                    .totalFee(BigDecimal.valueOf(i140Fee))
					.pass(true)
					.submissionId(request.submissionId())
					.build();

					

			SendMessageRequest sendMsgRequest = SendMessageRequest.builder()
					.queueUrl(elisResponseQueueName)
					.messageBody(mapper.writeValueAsString(elisValidationResponse))
					.build();

			logger.info("Sending mock evidence validation response message to queue: {}\n{}", elisResponseQueueName, message);
			SendMessageResponse response = sqsClient.sendMessage(sendMsgRequest);
			logger.info(response.toString());
			textMessage.acknowledge();
		} catch (Exception e) {
			logger.error("Error with ELIS validaiton mock listener {}", e);
		}
	}

}