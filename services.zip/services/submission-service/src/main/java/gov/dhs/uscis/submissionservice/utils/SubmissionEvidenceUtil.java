package gov.dhs.uscis.submissionservice.utils;

import gov.dhs.uscis.intake.services.formats.MagicBytes;

public class SubmissionEvidenceUtil {

    private SubmissionEvidenceUtil() {
    }

    private static String getFileExtension(String filename) {
        int dotIndex = filename.lastIndexOf(".");
        if (dotIndex >= 0) {
            return filename.substring(dotIndex);
        }
        return "";
    }

    public static boolean isFileExtension(String filePath, MagicBytes fileExtensionMatch) {
        if(filePath == null || fileExtensionMatch == null)
        {
            return false;
        }
        String fileExtension = getFileExtension(filePath);
        return fileExtensionMatch.getExtension().toLowerCase().equals(fileExtension.toLowerCase());
    }
}
