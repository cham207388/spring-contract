package gov.dhs.uscis.submissionservice.exception;

public class ChecksumException extends RuntimeException {
    public ChecksumException(String errorMessage) {
        super(errorMessage);
    }  
}
