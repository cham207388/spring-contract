package gov.dhs.uscis.submissionservice.validators;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Documented
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = EvidenceValidator.class)
public @interface ValidEvidence {

    String message() default "\"An evidence type is required, but one has not been specified\"";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
