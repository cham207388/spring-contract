package gov.dhs.uscis.submissionservice.validators.backend;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.MimeType;

import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.submissionservice.exception.BackendValidationException;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import gov.dhs.uscis.submissionservice.services.FormService;
import jakarta.servlet.http.Part;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import static java.util.Optional.ofNullable;

import java.util.ArrayList;

import static gov.dhs.uscis.submissionservice.services.SubmissionService.FEE_WAIVER_EVIDENCE_GROUP;

@Slf4j
@Component
@RequiredArgsConstructor
public class UploadEvidenceValidator {

    private final FormService formService;

    /*
     * 
     */
    public void validateEvidenceWithBackendData(EvidenceRequest evidenceRequest, String selectedFormType) {
        validateNoEvidenceContentTypeMismatch(evidenceRequest, selectedFormType);
        validateNotExceedsEvidences(evidenceRequest, selectedFormType);
    }


    /*
     * 
     */
    private void validateNotExceedsEvidences(EvidenceRequest evidenceRequest, String selectedFormType) {
        Submission submission = evidenceRequest.submission();
        if(selectedFormType == null || submission.getForms().stream().filter(form -> form.getType().equals(selectedFormType))
                .findFirst().get().getEligibilityCategory().getCategory() == null) {
            return;
        } 

        List<UploadEvidenceRequest> evidences = evidenceRequest.evidences();
        String evidenceGroupType = evidences.get(0).evidenceGroupType();
        List<SubmissionEvidence> existingEvidence = ofNullable(submission.getEvidences())
                        .orElse(Collections.emptyList())
                        .stream()
                        .filter((element) -> element.getEvidenceGroupType().equals(evidenceGroupType))
                        .toList();
        log.info("Submission has valid form type: {} and category: {} and group was specified when uploading: {}", 
                selectedFormType, submission.getEligibilityCategory(), evidenceGroupType);

        int maxNumberOfFiles = findMaxNumberOfEvidencesAllowed(evidenceGroupType, submission, selectedFormType);
        if(maxNumberOfFiles != 5 && evidencesExceedLimit(existingEvidence, evidences, maxNumberOfFiles))
        {
            throw new BackendValidationException(String.format("evidence group '%s' cannot exceed %d file(s)", evidenceGroupType, maxNumberOfFiles));
        }

    }

    private int findMaxNumberOfEvidencesAllowed(String evidenceGroupType, Submission submission, String selectedFormType) {
        if(FEE_WAIVER_EVIDENCE_GROUP.equals(evidenceGroupType)) return 5;

        EvidenceGroup result = this.formService.retrieveEvidenceGroup(selectedFormType, 
                    submission.getForms().stream().filter(form -> form.getType().equals(selectedFormType))
                    .findFirst().get().getEligibilityCategory().getCategory(), 
                    evidenceGroupType);
        
        return result.getMaxNumberOfFiles();
    }

    private boolean evidencesExceedLimit(List<SubmissionEvidence> existingEvidences, List<UploadEvidenceRequest> newEvidences, int limitPerGroup) {
        if(existingEvidences == null)
        {
            return newEvidences.size() > limitPerGroup;
        } 
        return ( existingEvidences.size() + newEvidences.size() ) > limitPerGroup;
    }

    /*
     * 
     */
    private void validateNoEvidenceContentTypeMismatch(EvidenceRequest evidenceRequest, String selectedFormType) {
        Submission submission = evidenceRequest.submission();
        if(selectedFormType == null || submission.getEligibilityCategory() == null) {
            return;
        }

        //ignore feeWaiver validation for now.
        String groupType = evidenceRequest.evidences().get(0).evidenceGroupType();
        if(FEE_WAIVER_EVIDENCE_GROUP.equals(groupType)) {
            return;
        } 

        String eligibilityCategory = submission.getEligibilityCategory().getCategory();
        
        List<MimeType> validMimeTypes = this.formService.retrieveEvidenceGroup(selectedFormType, 
                                        submission.getForms().stream().filter(form -> form.getType().equals(selectedFormType))
                                        .findFirst().get().getEligibilityCategory().getCategory(), 
                                        groupType).getAllowMediaTypes();
        List<Part> files = evidenceRequest.files();

        List<String> invalidMimeTypes = getInvalidFileMimeTypes(files, validMimeTypes);
        if(!invalidMimeTypes.isEmpty()) {
            String invalidTypesMessage = String.join(",", invalidMimeTypes );
            throw new BackendValidationException(String.format("invalid Mime Types for (%s,%s): %s", selectedFormType, eligibilityCategory, invalidTypesMessage));
        }
    }

    private List<String> getInvalidFileMimeTypes(List<Part> files, List<MimeType> validMimeTypes){
        List<MimeType> uploadedMimeTypes = files.stream().map(f -> MimeType.valueOf(f.getContentType())).toList();
        List<String> invalidMimeTypes = new ArrayList<String>();
        for(MimeType uploadedMimeType : uploadedMimeTypes) {
            if(!validMimeTypes.contains(uploadedMimeType)) {
                invalidMimeTypes.add(uploadedMimeType.toString());
            }
        }
        return invalidMimeTypes;
    }
}
