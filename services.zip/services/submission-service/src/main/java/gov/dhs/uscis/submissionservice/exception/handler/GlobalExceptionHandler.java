package gov.dhs.uscis.submissionservice.exception.handler;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import software.amazon.awssdk.services.cloudwatch.model.InvalidFormatException;

import gov.dhs.uscis.submissionservice.exception.AddClientValidationException;
import gov.dhs.uscis.submissionservice.exception.BackendValidationException;
import gov.dhs.uscis.submissionservice.exception.FeeHandlerNotFoundException;
import gov.dhs.uscis.submissionservice.exception.FormProtectedException;
import gov.dhs.uscis.submissionservice.exception.NoFormInSubmissionException;
import gov.dhs.uscis.submissionservice.exception.S3DeleteObjectException;
import gov.dhs.uscis.submissionservice.exception.S3PutObjectException;
import gov.dhs.uscis.submissionservice.exception.SubmissionBadException;
import gov.dhs.uscis.submissionservice.exception.SubmissionDeleteException;
import gov.dhs.uscis.submissionservice.exception.SubmissionIndexException;
import gov.dhs.uscis.submissionservice.exception.SubmissionUpdateException;
import gov.dhs.uscis.submissionservice.exception.ValidationStatusDeletionException;
import jakarta.validation.ConstraintViolationException;
import software.amazon.awssdk.services.s3.model.NoSuchBucketException;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(BackendValidationException.class)
    protected ResponseEntity<Object> handleBackendValidationException(BackendValidationException exception) {
        logger.error(exception.getMessage(), exception);
        Map<String, String> errors = new HashMap<>();
        errors.put("error", exception.getMessage());
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    protected ResponseEntity<Object> handleConstraintViolationException(ConstraintViolationException ex) {
        logger.error(ex.getMessage(), ex);
        Map<String, String> errors = new HashMap<>();

        ex.getConstraintViolations().forEach(violation -> {
            String fieldName = violation.getPropertyPath().toString();
            String errorMessage = violation.getMessage();
            errors.put(fieldName, errorMessage);
        });
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NoSuchBucketException.class)
    protected ResponseEntity<Object> handleNoSuchBucketException(NoSuchBucketException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>("Bucket not found", HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(FormProtectedException.class)
    protected ResponseEntity<Object> handleFormProtectedException(FormProtectedException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>(
                "Your uploaded form cannot be password protected. Upload a document without a password.",
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NoSuchKeyException.class)
    protected ResponseEntity<Object> handleNoSuchKeyException(NoSuchKeyException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>("Object not found", HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(NoFormInSubmissionException.class)
    protected ResponseEntity<Object> handleNoFormInSubmissionException(NoFormInSubmissionException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>("No forms in this submission", HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(S3DeleteObjectException.class)
    protected ResponseEntity<Object> handleS3DeleteObjectException(S3DeleteObjectException ex) {
        logger.error("S3 Service threw an exception: " + ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(S3PutObjectException.class)
    protected ResponseEntity<Object> handleS3PutObjectException(S3PutObjectException ex) {
        logger.error("S3 Put Object Service threw an exception: " + ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(NoSuchElementException.class)
    protected ResponseEntity<Object> handleNoSuchElementException(NoSuchElementException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(SubmissionUpdateException.class)
    protected ResponseEntity<Object> handleSubmissionUpdateException(SubmissionUpdateException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(SubmissionBadException.class)
    protected ResponseEntity<Object> handleSubmissionBadException(SubmissionBadException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(FeeHandlerNotFoundException.class)
    protected ResponseEntity<Object> handleFeeHandlerNotFound(FeeHandlerNotFoundException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(SubmissionIndexException.class)
    protected ResponseEntity<Object> handleSubmissionIndexException(SubmissionIndexException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(SubmissionDeleteException.class)
    protected ResponseEntity<Object> handleSubmissionDeleteException(SubmissionDeleteException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ValidationStatusDeletionException.class)
    protected ResponseEntity<Object> handleValidationStatusDeletionException(ValidationStatusDeletionException ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(InvalidFormatException.class)
    protected ResponseEntity<Object> handleInvalidFormatException(InvalidFormatException ex) {
        logger.warn(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    }

    protected ResponseEntity<Object> handleAddClientValidationException(AddClientValidationException ex) {
        logger.error(ex.getMessage(), ex);

        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    protected ResponseEntity<Object> handleAllExceptions(Exception ex) {
        logger.error(ex.getMessage(), ex);
        return new ResponseEntity<>(ex.getMessage(),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
