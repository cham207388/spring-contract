package gov.dhs.uscis.submissionservice.services;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.submissionservice.models.myUscis.draftBenefits.ApplicantFileableFormsResponse;
import gov.dhs.uscis.submissionservice.utils.FormRulesUtil;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DraftBenefitsService {
    private WebClient webClient;
    @Value("${uscis.draftbenefits.enable}")
    private boolean draftBenefitsServiceEnabled;
    @Value("${uscis.draftbenefits.testMockResponse}")
    private boolean draftBenefitsTestMockResponse;
    static final String APPLICANT_FILEABLE_FORMS_URL = "/api/applicant-fileable-forms";

    public DraftBenefitsService(@Qualifier("draftBenefitsWebClient") WebClient draftBenefitsWebClient) {
        this.webClient = draftBenefitsWebClient;
    }

    public boolean canApplicantFileFor(String formType, String myUscisId) {
        log.info(String.format("Checking if applicant (...%s) can file for %s", myUscisId.substring(0, 8), formType));
        if (!FormRulesUtil.isOneFormPerApplicant(FormType.fromString(formType)) ) return true;
        if (!draftBenefitsServiceEnabled) return draftBenefitsTestMockResponse;
        try {
                var entity = webClient.get()
                        .uri(APPLICANT_FILEABLE_FORMS_URL)
                        .header("ICAM-UUID", myUscisId)
                        .retrieve()
                        .toEntity(ApplicantFileableFormsResponse.class)
                        .block();

                if (entity.getStatusCode().is2xxSuccessful()) {
                    var body = entity.getBody();
                    var data = body.getData();

                    return !data.getApplicantFileableForms().isEmpty() && data.getApplicantFileableForms().contains(formType);
                }
                return false;

            } catch (WebClientResponseException ex) {
                log.error("Error fetching applicant fileable forms. {}", ex.getMessage());
                return false;
            }
    }

}
