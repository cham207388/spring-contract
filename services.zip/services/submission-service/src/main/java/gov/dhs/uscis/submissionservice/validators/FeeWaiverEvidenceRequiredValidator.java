package gov.dhs.uscis.submissionservice.validators;

import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class FeeWaiverEvidenceRequiredValidator
        implements ConstraintValidator<FeeWaiverEvidenceRequired, FinalSubmissionDto> {

    @Override
    public void initialize(FeeWaiverEvidenceRequired constraintAnnotation) {
    }

    @Override
    public boolean isValid(FinalSubmissionDto finalSubmissionDto, ConstraintValidatorContext context) {
        if (finalSubmissionDto.getUserRequestedFeeWaiver() && !finalSubmissionDto.getUserRequestedPartialFeeWaiver())
            return finalSubmissionDto.getFeeWaiver() != null && finalSubmissionDto.getEvidences().parallelStream()
                    .anyMatch(evidence -> "feeWaiver".equals(evidence.getEvidenceGroupType()));

        if (finalSubmissionDto.getUserRequestedFeeWaiver() && finalSubmissionDto.getUserRequestedPartialFeeWaiver()) {
            return finalSubmissionDto.getFeeWaiver() == null && finalSubmissionDto.getEvidences().parallelStream()
                    .anyMatch(evidence -> "feeWaiver".equals(evidence.getEvidenceGroupType()));
        }
        return true;
    }

}
