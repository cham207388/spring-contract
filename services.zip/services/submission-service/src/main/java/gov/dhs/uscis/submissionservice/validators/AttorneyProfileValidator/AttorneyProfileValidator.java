package gov.dhs.uscis.submissionservice.validators.AttorneyProfileValidator;

import java.util.Collections;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.validation.ClientNameEmailResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.RepresentativeProfileResponseData;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.PeepsService;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public abstract class AttorneyProfileValidator {
    protected PeepsService peepsService;
    protected ValidationStatusRepository statusDAO;
    protected final ValidatorEnum validatorType;
    protected final String FAILURE_MESSAGE;

    protected AttorneyProfileValidator(PeepsService peepsService, ValidationStatusRepository statusDAO, ValidatorEnum validatorType, String FAILURE_MESSAGE) {
        this.peepsService = peepsService;
        this.statusDAO = statusDAO;
        this.validatorType = validatorType;
        this.FAILURE_MESSAGE = FAILURE_MESSAGE;
    }

    public void validate(ClientNameEmailResponse messageResponse) {
        RepresentativeProfileResponseData profileData = peepsService.retrieveRepresentativeProfile(messageResponse.getMyUscisId());
        statusDAO.save(createValidationStatus(messageResponse, profileData));
    }

    protected abstract boolean validationFails(ClientNameEmailResponse messageResponse, RepresentativeProfileResponseData profileData);

    private ValidationStatus createValidationStatus(ClientNameEmailResponse messageResponse, RepresentativeProfileResponseData profileData) {
        return validationFails(messageResponse, profileData) ? failingStatus(messageResponse) :  passingStatus(messageResponse);
    }

        private ValidationStatus failingStatus(ClientNameEmailResponse messageResponse) {
        log.warn("Validation failed for submissionId {}: {}",
                messageResponse.getSubmissionId(), FAILURE_MESSAGE);
        return ValidationStatus.builder()
                .validator(validatorType)
                .formId(messageResponse.getFormId())
                .submissionId(messageResponse.getSubmissionId())
                .status(ValidationResultEnum.FAIL)
                .failureReasons(Collections.singletonList(FAILURE_MESSAGE))
                .build();
    }

    private ValidationStatus passingStatus(ClientNameEmailResponse messageResponse) {
        log.info("{} validation passed for submissionId {}.", validatorType.toString(), messageResponse.getSubmissionId());
        return ValidationStatus.builder()
                .validator(validatorType)
                .formId(messageResponse.getFormId())
                .submissionId(messageResponse.getSubmissionId())
                .status(ValidationResultEnum.PASS)
                .failureReasons(Collections.emptyList())
                .build();
    }



    
}
