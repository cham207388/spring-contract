package gov.dhs.uscis.submissionservice.validators;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Documented
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = FormValidator.class)
public @interface ValidForm {

    String message() default "\"Submitted form is invalid\"";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
