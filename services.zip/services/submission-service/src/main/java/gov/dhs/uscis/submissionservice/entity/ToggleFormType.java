package gov.dhs.uscis.submissionservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class ToggleFormType {

    public ToggleFormType(String toggleName, String formType) {
        this.toggleName = toggleName;
        this.formType = formType;
    }

    public ToggleFormType(){}

    @Column(name = "toggle_name")
    private String toggleName;

    @Column(name = "form_type")
    private String formType;
}
