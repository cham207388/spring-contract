package gov.dhs.uscis.submissionservice.models;

import java.util.List;

import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import lombok.Builder;

@Builder
public record SubmissionResponse(String submissionId, String myUscisId, List<SubmissionForm> forms) {

}