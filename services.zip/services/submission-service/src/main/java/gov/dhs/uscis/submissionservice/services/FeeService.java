package gov.dhs.uscis.submissionservice.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I130EligibilityCategory;
import gov.dhs.uscis.intake.enums.I131EligibilityCategory;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.N400EligibilityCategory;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.dto.C9Options;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I907FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.controllers.SubmissionDetailsController.FeeDetails;
import gov.dhs.uscis.submissionservice.exception.FeeHandlerNotFoundException;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.services.fees.FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.FormFeeHandler;
import gov.dhs.uscis.submissionservice.services.fees.handlers.I130Handler;
import gov.dhs.uscis.submissionservice.services.fees.handlers.I131Handler;
import gov.dhs.uscis.submissionservice.services.fees.handlers.I765Handler;
import gov.dhs.uscis.submissionservice.services.fees.handlers.N400Handler;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i131.I131Fees;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765C11FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765C9FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765Fees;
import gov.dhs.uscis.submissionservice.services.fees.strategies.n400.N400Fees;

@Service
public class FeeService {
    private List<FormFeeHandler<?, ?>> handlers;
    private SubmissionRepository submissionRepository;
    private Logger logger = LoggerFactory.getLogger(FeeService.class);

    private static final int MAX_ELIGIBILITY_CATEGORY_LENGTH = 80;

    public FeeService(FormMetaDataRepository formMetaDataRepository, SubmissionRepository submissionRepository) {
        this.submissionRepository = submissionRepository;
        handlers = Lists.newArrayList();
        handlers.add(new I765Handler(formMetaDataRepository));
        handlers.add(new N400Handler());
        handlers.add(new I131Handler());
        handlers.add(new I130Handler());
    }


    public boolean isEligibleForFeeWaiver(FormType formType, EligibilityCategoryEnum category, FeeStrategyOptions options) {
        // Initially only supported for I-765, and used for making a positive determination that the eligibility
        // combination should be able to see the ""
        if (FormType.I765.equals(formType)) {
            Optional<FormFeeHandler<?, ?>> handlerFor = handlers.parallelStream().filter(handler -> handler.canHandle(formType)).findFirst();
            return ((I765Handler) handlerFor.get()).inquireAboutFeeWaiver((I765EligibilityCategory) category, options);
        } else {
            return false;
        }
    }



    public BigDecimal calculateFeeFor(FormType formType, EligibilityCategoryEnum category, FeeStrategyOptions options) {
        Optional<FormFeeHandler<?, ?>> handlerFor = handlers.parallelStream()
                .filter(handler -> handler.canHandle(formType)).findFirst();

                if (handlerFor.isPresent() && FormType.I765.equals(formType))
                    return ((I765Handler) handlerFor.get()).handle((I765EligibilityCategory) category, options);

        if (handlerFor.isPresent() && FormType.N400.equals(formType))
            return ((N400Handler) handlerFor.get()).handle((N400EligibilityCategory) category, null);

        if (handlerFor.isPresent() && FormType.I131.equals(formType))
            return ((I131Handler) handlerFor.get()).handle((I131EligibilityCategory) category, null);

        if (handlerFor.isPresent() && FormType.I130.equals(formType))
            return ((I130Handler) handlerFor.get()).handle((I130EligibilityCategory) category, null);

        throw new FeeHandlerNotFoundException(formType);
    }
        public BigDecimal calculateI765FeeFor(FormType formType, I765EligibilityCategory category) {
        if (category == null)
            return I765Fees.FEE_EXEMPT;
        FeeStrategyOptions options = null;
        if (I765EligibilityCategory.isC11Category(category)) {
            options = new I765C11FeeStrategyOptions(false,
                    I765EligibilityCategory.C11AFGHAN.equals(category),
                    I765EligibilityCategory.C11UKRAINE.equals(category), null, false);
        } else if (I765EligibilityCategory.isC9Category(category)) {
            options = new I765C9FeeStrategyOptions(new C9Options(true, false), false);
        } else {
            options = new I765FeeStrategyOptions(false, false, false, null, false);

        }

        return calculateFeeFor(formType, category, options);

    }

    public BigDecimal calculateN400FeeFor(FormType formType, N400EligibilityCategory category) {
        if (category == null)
            return N400Fees.FEE_EXEMPT;

        return calculateFeeFor(formType, category, null);
    }

    public FeeDetails retrieveCalculatedFeeFor(String submissionId) {
        logger.info("Calculating fees for {}", submissionId);

        var submission = submissionRepository.getById(submissionId);
        if (submission.isEmpty()) {
            throw new NoSuchElementException(String.format("Submission does not exist:  %s", submissionId));
        }
        if (submission.get().getFeeTotal() == null) {
            throw new NoSuchElementException(
                    String.format("Submission does not have a calculated fee:  %s", submissionId));
        }
        String category = null;
        if(!submission.get().getFormType().equals(FormType.I907.getType())) {
            String eligibilityCategory = submission.map(sub -> sub.getEligibilityCategory().getCategory()).orElse("");

            category = Optional.ofNullable(submission.get().getEligibilitySubcategory())
                    .map(EligibilitySubcategoryEnum::getCategory)
                    .filter(s -> !s.isBlank())
                    .map(s -> eligibilityCategory + "-" + s)
                    .orElse(eligibilityCategory);
            category = category.length() > MAX_ELIGIBILITY_CATEGORY_LENGTH
                    ? category.substring(0, MAX_ELIGIBILITY_CATEGORY_LENGTH)
                    : category;
            logger.info("Returning calculated fee for submission {} with value {} and category {}", submissionId,
                    submission.get().getFeeTotal(), category);
        } else {
            category = get907UnderlyingReceipt(submission.get());
        }
                    SubmissionForm mainForm = submission
                        .flatMap(sub -> sub.getForms().stream()
                            .filter(form -> form.getType().equals(sub.getFormType().getType()))
                            .findFirst())
                        .orElseThrow(() -> new NoSuchElementException("Submission or matching form not found"));

                    List<String> allFormTypes = submission.map(s -> {
                        // 1. Safely get the comparison type first
                        String currentType = s.getFormType().getType();

                        // 2. Process the stream without referencing the Optional again
                        return s.getForms().stream()
                                .map(SubmissionForm::getType)
                                .filter(type -> !("G-28").equalsIgnoreCase(type) &&
                                            !type.equalsIgnoreCase(currentType))
                                .distinct()
                                .toList();
                    }).orElse(List.of());
    // If submission is empty or forms list is null, return an empty list
                boolean under14Value = submission
                    .filter(s -> s.getFormType() == FormType.I485)
                    .map(s -> mainForm.getFormSpecificInfo())
                    .filter(I485FormSpecificInfo.class::isInstance)
                    .map(info -> ((I485FormSpecificInfo) info).isUnder14())
                    .orElse(false);
                    List<String> forms = new ArrayList<>();
                    forms.add(mainForm.getType());
                    forms.addAll(allFormTypes);
		return new FeeDetails(submission.get().getFeeTotal(), category,   under14Value, forms);
    }

    public BigDecimal calculateI131FeeFor(FormType formType, I131EligibilityCategory category) {
        if (category == null)
            return I131Fees.FEE_EXEMPT;

        return calculateFeeFor(formType, category, null);
    }

    public BigDecimal calculateI130FeeFor(FormType formType, I130EligibilityCategory category) {
        if (category == null)
            return I131Fees.FEE_EXEMPT;

        return calculateFeeFor(formType, category, null);
    }

    private String get907UnderlyingReceipt(Submission submission) {
        if(submission.getFormSpecificInfo() != null) {
            logger.info("Setting I907 underlying petition receipt number as eligibility category for elis payment request");
            return ((I907FormSpecificInfo) submission.getFormSpecificInfo()).getUnderlyingPetitionReceiptNumber();
        }
        return "";
    }
}
