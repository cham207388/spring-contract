package gov.dhs.uscis.submissionservice.utils;

public record Tuple<A, B>(A first, B second) {}
