package gov.dhs.uscis.submissionservice.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.clients.UserGroupServiceClient;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;
import gov.dhs.uscis.submissionservice.controllers.AddClientRequestDetails;
import gov.dhs.uscis.submissionservice.exception.AddClientValidationException;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.ApplicantUuidResponse;
import gov.dhs.uscis.submissionservice.repository.ClientInformationRepository;
import gov.dhs.uscis.submissionservice.utils.FormRulesUtil;

@Service
public class ClientManagementService {
    public static final String CLIENT_INFORMATION_DOES_NOT_MATCH_ERROR = "Client information does not match input on the form";
    public static final String REP_EMAIL_ERROR = "You cannot use your email address when adding your client.";
    public static final String REP_USERGROUP_ID_NOT_FOUND_ERROR = "Unable to add client due to not being able to fetch rep user group id";
    public static final String CLIENT_ALREADY_ASSOCIATED_ERROR = "Client already associated.";
    public static final String CLIENT_CANNOT_FILE_FORM = "A %s form that is currently in a draft or pending decision status already exists for this client. A new submission cannot be performed at this time.";

    private Logger logger = LoggerFactory.getLogger(ClientManagementService.class);
    private ClientInformationRepository submissionClientRepository;
    private final PeepsService peepsService;
    private final DraftBenefitsService draftBenefitsService;
    private final UserGroupServiceClient userGroupServiceClient;

    public ClientManagementService(UserGroupServiceClient userGroupServiceClient, PeepsService peepsService,
            DraftBenefitsService draftBenefitsService,
            ClientInformationRepository submissionClientRepository) {
        this.userGroupServiceClient = userGroupServiceClient;
        this.submissionClientRepository = submissionClientRepository;
        this.peepsService = peepsService;
        this.draftBenefitsService = draftBenefitsService;
    }

    public ClientInformation addClient(String attorneyId, Submission submission, AddClientRequestDetails details) {
        logger.info("Attempting to add client {} to attorney {}", details.emailAddress(), attorneyId);

        ClientInformation representativeClient = addRepresentativeClient(attorneyId, submission, details.emailAddress(),
                details.name(), details.dateOfBirth(), details.aNumber());

        if (representativeClient != null) {
            logger.info("Client was successfully add at myUscis {}", representativeClient.getClientId());
            submissionClientRepository.save(attorneyId, representativeClient.getClientId(),
                    submission.getSubmissionId(), details.name(), representativeClient.getUserGroupIds());
        }
        return representativeClient;
    }

    private ClientInformation addRepresentativeClient(String attorneyId, Submission submission, String emailAddress,
            Name name, String dateOfBirth, String aNumber) {


        boolean valid = peepsService.validateClientEmailIsNotAttorneyEmail(attorneyId, emailAddress);
        if (!valid) {
            throw new AddClientValidationException(REP_EMAIL_ERROR);
        }

        var applicantInfo = peepsService.retrieveApplicantId(emailAddress);
        String userGroupId = getRepUserGroupId(attorneyId, submission.getSubmissionId());

        if (applicantInfo != null) {
            performPreliminaryChecks(attorneyId, submission, applicantInfo);
        } else {
            logger.info("Applicant info is null, meaning client does not have an account. Inviting client");
            return userGroupServiceClient.inviteClient(attorneyId, userGroupId, submission.getSubmissionId(),
                    emailAddress, name);
        }

        var clientMatchesForm = peepsService.verifyClientInformation(applicantInfo.applicantUUID(), name,
                dateOfBirth, aNumber);
        if (clientMatchesForm) {
            logger.info("Client information matches the filled out form. Inviting client");
            ClientInformation clientInformation = userGroupServiceClient.inviteClient(attorneyId, userGroupId, submission.getSubmissionId(),
                    emailAddress,
                    name);
                    clientInformation.setClientId(applicantInfo.applicantUUID());
            return clientInformation;

        } else {
            logger.info("Client information does not match input on client information form {},", attorneyId);
            throw new AddClientValidationException(
                    CLIENT_INFORMATION_DOES_NOT_MATCH_ERROR);
        }

    }

    private void performPreliminaryChecks(String attorneyId, Submission submission,
            ApplicantUuidResponse applicantInfo) {
        if (FormRulesUtil.isOneFormPerApplicant(submission.getFormType())) {
            checkIfApplicantIsAbleToFileForm(submission.getFormType(), applicantInfo);
        }

        boolean clientAssociated = userGroupServiceClient.isClientAssociated(attorneyId, applicantInfo.applicantUUID())
                .isAssociated();
        if (clientAssociated) {
            logger.info("Client {} already associated with rep", applicantInfo.applicantUUID());
            throw new AddClientValidationException(CLIENT_ALREADY_ASSOCIATED_ERROR);
        }
    }

    private void checkIfApplicantIsAbleToFileForm(FormType formType, ApplicantUuidResponse applicantInfo) {
        boolean clientIsAbleToFileForm = draftBenefitsService
                .canApplicantFileFor(formType.getType(), applicantInfo.applicantUUID());
        if (!clientIsAbleToFileForm) {
            String errorMessage = String.format(CLIENT_CANNOT_FILE_FORM, formType.getType());
            throw new AddClientValidationException(errorMessage);
        }
    }

    private String getRepUserGroupId(String attorneyId, String submissionId) {
        ClientInformation clientInformation = submissionClientRepository.findBySubmissionId(submissionId);
        String userGroupId;

        if (clientInformation == null) {
            UserGroupRole repGroupId = userGroupServiceClient.getRepGroupId(attorneyId);
            if (repGroupId == null)
                userGroupId = null;
            else
                userGroupId = repGroupId.getUserGroupId();
        } else
            userGroupId = clientInformation.getUserGroupIds().getFirst();

        if (userGroupId == null)
            throw new AddClientValidationException(REP_USERGROUP_ID_NOT_FOUND_ERROR);
        return userGroupId;
    }

    public List<ClientInformation> getListOfClientInformation(String clientId) {
        return submissionClientRepository.findAllByClientId(clientId);
    }
}