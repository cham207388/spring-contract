package gov.dhs.uscis.submissionservice.configs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;

import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

import jakarta.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class SecurityConfiguration {

    @Bean
    public SecurityFilterChain securityFilterChain (
            HttpSecurity http, 
            @Nullable JwtDecoder jwtDecoder /* only if OAuth enabled */
    ) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(config -> config.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .exceptionHandling(exp -> exp.authenticationEntryPoint(
                // Default to 401 instead of 403
                new HttpStatusEntryPoint(UNAUTHORIZED) ))
        ;

        if (null != jwtDecoder) {
            http
                .oauth2ResourceServer(server -> server.jwt(s -> s.decoder(jwtDecoder)))
                .authorizeHttpRequests(request -> request
                    .requestMatchers("/actuator/health").permitAll()
                    .requestMatchers(HttpMethod.GET, "/swagger-ui/**").permitAll()
                    .requestMatchers(HttpMethod.GET, "/v3/api-docs/**").permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/*/submissions").permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/*/submissions/org/*").permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/submissions/manifest/*").permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/submissions/*/manifest/id").permitAll()
                    .requestMatchers(HttpMethod.DELETE, "/api/v1/*/submissions/*").permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/submissions/*/fee").permitAll()
                    .requestMatchers(HttpMethod.PUT, "/api/v1/*/submissions/*/lockbox-status").permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/submissions/*/ingestion").permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/*/submissions/*/pfvs/validate").permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/v1/toggle/get-toggle/formType/**").permitAll()
                    .requestMatchers(HttpMethod.POST, "/api/v1/*/submissions/*").permitAll()
                    .requestMatchers("/error").permitAll()
                    .anyRequest().authenticated() )
            ;
        } else {
            log.info("Configuring server with OAuth DISABLED");
            http
                .authorizeHttpRequests(request -> request
                    .anyRequest().permitAll() )
                .anonymous(Customizer.withDefaults())
            ;
        }

        return http.build();
    }

    /**
     * Log requests by setting:
     *  logging.level.org.springframework.web.filter.CommonsRequestLoggingFilter=DEBUG
     */
    @Bean
    public CommonsRequestLoggingFilter requestLoggingFilter() {
        CommonsRequestLoggingFilter loggingFilter = new CommonsRequestLoggingFilter();
        loggingFilter.setIncludeHeaders(true);
        loggingFilter.setIncludeClientInfo(false);
        loggingFilter.setIncludeQueryString(true);
        loggingFilter.setIncludePayload(true);
        loggingFilter.setMaxPayloadLength(64000);
        return loggingFilter;
    }
}
