package gov.dhs.uscis.submissionservice.validators;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import gov.dhs.uscis.submissionservice.services.FormService;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class EvidenceValidator implements ConstraintValidator<ValidEvidence, FinalSubmissionDto> {
    private final FormService service;

    @Override
    public boolean isValid(FinalSubmissionDto submission, ConstraintValidatorContext context) {
        if(FormType.I907.getType().equals(submission.getType().getType())) {
            return true;
        }

        if (submission.getCategory() == null) return false;
        if (submission.getEvidences() == null) return true;

        Set<String> validEvidenceIds = submission.getForms().stream()
            .filter(form -> form != null && form.getType() != null )
            .filter(form -> form.getEligibilityCategory() != null && form.getEligibilityCategory().getCategory() != null)
            .map(form -> this.service.retrieveEvidenceGroups(
                form.getType(), 
                form.getEligibilityCategory().getCategory()
            ))
            .flatMap(List::stream)
            .flatMap(group -> group.getEvidenceTypes().stream())
            .map(type -> type.getId())
            .collect(Collectors.toSet());

        if (Boolean.TRUE.equals(submission.getUserRequestedFeeWaiver())) {
            validEvidenceIds.add("Other");
        }

        return submission.getEvidences().stream()
            .allMatch(evidence -> validEvidenceIds.contains(evidence.getType()));
    }

}
