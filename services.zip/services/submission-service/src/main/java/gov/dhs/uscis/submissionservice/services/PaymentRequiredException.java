package gov.dhs.uscis.submissionservice.services;

import java.net.URI;

public class PaymentRequiredException extends Exception{

    private final URI redirectUrl;

    public PaymentRequiredException(URI redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public URI getRedirectUrl() {
        return redirectUrl;
    }

}
