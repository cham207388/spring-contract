package gov.dhs.uscis.submissionservice.exception;

public class SubmissionIndexException  extends RuntimeException {

  public SubmissionIndexException(String errorMessage) {
      super(String.format("%s", errorMessage));
  }
}
