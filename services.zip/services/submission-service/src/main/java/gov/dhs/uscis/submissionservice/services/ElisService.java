package gov.dhs.uscis.submissionservice.services;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.BodyInserters.MultipartInserter;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ElisService {

    static final String CASE_PHOTO_VALIDATE_PATH = "/v1/case/photo/validate";
    private WebClient elisWebClient;

    public ElisService(@Qualifier("elisWebClient") WebClient elisWebClient) {
        this.elisWebClient = elisWebClient;
    }

    public ResponseEntity<Void> validatePhoto(MediaType type, Resource photoFile) throws WebClientResponseException {
        log.info("Mediatype: {} ", type);
        return elisWebClient.post().uri(CASE_PHOTO_VALIDATE_PATH)
                    .header("ELISExternalUserName", "PDF-Intake")
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.MULTIPART_FORM_DATA)
                    .body(getMultiPartFile(type, photoFile)).retrieve()
                    .toBodilessEntity()
                    .block();
    }

    private static MultipartInserter getMultiPartFile(MediaType type, Resource file) {
        MultipartBodyBuilder builder = new MultipartBodyBuilder();
        builder.part("file", file, type);
        return BodyInserters.fromMultipartData(builder.build());
    }
}