package gov.dhs.uscis.submissionservice.models.dto;

import lombok.NonNull;
import lombok.Builder;

@Builder
public record S3FileInfo(
    @NonNull String id, 
    @NonNull String checksum, 
    @NonNull String artifactId,
    @NonNull String s3Key) {
}
