package gov.dhs.uscis.submissionservice.components;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ELISValidationResponse;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.WatermarkerStatus;
import gov.dhs.uscis.intake.models.additionalinformation.I131AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I485AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I907AdditionalInformation;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I907FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ToggleService;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Component
@RequiredArgsConstructor
public class ElisValidationResponseListener implements MessageListener {

    private final ValidationStatusRepository validationStatusDAO;
    private final SubmissionRepository submissionDAO;
    private final ToggleService toggleService;
    private final SubmissionService submissionService;

    private static final Long HR1_FEE = 275L;
    ObjectMapper mapper = new ObjectMapper();

    @Override
    public void onMessage(Message message) {
        TextMessage textMessage = (TextMessage) message;
        try {
            MDC.put("traceId", UUID.randomUUID().toString());
            ELISValidationResponse updatedStatuses = mapper.readValue(textMessage.getText(),
                    ELISValidationResponse.class);
            if(updatedStatuses.results().size() == 0) {
                log.info("ignoring validation response with 0 validation statuses for form {} for submission {}", updatedStatuses.formId(), updatedStatuses.submissionId());
                return;
            }
            log.info("Received elis validation response with {} statuses, for form {} for submission {} resulting in a {}",
                    updatedStatuses.results().size(), updatedStatuses.formId(), updatedStatuses.submissionId(), updatedStatuses.pass());
            if(updatedStatuses.inProgress()){
                validationStatusDAO.deleteById(updatedStatuses.formId(), ValidatorEnum.CORE);
                log.info("Deleted CORE Validation Status for form id: {}", updatedStatuses.formId());
            }
            updatedStatuses.results().stream().forEach(validationStatusDAO::update);
            Optional<Submission> existingSubmissionOpt = submissionDAO.getById(updatedStatuses.submissionId());
            if (existingSubmissionOpt.isPresent()) {
                Submission existingSubmission = existingSubmissionOpt.get();

                if (existingSubmission.getForms() != null) {
                	boolean isEsignRequest = false;
                    Optional<SubmissionForm> updatedForm = existingSubmission.getForms().stream().filter(t -> t.getId().equals(updatedStatuses.formId())).findFirst();
                    if(updatedForm.isPresent()){
                    	if(updatedStatuses.fee() != null) {
                            log.info("Setting {} form fee to {}", updatedForm.get().getType(), updatedStatuses.fee());
                    		updatedForm.get().setFeeTotal(updatedStatuses.fee());
                    	}

                        Optional<ValidationStatus> esignStatus = updatedStatuses.results().stream().filter((res) -> res.getValidator() == ValidatorEnum.ESIGN).findFirst();
                        if(esignStatus.isPresent()) {
                        	isEsignRequest = true;
                        	if(esignStatus.get().getStatus() == ValidationResultEnum.PASS) {
	                        	log.info("Received a successful esign validation from elis");
	                        	updatedForm.get().setAttestationStatus(WatermarkerStatus.StatusEnum.SUCCESS);
                        	}
                        }
                    } else {
                        log.info("Form {} does not exist on Submission {}, skipping processing", updatedStatuses.formId(), updatedStatuses.submissionId());
                        return;
                    }

                    if(updatedStatuses.submissionFees() != null) {
                        for(SubmissionForm form : existingSubmission.getForms()) {
                            if(updatedStatuses.submissionFees().containsKey(form.getType())) {
                                log.info("Setting {} form fee to {} using submissionFees object", form.getType(), updatedStatuses.fee());
                                form.setFeeTotal(updatedStatuses.submissionFees().get(form.getType()));
                            }
                        }
                    }


                    if(!isEsignRequest){
                        BigDecimal totalFee = BigDecimal.ZERO;
                        boolean feeWaiverHandledInPFVS = toggleService.isToggleActive(ToggleEnum.PFVS_I912, existingSubmission.getFormType().getType());
                        if (!existingSubmission.getUserRequestedFeeWaiver() && updatedStatuses.fee() != null) {
                            if(updatedStatuses.fee() != null){
                                log.info("Adding form fee of {} to total fee", updatedStatuses.fee());
                                totalFee = totalFee.add(updatedStatuses.fee());
                            }
                            if(updatedStatuses.submissionFees() != null) {
                                for(String formType : updatedStatuses.submissionFees().keySet()) {
                                    log.info("Adding {} form fee of {} to total fee", formType , updatedStatuses.fee());
                                    totalFee = totalFee.add(updatedStatuses.submissionFees().get(formType));
                                }
                            }
                        } else if(!feeWaiverHandledInPFVS && existingSubmission.getUserRequestedFeeWaiver() && existingSubmission.getFormType().equals(FormType.I131.getType()) && updatedStatuses.additionalInfo() != null) {
                            I131AdditionalInformation additionalInfo = (I131AdditionalInformation) updatedStatuses.additionalInfo();
                            if(additionalInfo.getRequestedEAD()) {
                                totalFee = totalFee.add(BigDecimal.valueOf(HR1_FEE));
                            }
                        }
                        existingSubmission = handle485TDSS(existingSubmission,  updatedForm.get(), updatedStatuses);

                        if(updatedStatuses.totalFee() != null && (feeWaiverHandledInPFVS || !existingSubmission.getUserRequestedFeeWaiver())) {
                            log.info("Overriding calculated fees with PFVS total fee");
                            totalFee = updatedStatuses.totalFee();
                        }

                         log.info("Setting submission fee total to {}", totalFee);
                         existingSubmission.setFeeTotal(totalFee);
                         if (updatedStatuses.totalFee() != null
                                 && totalFee.compareTo(BigDecimal.ZERO) == 0
                                 && toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, existingSubmission.getFormType().getType())) {
                             log.info(
                                     "PFVS determined submission {} is fee exempt based on form data. Cleaning up fee waiver information",
                                     existingSubmission.getSubmissionId());
                             submissionService.cleanupFeeWaiverForFeeExemptSubmission(existingSubmission);
                         }
                     }

                    if(existingSubmission.getFormType().equals(FormType.I907.getType()) && updatedStatuses.additionalInfo() != null) {
                        I907AdditionalInformation i907additionalInfo = (I907AdditionalInformation) updatedStatuses.additionalInfo();
                        if(i907additionalInfo.getUnderlyingPetitionReceiptNumber() != null) {
                            existingSubmission.setFormSpecificInfo(new I907FormSpecificInfo(i907additionalInfo.getUnderlyingPetitionReceiptNumber()));
                            log.info("Set underlying petition receipt number for 907");
                        }
                    }
                }
                submissionDAO.save(existingSubmission);
            }
            textMessage.acknowledge();
        } catch (Exception e) {
            throw new RuntimeException("Could not deserialize the validation status object", e);
        } finally {
            MDC.clear();
        }
    }

    private Submission handle485TDSS(Submission existingSubmission, SubmissionForm updatedForm, ELISValidationResponse updatedStatuses) {
        if (FormType.I485.equals(existingSubmission.getFormType()) && updatedStatuses.additionalInfo() instanceof I485AdditionalInformation additionalInfoFromPFVS) {
                            FormSpecificInfo i485Info;
                            // Check if object is null, if so, initialize it
                            if (existingSubmission.getFormSpecificInfo() == null) {
                                i485Info = new I485FormSpecificInfo();
                            }
                            else {
                               i485Info =  existingSubmission.getFormSpecificInfo();
                            }

                            // Safely cast and update
                            if (i485Info instanceof I485FormSpecificInfo) {
                                ((I485FormSpecificInfo) i485Info).setUnder14(additionalInfoFromPFVS.isUnder14());
                                existingSubmission.setFormSpecificInfo(i485Info);
                                updatedForm.setFormSpecificInfo(i485Info);
                            }

                        }
                        return existingSubmission;

    }
}