package gov.dhs.uscis.submissionservice.services.fees;

public interface FeeStrategyOptions {}
