package gov.dhs.uscis.submissionservice.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.submissionservice.services.ClientManagementService;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "Clients", description = "Client Management APIs")
@RestController
@RequestMapping("/api/v1/{myUscisId}/submissions/{submissionId}/clients")
public class ClientController {

    private ClientManagementService clientManagementService;
    private SubmissionService submissionService;
    private Logger logger = LoggerFactory.getLogger(ClientController.class);

    public ClientController(ClientManagementService clientManagementService, SubmissionService submissionService) {
        this.clientManagementService = clientManagementService;
        this.submissionService = submissionService;
    }

    @PostMapping("/add-client")
    public ResponseEntity<String> addClientLegacy(@PathVariable String myUscisId, @PathVariable String submissionId,
            @RequestBody AddClientRequestDetails details) {
        return addClient(myUscisId, submissionId, details);
    }

    @PostMapping()
    public ResponseEntity<String> addClient(@PathVariable String myUscisId, @PathVariable String submissionId,
            @RequestBody AddClientRequestDetails details) {
        logger.info("Adding client for submission {}", submissionId);

        Submission submission = this.submissionService.retrieveSubmission(submissionId);
        ClientInformation client = clientManagementService.addClient(myUscisId, submission, details);

        if (client != null) {
            return ResponseEntity.ok().body(client.getClientId());
        } else {
            return ResponseEntity.ok().body(null);
        }
    }
}
