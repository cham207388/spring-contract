package gov.dhs.uscis.submissionservice.validators;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class IsDraftValidator
        implements ConstraintValidator<IsDraft, SubmissionState> {

    @Override
    public void initialize(IsDraft constraintAnnotation) {
    }

    @Override
    public boolean isValid(SubmissionState submissionState, ConstraintValidatorContext context) {
        return submissionState == SubmissionState.DRAFT;
    }

}
