package gov.dhs.uscis.submissionservice.services;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.models.Submission;

@Component
public class MyUscisCacheManagementClient {

    private Logger logger = LoggerFactory.getLogger(MyUscisCacheManagementClient.class);
    private WebClient webClient;

    private static final String UPDATE_DRAFT_ENDPOINT = "/api/pdfi/drafts";
    private static final String UPDATE_CASE_ENDPOINT = "/api/pdfi/cases";
    private ObjectMapper objectMapper;
    private boolean enabled;

    public MyUscisCacheManagementClient(WebClient webClient, ObjectMapper objectMapper, boolean enabled) {
        this.webClient = webClient;
        this.enabled = enabled;
        this.objectMapper = objectMapper;
    }

    public void publishDraftChangeEvent(Submission submission) {
    	if (enabled && !AccountType.APPLICANT.equals(submission.getApplicant().getAccountType())) {
            try {
                logger.info("Updating draft in myUscis Cache with id {}", submission.getSubmissionId());
                webClient.post()
                        .uri(UPDATE_DRAFT_ENDPOINT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(objectMapper.writeValueAsString(submission))
                        .header("ICAM-UUID", submission.getMyUscisId())
                        .retrieve()
                        .bodyToMono(Map.class)
                        .block();
            } catch (Exception ex) {
                logger.error("error while publishing new submission created to myuscis.", ex);
            }
    	}
    	else {
    		logger.info("Not updating myUSCIS draft cache, updates are disabled for user type {}",
                    submission.getApplicant().getAccountType());
    	}
    }

    public void publishCaseChangeEvent(Submission submission) {
    	if (enabled && !AccountType.APPLICANT.equals(submission.getApplicant().getAccountType())) {
            try {
                logger.info("Updating submission status in myUSCIS cache {} with status {}",
                        submission.getSubmissionId(), submission.getStatus());
                webClient.post()
                        .uri(UPDATE_CASE_ENDPOINT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(objectMapper.writeValueAsString(submission))
                        .header("ICAM-UUID", submission.getMyUscisId())
                        .retrieve()
                        .bodyToMono(Map.class)
                        .block();
            } catch (Exception ex) {
                logger.error("error while publishing new submission created to myuscis.", ex);
            }
    	}
    	else {
    		logger.info("Not updating myUSCIS cases cache, updates are disabled for user type {}",
                    submission.getApplicant().getAccountType());
    	}
    }
}