package gov.dhs.uscis.submissionservice.models;


public record InitialSubmissionCreationRequest(String myUscisId, String eligibilityCategory) {
}
