package gov.dhs.uscis.submissionservice.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I751EligibilityCategory;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.form.metadata.EligibilityCategory;
import gov.dhs.uscis.intake.models.form.metadata.EligibilitySubcategory;
import gov.dhs.uscis.intake.models.form.metadata.MetaData;
import gov.dhs.uscis.submissionservice.entity.ConcurrentForms;
import gov.dhs.uscis.submissionservice.models.EligibilityCategoryResponse;
import gov.dhs.uscis.submissionservice.repository.ConcurrentFormsRepository;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;

@Service
@Slf4j
public class FormService {

    private DynamoDbTable<FormMetaData> formMetaDataTable;
    private ClientManagementService clientManagementService;
    private SubmissionRepository submissionRepository;
    private ConcurrentFormsRepository concurrentFormsRepository;

    public FormService(DynamoDbTable<FormMetaData> formMetaDataTable, ClientManagementService clientManagementService,
            SubmissionRepository submissionRepository, ConcurrentFormsRepository concurrentFormsRepository) {
        this.formMetaDataTable = formMetaDataTable;
        this.clientManagementService = clientManagementService;
        this.submissionRepository = submissionRepository;
        this.concurrentFormsRepository = concurrentFormsRepository;
    }

    public FormMetaData retrieveFormMetaData(String formType) {
        Key key = Key.builder().partitionValue(formType).build();
        GetItemEnhancedRequest request = GetItemEnhancedRequest.builder().key(key).build();
        return formMetaDataTable.getItem(request);
    }

    public List<EvidenceGroup> retrieveEvidenceGroups(String formType, String eligibilityCategory) {
        FormMetaData formMetaData = retrieveFormMetaData(formType);
        if (formMetaData == null)
            return List.of();
        EligibilityCategory data = formMetaData.getEligibilityCategories().stream()
                .filter(eligibilityCategoryData -> eligibilityCategoryData.getCategory().equals(eligibilityCategory))
                .findFirst().orElseThrow();
        List<EvidenceGroup> evidenceGroups = new ArrayList<>(Optional.ofNullable(data.getMetaData().getEvidenceGroups()).orElse(Collections.emptyList()));
        List<EligibilitySubcategory> subcategories = data.getMetaData().getSubcategories();
        if (subcategories != null)
            evidenceGroups.addAll(subcategories.stream().flatMap(subCategory -> {
                return subCategory.getEvidenceGroupsToInclude() != null
                        ? subCategory.getEvidenceGroupsToInclude().stream()
                        : Stream.of();
            }).toList());
        return evidenceGroups;
    }

    public EvidenceGroup retrieveEvidenceGroup(String formType, String eligibilityCategory, String groupType) {
        return this.retrieveEvidenceGroups(formType, eligibilityCategory)
                .stream().filter((group) -> group.getId().equals(groupType)).findFirst().orElseThrow();
    }

    public List<EligibilityCategoryResponse> retrieveEligibilityCategories(String formType) {
        FormMetaData formMetaData = retrieveFormMetaData(formType);
        if (formMetaData == null)
            return new ArrayList<EligibilityCategoryResponse>();

        return formMetaData.getEligibilityCategories().stream()
                .map(eligibilityCategoryData -> {
                    MetaData metaData = eligibilityCategoryData.getMetaData();
                    return new EligibilityCategoryResponse(eligibilityCategoryData.getCategory(),
                            metaData.isFeeWaivable(),
                            metaData.isFeeExemptable());
                }).toList();
    }

    public List<MetadataValidationEnum> retrieveEvidenceGroupValidations(String formtype, String eligibilitycategory,
            String evidenceGroupId) {
        FormMetaData metadata = formMetaDataTable
                .getItem(GetItemEnhancedRequest.builder().key(Key.builder().partitionValue(formtype).build()).build());
        Optional<EligibilityCategory> filteredCategory = metadata.getEligibilityCategories().parallelStream()
                .filter(category -> category.getCategory().equals(eligibilitycategory)).findAny();
        if (filteredCategory.isPresent()) {
            Optional<List<MetadataValidationEnum>> validations = filteredCategory.get().getMetaData()
                    .getEvidenceGroups()
                    .parallelStream().filter(evidenceGroup -> evidenceGroup.getId().equals(evidenceGroupId))
                    .map(EvidenceGroup::getValidations).findAny();
            return validations.orElse(List.of());
        } else {
            return List.of();
        }
    }

    public Integer retrieveBenefitTypeCodeByEligiblityCategory(String formType, Submission submission ) {

            FormMetaData formMetaData = retrieveFormMetaData(formType);
            List<EligibilityCategory> eligiblityCategories = formMetaData.getEligibilityCategories();

            Optional<EligibilityCategory> eligibilityCategoryFormMetadata = eligiblityCategories.stream()
                    .filter(ec -> ec.getCategory().equals(submission.getEligibilityCategory().getCategory())).findFirst();
                    if (eligibilityCategoryFormMetadata.isPresent()) {
                        EligibilityCategory eligibilityCategory = eligibilityCategoryFormMetadata.get();
                        return Integer.valueOf(eligibilityCategory.getBenefitTypeCode());
                    }
        return 0;
    }

    public Boolean isFeeWaiverEnabled(FormType formType) {
        FormMetaData formMetaData = retrieveFormMetaData(formType.getType());
        return formMetaData.getFeeWaiverEnabled();
    }

    public Boolean canClientFile(String myUscisId, String formType) {
        List<ClientInformation> listOfClientInformation = clientManagementService.getListOfClientInformation(myUscisId);

        log.info("Checking client can file for {}", formType);
        return listOfClientInformation.stream()
                .map((info) -> submissionRepository.getById(info.getSubmissionId()))
                .filter((s) -> s.isPresent())
                .map(Optional::get)
                .filter((s) -> s.getFormType().getType().equals(formType)
                        && List.of(SubmissionState.RECEIVED, SubmissionState.DRAFT).contains(s.getStatus()))
                .count() < maxFiling(formType);
    }

    // This function will only run for the 751 as they are the only submission with sub categories
    public List<Integer> addApplicationReasonCodes(Submission submission, FormType formType) {
        List<Integer> eligiblitySubCategoryReasonCodes = new ArrayList<Integer>();

        if (submission.getEligibilityCategory() != null) {
            FormMetaData formMetaData = retrieveFormMetaData(formType.getType());

            List<EligibilityCategory> eligiblityCategories = formMetaData.getEligibilityCategories();
            Optional<EligibilityCategory> eligibilityCategoryFormMetadata = eligiblityCategories.stream()
                    .filter(ec -> ec.getCategory().equals(submission.getEligibilityCategory().getCategory())).findFirst();

            if (eligibilityCategoryFormMetadata.isPresent()) {
                if (I751EligibilityCategory.WAIVER_OR_INDIVIDUAL_FILING.equals(submission.getEligibilityCategory())
                        && !submission.getEligibilitySubcategories().isEmpty()) {
                    List<String> subCategoriesNames = submission.getEligibilitySubcategories().stream()
                            .map(p -> p.getCategory()).collect(Collectors.toList());
                    List<EligibilitySubcategory> subCategoryFormMetadata = eligibilityCategoryFormMetadata.get()
                            .getMetaData().getSubcategories();

                    List<EligibilitySubcategory> filteredFormMetadata = subCategoryFormMetadata.stream()
                            .filter(subCategory -> subCategoriesNames.contains(subCategory.getCategory()))
                            .collect(Collectors.toList());

                    filteredFormMetadata.stream().forEach(
                            ec -> eligiblitySubCategoryReasonCodes.add(Integer.parseInt(ec.getApplicationReasonCode())));
                } else if (I751EligibilityCategory.WAIVER_OR_INDIVIDUAL_FILING.equals(submission.getEligibilityCategory())) {
                    // If we are here the sub category list is empty. Do not send anything
                    return eligiblitySubCategoryReasonCodes;
                } else {
                    eligiblitySubCategoryReasonCodes.add(Integer.parseInt(eligibilityCategoryFormMetadata.get().getApplicationReasonCode()));

                    eligiblitySubCategoryReasonCodes.forEach(ec -> log.info("eligiblity codes to use are {}", ec));
                    return eligiblitySubCategoryReasonCodes;
                }
            }

        }
        return eligiblitySubCategoryReasonCodes;
    }

    // Todo: Extract out to a factory that takes in the formtype .
    private int maxFiling(String formType) {
        if (FormType.N400.getType().equals(formType))
            return 1;

        return Integer.MAX_VALUE;
    }

    public List<String> retrieveConcurrentForms(String formType) {
        List<String> formTypes = new ArrayList<>();
        List<ConcurrentForms> concurrentForms = concurrentFormsRepository.findByIdPrimaryFormTypeAndActiveIsTrue(formType);

        concurrentForms.stream().forEach(form -> formTypes.add(form.getId().getConcurrentFormType()));
        return formTypes;
    }

}
