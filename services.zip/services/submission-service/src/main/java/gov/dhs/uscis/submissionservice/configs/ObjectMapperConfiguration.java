package gov.dhs.uscis.submissionservice.configs;

import java.time.ZonedDateTime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.util.MimeType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;

import gov.dhs.uscis.intake.converters.FromMimeTypeSerializer;
import gov.dhs.uscis.intake.converters.ToMimeTypeDeserializer;
import gov.dhs.uscis.intake.converters.ZonedDateTimeDeserializer;
import gov.dhs.uscis.intake.converters.ZonedDateTimeSerializer;

@Configuration
public class ObjectMapperConfiguration {
    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        final SimpleModule module = new SimpleModule();
        module.addSerializer(ZonedDateTime.class, new ZonedDateTimeSerializer());
        module.addDeserializer(ZonedDateTime.class, new ZonedDateTimeDeserializer());
        module.addSerializer(MimeType.class, new FromMimeTypeSerializer());
        module.addDeserializer(MimeType.class, new ToMimeTypeDeserializer());
        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        mapper.registerModule(module);
        mapper.registerModule(new Jdk8Module()); // support for Optional
        return mapper;
    }

}
