package gov.dhs.uscis.submissionservice.validators.n400;

import java.util.List;

import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.ValidationStatus.ValidationStatusBuilder;
import gov.dhs.uscis.intake.models.validation.FormFieldResult;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.validators.FieldValidator;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;

@Component
@Slf4j
public class BasisOfEligibilityValidator implements FieldValidator {

    private static final String MULTIPLE = "multiple";
    DynamoDbTable<ValidationStatus> validationStatusTable;
    FormService formService;

    public final static String NO_BASIS_DETECTED_MESSAGE = "You did not select a basis for eligibility in **Part 1. Information About Your Eligibility** of the %s.  Please review your form and select a reason for filing to prevent you application from being rejected.";
    public final static String MULTIPLE_BASES_DETECTED_MESSAGE = "There were multiple Bases of Eligibility detected on the form. Please review your selection to prevent your application from being rejected.";
    public final static String MESSAGE = "Basis of Eligibility selected (%s) is different from what is on the form (%s). Please review your selection to prevent your application from being rejected.";
    public final static String BASIS_OF_ELIGIBILITY_MISMATCH = "The basis for eligibility you selected does not match the category you selected in **Part 1. Information About Your Eligibility** of your PDF.\n\nPlease go back to Getting Started, Basis for Eligibility, and select the correct eligibility category.";
    public final static String BASIS_OF_ELIGIBILITY_NOT_SELECTED = "Please specify your basis of eligibility under Getting Started.";

    public BasisOfEligibilityValidator(DynamoDbTable<ValidationStatus> validationStatusTable, FormService formService) {
        this.validationStatusTable = validationStatusTable;
        this.formService = formService;
    }

    @Override
    public void validate(Submission submission, FormFieldResult result) {
        FormFields formFields = FormFields.builder()
                .formId(result.getFormId())
                .eligibilityCategory(extractCategoryFromResult(result))
                .build();

        validate(submission, formFields);
    }

    private String extractCategoryFromResult(FormFieldResult result) {
        List<EligibilityCategoryEnum> selectedCategories = result.getSelectedCategories();
        return selectedCategories.isEmpty() ? null
                : selectedCategories.size() > 1 ? MULTIPLE
                        : selectedCategories.getFirst().getCategory();
    }

    @Override
    public void validate(Submission submission, FormFields formFields) {
        var vBuilder = ValidationStatus
                .builder()
                .submissionId(submission.getSubmissionId())
                .formId(formFields.formId()).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .failureReasons(Lists.newArrayList()).validationWarnings(Maps.newHashMap());

        EligibilityCategoryEnum categoryEnum = (EligibilityCategoryEnum) submission.getEligibilityCategory();

        if (categoryEnum == null)
            vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(BASIS_OF_ELIGIBILITY_NOT_SELECTED));
        else {
            var categoryOnSubmission = categoryEnum.getCategory();
            String categoryOnForm = formFields.eligibilityCategory();
            validateEligibility(vBuilder, categoryOnSubmission, categoryOnForm, submission.getFormType().getType());
        }
        validationStatusTable.putItem(PutItemEnhancedRequest.builder(ValidationStatus.class)
                .item(vBuilder.build())
                .build());
    }

    private void validateEligibility(ValidationStatusBuilder vBuilder, String categoryOnSubmission,
            String categoryOnForm, String formTypeString) {

        switch (categoryOnForm) {
            case null:
                vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(String.format(NO_BASIS_DETECTED_MESSAGE, formTypeString)));
                break;
            case MULTIPLE:
                vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(MULTIPLE_BASES_DETECTED_MESSAGE));
                break;
            default:
                if (categoryOnSubmission.contains(categoryOnForm)) {
                    vBuilder.status(ValidationResultEnum.PASS).build();
                } else {
                    vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(BASIS_OF_ELIGIBILITY_MISMATCH));
                }
        }
    }
}