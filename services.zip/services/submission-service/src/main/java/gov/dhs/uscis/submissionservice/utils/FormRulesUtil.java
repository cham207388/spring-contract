package gov.dhs.uscis.submissionservice.utils;

import gov.dhs.uscis.intake.enums.FormType;

public class FormRulesUtil {

    private FormRulesUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static boolean isOneFormPerApplicant(FormType formType) {
        return FormType.N400.equals(formType) || FormType.I751.equals(formType);
    }
}
