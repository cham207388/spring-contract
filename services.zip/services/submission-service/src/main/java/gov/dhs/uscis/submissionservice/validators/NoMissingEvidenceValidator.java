package gov.dhs.uscis.submissionservice.validators;

import java.util.List;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

@Component
public class NoMissingEvidenceValidator implements ConstraintValidator<NoMissingEvidence, EvidenceRequest> {

    @Override
    public boolean isValid(EvidenceRequest value, ConstraintValidatorContext context) {
        List<String> evidenceFileNames = value.evidences().stream().map(e -> e.fileName()).toList();
        List<String> fileNames = value.files().stream().map(f -> f.getSubmittedFileName())
                            .map(name -> getName(name))
                            .toList();
        return evidenceFileNames.equals(fileNames);
    }

    private String getName(String filename) {
        int lastSlashPosition = filename.lastIndexOf(47);
        int lastBackSlashPosition = filename.lastIndexOf(92);
        int index = Math.max(lastSlashPosition, lastBackSlashPosition);
        return filename.substring(index + 1);
     }
}
