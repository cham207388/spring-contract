package gov.dhs.uscis.submissionservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

import org.springframework.context.annotation.Import;
import gov.dhs.uscis.intake.configs.EligibilityCategoryConfig;
@SpringBootApplication
@Import(EligibilityCategoryConfig.class)
@EnableScheduling
public class SubmissionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubmissionServiceApplication.class, args);
	}
}