package gov.dhs.uscis.submissionservice.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.submissionservice.models.EligibilityCategoryResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.draftBenefits.AbleToFileResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AccountTypeResponse;
import gov.dhs.uscis.submissionservice.services.DraftBenefitsService;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.services.PeepsService;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Tag(name = "Form And Evidence", description = "Form and Evidence Management APIs")
@RestController
@RequestMapping("/api/v1/forms")
@Slf4j
public class FormController {

    private final FormService formService;
    private final DraftBenefitsService draftBenefitsService;
    private final PeepsService peepsService;
    private final SubmissionService submissionService;

    public FormController(FormService formService, DraftBenefitsService draftBenefitsService,
            PeepsService peepsService, SubmissionService submissionService) {
        this.formService = formService;
        this.draftBenefitsService = draftBenefitsService;
        this.peepsService = peepsService;
        this.submissionService = submissionService;
    }

    @GetMapping("{formType}/metadata")
    public ResponseEntity<FormMetaData> retrieveFormMetaData(@PathVariable("formType") String formType) {
        FormMetaData formMetaData = formService.retrieveFormMetaData(formType);
        if (formMetaData != null && formMetaData.getEnabled())
            return ResponseEntity.ok().body(formMetaData);
        else
            return ResponseEntity.notFound().build();

    }

    @GetMapping("{formType}/eligibilityCategories")
    public ResponseEntity<List<EligibilityCategoryResponse>> retrieveEligibilityCategories(
            @PathVariable("formType") String formType) {
        List<EligibilityCategoryResponse> eligibilityCategories = formService.retrieveEligibilityCategories(formType);
        return ResponseEntity.ok().body(eligibilityCategories);
    }

    @GetMapping("{formType}/metadata/{eligibilityCategory}/evidence")
    public ResponseEntity<List<EvidenceGroup>> retrieveEvidenceGroups(@PathVariable("formType") String formType,
            @PathVariable("eligibilityCategory") String eligibilityCategory) {
        List<EvidenceGroup> evidences = formService.retrieveEvidenceGroups(formType, eligibilityCategory);
        if (evidences != null)
            return ResponseEntity.ok().body(evidences);
        else
            return ResponseEntity.notFound().build();
    }

    @GetMapping("{formType}/metadata/{eligibilityCategory}/evidence/{evidenceGroupType}/validations")
    public ResponseEntity<List<MetadataValidationEnum>> retrieveEvidenceGroupValidations(
            @PathVariable("formType") String formType, @PathVariable("eligibilityCategory") String eligibilityCategory,
            @PathVariable("evidenceGroupType") String evidenceGroupType) {
        return ResponseEntity.ok()
                .body(formService.retrieveEvidenceGroupValidations(formType, eligibilityCategory, evidenceGroupType));
    }

    @GetMapping("{formType}/ableToFile/{myUscisId}")
    public ResponseEntity<AbleToFileResponse> retrieveIsAbleToFile(@PathVariable("formType") String formType,
            @PathVariable("myUscisId") String myUscisId) {
        var result = draftBenefitsService.canApplicantFileFor(formType, myUscisId);
        AccountTypeResponse accountType = peepsService.retrieveAccountType(myUscisId);
        try {
            result = result && formService.canClientFile(myUscisId, formType);
        } catch (Exception e) {
            log.error("Failed to find all drafts by Applicant UscisId {}", e);
        }
        
        FormMetaData formMetaData = formService.retrieveFormMetaData(formType);

        if (accountType.accountType().equals(AccountType.REPRESENTATIVE)
                && !formMetaData.getRepresentativeEnabled())
            return ResponseEntity.ok().body(new AbleToFileResponse(false));
        return ResponseEntity.ok().body(new AbleToFileResponse(result));

    }

    @GetMapping("{formType}/concurrentForms")
    public ResponseEntity<List<String>> retrieveConcurrentForms(@PathVariable("formType") String formType) {
        return ResponseEntity.ok().body(formService.retrieveConcurrentForms(formType));
    }
}