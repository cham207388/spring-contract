package gov.dhs.uscis.submissionservice.repository;

import static gov.dhs.uscis.intake.entities.submission.SubmissionState.DRAFT;

import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.exception.SubmissionUpdateException;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.internal.AttributeValues;
import software.amazon.awssdk.enhanced.dynamodb.model.BatchGetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.BatchGetResultPageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.DeleteItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.ReadBatch;
import software.amazon.awssdk.enhanced.dynamodb.model.ReadBatch.Builder;
import software.amazon.awssdk.enhanced.dynamodb.model.ScanEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

@Slf4j
@Component
public class SubmissionRepository {

    private static final String NO_ACCOUNT = "NO-ACCOUNT";
    private final DynamoDbTable<Submission> submissionTable;
    private final ClientInformationRepository clientInformationRepository;
    private final AuditService auditService;
    private final DynamoDbEnhancedClient dynamoDbClient;

    public SubmissionRepository(DynamoDbTable<Submission> submissionTable,
            ClientInformationRepository clientInformationRepository, AuditService auditService,
            DynamoDbEnhancedClient dynamoDbClient) {
        this.submissionTable = submissionTable;
        this.clientInformationRepository = clientInformationRepository;
        this.auditService = auditService;
        this.dynamoDbClient = dynamoDbClient;
    }

    public Submission save(@NonNull Submission submission) {
        submission.setUpdatedAt(ZonedDateTime.now());
        final PutItemEnhancedRequest<Submission> enhancedRequest = PutItemEnhancedRequest
                .builder(Submission.class)
                .item(submission)
                .build();
        submissionTable.putItem(enhancedRequest);
        return finalizeSubmissionRetrieval(Optional.of(submission)).get();
    }

    public List<Submission> findAllDraftsByMyUscisId(String myUscisId) {
        return findAllByMyUscisIdAndStatus(myUscisId, Arrays.asList(DRAFT));
    }

    public List<Submission> findAllByMyUscisIdAndStatus(String myUscisId, List<SubmissionState> statusList) {
    	return findAllByMyUscisIdAndStatus(myUscisId, statusList, false);
    }
    
    public List<Submission> findAllByOrgMyUscisIdAndStatus(String myUscisId, List<SubmissionState> statusList) {
    	return findAllByMyUscisIdAndStatus(myUscisId, statusList, true);
    }
    
    private List<Submission> findAllByMyUscisIdAndStatus(String myUscisId, List<SubmissionState> statusList, boolean orgId) {
        DynamoDbIndex<Submission> myUscisIdIndex = submissionTable.index("requests_by_myUscisId");
        if(orgId) {
        	myUscisIdIndex = submissionTable.index("requests_by_orgMyUscisId");
        }
        QueryConditional queryConditional = QueryConditional.keyEqualTo(
                Key.builder()
                        .partitionValue(myUscisId)
                        .build());

        var statusQueryParametersBuilder = new StringBuilder();
        Map<String, AttributeValue> values = new HashMap<>();
        for (int i = 0; i < statusList.size(); i++) {
            statusQueryParametersBuilder.append(String.format(":status%d,", i));
            values.put(String.format(":status%d", i), AttributeValues.stringValue(statusList.get(i).toString()));
        }
        var statusQueryParameters = statusQueryParametersBuilder.toString();

        SdkIterable<Page<Submission>> queryResults = null;
        if (statusQueryParameters.length() > 0) {
            statusQueryParameters = statusQueryParameters.substring(0, statusQueryParameters.length() - 1);
            var filteredByStatusExpression = Expression.builder()
                    .expression(String.format("#status in (%s)", statusQueryParameters))
                    .expressionNames(java.util.Map.of("#status", "status"))
                    .expressionValues(values).build();
            queryResults = getQuerySubmissionWithFilterByMyUscisId(filteredByStatusExpression,
                    myUscisIdIndex, queryConditional);
        } else {

            queryResults = getQuerySubmissionWithoutFilterByMyUscisId(myUscisIdIndex, queryConditional);
        }

        Stream<Submission> finalList = queryResults.stream()
                .flatMap(page -> page.items().stream())
                .map(item -> finalizeSubmissionRetrieval(Optional.of(item)).get());

        List<ClientInformation> allByClientId = clientInformationRepository.findAllByClientId(myUscisId);

        if (!allByClientId.isEmpty()) {
            Builder<Submission> builder = ReadBatch.builder(Submission.class).mappedTableResource(submissionTable);
            allByClientId
                    .forEach(info -> builder.addGetItem(Key.builder().partitionValue(info.getSubmissionId()).build()));

            BatchGetResultPageIterable getItemResponse = dynamoDbClient
                    .batchGetItem(BatchGetItemEnhancedRequest.builder().addReadBatch(builder.build()).build());
            Stream<Submission> filteredClientSubmissions = getItemResponse.stream()
                    .flatMap(page -> page.resultsForTable(submissionTable).stream())
                    .filter(submission -> statusList.contains(submission.getStatus())
                            && !submission.getStatus().equals(SubmissionState.DRAFT)
                            && !submission.getStatus().equals(SubmissionState.DELETED))
                    .map(submission -> {
                        submission.setClientInformation(allByClientId.stream()
                                .filter(info -> info.getSubmissionId().equals(submission.getSubmissionId()))
                                .findFirst()
                                .orElse(null));
                        if (submission.getEvidences() != null) {
                            submission.getEvidences().stream()
                                    .forEach(evidence -> evidence
                                            .setUrl(evidence.getUrl().replace(submission.getMyUscisId(),
                                                    myUscisId)));
                            submission.getForms().stream()
                                    .forEach(form -> form
                                            .setUrl(form.getUrl().replace(submission.getMyUscisId(), myUscisId)));
                            if (submission.getFeeWaiver() != null) {
                                SubmissionEvidence feeWaiver = submission.getFeeWaiver();
                                feeWaiver.setUrl(feeWaiver.getUrl().replace(submission.getMyUscisId(), myUscisId));
                                submission.setFeeWaiver(feeWaiver);
                            }
                        }
                        submission.setMyUscisId(myUscisId);
                        return submission;
                    });
            return Stream.concat(finalList, filteredClientSubmissions).toList();
        }
        return finalList.toList();
    }

    public List<Submission> findAllByMyUscisIdAndStatuswithApplicant(String applicantMyUscisId,
            List<SubmissionState> statusList) {

        DynamoDbIndex<Submission> myUscisIdIndex = submissionTable.index("requests_by_myUscisId");
        Expression uscisFilter = null;

        var statusQueryParametersBuilder = new StringBuilder();
        Map<String, AttributeValue> valuesForStatus = new HashMap<>();
        for (int i = 0; i < statusList.size(); i++) {
            statusQueryParametersBuilder.append(String.format(":status%d,", i));
            valuesForStatus.put(String.format(":status%d", i),
                    AttributeValues.stringValue(statusList.get(i).toString()));
        }

        // Create the applicantUid search
        Map<String, AttributeValue> valuesForUSCIS = new HashMap<>();

        if (applicantMyUscisId != null) {
            valuesForUSCIS.put(":myUscisId", AttributeValue.builder().s(applicantMyUscisId).build());

            uscisFilter = Expression.builder()
                    .expression("#applicant.#myUscisId = :myUscisId")
                    .expressionNames(Map.of("#applicant", "applicant", "#myUscisId", "myUscisId"))
                    .expressionValues(valuesForUSCIS).build();
        }
        var statusQueryParameters = statusQueryParametersBuilder.toString();

        SdkIterable<Page<Submission>> queryResults = null;
        if (statusQueryParameters.length() > 0) {
            statusQueryParameters = statusQueryParameters.substring(0, statusQueryParameters.length() - 1);
            var filteredByStatusExpression = Expression.builder()
                    .expression(String.format("#status in (%s)", statusQueryParameters))
                    .expressionNames(java.util.Map.of("#status", "status"))
                    .expressionValues(valuesForStatus).build();
            if (uscisFilter != null) {
                filteredByStatusExpression.or(uscisFilter);
            }
            queryResults = getScanSubmissionWithFilterByMyApplicantId(filteredByStatusExpression, myUscisIdIndex);
        } else {
            queryResults = getScanSubmissionWithFilterByMyApplicantId(uscisFilter, myUscisIdIndex);
        }
        return queryResults.stream()
                .flatMap(page -> page.items().stream())
                .toList();
    }

    private SdkIterable<Page<Submission>> getQuerySubmissionWithFilterByMyUscisId(Expression expression,
            DynamoDbIndex<Submission> myUscisIdIndex, QueryConditional queryConditional) {
        return myUscisIdIndex.query(
                QueryEnhancedRequest.builder()
                        .queryConditional(queryConditional)
                        .filterExpression(expression)
                        .build());
    }

    private SdkIterable<Page<Submission>> getQuerySubmissionWithoutFilterByMyUscisId(
            DynamoDbIndex<Submission> myUscisIdIndex,
            QueryConditional queryConditional) {
        return myUscisIdIndex.query(
                QueryEnhancedRequest.builder()
                        .queryConditional(queryConditional)
                        .build());
    }

    private SdkIterable<Page<Submission>> getScanSubmissionWithFilterByMyApplicantId(Expression expression,
            DynamoDbIndex<Submission> myUscisIdIndex) {
        return myUscisIdIndex.scan(
                ScanEnhancedRequest.builder()
                        .filterExpression(expression)
                        .build());
    }

    public Optional<Submission> getById(String id) {
        final GetItemEnhancedRequest request = GetItemEnhancedRequest.builder()
                .key(builder -> builder.partitionValue(id))
                .build();

        Submission submission = submissionTable.getItem(request);
        return finalizeSubmissionRetrieval(Optional.ofNullable(submission));
    }

    public Optional<Submission> getDraftById(String myUscisId, String orgMyUscisId, String submissionId) {
    	String expression = "#status = :status AND myUscisId = :myUscisId";
    	Map<String, AttributeValue> expressionValues = Map.of(":status", AttributeValue.fromS(SubmissionState.DRAFT.name()), ":myUscisId", AttributeValue.fromS(myUscisId));
    	if(StringUtils.isNotEmpty(orgMyUscisId)) {
    		expression = "#status = :status AND (myUscisId = :myUscisId OR orgMyUscisId = :orgMyUscisId)";
    		expressionValues = Map.of(":status", AttributeValue.fromS(SubmissionState.DRAFT.name()), ":myUscisId", AttributeValue.fromS(myUscisId), ":orgMyUscisId", AttributeValue.fromS(orgMyUscisId));
    	}
    	
        PageIterable<Submission> query = submissionTable.query(QueryEnhancedRequest.builder()
                .queryConditional(QueryConditional.keyEqualTo(Key.builder().partitionValue(submissionId).build()))
                .filterExpression(Expression.builder()
                        .expression(expression)
                        .expressionNames(Map.of("#status", "status"))
                        .expressionValues(expressionValues)
                        .build())
                .build());
        return finalizeSubmissionRetrieval(query.items().stream().findFirst());
    }
    
    public Optional<Submission> getByManifestId(String manifestId) {
        DynamoDbIndex<Submission> index = submissionTable.index("requests_by_manifestId");
        Key key = Key.builder().partitionValue(manifestId.toLowerCase()).build();
        SdkIterable<Page<Submission>> query = index
                .query(builder -> builder.queryConditional(QueryConditional.keyEqualTo(key)));
        return finalizeSubmissionRetrieval(query.stream().flatMap(page -> page.items().stream()).findFirst());
    }

    public Submission update(@NonNull Submission submission) {
        submission.setUpdatedAt(ZonedDateTime.now());
        final UpdateItemEnhancedRequest<Submission> enhancedRequest = UpdateItemEnhancedRequest
                .builder(Submission.class)
                .item(submission)
                .build();
        try {
            Submission updatedSubmission = submissionTable.updateItem(enhancedRequest);
            auditService.addEvent(submission.getMyUscisId() == null ? NO_ACCOUNT : submission.getMyUscisId(),
                    submission.getSubmissionId(),
                    ActionPerformed.SUBMISSION_UPDATED, null);
            return finalizeSubmissionRetrieval(Optional.of(updatedSubmission)).get();
        } catch (Exception ex) {
            log.error("Exception encountered during updateItem for Submission with id {} with Exception {}",
                    submission.getSubmissionId(), ex.getMessage());
            throw new SubmissionUpdateException(ex.getMessage());
        }
    }

    public Submission updateSubmissionLock(@NonNull Submission submission) {
        submission.setLockedAt(ZonedDateTime.now());
        final UpdateItemEnhancedRequest<Submission> enhancedRequest = UpdateItemEnhancedRequest
                .builder(Submission.class)
                .item(submission)
                .build();
        try {
            return submissionTable.updateItem(enhancedRequest);
        } catch (Exception ex) {
            log.error("Exception encountered during updateItem for Submission with id {} with Exception {}",
                    submission.getSubmissionId(), ex.getMessage());
            throw new SubmissionUpdateException(ex.getMessage());
        }
    }

    public void deleteById(@NonNull String submissionId) {
        DeleteItemEnhancedRequest deleteRequest = DeleteItemEnhancedRequest.builder()
                .key(builder -> builder.partitionValue(submissionId)).build();
        submissionTable.deleteItem(deleteRequest);
    }

    public Optional<Submission> findBySubmissionIdAndUscisId(String submissionId, String myUscisId, String orgMyUscisId) {
    	String expression = "myUscisId = :id";
    	Map<String, AttributeValue> expressionValues = Map.of(":id", AttributeValue.fromS(myUscisId));
    	if(StringUtils.isNotEmpty(orgMyUscisId)) {
    		expression = "myUscisId = :id OR orgMyUscisId = :orgMyUscisId";
    		expressionValues = Map.of(":id", AttributeValue.fromS(myUscisId), ":orgMyUscisId", AttributeValue.fromS(orgMyUscisId));
    	}
    	
        PageIterable<Submission> query = submissionTable.query(QueryEnhancedRequest.builder()
                .queryConditional(QueryConditional.keyEqualTo(Key.builder().partitionValue(submissionId).build()))
                .filterExpression(Expression.builder()
                        .expression(expression)
                        .expressionValues(expressionValues)
                        .build())
                .build());

        return finalizeSubmissionRetrieval(query.items().stream().findFirst());
    }

    private Optional<Submission> finalizeSubmissionRetrieval(Optional<Submission> submission){
    	submission = enrichWithClientInformation(submission);
    	submission = initializeFormObjectsWhenNull(submission);
    	return submission;
    }
    
    private Optional<Submission> enrichWithClientInformation(Optional<Submission> submission) {
        if (submission.isPresent()) {
            boolean applicantIsSet = submission.get().getApplicant() != null
                    && submission.get().getApplicant().getAccountType() != null;
            if (applicantIsSet ? submission.get().getApplicant().getAccountType() == AccountType.REPRESENTATIVE
                    : false) {
                var clientInformation = clientInformationRepository
                        .findBySubmissionId(submission.get().getSubmissionId());
                submission.get().setClientInformation(clientInformation);
            }
        }
        return submission;
    }
    
    private Optional<Submission> initializeFormObjectsWhenNull(Optional<Submission> submission){
    	if(submission.isPresent()) {
	    	if(submission.get().getForms() == null) {
	    		submission.get().setForms(List.of());
	        }
	        if(submission.get().getForms().stream().noneMatch(form -> form.getType().equals(submission.get().getFormType().getType()))){
	        	submission.get().setForms(List.of(
	        			SubmissionForm.builder()
	        				.id(UUID.randomUUID().toString())
	        				.type(submission.get().getFormType().getType())
	        				.build()));
	        	final UpdateItemEnhancedRequest<Submission> enhancedRequest = UpdateItemEnhancedRequest
	                    .builder(Submission.class)
	                    .item(submission.get())
	                    .build();
	        	submissionTable.updateItem(enhancedRequest);
	        }
    	}
    	return submission;
    }

}
