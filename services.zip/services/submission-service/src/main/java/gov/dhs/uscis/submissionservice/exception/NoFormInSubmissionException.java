package gov.dhs.uscis.submissionservice.exception;

public class NoFormInSubmissionException extends RuntimeException {

    public NoFormInSubmissionException(String errorMessage) {
        super(String.format("%s", errorMessage));
    }
}
