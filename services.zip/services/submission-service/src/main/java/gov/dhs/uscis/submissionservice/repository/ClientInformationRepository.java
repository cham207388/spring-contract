package gov.dhs.uscis.submissionservice.repository;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.models.core.Name;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;

@Slf4j
@Component
@AllArgsConstructor
public class ClientInformationRepository {

    private final DynamoDbTable<ClientInformation> clientInformationTable;
    private Logger logger = LoggerFactory.getLogger(ClientInformationRepository.class);

    public ClientInformationRepository(DynamoDbTable<ClientInformation> clientInformationTable) {
        this.clientInformationTable = clientInformationTable;
    }

    public ClientInformation save(String attorneyId, String clientId, String submissionId, Name name,
            List<String> userGroupIds) {
        var clientInformation = ClientInformation.builder()
                .clientId(clientId)
                .attorneyId(attorneyId)
                .submissionId(submissionId)
                .name(name)
                .userGroupIds(userGroupIds)
                .build();

        return this.save(clientInformation);
    }

    public ClientInformation save(ClientInformation clientInformation) {
        if (clientInformation.getUserGroupIds() == null) {
            clientInformation.setUserGroupIds(List.of());
        }
        logger.info("Saving Attorney Association {} {} {} with {} userGroup id(s)",
                clientInformation.getAttorneyId(),
                clientInformation.getClientId(),
                clientInformation.getSubmissionId(),
                clientInformation.getUserGroupIds());
        final PutItemEnhancedRequest<ClientInformation> enhancedRequest = PutItemEnhancedRequest
                .builder(ClientInformation.class)
                .item(clientInformation)
                .build();
        clientInformationTable.putItem(enhancedRequest);
        logger.info("Completed saving new client information to repository {}", clientInformation);
        return clientInformation;
    }

    public ClientInformation findBySubmissionId(String submissionId) {
        var request = GetItemEnhancedRequest.builder().key(builder -> builder.partitionValue(submissionId)).build();
        var clientInformation = clientInformationTable.getItem(request);
        logger.info("Retrieving client information for submission id {}", submissionId);
        return clientInformation;
    }

    public List<ClientInformation> findAllByClientId(String clientId) {
        DynamoDbIndex<ClientInformation> index = clientInformationTable.index("by_clientId");
        
        SdkIterable<Page<ClientInformation>> result = index.query(QueryConditional.keyEqualTo(Key.builder().partitionValue(clientId).build()));

        return result.stream().flatMap(page -> page.items().stream()).toList();
    }

    public void delete(ClientInformation clientInformation) {
        clientInformationTable.deleteItem(clientInformation);
        logger.info("Completed deleting client information to repository {}", clientInformation.getSubmissionId());
    }

}
