package gov.dhs.uscis.submissionservice.configs;

import java.net.URI;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

import com.amazon.sqs.javamessaging.ProviderConfiguration;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazon.sqs.javamessaging.SQSSession;

import gov.dhs.uscis.submissionservice.components.ElisEvidenceValidationResponseListener;
import gov.dhs.uscis.submissionservice.components.MockElisEvidenceValidationListener;
import gov.dhs.uscis.submissionservice.components.ElisValidationResponseListener;
import gov.dhs.uscis.submissionservice.components.MockElisEsignValidationListener;
import gov.dhs.uscis.submissionservice.components.MockElisValidationListener;
import gov.dhs.uscis.submissionservice.components.ReplaySubmissionResponseListener;
import jakarta.jms.ConnectionFactory;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.sqs.SqsClient;

@Configuration
public class AWSConfig {
    @Value("${uscis.s3.endpoint}")
    private String s3Endpoint;

    @Value("${uscis.sqs.endpoint}")
    private String sqsEndpoint;

    @Value("${uscis.sqs.validation.elisResponse.queueUrl}")
    private String elisResponseQueueName;
    
    @Value("${uscis.sqs.evidence.validation.elisResponse.queueUrl}")
    private String elisEvidenceResponseQueueName;

    @Value("${uscis.sqs.validation.elisRequest.queueUrl}")
    private String elisRequestQueueName;

    @Value("${uscis.sqs.evidence.validation.elisRequest.queueUrl}")
    private String evidenceValidationRequestQueueUrl;
    
    @Value(value = "${uscis.sqs.validation.submission.queueUrl}")
    private String replaySubmissionQueueName;

    @Value(value = "${uscis.sqs.esign.elisRequest.queueUrl}")
    private String esignRequestQueueUrl;

    @Bean
    public S3Client getS3Client() {
        return S3Client.builder()
                .region(Region.US_EAST_1)
                .endpointOverride(URI.create(s3Endpoint))
                .forcePathStyle(true)
                .build();
    }

    @Bean
    public SqsClient sqsClient() {
        return SqsClient.builder()
                .region(Region.US_EAST_1)
                .endpointOverride(URI.create(sqsEndpoint))
                .build();
    }

    @Bean
    public DefaultMessageListenerContainer elisValidationResponseListenerContainer(@Qualifier("sqsConnection") ConnectionFactory connectionFactory, ElisValidationResponseListener elisValidationResponseListener) {
        DefaultMessageListenerContainer listenerContainer = new DefaultMessageListenerContainer();
        listenerContainer.setConnectionFactory(connectionFactory);
        listenerContainer.setDestinationName(elisResponseQueueName);
        listenerContainer.setMessageListener(elisValidationResponseListener);
        listenerContainer.setSessionAcknowledgeMode(SQSSession.UNORDERED_ACKNOWLEDGE);
        return listenerContainer;
    }
    
    @Bean
    public DefaultMessageListenerContainer elisEvidenceValidationResponseListenerContainer(@Qualifier("sqsConnection") ConnectionFactory connectionFactory, ElisEvidenceValidationResponseListener elisEvidenceValidationResponseListener) {
        DefaultMessageListenerContainer listenerContainer = new DefaultMessageListenerContainer();
        listenerContainer.setConnectionFactory(connectionFactory);
        listenerContainer.setDestinationName(elisEvidenceResponseQueueName);
        listenerContainer.setMessageListener(elisEvidenceValidationResponseListener);
        listenerContainer.setSessionAcknowledgeMode(SQSSession.UNORDERED_ACKNOWLEDGE);
        return listenerContainer;
    }

    @Bean
    @Profile("mock_elis")
    public DefaultMessageListenerContainer mockElisValidationListenerContainer(@Qualifier("sqsConnection") ConnectionFactory connectionFactory, MockElisValidationListener elisValidationListener) {
        DefaultMessageListenerContainer listenerContainer = new DefaultMessageListenerContainer();
        String[] queueParts = elisRequestQueueName.split("/");
        listenerContainer.setConnectionFactory(connectionFactory);
        listenerContainer.setDestinationName(queueParts[queueParts.length-1]);
        listenerContainer.setMessageListener(elisValidationListener);
        listenerContainer.setSessionAcknowledgeMode(SQSSession.UNORDERED_ACKNOWLEDGE);
        return listenerContainer;
    }

    @Bean
    @Profile("mock_elis")
    public DefaultMessageListenerContainer mockEsignValidationListener(@Qualifier("sqsConnection") ConnectionFactory connectionFactory, MockElisEsignValidationListener elisEsignValidationListener) {
        DefaultMessageListenerContainer listenerContainer = new DefaultMessageListenerContainer();
        String[] queueParts = esignRequestQueueUrl.split("/");
        listenerContainer.setConnectionFactory(connectionFactory);
        listenerContainer.setDestinationName(queueParts[queueParts.length-1]);
        listenerContainer.setMessageListener(elisEsignValidationListener);
        listenerContainer.setSessionAcknowledgeMode(SQSSession.UNORDERED_ACKNOWLEDGE);
        return listenerContainer;
    }

    @Bean
    @Profile("mock_elis")
    public DefaultMessageListenerContainer mockElisEvidenceValidationListenerContainer(@Qualifier("sqsConnection") ConnectionFactory connectionFactory, MockElisEvidenceValidationListener elisEvidenceValidationResponseListener) {
        DefaultMessageListenerContainer listenerContainer = new DefaultMessageListenerContainer();
        String[] queueParts = evidenceValidationRequestQueueUrl.split("/");
        listenerContainer.setConnectionFactory(connectionFactory);
        listenerContainer.setDestinationName(queueParts[queueParts.length-1]);
        listenerContainer.setMessageListener(elisEvidenceValidationResponseListener);
        listenerContainer.setSessionAcknowledgeMode(SQSSession.UNORDERED_ACKNOWLEDGE);
        return listenerContainer;
    }


    
    @Bean
    public DefaultMessageListenerContainer retrySubmissionListenerContainer(@Qualifier("sqsConnection") ConnectionFactory connectionFactory, ReplaySubmissionResponseListener replayListener) {
    	DefaultMessageListenerContainer listenerContainer = new DefaultMessageListenerContainer();
        listenerContainer.setConnectionFactory(connectionFactory);
        listenerContainer.setDestinationName(replaySubmissionQueueName);
        listenerContainer.setMessageListener(replayListener);
        listenerContainer.setSessionAcknowledgeMode(SQSSession.UNORDERED_ACKNOWLEDGE);
        return listenerContainer;
    }

    @Bean(name = "sqsConnection")
    public SQSConnectionFactory sqsConnectionFactory(SqsClient sqsClient){
        return new SQSConnectionFactory(new ProviderConfiguration(), sqsClient);
    }
}
