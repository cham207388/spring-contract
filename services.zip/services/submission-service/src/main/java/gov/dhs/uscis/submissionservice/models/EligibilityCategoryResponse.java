package gov.dhs.uscis.submissionservice.models;


public record EligibilityCategoryResponse(String category, boolean feeWaivable, boolean feeExemptable) {

}