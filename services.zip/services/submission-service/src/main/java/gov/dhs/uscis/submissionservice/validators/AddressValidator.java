package gov.dhs.uscis.submissionservice.validators;

import java.util.Collections;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.ValidationStatus.ValidationStatusBuilder;
import gov.dhs.uscis.intake.models.validation.address_extract.AddressValidationResult;
import gov.dhs.uscis.intake.models.validation.address_extract.ClientAddress;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AddressValidator {
    private ValidationStatusRepository statusRepository;

    public static final String DEFAULT_FAILURE_MESSAGE = "Unable to submit form. Client address on form does not match address on G-28.";
    public static final String INCOMPLETE_FAILURE_MESSAGE = "Unable to submit form. Client address on the Form %s is not complete. Please correct and upload to continue.";

    public AddressValidator(ValidationStatusRepository statusDAO) {
        this.statusRepository = statusDAO;
    }

    public void validate(AddressValidationResult result) {
        FormType formType = FormType.fromString(result.getFormType());
        String formId = result.getFormId();
        String submissionId = result.getSubmissionId();
        ClientAddress clientAddress = result.getClientAddress();
        ValidationStatusBuilder statusBuilder = ValidationStatus.builder()
                .submissionId(submissionId)
                .formId(formId)
                .validator(ValidatorEnum.G28_COMP);

        if (clientAddress == null || clientAddress.hasMissingAddressPart()) {
            statusBuilder
                    .status(ValidationResultEnum.FAIL)
                    .failureReasons(Collections.singletonList(String.format(INCOMPLETE_FAILURE_MESSAGE, formType.getType())));
        } else {
            statusBuilder
                    .status(ValidationResultEnum.PASS)
                    .failureReasons(Collections.emptyList());
        }

        statusRepository.save(statusBuilder.build());
    }
}