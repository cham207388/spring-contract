package gov.dhs.uscis.submissionservice.exception;

import gov.dhs.uscis.intake.enums.FormType;

public class FeeHandlerNotFoundException extends RuntimeException{
 public FeeHandlerNotFoundException(FormType formType) {
  super(String.format("Fee handler for form %s not found.", formType));
 }
}
