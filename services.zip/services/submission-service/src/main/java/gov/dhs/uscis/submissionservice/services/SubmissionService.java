package gov.dhs.uscis.submissionservice.services;

import static gov.dhs.uscis.intake.entities.submission.SubmissionState.REJECTED;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.apache.commons.lang3.StringUtils.isBlank;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;

import gov.dhs.uscis.intake.clients.AccountsDataClient;
import gov.dhs.uscis.intake.clients.UserGroupServiceClient;
import gov.dhs.uscis.intake.constants.DocumentType;
import gov.dhs.uscis.intake.constants.FeeWaiverErrors;
import gov.dhs.uscis.intake.constants.S3Constants;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.FormTypeDescription;
import gov.dhs.uscis.intake.enums.I130EligibilityCategory;
import gov.dhs.uscis.intake.enums.I131EligibilityCategory;
import gov.dhs.uscis.intake.enums.I140EligibilityCategory;
import gov.dhs.uscis.intake.enums.I751EligibilityCategory;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.N400EligibilityCategory;
import gov.dhs.uscis.intake.enums.PFVSEvidenceType;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import gov.dhs.uscis.intake.enums.ResidencyStatus;
import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I751WaiverOrIndividualFilingSubcategory;
import gov.dhs.uscis.intake.exceptions.S3DeleteObjectException;
import gov.dhs.uscis.intake.models.ConcurrentForm;
import gov.dhs.uscis.intake.models.EntityType;
import gov.dhs.uscis.intake.models.EsignData;
import gov.dhs.uscis.intake.models.EsignRequest;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.FinalTransmissionStatus;
import gov.dhs.uscis.intake.models.LockboxStatuses;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest.ManifestUpdate;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest.SubmissionUpdate;
import gov.dhs.uscis.intake.models.ValidationRequest;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.WatermarkerStatus;
import gov.dhs.uscis.intake.models.additionalinformation.AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.ETA9089AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I912AdditionalInformation;
import gov.dhs.uscis.intake.models.core.ClientAssociation;
import gov.dhs.uscis.intake.models.dto.C9Options;
import gov.dhs.uscis.intake.models.dto.C9UpdateRequest;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.intake.models.myuscis.Admin;
import gov.dhs.uscis.intake.models.submission.ExtractedFormEntries;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I130FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I140FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I765FormSpecificInfo;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;
import gov.dhs.uscis.intake.monitoring.LogContext;
import gov.dhs.uscis.intake.monitoring.SubmissionStateChange;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.intake.services.SystemClockService;
import gov.dhs.uscis.intake.util.LockboxTransmissionUtil;
import gov.dhs.uscis.intake.util.MapEvidenceTypes;
import gov.dhs.uscis.intake.util.SubmissionUtils;
import gov.dhs.uscis.submissionservice.exception.SubmissionBadException;
import gov.dhs.uscis.submissionservice.exception.SubmissionDeleteException;
import gov.dhs.uscis.submissionservice.exception.SubmissionIndexException;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;
import gov.dhs.uscis.submissionservice.models.dto.EligibilityUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import gov.dhs.uscis.submissionservice.models.dto.S3FileInfo;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AccountTypeResponse;
import gov.dhs.uscis.submissionservice.models.submissionStatus.ErrorGroup;
import gov.dhs.uscis.submissionservice.models.submissionStatus.SubmissionStatusResponse;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.repository.ClientInformationRepository;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.services.fees.FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765C11FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765C9FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765Fees;
import gov.dhs.uscis.submissionservice.services.fees.strategies.n400.N400Fees;
import gov.dhs.uscis.submissionservice.validators.FieldValidator;
import gov.dhs.uscis.submissionservice.validators.i765.ReasonForFilingValidator;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.services.sns.model.InvalidStateException;
import software.amazon.awssdk.utils.StringUtils;

@Slf4j
@Service
public class SubmissionService {

    public static final String FEE_WAIVER_EVIDENCE_GROUP = "feeWaiver";
    private final ReasonForFilingValidator reasonForFilingValidator;

    @Value("${uscis.downloader.baseUrl}")
    private String downloaderBaseUrl;

    private final S3Service s3Service;
    private final FeeService feeService;
    private final AuditService auditService;
    private final FormService formService;
    private final ValidationService validationService;
    private final SubmissionRepository submissionDao;
    private final Function<String, String> uuid;
    private final SystemClockService systemClock;
    private final PaymentServiceClient paymentServiceClient;

    private final SqsService sqsService;

    private LockboxGatewayClient lockboxGatewayClient;

    private EligibilityCategoryValidatorFactory categoryValidatorFactory;

    private ClientInformationRepository clientInformationRepository;

    private MyUscisCacheManagementClient myUscisCacheManagementClient;

    private UserGroupServiceClient userGroupServiceClient;

    private PeepsService peepsService;

    private AccountsDataClient accountsDataClient;

    private ToggleService toggleService;

    private static final Set<I751WaiverOrIndividualFilingSubcategory> GROUP_A = EnumSet.of(I751WaiverOrIndividualFilingSubcategory.SPOUSE_DECEASED, I751WaiverOrIndividualFilingSubcategory.DIVORCE_ANNULMENT, I751WaiverOrIndividualFilingSubcategory.GOOD_FAITH_SPOUSE_EXTREME_CRUELTY);
    private static final Set<I751WaiverOrIndividualFilingSubcategory> GROUP_B = EnumSet.of(I751WaiverOrIndividualFilingSubcategory.PARENT_GOOD_FAITH_EXTREME_CRUELTY);

    private static final Set<String> I129_VARIANTS = Set.of(
        FormType.I129R.getType(),
        FormType.I129TN.getType(),
        FormType.I129E3.getType(),
        FormType.I129H3.getType(),
        FormType.I129OP.getType(),
        FormType.I129Q.getType()
    );

    public SubmissionService(SubmissionRepository submissionDao, S3Service s3Service,
            FeeService feeService, AuditService auditService, Function<String, String> uuid, FormService formService,
            ValidationService validationService,
            LockboxGatewayClient lockboxGatewayClient, SystemClockService systemClock,
            PaymentServiceClient paymentServiceClient, SqsService sqsService,
            DraftBenefitsService draftBenefitsService, EligibilityCategoryValidatorFactory categoryValidatorFactory,
            ReasonForFilingValidator reasonForFilingValidator,
            ClientInformationRepository clientInformationRepository,
            MyUscisCacheManagementClient myUscisCacheManagementClient,
            UserGroupServiceClient userGroupServiceClient,
            PeepsService peepsService,
            AccountsDataClient accountsDataClient,
            ToggleService toggleService
        ) {
        this.submissionDao = submissionDao;
        this.lockboxGatewayClient = lockboxGatewayClient;
        this.paymentServiceClient = paymentServiceClient;
        this.s3Service = s3Service;
        this.uuid = uuid;
        this.feeService = feeService;
        this.auditService = auditService;
        this.formService = formService;
        this.validationService = validationService;
        this.systemClock = systemClock;
        this.sqsService = sqsService;
        this.categoryValidatorFactory = categoryValidatorFactory;
        this.clientInformationRepository = clientInformationRepository;
        this.myUscisCacheManagementClient = myUscisCacheManagementClient;
        this.userGroupServiceClient = userGroupServiceClient;
        this.reasonForFilingValidator = reasonForFilingValidator;
        this.peepsService = peepsService;
        this.accountsDataClient = accountsDataClient;
        this.toggleService = toggleService;
    }

    public final Submission retrieveSubmission(String submissionId) {
        return submissionDao.getById(submissionId)
                .orElseThrow(
                        () -> new NoSuchElementException(String.format("Submission Not Found: %s", submissionId)));
    }

    public final Submission retrieveSubmissionByIdAndUscisId(String submissionId, String myUscisId, String orgMyUscisId) {
        return submissionDao.findBySubmissionIdAndUscisId(submissionId, myUscisId, orgMyUscisId)
                .orElseThrow(
                        () -> new NoSuchElementException(
                                String.format("Submission %s Not Found for user %s", submissionId, myUscisId)));
    }

    public final Submission retrieveDraftSubmission(String myUscisId, String orgMyUscisId, String submissionId) {
        var updated = false;
        Submission draft = submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)
                .orElseThrow(
                        () -> new NoSuchElementException(
                                String.format("Draft Submission %s Not Found for user %s)", submissionId,
                                        myUscisId)));

        SubmissionEvidence feeWaiver = draft.getFeeWaiver();
        if (feeWaiver != null && !s3Service.checkIfFileExists(feeWaiver.getS3Key(), false)) {
            processFeeWaiverAndSupportDocsDelete(draft);
            draft.setUserRequestedFeeWaiver(false);
            updated = true;
        }

        if (draft.getEvidences() != null) {
            List<SubmissionEvidence> filteredEvidence = draft.getEvidences().parallelStream()
                    .filter(evidence -> s3Service.checkIfFileExists(evidence.getS3Key(), false))
                    .collect(Collectors.toList());

            if (filteredEvidence.size() != draft.getEvidences().size()) {
                draft.setEvidences(filteredEvidence);
                updated = true;
            }
        }

        if (draft.getUserRequestedPartialFeeWaiver() == null) {
            draft.setUserRequestedPartialFeeWaiver(false);
            updated = true;
        }

        return updated ? submissionDao.update(draft) : draft;
    }

    public final Submission updateDraftSubmissionLock(Submission submission) {
        return submissionDao.updateSubmissionLock(submission);
    }

    public Submission updateUserRequestedFeeWaiver(String myUscisId, String orgMyUscisId, String submissionId,
            boolean userRequestedFeeWaiver) {

        Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        submission.setUserRequestedFeeWaiver(userRequestedFeeWaiver);
        resetAttestationFields(submission);

        if (!userRequestedFeeWaiver) {
            updateFeeTotalOnRequestedFeeWaiverChange(submission);
            log.info("Checking if fee waiver goes through PFVS for {} - {}", submission.getFormType().getType(), toggleService.isToggleActive(PFVSEvidenceType.I912.getToggle(), submission.getFormType().getType()));
            if(toggleService.isToggleActive(PFVSEvidenceType.I912.getToggle(), submission.getFormType().getType())) {
            	Optional<SubmissionForm> primaryForm = submission.getForms().stream().filter(form -> submission.getFormType().equals(form.getType())).findFirst();
    			if(primaryForm.isPresent()) {
    				validationService.deleteStatus(primaryForm.get().getId());
        			log.info("Fee waiver deleted. Resending uploaded submission of type {} to validation service for fee recalculation", primaryForm.get().getType());
        			sendPFVSValidationRequest(submission, primaryForm.get().getId(), primaryForm.get().getS3Key());
    			}
            }
        } else if (submission.getFormType() == FormType.I765) {
            BigDecimal feeTotal = calculateTotalFee(submission, false);
            submission.setFeeTotal(feeTotal);
        }

        log.info("Updated fee waiver request to {}", userRequestedFeeWaiver);
        auditService.addEvent(submission.getMyUscisId(), submission.getSubmissionId(),
                ActionPerformed.FEE_WAIVER_REQUESTED, Boolean.toString(userRequestedFeeWaiver));

        return submissionDao.update(submission);
    }

    public Submission updateUserRequestedPartialFeeWaiver(String myUscisId, String orgMyUscisId, String submissionId,
            boolean userRequestedPartialFeeWaiver) {

        Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        boolean feeWaiverEnabled = Boolean.TRUE.equals(formService.isFeeWaiverEnabled(submission.getFormType()));

        if (!FormType.N400.equals(submission.getFormType()) || !feeWaiverEnabled) {
            throw new SubmissionBadException("Partial fee waiver unsupported");
        }

        submission.setUserRequestedPartialFeeWaiver(userRequestedPartialFeeWaiver);

        if (userRequestedPartialFeeWaiver) {
            // Changing from full fee waiver to partial, remove I-912 and other evidence
            submission.setFeeTotal(N400Fees.PARTIAL_FEE);
            processFeeWaiverDelete(submission);
            processSupportDocsDelete(submission);
        } else {
            // Changing from partial fee waiver to full, remove evidence, and reset the fee
            // until they upload new I-912
            submission.setFeeTotal(N400Fees.FULL_FEE);
            processSupportDocsDelete(submission);
        }

        resetAttestationFields(submission);

        return submissionDao.update(submission);
    }

    public final Submission updateSubmissionWithForm(Submission submission, UploadRequest request,
            MultipartFile file) throws IOException {

    	String formId = UUID.randomUUID().toString();
        boolean fileRemoved = false;
           // 1. BACKUP ORIGINAL STATE (Shallow copies of the lists)
    final List<SubmissionForm> originalForms = new ArrayList<>(submission.getForms());
    final List<SubmissionEvidence> originalEvidences = submission.getEvidences() != null
            ? submission.getEvidences().stream()
                .<SubmissionEvidence>map(ev -> ev.toBuilder().build())
                .toList() // Deep copy via Lombok builder
            : null;
        SubmissionForm existingForm = submission.getForms().stream()
                .filter(form -> form.getType().equals(request.formType())).findFirst()
                .orElseGet(() -> createMissingForm(submission, request.formType(), formId));

        fileRemoved = removeExistingFormsOfSameType(submission, request.formType());
        Submission updated = submissionDao.update(submission);
        S3FileInfo s3FileInfo = null;
       try {
    	 s3FileInfo = s3Service.uploadForm(submission, formId, file, request);
        Map<String, String> data = Map.of("formId", formId, "SubmissionId", submission.getSubmissionId());

        try(LogContext ctx = LogContext.putAll(data)) {
            log.info("Updating submission for form");
        }

        log.info("Form id: {} from S3 service upload response for submissionId: {}", formId, submission.getSubmissionId());
        log.info("Updating submission for form Id: {} for submissionId: {}", formId, submission.getSubmissionId());

        final List<SubmissionForm> forms = submission.getForms() != null ? submission.getForms() : new ArrayList<>();
        log.info("building SubmissionForm with form id {} and s3 key {}", s3FileInfo.id(), s3FileInfo.s3Key());
    	forms.add(SubmissionForm.builder()
                .id(s3FileInfo.id())
                .type(request.formType())
                .clientId(existingForm.getClientId())
                .eligibilityCategory(existingForm.getEligibilityCategory())
                .eligibilitySubcategory(existingForm.getEligibilitySubcategory())
                .eligibilitySubcategoryList(existingForm.getEligibilitySubcategoryList())
                .benefitTypeCode(existingForm.getBenefitTypeCode())
                .applicationReasonCode(existingForm.getApplicationReasonCode())
                .name(request.fileName())
                .s3Key(s3FileInfo.s3Key())
                .url(String.format("%s/%s", downloaderBaseUrl, s3FileInfo.s3Key()))
                .md5Hash(s3FileInfo.checksum())
                .formSpecificInfo(existingForm.getFormSpecificInfo())
                .uploadedAt(systemClock.getSystemTime())
                .build());

    	if(updated.getEvidences() != null) {
    		updated.getEvidences()
    			.stream().filter(ev -> (existingForm.getId().equals(ev.getFormId())))
    			.forEach(ev -> {
    				ev.setFormId(formId);
    			});
    	}


        updated.setForms(forms);
         updated = submissionDao.update(updated);
                if (submission.getFormType() != null && toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, updated.getFormType().getType())) {
            log.info("Sending uploaded submission of type {} to validation service", request.formType());
            sendPFVSValidationRequest(updated, s3FileInfo.id(), s3FileInfo.s3Key());
        }
        return updated;
    } catch (Exception e) {
                log.error("Process failed.", e);

        submission.setForms(originalForms);
        if (originalEvidences != null) {
            // Restore evidence list and their internal IDs
            submission.setEvidences(originalEvidences);
        }
        throw e; // Rethrow to notify the user/system
    }
    }

    private SubmissionForm createMissingForm(Submission submission, String formType, String formId) {
        List<SubmissionForm> forms = new ArrayList<>(submission.getForms());
        SubmissionForm newForm = SubmissionForm.builder()
                .type(formType)
            	.id(formId != null ? formId : UUID.randomUUID().toString())
            	.build();

        forms.add(newForm);
        submission.setForms(forms);
        return newForm;
    }

    private boolean removeExistingFormsOfSameType(Submission submission, String formType) {
        boolean fileRemoved = false;
        String fileRemovedString;
        List<SubmissionForm> submissionForms = submission.getForms();
        if (submissionForms == null || submissionForms.isEmpty()) {
            return fileRemoved;
        }

        List<SubmissionForm> filteredSubmissionForms = new ArrayList<SubmissionForm>();
        for( SubmissionForm submissionForm : submissionForms ){
            if(formType.equals(submissionForm.getType())) {
            	if(submissionForm.getS3Key() != null) {
            	fileRemovedString = 	s3Service.deleteS3Object(submissionForm.getS3Key(), false);
                if ((S3Constants.DELETION_SUCCESS_MESSAGE).equals(fileRemovedString)) {
                    fileRemoved = true;
                }
            	}
            } else {
                filteredSubmissionForms.add(submissionForm);
            }
        }
        submission.setForms(filteredSubmissionForms);
        return fileRemoved;
    }


    public Submission updateSubmissionWithEvidence(String myUscisId, String orgMyUscisId, String submissionId, String formId,
            UploadEvidenceRequest request,
            S3FileInfo s3FileInfo,
            String selectedFormType) {
        log.info("building SubmissionEvidence with form id {} and s3 key {}", s3FileInfo.id(), s3FileInfo.s3Key());
        final SubmissionEvidence newEvidence = SubmissionEvidence.builder()
                .id(s3FileInfo.id())
                .name(request.fileName())
                .type(request.type())
                .evidenceGroupType(request.evidenceGroupType())
                .s3Key(s3FileInfo.s3Key())
                .url(String.format("%s/evidence/%s", downloaderBaseUrl, s3FileInfo.s3Key()))
                .md5Hash(s3FileInfo.checksum())
                .uploadedAt(systemClock.getSystemTime())
                .formId(formId)
                .build();

        final Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

        final List<SubmissionEvidence> submissionEvidences = submission.getEvidences() != null
                ? submission.getEvidences()
                : new ArrayList<>();

        buildAndSendEvidencePFVSRequest(submission, selectedFormType, request, newEvidence);

        submissionEvidences.add(newEvidence);
        submission.setEvidences(submissionEvidences);
        submissionDao.update(submission);
        return submission;
    }
    private void buildAndSendEvidencePFVSRequest(Submission submission, String selectedFormType, UploadEvidenceRequest request, SubmissionEvidence newEvidence) {
        log.info("Building PFVS evidence validation request for submissionId: {}, form: {}, evidenceGroupType: {}",
            submission.getSubmissionId(), selectedFormType, request.evidenceGroupType());

        String eligibilityCategory = submission.getForms().stream()
                .filter(form -> form.getType().equals(selectedFormType))
                .findFirst()
                .map(form -> form.getEligibilityCategory().getCategory())
                .orElse(null);

        if (eligibilityCategory == null || request.evidenceGroupType().equals(FEE_WAIVER_EVIDENCE_GROUP)) {
            log.warn("Skipping PFVS request: eligibilityCategory is null or request is FEE_WAIVER_EVIDENCE_GROUP");
            return;
        }

        EvidenceGroup evidenceGroup = formService.retrieveEvidenceGroup(selectedFormType, eligibilityCategory,
                request.evidenceGroupType());

        if (evidenceGroup == null) {
            log.error("Failed to retrieve evidence group for form: {}, category: {}, type: {}",
                selectedFormType, eligibilityCategory, request.evidenceGroupType());
            return;
        }

        boolean sendEvidenceToPFVS = false;
        PFVSEvidenceType evidenceType = PFVSEvidenceType.findByFormType(request.type());
        AdditionalInformation additionalInformation = null;

        if (selectedFormType.equals(FormType.I140.getType())
                && submission.getFormSpecificInfo() instanceof I140FormSpecificInfo i140Info) {

            additionalInformation = ETA9089AdditionalInformation.builder().dolNumber(i140Info.getDolNumber())
                    .build();
            evidenceType = PFVSEvidenceType.E9089FD;
            sendEvidenceToPFVS = !i140Info.getIsScheduleA();
            log.info("Processing I-140 specific logic. Send to PFVS: {}, DOL Number: {}, isScheduleA: {}",
                    sendEvidenceToPFVS, i140Info.getDolNumber(), i140Info.getIsScheduleA());
        } else if(evidenceType != null) {
            sendEvidenceToPFVS = true;
        }

        if (sendEvidenceToPFVS) {
            log.info("Sending PFVS validation request for evidence: {}, type: {}", newEvidence.getId(), evidenceType);
            sendEvidencePFVSValidationRequest(submission, newEvidence, evidenceType, additionalInformation);
        } else {
            log.warn(
                    "Criteria not met to send PFVS validation for submissionId: {}, evidenceGroup.getId(): {}, PFVSEvidenceType: {}",
                    submission.getSubmissionId(), evidenceGroup.getId(), evidenceType);
        }
    }

    public List<Submission> findAllByMyUscisIdAndStatus(String myUscisId,
            List<SubmissionState> submissionStateList) {
        try {
            return submissionDao.findAllByMyUscisIdAndStatus(myUscisId, submissionStateList);
        } catch (Exception ex) {
            log.error("Exception encountered while getting all the Submissions by status status for uscisId: {}",
                    myUscisId,
                    ex.getMessage());
            throw new SubmissionIndexException(ex.getMessage());
        }
    }

    public List<Submission> findAllByOrgMyUscisIdAndStatus(String orgMyUscisId,
            List<SubmissionState> submissionStateList) {
        try {
            return submissionDao.findAllByOrgMyUscisIdAndStatus(orgMyUscisId, submissionStateList);
        } catch (Exception ex) {
            log.error("Exception encountered while getting all the Submissions by status status for org uscisId: {}",
            		orgMyUscisId,
                    ex.getMessage());
            throw new SubmissionIndexException(ex.getMessage());
        }
    }

    public List<Submission> findAllByApplicantUscisIdAndStatus(String applicantMyUscisId,
            List<SubmissionState> submissionStateList) {
        try {
            return submissionDao.findAllByMyUscisIdAndStatuswithApplicant(applicantMyUscisId, submissionStateList);
        } catch (Exception ex) {
            log.error("Exception encountered while getting all the Submissions by status status for uscisId: {}",
                    applicantMyUscisId,
                    ex.getMessage());
            throw new SubmissionIndexException(ex.getMessage());
        }
    }

    public final Submission updateSubmissionWithFeeWaiver(String myUscisId, String orgMyUscisId, String submissionId,
            UploadFeeWaiverRequest request, S3FileInfo s3FileInfo) {
        final Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

        log.info("building SubmissionEvidence (feewaiver) with form id {} and s3 key {}", s3FileInfo.id(),
                s3FileInfo.s3Key());
        SubmissionEvidence feeWaiver = SubmissionEvidence.builder()
                .id(s3FileInfo.id())
                .name(request.fileName())
                .type(null)
                .evidenceGroupType(FEE_WAIVER_EVIDENCE_GROUP)
                .s3Key(s3FileInfo.s3Key())
                .url(String.format("%s/evidence/%s", downloaderBaseUrl, s3FileInfo.s3Key()))
                .md5Hash(s3FileInfo.checksum())
                .uploadedAt(systemClock.getSystemTime())
                .build();
        submission.setFeeWaiver(feeWaiver);
        submission.setUserRequestedFeeWaiver(true);

        return submissionDao.update(submission);
    }

    public final String deleteEvidenceFromSubmission(String myUscisId, String orgMyUscisId, String submissionId, String evidenceId) {
        try {
            final Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

            Optional<SubmissionEvidence> evidenceToDelete = submission.getEvidences().parallelStream()
                    .filter(evidence -> evidence.getId().equals(evidenceId)).findAny();

            removeEvidenceFromSubmission(evidenceId, submission);
            submissionDao.update(submission);

            if (evidenceToDelete.isPresent()) {
                String s3Key = evidenceToDelete.get().getS3Key();
                boolean documentStillInUse = submission.getEvidences().parallelStream()
                        .anyMatch(evidence -> evidence.getS3Key().equals(s3Key));

                SubmissionEvidence feeWaiver = submission.getFeeWaiver();
                if (submission.getUserRequestedFeeWaiver() && !documentStillInUse)
                    documentStillInUse = feeWaiver != null && feeWaiver.getS3Key().equals(s3Key);

                return documentStillInUse ? null : s3Key;
            } else
                return null;
        } catch (NoSuchElementException | IndexOutOfBoundsException ex) {
            throw new NoSuchElementException(ex.getMessage() + " for evidenceId: " + evidenceId);
        }
    }

    private void removeEvidenceFromSubmission(String evidenceId, final Submission submission) {
        if (submission.getEvidences() != null && !submission.getEvidences().isEmpty()) {
            submission.getEvidences().removeIf(evidence -> evidence.getId().equals(evidenceId));
        } else {
            log.debug("Evidence {} cannot be deleted due to no evidence existing for submission {}", evidenceId,
                    submission.getSubmissionId());
        }
    }

    public Submission updateFeeWaiverEvidence(Submission submission, String documentType, Boolean lockEdit) {
        SubmissionEvidence feeWaiver = Optional.ofNullable(submission.getFeeWaiver())
                .orElseThrow(() -> new NoSuchElementException(
                        "No FeeWaiver for submissionId: " + submission.getSubmissionId()));
        if (!feeWaiver.getIsEditable()) {
            return submission;
        }
        feeWaiver.setType(documentType);
        feeWaiver.setIsEditable(!lockEdit);

        I912AdditionalInformation i912Info = new I912AdditionalInformation(!PFVSEvidenceType.I912.getType().equals(documentType));
        sendEvidencePFVSValidationRequest(submission, feeWaiver, PFVSEvidenceType.I912, i912Info);
        return submissionDao.update(submission);
    }

    public Submission deleteFeeWaiverFromSubmission(String myUscisId, String orgMyUscisId, String submissionId, String feeWaiverId) {
    	try {
    		final Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
    		BigDecimal feeTotal = calculateTotalFee(submission, submission.getFormType(),
    				submission.getEligibilityCategory(), true, false);
    		submission.setFeeTotal(feeTotal);

    		if(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, submission.getFormType().getType()) && submission.getForms() != null) {
    			Optional<SubmissionForm> primaryForm = submission.getForms().stream().filter(form -> submission.getFormType().equals(form.getType())).findFirst();
    			if(primaryForm.isPresent()) {
    				validationService.deleteStatus(primaryForm.get().getId());
        			log.info("Resending uploaded submission of type {} to validation service for fee recalculation", primaryForm.get().getType());
        			sendPFVSValidationRequest(submission, primaryForm.get().getId(), primaryForm.get().getS3Key());
    			}
    		}

    		return submissionDao.update(submission);

    	} catch (NoSuchElementException | IndexOutOfBoundsException ex) {
    		throw new NoSuchElementException(ex.getMessage() + " for feeWaiverId: " + feeWaiverId);
    	}
    }

    private void processFeeWaiverAndSupportDocsDelete(final Submission submission) {
        processFeeWaiverDelete(submission);

        processSupportDocsDelete(submission);
    }

    // clean up feewaiver when submission is determined to be fee exempt
    public void cleanupFeeWaiverForFeeExemptSubmission(Submission submission) {
        log.info("Cleaning up fee waiver information for fee exempt submission {}", submission.getSubmissionId());
        submission.setUserRequestedFeeWaiver(false);
        processFeeWaiverAndSupportDocsDelete(submission);
    }

    private void processSupportDocsDelete(final Submission submission) {
        if (submission.getEvidences() != null && !submission.getEvidences().isEmpty()) {
            submission.getEvidences().parallelStream()
                    .filter(evidence -> FEE_WAIVER_EVIDENCE_GROUP.equalsIgnoreCase(evidence.getEvidenceGroupType()))
                    .forEach(evidence -> s3Service.deleteS3Object(evidence.getS3Key(), true));
            submission.getEvidences()
                    .removeIf(evidence -> FEE_WAIVER_EVIDENCE_GROUP
                            .equalsIgnoreCase(evidence.getEvidenceGroupType()));
        }
    }

    private void processFeeWaiverDelete(final Submission submission) {
        final SubmissionEvidence feeWaiver = submission.getFeeWaiver();

        if (feeWaiver != null) {
            submission.setFeeWaiver(null);
            try {
                s3Service.deleteS3Object(feeWaiver.getS3Key(), true);
            } catch (S3DeleteObjectException ex) {
                log.error("Failed to delete fee waiver from s3");
            }
        }
    }

    public FormSpecificInfo setFormSpecificInfoValuesForFormWhenSelectedWithinMyUscis(FormType formType,
            EligibilityCategoryEnum eligiblityCategory) {
        // all this 765 conditionals everywhere needs to be cleaned up...
        SubmissionForm submissionForm = new SubmissionForm();
        FormSpecificInfo formSpecificInfo = null;
        if (formType.equals(FormType.I765)) {

            I765FormSpecificInfo i765FormSpecificInfo = new I765FormSpecificInfo();
            if (!I765EligibilityCategory.C11PAROLE.equals(eligiblityCategory)) {
                // submission.setImmvi(false);
                i765FormSpecificInfo.setImmvi(false);
            }

            if (I765EligibilityCategory.C9.equals(eligiblityCategory)) {
                // submission.setC9updateRequest(new C9UpdateRequest(
                // new C9Options(true, false), Boolean.TRUE));
            }
            ReasonForFiling initial = ReasonForFiling.INITIAL;
            // submission.setReasonForFiling(initial.toString());
            submissionForm.setBenefitTypeCode(initial.getBenefitTypeCode());
            i765FormSpecificInfo.setFormType(FormType.I765);

            if (!I765EligibilityCategory.C11PAROLE.equals(eligiblityCategory)) {
                // submission.setImmvi(false);
                i765FormSpecificInfo.setImmvi(false);

            }
            if (I765EligibilityCategory.C9.equals(eligiblityCategory)) {
                /*
                 * submission.setC9updateRequest(new C9UpdateRequest(
                 * new C9Options(true, false), true));
                 */
                i765FormSpecificInfo.setBefore04012024(false);
                i765FormSpecificInfo.setOnOrAfterApril012024(true);
            }
            formSpecificInfo = i765FormSpecificInfo;

        }
        return formSpecificInfo;
    }

    public final Submission createInitialSubmission(String myUscisId, SubmissionRequest request) {
        final String submissionId = uuid.apply(myUscisId);
        FormType formType = request.formType();
        String eligibilityCategory = request.eligibilityCategory();

        EligibilityCategoryEnum submissionEligibility = null;
        if (eligibilityCategory != null) {
            submissionEligibility = EligibilityCategoryEnum.fromString(eligibilityCategory);            // create the form
        }

        BigDecimal feeTotal = getInitialFee(formType, submissionEligibility);

        String reasonForFiling = ReasonForFiling.isApplicableToEligibilityCategory(submissionEligibility)
                ? ReasonForFiling.INITIAL.toString()
                : null;
        C9UpdateRequest c9updateRequest = I765EligibilityCategory.C9.equals(submissionEligibility)
                ? new C9UpdateRequest(new C9Options(true, false), Boolean.TRUE)
                : null;
        Boolean userRequestedFeeWaiver = I765EligibilityCategory.C9.equals(submissionEligibility)
                ? c9updateRequest.isFeeWaiverEligible()
                : Boolean.FALSE;
        final Submission submission = Submission.builder()
                .myUscisId(myUscisId)
                .formType(formType)
                .formName(request.formDescription())
                .eligibilityCategory(submissionEligibility)
                .forms(createInitialForms(formType, request, submissionEligibility))
                .submissionId(submissionId)
                .status(SubmissionState.DRAFT)
                .userRequestedFeeWaiver(userRequestedFeeWaiver)
                .userRequestedPartialFeeWaiver(Boolean.FALSE)
                .evidences(Lists.newArrayList())
                .immvi(Boolean.FALSE)
                .feeTotal(feeTotal)
                .attested(Boolean.FALSE)
                .applicant(UserInformation
                        .builder()
                        .accountType(request.accountType())
                        .myUscisId(myUscisId)
                        .build())
                .timestamp(systemClock.getSystemTime())
                .updatedAt(systemClock.getSystemTime())
                .c9updateRequest(c9updateRequest)
                .reasonForFiling(reasonForFiling)
                .formSpecificInfo(setFormSpecificInfoValuesForFormWhenSelectedWithinMyUscis(formType, submissionEligibility))
                .selectedConcurrentForms(request.concurrentForms() != null ? request.concurrentForms().stream().map(cf -> FormType.fromString(cf.formType())).toList() : null)
                .build();
        if(request.accountType().equals(AccountType.REGISTRANT)) {
        	UserGroupRole organizationGroupRole = userGroupServiceClient.getOrganizationGroupRole(myUscisId);
        	if(organizationGroupRole != null && StringUtils.isNotBlank(organizationGroupRole.getUserGroupId())) {
        		submission.getApplicant().setUserGroupId(organizationGroupRole.getUserGroupId());
        		submission.setOrgMyUscisId(organizationGroupRole.getUserGroupId());
        	}
        }
        request.clientInformation().ifPresentOrElse(info -> {
            ClientAssociation association = userGroupServiceClient.isClientAssociated(myUscisId, info.getClientId());
            boolean clientInOrg = request.clientInformation().get().getClientId().startsWith("O-");
            submission.setClientInformation(associateClientInformationWithSubmission(association, submissionId, info));
            if (AccountType.REPRESENTATIVE.equals(request.accountType()) && clientInOrg) {
                submission.setOrgMyUscisId(request.clientInformation().get().getClientId());
            } else {
                submission.setOrgMyUscisId(association.clientUserGroupId());
            }
        }, () -> {
            submission.setClientInformation(createDefaultClientInformation(myUscisId, submissionId));
        });
        auditService.createAudit(submission.getMyUscisId(), submissionId);
        return submissionDao.save(submission);
    }

    private List<SubmissionForm> createInitialForms(FormType mainFormType, SubmissionRequest request, EligibilityCategoryEnum submissionEligibility){
    	List<SubmissionForm> forms = new ArrayList<>();
    	Optional<ClientInformation> clientInformationOptional = request.clientInformation();
    	forms.add(SubmissionForm.builder()
        		.eligibilityCategory(submissionEligibility)
        		.type(mainFormType.getType())
        		.id(UUID.randomUUID().toString())
                .benefitTypeCode(mainFormType == FormType.I765 ? ReasonForFiling.INITIAL.getBenefitTypeCode() : null)
                .applicationReasonCode(request.applicationReasonCode())
                .formSpecificInfo(setFormSpecificInfoValuesForFormWhenSelectedWithinMyUscis(mainFormType, submissionEligibility))
        		.clientId(clientInformationOptional.isPresent() ? clientInformationOptional.get().getClientId() : null)
        		.clientName(clientInformationOptional.isPresent() ? clientInformationOptional.get().getName() : null)
                .build());

    	if(request.concurrentForms() != null) {
    		for(ConcurrentForm concurrentForm : request.concurrentForms()) {
    			SubmissionForm submissionForm = SubmissionForm.builder()
                		.type(concurrentForm.formType())
                		.id(UUID.randomUUID().toString())
                		.build();
    			Optional<ClientInformation> concurrentFormClientInformationOptional = concurrentForm.clientInformation();
    			if(concurrentFormClientInformationOptional.isPresent()) {
    				ClientInformation clientInformation = concurrentFormClientInformationOptional.get();
    				submissionForm.setClientId(clientInformation.getClientId());
    				submissionForm.setClientName(clientInformation.getName());
    			}
    			forms.add(submissionForm);
    		}
    	}

    	if(AccountType.REPRESENTATIVE.equals(request.accountType())) {
    		forms.add(SubmissionForm.builder()
            		.type(FormType.G28.getType())
            		.id(UUID.randomUUID().toString())
            		.build());
    	}

    	return forms;
    }

    private BigDecimal getInitialFee(FormType formType, EligibilityCategoryEnum submissionEligibility) {
    	BigDecimal feeTotal = BigDecimal.ZERO;
    	if (FormType.I765.equals(formType)) {
            // Shortcutting the calculation for reason for filing dependent fee structures
            // as we will not have that
            // information at this point.
            if (!ReasonForFiling.isApplicableToEligibilityCategory(submissionEligibility)) {
                feeTotal = feeService.calculateI765FeeFor(formType, (I765EligibilityCategory) submissionEligibility);
            }
        } else if (FormType.N400.equals(formType)) {
            feeTotal = feeService.calculateN400FeeFor(formType, (N400EligibilityCategory) submissionEligibility);
        } else if (FormType.I131.equals(formType)) {
            feeTotal = feeService.calculateI131FeeFor(formType, (I131EligibilityCategory) submissionEligibility);
        } else if (FormType.I130.equals(formType)) {
            feeTotal = feeService.calculateI130FeeFor(formType, (I130EligibilityCategory) submissionEligibility);
        }
    	return feeTotal;
    }

    private ClientInformation createDefaultClientInformation(String myUscisId, String submissionId) {
        log.info("About to retrieve rep id for {}", myUscisId);
        var repGroupid = userGroupServiceClient.getRepGroupId(myUscisId);
        log.info("Retrieving rep group id for {} as {}", myUscisId, repGroupid);
        List<String> userGroupIds = Lists.newArrayList();
        if (repGroupid != null)
            userGroupIds.add(repGroupid.getUserGroupId());
        return clientInformationRepository.save(myUscisId, null, submissionId, null, userGroupIds);
    }

    private ClientInformation associateClientInformationWithSubmission(ClientAssociation association, final String submissionId, ClientInformation info) {
        var ids = new ArrayList<String>(info.getUserGroupIds());
        ids.add(association.clientUserGroupId());

        log.info("Adding group ids {} to the submisson {}", ids, submissionId);
        return clientInformationRepository.save(info.getAttorneyId(),
                info.getClientId(), submissionId, info.getName(), ids);
    }

    public final Submission deleteFormFromSubmission(String myUscisId, String orgMyUscisId, String submissionId, String formId) {
        try {
            final Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
            final List<SubmissionForm> submissionForms = submission.getForms() != null
                    ? submission.getForms()
                    : new ArrayList<>();

            final SubmissionForm submissionForm = submissionForms.stream()
                    .filter(form -> form.getId().equals(formId)).findFirst().orElseThrow();

            String s3Key = submissionForm.getS3Key();

            var formType = submission.getFormType();
            if (FormType.I765.equals(formType)) {
                BigDecimal feeTotal = calculateTotalFee(submission, false);
                submission.setFeeTotal(feeTotal);
            }

            submissionForm.setS3Key(null);
            submissionForm.setUrl(null);
            submissionForm.setName(null);
            submissionForm.setMd5Hash(null);
            submissionForm.setUploadedAt(null);

            s3Service.deleteS3Object(s3Key, false);
            validationService.deleteStatus(formId);
            log.info("deleting: {} from S3 and from submission {}", s3Key, submissionId);
            return submissionDao.update(submission);

        } catch (NoSuchElementException e) {
            throw new NoSuchElementException(e.getMessage() + " for form ID: " + formId);
        }
    }

    public final SubmissionStatusResponse retrieveSubmissionStatus(String myUscisId, String orgMyUscisId, String submissionId) {
        final List<String> submissionErrors = new ArrayList<>();
        final Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        if (null == submission.getEligibilityCategory() && !submission.getFormType().equals(FormType.I907)) {
            submissionErrors.add("An Eligibility Category was not selected");
        }

        List<SubmissionForm> forms = Optional.ofNullable(submission.getForms()).orElse(emptyList());
        List<ErrorGroup> formErrors = checkFormErrors(submission, forms);

        final List<ErrorGroup> evidenceErrors = new ArrayList<>();
        if (submission.getFormType().equals(FormType.I765) && submission.getUserRequestedFeeWaiver()) {
            validateFeeWaiverAndSupportingEvidences(submissionErrors, submission, evidenceErrors);
        }

        if (submission.getFormType().equals(FormType.N400) && submission.getUserRequestedFeeWaiver()) {
            if (submission.getUserRequestedPartialFeeWaiver() != null
                    && submission.getUserRequestedPartialFeeWaiver().equals(Boolean.TRUE)) {
                validateSupportingEvidences(submission, evidenceErrors, true);
            }

            if (submission.getUserRequestedPartialFeeWaiver() != null
                    && submission.getUserRequestedPartialFeeWaiver().equals(Boolean.FALSE)) {
                validateFeeWaiverAndSupportingEvidences(submissionErrors, submission, evidenceErrors);
            }
        }
        validateDolCaseSelectForI140(submission, submissionErrors, evidenceErrors);
        List<SubmissionEvidence> evidences = submission.getEvidences();
        if (null != evidences)
            evidences.forEach(evidence -> {
                evidenceErrors.add(ErrorGroup.builder()
                        .type(evidence.getType())
                        .errors(validate(evidence))
                        .formType(getFormTypeByFormId(submission, evidence.getFormId()))
                        .build());
            });

        return SubmissionStatusResponse.builder()
                .submissionErrors(submissionErrors)
                .formErrors(formErrors)
                .evidenceErrors(evidenceErrors)
                .build();
    }

            private String getFormTypeByFormId(Submission submission, String formId) {
            // 1. Loop through the forms in the submission
            if (submission.getForms()!= null) {
            for (SubmissionForm form : submission.getForms()) {

                // 2. Find the form that matches your formId
                if (formId.equals(form.getId())) {
                    return form.getType();
                }
            }

            // 3. Fallback to the primary form type if no match is found
            return submission.getFormType().getType();
        }
        return null;
        }
    private void validateDolCaseSelectForI140(Submission submission, List<String> submissionErrors, List<ErrorGroup> evidenceErrors) {
        List<I140EligibilityCategory> dolNumberRequiredPetitionTypes = List.of(I140EligibilityCategory.MEMBER_OF_PROFESSIONS, I140EligibilityCategory.PROFESSIONAL, I140EligibilityCategory.SKILLED_WORKER);
        if (submission.getFormType().equals(FormType.I140) && submission.getFormSpecificInfo() != null
        && dolNumberRequired(submission) && dolNumberRequiredPetitionTypes.contains(submission.getEligibilityCategory()))  {
            if (((I140FormSpecificInfo) submission.getFormSpecificInfo()).getDolNumber().isBlank() )  {
                         submissionErrors.add("The Labor Certification DOL Case Number is missing on the Petition Type page.");
            }
            String laborCertificationEvidence = "labor-certification";
            if (submission.getEvidences() != null) {
                Optional<SubmissionEvidence> evidence9089FD = submission.getEvidences().stream()
                        .filter(el -> laborCertificationEvidence.equals(el.getEvidenceGroupType()))
                        .findFirst();

                if (!evidence9089FD.isPresent()) {
                    evidenceErrors.add(new ErrorGroup(submission.getFormType().getType(), laborCertificationEvidence,
                            List.of("Form ETA-9089 Final Determination is missing")));
                }
            }
        }
    }


    private void validateFeeWaiverAndSupportingEvidences(final List<String> errors, final Submission submission,
            final List<ErrorGroup> evidenceStatuses) {
        SubmissionEvidence feeWaiver = submission.getFeeWaiver();
        if (null == feeWaiver) {
            errors.add("Provide Form I-912 or a signed letter to submit your fee waiver request.");
        } else {
            evidenceStatuses.add(ErrorGroup.builder() // general validation of feeWaiver
                    .type(submission.getFeeWaiver().getType())
                     .formType(getFormTypeByFormId(submission, feeWaiver.getFormId()))
                    .errors(validateFeeWaiver(feeWaiver))
                    .build());

            validateSupportingEvidences(submission, evidenceStatuses, false);
        }
    }

    private void validateSupportingEvidences(final Submission submission,
            final List<ErrorGroup> evidenceStatuses, boolean forPartialFeeWaiver) {
        if (!submission.getEvidences().parallelStream() // validate that supporting doc is present
                .anyMatch(evidence -> evidence.getEvidenceGroupType() != null
                        && evidence.getEvidenceGroupType().equals(FEE_WAIVER_EVIDENCE_GROUP))) {
            evidenceStatuses.add(ErrorGroup.builder()
                    .type(FEE_WAIVER_EVIDENCE_GROUP)
                    .errors(List
                            .of(forPartialFeeWaiver ? "Partial Fee waiver evidence is missing"
                                    : "Fee waiver evidence is missing"))
                    .build());
        }
    }

    /*
     * @MetricAware(transaction = AuditableTransaction.PendingSubmission)
     * private final LockboxTransmission transformToLockboxTransmission(Submission
     * s) {
     * SubmissionForm form = s.getForms().get(0);
     * List<SubmissionEvidence> evidences = new ArrayList<>();
     * if (s.getEvidences() != null)
     * evidences.addAll(s.getEvidences());
     *
     * if (!TRUE.equals(s.getUserRequestedFeeWaiver())) {
     * // Last opportunity to clean up dangling files, otherwise should no-op
     * processFeeWaiverAndSupportDocsDelete(s);
     * }
     *
     * if (TRUE.equals(s.getUserRequestedFeeWaiver()) &&
     * !TRUE.equals(s.getUserRequestedPartialFeeWaiver())) {
     * SubmissionEvidence feeWaiver = s.getFeeWaiver();
     * feeWaiver.setType(DocumentType.FeeWaiver.FORM_I912);
     * evidences.add(feeWaiver);
     * }
     *
     * LockboxSubmission lockboxSub = new LockboxSubmission(s.getSubmissionId(),
     * s.getUserRequestedFeeWaiver(),
     * s.getFeeTotal(), StatusEnum.RECEIVED, new LockboxForm(form.getType(),
     * form.getId(),
     * form.getUrl(), form.getName(), form.getMd5Hash(),
     * form.getRejectionReasons()),
     * evidences);
     *
     * return new LockboxTransmission(s.getMyUscisId(), lockboxSub);
     * }
     *
     */

    @SubmissionStateChange
    public Submission updateSubmissionWithLockBoxStatus(String submissionId, SubmissionUpdateRequest request) {
        log.debug("updateSubmissionWithLockBoxStatus called with update type: " + request.getUpdateType());

        Submission submission = retrieveSubmission(submissionId);
        submission.setUpdatedAt(systemClock.getSystemTime());

        if (request.getUpdateType() == EntityType.SUBMISSION) {
            handleSubmissionUpdateRequested(request, submission);
        } else if (request.getUpdateType() == EntityType.MANIFEST) {
            handleManifestUpdateRequested(request, submission);
        }

        if (submission.getApplicant().getAccountType() != null) {
            if (submission.getApplicant().getAccountType().equals(AccountType.REPRESENTATIVE)
                    && request.getSubmissionUpdate() != null) {
                Optional<ApplicationStatus> g28Status = request.getSubmissionUpdate().getApplicationStatuses().stream()
                        .filter(status -> status.getFormType().equals(FormType.G28.getType())).findFirst();
                if (g28Status.isPresent() && g28Status.get().getStatus().equals(StatusEnum.REJECTED)
                        && submission.getStatus().equals(SubmissionState.ACCEPTED)) {
                    Submission copy = SubmissionUtils.copySubmission(submission);
                    copy.setSubmissionId(UUID.randomUUID().toString());
                    copy.setEvidences(List.of());
                    copy.setFeeWaiver(null);
                    copy.setFormType(FormType.G28);
                    copy.setFormName(FormTypeDescription.G28.getDescription());
                    copy.setStatus(REJECTED);
                    copy.setLockboxStatus(LockboxStatuses.REJECTED);

                    var clientId = submission.getClientInformation() != null
                            ? submission.getClientInformation().getClientId()
                            : null;
                    submission.setApplicant(UserInformation.builder().accountType(AccountType.APPLICANT)
                            .myUscisId(clientId).build());
                    submission.setMyUscisId(clientId);

                    Optional<SubmissionForm> g28Form = copy.getForms().stream()
                            .filter(form -> form.getType().equals(FormType.G28.getType())).findFirst();
                    g28Form.ifPresent(g28 -> {
                        copy.setForms(List.of(g28));
                        submission.getForms().removeIf(form -> form.getId().equals(g28.getId()));
                        submission.getEvidences().add(SubmissionUtils.convertToEvidence(g28));
                    });

                    submissionDao.save(copy);
                }

            }
        }

        return submissionDao.update(submission);
    }

    private void handleManifestUpdateRequested(SubmissionUpdateRequest request, Submission submission) {
        ManifestUpdate manifestUpdate = request.getManifestUpdate();

        switch (manifestUpdate.getStatus()) {
            case RECEIVED:
                submission.setLockboxStatus(LockboxStatuses.RECEIVED);
                break;
            case COMPLETE:
                submission.setLockboxStatus(LockboxStatuses.PROCESSING);
                break;
            case ERROR:
                submission.setLockboxStatus(LockboxStatuses.ERROR);
                submission.setLockboxErrors(manifestUpdate.getErrors());
                break;
            default:
                throw new SubmissionBadException("Invalid manifest status");
        }
    }

    private void handleSubmissionUpdateRequested(SubmissionUpdateRequest request, Submission submission) {
        SubmissionUpdate submissionUpdate = request.getSubmissionUpdate();
        switch (submissionUpdate.getStatus()) {
            case ACCEPTED:
                setAcceptedState(submission);
                break;
            case REJECTED:
                setRejectedState(submission);
                break;
            case MIXED:
                List<ApplicationStatus> statuses = submissionUpdate.getApplicationStatuses();
                statuses.stream()
                        .filter(status -> submission.getFormType().getType().equals(status.getFormType()))
                        .findFirst()
                        .ifPresentOrElse((status -> {
                            if (StatusEnum.ACCEPTED.equals(status.getStatus())) {
                                setAcceptedState(submission);
                            } else {
                                setRejectedState(submission);
                            }
                        }), null);
                break;
            default:
                            log.error("Invalid submission status for submission ID: {}", submission.getSubmissionId());
                throw new SubmissionBadException("Invalid submission status" );
        }

        myUscisCacheManagementClient.publishCaseChangeEvent(submission);
    }


    private void setRejectedState(Submission submission) {
        submission.setLockboxStatus(LockboxStatuses.REJECTED);
        submission.setStatus(SubmissionState.REJECTED);
    }

    private void setAcceptedState(Submission submission) {
        submission.setLockboxStatus(LockboxStatuses.ACCEPTED);
        submission.setStatus(SubmissionState.ACCEPTED);
    }

    private List<String> validate(SubmissionEvidence evidence) {
        final List<String> errors = new ArrayList<>();

        if (isBlank(evidence.getType())) {
            return singletonList("Choose the type for the uploaded evidence");
        }
        if (evidence.getId() == null) {
            errors.add(String.format("%s is missing ID", evidence.getType()));
        }
        if (evidence.getName() == null) {
            errors.add(String.format("%s is missing Name", evidence.getType()));
        }
        if (evidence.getMd5Hash() == null) {
            errors.add(String.format("%s is missing Md5Hash", evidence.getType()));
        }
        if (evidence.getUrl() == null) {
            errors.add(String.format("%s is missing URL", evidence.getType()));
        }

        List<ValidationStatus> queryValidationStatus = validationService.queryValidationStatus(evidence.getId());
        List<String> validationErrors = queryValidationStatus.stream()
                .filter(status -> ValidationResultEnum.FAIL.equals(status.getStatus()))
                .flatMap(status -> status.getFailureReasons().stream())
                .toList();
        errors.addAll(validationErrors);

        return errors;
    }

    private List<String> validateFeeWaiver(SubmissionEvidence feeWaiver) {
        final List<String> errors = new ArrayList<>();

        if (isBlank(feeWaiver.getType())) {
            return singletonList("Select the category for your fee waiver evidence");
        }
        if (feeWaiver.getId() == null) {
            errors.add(String.format("%s is missing ID", feeWaiver.getType()));
        }
        if (feeWaiver.getName() == null) {
            errors.add(String.format("%s is missing Name", feeWaiver.getType()));
        }
        if (feeWaiver.getMd5Hash() == null) {
            errors.add(String.format("%s is missing Md5Hash", feeWaiver.getType()));
        }
        if (feeWaiver.getUrl() == null) {
            errors.add(String.format("%s is missing URL", feeWaiver.getType()));
        }

        if (DocumentType.FeeWaiver.FORM_I912.equals(feeWaiver.getType())
                || DocumentType.FeeWaiver.FEE_DECLARATION.equals(feeWaiver.getType())) {
            List<ValidationStatus> queryValidationStatus = validationService
                    .queryValidationStatus(feeWaiver.getId());
            List<String> validationErrors = queryValidationStatus.stream()
                    .filter(status -> ValidationResultEnum.FAIL.equals(status.getStatus()))
                    .flatMap(status -> status.getFailureReasons().stream())
                    .toList();

            if (DocumentType.FeeWaiver.FEE_DECLARATION.equals(feeWaiver.getType())) {
                validationErrors = validationErrors.contains(FeeWaiverErrors.FORM_TYPE_NOT_PRESENT_MESSAGE)
                        ? List.of()
                        : validationErrors;
            }

            errors.addAll(validationErrors);
        }
        return errors;
    }

    private List<ErrorGroup> checkFormErrors(Submission submission, List<SubmissionForm> forms) {

        Boolean isSubmissionByRepresentative = submission.getApplicant() != null
                ? (AccountType.REPRESENTATIVE == submission.getApplicant().getAccountType())
                : false;

        List<ErrorGroup> formErrors = new ArrayList<ErrorGroup>();

        for (SubmissionForm formToValidate : forms) {
            ErrorGroup formErrorGroup = ErrorGroup.builder()
                    .type(formToValidate.getType())
                    .errors(new ArrayList<String>())
                    .build();

            formErrors.add(formErrorGroup);

            if (formToValidate.getName() == null) {
                formErrorGroup.errors().add(String.format("Your Form %s is missing", formToValidate.getType()));
            }
            List<ValidationStatus> queryValidationStatus = validationService
                    .queryValidationStatus(formToValidate.getId());
            List<String> validationErrors = queryValidationStatus.stream()
                    .filter(status -> ValidationResultEnum.FAIL.equals(status.getStatus())
                            && ((!status.getValidator().equals(ValidatorEnum.SIGNATURE))
                                    || (isSubmissionByRepresentative))

                    )
                    .flatMap(status -> status.getFailureReasons().stream())
                    .toList();
            formErrorGroup.errors().addAll(validationErrors);

        }

        final List<String> requiredForms = new ArrayList<>();
        requiredForms.add(submission.getFormType().getType());
        if (isSubmissionByRepresentative) {
            requiredForms.add(FormType.G28.getType());
        }

        for (String requiredFormType : requiredForms) {
            ErrorGroup requiredFormErrorGroup = formErrors.stream()
                    .filter(requiredForm -> requiredFormType.equals(requiredForm.type()))
                    .findFirst()
                    .orElse(null);

            if (requiredFormErrorGroup == null) {
                formErrors.add(
                        ErrorGroup.builder()
                                .type(requiredFormType)
                                .errors(List.of(String.format("Your Form %s is missing", requiredFormType)))
                                .build());
            }
        }
        return formErrors;
    }

    public final List<Submission> retrieveDraftSubmissions(String myUscisId) {
        try {
            return submissionDao.findAllDraftsByMyUscisId(myUscisId);
        } catch (Exception ex) {
            log.error("Exception encountered while getting all the Submissions in Draft status for uscisId: {}",
                    myUscisId,
                    ex.getMessage());
            throw new SubmissionIndexException(ex.getMessage());
        }
    }

    public void deleteDraftSubmission(String myUscisId, String orgMyUscisId, String submissionId) {
        log.info("deleting draft submission with submissionId: {}", submissionId);

        try {
            final Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
            final List<SubmissionForm> submissionForms = submission.getForms();
            final SubmissionEvidence feeWaiver = submission.getFeeWaiver();
            final List<SubmissionEvidence> submissionEvidences = submission.getEvidences();

            if (formExists(submissionForms)) {
                submissionForms.forEach(form -> {
                    s3Service.deleteS3Object(form.getS3Key(), false);
                });
            }

            if (submissionEvidences != null && !submissionEvidences.isEmpty()) {
                submissionEvidences.forEach(evidence -> {
                    s3Service.deleteS3Object(evidence.getS3Key(), true);
                });
            }

            if (feeWaiver != null) {
                s3Service.deleteS3Object(feeWaiver.getS3Key(), true);
            }

            submissionDao.deleteById(submissionId);
            myUscisCacheManagementClient.publishDraftChangeEvent(submission);
        } catch (Exception ex) {
            log.error("Exception encountered during deleteItem for Submission with id {} with Exception {}",
                    submissionId, ex.getMessage());
            throw new SubmissionDeleteException(ex.getMessage());
        }
    }

    // private void deleteClientInformation( final Submission submission) {
    // if (submission.getApplicant() != null
    // && submission.getApplicant().getAccountType() == AccountType.REPRESENTATIVE)
    // {
    // var clientInformation =
    // clientInformationRepository.findBySubmissionId(submission.getSubmissionId());
    // if (clientInformation != null) {
    // clientInformationRepository.delete(clientInformation);
    // }
    // }
    // }

    private void updateFeeTotalOnCategoryChange(boolean hasCategoryChanged, Submission submission,
            BigDecimal calculatedFee) {
        if (hasCategoryChanged)
            submission.setFeeTotal(calculatedFee);
    }

    private void updateFeeTotalOnRequestedFeeWaiverChange(Submission submission) {
        BigDecimal feeTotal = calculateTotalFee(submission, true);
        submission.setFeeTotal(feeTotal);
    }

    public Submission updateImmvi(String submissionId, String myUscisId, String orgMyUscisId, Boolean requestingImmvi) {
        Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        if (!submission.getFormType().equals(FormType.I765))
            throw new SubmissionBadException("IMMVI not applicable for this form type");
        SubmissionForm existingForm = submission.getForms().stream()
                .filter(form -> form.getType().equals(submission.getFormType().getType())).findFirst().orElseThrow();
        submission.setImmvi(requestingImmvi);
        if (submission.getFormSpecificInfo() == null) {
            I765FormSpecificInfo specificInfo = new I765FormSpecificInfo();
            specificInfo.setImmvi(requestingImmvi);
            submission.setFormSpecificInfo(specificInfo);
        }
        else {
          ((I765FormSpecificInfo) submission.getFormSpecificInfo()).setImmvi(requestingImmvi);
        }

        if (existingForm.getFormSpecificInfo() == null) {
            I765FormSpecificInfo specificInfo = new I765FormSpecificInfo();
            specificInfo.setImmvi(requestingImmvi);
            existingForm.setFormSpecificInfo(specificInfo);
        }
        else {
            ((I765FormSpecificInfo) existingForm.getFormSpecificInfo()).setImmvi(requestingImmvi);
        }
            submission.setForms(submission.getForms());
            BigDecimal totalFee = calculateTotalFee(submission, submission.getImmvi());
       if( !toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, submission.getFormType().getType())) {
            submission.setFeeTotal(totalFee);
        }
        if (requestingImmvi && submission.getUserRequestedFeeWaiver() != null) {
            submission.setFeeWaiver(null);
            submission.setUserRequestedFeeWaiver(false);
        }

        auditService.addEvent(submission.getMyUscisId(), submission.getSubmissionId(),
                ActionPerformed.SELECT_IMMVI,
                requestingImmvi.toString());

        return submissionDao.update(submission);
    }

    public Submission updateC9Fee(String submissionId, String myUscisId, String orgMyUscisId, C9UpdateRequest request) {
        Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        // TODO This function needs to run for the I765
    	if(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, submission.getFormType().getType()) && !(submission.getFormType().equals(FormType.I765))) {
    		// the additional information will be populated from form specific info. We don't need this for PFVS enabled.
    		return submission;
    	}

        if (!submission.getFormType().equals(FormType.I765)) {
            throw new SubmissionBadException("C9 not applicable for this form type");
        }
        submission.setC9updateRequest(request);

        FormType formType = submission.getFormType();
        if (formExists(submission.getForms())) {
        	SubmissionForm form = submission.getForms().stream()
                    .filter(f -> f.getType().equals(formType.getType()))
                    .findFirst()
                    .orElse(null);
	    	if(form != null && form.getExtractedData() != null) {
	        		reasonForFilingValidator.validate(submission, FormFields.builder()
	                        .formId(form.getId())
	                        .eligibilityCategory(form.getExtractedData().getEligibilityCategory())
	                        .reasonForApplySelection(ReasonForFiling.fromFormEntry(form.getExtractedData().getReasonForFiling()).toString())
	                        .build());
	        }
        }
        if(submission.getFormType().equals(FormType.I765)) {
            FeeStrategyOptions options = buildOptionsForI765(submission, submission.getEligibilityCategory());
            boolean shouldResetFeeWaiver = !feeService.isEligibleForFeeWaiver(submission.getFormType(), submission.getEligibilityCategory(), options);
            // If the user has requested a fee waiver, but now is no longer eligible for one, reset fee waiver info on the submission.
                        BigDecimal calculatedFee = (calculateTotalFee(submission, shouldResetFeeWaiver));
                        if (!(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, formType.getType()))) {
                            submission.setFeeTotal(calculatedFee);
                    }
       }

        auditService.addEvent(submission.getMyUscisId(), submission.getSubmissionId(), ActionPerformed.SELECT_C9_OPTION, "");

        return submissionDao.update(submission);
    }

    public Submission updateReasonForFiling(String submissionId, String myUscisId, String orgMyUscisId, String reasonForFiling) {
        Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        submission.setReasonForFiling(reasonForFiling);

        FormType formType = submission.getFormType();
        if(FormType.I765.equals(formType)) {
        	ReasonForFiling reasonForFilingEnum = ReasonForFiling.fromString(reasonForFiling);
        	submission.setBenefitTypeCode(reasonForFilingEnum.getBenefitTypeCode());        // TODO can we pull this out of a specific loop
        	SubmissionForm submissionFormI765 =submission.getForms()
	        		.stream()
	        		.filter(submissionForm -> FormType.I765.getType().equals(submissionForm.getType()))
	        		.findFirst()
	        		.orElse(null);
        	if(submissionFormI765 != null) {
        		submissionFormI765.setBenefitTypeCode(reasonForFilingEnum.getBenefitTypeCode());
        		submission.setReasonForFiling(reasonForFiling);
        	}
        }
        if (formExists(submission.getForms())) {
        	SubmissionForm form = submission.getForms().stream()
                    .filter(f -> f.getType().equals(formType.getType()))
                    .findFirst()
                    .orElse(null);
        	if(form != null && form.getS3Key() != null) {
            	if(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, submission.getFormType().getType())) {
            		log.info("Sending validation request to PFVS due to reason for filing update.");
            		sendPFVSValidationRequest(submission, form.getId(), form.getS3Key());
            		validationService.deleteStatus(form.getId());
                } else if(form.getExtractedData() != null) {
            		reasonForFilingValidator.validate(submission, FormFields.builder()
                            .formId(form.getId())
                            .eligibilityCategory(form.getExtractedData().getEligibilityCategory())
                            .reasonForApplySelection(ReasonForFiling.fromFormEntry(form.getExtractedData().getReasonForFiling()).toString())
                            .build());
            	}
            	}
        }
        if(formType.equals(FormType.I765)) {
            FeeStrategyOptions options = buildOptionsForI765(submission, submission.getEligibilityCategory());
            boolean shouldResetFeeWaiver = !feeService.isEligibleForFeeWaiver(submission.getFormType(), submission.getEligibilityCategory(), options);
            // If the user has requested a fee waiver, but now is no longer eligible for one, reset fee waiver info on the submission.
                            // We will change remove the fees when we migrate to PFVS in production
                    BigDecimal calculatedFee = calculateTotalFee(submission, shouldResetFeeWaiver);
                    if (!(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, formType.getType()))) {
                    submission.setFeeTotal(calculatedFee);
                    }
        }

        auditService.addEvent(submission.getMyUscisId(), submission.getSubmissionId(), ActionPerformed.SELECT_REASON_FOR_FILING, reasonForFiling.toString());

        return submissionDao.update(submission);
    }

    public Submission updateSignatureReviewed(String submissionId, String myUscisId, String orgMyUscisId, Boolean hasReviewedSignature) {
        Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

        submission.setAttested(true);
        submission.setAttestedAt(systemClock.getSystemTime());
        submission.setHasReviewedSignature(hasReviewedSignature);

        auditService.addEvent(submission.getMyUscisId(), submission.getSubmissionId(),
                ActionPerformed.REVIEW_SIGNATURE,
                hasReviewedSignature.toString());

        return submissionDao.update(submission);
    }

    public Submission updateEligibility(String submissionId, String myUscisId, String orgMyUscisId, EligibilityUpdateRequest request) {
        Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

        log.info("Looking for form type {} in submission {}, existing: {}", request.getFormType(), submissionId, submission.getForms().stream().map(SubmissionForm::getType).toList());

        SubmissionForm existingForm = submission.getForms().stream()
                .filter(form -> form.getType().equals(request.getFormType())).findFirst().orElse(null);

        if(existingForm == null) {
            existingForm = createMissingForm(submission, request.getFormType(), null);
        }
        submission.setReasonForFiling(null);

        existingForm.setEligibilityCategory(request.getEligibilityCategory());
        existingForm.setEligibilitySubcategory(request.getEligibilitySubcategory());
        if(request.getEligibilitySubcategory() != null){
            existingForm.setEligibilitySubcategoryList(List.of(request.getEligibilitySubcategory()));
        }
        existingForm.setBenefitTypeCode(request.getBenefitTypeCode());
        existingForm.setApplicationReasonCode(request.getApplicationReasonCode());

        FormType formType = FormType.fromString(request.getFormType());
        if(!submission.getFormType().equals(formType)) {
        	log.info("Processing eligibility update on concurrent non-primary form");
        }
        else {
        	if(FormType.I751.equals(submission.getFormType())) {
                submission.setUserIsEligibleForFeeWaiver(is751SelectedCategoryFeewaivable(request.getEligibilityCategory()));
            }
            submission.setEligibilityCategory(request.getEligibilityCategory());
            submission.setEligibilitySubcategory(request.getEligibilitySubcategory());
            submission.setBenefitTypeCode(request.getBenefitTypeCode());
            submission.setApplicationReaonCode(request.getApplicationReasonCode());

            SubmissionForm afterUpdate = submission.getForms().stream()
                    .filter(form -> form.getType().equals(request.getFormType())).findFirst().orElseThrow();

            log.info("Primary form now {}", afterUpdate.toString());

            Boolean partialFeeWaiverRequested = submission.getUserRequestedPartialFeeWaiver();
            boolean userHasFeeWaiverDocumentUploaded = submission.getFeeWaiver() != null;
            Boolean feeWaiverRequested = submission.getUserRequestedFeeWaiver();

            //all this 765 conditionals everywhere needs to be cleaned up...
            if (!I765EligibilityCategory.C11PAROLE.equals(request.getEligibilityCategory())) {
                 I765FormSpecificInfo i765FormSpecificInfo = new I765FormSpecificInfo();
                submission.setImmvi(false);
            i765FormSpecificInfo.setImmvi(false);
            }

            if(I765EligibilityCategory.C9.equals(request.getEligibilityCategory())) {
                submission.setC9updateRequest(new C9UpdateRequest(
                    new C9Options(true, false), feeWaiverRequested));
            }
           //   SubmissionForm form =  setValuesForFormWhenSelectedWithinMyUscis(submission, submissionForm, eligiblityCategory );
     if (submission.getFormType().equals(FormType.I765)) {
        	ReasonForFiling initial = ReasonForFiling.INITIAL;
            submission.setReasonForFiling(initial.toString());
            existingForm.setBenefitTypeCode(initial.getBenefitTypeCode());
                             I765FormSpecificInfo i765FormSpecificInfo = new I765FormSpecificInfo();
            i765FormSpecificInfo.setFormType(FormType.I765);

        if (!I765EligibilityCategory.C11PAROLE.equals(request.getEligibilityCategory())) {
            submission.setImmvi(false);
            i765FormSpecificInfo.setImmvi(false);

        }
        if(I765EligibilityCategory.C9.equals(request.getEligibilityCategory())) {
            submission.setC9updateRequest(new C9UpdateRequest(
                new C9Options(true, false), true));
                i765FormSpecificInfo.setBefore04012024(false);
                i765FormSpecificInfo.setOnOrAfterApril012024(true);

        }
        submission =   updateFormSpecificInfo(submission, i765FormSpecificInfo);
    }
            // If reason for filing is not applicable to this category, null it out.
            // TODO remove after TDSS is permanently on
            submission.setReasonForFiling(null);
            if (StringUtils.isEmpty(submission.getReasonForFiling()) && FormType.I765.equals(formType)) {
            // However, if we just changed categories, default to initial as updateReasonForFiling
            // does not trigger from the category change.
            submission.setReasonForFiling(ReasonForFiling.INITIAL.toString());
              }

        if (formType.equals(FormType.I765)) {
            BigDecimal calculatedFee = calculateTotalFee(submission, submission.getFormType(), request.getEligibilityCategory(), false, false);

                if (calculatedFee != null) {
                    submission.setFeeTotal(calculatedFee);
                    var isFeeExempt = calculatedFee.compareTo(BigDecimal.ZERO) == 0;
                    if (isFeeExempt)
                        submission.setUserRequestedFeeWaiver(false);
                }

                if (userHasFeeWaiverDocumentUploaded && calculatedFee != null
                        && calculatedFee.compareTo(I765Fees.FEE_EXEMPT) == 0) {
                    processFeeWaiverAndSupportDocsDelete(submission);
                    submission.setUserRequestedFeeWaiver(false);
                }
                // We will change remove the fees when we migrate to PFVS in production
                    if ((toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, formType.getType()))) {
                        submission.setFeeTotal(BigDecimal.ZERO);
                    }
                if (formExists(submission.getForms())) {
                    processEligibilityCategoryUpdate(submission, request, false);
                }
            }

            if (formType.equals(FormType.N400) && !(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, formType.getType()))) {
                BigDecimal calculatedFee = feeService.calculateFeeFor(submission.getFormType(),
                        submission.getEligibilityCategory(),
                        null);
                boolean isFeeExempt = submission.getFeeTotal() != null
                        && calculatedFee.compareTo(N400Fees.FEE_EXEMPT) == 0;
                if (!feeWaiverRequested || isFeeExempt)
                    updateFeeTotalOnCategoryChange(request.getEligibilityCategory() != null, submission, calculatedFee);

                if (feeWaiverRequested && isFeeExempt) {
                    submission.setUserRequestedFeeWaiver(false);
                    if (userHasFeeWaiverDocumentUploaded)
                        processFeeWaiverAndSupportDocsDelete(submission);
                    if (partialFeeWaiverRequested) {
                        submission.setUserRequestedPartialFeeWaiver(false);
                        processSupportDocsDelete(submission);
                    }
                }

                if (!isFeeExempt && feeWaiverRequested && !partialFeeWaiverRequested
                        && userHasFeeWaiverDocumentUploaded)
                    submission.setFeeTotal(N400Fees.FEE_EXEMPT);

                if (formExists(submission.getForms())) {
                    processEligibilityCategoryUpdate(submission, request, false);
                }
            }
        }
        return finalizeEligibilityCategoryUpdate(submission, formType, request);
    }

    private Submission finalizeEligibilityCategoryUpdate(Submission submission, FormType formType, EligibilityUpdateRequest request) {
        if (toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, formType.getType())) {
            if (!FormType.I765.equals(formType)) {
            submission.setUserRequestedFeeWaiver(false);
            }


            if (formExists(submission.getForms())) {
                processEligibilityCategoryUpdate(submission, request, true);
            }
        }

    	//Likely need to update this method to find all evidence groups in a submission, not just for the primary form
        if (submission.getEvidences() != null && !submission.getEvidences().isEmpty()) {
            var evidenceGroups = formService.retrieveEvidenceGroups(submission.getFormType().getType(),
            		request.getEligibilityCategory().getCategory());
            removeIrrelevantEvidence(submission, evidenceGroups);
        }

        resetAttestationFields(submission);

        auditService.addEvent(submission.getMyUscisId(), submission.getSubmissionId(),
                ActionPerformed.SELECT_ELIGIBILITY_CATEGORY,
                request.getEligibilityCategory().toString());

        return submissionDao.update(submission);
    }

    public Submission setResidencyStatus(String submissionId, String myUscisId, String orgMyUscisId, ResidencyStatus residencyStatus) {
        Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        submission.setIsUSCitizen(residencyStatus);

        Optional<SubmissionForm> submissionForm = submission.getForms()
        									.stream()
        									.filter((form) ->
                                                form.getType().equals(submission.getFormType().getType())
                                            )
        									.findFirst();
        if(submissionForm.isPresent()) {
        	submissionForm.get().setFormSpecificInfo(new I130FormSpecificInfo(residencyStatus));
        }

        Submission updatedSub = submissionDao.update(submission);
        if(submissionForm.isPresent()) {
        	sendPFVSValidationRequest(updatedSub, submissionForm.get().getId(), submissionForm.get().getS3Key());
        	validationService.deleteStatus(submissionForm.get().getId());
        }

        return updatedSub;
    }

    private void resetAttestationFields(Submission submission) {
        submission.setAttested(false);
        submission.setAttestationSignature(null);
        submission.setAttestedAt(null);
    }

    private void removeIrrelevantEvidence(Submission updatedSubmission, List<EvidenceGroup> evidenceGroups) throws S3DeleteObjectException {
        List<SubmissionEvidence> irrelevantEvidence = updatedSubmission.getEvidences().parallelStream()
                .filter(evidence -> evidenceGroups.parallelStream()
                        .noneMatch(group -> group.getId().equals(evidence.getEvidenceGroupType()))
                        && !evidence.getEvidenceGroupType().equals(FEE_WAIVER_EVIDENCE_GROUP))
                .toList();
        irrelevantEvidence
                .forEach(evidence -> {
                    removeEvidenceFromSubmission(evidence.getId(), updatedSubmission);

                    String s3Key = evidence.getS3Key();
                    boolean documentStillInUse = updatedSubmission.getEvidences().parallelStream()
                            .anyMatch(subEvidence -> subEvidence.getS3Key().equals(s3Key));

                    SubmissionEvidence feeWaiver = updatedSubmission.getFeeWaiver();
                    if (updatedSubmission.getUserRequestedFeeWaiver() && !documentStillInUse && feeWaiver != null)
                        documentStillInUse = feeWaiver.getS3Key().equals(s3Key);

                    if (!documentStillInUse)
                        s3Service.deleteS3Object(evidence.getS3Key(), true);
                });
    }

    void processEligibilityCategoryUpdate(Submission updatedSubmission, EligibilityUpdateRequest request, boolean pfvsValidations) {
        FormType formType = updatedSubmission.getFormType();

        SubmissionForm form = updatedSubmission.getForms().stream()
                .filter(f -> f.getType().equals(request.getFormType()))
                .findFirst()
                .orElse(null);
        if (form != null) {
            form.setEligibilityCategory(request.getEligibilityCategory());
            form.setEligibilitySubcategory(request.getEligibilitySubcategory());
            form.setEligibilitySubcategoryList(updatedSubmission.getEligibilitySubcategories());

            if(form.getS3Key() != null) {
            if(!pfvsValidations && form.getExtractedData() != null) {
                	 FieldValidator validator = categoryValidatorFactory.getValidator(formType);
                    validator.validate(updatedSubmission, FormFields.builder().formId(form.getId())
                            .eligibilityCategory(form.getExtractedData().getEligibilityCategory()).build());
               }
               else {
            	   validationService.deleteStatus(form.getId());
            	   log.info("Resending uploaded submission of type {} to validation service", formType.getType());
            	   sendPFVSValidationRequest(updatedSubmission, form.getId(), form.getS3Key());
               }

            }
        }
    }

    private void sendPFVSValidationRequest(Submission submission, String formId, String s3Key) {
    	Optional<SubmissionForm> parentForm = submission.getForms()
				.stream()
				.filter(form -> submission.getFormType().getType().equals(form.getType()))
				.findFirst();

    	SubmissionForm activeForm = submission.getForms()
				.stream()
				.filter(form -> formId.equals(form.getId()))
				.findFirst().orElseThrow(() -> new NoSuchElementException(String.format("Form Not Found: %s", formId)));

    	FormType requestedFormType = FormType.fromString(activeForm.getType());
    	String parentFormId = null;
    	if(parentForm.isPresent()) {
    		parentFormId = parentForm.get().getId();
    	}

        List<String> submissionFormIds = submission.getForms()
                                .stream()
                                .filter(form -> form.getUploadedAt() != null)
                                .map(form -> form.getId())
                                .toList();

        List<String> evidenceIds = new ArrayList<>();
        if(submission.getEvidences() != null) {
        	evidenceIds.addAll(submission.getEvidences()
                    .stream()
                    .map(ev -> ev.getId())
                    .toList());
        }
        if(submission.getFeeWaiver() != null) {
        	evidenceIds.add(submission.getFeeWaiver().getId());
        }

        log.info("Submission [{}] has the associated formIds: [{}] and associated evidenceIds: [{}]", submission.getSubmissionId(), submissionFormIds, evidenceIds);
        try(LogContext ctx = LogContext.put("submissionId", submission.getSubmissionId())
                .and("submissionFormIds", submissionFormIds.toString())
                .and("evidenceIds", evidenceIds.toString())) {
            log.info("Submission with associated formIds and associated evidenceIds");
        }

    	Integer benefitTypeCode = null;
        Integer applicationReasonCode = null;
        EligibilityCategoryEnum formEligibility = null;
        EligibilitySubcategoryEnum formSubEligibility = null;
        String clientUUID = null;
        if(activeForm.getEligibilityCategory() != null) {
            benefitTypeCode = (activeForm.getBenefitTypeCode() != null) ? activeForm.getBenefitTypeCode() :formService.retrieveBenefitTypeCodeByEligiblityCategory(activeForm.getType(), submission);
        	applicationReasonCode = activeForm.getApplicationReasonCode();
        	formEligibility = activeForm.getEligibilityCategory();
        	formSubEligibility = activeForm.getEligibilitySubcategory();
        }
        else if(submission.getEligibilityCategory() != null) {
        	benefitTypeCode = submission.getBenefitTypeCode();
        	applicationReasonCode = submission.getApplicationReaonCode();
        	formEligibility = submission.getEligibilityCategory();
        	formSubEligibility = submission.getEligibilitySubcategory();
        }

        if(submission.getClientInformation() != null) {
        	clientUUID = submission.getClientInformation().getClientId();
        }
        if(submission.getSelectedConcurrentForms() != null && !submission.getSelectedConcurrentForms().isEmpty() && activeForm.getClientId() != null) {
        	clientUUID = activeForm.getClientId();
        }

        Optional<AdditionalInformation> additionalInfoOptional =
                AdditionalInformationFactory.createAdditionalInformation(submission, formService, requestedFormType);

        AdditionalInformation additionalInfo = null;
        if (additionalInfoOptional.isPresent()) {
            additionalInfo = additionalInfoOptional.get();
        }

        String userGroupId = null;
        if(submission.getApplicant() != null && StringUtils.isNotBlank(submission.getApplicant().getUserGroupId())) {
        	userGroupId = submission.getApplicant().getUserGroupId();
        }
        if(activeForm.getClientId() != null && activeForm.getClientId().startsWith("O-")) {
        	userGroupId = activeForm.getClientId();
        }

        ValidationRequest validationRequest = new ValidationRequest(
                submission.getSubmissionId(),
                formId,
                parentFormId,
                submission.getMyUscisId(),
                userGroupId,
                clientUUID,
                s3Key,
                activeForm.getType(),
                submission.getFormType().getType(),
                benefitTypeCode,
                applicationReasonCode,
                additionalInfo,
                submissionFormIds,
                evidenceIds,
                submission.getSelectedConcurrentForms()
        );

        // log.info("SENDING SQS MESSAGE: {}", validationRequest);
        try(LogContext ctx = LogContext.put("sqsMessage", validationRequest.toString())) {
            log.info("SENDING SQS MESSAGE:");
        }

        sqsService.sendValidationRequest(
            validationRequest
        );
    }

	protected void sendEvidencePFVSValidationRequest(Submission submission, SubmissionEvidence submissionEvidence, PFVSEvidenceType evidenceValidatorType, AdditionalInformation additionalInformation) {
    	String requestFormType = submission.getFormType().getType();
    	List<String> submissionFormIds = List.of();
    	List<String> evidenceIds = List.of();

    	if(evidenceValidatorType.getToggle() != null && !toggleService.isToggleActive(evidenceValidatorType.getToggle(), requestFormType)) {
    		return;
    	}

    	if(submission.getForms() != null) {
    		submissionFormIds = submission.getForms()
                    .stream()
                    .map(form -> form.getId())
                    .toList();
    	}
		evidenceIds = submission.getEvidences()
				.stream()
				.map(ev -> ev.getId())
				.toList();

		log.info("Submission [{}] has the associated formIds: [{}] and associated evidenceIds: [{}]", submission.getSubmissionId(), submissionFormIds, evidenceIds);

        try(LogContext ctx = LogContext.put("submissionId", submission.getSubmissionId())
                .and("submissionFormIds", submissionFormIds.toString())
                .and("evidenceIds", evidenceIds.toString())) {
            log.info("Submission with associated formIds and associated evidenceIds");
        }
        Optional<SubmissionForm> form = Optional.ofNullable(submission.getForms())
            .orElseGet(Collections::emptyList)
            .stream()
            .filter(el -> el.getId().equals(submissionEvidence.getFormId()))
            .findFirst();

        ValidationRequest validationRequest = ValidationRequest.builder()
                .submissionId(submission.getSubmissionId())
                .benefitTypeCode(form.isPresent() ? form.get().getBenefitTypeCode() : null)
                .applicationReasonCode(form.isPresent() ? form.get().getApplicationReasonCode() : null)
                .formId(submissionEvidence.getId())
                .uuid(submission.getMyUscisId())
                .userGroupId(null)
                .s3Key(submissionEvidence.getS3Key())
                .formType(evidenceValidatorType.getPFVSFormTypeOverride() != null ? evidenceValidatorType.getPFVSFormTypeOverride() : evidenceValidatorType.getType())
                .submissionFormType(requestFormType)
                .submissionFormIds(submissionFormIds)
                .evidenceIds(evidenceIds)
                .additionalInfo(additionalInformation)
                .build();

        log.info("SENDING SQS MESSAGE: {}", validationRequest);

        sqsService.sendEvidenceValidationRequest(
            validationRequest
        );
    }
    private BigDecimal calculateTotalFee(Submission submission, boolean resetFeeWaiverFields) {
        return calculateTotalFee(submission, submission.getFormType(), submission.getEligibilityCategory(), resetFeeWaiverFields, resetFeeWaiverFields);
    }

    private BigDecimal calculateTotalFee(Submission updatedSubmission, FormType formType,
            EligibilityCategoryEnum eligibilityCategory, boolean deleteFeeWaiver, boolean resetFeeWaiverRequest) {
        if (deleteFeeWaiver) {
            processFeeWaiverAndSupportDocsDelete(updatedSubmission);
        }
        if (resetFeeWaiverRequest) {
            updatedSubmission.setUserRequestedFeeWaiver(false);
            if (FormType.N400.equals(formType)) {
                updatedSubmission.setUserRequestedPartialFeeWaiver(false);
            }
        }

        if (FormType.N400.equals(formType) && !(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, formType.getType()))) {
            return feeService.calculateFeeFor(formType, eligibilityCategory, null);
        } else if (toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, formType.getType())){

            // TODO refactor fee wiaver logic to be on the metadata
            if ((FormType.I765).equals(formType) && eligibilityCategory != null) {
            FeeStrategyOptions options = buildOptionsForI765(updatedSubmission, eligibilityCategory);
            setFeeWaiverEligibility(updatedSubmission, feeService.isEligibleForFeeWaiver(formType, eligibilityCategory, options), formType);
            }
            if (updatedSubmission.getForms() != null) {
                BigDecimal totalFee = BigDecimal.ZERO;
                for (SubmissionForm form : updatedSubmission.getForms()) {
                    if (form.getFeeTotal() != null) {
                        totalFee = totalFee.add(form.getFeeTotal());
                    }
                }
                return totalFee;
            } else {
                return BigDecimal.ZERO;
            }
        } else if (FormType.I765.equals(formType) && eligibilityCategory != null) {
            FeeStrategyOptions options = buildOptionsForI765(updatedSubmission, eligibilityCategory);
            setFeeWaiverEligibility(updatedSubmission, feeService.isEligibleForFeeWaiver(formType, eligibilityCategory, options), formType);
            return feeService.calculateFeeFor(formType, eligibilityCategory, options);
    } else {
        return I765Fees.FEE_EXEMPT;
        }
    }

    public FeeStrategyOptions buildOptionsForI765(Submission submission, EligibilityCategoryEnum eligibilityCategory) {
        List<SubmissionForm> forms = submission.getForms();
        FeeStrategyOptions options = new I765FeeStrategyOptions(false, false, false, submission.getReasonForFiling(), submission.getUserRequestedFeeWaiver());

        if (I765EligibilityCategory.C9.equals(eligibilityCategory)) {
            C9UpdateRequest c9UpdateRequest = submission.getC9updateRequest();
            options = new I765C9FeeStrategyOptions(c9UpdateRequest.getOptions(), submission.getUserRequestedFeeWaiver());
        } else if (I765EligibilityCategory.isC11Category(eligibilityCategory)) {
            String reasonForFiling = submission.getReasonForFiling();
            if (formExists(forms)) {
                ExtractedFormEntries extractedData = forms.get(0).getExtractedData();
                if (extractedData != null) {
                    reasonForFiling = extractedData.getReasonForFiling();
                }
            }

            options = new I765C11FeeStrategyOptions(
                    submission.getImmvi() != null ? submission.getImmvi() : false,
                    I765EligibilityCategory.C11AFGHAN.equals(eligibilityCategory),
                    I765EligibilityCategory.C11UKRAINE.equals(eligibilityCategory),
                    reasonForFiling,
                    submission.getUserRequestedFeeWaiver());
        } else {
            if (formExists(forms)) {
                ExtractedFormEntries extractedData = forms.get(0).getExtractedData();
                if (extractedData != null) {
                    options = new I765FeeStrategyOptions(extractedData.isSalvadorianABCEligible(), false, false, extractedData.getReasonForFiling(), submission.getUserRequestedFeeWaiver());
                }
            }
        }
        return options;
    }

    private void setFeeWaiverEligibility(Submission submission, boolean eligibleForFeeWaiver, FormType formType) {
        submission.setUserIsEligibleForFeeWaiver(eligibleForFeeWaiver);
    }


    public Optional<Submission> retrieveSubmissionByManifestId(String manifestId) {
        Optional<Submission> optionalSubmission = submissionDao
                .getById(lockboxGatewayClient.mapManifestToSubmissionId(manifestId.toLowerCase()).block());
        optionalSubmission.ifPresent(submission -> {
            if (submission.getEvidences() != null)
                submission.setEvidences(submission.getEvidences().parallelStream().map(evidence -> {
                    evidence.setEvidenceGroupType(null);
                    evidence = MapEvidenceTypes.mapEOIRBIAEvidence(evidence);

                    return evidence;
                }).toList());

            if (submission.getManifestId() == null)
                submission.setManifestId(manifestId);

            ClientInformation clientInformation = submission.getClientInformation();

            if (submission.getApplicant().getAccountType() != null) {
                if (submission.getApplicant().getAccountType().equals(AccountType.REPRESENTATIVE)) {
                    submission.getApplicant().setAccountType(AccountType.APPLICANT);
                    submission.getApplicant()
                            .setMyUscisId(clientInformation != null ? clientInformation.getClientId() : null);
                    submission.setClientInformation(null);
                }
            } else {
                submission.getApplicant().setAccountType(AccountType.APPLICANT);
            }

            submission.setFormName(null);
        });

        return optionalSubmission;
    }

    public Submission updateEvidence(Submission submission, String id, String type) {
        if (submission.getEvidences() != null) {
            submission.getEvidences().stream().filter(evidence -> evidence.getId().equals(id))
                    .findFirst().ifPresent((evidence) -> evidence.setType(type));
        }

        return submissionDao.update(submission);
    }

    // TODO deprecated function after moving to TDSS
    public void updateSubmissionWithFormFields(FormFields formFields, FormType formType) {
        ExtractedFormEntries entries = ExtractedFormEntries.builder()
                .eligibilityCategory(formFields.eligibilityCategory())
                .reasonForFiling(formType == FormType.I765
                        ? ReasonForFiling.fromFormEntry(formFields.reasonForApplySelection()).toString()
                        : formFields.reasonForApplySelection())                .isSalvadorianABCEligible(formFields.abcBenefitsApplied()).build();

        Submission submission = retrieveSubmission(formFields.submissionId());
        if (submission.getStatus() != SubmissionState.DRAFT) {
            log.error("Submission update trigger for a submission in draft:  " + formFields.submissionId());
            throw InvalidStateException.builder().message("Unable to update form fields, submission is not a draft").build();
        }

        Optional<SubmissionForm> optionalForm = submission.getForms().parallelStream()
                .filter(form -> form.getId().equals(formFields.formId())).findFirst();

        if (optionalForm.isPresent()) {
            SubmissionForm form = optionalForm.get();
            form.setExtractedData(entries);

            if (submission.getFormType().equals(FormType.I765)) {
                EligibilityCategoryEnum submissionEligibility = submission.getEligibilityCategory();
                FeeStrategyOptions options = I765EligibilityCategory.isC11Category(submissionEligibility)
                        ? I765C11FeeStrategyOptions.builder()
                                .isAfghan(I765EligibilityCategory.C11AFGHAN.equals(submissionEligibility))
                                .isImmvi(submission.getImmvi())
                                .reasonForFiling(entries.getReasonForFiling())
                                .isUkraine(I765EligibilityCategory.C11UKRAINE.equals(submissionEligibility))
                                .userRequestedFeeWaiver(submission.getUserRequestedFeeWaiver()).build()
                        : I765FeeStrategyOptions.builder().hasPendingI589(false).i485PaidInFull(false)
                                .isSalvadorianABCEligible(entries.isSalvadorianABCEligible())
                                .reasonForFiling(entries.getReasonForFiling())
                                .userRequestedFeeWaiver(submission.getUserRequestedFeeWaiver()).build();
                BigDecimal calculatedFee = feeService.calculateFeeFor(submission.getFormType(),
                        submissionEligibility,
                        options);

                boolean shouldResetFeeWaiver = feeService.isEligibleForFeeWaiver(submission.getFormType(), submission.getEligibilityCategory(), options);
                submission.setUserIsEligibleForFeeWaiver(shouldResetFeeWaiver);
                if (submission.getUserRequestedFeeWaiver() && calculatedFee.compareTo(I765Fees.FEE_EXEMPT) == 0) {
                    processFeeWaiverAndSupportDocsDelete(submission);
                    submission.setUserRequestedFeeWaiver(false);
                } else {
                    submission.setFeeTotal(calculatedFee);
                }
            }
        submissionDao.update(submission);
        }
    }

    private boolean formExists(List<SubmissionForm> forms) {
    	return forms != null  && !forms.isEmpty() && forms.stream().anyMatch(form -> form.getS3Key() != null);
    }

    public Submission attestForm(String myUscisId, String orgMyUscisId, String submissionId, String formId,
        Boolean attested, String attestationSignature) {

    Submission updatedSubmission = setAttestationFields(submissionId, myUscisId, orgMyUscisId, attested, attestationSignature);
    return updatedSubmission;
}

    private Submission setAttestationFields(String submissionId, String myUscisId, String orgMyUscisId, Boolean attested, String attestationSignature) {
    	Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

        if (Boolean.TRUE.equals(attested)) {
        	submission.setAttested(attested);
            submission.setAttestationSignature(attestationSignature);
            submission.setAttestedAt(systemClock.getSystemTime());
        } else {
            resetAttestationFields(submission);
        }

        return submissionDao.update(submission);
    }

    public Mono<String> completeSubmission(String myUscisId, String orgMyUscisId, String submissionId)
            throws PaymentRequiredException {
        Submission submission = submissionDao.getDraftById(myUscisId, orgMyUscisId, submissionId)
                .orElseThrow(() -> new NoSuchElementException("Submission Not Found"));

        if (submission.getFormType().isAutoIngested() || paymentServiceClient.isAuthorized(submissionId, submission.getFeeTotal(), submission.getFormType().getType())) {

            if (!Boolean.TRUE.equals(submission.getUserRequestedFeeWaiver())) {
                // Last opportunity to clean up dangling files, otherwise should no-op
                processFeeWaiverAndSupportDocsDelete(submission);
            }

            LockboxTransmission transmission = LockboxTransmissionUtil.lockboxTransmissionFromSubmission(submission);
            submission.setStatus(SubmissionState.RECEIVED);
            submissionDao.update(submission);

            log.info("Submitting submission with id {} to Lockbox Gateway", submissionId);

            return lockboxGatewayClient.sendTransmission(transmission)
                    .doOnSuccess(manifestId -> {
                        submission.setManifestId(manifestId);
                        submission.setLockboxStatus(LockboxStatuses.PENDING);
                        submission.setSubmittedAt(systemClock.getSystemTime());
                        submissionDao.update(submission);
                        auditService.addEvent(myUscisId, submissionId, ActionPerformed.MANIFEST_SENT,
                                SubmissionState.PUBLISHED,
                                null);

                    })
                    .doOnError(e -> log.error("Error while sending submission to lockbox {}", submissionId))
                    .doOnSuccess(res -> {
                		myUscisCacheManagementClient.publishCaseChangeEvent(submission);
                    });

        } else {

            log.warn("Unable to process submission {}, payment information is not complete.", submissionId);
            throw new HttpServerErrorException(HttpStatusCode.valueOf(422), "Payment has not been authorized");
        }
    }

    public List<String> getValidationStatus(String myUscisId, FinalSubmissionDto finalSubmissionDto) {
        List<String> validationErrors = new ArrayList<>();

        if(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, finalSubmissionDto.getType().getType())) {
            if(finalSubmissionDto.getValidations().stream().anyMatch(val -> val.validator().name().equals(ValidatorEnum.PFVS.name()))) {
                finalSubmissionDto.getValidations().stream().filter(val -> !val.validator().name().equals(ValidatorEnum.SIGNATURE.name())).forEach(val -> {
                    if(val.result().equals(ValidationResultEnum.FAIL)) {
                        validationErrors.add(val.reasons().toString());
                    } else if(val.result().equals(ValidationResultEnum.PENDING)) {
                        validationErrors.add(String.format("{} validation is still pending", val.validator()));
                    }
                });
            } else {
                validationErrors.add("PFVS Validation status could not be retrieved");
            }
            log.info("Submission form(s) contain following validation errors: {}", validationErrors.toString());
        }
        return validationErrors;
    }

    public WatermarkerStatus.StatusEnum getAttestationStatus(String submissionId, String formId) {
        Submission submission = retrieveSubmission(submissionId);

        return submission.getForms().stream().filter(form -> form.getId().equals(formId)).findFirst().orElseThrow()
                .getAttestationStatus();
    }

    public FinalTransmissionStatus getFinalTransmissionStatus(String myUscisId, String submissionId) {
        Submission submission = retrieveSubmission(submissionId);
        FinalTransmissionStatus transmissionStatus = submission.getTransmissionStatus();
        if (transmissionStatus == null)
            return FinalTransmissionStatus.builder().status(FinalTransmissionStatus.StatusEnum.IN_PROGRESS).build();
        return transmissionStatus;
    }

    public void updateTransmissionStatus(String submissionId, FinalTransmissionStatus.StatusEnum status,
            String message) {
        Submission submission = retrieveSubmission(submissionId);

        FinalTransmissionStatus finalTransmissionStatus = FinalTransmissionStatus.builder()
                .status(status).message(message).build();

        submission.setTransmissionStatus(finalTransmissionStatus);
        submissionDao.update(submission);

        log.info("Updating final transmission status for submissionId: {} status: {}",
                submissionId, status);
    }

    public void updateFee(String submissionId, BigDecimal feeTotal) {
        var submission = retrieveSubmission(submissionId);
        if (submission.getStatus() == SubmissionState.DRAFT) {
            submission.setFeeTotal(feeTotal);
            submissionDao.update(submission);
        } else {
            log.error("Attempt to update fee on a submission that is no longer a draft {}", submissionId);
        }
    }



    public void esignForm(String myUSCISId, String orgMyUscisId, String submissionId, String formId, EsignData esignData){
    	setAttestationFields(submissionId, myUSCISId, orgMyUscisId, true, esignData.applicantFullName());
        sqsService.sendEsignRequest(
            new EsignRequest(
            	submissionId,
                formId,
                "PETITIONER",
                myUSCISId,
                esignData
            )
        );

    }

    // Currently used for the I-751 only
    public Submission updateEligibilitySubcategories(String submissionId, String myUscisId, String orgMyUscisId, List<EligibilitySubcategoryEnum> eligibilitySubcategories) {
        validateSameGroup(eligibilitySubcategories);

        Submission submission = retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        submission.setEligibilitySubcategories(eligibilitySubcategories);

        if(FormType.I751.equals(submission.getFormType())) {
            submission.setUserIsEligibleForFeeWaiver(is751SelectedSubCategoriesFeewaivable(eligibilitySubcategories));
        }

        if (toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, submission.getFormType().getType())) {
            submission.setUserRequestedFeeWaiver(false);
            if (formExists(submission.getForms())) {
                processEligibilityCategoryUpdate(submission, new EligibilityUpdateRequest(submission.getEligibilityCategory(), submission.getEligibilitySubcategory(), null, null, submission.getFormType().getType()), true);
            }
        }
         String  eligiblitySubCategories = submission.getEligibilitySubcategories().stream().map(EligibilitySubcategoryEnum::getCategory).reduce((a,b) -> a + ", " + b).orElse("");

        auditService.addEvent(submission.getMyUscisId(), submission.getSubmissionId(),
        ActionPerformed.SELECT_ELIGIBILITY_CATEGORY,
        eligiblitySubCategories);

        return submissionDao.update(submission);
    }

    public Submission resetSubmissionToDraft(String submissionId) {
    	Submission submission = retrieveSubmission(submissionId);
    	submission.setStatus(SubmissionState.DRAFT);
    	return submissionDao.update(submission);
    }

    private void validateSameGroup(List<EligibilitySubcategoryEnum> eligibilitySubcategories){
        boolean hasGroupA = eligibilitySubcategories.stream().anyMatch(GROUP_A::contains);
        boolean hasGroupB = eligibilitySubcategories.stream().anyMatch(GROUP_B::contains);

        if(hasGroupA && hasGroupB){
            throw new SubmissionBadException( "subcategories can only be in the same group");
        }
    };

    private boolean is751SelectedSubCategoriesFeewaivable(List<EligibilitySubcategoryEnum> eligibilitySubcategories) {
        // This function should be looking at the metadata and not exist
        Set<EligibilitySubcategoryEnum> FEE_WAIVER_VALUES = Set.of(
            I751WaiverOrIndividualFilingSubcategory.SPOUSE_DECEASED,
            I751WaiverOrIndividualFilingSubcategory.DIVORCE_ANNULMENT,
            I751WaiverOrIndividualFilingSubcategory.EXTREME_HARDSHIP);
            return eligibilitySubcategories.stream().anyMatch(FEE_WAIVER_VALUES::contains);
    }

    private boolean is751SelectedCategoryFeewaivable(EligibilityCategoryEnum eligibilityCategoryEnum) {
        Set<EligibilityCategoryEnum> FEE_WAIVER_VALUES = Set.of(
            I751EligibilityCategory.SPOUSE,
            I751EligibilityCategory.MY_PARENT_SPOUSE);
        return FEE_WAIVER_VALUES.contains(eligibilityCategoryEnum);
    }

    public Submission updateFormSpecificInfo(Submission submission, FormSpecificInfo formSpecificInfo){
        return updateFormSpecificInfo(submission, formSpecificInfo, true);
    }

    public Submission updateFormSpecificInfo(Submission submission, FormSpecificInfo formSpecificInfo, boolean revalidate) {
        if(submission.getFormType().equals(formSpecificInfo.getFormType())) {
        	submission.setFormSpecificInfo(formSpecificInfo);
        }

        SubmissionForm submissionForm = submission.getForms()
                .stream()
                .filter(form -> form.getType().equals(formSpecificInfo.getFormType().getType()))
                .findFirst().orElseThrow(() -> new NoSuchElementException(String.format("Form of type %s Not Found", formSpecificInfo.getFormType().getType())));
        submissionForm.setFormSpecificInfo(formSpecificInfo);

        if(revalidate){
            validateFormSpecificInfo(submission, formSpecificInfo);
        }
        return submission;
    }

    public Submission updateFormSpecificInfo(String submissionId, FormSpecificInfo formSpecificInfo) {
        return updateFormSpecificInfo(submissionId, formSpecificInfo , true);
    }

    public Submission updateFormSpecificInfo(String submissionId, FormSpecificInfo formSpecificInfo, boolean revalidate) {
        Submission submission = retrieveSubmission(submissionId);

        submission = updateFormSpecificInfo(submission, formSpecificInfo, revalidate);
        return submissionDao.update(submission);
    }

    private void validateFormSpecificInfo(Submission submission, FormSpecificInfo formSpecificInfo) {
        if (FormType.I140.equals(formSpecificInfo.getFormType())) {
                String laborCertificationEvidence = "labor-certification";
                if (formSpecificInfo instanceof I140FormSpecificInfo && submission.getEvidences() != null) {
                    Optional<SubmissionEvidence> evidence9089FD = submission.getEvidences().stream()
                            .filter(el -> laborCertificationEvidence.equals(el.getEvidenceGroupType()))
                            .findFirst();
                            finalDeterminationLogic(submission, evidence9089FD);
                }
        }
		if(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, submission.getFormType().getType())) {
			Optional<SubmissionForm> submissionForm = submission.getForms()
                    .stream()
                    .filter(form -> form.getType().equals(formSpecificInfo.getFormType().getType()) &&
                            !isBlank(form.getS3Key()))
                    .findFirst();

            if(submissionForm.isPresent()) {
                sendPFVSValidationRequest(submission, submissionForm.get().getId(), submissionForm.get().getS3Key());
                validationService.deleteStatus(submissionForm.get().getId());
            }
        }
    }

    private void finalDeterminationLogic(Submission submission, Optional<SubmissionEvidence> evidence9089FD) {
        I140FormSpecificInfo i140FormSpecificInfo = ((I140FormSpecificInfo) submission.getFormSpecificInfo());

        if (evidence9089FD.isPresent() && !isBlank(i140FormSpecificInfo.getDolNumber()) && dolNumberRequired(submission)) {
            ETA9089AdditionalInformation eta9089AdditionalInformation = new ETA9089AdditionalInformation();
            eta9089AdditionalInformation.setDolNumber(i140FormSpecificInfo.getDolNumber());

            validationService.deleteStatus(evidence9089FD.get().getId());
            log.info("Resending uploaded evidence of type {} to validation service", evidence9089FD.get().getType());
            sendEvidencePFVSValidationRequest(submission, evidence9089FD.get(), PFVSEvidenceType.E9089FD, eta9089AdditionalInformation);
    }
}

    private boolean dolNumberRequired(Submission submission) {
        I140FormSpecificInfo i140FormSpecificInfo = ((I140FormSpecificInfo) submission.getFormSpecificInfo());
       return   !i140FormSpecificInfo.getIsScheduleA();
    }

    public Submission resetFormSpecificInfo(String submissionId) {
        Submission submission = retrieveSubmission(submissionId);
        submission.setFormSpecificInfo(null);
        return submissionDao.update(submission);

    }


    public boolean canUserPayAndSubmit(String myUscisId, String submissionId) {
    	Submission submission = retrieveSubmission(submissionId);
    	if(FormType.ORGANIZATION_FILED_FORM_TYPES.contains(submission.getFormType())) {
    		AccountTypeResponse response = peepsService.retrieveAccountType(myUscisId);
    		if(response != null && response.accountType().equals(AccountType.REPRESENTATIVE)) {
    			return true;
    		}
            else if(response != null && response.accountType().equals(AccountType.APPLICANT)) {
    			return true;
    		}
    		UserGroupRole userGroupRole = userGroupServiceClient.getOrganizationGroupRole(myUscisId);
    		return userGroupRole != null && userGroupRole.getRoles().contains("user_group_org_admin");
        }
    	return true;
    }

    public List<Admin> getAdministrators(String myUscisId, String submissionId) {
    	String clientId = getClientId(submissionId);
    	if(clientId != null) {
    		return accountsDataClient.getAdministrators(myUscisId, clientId);
    	}
    	return Collections.emptyList();
    }

    private String getClientId(String submissionId) {
    	Submission submission = retrieveSubmission(submissionId);
    	if(submission != null) {
    		if(submission.getApplicant() != null && submission.getApplicant().getUserGroupId() != null) {
    			return submission.getApplicant().getUserGroupId();
    		} else if(submission.getClientInformation() != null && submission.getClientInformation().getClientId() != null) {
    			return submission.getClientInformation().getClientId();
    		}
    	}
    	return null;
    }

    public String getOrgId(String myUscisId) {
    	UserGroupRole organizationGroupRole = userGroupServiceClient.getOrganizationGroupRole(myUscisId);
    	if(organizationGroupRole == null) {
    		return null;
    	}
    	return organizationGroupRole.getUserGroupId();
    }

    public void sendNotificationToAdministrator(String myUscisId, String submissionId, List<String> uuids) {
    	Submission submission = retrieveSubmission(submissionId);
    	submission.setSentNotify(true);
    	submissionDao.update(submission);
    	accountsDataClient.notifyAdministrators(myUscisId, submissionId, uuids);
    }

    public void validateSubmission(String myUscisId, String submissionId) {
    	log.info("Attempting to send PFVS validation request for submission {}", submissionId);
    	Submission submission = retrieveSubmissionByIdAndUscisId(submissionId, myUscisId, null);
    	for(SubmissionForm submissionForm : submission.getForms()) {
    		if(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, submission.getFormType().getType())) {
    			log.info("Sending validate request to PFVS for submission form {}", submissionForm.getId());
    			sendPFVSValidationRequest(submission, submissionForm.getId(), submissionForm.getS3Key());
    		} else {
    			log.error("The submission form {} is not supported by PFVS, will not send validate request.", submissionForm.getId());
    		}
    	}
    }

    public Map<String, String> getSubmissionICAMUUIDs(Submission submission) {
        Map<String, String> formClientIdMap = new HashMap<>();
        for(SubmissionForm form : submission.getForms()) {
            String clientId = form.getClientId() == null ? submission.getMyUscisId() : form.getClientId();
            formClientIdMap.put(getELISFormTypeName(form.getType()), clientId);
        }
        return formClientIdMap;
    }

    private String getELISFormTypeName(String formType) {
        if(I129_VARIANTS.contains(formType)) {
            return "I-129";
        }
        return formType;
    }

}