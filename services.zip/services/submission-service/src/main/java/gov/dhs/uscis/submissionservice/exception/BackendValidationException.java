package gov.dhs.uscis.submissionservice.exception;

public class BackendValidationException extends RuntimeException{
    public BackendValidationException(String errorMessage) {
        super(errorMessage);
    }
}
