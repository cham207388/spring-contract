package gov.dhs.uscis.submissionservice.validators;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = NoMissingEvidenceValidator.class)
public @interface NoMissingEvidence {
    String message() default "\"Missing Evidence or File\"";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
