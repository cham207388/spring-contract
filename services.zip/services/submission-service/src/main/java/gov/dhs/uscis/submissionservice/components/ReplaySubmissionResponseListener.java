package gov.dhs.uscis.submissionservice.components;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.models.ReplaySubmissionRequest;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;
import reactor.core.publisher.Mono;

@Component
public class ReplaySubmissionResponseListener implements MessageListener {

	private Logger logger = LoggerFactory.getLogger(getClass());
	private ObjectMapper mapper = new ObjectMapper();
	private SubmissionService service;
    private AuditService auditService;
	

	public ReplaySubmissionResponseListener(SubmissionService service, AuditService auditService) {
		this.service = service;
        this.auditService = auditService;
	}


	@Override
	public void onMessage(Message message) {
		try {
			TextMessage textMessage = (TextMessage) message;
			MDC.put("traceId", UUID.randomUUID().toString());
			ReplaySubmissionRequest request = mapper.readValue(textMessage.getText(), ReplaySubmissionRequest.class);
            logger.info("SQS Message: {}", request);
            Submission refreshedSubmission = service.resetSubmissionToDraft(request.submissionId());
			String completeSubmissionResponse = service.completeSubmission(request.myUscisId(), null, request.submissionId()).block();
			logger.info("Replay Submission Response: {} - {}",request.submissionId(),completeSubmissionResponse);
            auditService.addEvent(request.myUscisId(), request.submissionId(), ActionPerformed.SUBMISSION_REPLAYED, SubmissionState.PUBLISHED, null);
            textMessage.acknowledge();
		} catch (Exception e) {
			logger.info("Error Processing Record Replay: {}",  e.getMessage());
		} finally {
			MDC.clear();
		}

	}

}
