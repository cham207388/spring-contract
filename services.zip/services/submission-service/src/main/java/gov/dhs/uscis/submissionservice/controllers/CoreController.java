package gov.dhs.uscis.submissionservice.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.models.dto.CoreData;
import gov.dhs.uscis.submissionservice.services.CoreService;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Core MetaData", description = "Global configurations for platform")
@RestController
@RequestMapping("/api/v1/metadata")
public class CoreController {

    private final CoreService coreService;

    public CoreController(CoreService coreService) {
        this.coreService = coreService;
    }

    @GetMapping("/core")
    public ResponseEntity<CoreData> retrieveFormMetaData() {
        CoreData coreMetaData = coreService.getCoreMetaData();
        if (coreMetaData != null)
            return ResponseEntity.ok().body(coreMetaData);
        else
            return ResponseEntity.notFound().build();
    }

}