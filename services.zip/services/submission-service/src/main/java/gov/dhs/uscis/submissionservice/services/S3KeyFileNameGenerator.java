package gov.dhs.uscis.submissionservice.services;

public interface S3KeyFileNameGenerator{
    String generateName(String extension );
}