package gov.dhs.uscis.submissionservice.models.submissionStatus;

import java.util.List;

import lombok.Builder;

@Builder
public record SubmissionStatusResponse(
    List<String> submissionErrors,
    List<ErrorGroup> formErrors,
    List<ErrorGroup> evidenceErrors) {
}
