package gov.dhs.uscis.submissionservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class ConcurrentFormPair {

    public ConcurrentFormPair(String primaryFormType, String concurrentFormType) {
        this.primaryFormType = primaryFormType;
        this.concurrentFormType = concurrentFormType;
    }

    public ConcurrentFormPair(){}

    @Column(name = "primary_form_type")
    private String primaryFormType;

    @Column(name = "concurrent_form_type")
    private String concurrentFormType;
    
    public String getPrimaryFormType() {
        return this.concurrentFormType;
    }
    
    public String getConcurrentFormType() {
        return this.concurrentFormType;
    }
}