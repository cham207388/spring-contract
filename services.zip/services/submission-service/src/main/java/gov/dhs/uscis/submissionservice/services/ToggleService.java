package gov.dhs.uscis.submissionservice.services;

import java.util.Optional;

import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.submissionservice.entity.Toggle;
import gov.dhs.uscis.submissionservice.entity.ToggleFormTypeOverride;
import gov.dhs.uscis.submissionservice.exception.ToggleNotFoundException;
import gov.dhs.uscis.submissionservice.repository.ToggleFormTypeOverrideRepository;
import gov.dhs.uscis.submissionservice.repository.ToggleRepository;
import lombok.extern.slf4j.Slf4j;
import java.util.List;

@Slf4j
@Service
public class ToggleService {

	private final ToggleRepository toggleRepository;
	private final ToggleFormTypeOverrideRepository toggleFormTypeOverrideRepository;

	public ToggleService(ToggleRepository toggleRepository, ToggleFormTypeOverrideRepository toggleFormTypeOverrideRepository) {
		this.toggleRepository = toggleRepository;
		this.toggleFormTypeOverrideRepository = toggleFormTypeOverrideRepository;
	}

	public boolean isToggleActive(ToggleEnum toggle, String formType){
		Optional<ToggleFormTypeOverride> formToggle = toggleFormTypeOverrideRepository.findByIdToggleNameAndIdFormType(toggle.getName(), formType);
		if(formToggle.isPresent()) {
			return formToggle.get().isActive();
		}
		else {
			return isToggleActiveUniversal(toggle);
		}
	}

    public boolean isToggleActive(String toggleName, String formType) {
        Optional<ToggleFormTypeOverride> formToggle = toggleFormTypeOverrideRepository.findByIdToggleNameAndIdFormType(toggleName, formType);
		if(formToggle.isPresent()) {
			return formToggle.get().isActive();
		}
		else {
			return isToggleActiveUniversal(toggleName);
		}
    }

    public boolean isToggleActiveUniversal(String toggleName) {
		Optional<Toggle> universalToggle = toggleRepository.findById(toggleName);
		if(universalToggle.isPresent()) {
			return universalToggle.get().isActive();
		}
		throw new ToggleNotFoundException(toggleName);
	}
	
	public boolean isToggleActiveUniversal(ToggleEnum toggle) {
		Optional<Toggle> universalToggle = toggleRepository.findById(toggle.getName());
		if(universalToggle.isPresent()) {
			return universalToggle.get().isActive();
		}
		throw new ToggleNotFoundException(toggle.getName());
	}
    
}
