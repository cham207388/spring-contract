package gov.dhs.uscis.submissionservice.validators;

import gov.dhs.uscis.submissionservice.validators.i765.receiptProfile.ReceiptProfile;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProfileResponse {
    private ReceiptProfile data;
    private String error;
}
