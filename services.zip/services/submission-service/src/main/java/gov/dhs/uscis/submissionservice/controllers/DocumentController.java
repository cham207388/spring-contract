package gov.dhs.uscis.submissionservice.controllers;

import static java.util.Collections.emptyList;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import org.springframework.http.MediaType;
import org.springframework.http.MediaTypeFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.models.EvidenceGroup;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.UpdateSubmissionResponse;
import gov.dhs.uscis.intake.models.UploadResponse;
import gov.dhs.uscis.intake.models.dto.SubmissionDto;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.submissionservice.exception.NoFormInSubmissionException;
import gov.dhs.uscis.submissionservice.io.MultipartInputStreamFileResource;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceResponse;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import gov.dhs.uscis.submissionservice.models.dto.S3FileInfo;
import gov.dhs.uscis.submissionservice.models.dto.SubmissionMapper;
import gov.dhs.uscis.submissionservice.models.elis.ElisPhotoValidationError;
import gov.dhs.uscis.submissionservice.services.ElisService;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.services.S3Service;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.validators.ValidPdfDimensions;
import gov.dhs.uscis.submissionservice.validators.backend.UploadEvidenceValidator;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.Part;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import jakarta.validation.Validator;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "Upload", description = "Submission Upload API's")
@RestController
@Validated
@RequestMapping("/api/v1/{myUscisId}/submissions")
public class DocumentController {

    private S3Service s3Service;
    private UploadEvidenceValidator uploadEvidenceValidator;
    private SubmissionService submissionService;
    private ElisService elisService;
    private ObjectMapper objectMapper;
    private AuditService auditService;
    private FormService formService;
    private Validator validator;

    public DocumentController(
            S3Service s3Service,
            UploadEvidenceValidator uploadEvidenceValidator,
            SubmissionService submissionService,
            ElisService elisService,
            ObjectMapper objectMapper,
            AuditService auditService,
            FormService formService,
            Validator validator) {
        this.s3Service = s3Service;
        this.uploadEvidenceValidator = uploadEvidenceValidator;
        this.submissionService = submissionService;
        this.elisService = elisService;
        this.objectMapper = objectMapper;
        this.auditService = auditService;
        this.formService = formService;
        this.validator = validator;
    }

    @PostMapping(path = "/{submissionId}/form", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public UploadResponse uploadForm(@RequestPart("file") MultipartFile file,
            @Valid @RequestPart("uploadRequest") UploadRequest uploadRequest,
            @PathVariable("myUscisId") String myUscisId,
            @PathVariable("submissionId") String submissionId,
            @RequestParam(value = "orgMyUscisId", required = false) String orgMyUscisId)
            throws IOException {
        log.info("In uploadForm method for submissionId: {} and formtype: {} an File: {}", submissionId,
                uploadRequest.formType(), file);

        Submission submission = submissionService.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        Submission updatedSubmission = submissionService.updateSubmissionWithForm(submission, uploadRequest, file);
        SubmissionForm submissionForm = updatedSubmission.getForms().stream()
                .filter(form -> form.getType().equals(uploadRequest.formType())).findFirst().orElseThrow();
        String artifactId = submissionForm.getS3Key().split("/")[submissionForm.getS3Key().split("/").length - 1];
        return new UploadResponse(submissionForm.getId(), artifactId, submissionForm.getUploadedAt());
    }


    @GetMapping("/{submissionId}/form/{formId}")
    public ResponseEntity<byte[]> downloadForm(
            @PathVariable("myUscisId") String myUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("formId") String formId) {
        Submission submission = submissionService.retrieveSubmission(submissionId);

        String s3Key = submission.getForms().stream()
                .filter(form -> formId.equals(form.getId()))
                .findFirst()
                .orElseThrow(() -> new NoFormInSubmissionException("No such form in this submission"))
                .getS3Key();

        byte[] body = s3Service.getFileData(s3Key, true);

        return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).body(body);
    }

    @GetMapping("/{submissionId}/form/attested")
    public ResponseEntity<byte[]> downloadAttestedForm(
            @PathVariable("myUscisId") String myUscisId,
            @PathVariable("submissionId") String submissionId) {
        Submission submission = submissionService.retrieveSubmission(submissionId);
        String s3Key = submission.getForms().get(0).getAttestedS3Key();
        byte[] body = s3Service.getFileData(s3Key, true);

        return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).body(body);
    }

    @GetMapping("/{submissionId}/evidences/{evidenceId}/{fileName}")
    public ResponseEntity<byte[]> downloadEvidence(
            @PathVariable("myUscisId") String myUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("evidenceId") String evidenceId,
            @PathVariable("fileName") String fileName) {
        Submission submission = submissionService.retrieveSubmission(submissionId);
        String s3Key;

        SubmissionEvidence feeWaiver = submission.getFeeWaiver();
        if (feeWaiver != null && feeWaiver.getId().equals(evidenceId)) {

            s3Key = feeWaiver.getS3Key();
        } else {
            var submissionEvidence = submission.getEvidences().stream()
                    .filter(evidence -> evidence.getId().equals(evidenceId))
                    .findFirst()
                    .orElseThrow();
            s3Key = submissionEvidence.getS3Key();
        }

        final File file = new File(fileName);
        MediaType mimeTypeOptional = MediaTypeFactory.getMediaType(file.getName()).get();
        byte[] body = s3Service.getFileData(s3Key, false);

        return ResponseEntity.ok()
                .contentType(mimeTypeOptional)
                .body(body);
    }

    @PostMapping(path = "/{submissionId}/evidence/{selectedFormType}", consumes = {
            MediaType.MULTIPART_FORM_DATA_VALUE })
    public ResponseEntity<List<UploadEvidenceResponse>> uploadEvidence(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value = "orgMyUscisId", required = false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("selectedFormType") String selectedFormType,
            @RequestParam(value = "formId", required = false) String formId,
            EvidenceRequest request) throws IOException {
         Set<ConstraintViolation<EvidenceRequest>> violations = validator.validate(request);
      if (!violations.isEmpty()) {
            violations.forEach(violation -> 
        log.error("Validation failed on field '{}': {}", 
            violation.getPropertyPath(), 
            violation.getMessage())
    );
     throw new ConstraintViolationException(violations);
        }
        uploadEvidenceValidator.validateEvidenceWithBackendData(request, selectedFormType);
        Submission submission = request.submission();

        if (formId == null)
            formId = submission.getForms().stream().filter(form -> form.getType().equals(selectedFormType)).findFirst()
                    .get().getId();
        List<Part> files = request.files();
        List<UploadEvidenceRequest> evidences = request.evidences();
        // this needs to improve
        List<ElisPhotoValidationError> errors = (files.size() == 1 &&
                "Applicant Photo".equals(evidences.get(0).type()))
                        ? validatePhoto(files.get(0), evidences.get(0).fileName())
                        : Collections.emptyList();
        List<UploadEvidenceResponse> responses = new ArrayList<>();
        for (UploadEvidenceRequest evidence : evidences.stream().limit(5).toList()) {
            Part file = files.stream()
                    .filter((f) -> f.getSubmittedFileName().contains(evidence.fileName()))
                    .findFirst().get();
            responses.add(uploadEvidence(myUscisId, orgMyUscisId, submissionId, formId, file, evidence, submission,
                    selectedFormType, errors));
        }

        responses.removeIf(Objects::isNull);
        return ResponseEntity.ok(responses);
    }

    @PostMapping(path = "/{submissionId}/feeWaiver", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    @ApiResponse(responseCode = "201")
    public ResponseEntity<UpdateSubmissionResponse> uploadFeeWaiver(
            @ValidPdfDimensions @RequestPart("file") MultipartFile file,
            @Valid @RequestPart("uploadFeeWaiverRequest") UploadFeeWaiverRequest feeWaiverRequest,
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value = "orgMyUscisId", required = false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            UriComponentsBuilder uriBuilder) throws IOException {
        log.info("In uploadFeeWaiver method for submissionId: {}", submissionId);
        Submission submission = submissionService.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        if (formService.isFeeWaiverEnabled(submission.getFormType())) {
            S3FileInfo s3FileInfo = s3Service.uploadFeeWaiver(myUscisId, submissionId, file, feeWaiverRequest,
                    submission);

            log.info("FeeWaiver id: {} from S3 service upload evidence response for submissionId: {}", s3FileInfo.id(),
                    submissionId);
            log.info("Updating submission for FeeWaiver Id: {} for submissionId: {}", s3FileInfo.id(), submissionId);
            Submission updatedSubmission = submissionService.updateSubmissionWithFeeWaiver(myUscisId, orgMyUscisId,
                    submissionId,
                    feeWaiverRequest,
                    s3FileInfo);

            URI location = uriBuilder.path("{id}").buildAndExpand(s3FileInfo.id()).toUri();
            SubmissionDto dto = SubmissionMapper.toSubmissionDTO(updatedSubmission);
            log.info("DTO: {}", dto);
            return ResponseEntity.created(location)
                    .body(new UpdateSubmissionResponse(dto));
        } else {
            log.info("Submission Form Type not fee waivable: ", submission.getFormType());
            return ResponseEntity.badRequest().build();
        }
    }

    private List<ElisPhotoValidationError> validatePhoto(Part file, String filename) throws IOException {
        log.info("Calling ELIS in a bit with media type {} ", file.getContentType());
        try {
            elisService.validatePhoto(MediaType.valueOf(file.getContentType()),
                    new MultipartInputStreamFileResource(file.getInputStream(), filename));
            log.info("Image was successfully validated");
            return emptyList();
        } catch (WebClientResponseException e) {
            log.info("ELIS returned validation errors {}", e.getResponseBodyAsString());
            return objectMapper.readValue(e.getResponseBodyAsString(),
                    new TypeReference<List<ElisPhotoValidationError>>() {
                    });
        }
    }

    private UploadEvidenceResponse uploadEvidence(String myUscisId, String orgMyUscisId, String submissionId,
            String formId, Part file,
            UploadEvidenceRequest evidence, Submission submission, String selectedFormType,
            List<ElisPhotoValidationError> errors) throws IOException {
        log.info("In uploadEvidence method for submissionId: {}, errors: {}", submission.getSubmissionId(), errors);
        int maxNumberOfFiles = getMaxFilesForEvidenceGroup(evidence.evidenceGroupType(), submission, selectedFormType);
        boolean canUpload = submission.getEvidences() != null ? submission.getEvidences().parallelStream()
                .filter(subEvidence -> (subEvidence.getType().equals(evidence.type())
                        && subEvidence.getEvidenceGroupType().equals(evidence.evidenceGroupType())))
                .count() < maxNumberOfFiles : true;
        if (canUpload) {
            S3FileInfo s3FileInfo = s3Service.uploadEvidence(myUscisId, submissionId, file, evidence, submission,
                    selectedFormType);
            String id = s3FileInfo.id();
            log.info("Evidence id: {} from S3 service upload evidence response for submissionId: {}", id,
                    submission.getSubmissionId());
            log.info("Updating submission for Evidence Id: {} for submissionId: {}", id, submission.getSubmissionId());

            Submission updatedSubmission = submissionService.updateSubmissionWithEvidence(myUscisId, orgMyUscisId,
                    submissionId, formId,
                    evidence, s3FileInfo, selectedFormType);
            var submissionEvidence = updatedSubmission.getEvidences().stream().filter(e -> e.getId().equals(id))
                    .findFirst()
                    .orElseThrow();
            log.info("Returning 200 with errors object: {}", errors);
            auditService.addEvent(myUscisId, submissionId, ActionPerformed.EVIDENCE_UPLOADED, id);
            return new UploadEvidenceResponse(id, submissionEvidence.getName(), submissionEvidence.getFormId(),
                    submissionEvidence.getUploadedAt(),
                    !errors.isEmpty(), errors);
        } else
            return null;
    }

    private int getMaxFilesForEvidenceGroup(@NotNull String evidenceGroupType, Submission submission,
            String selectedFormType) {
        if (SubmissionService.FEE_WAIVER_EVIDENCE_GROUP.equals(evidenceGroupType))
            return 20;
        EvidenceGroup evidenceGroup = formService.retrieveEvidenceGroup(selectedFormType,
                submission.getForms().stream().filter(form -> form.getType().equals(selectedFormType))
                        .findFirst().get().getEligibilityCategory().getCategory(),
                evidenceGroupType);
        return evidenceGroup.getMaxNumberOfFiles();

    }

}
