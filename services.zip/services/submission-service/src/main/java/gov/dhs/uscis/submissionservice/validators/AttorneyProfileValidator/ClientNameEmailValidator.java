package gov.dhs.uscis.submissionservice.validators.AttorneyProfileValidator;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.validation.ClientNameEmailResponse;
import gov.dhs.uscis.intake.models.validation.name_extract.ClientName;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.RepresentativeProfileResponseData;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.PeepsService;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ClientNameEmailValidator extends AttorneyProfileValidator {

    private static final String FAILURE_MESSAGE = "You cannot use your name and/or email address in the client information name and email address fields";

    public ClientNameEmailValidator(PeepsService peepsService, ValidationStatusRepository statusDAO) {
        super(peepsService, statusDAO, ValidatorEnum.G28_NAME_EMAIL, FAILURE_MESSAGE);
    }

    @Override
    protected boolean validationFails(ClientNameEmailResponse messageResponse,
            RepresentativeProfileResponseData profile) {
        ClientName profileName = ClientName.builder()
                .familyName(profile.lastName())
                .givenName(profile.firstName())
                .build();

        boolean nameMatches = null != messageResponse.getClientName() && messageResponse.getClientName().equals(profileName);
        boolean emailMatches = null != messageResponse.getEmail() && messageResponse.getEmail().equalsIgnoreCase(profile.email());

        return emailMatches || nameMatches;
    }

}