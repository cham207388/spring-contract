package gov.dhs.uscis.submissionservice.services;

import java.math.BigDecimal;
import java.net.URI;
import java.util.Map;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PaymentServiceClient {

  private WebClient paymentServiceWebClient;

  public PaymentServiceClient(@Qualifier("paymentServiceWebClient") WebClient paymentServiceWebClient) {
    this.paymentServiceWebClient = paymentServiceWebClient;
  }

  public boolean isAuthorized(String submissionId, BigDecimal amount, String formType) {
    log.info("Calling payment service for submission id: {} with amount {} and formType {} ", submissionId, amount.toString(), formType);
    var response = paymentServiceWebClient.get()
        .uri("/api/v1/payments/" + submissionId + "/authorization/status?feeTotal="+ amount.toString() + "&formType=" + formType)
        .retrieve()
        .bodyToMono(Map.class)
        .block();
    log.debug("Call to payment service completed:  " + submissionId);
    var status = response.get("status");
    log.debug("Payment status:  " + status);
    return "Authorized".equals(status);
  }

  public URI startAuthorization(String submissionId, FormType formType, BigDecimal fee) {
    log.debug("Calling payment service for submission id:  " + submissionId);
    return paymentServiceWebClient.get()
        .uri("/api/v1/payments/" + submissionId + "/authorization?feeTotal=" + fee + "&formType="
            + formType.getType())
        .retrieve()
        .toBodilessEntity()
        .block().getHeaders().getLocation();
  }
}