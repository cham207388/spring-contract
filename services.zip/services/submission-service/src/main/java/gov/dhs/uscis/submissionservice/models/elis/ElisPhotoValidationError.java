package gov.dhs.uscis.submissionservice.models.elis;

public record ElisPhotoValidationError(String code, String message, String correlationID, String field) {}
