package gov.dhs.uscis.submissionservice.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.exceptions.MyUscisProcessingException;
import gov.dhs.uscis.intake.models.core.Name;
import gov.dhs.uscis.submissionservice.exception.AddClientValidationException;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AccountTypeResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.ApplicantUuidResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.BulkInfo;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.BulkInfoRequest;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.BulkInfoResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.RepresentativeProfileResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.RepresentativeProfileResponseData;
import gov.dhs.uscis.submissionservice.validators.i765.receiptProfile.ReceiptProfile;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@JsonIgnoreProperties(ignoreUnknown = true)
public class PeepsService {
    private static final String ACCOUNT_NOT_APPLICANT_ERROR = "The account associated with the email cannot be added as a client at this time.";
    private WebClient webClient;
    public static final String BULK_USER_INFO_URL = "/api/icam/bulk_fetch_user_info";
    public static final String REPRESENTATIVE_PROFILE_URL = "/api/representative-profile";

    private PeepsClient peepsClient;

    public PeepsService(@Qualifier("peepsWebClient") WebClient peepsWebClient, PeepsClient peepsClient) {
        this.webClient = peepsWebClient;
        this.peepsClient = peepsClient;
    }

    public AccountTypeResponse retrieveAccountType(String myUscisId) {
        String truncatedMyUscisId = myUscisId.substring(0, 8);
        log.info(String.format("Looking up account type for user (...%s).", truncatedMyUscisId));
        var request = new BulkInfoRequest(List.of(myUscisId), List.of());

        try {
            var response = webClient.post()
                    .uri(BULK_USER_INFO_URL)
                    .header("ICAM-UUID", myUscisId)
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(BulkInfoResponse.class)
                    .block();

            if (null != response && null != response.getData()) {
                if (!response.getData().isEmpty())
                    return AccountTypeResponse.builder()
                            .accountType(AccountType.fromString(response.getData().getFirst().getAccountType()))
                            .build();
                else
                    return AccountTypeResponse.builder().accountType(AccountType.APPLICANT).build();
            }
            throw new RuntimeException("Received invalid response from bulk info api");

        } catch (Exception ex) {
            log.error("Error fetching applicant's account type for user (...%s).", truncatedMyUscisId,
                    ex);
            throw ex;
        } 
    }

    public ApplicantUuidResponse retrieveApplicantId(String emailAddress) {
        log.info(String.format("Looking up applicantUUID for email (...%s).", emailAddress));

        var request = new BulkInfoRequest(List.of(), List.of(emailAddress));

        try {
            var response = webClient.post()
                    .uri(BULK_USER_INFO_URL)
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(BulkInfoResponse.class)
                    .block();

            if (null != response && null != response.getData() && !response.getData().isEmpty()) {
                BulkInfo info = response.getData().getFirst();
                if (!info.getAccountType().equals(AccountType.APPLICANT.getType()))
                    throw new AddClientValidationException(ACCOUNT_NOT_APPLICANT_ERROR);

                return new ApplicantUuidResponse(response.getData().getFirst().getAccountUUID());
            }
            return null;

        } catch (AddClientValidationException ex) {
            log.error("Add client validation exception for (...{}).", emailAddress, ex);
            throw ex;
        } catch (Exception ex) {
            log.error("Error fetching applicant's account type with email (...%s).", emailAddress,
                    ex);

            return null;
        }
    }

    public RepresentativeProfileResponseData retrieveRepresentativeProfile(String myUscisId) {
        String truncatedMyUscisId = myUscisId.substring(0, 8);
        log.info(String.format("Looking profile for user (...%s).", truncatedMyUscisId));

        try {
            var response = webClient.get()
                    .uri(REPRESENTATIVE_PROFILE_URL)
                    .header("ICAM-UUID", myUscisId)
                    .retrieve()
                    .bodyToMono(RepresentativeProfileResponse.class)
                    .block();

            if (null != response && null != response.getData()) {
                return response.getData();
            }
            throw new RuntimeException("Received invalid response from account profile api");

        } catch (Exception ex) {
            log.error("Error fetching profile for user (...%s).", truncatedMyUscisId,
                    ex);
            throw ex;
        }
    }

    public boolean verifyClientInformation(String clientUUID, Name name, String dateOfBirth, String aNumber)
            throws MyUscisProcessingException {

        try {
            var response = peepsClient.retrieveUserInfo(clientUUID);
            if (response != null && response.data() != null) {
                ReceiptProfile profile = response.data();

                boolean alienNumberMatches = (profile.getAlienNumber() != null
                        && aNumber != null
                        && profile.getAlienNumber().equals(aNumber))
                        || (profile.getAlienNumber() == null && aNumber == null);

                boolean dobMatches = profile.getDateOfBirth() != null
                        && dateOfBirth != null
                        && profile.getDateOfBirth().equals(dateOfBirth);

                Name profileName = new Name(profile.getFirstName(), null, profile.getLastName());

                boolean nameMatches = profileName.equals(name);

                return alienNumberMatches && dobMatches && nameMatches;
            }
        } catch (MyUscisProcessingException e) {
            if (PeepsClient.NO_PROFILE_EXISTS.equals(e.getMessage())) {
                log.info("No profile found for {}", clientUUID);
                return true;
            } else {
                throw e;
            }
        }

        return false;
    }

    public boolean validateClientEmailIsNotAttorneyEmail(String myUscisId, String emailAddress) {
        var repProfile = retrieveRepresentativeProfile(myUscisId);
        log.info("received email {}. Comparing to profile email {}", emailAddress, repProfile.email());
        if (repProfile.email().equals(emailAddress)) {
            return false;
        }
        return true;
    }
}
