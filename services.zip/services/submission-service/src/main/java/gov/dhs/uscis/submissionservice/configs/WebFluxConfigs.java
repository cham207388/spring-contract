package gov.dhs.uscis.submissionservice.configs;

import java.io.FileInputStream;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.clients.AccountsDataClient;
import gov.dhs.uscis.intake.clients.ReactiveUserGroupServiceClient;
import gov.dhs.uscis.intake.clients.UserGroupServiceClient;
import gov.dhs.uscis.submissionservice.services.LockboxGatewayClient;
import gov.dhs.uscis.submissionservice.services.MyUscisCacheManagementClient;
import gov.dhs.uscis.submissionservice.services.PeepsClient;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import lombok.extern.slf4j.Slf4j;
import reactor.netty.http.client.HttpClient;

@Configuration
@Slf4j
public class WebFluxConfigs {

    @Value("${uscis.lockbox.baseUrl}")
    private String lockboxBaseUrl;
    @Value("${uscis.elis.baseUrl}")
    private String elisBaseUrl;
    @Value("${uscis.elis.keystore}")
    private String elisKeyStore;
    @Value("${uscis.elis.keyStorePassword}")
    private String elisKeyStorePassword;

    @Value("${uscis.lockbox.timeoutSeconds:120}")
    private int TIMEOUT_SECONDS;

    public WebFluxConfigs(@Value("${uscis.lockbox.baseUrl}") String lockboxBaseUrl,
            @Value("${uscis.elis.baseUrl}") String elisBaseUrl, @Value("${uscis.elis.keystore}") String elisKeyStore,
            @Value("${uscis.elis.keyStorePassword}") String elisKeyStorePassword) {
        this.lockboxBaseUrl = lockboxBaseUrl;
        this.elisBaseUrl = elisBaseUrl;
        this.elisKeyStore = elisKeyStore;
        this.elisKeyStorePassword = elisKeyStorePassword;
    }

    @Bean("peepsWebClient")
    public WebClient peepsWebClient(@Value("${uscis.peeps.url}") String peepsUrl,
            @Value("${uscis.peeps.username}") String username, @Value("${uscis.peeps.password}") String password)
            throws SSLException {
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(getHttpClient()))
                .defaultHeaders(headers -> headers.setBasicAuth(username, password))
                .baseUrl(peepsUrl)
                .build();
    }

    @Bean
    public PeepsClient peepsClient(@Qualifier("peepsWebClient") WebClient peepsClient) {
        return new PeepsClient(peepsClient);
    }

    @Bean
    public MyUscisCacheManagementClient myUscisCacheManagementClient(
            @Value("${uscis.cacheupdate.url}") String url,
            @Value("${uscis.cacheupdate.username}") String username,
            @Value("${uscis.cacheupdate.password}") String password,
            @Value("${uscis.cacheupdate.enable}") boolean enabled,
            ObjectMapper objectMapper ) throws SSLException {
        var webClient = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(getHttpClient()))
                .defaultHeaders(headers -> headers.setBasicAuth(username, password))
                .baseUrl(url)
                .build();

        return new MyUscisCacheManagementClient(webClient, objectMapper, enabled);
    }

    @Bean
    public UserGroupServiceClient userGroupServiceClient(ReactiveUserGroupServiceClient serviceClient ) throws SSLException {
        return new UserGroupServiceClient(serviceClient);
    }

    @Bean
    public ReactiveUserGroupServiceClient reactiveUserGroupServiceClient(@Value("${uscis.usergroupservice.url}") String url,
            @Value("${uscis.usergroupservice.username}") String username,
            @Value("${uscis.usergroupservice.password}") String password) throws SSLException {

        var webClient = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(HttpClient.create().responseTimeout(java.time.Duration.ofSeconds(TIMEOUT_SECONDS))))
                .defaultHeaders(headers -> headers.setBasicAuth(username, password))
                .baseUrl(url)
                .build();

        return new ReactiveUserGroupServiceClient(webClient);
    }

    @Bean("draftBenefitsWebClient")
    WebClient draftBenefitsWebClient(@Value("${uscis.draftbenefits.url}") String draftBenefits,
            @Value("${uscis.draftbenefits.username}") String username,
            @Value("${uscis.draftbenefits.password}") String password)
            throws SSLException {

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(getHttpClient()))
                .defaultHeaders(headers -> headers.setBasicAuth(username, password))
                .baseUrl(draftBenefits)
                .build();
    }

    @Bean("paymentServiceWebClient")
    public WebClient paymentServiceWebClient(@Value("${uscis.payments.baseUrl}") String paymentServiceBaseUrl) {
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(
                        getHttpClient()))
                .baseUrl(paymentServiceBaseUrl)
                .build();
    }

    @Bean
    public LockboxGatewayClient lockboxGatewayClient(
        @Value("${uscis.lockbox.baseUrl}") String lockboxBaseUrl,
            @Value("${uscis.lockbox.retries:2}") int retries,
            @Value("${uscis.lockbox.retryDurationSeconds:2}") int retryDurationSeconds) {

                var webClient = WebClient.builder()
                .baseUrl(lockboxBaseUrl)
                .clientConnector(new ReactorClientHttpConnector(getHttpClient()))
                .build();
        return new LockboxGatewayClient(webClient, retries, retryDurationSeconds );
    }

    @Bean("elisWebClient")
    public WebClient elisWebClient( @Value("${uscis.elis.baseUrl}") String elisBaseUrl, 
            @Value("${uscis.elis.keystore}") String elisKeyStore,
            @Value("${uscis.elis.keyStorePassword}") String elisKeyStorePassword) {
        log.info("Elis Web URL {}", this.elisBaseUrl);
        return WebClient.builder()
                .baseUrl(elisBaseUrl)
                .clientConnector(new ReactorClientHttpConnector(getElisHttpClient(elisBaseUrl)))
                .build();
    }
    
    @Bean
    public AccountsDataClient accountsDataClient(@Value("${uscis.accountsdata.url}") String url,
            @Value("${uscis.accountsdata.username}") String username,
            @Value("${uscis.accountsdata.password}") String password) {

    	log.info("Accounts data client: {}, {}, {}", url, username, password.substring(0, 3)+"*...*"+ password.substring(password.length()-2));
        var webClient = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(HttpClient.create().responseTimeout(java.time.Duration.ofSeconds(TIMEOUT_SECONDS))))
                .defaultHeaders(headers -> headers.setBasicAuth(username, password))
                .baseUrl(url)
                .build();

        return new AccountsDataClient(webClient);
    }

    private SslContext createSSLContext() {
        try {
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            keyStore.load(new FileInputStream(elisKeyStore),
                    elisKeyStorePassword.toCharArray());

            KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
            keyManagerFactory.init(keyStore, elisKeyStorePassword.toCharArray());

            return SslContextBuilder.forClient()
                    .keyManager(keyManagerFactory)
                    .build();

        } catch (Exception e) {
            throw new RuntimeException("Error creating SSL context.");
        }
    }

    private HttpClient getHttpClient() {
        return HttpClient.create().responseTimeout(java.time.Duration.ofSeconds(TIMEOUT_SECONDS));
    }
    
    private HttpClient getElisHttpClient(String hostAddress ) {
        HttpClient client = getHttpClient();
        var isSslRequired = hostAddress.toLowerCase().startsWith("https");
        if (isSslRequired) {
            log.info("adding ssl context");
            return client.secure(spec -> spec.sslContext(createSSLContext()));
        }
        return client;
    }

}