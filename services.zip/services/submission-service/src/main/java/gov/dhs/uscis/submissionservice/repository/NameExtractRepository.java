package gov.dhs.uscis.submissionservice.repository;

import java.util.Optional;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.models.validation.name_extract.NameExtract;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.DeleteItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@Slf4j
@Component
@AllArgsConstructor
public class NameExtractRepository {

    private final DynamoDbTable<NameExtract> table;

    public NameExtract save(@NonNull NameExtract nameExtract) {
        try {
            final PutItemEnhancedRequest<NameExtract> enhancedRequest = PutItemEnhancedRequest
                    .builder(NameExtract.class)
                    .item(nameExtract)
                    .build();
            table.putItem(enhancedRequest);

            log.info("Saved NameExtract for submissionId {}", nameExtract.getSubmissionId());
            return nameExtract;
        } catch (Exception e) {
            log.error("Error saving NameExtract for submission {}", nameExtract.getSubmissionId());
            throw new RuntimeException(String.format("Failed to save NameExtract for submissionId {} and formType {}",
                    nameExtract.getSubmissionId(), nameExtract.getForm()), e);
        }
    }

    public NameExtract update(@NonNull NameExtract nameExtract) {
        final UpdateItemEnhancedRequest<NameExtract> enhancedRequest = UpdateItemEnhancedRequest
                .builder(NameExtract.class)
                .item(nameExtract)
                .build();
        try {
            return table.updateItem(enhancedRequest);
        } catch (Exception e) {
            log.error("Exception encountered during updateItem for NameExtract for submission with id {} and formType {}",
                    nameExtract.getSubmissionId(), e.getMessage());
            throw new RuntimeException(String.format("Failed to update NameExtract for submissionId {} and formType {}",
                    nameExtract.getSubmissionId(), nameExtract.getForm()), e);        }
    }

    public Optional<NameExtract> getBySubmissionId(String submissionId) {
        try {
            GetItemEnhancedRequest request = GetItemEnhancedRequest.builder()
                    .key(builder -> builder.partitionValue(submissionId))
                    .consistentRead(true)
                    .build();

            NameExtract nameExtract = table.getItem(request);
            log.info("Retrieved NameExtract for submissionId {}; nameExtract {}", submissionId, nameExtract);
            return Optional.ofNullable(nameExtract);
        } catch (Exception e) {
            log.error("Error retrieving NameExtract for submission {}", submissionId);
            throw new RuntimeException(String.format("Failed to retrieve NameExtract for submissionId {}.",
                    submissionId), e);
        }
    }

    public void deleteBySubmissionId(@NonNull String submissionId) {
        try {
            DeleteItemEnhancedRequest deleteRequest = DeleteItemEnhancedRequest.builder()
                    .key(builder -> builder.partitionValue(submissionId)).build();
            table.deleteItem(deleteRequest);
            log.info("Deleted NameExtract for submissionId {}", submissionId);
        } catch (Exception e) {
            log.error("Error deleting NameExtract for submissionId {}", submissionId);
            throw new RuntimeException(String.format("Failed to delete NameExtract for submissionId {}.",
                    submissionId), e);
        }
    }
}
