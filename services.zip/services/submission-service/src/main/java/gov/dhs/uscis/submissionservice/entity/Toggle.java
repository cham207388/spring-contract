package gov.dhs.uscis.submissionservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "toggle")
public class Toggle {

    public Toggle(String toggleName, String toggleDescription, boolean active) {
        this.toggleName = toggleName;
        this.toggleDescription = toggleDescription;
        this.active = active;
    }

    public Toggle(){}

    @Id
    @Column(name = "toggle_name")
    private String toggleName;

    @Column(name = "toggle_description")
    private String toggleDescription;

    @Column(name = "active")
    private boolean active;
}
