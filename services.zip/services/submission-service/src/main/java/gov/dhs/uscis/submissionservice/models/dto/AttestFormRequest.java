package gov.dhs.uscis.submissionservice.models.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttestFormRequest {
    @NotNull
    Boolean attested;
    @NotNull @NotBlank
    String attestationSignature;
}
