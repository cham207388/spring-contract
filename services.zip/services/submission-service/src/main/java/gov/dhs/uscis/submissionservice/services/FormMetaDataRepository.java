package gov.dhs.uscis.submissionservice.services;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.models.FormMetaData;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@Component
@Slf4j
@AllArgsConstructor
public class FormMetaDataRepository {

    private DynamoDbTable<FormMetaData> table;
    

    public  FormMetaData update(@NonNull FormMetaData formData) {
        final UpdateItemEnhancedRequest<FormMetaData> enhancedRequest = UpdateItemEnhancedRequest
                .builder(FormMetaData.class)
                .item(formData)
                .build();
        try {
            return table.updateItem(enhancedRequest);
        } catch (Exception e) {
            throw new RuntimeException(String.format("Failed to update AddressExtract for submissionId {} and formType {}", formData.getFormType()), e);      
        }
    }
  /*   public FormMetaData retrieveFormMataData(String formType) {
        try {
            GetItemEnhancedRequest request = GetItemEnhancedRequest.builder()
                    .key(builder -> builder.partitionValue(formType)).build();
            return table.getItem(request);
        } catch (Exception ex) {
            log.error("Exception encountered during getItem", ex.getMessage());
            return null;
        } 
            */

            public FormMetaData retrieveFormMataData(String formType) {
        Key key = Key.builder().partitionValue(formType).build();
        GetItemEnhancedRequest request = GetItemEnhancedRequest.builder().key(key).build();
        return table.getItem(request);
    }
}
