package gov.dhs.uscis.submissionservice.validators;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.validation.FormFieldResult;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;

public interface FieldValidator {
    public void validate(Submission submission, FormFields formFields);
    public void validate(Submission submission, FormFieldResult eligibility); 
}