package gov.dhs.uscis.submissionservice.controllers;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.submissionservice.services.mappers.SubmissionTransformation;

public class ElISDownloaderUrlMapper implements SubmissionTransformation {

    private String downloaderOverrideUrl;
    private Logger logger = LoggerFactory.getLogger(ElISDownloaderUrlMapper.class);

    public ElISDownloaderUrlMapper(String downloaderOverrideUrl) {
        this.downloaderOverrideUrl = downloaderOverrideUrl;
    }

    @Override
    public Submission transform(Submission submission) {
        logger.debug("Transformation submission {}", submission.getSubmissionId());
        List<SubmissionEvidence> evidences = submission.getEvidences();
        if (evidences != null) {
            submission.setEvidences(evidences.parallelStream().map(evidence -> {
                if (evidence.getUrl() != null) {
                    evidence.setUrl(replaceHostWithCustomizedHost(downloaderOverrideUrl, evidence.getUrl()));
                }
                return evidence;
            }).toList());
        }

        if( submission.getFeeWaiver() != null ){
            submission.getFeeWaiver().setUrl(replaceHostWithCustomizedHost(downloaderOverrideUrl, submission.getFeeWaiver().getUrl()));
        }

        if( submission.getForms() != null ){
            submission.getForms().forEach(f -> {
                f.setUrl(replaceHostWithCustomizedHost(downloaderOverrideUrl, f.getUrl()));
            });
        }

        return submission;
    }

    private String replaceHostWithCustomizedHost(String url, String currentUrl) {
        try {
            String newUrl = url + new URI(currentUrl).getPath().replace("/csai-intake-downloader", "");
            logger.info("Converting url from {} to {}", currentUrl, newUrl);
            return newUrl;
        } catch (URISyntaxException e) {
            logger.error("Unable to translate the currentl url {}", currentUrl);
        }

        return currentUrl;
    }

}
