package gov.dhs.uscis.submissionservice.components;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ELISValidationResponse;
import gov.dhs.uscis.intake.models.ValidationStatus;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

@Component
@Profile("mock_elis")
public class MockElisValidationListener implements MessageListener {

	private final SqsClient sqsClient;

	@Value("${uscis.sqs.validation.elisResponse.queueUrl}")
	private String elisResponseQueueName;

    @Value("${uscis.sqs.validation.elisResponse.defaultFeeTotal:999}")
	private int elisResponseDefaultFeeTotal;


	ObjectMapper mapper = new ObjectMapper();
	private static final Logger logger = LoggerFactory.getLogger(MockElisValidationListener.class);
	private static final int i751Fee = 700;
    private static final int i140Fee = 665;

	@Autowired
	public MockElisValidationListener(SqsClient sqsClient) {
		this.sqsClient = sqsClient;
	}

	@Override
	public void onMessage(Message message) {
		TextMessage textMessage = (TextMessage) message;
		try {
			ELISValidationResponse request = mapper.readValue(textMessage.getText(), ELISValidationResponse.class);

            logger.info("MOCK ELIS, recieved Message: " + request.toString());

			ValidationStatus mockUpdatedStatus = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
					.isMultipart(false)
					.validator(ValidatorEnum.PFVS)
					.build();

			ValidationStatus mockSignatureStatus = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
                    .failureReasons(List.of("Signature isn't present"))
					.isMultipart(true)
					.validator(ValidatorEnum.SIGNATURE)
					.build();

			ValidationStatus mockCoreStatus = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
					.isMultipart(false)
					.validator(ValidatorEnum.CORE)
					.build();

			ValidationStatus mockEligibility = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
					.isMultipart(false)
					.validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
					.build();

			ValidationStatus mockG28Comp = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
					.isMultipart(false)
					.validator(ValidatorEnum.G28_COMP)
					.build();

			ValidationStatus mockG28CompName = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
					.isMultipart(false)
					.validator(ValidatorEnum.G28_COMP_NAME)
					.build();

			ValidationStatus mockG28NameEmail = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
					.isMultipart(false)
					.validator(ValidatorEnum.G28_NAME_EMAIL)
					.build();

			ValidationStatus mockG28AttorneyName = ValidationStatus.builder()
					.formId(request.formId())
					.submissionId(request.submissionId())
					.status(ValidationResultEnum.PASS)
					.isMultipart(false)
					.validator(ValidatorEnum.G28_ATTORNEY_NAME)
					.build();


			List<ValidationStatus> statusResponses = new ArrayList<>();
			if(!request.formType().equals(FormType.G28.getType())) {
			statusResponses.addAll(Arrays.asList(mockUpdatedStatus, mockSignatureStatus, mockCoreStatus, mockEligibility));
			}

			else if(request.formType().equals(FormType.G28.getType())) {
				statusResponses.addAll(Arrays.asList(mockCoreStatus, mockSignatureStatus, mockG28Comp, mockG28CompName, mockG28NameEmail, mockG28AttorneyName));
			}
			int feeTotal = elisResponseDefaultFeeTotal;
			if (request.formType().equals(FormType.I751.getType())) {
				feeTotal = i751Fee;
			}
            else if (request.formType().equals(FormType.I140.getType())) {
                feeTotal = i140Fee;
            }
			else if (request.formType().equals(FormType.G28.getType())) {
				feeTotal = 0;
			}

			ELISValidationResponse elisValidationResponse = ELISValidationResponse.builder()
					.results(statusResponses)
					.formId(request.formId())
					.fee(BigDecimal.valueOf(feeTotal))
					.formType(request.formType())
					.pass(true)
					.submissionId(request.submissionId())
					.build();

			SendMessageRequest sendMsgRequest = SendMessageRequest.builder()
					.queueUrl(elisResponseQueueName)
					.messageBody(mapper.writeValueAsString(elisValidationResponse))
					.build();

			logger.info("Sending mock validation response message to queue: {}\n{}", elisResponseQueueName, message);
            //Adding 10 second sleep to simulate a short wait in PFVS for more realistic testing
            Thread.sleep(10000);
			SendMessageResponse response = sqsClient.sendMessage(sendMsgRequest);
			logger.info(response.toString());
			textMessage.acknowledge();
		} catch (Exception e) {
			logger.error("Error with ELIS validaiton mock listener {}", e);
		}
	}

}