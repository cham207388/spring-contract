package gov.dhs.uscis.submissionservice.configs;

import java.security.interfaces.RSAPublicKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;

@Configuration
@ConditionalOnProperty(name = "application.security.enforce.oauth", havingValue = "true", matchIfMissing = true)
public class JwtConfig {

    @Value("${application.security.jwt.public-key}")
    RSAPublicKey jwtPublicKey;

    @Bean
    public JwtDecoder jwtDecoder() {
        return NimbusJwtDecoder 
            .withPublicKey(jwtPublicKey).build();
    }
}
