package gov.dhs.uscis.submissionservice.models;

import jakarta.validation.constraints.NotEmpty;

public record UpdateEvidenceRequest(
    @NotEmpty
    String type
) {}
