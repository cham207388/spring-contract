package gov.dhs.uscis.submissionservice.services.mappers;

import java.util.List;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;

public class ELISEvidenceMapper implements SubmissionTransformation {

    private static final List<String> form797Types = List.of("Form-797", "Form-797c");

    @Override
    public Submission transform(Submission submission) {
        List<SubmissionEvidence> evidences = submission.getEvidences();
        if (evidences != null) {
            submission.setEvidences(evidences.parallelStream().map(evidence -> {
                if (evidence.getType() != null && ELISEvidenceMapper.form797Types.contains(evidence.getType())) {
                    evidence.setType("Other");
                }
                return evidence;
            }).toList());
        }

        return submission;
    }

}
