package gov.dhs.uscis.submissionservice.services.fees;

import java.math.BigDecimal;

import gov.dhs.uscis.intake.enums.FormType;

public interface FormFeeHandler<T, F> {
    public boolean canHandle(FormType type);

    public BigDecimal handle(T strategyContext, F options);
}