package gov.dhs.uscis.submissionservice.controllers;

import static gov.dhs.uscis.submissionservice.models.dto.SubmissionMapper.toSubmissionDTO;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.enums.ResidencyStatus;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.exceptions.AccountsDataClientException;
import gov.dhs.uscis.intake.models.EsignData;
import gov.dhs.uscis.intake.models.FinalTransmissionStatus;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionRequest;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest;
import gov.dhs.uscis.intake.models.UpdateSubmissionResponse;
import gov.dhs.uscis.intake.models.WatermarkerStatus;
import gov.dhs.uscis.intake.models.dto.C9Options;
import gov.dhs.uscis.intake.models.dto.C9UpdateRequest;
import gov.dhs.uscis.intake.models.dto.SubmissionDto;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResponse;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.intake.util.SubmissionUtils;
import gov.dhs.uscis.submissionservice.exception.ValidationStatusDeletionException;
import gov.dhs.uscis.submissionservice.models.UpdateEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UpdateFeeWaiverEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UpdateFormTypeRequest;
import gov.dhs.uscis.submissionservice.models.dto.AttestFormRequest;
import gov.dhs.uscis.submissionservice.models.dto.C9FeeUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.EligibilitySubcategoriesUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.EligibilityUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.FeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import gov.dhs.uscis.submissionservice.models.dto.HasReviewedSignatureUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.ImmviUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.PartialFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.dto.ReasonForFilingUpdateRequest;
import gov.dhs.uscis.submissionservice.models.dto.SubmissionMapper;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AccountTypeResponse;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.AddClientRequest;
import gov.dhs.uscis.submissionservice.models.submissionStatus.SubmissionStatusResponse;
import gov.dhs.uscis.submissionservice.services.PaymentRequiredException;
import gov.dhs.uscis.submissionservice.services.PeepsService;
import gov.dhs.uscis.submissionservice.services.S3Service;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ValidationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Tag(name = "Submission", description = "Submission Management APIs")
@RestController
@RequestMapping("/api/v1/{myUscisId}/submissions")
public class SubmissionController {

    private final SubmissionService service;
    private final S3Service s3Service;
    private final ValidationService validationService;
    private final AuditService auditService;
    private final Validator validator;
    private final PeepsService peepsService;

    public SubmissionController(SubmissionService service,
            S3Service s3Service, ValidationService validationService,
            AuditService auditService,
            PeepsService peepsService, Validator validator) {
        this.service = service;
        this.s3Service = s3Service;
        this.validationService = validationService;
        this.auditService = auditService;
        this.peepsService = peepsService;
        this.validator = validator;
    }

    @GetMapping()
    public ResponseEntity<List<SubmissionDto>> getAllSubmissions(@PathVariable("myUscisId") String myUscisId,
            @RequestParam() String filters) {
        var submissions = service.findAllByMyUscisIdAndStatus(myUscisId,
                SubmissionUtils.convertAndValidateFilters(filters));
        List<SubmissionDto> submissionDtoList = SubmissionMapper.toSubmissionDtoList(submissions);

        return ResponseEntity.ok().body(submissionDtoList);
    }

    @GetMapping("/org/{orgMyUscisId}")
    public ResponseEntity<List<SubmissionDto>> getAllSubmissions(@PathVariable("myUscisId") String myUscisId, @PathVariable("orgMyUscisId") String orgMyUscisId, @RequestParam() String filters) {
        var submissions = service.findAllByOrgMyUscisIdAndStatus(orgMyUscisId, SubmissionUtils.convertAndValidateFilters(filters));
        List<SubmissionDto> submissionDtoList = SubmissionMapper.toSubmissionDtoList(submissions);

        return ResponseEntity.ok().body(submissionDtoList);
    }

    @GetMapping("/applicant")
    public ResponseEntity<List<SubmissionDto>> getAllSubmissionsForApplicant(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam() String filters) {
        var submissions = service.findAllByApplicantUscisIdAndStatus(myUscisId,
                SubmissionUtils.convertAndValidateFilters(filters));
        List<SubmissionDto> submissionDtoList = SubmissionMapper.toSubmissionDtoList(submissions);

        if (submissionDtoList.size() != 0)
            return ResponseEntity.ok().body(submissionDtoList);
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{submissionId}")
    @Parameters
    public ResponseEntity<SubmissionDto> getSubmissionById(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId) {
        Submission submission = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);

        SubmissionDto submissionDto = SubmissionMapper.toSubmissionDTO(submission);

        if (submissionDto != null)
            return ResponseEntity.ok().body(submissionDto);
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{submissionId}/status")
    public final ResponseEntity<SubmissionStatusResponse> getSubmissionStatus(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId) {
        final SubmissionStatusResponse submissionStatusResponse = service.retrieveSubmissionStatus(myUscisId, orgMyUscisId,
                submissionId);
        if (submissionStatusResponse != null) {
            return ResponseEntity.ok().body(submissionStatusResponse);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/drafts")
    public ResponseEntity<List<SubmissionDto>> getDraftSubmissionsById(@PathVariable("myUscisId") String myUscisId) {
        log.info("Retrieving draft for {} ", myUscisId);
        List<Submission> submissions = service.retrieveDraftSubmissions(myUscisId);
        List<SubmissionDto> submissionDtoList = SubmissionMapper.toSubmissionDtoList(submissions);

        return ResponseEntity.ok().body(submissionDtoList);
    }

    @PostMapping("/")
    public final ResponseEntity<SubmissionDto> createInitialSubmission(
            @PathVariable("myUscisId") String myUscisId,
            @RequestBody SubmissionRequest request) {
        final Submission submission = service.createInitialSubmission(myUscisId, request);
        return ResponseEntity.ok().body(SubmissionMapper.toSubmissionDTO(submission));
    }

    @SuppressWarnings("rawtypes")
    @PostMapping("/{submissionId}")
    public final Mono<ResponseEntity> completeSubmission(
            @PathVariable("myUscisId") String myUscisId, @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") FinalSubmissionDto finalSubmissionDto)
            throws PaymentRequiredException {
        var violations = validator.validate(finalSubmissionDto);
        if (!violations.isEmpty())
            return Mono.just(ResponseEntity.badRequest().body("Validation error: " + violations));
        log.info("complete submission endpoint called with {}", finalSubmissionDto);
        return service.completeSubmission(myUscisId, orgMyUscisId, finalSubmissionDto.getSubmissionId())
                .map(s -> ResponseEntity.ok(s));
    }

    @GetMapping("/{submissionId}/validations")
    public final ResponseEntity<List<String>> checkValidations(
            @PathVariable("myUscisId") String myUscisId,
            @PathVariable("submissionId") FinalSubmissionDto finalSubmissionDto) {
        return ResponseEntity.ok().body(service.getValidationStatus(myUscisId, finalSubmissionDto));
    }

    @PutMapping("/{submissionId}/lockbox-status")
    public final ResponseEntity<String> updateSubmissionWithLockBoxStatus(
            @PathVariable("myUscisId") String myUscisId,
            @PathVariable("submissionId") String submissionId,
            @RequestBody SubmissionUpdateRequest request) {
        var updatedSubmission = service.updateSubmissionWithLockBoxStatus(submissionId, request);
        if (updatedSubmission != null) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.badRequest()
                .body("Encountered an error updating Submission with ID " + submissionId + ".");

    }

    @PatchMapping(path = "/{submissionId}/lock")
    public final ResponseEntity<String> updateDraftSubmissionLock(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId) {
        Submission submission = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        var updateDraftSubmissionLock = service.updateDraftSubmissionLock(submission);
        if (updateDraftSubmissionLock != null) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.badRequest()
                .body("Encountered an error updating lock for Submission with ID " + submissionId + ".");

    }

    @PutMapping("/{submissionId}/immvi")
    public ResponseEntity<SubmissionDto> updateImmvi(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @Valid @RequestBody ImmviUpdateRequest request) {
        Submission updatedSubmission = service.updateImmvi(submissionId, myUscisId, orgMyUscisId, request.getImmvi());
        return ResponseEntity.ok(toSubmissionDTO(updatedSubmission));
    }

    @PutMapping("/{submissionId}/c9fee")
    public ResponseEntity<SubmissionDto> updateC9Fee(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @Valid @RequestBody C9FeeUpdateRequest c9UpdateRequest) {
        C9UpdateRequest c9Request = getC9Request(c9UpdateRequest);
        Submission updatedSubmission = service.updateC9Fee(submissionId, myUscisId, orgMyUscisId, c9Request);
        return ResponseEntity.ok(toSubmissionDTO(updatedSubmission));
    }

    @PostMapping("/{submissionId}/esign/{formId}")
    public ResponseEntity<Void> esignForm(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("formId") String formId,
            @Valid @RequestBody EsignData esignData) {
        service.esignForm(myUscisId, orgMyUscisId, submissionId, formId, esignData);
        return ResponseEntity.noContent().build();
    }

    private C9UpdateRequest getC9Request(C9FeeUpdateRequest request) {
        C9Options options = C9Options
            .builder()
            .onOrAfterApril012024(request.getOptions().isOnOrAfterApril012024())
            .beforeApril012024(request.getOptions().isBeforeApril012024())
            .build();
        C9UpdateRequest c9Request = C9UpdateRequest.builder()
            .options(options)
            .isFeeWaiverEligible(request.isFeeWaiverEligible())
            .build();
        return c9Request;
    }

    @PutMapping("/{submissionId}/reason-for-filing")
    public ResponseEntity<SubmissionDto> updateReasonForFiling(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @Valid @RequestBody ReasonForFilingUpdateRequest request) {
        Submission updatedSubmission = service.updateReasonForFiling(submissionId, myUscisId, orgMyUscisId, request.getReasonForFiling());
        return ResponseEntity.ok(toSubmissionDTO(updatedSubmission));
    }

    @PutMapping("/{submissionId}/review-signature")
    public ResponseEntity<SubmissionDto> reviewSignature(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @Valid @RequestBody HasReviewedSignatureUpdateRequest request) {
        SubmissionDto updatedSubmission = SubmissionMapper
                .toSubmissionDTO(service.updateSignatureReviewed(submissionId, myUscisId, orgMyUscisId,
                        request.getHasReviewedSignature()));
        return ResponseEntity.ok(updatedSubmission);
    }

    @PutMapping("/{submissionId}/category")
    public ResponseEntity<SubmissionDto> updateEligibility(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @Valid @RequestBody EligibilityUpdateRequest request) {

        Submission updatedSubmission = service.updateEligibility(submissionId, myUscisId, orgMyUscisId, request);
        SubmissionDto updatedSubmissionDto = SubmissionMapper.toSubmissionDTO(updatedSubmission);
        return ResponseEntity.ok(updatedSubmissionDto);
    }

    @PutMapping("/{submissionId}/eligibility-subcategories")
    public ResponseEntity<SubmissionDto> updateEligibilitySubcategories(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @Valid @RequestBody EligibilitySubcategoriesUpdateRequest request) {

        SubmissionDto updatedSubmission = SubmissionMapper
                .toSubmissionDTO(service.updateEligibilitySubcategories(submissionId, myUscisId, orgMyUscisId, request.getEligibilitySubcategories()));
        return ResponseEntity.ok(updatedSubmission);
    }

    @PutMapping("/{submissionId}/fee-waiver")
    public ResponseEntity<SubmissionDto> updateUserRequestedFeeWaiver(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @Valid @RequestBody FeeWaiverRequest request) {
        Submission result = service.updateUserRequestedFeeWaiver(myUscisId, orgMyUscisId, submissionId,
                request.getUserRequestedFeeWaiver());
        return ResponseEntity.ok(toSubmissionDTO(result));
    }

    @PutMapping("/{submissionId}/partial-fee-waiver")
    public ResponseEntity<SubmissionDto> updateUserRequestedPartialFeeWaiver(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @Valid @RequestBody PartialFeeWaiverRequest request) {
        Submission result = service.updateUserRequestedPartialFeeWaiver(myUscisId, orgMyUscisId, submissionId,
                request.getUserRequestedPartialFeeWaiver());
        return ResponseEntity.ok(toSubmissionDTO(result));
    }

    @GetMapping("/{submissionId}/validation-status")
    @Operation(summary = "Poll validation status of all submission artifacts")
    public ResponseEntity<ValidationStatusResponse> retrieveValidationStatus(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId) {
        Submission submission = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        ValidationStatusResponse validationStatus = validationService.retrieveValidationStatus(submission);
        if (validationStatus != null)
            return ResponseEntity.ok().body(validationStatus);
        return ResponseEntity.notFound().build();
    }

    @PutMapping("/{submissionId}/residency-status")
    public ResponseEntity<SubmissionDto> setResidencyStatus(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @RequestParam ResidencyStatus residencyStatus) {
        SubmissionDto updatedSubmission = SubmissionMapper
                .toSubmissionDTO(service.setResidencyStatus(submissionId, myUscisId, orgMyUscisId, residencyStatus));
        return ResponseEntity.ok(updatedSubmission);
    }

    @GetMapping("/{submissionId}/forms/{formId}/i912-validation-status")
    @Operation(summary = "Poll form validation status")
    public ResponseEntity<ValidationStatusResponse> retrieveI912ValidationStatus(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("formId") String formId) {

        Submission submission = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        ValidationStatusResponse validationStatus = validationService.retrieveI912ValidationStatus(formId, submission);
        if (validationStatus != null)
            return ResponseEntity.ok().body(validationStatus);
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{submissionId}/forms/{id}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<SubmissionDto> deleteFormByFormId(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("id") String id) {
        if (id instanceof String) {
            SubmissionDto submissionDto = SubmissionMapper
                    .toSubmissionDTO(service.deleteFormFromSubmission(myUscisId, orgMyUscisId, submissionId, id));

            return ResponseEntity.ok().body(submissionDto);
        }
        return ResponseEntity.badRequest().build();
    }

    @DeleteMapping("/{submissionId}/evidence/{id}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<Void> deleteEvidenceByEvidenceId(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("id") String id) {
        log.info("deleting evidence: {} from submission {}", id, submissionId);
        String evidenceS3Key = service.deleteEvidenceFromSubmission(myUscisId, orgMyUscisId, submissionId, id);
        log.info("deleting evidence: {} from S3 for submission {}", evidenceS3Key, submissionId);
        if (evidenceS3Key != null) {
            s3Service.deleteS3Object(evidenceS3Key, true);
            auditService.addEvent(myUscisId, submissionId, ActionPerformed.EVIDENCE_DELETED_WITH_S3, evidenceS3Key);
        } else {
            auditService.addEvent(myUscisId, submissionId, ActionPerformed.EVIDENCE_DELETED_WITHOUT_S3, id);
        }

        try {
            validationService.deleteStatus(id);
        } catch (ValidationStatusDeletionException e) {
            log.error("Error deleting validation status for evidence", e);
        }

        return ResponseEntity.noContent().build();
    }


    @PatchMapping(path = "/{submissionId}/feeWaiver/{id}")
    public ResponseEntity<UpdateSubmissionResponse> updateFeeWaiverEvidence(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") @UUID String submissionId,
            @PathVariable("id") @UUID String id,
            @RequestBody @Valid UpdateFeeWaiverEvidenceRequest request) {

        Submission submission = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        submission = service.updateFeeWaiverEvidence(submission, request.type(), false);

        UpdateSubmissionResponse response = UpdateSubmissionResponse.builder()
                .submission(SubmissionMapper.toSubmissionDTO(submission))
                .build();
        return ResponseEntity.ok().body(response);
    }

    @PatchMapping(path = "/{submissionId}/evidence/{id}")
    public ResponseEntity<UpdateSubmissionResponse> updateEvidence(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") @UUID String submissionId,
            @PathVariable("id") @UUID String id,
            @RequestBody @Valid UpdateEvidenceRequest request) {

        Submission submission = service.retrieveDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        submission = service.updateEvidence(submission, id, request.type());

        UpdateSubmissionResponse response = UpdateSubmissionResponse.builder()
                .submission(SubmissionMapper.toSubmissionDTO(submission))
                .build();
        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping("/{submissionId}/feeWaiver/{id}")
    public ResponseEntity<SubmissionDto> deleteFeeWaiverByFeeWaiverId(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("id") String id) {
        SubmissionDto submissionDto = SubmissionMapper
                .toSubmissionDTO(service.deleteFeeWaiverFromSubmission(myUscisId, orgMyUscisId, submissionId, id));
        log.info("Deleting feeWaiver from Submission with submissionId: {} with id {}", submissionId, id);
        return ResponseEntity.ok().body(submissionDto);
    }

    @DeleteMapping("/{submissionId}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<Void> deleteDraftSubmission(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId) {
        service.deleteDraftSubmission(myUscisId, orgMyUscisId, submissionId);
        log.info("deleting draft submission with submissionId: {}", submissionId);

        return ResponseEntity.noContent().build();
    }

    @PostMapping(path = "/{submissionId}/attest/{formId}")
    public final ResponseEntity<SubmissionDto> attestForm(
            @PathVariable("myUscisId") String myUscisId,
            @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("formId") String formId,
            @Valid @RequestBody AttestFormRequest request) {

        SubmissionDto submissionDto = SubmissionMapper
                .toSubmissionDTO(service.attestForm(myUscisId, orgMyUscisId, submissionId, formId, request.getAttested(),
                        request.getAttestationSignature()));

        return ResponseEntity.ok().body(submissionDto);
    }

    @GetMapping(path = "/{submissionId}/forms/{formId}/attestation-status")
    @Operation(summary = "Poll form attestation status")
    public final ResponseEntity<WatermarkerStatus.StatusEnum> pollForAttestationStatus(
            @PathVariable("myUscisId") String myUscisId,
            @PathVariable("submissionId") String submissionId,
            @PathVariable("formId") String formId) {

        WatermarkerStatus.StatusEnum status = service.getAttestationStatus(submissionId, formId);
        return ResponseEntity.ok().body(status);
    }

    @GetMapping(path = "/{submissionId}/final-transmission-status")
    @Operation(summary = "Poll for final transmission status")
    public final ResponseEntity<FinalTransmissionStatus> pollForFinalTransmissionStatus(
            @PathVariable("myUscisId") String myUscisId,
            @PathVariable("submissionId") String submissionId) {
        FinalTransmissionStatus status = service.getFinalTransmissionStatus(myUscisId, submissionId);
        return ResponseEntity.ok().body(status);
    }

    @GetMapping("/userRole")
    public ResponseEntity<AccountTypeResponse> retrieveUserRole(
            @PathVariable("myUscisId") String myUscisId) {
        var result = peepsService.retrieveAccountType(myUscisId);
        return ResponseEntity.ok().body(result);
    }

    @PostMapping("/add-client")
    public ResponseEntity<Boolean> addClient(
            @PathVariable("myUscisId") String myUscisId,
            @RequestBody AddClientRequest request) {
        log.info("Validating client email does not match representative's email");
        boolean emailValidated = peepsService.validateClientEmailIsNotAttorneyEmail(myUscisId, request.emailAddress());
        return ResponseEntity.ok().body(emailValidated);
    }

    @PutMapping("/{submissionId}/form-specific-info")
    public ResponseEntity<SubmissionDto> updateFormSpecificInfo(
            @PathVariable("submissionId") String submissionId,
            @RequestBody FormSpecificInfo request) {
        Submission updatedSubmission = service.updateFormSpecificInfo(submissionId, request);
        return ResponseEntity.ok(toSubmissionDTO(updatedSubmission));
    }

    @DeleteMapping("/{submissionId}/delete-form-specific-info")
    public ResponseEntity<SubmissionDto> deleteFormSpecificInfo(
            @PathVariable("submissionId") String submissionId) {
        Submission updatedSubmission = service.resetFormSpecificInfo(submissionId);
        return ResponseEntity.ok(toSubmissionDTO(updatedSubmission));
    }

    @GetMapping("/{submissionId}/can-pay-and-submit")
    public ResponseEntity<Boolean> canUserPayAndSubmit(@PathVariable("myUscisId") String myUscisId,
    		@PathVariable("submissionId") String submissionId) {
    	return ResponseEntity.ok(service.canUserPayAndSubmit(myUscisId, submissionId));
    }

    @GetMapping("/{submissionId}/administrators")
    public ResponseEntity<List<gov.dhs.uscis.intake.models.myuscis.Admin>> getAdministrators(@PathVariable("myUscisId") String myUscisId,
    		@PathVariable("submissionId") String submissionId) {
    	return ResponseEntity.ok().body(service.getAdministrators(myUscisId, submissionId));
    }

    @PostMapping("/{submissionId}/notify")
    public ResponseEntity<Void> notifyAdministrators(@PathVariable("myUscisId") String myUscisId,
    		@PathVariable("submissionId") String submissionId,
    		@RequestBody List<String> admins) {
    	try {
    		service.sendNotificationToAdministrator(myUscisId, submissionId, admins);
    		return ResponseEntity.ok().build();
    	} catch(AccountsDataClientException e) {
    		return ResponseEntity.internalServerError().build();
    	}
    }

    @GetMapping("/orgId")
    public ResponseEntity<String> getAdministrators(@PathVariable("myUscisId") String myUscisId) {
    	return ResponseEntity.ok().body(service.getOrgId(myUscisId));
    }
}
