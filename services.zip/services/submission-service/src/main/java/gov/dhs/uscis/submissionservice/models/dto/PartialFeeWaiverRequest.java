package gov.dhs.uscis.submissionservice.models.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PartialFeeWaiverRequest {
    @NotNull
    private Boolean userRequestedPartialFeeWaiver;
}
