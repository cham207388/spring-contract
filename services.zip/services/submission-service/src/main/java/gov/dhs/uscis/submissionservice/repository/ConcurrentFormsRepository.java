package gov.dhs.uscis.submissionservice.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.dhs.uscis.submissionservice.entity.ConcurrentForms;

@Repository
public interface ConcurrentFormsRepository extends CrudRepository<ConcurrentForms, String>{
    public List<ConcurrentForms> findByIdPrimaryFormTypeAndActiveIsTrue(String primaryFormType);
    public ConcurrentForms findByIdPrimaryFormTypeAndIdConcurrentFormTypeAndActiveIsTrue(String primaryFormType, String concurrentFormType);

}
