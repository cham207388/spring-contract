package gov.dhs.uscis.submissionservice.models.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class C9FeeOptions {
    // These options were introduced by CSAI-4258. The reason two booleans are needed is because they can both be false. See below for what they represent: 
    
    // You filed your I-485 on or after July 30, 2007 AND before April 1, 2024.
    // AND your form I-485 is still pending.
    // AND you paid the I-485 filing fee.
    // OR you are eligible for an exemption. 
    private boolean onOrAfterApril012024;

    // You filed your I-483 with a fee on or after April 1, 2024.
    // AND your form I-485 is still pending.
    private boolean beforeApril012024;
}