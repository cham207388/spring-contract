package gov.dhs.uscis.submissionservice.models;

import static gov.dhs.uscis.intake.constants.DocumentType.FeeWaiver.FEE_DECLARATION;
import static gov.dhs.uscis.intake.constants.DocumentType.FeeWaiver.FORM_I912;

import jakarta.validation.constraints.Pattern;
import lombok.Builder;

@Builder
public record UpdateFeeWaiverEvidenceRequest(
    @Pattern(regexp = "^(" + FEE_DECLARATION + "|" + FORM_I912 + ")$", message = "Invalid document type")
    String type
) {}
