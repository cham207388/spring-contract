package gov.dhs.uscis.submissionservice.models;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;

@Builder
public record UploadRequest(@NotNull String fileName, boolean isForm, String type, String md5Hash,
        @NotNull String formType) {
}