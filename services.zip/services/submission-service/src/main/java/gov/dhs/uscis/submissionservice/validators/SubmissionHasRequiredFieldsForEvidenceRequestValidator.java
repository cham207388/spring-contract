package gov.dhs.uscis.submissionservice.validators;

import org.springframework.stereotype.Component;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import gov.dhs.uscis.intake.models.Submission;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

@Component
public class SubmissionHasRequiredFieldsForEvidenceRequestValidator implements ConstraintValidator<SubmissionHasRequiredFieldsForEvidenceRequest, EvidenceRequest> {

    @Override
    public boolean isValid(EvidenceRequest evidenceRequest, ConstraintValidatorContext context) {
        Submission submission = evidenceRequest.submission();
        return (submission.getFormType() != null && submission.getEligibilityCategory() != null);
    }

}
