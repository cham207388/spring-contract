package gov.dhs.uscis.submissionservice.repository;

import java.util.Optional;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.models.validation.address_extract.AddressExtract;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.DeleteItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@Slf4j
@Component
@AllArgsConstructor
public class AddressExtractRepository {

    private final DynamoDbTable<AddressExtract> table;

    public AddressExtract save(@NonNull AddressExtract addressExtract) {
        try {
            final PutItemEnhancedRequest<AddressExtract> enhancedRequest = PutItemEnhancedRequest
                    .builder(AddressExtract.class)
                    .item(addressExtract)
                    .build();
            table.putItem(enhancedRequest);

            log.info("Saved AddressExtract for submissionId {}", addressExtract.getSubmissionId());
            return addressExtract;
        } catch (Exception e) {
            log.error("Error saving AddressExtract for submission {}", addressExtract.getSubmissionId());
            throw new RuntimeException(String.format("Failed to save AddressExtract for submissionId {} and formType {}",
                    addressExtract.getSubmissionId(), addressExtract.getFormType()), e);
        }
    }

    public AddressExtract update(@NonNull AddressExtract addressExtract) {
        final UpdateItemEnhancedRequest<AddressExtract> enhancedRequest = UpdateItemEnhancedRequest
                .builder(AddressExtract.class)
                .item(addressExtract)
                .build();
        try {
            return table.updateItem(enhancedRequest);
        } catch (Exception e) {
            log.error("Exception encountered during updateItem for AddressExtract for submission with id {} and formType {}",
                    addressExtract.getSubmissionId(), e.getMessage());
            throw new RuntimeException(String.format("Failed to update AddressExtract for submissionId {} and formType {}",
                    addressExtract.getSubmissionId(), addressExtract.getFormType()), e);        }
    }

    public Optional<AddressExtract> getBySubmissionId(String submissionId) {
        try {
            GetItemEnhancedRequest request = GetItemEnhancedRequest.builder()
                    .key(builder -> builder.partitionValue(submissionId))
                    .consistentRead(true)
                    .build();
            log.info("Retrieved AddressExtract for submissionId {}", submissionId);
            return Optional.ofNullable(table.getItem(request));
        } catch (Exception e) {
            log.error("Error retrieving AddressExtract for submission {}", submissionId);
            throw new RuntimeException(String.format("Failed to retrieve AddressExtract for submissionId {}.",
                    submissionId), e);
        }
    }

    public void deleteBySubmissionId(@NonNull String submissionId) {
        try {
            DeleteItemEnhancedRequest deleteRequest = DeleteItemEnhancedRequest.builder()
                    .key(builder -> builder.partitionValue(submissionId)).build();
            table.deleteItem(deleteRequest);
            log.info("Deleted AddressExtract for submissionId {}", submissionId);
        } catch (Exception e) {
            log.error("Error deleting AddressExtract for submissionId {}", submissionId);
            throw new RuntimeException(String.format("Failed to delete AddressExtract for submissionId {}.",
                    submissionId), e);
        }
    }
}
