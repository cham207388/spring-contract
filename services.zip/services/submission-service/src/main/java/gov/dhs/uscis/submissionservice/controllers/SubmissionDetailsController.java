package gov.dhs.uscis.submissionservice.controllers;

import java.math.BigDecimal;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

import gov.dhs.uscis.submissionservice.services.FeeService;

@RestController
@RequestMapping("/api/v1/submissions")
public class SubmissionDetailsController {
    
    private FeeService feeService;
public record FeeDetails(BigDecimal amount, String eligibilityCategory, boolean isUnder14, List<String> formTypeList){}

    public SubmissionDetailsController(FeeService feeService){
        this.feeService = feeService;
    }

    @GetMapping("/{submissionId}/fee")
    public FeeDetails getFeeDetails(@PathVariable String submissionId ){
        return feeService.retrieveCalculatedFeeFor(submissionId);
    }
    
}
