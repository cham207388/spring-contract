package gov.dhs.uscis.submissionservice.services;

import static gov.dhs.uscis.intake.entities.audit.ActionPerformed.*;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.*;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.*;
import static java.util.Collections.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.constants.DocumentType;
import gov.dhs.uscis.intake.constants.FeeWaiverErrors;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.enums.AccountType;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I140FormSpecificInfo;
import gov.dhs.uscis.intake.models.validation.ValidationDetails;
import gov.dhs.uscis.intake.models.validation.Validation;
import gov.dhs.uscis.intake.models.validation.ValidationStatusEnum;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResponse;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResult;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.intake.services.formats.MagicBytes;
import gov.dhs.uscis.submissionservice.exception.ValidationStatusDeletionException;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.utils.FormValidationStatusUtil;
import gov.dhs.uscis.submissionservice.utils.SubmissionEvidenceUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ValidationService {

    public static final String FORM_797C  = "Form-797c";
    public static final String FORM_797 = "Form-797";
    public static final String ETA_9089FINAL = "ETA9089 FD";


    private static final List<String> EVIDENCE_TYPES_WITH_VALIDATIONS = List.of(FORM_797, FORM_797C);
    private final ValidationStatusRepository validationStatusDAO;
    private AuditService auditService;
    private FormService formService;
    private ToggleService toggleService;

    public ValidationService(ValidationStatusRepository validationStatusDAO, AuditService auditService, ToggleService toggleService,
            FormService formService) {
        this.validationStatusDAO = validationStatusDAO;
        this.auditService = auditService;
        this.formService = formService;
        this.toggleService = toggleService;
    }

    public ValidationStatusResponse retrieveValidationStatus(Submission submission) {

        Boolean isSubmissionByRepresentative = submission.getApplicant() != null
            ? AccountType.REPRESENTATIVE.equals(submission.getApplicant().getAccountType())
            : false;

        List<SubmissionForm> submissionForms = Optional.ofNullable(submission.getForms()).orElse(emptyList());
        List<Validation> formValidations = submissionForms.stream()
        .map(submissionForm -> retrieveFormValidationStatus(submissionForm, isSubmissionByRepresentative))
        .filter(Optional::isPresent)
        .map(Optional::get)
        .toList();

        List<SubmissionEvidence> evidences = Optional.ofNullable(submission.getEvidences()).orElse(emptyList());
        List<Validation> evidenceValidations = evidences.stream()
                .map(evidence -> retrieveEvidenceValidationStatus(submission.getFormSpecificInfo(), evidence))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .toList();

        ValidationStatusEnum responseStatus = determineResponseStatus(formValidations, evidenceValidations);

        return ValidationStatusResponse
                .builder()
                .status(responseStatus)
                .formValidations(formValidations)
                .evidenceValidations(evidenceValidations)
                .build();
    }

    private Optional<Validation> retrieveFormValidationStatus(SubmissionForm form, Boolean isSubmissionByRepresentative) {
        log.info("Retrieving form validation status: {}", form.getType());

            List<ValidationStatus> validations = validationStatusDAO.getByFileId(form.getId())
                .stream()
                .toList();
            FormMetaData formMetaData = formService.retrieveFormMetaData(form.getType());
            formMetaData = determineValidationsBasedOnPFVS(form.getType(), formMetaData);
            log.info("{} -> {} form validations size: {}", form.getType(), form.getId(),
                    validations.size());
            return Optional.of(Validation.builder()
                    .groupType(form.getType())
                    .id(form.getId())
                    .status(FormValidationStatusUtil.determineFormStatus(validations, formMetaData, isSubmissionByRepresentative))
                    .details(mapResultsToValidationList(validations))
                    .build());
    }

    public Optional<Validation> retrieveEvidenceValidationStatus(FormSpecificInfo formSpecificInfo, SubmissionEvidence evidence) {
        log.info("Retrieving validation status: {}", evidence.getEvidenceGroupType());
        if (EVIDENCE_TYPES_WITH_VALIDATIONS.contains(evidence.getType()) || ( ETA_9089FINAL.equals(evidence.getType()) && !((I140FormSpecificInfo) formSpecificInfo).getIsScheduleA() ) ) {
            List<ValidationStatus> validations = validationStatusDAO.getByFileId(evidence.getId());
            log.info("{} -> {} validations size: {}", evidence.getEvidenceGroupType(), evidence.getId(),
                    validations.size());
            return Optional.of(Validation.builder()
                    .groupType(evidence.getEvidenceGroupType())
                    .id(evidence.getId())
                    .status( determineEvidenceStatus(validations))
                    .details(mapResultsToValidationList(validations))
                    .build());

        }

        log.info("No validations are required, returning the empty set {} - {}", evidence.getEvidenceGroupType(),
                evidence.getId());
        return Optional.empty();
    }

    public ValidationStatusResponse retrieveI912ValidationStatus(String formId, Submission submission) {
        List<ValidationStatus> queryResult = queryValidationStatus(formId);
        if (queryResult == null)
            return null;

        ValidationStatus i912ValidationStatus = queryResult.stream()
                .filter(el -> ValidatorEnum.I912.equals(el.getValidator())).findFirst().orElse(null);

        SubmissionEvidence feeWaiver = submission.getFeeWaiver();

        boolean feeWaiverIsNotPDFDocument = feeWaiver != null
                && feeWaiver.getS3Key() != null
                && !SubmissionEvidenceUtil.isFileExtension(feeWaiver.getS3Key(), MagicBytes.PDF);

        boolean isDocTypeFeeDeclaration = feeWaiver != null
                && DocumentType.FeeWaiver.FEE_DECLARATION.equals(feeWaiver.getType());

        boolean uploadedFormIsNotI912 = i912ValidationStatus != null && i912ValidationStatus.getFailureReasons() != null
                && i912ValidationStatus.getFailureReasons().contains(FeeWaiverErrors.FORM_TYPE_NOT_PRESENT_MESSAGE);


        if ((isDocTypeFeeDeclaration && uploadedFormIsNotI912) || feeWaiverIsNotPDFDocument ) {
            return ValidationStatusResponse.builder()
                    .status(ValidationStatusEnum.COMPLETE)
                    .i912FeeWaiverValidation(
                        ValidationDetails.builder()
                            .validator(ValidatorEnum.I912)
                            .result(ValidationResultEnum.PASS)
                            .reasons(List.of())
                            .warnings(Map.of())
                            .build()
                    )
                    .build();
        }


        ValidationStatusEnum statusEnum = i912ValidationStatus != null ? ValidationStatusEnum.COMPLETE
                : ValidationStatusEnum.IN_PROGRESS;



        return ValidationStatusResponse.builder().status(statusEnum)
                .i912FeeWaiverValidation(
                    ValidationStatusEnum.IN_PROGRESS.equals(statusEnum) ? null
                        : mapValidationStatusToValidationDetails(i912ValidationStatus)
                )
                .build();
    }

    public void saveSignatureResult(ValidationStatusResult incomingResult, String messageId) {
        ValidationStatus incomingValidation = ValidationStatus.fromResult(incomingResult);

        var existingValidation = validationStatusDAO.getByFileId(incomingValidation.getFormId()).stream()
                .filter(validation -> validation.getValidator().equals(ValidatorEnum.SIGNATURE)
                        && validation.getFormId().equals(incomingValidation.getFormId())
                        && validation.isMultipart()
                        && !messageId.equals(validation.getMessageId()))
                .findFirst();

        if(existingValidation.isPresent()){
            ValidationResultEnum status = ValidationResultEnum.PASS.equals(existingValidation.get().getStatus())
            && ValidationResultEnum.PASS.equals(incomingValidation.getStatus()) ? ValidationResultEnum.PASS : ValidationResultEnum.FAIL;

            incomingValidation.setStatus(status);
            String i765RepresentativeFlowErrorMessage = "The uploaded form is missing one or both signatures. Please sign the form and reupload.";
            incomingValidation.setFailureReasons(ValidationResultEnum.PASS.equals(status) ? List.of() : List.of(i765RepresentativeFlowErrorMessage));
            incomingValidation.setMultipart(false);
        }

        validationStatusDAO.save(incomingValidation);

        if (SIGNATURE.equals(incomingValidation.getValidator()) && incomingValidation.getStatus() != null) {
            ActionPerformed action = incomingValidation.getStatus().equals(PASS) ? SIGNATURE_DETECTED : SIGNATURE_NOT_DETECTED;
            auditService.addEvent(incomingResult.myUscisId(), incomingValidation.getSubmissionId(), action, "");
        }
    }

    public void createFrom(ValidationStatusResult result) {
        ValidationStatus validationStatus = ValidationStatus.builder()
                .formId(result.formId())
                .submissionId(result.submissionId())
                .status(result.status())
                .validator(result.validator())
                .validationWarnings(result.validationWarnings())
                .failureReasons(result.failureReasons().stream()
                        .flatMap(reasons -> reasons.values().stream())
                        .collect(Collectors.toList()))
                .build();

        validationStatusDAO.save(validationStatus);
    }

    public List<ValidationStatus> queryValidationStatus(String fileId) {
        try {
            return validationStatusDAO.getByFileId(fileId);
        } catch (NoSuchElementException e) {
            throw new NoSuchElementException(e.getMessage() + " for form ID: " + fileId);
        }
    }

    private ValidationStatusEnum determineEvidenceStatus(List<ValidationStatus> validations) {
        return validations.isEmpty() ? ValidationStatusEnum.IN_PROGRESS : ValidationStatusEnum.COMPLETE;
    }

    private ValidationStatusEnum determineResponseStatus(List<Validation> formValidations, List<Validation> evidenceValidations) {
        boolean formValidationInProgress = formValidations.stream().anyMatch(
            formValidation -> ValidationStatusEnum.IN_PROGRESS.equals(formValidation.status())
        );

        boolean evidenceValidationInProgress = evidenceValidations.stream().anyMatch(
            evidenceValidation -> ValidationStatusEnum.IN_PROGRESS.equals(evidenceValidation.status())
        );

        return (formValidationInProgress || evidenceValidationInProgress) ?
            ValidationStatusEnum.IN_PROGRESS : ValidationStatusEnum.COMPLETE;
    }

    private List<ValidationDetails> mapResultsToValidationList(List<ValidationStatus> results) {
        return !results.isEmpty() ? results
                .stream()
                .map(result -> mapValidationStatusToValidationDetails(result))
                .collect(Collectors.toList()) : Collections.emptyList();
    }

    private ValidationDetails mapValidationStatusToValidationDetails(ValidationStatus validationStatus) {
        return new ValidationDetails(validationStatus.getValidator(), validationStatus.getStatus(),
        validationStatus.getFailureReasons(), validationStatus.getValidationWarnings());
    }

    public void deleteStatus(String fileId) {
        try {
            List<ValidationStatus> vStatusList = validationStatusDAO.getByFileId(fileId);
            for (ValidationStatus vStatus : vStatusList) {
                validationStatusDAO.deleteById(fileId, vStatus.getValidator());
            }
        } catch (Exception e) {
            throw new ValidationStatusDeletionException(e.getMessage() + " for form ID: " + fileId);
        }
    }

    public boolean validateUpdateSubmission(Submission submission, FormType formType) {
        var feeWaiverEnabled = formService.isFeeWaiverEnabled(formType);
        return submission.getEligibilityCategory() != null || submission.getImmvi() != null
                || (submission.getUserRequestedFeeWaiver() != null && feeWaiverEnabled) || submission.getHasReviewedSignature() != null
                || submission.getAttested() != null || (submission.getUserRequestedPartialFeeWaiver() != null && feeWaiverEnabled);
    }

        public FormMetaData determineValidationsBasedOnPFVS(String formType, FormMetaData formMetaData ) {
        if(toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, formType) && !formType.equals(FormType.G28.getType()))  {
            formMetaData.setValidations(List.of(MetadataValidationEnum.PFVS));
            return formMetaData;
        }
        else if ( formType.equals(FormType.G28.getType())) {
                        formMetaData.setValidations(List.of(MetadataValidationEnum.CORE, MetadataValidationEnum.SIGNATURE, MetadataValidationEnum.G28_COMP, MetadataValidationEnum.G28_COMP_NAME, MetadataValidationEnum.G28_NAME_EMAIL, MetadataValidationEnum.G28_ATTORNEY_NAME ));
                        return formMetaData;

        }else {
            formMetaData.setValidations(List.of(MetadataValidationEnum.CORE, MetadataValidationEnum.SIGNATURE, MetadataValidationEnum.FORM_FIELDS, MetadataValidationEnum.G28_COMP, MetadataValidationEnum.G28_COMP_NAME ));
            return formMetaData;
        }
    }
}
