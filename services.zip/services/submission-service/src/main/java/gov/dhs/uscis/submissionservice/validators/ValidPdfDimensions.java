package gov.dhs.uscis.submissionservice.validators;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

@Target({ElementType.PARAMETER, ElementType.FIELD, ElementType.TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PdfDimensionValidator.class)
public @interface ValidPdfDimensions {
    String message() default "PDF dimensions exceed the maximum allowable size.";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
