package gov.dhs.uscis.submissionservice.exception;

public class FormProtectedException extends RuntimeException {

    public FormProtectedException(String errorMessage) {
        super(String.format("%s", errorMessage));
    }
}
