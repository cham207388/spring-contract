package gov.dhs.uscis.submissionservice.controllers;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.elis.ELISIngestionPackage;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "Submission by Manifest", description = "Submission Manifest APIs")
@RestController
@RequestMapping("/api/v1/submissions")
public class SubmissionManifestController {

    private static final String MANIFEST_ID = "manifestId";
    private final SubmissionService service;
    private ElisDataEnrichmentPipeline dataEncrichmentPipeline;

    public SubmissionManifestController(
            SubmissionService service,
            ElisDataEnrichmentPipeline dataEncrichmentPipeline) {
        this.service = service;
        this.dataEncrichmentPipeline = dataEncrichmentPipeline;
    }

    @GetMapping("/manifest/{manifestId}")
    @Operation(description = "System API invoked by ELIS to retrieve submission information by manifest Id")
    public ResponseEntity<Submission> getSubmissionByManifestId(@PathVariable String manifestId) {
        Optional<Submission> submission = Optional.empty();
        try {
            submission = service.retrieveSubmissionByManifestId(manifestId);
        } catch( Exception e ){
            log.error("Error while retrieving submission based on manifesgt id {}", manifestId);
            return ResponseEntity.notFound().build();
        }
        return submission.isPresent() ? 
        ResponseEntity.ok(dataEncrichmentPipeline.enrich(submission.get())) : ResponseEntity.notFound().build();
    }

    @GetMapping("/manifest/{manifestId}/icamuuids")
    @Operation(description = "System API invoked by ELIS to retrieve a map of ICAM UUIDs on a submission by manifest Id")
    public ResponseEntity<Map<String, String>> getSubmissionUUIDsByManifestId(@PathVariable String manifestId) {
        Optional<Submission> submission = Optional.empty();
        Map<String, String> submissionUUIDs;
        try {
            submission = service.retrieveSubmissionByManifestId(manifestId);
            submissionUUIDs = service.getSubmissionICAMUUIDs(submission.get());
        } catch( Exception e ){
            log.error("Error while retrieving submission based on manifest id {}", manifestId);
            return ResponseEntity.notFound().build();
        }
        return !submissionUUIDs.isEmpty() ? 
        ResponseEntity.ok(submissionUUIDs) : ResponseEntity.notFound().build();
    }

    @GetMapping("/{submissionId}/manifest/id")
    @Operation(description = "System API invoked by ELIS to map submission ids to transmission ids (also know as manifest ids)")
    public ResponseEntity<?> getManifestIdBySubmissionId(@PathVariable("submissionId") String submissionId) {
        log.info("Looking up mapping submission id:  {}", submissionId);
        Submission submission = service.retrieveSubmission(submissionId);
        // This can happen if the submission id is not set or the manifest id is not
        // set.
        if (submission != null) {
            return submission.getManifestId() == null ? ResponseEntity.notFound().build()
                    : ResponseEntity.ok(Map.of(MANIFEST_ID, submission.getManifestId()));
        }

        return ResponseEntity.notFound().build();
    }
    
    @GetMapping("/{submissionId}/ingestion")
    @Operation(description = "System API invoked by ELIS to map submission ids to transmission ids (also know as manifest ids)")
    public ResponseEntity<ELISIngestionPackage> getInformationForELISIngestion(@PathVariable("submissionId") String submissionId) {
        log.info("Looking up ingestion dto for submission id:  {}", submissionId);
        Submission submission = service.retrieveSubmission(submissionId);
        
        if (submission != null) {
        	Map<String, String> s3KeyMap = new HashMap<>();
        	submission.getForms().stream().forEach(form -> {
        		s3KeyMap.put(form.getType(), form.getS3Key());
        	});
        	String userGroupId = submission.getApplicant().getUserGroupId();
        	
        	if(s3KeyMap.get(FormType.G28.getType()) != null) {
        		userGroupId = submission.getClientInformation().getClientId();
        	}
        	
        	return ResponseEntity.ok(ELISIngestionPackage.builder()
            		.submissionId(submission.getSubmissionId())
            		.myUscisId(submission.getMyUscisId())
            		.manifestId(submission.getManifestId())
            		.userGroupId(userGroupId)
            		.s3Key(s3KeyMap)
            		.build());
        }

        return ResponseEntity.notFound().build();
    }
}
