package gov.dhs.uscis.submissionservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "toggle_form_type_override")
public class ToggleFormTypeOverride {

    public ToggleFormTypeOverride(String toggleName, String formType, boolean active) {
        this.id = new ToggleFormType(toggleName, formType);
        this.active = active;
    }

    public ToggleFormTypeOverride(){}

    @EmbeddedId
    private ToggleFormType id;
    
    @Column(name = "active")
    private boolean active;
}
