package gov.dhs.uscis.submissionservice.components;

import java.security.SecureRandom;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.stereotype.Component;

import com.google.common.base.Function;

@Component("uuid")
public class UuidGenerator implements Function<String, String> {
    private final SecureRandom random = new SecureRandom();

    @Override
    public String apply(String input) {
        return UUID.nameUUIDFromBytes(
                String.format("%s.%s", input,
                    generateAlphnumericString(10)).getBytes())
                .toString();
    }

    private String generateAlphnumericString(int length) {
        final String ALPHANUMERICS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        return IntStream.range(0, length)
                        .mapToObj(i -> {
                            final int index = random.nextInt(ALPHANUMERICS.length());
                            return String.valueOf(ALPHANUMERICS.charAt(index));
                        })
                        .collect(Collectors.joining());
    }
    
}
