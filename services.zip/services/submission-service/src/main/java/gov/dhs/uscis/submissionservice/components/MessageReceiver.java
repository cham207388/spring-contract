package gov.dhs.uscis.submissionservice.components;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import gov.dhs.uscis.intake.constants.DocumentType.FeeWaiver;

import software.amazon.awssdk.services.sns.model.InvalidStateException;
import com.amazonaws.services.lambda.runtime.events.SNSEvent.SNS;
import com.amazonaws.services.lambda.runtime.events.models.s3.S3EventNotification;
import com.amazonaws.services.lambda.runtime.serialization.PojoSerializer;
import com.amazonaws.services.lambda.runtime.serialization.events.LambdaEventSerializers;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.enums.ValidatorInfo;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.validation.ClientNameEmailResponse;
import gov.dhs.uscis.intake.models.validation.FormFieldResult;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResult;
import gov.dhs.uscis.intake.models.validation.address_extract.AddressValidationResult;
import gov.dhs.uscis.intake.models.validation.name_extract.NameValidationResult;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ToggleService;
import gov.dhs.uscis.submissionservice.services.ValidationService;
import gov.dhs.uscis.submissionservice.validators.AddressValidator;
import gov.dhs.uscis.submissionservice.validators.FieldValidator;
import gov.dhs.uscis.submissionservice.validators.NameValidator;
import gov.dhs.uscis.submissionservice.validators.PersonValidator;
import gov.dhs.uscis.submissionservice.validators.AttorneyProfileValidator.AttorneyNameMatchesFormValidator;
import gov.dhs.uscis.submissionservice.validators.AttorneyProfileValidator.ClientNameEmailValidator;
import gov.dhs.uscis.submissionservice.validators.i765.AbcBenefitsAppliedValidator;
import gov.dhs.uscis.submissionservice.validators.i765.EligibilityCategoryValidator;
import gov.dhs.uscis.submissionservice.validators.i765.ReasonForFilingValidator;
import gov.dhs.uscis.submissionservice.validators.n400.BasisOfEligibilityValidator;

import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.DeleteMessageRequest;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.SqsException;

@Component
public class MessageReceiver {
    ObjectMapper mapper = new ObjectMapper();
    private Logger logger = LoggerFactory.getLogger(MessageReceiver.class);

    private static final String TRACE_ID = "traceId";

    @Value("${uscis.sqs.validation.queueUrl}")
    private String queueUrl;

    @Value("${uscis.sqs.validation.i912.queueUrl}")
    private String i912ResultQueue;

    @Value("${uscis.sqs.validation.field.queueUrl}")
    private String fieldQueueUrl;

    @Value("${uscis.sqs.validation.eligibility.queueUrl}")
    private String eligibilityResultQueue;

    @Value("${uscis.sqs.validation.person.queueUrl}")
    private String personResultQueue;

    @Value("${uscis.sqs.validation.name.queueUrl}")
    private String nameResultQueue;

    @Value("${uscis.sqs.validation.address.queueUrl}")
    private String addressResultQueue;

    @Value("${uscis.sqs.validation.clientNameEmail.queueUrl}")
    private String clientNameEmailQueueUrl;

    @Value("${uscis.sqs.validation.attorneyName.queueUrl}")
    private String attorneyNameQueueUrl;

    DynamoDbTable<ValidationStatus> validationStatusTable;
    SqsClient sqsClient;
    EligibilityCategoryValidator eligibilityCategoryValidator;
    AbcBenefitsAppliedValidator abcBenefitsAppliedValidator;
    SubmissionService submissionService;
    ValidationService validationService;
    BasisOfEligibilityValidator basisOfEligibilityValidator;
    PersonValidator personValidator;
    NameValidator nameValidator;
    AddressValidator addressValidator;
    ClientNameEmailValidator clientNameEmailValidator;
    AttorneyNameMatchesFormValidator attorneyNameMatchesFormValidator;
    ReasonForFilingValidator reasonForFilingValidator;
    ToggleService toggleService;

    final PojoSerializer<SNS> snsSerializer = LambdaEventSerializers.serializerFor(SNS.class,
            Thread.currentThread().getContextClassLoader());
    final PojoSerializer<S3EventNotification> s3Serializer = LambdaEventSerializers
            .serializerFor(S3EventNotification.class, Thread.currentThread().getContextClassLoader());

    private List<FieldValidator> fieldValidators;

    public MessageReceiver(DynamoDbTable<ValidationStatus> validationStatusTable, SqsClient sqsClient,
            EligibilityCategoryValidator eligibilityCategoryValidator,
            PersonValidator personValidator,
            AbcBenefitsAppliedValidator abcBenefitsAppliedValidator,
            SubmissionService submissionService,
            ValidationService validationService,
            BasisOfEligibilityValidator basisOfEligibilityValidator,
            NameValidator nameValidator,
            AddressValidator addressValidator,
            ClientNameEmailValidator clientNameEmailValidator,
            AttorneyNameMatchesFormValidator attorneyNameMatchesFormValidator,
            ReasonForFilingValidator reasonForFilingValidator,
            ToggleService toggleService) {
        this.validationStatusTable = validationStatusTable;
        this.sqsClient = sqsClient;
        this.submissionService = submissionService;
        this.validationService = validationService;
        this.basisOfEligibilityValidator = basisOfEligibilityValidator;
        this.fieldValidators = List.of(eligibilityCategoryValidator, abcBenefitsAppliedValidator, reasonForFilingValidator);
        this.nameValidator = nameValidator;
        this.addressValidator = addressValidator;
        this.clientNameEmailValidator = clientNameEmailValidator;
        this.attorneyNameMatchesFormValidator = attorneyNameMatchesFormValidator;
        this.personValidator = personValidator;
        this.toggleService = toggleService;
    }

    @Scheduled(fixedDelayString = "${uscis.sqs.fixedDelay}", initialDelayString = "${uscis.sqs.initialDelay}")
    public void receiveValidationResultMessage() {
        try {
            for (Message message : getMessagesFromQueue(queueUrl)) {
                MDC.put(TRACE_ID, UUID.randomUUID().toString());
                logger.info(String.format("Received SQS validation message: %s", message));
                ValidationStatusResult validationStatus = mapper.readValue(message.body(),
                        ValidationStatusResult.class);

                if (ValidatorEnum.SIGNATURE.equals(validationStatus.validator())) {
                    validationService.saveSignatureResult(validationStatus, message.messageId());
                } else {
                    validationService.createFrom(validationStatus);
                }

                sqsClient.deleteMessage(DeleteMessageRequest.builder().queueUrl(queueUrl)
                        .receiptHandle(message.receiptHandle()).build());
            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
        } finally {
            MDC.clear();
        }
    }

    @Scheduled(fixedDelayString = "${uscis.sqs.fixedDelay}", initialDelayString = "${uscis.sqs.initialDelay}")
    public void receiveI912ValidationResultMessage() {
        try {
            for (Message message : getMessagesFromQueue(i912ResultQueue)) {
                MDC.put(TRACE_ID, UUID.randomUUID().toString());
                logger.info(String.format("Received SQS validation message: %s", message));
                ValidationStatusResult validationStatus = mapper.readValue(message.body(),
                        ValidationStatusResult.class);
                validationService.createFrom(validationStatus);

                if(isI912Form(validationStatus)) {
                    logger.info("I-912 FORM DETECTED, SETTING FEE WAIVER TYPE");
                    Submission submission = submissionService.retrieveDraftSubmission(validationStatus.myUscisId(), null, validationStatus.submissionId());
                    if (toggleService.isToggleActive(ToggleEnum.PFVS_ENABLED, submission.getFormType().getType()) && submission.getFormType() == FormType.I751) {
                        logger.info("Setting the fee to 0 as a fee waiver was detected for submissionId {}", submission.getSubmissionId());

                    BigDecimal feeTotal = BigDecimal.ZERO;
                    submission.setFeeTotal(feeTotal);
                    }

                submission = submissionService.updateFeeWaiverEvidence(submission, FeeWaiver.FORM_I912, true);
                }

                sqsClient.deleteMessage(DeleteMessageRequest.builder().queueUrl(i912ResultQueue)
                        .receiptHandle(message.receiptHandle()).build());
            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
        } finally {
            MDC.clear();
        }
    }

    private boolean isI912Form(ValidationStatusResult validationStatus) {
        if(validationStatus.validationWarnings() == null) {
            return false;
        }
        String IS_I912_FORM = validationStatus.validationWarnings().get(ValidatorInfo.IS_I912_FORM.toString());
        return "true".equals(IS_I912_FORM);
    }

    @Scheduled(fixedDelayString = "${uscis.sqs.fixedDelay}", initialDelayString = "${uscis.sqs.initialDelay}")
    public List<FormFields> receiveFormFieldsValidationResultMessage() {
        List<FormFields> formFieldsValidationStatusResultList = new ArrayList<>();
        try {
            for (Message message : getMessagesFromQueue(fieldQueueUrl)) {
                MDC.put(TRACE_ID, UUID.randomUUID().toString());
                logger.info(String.format("Received SQS Form Field validation message: %s", message));
                FormFields formFields = mapper.readValue(message.body(),
                        FormFields.class);
                var submission = fetchDraftSubmission(formFields);
                if (submission.getFormType() == FormType.I751 || submission.getFormType() == FormType.I765
                      || submission.getFormType() == FormType.N400)
{
                    personValidator.validate(formFields.alienNumber(), formFields.dateOfBirth(),
                            formFields.formId(),
                            formFields.submissionId(),
                            submission.getFormType());
}
                fieldValidators.forEach(validator -> validator.validate(submission, formFields));

                formFieldsValidationStatusResultList.add(formFields);

                submissionService.updateSubmissionWithFormFields(formFields, submission.getFormType());

                sqsClient.deleteMessage(DeleteMessageRequest.builder().queueUrl(fieldQueueUrl)
                        .receiptHandle(message.receiptHandle()).build());

            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
        } finally {
            MDC.clear();
        }

        return formFieldsValidationStatusResultList;
    }

    @Scheduled(fixedDelayString = "${uscis.sqs.fixedDelay}", initialDelayString = "${uscis.sqs.initialDelay}")
    public void receiveEligibilityValidationResultMessage() {
        try {
            for (Message message : getMessagesFromQueue(eligibilityResultQueue)) {
                MDC.put(TRACE_ID, UUID.randomUUID().toString());
                logger.info(String.format("Received SQS Form Field validation message: %s", message));
                FormFieldResult result = mapper.readValue(message.body(), FormFieldResult.class);

                var submission = fetchDraftSubmission(result);
                basisOfEligibilityValidator.validate(submission, result);

                var formFields = FormFields.builder()
                        .formId(result.getFormId())
                        .submissionId(result.getSubmissionId())
                        .abcBenefitsApplied(false)
                        .eligibilityCategory(result.getSelectedCategories().getFirst().getCategory())
                        .build();

                submissionService.updateSubmissionWithFormFields(formFields, submission.getFormType());

                sqsClient.deleteMessage(DeleteMessageRequest.builder().queueUrl(eligibilityResultQueue)
                        .receiptHandle(message.receiptHandle()).build());

            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
        } finally {
            MDC.clear();
        }
    }

    @Scheduled(fixedDelayString = "${uscis.sqs.fixedDelay}", initialDelayString = "${uscis.sqs.initialDelay}")
    public void receivePersonValidationResultMessage() {
        try {
            for (Message message : getMessagesFromQueue(personResultQueue)) {
                MDC.put(TRACE_ID, UUID.randomUUID().toString());
                logger.info("Received SQS Form Field validation message");
                FormFieldResult result = mapper.readValue(message.body(), FormFieldResult.class);
                logger.info("submissionId: {}, formId: {}", result.getSubmissionId(), result.getFormId());

                var submission = fetchDraftSubmission(result);

                // validate based on form type
                personValidator.validate(result.getAlienNumber(), result.getDateOfBirth(), result.getFormId(),
                        result.getSubmissionId(), submission.getFormType());

                sqsClient.deleteMessage(DeleteMessageRequest.builder().queueUrl(personResultQueue)
                        .receiptHandle(message.receiptHandle()).build());

            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
        } finally {
            MDC.clear();
        }
    }

    @Scheduled(fixedDelayString = "${uscis.sqs.fixedDelay}", initialDelayString = "${uscis.sqs.initialDelay}")
    public void receiveNameValidationResultMessage() {
        try {
            for (Message message : getMessagesFromQueue(nameResultQueue)) {
                MDC.put(TRACE_ID, UUID.randomUUID().toString());
                logger.info(String.format("Received SQS Form Field validation message: %s",
                        message));
                NameValidationResult result = mapper.readValue(message.body(), NameValidationResult.class);
                nameValidator.validate(result);
                sqsClient.deleteMessage(DeleteMessageRequest.builder().queueUrl(nameResultQueue)
                        .receiptHandle(message.receiptHandle()).build());
            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
        } finally {
            MDC.clear();
        }
    }

    @Scheduled(fixedDelayString = "${uscis.sqs.fixedDelay}", initialDelayString = "${uscis.sqs.initialDelay}")
    public void receiveAddressValidationResultMessage() {
        try {
            for (Message message : getMessagesFromQueue(addressResultQueue)) {
                MDC.put(TRACE_ID, UUID.randomUUID().toString());
                AddressValidationResult result = mapper.readValue(message.body(), AddressValidationResult.class);
                addressValidator.validate(result);
                sqsClient.deleteMessage(DeleteMessageRequest.builder().queueUrl(addressResultQueue)
                        .receiptHandle(message.receiptHandle()).build());
            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
        } finally {
            MDC.clear();
        }
    }

    @Scheduled(fixedDelayString = "${uscis.sqs.fixedDelay}", initialDelayString = "${uscis.sqs.initialDelay}")
    public void receiveClientNameEmailValidationResultMessage() {
        try {
            for (Message message : getMessagesFromQueue(clientNameEmailQueueUrl)) {
                MDC.put(TRACE_ID, UUID.randomUUID().toString());
                logger.info(String.format("Received SQS Client name-email validation message: %s",
                        message));
                ClientNameEmailResponse result = mapper.readValue(message.body(), ClientNameEmailResponse.class);

                clientNameEmailValidator.validate(result);

                sqsClient.deleteMessage(DeleteMessageRequest.builder().queueUrl(clientNameEmailQueueUrl)
                        .receiptHandle(message.receiptHandle()).build());
            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
        } finally {
            MDC.clear();
        }
    }

    @Scheduled(fixedDelayString = "${uscis.sqs.fixedDelay}", initialDelayString = "${uscis.sqs.initialDelay}")
    public void receiveAttorneyNameValidationResultMessage() {
        try {
            for (Message message : getMessagesFromQueue(attorneyNameQueueUrl)) {
                MDC.put(TRACE_ID, UUID.randomUUID().toString());
                logger.info(String.format("Received SQS Attorney name validation message: %s",
                        message));
                ClientNameEmailResponse result = mapper.readValue(message.body(), ClientNameEmailResponse.class);

                attorneyNameMatchesFormValidator.validate(result);

                sqsClient.deleteMessage(DeleteMessageRequest.builder().queueUrl(attorneyNameQueueUrl)
                        .receiptHandle(message.receiptHandle()).build());
            }
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
        } finally {
            MDC.clear();
        }
    }

    private List<Message> getMessagesFromQueue(String queueName) {
        try {
            ReceiveMessageRequest receiveMessageRequest = ReceiveMessageRequest.builder()
                    .queueUrl(queueName)
                    .maxNumberOfMessages(5)
                    .build();
            return sqsClient.receiveMessage(receiveMessageRequest).messages();
        } catch (SqsException e) {
            logger.error(e.awsErrorDetails().errorMessage(), e);
            return List.of();
        }
    }

    private Submission fetchDraftSubmission(FormFields formFields) {
        String submissionId = formFields.submissionId();
        return getDraftSubmissionById(submissionId);
    }

    private Submission fetchDraftSubmission(FormFieldResult fields) {
        String submissionId = fields.getSubmissionId();
        return getDraftSubmissionById(submissionId);
    }

    private Submission getDraftSubmissionById(String submissionId) {
        var submission = submissionService.retrieveSubmission(submissionId);
        if (submission.getStatus() != SubmissionState.DRAFT) {
            logger.error("Attempt to update eligibility category on non-draft submission {}",
                    submission.getSubmissionId());
            throw InvalidStateException.builder().message("Submission is not a draft: " + submissionId).build();
        }
        return submission;
    }
}
