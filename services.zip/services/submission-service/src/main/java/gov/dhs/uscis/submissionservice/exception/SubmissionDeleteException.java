package gov.dhs.uscis.submissionservice.exception;

public class SubmissionDeleteException extends RuntimeException {

  public SubmissionDeleteException(String errorMessage) {
    super(String.format("%s", errorMessage));
  }
}
