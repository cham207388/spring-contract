package gov.dhs.uscis.submissionservice.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.submissionservice.services.mappers.ELISEvidenceMapper;
import gov.dhs.uscis.submissionservice.services.mappers.SubmissionTransformation;

@Service
public class ElisDataEnrichmentPipeline {

    private List<SubmissionTransformation> transformations;

    public ElisDataEnrichmentPipeline(
            @Value("${application.elis.downloaderOverride.url}") String downloaderOverrideUrl,
            @Value("${application.elis.downloaderOverride.enabled:false}") boolean downloaderOverrideEnabled) {

        transformations = new ArrayList<SubmissionTransformation>();
        transformations.add(new ELISEvidenceMapper());
        if (downloaderOverrideEnabled)
            transformations.add(new ElISDownloaderUrlMapper(downloaderOverrideUrl));
    }

    public Submission enrich(Submission submission) {
        for (var transformation : transformations) {
            transformation.transform(submission);
        }

        return submission;
    }
}
