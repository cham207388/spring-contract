package gov.dhs.uscis.submissionservice.services;

import java.time.Duration;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

public class LockboxGatewayClient {

    private static final String MANIFEST_ID = "manifestId";
    private static final String SUBMISSION_ID = "submissionId";
    private Logger logger = LoggerFactory.getLogger(LockboxGatewayClient.class);
    private WebClient lockboxWebClient;
    private int retryAttempts;
    private int retryDurationSeconds;

    public LockboxGatewayClient(WebClient lockboxWebClient, int retryAttempts, int retryDurationSeconds ){
        this.lockboxWebClient = lockboxWebClient;
        this.retryAttempts = retryAttempts;
        this.retryDurationSeconds = retryDurationSeconds;
    }

    public Mono<String> sendTransmission(final LockboxTransmission transmission) {
        logger.debug("Sending transaction to lockbox-gateway for submission {}",
                transmission.getSubmission().getSubmissionId());
        return lockboxWebClient
                .post()
                .uri("/api/v1/manifest")
                .bodyValue(transmission)
                .retrieve()
                .onStatus(HttpStatusCode::isError,
                        err -> Mono.error(
                                new ResponseStatusException(err.statusCode(),
                                        "Error submitting to Lockbox Gateway:  "
                                                + transmission.getSubmission().getSubmissionId())))
                .bodyToMono(Map.class)
                .retryWhen(Retry.backoff(this.retryAttempts, Duration.ofSeconds(this.retryDurationSeconds))
                        .doBeforeRetry(f -> logger.error("Transaction is being replayed because of timeout: {}",
                                transmission.getSubmission().getSubmissionId())))
                .map(m -> String.valueOf(m.get(MANIFEST_ID)));
    }

    public Mono<String> mapManifestToSubmissionId(String manifestId ){
    	logger.info("Sending mapManifestToSubmissionId to lockbox-gateway manifest {}", manifestId);
        return lockboxWebClient
                .get()
                .uri("/api/v1/manifest/" + manifestId + "/confirmation")
                .retrieve()
                .onStatus(HttpStatusCode::isError,
                        err -> Mono.error(
                                new ResponseStatusException(err.statusCode(),
                                        "Error retrieving confirmation for manifest "  + manifestId)))
                .bodyToMono(Map.class)
                .retryWhen(Retry.backoff(retryAttempts, Duration.ofSeconds(3))
                        .doBeforeRetry(f -> logger.error("Retrying submission id mapping retrieval: {}",
                                manifestId)))
                .map(m -> String.valueOf(m.get(SUBMISSION_ID)));
    }
}