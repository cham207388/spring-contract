package gov.dhs.uscis.submissionservice.exception;

import gov.dhs.uscis.intake.constants.S3Constants;

public class S3PutObjectException extends RuntimeException {
    public S3PutObjectException(String errorMessage) {
        super(String.format("%s : %s", S3Constants.UPLOAD_FAILURE_MESSAGE, errorMessage));
    }  
}
