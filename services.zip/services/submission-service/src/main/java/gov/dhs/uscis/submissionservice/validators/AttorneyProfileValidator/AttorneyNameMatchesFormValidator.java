package gov.dhs.uscis.submissionservice.validators.AttorneyProfileValidator;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.validation.ClientNameEmailResponse;
import gov.dhs.uscis.intake.models.validation.name_extract.ClientName;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.RepresentativeProfileResponseData;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.PeepsService;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AttorneyNameMatchesFormValidator extends AttorneyProfileValidator {

    private static final String FAILURE_MESSAGE = "Logged in user does not match information on forms.";

    public AttorneyNameMatchesFormValidator(PeepsService peepsService, ValidationStatusRepository statusDAO) {
        super(peepsService, statusDAO, ValidatorEnum.G28_ATTORNEY_NAME, FAILURE_MESSAGE);
    }

    @Override
    protected boolean validationFails(ClientNameEmailResponse messageResponse,
            RepresentativeProfileResponseData profile) {
        if (null == messageResponse.getClientName()
                || null == profile.lastName()
                || null == profile.lastName()) {
            return true;
        }

        ClientName profileName = ClientName.builder()
                .familyName(profile.lastName())
                .givenName(profile.firstName())
                .build();
        log.error("Attorney name mismatch in peeps. Profile name {} {} extracted name {} {} for submissionID {} ",
                profileName.getGivenName(), profileName.getFamilyName(),
                messageResponse.getClientName().getGivenName(), messageResponse.getClientName().getFamilyName(),
                messageResponse.getSubmissionId());
        return !messageResponse.getClientName().equals(profileName);
    }

}