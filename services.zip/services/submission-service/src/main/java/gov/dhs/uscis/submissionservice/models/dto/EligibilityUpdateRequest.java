package gov.dhs.uscis.submissionservice.models.dto;

import org.springframework.lang.Nullable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EligibilityUpdateRequest {
    @NotNull
    private EligibilityCategoryEnum eligibilityCategory;
    private EligibilitySubcategoryEnum eligibilitySubcategory;
    private Integer benefitTypeCode;
    private Integer applicationReasonCode;
    private String formType;
}
