package gov.dhs.uscis.submissionservice.configs;

import static java.util.UUID.randomUUID;

import java.time.Clock;
import java.time.ZonedDateTime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import gov.dhs.uscis.intake.daos.AuditDAO;
import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.audit.Audit;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.intake.services.FileFormatValidator;
import gov.dhs.uscis.intake.services.SystemClockService;
import gov.dhs.uscis.submissionservice.repository.ClientInformationRepository;
import gov.dhs.uscis.submissionservice.services.S3KeyFileNameGenerator;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

@Configuration
public class CommonsConfig {

    @Bean
    public Clock clock() {
        return Clock.systemUTC();
    }

    @Bean
    public SystemClockService systemClockService(Clock clock){
        return () -> ZonedDateTime.now(clock);
    }

    @Bean
    public AuditDAO auditDAO (DynamoDbTable<Audit> auditTable) {
        return new AuditDAO(auditTable);
    }

    @Bean
    ClientInformationRepository clientInformationRepository(DynamoDbTable<ClientInformation> clientInformationTable) {
        return new ClientInformationRepository(clientInformationTable);
    }

    @Bean
    public AuditService auditService (AuditDAO auditDAO, Clock clock) {
        return new AuditService(auditDAO, clock);
    }

    @Bean
    public S3KeyFileNameGenerator s3KeyFileNameGenerator(){
        return (extension) -> {
            return String.format("%s%s", randomUUID().toString()
                .substring(0, 10).replace("-",""),
                extension);
        };
    }

    @Bean
    public FileFormatValidator fileFormatValidator(){
        return new FileFormatValidator();
    }
}