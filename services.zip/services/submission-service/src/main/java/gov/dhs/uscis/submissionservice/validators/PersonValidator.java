package gov.dhs.uscis.submissionservice.validators;

import static gov.dhs.uscis.intake.entities.submission.SubmissionState.DRAFT;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import gov.dhs.uscis.intake.models.ErrorType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import software.amazon.awssdk.services.eventbridge.model.InvalidStateException;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.ValidationStatus.ValidationStatusBuilder;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.FormService;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PersonValidator {

    private WebClient peepsWebClient;
    public static final String PROFILE_URL = "/api/user-profile/receipt-profile/latest";
    public static final String FORM_FIELD_DOB_FORMAT = "MM/dd/yyyy";

    private ValidationStatusRepository statusDAO;
    private SubmissionRepository submissionDAO;
    private FormService formService;

    private String dobFailureMessage;
    private String aNumberFailureMessage;

    private static final String DEFAULT_FAILURE_MESSAGE = "Unable to submit form. Applicant and user are not the same.";

    public PersonValidator(@Qualifier("peepsWebClient") WebClient peepsWebClient, ValidationStatusRepository statusDAO,
            FormService formService,
            SubmissionRepository submissionDAO) {
        this.peepsWebClient = peepsWebClient;
        this.statusDAO = statusDAO;
        this.formService = formService;
        this.submissionDAO = submissionDAO;
    }

    public void validate(String aNumber,
            String dateOfBirth,
            String formId,
            String submissionId,
            FormType formType) {
        setFormAttributes(formType);
        ValidationStatusBuilder statusBuilder = ValidationStatus.builder()
                .formId(formId)
                .submissionId(submissionId)
                .failureReasons(new ArrayList<>())
                .validator(ValidatorEnum.PERSON);

        log.info("Fetching profile from peeps with submission ID {}", submissionId);
        Submission draft = submissionDAO.getById(submissionId).get();
        if (draft == null || !draft.getStatus().equals(DRAFT)) {
            throw InvalidStateException.builder()
                .message(String.format("Submission %s is no longer in draft state {}", submissionId))
                .build();
        }

        try {
            var entity = peepsWebClient.get()
                    .uri(PROFILE_URL)
                    .header("ICAM-UUID", draft.getMyUscisId())
                    .retrieve()
                    .toEntity(ProfileResponse.class)
                    .block();

            if (entity.getStatusCode().is2xxSuccessful()) {
                var body = entity.getBody();
                var profile = body.getData();

                if (profile.getAlienNumber() == null) {
                    setPass(statusBuilder);
                } else if (aNumber == null) {
                    log.warn("Validation failed for submissionId {}: alien number is null on form",
                            draft.getSubmissionId());
                    setFail(statusBuilder,
                            aNumberFailureMessage);
                } else if (dateOfBirth == null) {
                    log.warn("Validation failed for submissionId {}: DOB is null on form",
                            draft.getSubmissionId());
                    setFail(statusBuilder,
                            dobFailureMessage);
                } else if (profile.getAlienNumber()
                        .equalsIgnoreCase(aNumber.replaceAll("[^\\d]+", ""))) {
                    String formFieldDOB = dateOfBirth;
                    String profileDOB = profile.getDateOfBirth();

                    log.debug("Parsing MM/dd/yyyy date from form field");
                    LocalDate formFieldDob = LocalDate.parse(formFieldDOB,
                            DateTimeFormatter.ofPattern(FORM_FIELD_DOB_FORMAT));
                    log.debug("Parsing ISO date from PEEPs profile");
                    LocalDate profileDob = LocalDate.parse(profileDOB, DateTimeFormatter.ISO_DATE);

                    if (Duration.between(profileDob.atStartOfDay(), formFieldDob.atStartOfDay()).toDays() < 2) {
                        setPass(statusBuilder);
                    } else {
                        log.warn(
                                "Validation failed for submissionId {}: profile start {} and form start {} are 2 or more days apart",
                                draft.getSubmissionId(), profileDob.atStartOfDay(), formFieldDob.atStartOfDay());
                        setFail(statusBuilder,
                                DEFAULT_FAILURE_MESSAGE);
                    }

                } else {
                    log.warn(
                            "Validation failed for submissionId {}: There was a discrepancy between the A-Number on your form and the one we have on file.",
                            draft.getSubmissionId());
                    setFail(statusBuilder,
                            "There was a discrepancy between the A-Number on your form and the one we have on file.");
                }
            }

        } catch (WebClientResponseException ex) {
            log.error("Error fetching receipt profile from peeps. {} with submission id {}", ex.getMessage(),
                    draft.getSubmissionId());
            if (ex.getStatusCode().isSameCodeAs(HttpStatusCode.valueOf(404)))
                setPass(statusBuilder);
            else
                setFail(statusBuilder, DEFAULT_FAILURE_MESSAGE);
        } catch (DateTimeParseException e) {
            log.error("Error parsing date: " + e.getMessage());
            setFail(statusBuilder,
                    "Date of birth was not correctly detected. Please make sure the date of birth is filled out clearly.");
        }

        ValidationStatus validationStatus = statusBuilder.build();
        statusDAO.save(validationStatus);
    }

    private void setFormAttributes(FormType formType) {
        FormMetaData formMetaData = formService.retrieveFormMetaData(formType.getType());

        this.aNumberFailureMessage = formMetaData.getErrorMap().stream()
                .filter(e -> e.getErrorType().equals(ErrorType.A_NUMBER_ERROR))
                .findFirst().get().getErrorMessage();
        this.dobFailureMessage = formMetaData.getErrorMap().stream()
                .filter(e -> e.getErrorType().equals(ErrorType.DOB_ERROR))
                .findFirst().get().getErrorMessage();

    }

    private ValidationStatusBuilder setFail(ValidationStatusBuilder statusBuilder, String failureMessage) {
        return statusBuilder.status(ValidationResultEnum.FAIL)
                .failureReasons(List.of(failureMessage));
    }

    private ValidationStatusBuilder setPass(ValidationStatusBuilder statusBuilder) {
        return statusBuilder.status(ValidationResultEnum.PASS).failureReasons(new ArrayList<>());
    }
}
