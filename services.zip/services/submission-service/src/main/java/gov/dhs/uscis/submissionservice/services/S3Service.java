package gov.dhs.uscis.submissionservice.services;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import software.amazon.awssdk.services.cloudwatch.model.InvalidFormatException;
import software.amazon.awssdk.services.s3.model.S3Exception;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.constants.DocumentType;
import gov.dhs.uscis.intake.constants.MetadataConstants;
import gov.dhs.uscis.intake.constants.S3Constants;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.enums.PFVSEvidenceType;
import gov.dhs.uscis.intake.enums.ToggleEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.intake.services.FileFormatValidator;
import gov.dhs.uscis.intake.services.formats.MagicBytes;
import gov.dhs.uscis.submissionservice.exception.FormProtectedException;
import gov.dhs.uscis.submissionservice.exception.S3DeleteObjectException;
import gov.dhs.uscis.submissionservice.exception.S3PutObjectException;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.UploadFeeWaiverRequest;
import gov.dhs.uscis.submissionservice.models.UploadRequest;
import gov.dhs.uscis.submissionservice.models.dto.S3FileInfo;
import jakarta.servlet.http.Part;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.core.exception.SdkException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.CopyObjectRequest;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.DeleteObjectResponse;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

@Slf4j
@Service
public class S3Service {
    private final String formBucket;
    private final String evidenceBucket;
    private final String backupBucket;
    private final S3Client s3Client;
    private final AuditService auditService;
    private S3KeyFileNameGenerator fileNameGenerator;
    private FileFormatValidator fileFormatValidator;
    private ObjectMapper objectMapper;
    private ToggleService toggleService;

    public S3Service(S3Client s3Client,
            AuditService auditService,
            S3KeyFileNameGenerator fileNameGenerator,
            FileFormatValidator fileFormatValidator,
            ObjectMapper objectMapper,
            ToggleService toggleService,
            @Value("${uscis.s3.buckets.form}") String formBucket,
            @Value("${uscis.s3.buckets.evidence}") String evidenceBucket,
            @Value("${uscis.s3.buckets.backup}") String backupBucket) {
        this.s3Client = s3Client;
        this.auditService = auditService;
        this.fileNameGenerator = fileNameGenerator;
        this.fileFormatValidator = fileFormatValidator;
        this.objectMapper = objectMapper;
        this.formBucket = formBucket;
        this.evidenceBucket = evidenceBucket;
        this.backupBucket = backupBucket;
        this.toggleService = toggleService;
    }

    public void validateFormCanLoad(MultipartFile file) throws IOException {
        byte[] buffer = file.getBytes();

        if (formIsPasswordProtected(buffer)) {
            throw new FormProtectedException("PDF form is Password Protected");
        }

        var derivedFormat = fileFormatValidator.isSupportedFile(buffer);
        if (derivedFormat != MagicBytes.PDF) {
            var ex = InvalidFormatException.builder().message("Not a valid PDF").build();
            throw ex;
        }
    }

    public S3FileInfo uploadForm(Submission submission, String id, MultipartFile file, UploadRequest request)
            throws IOException {
        String submissionId = submission.getSubmissionId();
        String myUscisId = submission.getMyUscisId();
        String userFlow = submission.getApplicant().getAccountType().getType();

        log.info("In S3 service uploadForm method for submissionId: {} and formtype: {}", submissionId,
                request.formType());

        validateFormCanLoad(file);
        
        try {
            S3FileInfo s3FileInfo = uploadFileToS3(id, submissionId, myUscisId, userFlow, request.fileName(), file.getBytes(),
                    request.formType(), formBucket);
                    auditService.addEvent(myUscisId, submissionId, ActionPerformed.FORM_UPLOADED, id);
                    auditService.addEvent(myUscisId, submissionId, ActionPerformed.MD5HASH_CREATED, s3FileInfo.checksum());
            return s3FileInfo;
        } catch (SdkException e) {
            log.error("Error uploading into bucket with myUscisId {} and submission{}: {} with submission id {} and myUscisId " + myUscisId, submissionId, e.toString());
            throw new S3PutObjectException(e.getMessage());
        }
    }

    private S3FileInfo uploadFileToS3(String id, String submissionId, String myUscisId, String userFlow,
            String fileName, byte[] bytes,
            String formType, String bucket) throws IOException {
        return uploadFileToS3(id, submissionId, myUscisId, userFlow, fileName, bytes, formType, bucket,
                new HashMap<String, String>());
    }

    private S3FileInfo uploadFileToS3(String formId, String submissionId, String myUscisId, String userFlow,
            String fileName, byte[] bytes,
            String formType, String bucket, Map<String, String> additionalMetaData)
            throws IOException {
        log.info("In S3 PutObject for form upload for submissionId: {} and formType: {}", submissionId,
                formType);

        var magicBytes = fileFormatValidator.isSupportedFile(bytes);
        if (magicBytes == MagicBytes.UNSUPPORTED)
            throw InvalidFormatException.builder().message("File format is not supported").build();

        String keyName = fileNameGenerator.generateName(magicBytes.getExtension());
        String s3Key = String.format("%s/%s/%s", submissionId, myUscisId, keyName);
        Map<String, String> metaData = createManifestMetaData(formId, fileName, submissionId, myUscisId, formType,
                userFlow);
        metaData.putAll(additionalMetaData);
        log.info("KEY FILENAME: {} ORIGINAL NAME: {}", keyName, fileName);
        var checksum = generateChecksum(bytes);

        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(bucket)
                .key(s3Key)
                .metadata(metaData)
                .build();

        s3Client.putObject(putObjectRequest, RequestBody.fromBytes(bytes));

        log.info("Successfully uploaded filename: {} for Bucket: {} for submissionId: {}", fileName, bucket,
                submissionId);
        log.info("returning S3FileInfo values: {}, {}, {}", formId, checksum, s3Key);

        return new S3FileInfo(formId, checksum, keyName, s3Key);
    }

    public byte[] getFileData(String s3Key, Boolean isForm) {
        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .bucket(isForm ? formBucket : evidenceBucket)
                .key(s3Key)
                .build();
        ResponseBytes<GetObjectResponse> objectBytes = s3Client.getObjectAsBytes(getObjectRequest);

        byte[] data = objectBytes.asByteArray();
        return data;
    }

    public S3FileInfo uploadEvidence(String myUscisId, String submissionId, Part file, UploadEvidenceRequest request,
            Submission submission, String selectedFormType)
            throws S3PutObjectException, IOException {
        String userFlow = submission.getApplicant().getAccountType().getType();
        log.info("In S3 service uploadEvidence method for submissionId: {}", submissionId);
        String id = UUID.randomUUID().toString();
        byte[] bytes = FileCopyUtils.copyToByteArray(file.getInputStream());

        try {
            log.info("In S3 PutObject for evidence upload for submissionId: {}", submissionId);
            Map<String, String> additionalMetaData = new HashMap<>();

            PFVSEvidenceType evidenceType = PFVSEvidenceType.findByFormType(request.type());
            boolean isSentToPFVS = (evidenceType != null)
                    ? toggleService.isToggleActive(evidenceType.getToggle(), submission.getFormType().getType())
                    : false;
            log.info("Evidence with id({}) being uploaded with sent to pfvs set to: {}", id, isSentToPFVS);

            additionalMetaData.put(MetadataConstants.ELIGIBILITYCATEGORY,
                    submission.getEligibilityCategory().toString());
            additionalMetaData.put(MetadataConstants.EVIDENCETYPE, request.type());
            additionalMetaData.put(MetadataConstants.SENT_TO_PFVS, String.valueOf(isSentToPFVS));
        
            var s3FileInfo = uploadFileToS3(id, submissionId, myUscisId, userFlow, request.fileName(), bytes,
                    selectedFormType, evidenceBucket, additionalMetaData);

            Map<String, String> auditMetadata = new HashMap<>();
            auditMetadata.put("fileId", id);
            auditMetadata.put("type", request.type());
            auditService.addEvent(myUscisId, submissionId,
                    ActionPerformed.EVIDENCE_UPLOADED, objectMapper.writeValueAsString(auditMetadata));
                    auditService.addEvent(myUscisId, submissionId, ActionPerformed.MD5HASH_CREATED, s3FileInfo.checksum());

            return s3FileInfo;
        } catch (SdkException e) {
            log.error("Error uploading into bucket:" + e.toString());
            throw new S3PutObjectException(e.getMessage());
        }
    }

    public S3FileInfo uploadFeeWaiver(String myUscisId, String submissionId, MultipartFile file,
            UploadFeeWaiverRequest request, Submission submission)
            throws S3PutObjectException, IOException {
        log.info("In S3 service uploadFeeWaiver method for submissionId: {}", submissionId);
        String id = UUID.randomUUID().toString();
        String userFlow = submission.getApplicant().getAccountType().getType();
        try {
            log.info("In S3 PutObject for feewaiver upload for submissionId: {}", submissionId);
            
            boolean isSentToPFVS = toggleService.isToggleActive(ToggleEnum.PFVS_I912, submission.getFormType().getType());
            log.info("Fee Waiver being uploaded with sent to pfvs set to: {}", isSentToPFVS);
            
            Map<String, String> additionalMetaData = new HashMap<>();

            additionalMetaData.put(MetadataConstants.ELIGIBILITYCATEGORY,
                    submission.getEligibilityCategory().toString());
            additionalMetaData.put(MetadataConstants.EVIDENCETYPE, DocumentType.FeeWaiver.FORM_I912);
            additionalMetaData.put(MetadataConstants.SENT_TO_PFVS, String.valueOf(isSentToPFVS));
            var s3FileInfo = uploadFileToS3(id, submissionId, myUscisId, userFlow, request.fileName(), file.getBytes(),
                    submission.getFormType().getType(), evidenceBucket, additionalMetaData);

            auditService.addEvent(myUscisId, submissionId,
                    ActionPerformed.FEE_WAIVER_UPLOADED, id);
                    auditService.addEvent(myUscisId, submissionId, ActionPerformed.MD5HASH_CREATED, s3FileInfo.checksum());

            return s3FileInfo;
        } catch (SdkException e) {
            log.error("Error uploading into bucket:" + e.toString());
            throw new S3PutObjectException(e.getMessage());
        }
    }

    private Map<String, String> createManifestMetaData(String id, String filename, String submissionId,
            String myUscisId,
            String formType, String userFlow) {
        Map<String, String> metaData = new HashMap<>();
        metaData.put(MetadataConstants.FILENAME, filename);
        metaData.put(MetadataConstants.ID, id);
        metaData.put(MetadataConstants.SUBMISSIONID, submissionId);
        metaData.put(MetadataConstants.MYUSCISID, myUscisId);
        metaData.put(MetadataConstants.FORMTYPE, formType);
        if (userFlow != null)
            metaData.put(MetadataConstants.USERFLOW, userFlow);
        return metaData;
    }

    public String deleteS3Object(String objectKey, boolean isEvidence) throws S3DeleteObjectException {

        String bucketName = isEvidence ? evidenceBucket : formBucket;
        
        try {
        	if(!isEvidence) {
        		backUpS3Object(bucketName, objectKey);
        	}
            DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                    .bucket(bucketName)
                    .key(objectKey)
                    .build();
            DeleteObjectResponse res = s3Client.deleteObject(deleteObjectRequest);
            if (res != null && res.sdkHttpResponse() != null)
                log.info("Resulting Status Code of S3 Delete Object action: {}", res.sdkHttpResponse().statusCode());

            return S3Constants.DELETION_SUCCESS_MESSAGE;
        } catch (SdkClientException | AwsServiceException e) {
            throw new S3DeleteObjectException(e.getMessage());
        }
    }

    private void backUpS3Object(String sourceBucket, String sourceKey){
        try
        {
        	CopyObjectRequest request = CopyObjectRequest.builder()
        			.sourceBucket(sourceBucket)
        			.sourceKey(sourceKey)
        			.destinationBucket(backupBucket)
        			.destinationKey(sourceKey).build();
            s3Client.copyObject(request);
            log.info("Successfully uploaded backup for filename: {} for Bucket: {}", sourceKey, backupBucket);
        }
        catch (S3Exception ex) {
        	log.error("Error backing up file " + sourceKey + " to backup bucket " + backupBucket, ex);
            //throw ex;
        }
    }
    

    public boolean checkIfFileExists(String key, boolean isForm) {
        try {
            s3Client.headObject(
                    HeadObjectRequest.builder().bucket(isForm ? formBucket : evidenceBucket).key(key).build());
            return true;
        } catch (NoSuchKeyException e) {
            return false;
        }
    }

    private String generateChecksum(byte[] bytes) throws IOException {
        return DigestUtils.md5Hex(bytes);
    }

    private boolean formIsPasswordProtected(byte[] buffer) throws IOException {
        boolean encrypted = true;
        PDDocument doc = null;
        try {
            doc = Loader.loadPDF(buffer);
            doc.getPages();
            encrypted = false;
        } catch (InvalidPasswordException invalidPasswordException) {
            encrypted = true;
            log.error("Unable to read password protected PDF.", invalidPasswordException);
        } catch (IOException io) {
            encrypted = true;
            log.error("An error occurred while reading a PDF attachment during account submission.", io);
        } finally {
            if (!Objects.isNull(doc)) {
                try {
                    doc.close();
                    encrypted = false;
                } catch (IOException io) {
                    log.error("An error occurred while closing a PDF attachment ", io);
                }
            }
        }
        return encrypted;

    }
}