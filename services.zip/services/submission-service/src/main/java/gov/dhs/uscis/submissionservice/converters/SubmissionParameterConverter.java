package gov.dhs.uscis.submissionservice.converters;

import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.validation.Validation;
import gov.dhs.uscis.intake.models.validation.ValidationDetails;
import gov.dhs.uscis.intake.models.validation.ValidationStatusResponse;
import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.ValidationService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SubmissionParameterConverter implements Converter<String, FinalSubmissionDto> {
  private final ValidationService validationService;
  private final SubmissionService submissionService;

    public SubmissionParameterConverter(SubmissionService submissionService, ValidationService validationService) {
        this.submissionService = submissionService;
        this.validationService = validationService;
    }
  
  @Override
  public FinalSubmissionDto convert(String submissionId) {
    log.info("Beginning submission conversion for submission id {}", submissionId );
    Submission submission = submissionService.retrieveSubmission(submissionId);
    ValidationStatusResponse validationStatusResponse = validationService.retrieveValidationStatus(submission);
    Validation formValidation = validationStatusResponse.formValidations().stream().filter(
        validation -> submission.getFormType().equals(validation.groupType())
    ).findFirst().orElse(null);

    List<ValidationDetails> formValidationDetails = formValidation != null ? formValidation.details() : List.of();

    Boolean userRequestedPartialFeeWaiver = submission.getUserRequestedPartialFeeWaiver();
    FinalSubmissionDto finalSubmission = FinalSubmissionDto.builder().submissionId(submissionId)
        .type(submission.getFormType())
        .category(submission.getEligibilityCategory())
        .attested(submission.getAttested())
        .hasReviewedSignature(submission.getHasReviewedSignature())
        .signature(submission.getAttestationSignature())
        .feeWaiver(submission.getFeeWaiver())
        .status(submission.getStatus())
        .userRequestedFeeWaiver(submission.getUserRequestedFeeWaiver())
        .userRequestedPartialFeeWaiver(userRequestedPartialFeeWaiver == null ? false : userRequestedPartialFeeWaiver)
        .evidences(submission.getEvidences())
        .forms(submission.getForms())
        .validations(formValidationDetails).build();
    log.info("Completed submission validation for submission id {}", submissionId );
    return finalSubmission;
  }
}
