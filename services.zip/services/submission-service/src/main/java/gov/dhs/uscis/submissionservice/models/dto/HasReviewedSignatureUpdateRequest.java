package gov.dhs.uscis.submissionservice.models.dto;

import lombok.Data;
import jakarta.validation.constraints.NotNull;

@Data
public class HasReviewedSignatureUpdateRequest {
    @NotNull
    private Boolean hasReviewedSignature;
}
