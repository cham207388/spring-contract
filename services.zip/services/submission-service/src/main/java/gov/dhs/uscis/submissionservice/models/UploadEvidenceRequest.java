package gov.dhs.uscis.submissionservice.models;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;

@Builder
public record UploadEvidenceRequest(@NotNull String fileName, @NotNull String type, @NotNull String evidenceGroupType) {
}