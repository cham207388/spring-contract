package gov.dhs.uscis.submissionservice.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.dhs.uscis.intake.enums.MetadataValidationEnum;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.validation.ValidationStatusEnum;

public class FormValidationStatusUtil {

	private static final Logger logger = LoggerFactory.getLogger(FormValidationStatusUtil.class);
	
    private static record MatchFormValidationResult(boolean validationNotFound, boolean validationFailed, boolean validationPending) {
    };

    private static MatchFormValidationResult matchFormToValidation(String metadataValidation,
            Map<String, ValidationStatus> validationsLookup, boolean isSubmissionByRepresentative) {
        Boolean validationNotFound = false;
        Boolean validationFailed = false;
        Boolean validationPending = false;

        if (!(validationsLookup.containsKey(metadataValidation))) {
            validationNotFound = true;
        } else {
            ValidationStatus validationStatus = validationsLookup.get(metadataValidation.toString());
            if (ValidationResultEnum.FAIL.equals(validationStatus.getStatus())) {
                if ((!ValidatorEnum.SIGNATURE.toString().equals(validationStatus.getValidator().toString()))
                        || isSubmissionByRepresentative) {
                    validationFailed = true;
                }

            } else if (ValidationResultEnum.PENDING.equals(validationStatus.getStatus())) validationPending = true;
        }
        return new MatchFormValidationResult(validationNotFound, validationFailed, validationPending);
    }

    private static Map<String, ValidationStatus> buildValidationStatusLookupMap(
            List<ValidationStatus> formValidations) {
        Map<String, ValidationStatus> validationsLookup = new HashMap<String, ValidationStatus>();

        for (ValidationStatus validationStatus : formValidations) {
            if (validationStatus.getValidator() != null) {
                validationsLookup.put(validationStatus.getValidator().toString(), validationStatus);
            }
        }
        return validationsLookup;
    }

    protected static List<String> getValidationStatusLookupKeys(FormMetaData formMetaData,
            Boolean isSubmissionByRepresentative) {
        if (formMetaData.getValidations() == null) {
            return List.of();
        }
        return formMetaData.getValidations().stream()
                .filter(metaDataValidationEnum -> isSubmissionByRepresentative
                        || !List.of(MetadataValidationEnum.G28_COMP, MetadataValidationEnum.G28_COMP_NAME).contains(metaDataValidationEnum))
                .flatMap(
                        metaDataValidationEnum -> {
                            if (metaDataValidationEnum == MetadataValidationEnum.FORM_FIELDS) {
                                return Stream.of(ValidatorEnum.PERSON.toString(),
                                        ValidatorEnum.ELIGIBILITY_CATEGORY.toString());
                            }
                            return Stream.of(metaDataValidationEnum.toString());
                        })
                .collect(Collectors.toList());
    }

    public static ValidationStatusEnum determineFormStatus(List<ValidationStatus> formValidations,
            FormMetaData formMetaData, Boolean isSubmissionByRepresentative) {
        Map<String, ValidationStatus> validationsLookup = buildValidationStatusLookupMap(formValidations);
        List<String> validationStatusLookupKeys = getValidationStatusLookupKeys(formMetaData,
                isSubmissionByRepresentative);
        Boolean validationNotFound = false;
        Boolean validationWaiting = false;

        for (String validationStatusLookupKey : validationStatusLookupKeys) {
            MatchFormValidationResult matchResult = matchFormToValidation(validationStatusLookupKey, validationsLookup,
                    isSubmissionByRepresentative);
            if (ValidatorEnum.CORE.toString().equals(validationStatusLookupKey) && matchResult.validationFailed) {
                return ValidationStatusEnum.COMPLETE;
            }
            validationNotFound = validationNotFound || matchResult.validationNotFound;
            validationWaiting = validationWaiting || matchResult.validationPending;

            if(validationNotFound || validationWaiting){
            	logger.info("Looking for validation status of {} against statuses: {}, none found: {}, still pending: {}", validationStatusLookupKey, validationsLookup.keySet(), validationNotFound, validationWaiting);
            }
        }

        if (validationNotFound) {
            return ValidationStatusEnum.IN_PROGRESS;
        }
        if (validationWaiting) return ValidationStatusEnum.AWAITING;

        return ValidationStatusEnum.COMPLETE;

    }

}
