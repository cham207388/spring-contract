package gov.dhs.uscis.submissionservice.validators;

public interface N400FieldValidator extends FieldValidator {
}
