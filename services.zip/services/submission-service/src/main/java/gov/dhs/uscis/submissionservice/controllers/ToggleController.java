package gov.dhs.uscis.submissionservice.controllers;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.submissionservice.services.ToggleService;

@Slf4j
@Tag(name = "Toggles", description = "Our Toggles in our postgres database")
@RestController
@RequestMapping("/api/v1/toggle")
public class ToggleController {

    private final ToggleService toggleService;

    public ToggleController(ToggleService toggleService) {
        this.toggleService = toggleService;
    }

    @GetMapping("/get-toggle/formType/{formType}/{toggleName}") 
        public ResponseEntity<Boolean> getToggleName(@PathVariable String toggleName, @PathVariable String formType) {
            return ResponseEntity.ok().body(toggleService.isToggleActive(toggleName, formType));   
    }

}
