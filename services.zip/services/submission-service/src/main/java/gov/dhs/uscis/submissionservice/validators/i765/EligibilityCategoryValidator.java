package gov.dhs.uscis.submissionservice.validators.i765;

import java.util.List;

import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.validation.FormFieldResult;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.validators.FieldValidator;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;

@Component
@Slf4j
public class EligibilityCategoryValidator implements FieldValidator {

    DynamoDbTable<ValidationStatus> validationStatusTable;
    FormService formService;

    public final static String NO_CATEGORY_DETECTED_MESSAGE = "There was no Eligibility Category detected on the form. Please review your selection to prevent your application from being rejected.";
    public final static String MESSAGE = "Eligibility Category selected (%s) is different from what is on the form (%s). Please review your selection to prevent your application from being rejected.";
    public final static String ELIGIBILITY_CATEGORY_MISMATCH = "The eligibility category you selected does not match the eligibility category on the form.";
    public final static String ELIGIBILITY_CATEGORY_NOT_SELECTED = "Please specify your eligibility category under Getting Started.";
    

    public EligibilityCategoryValidator(DynamoDbTable<ValidationStatus> validationStatusTable, FormService formService) {
        this.validationStatusTable = validationStatusTable;
        this.formService = formService;
    }

    @Override
    public void validate(Submission submission, FormFields formFields) {
        
        var vBuilder = ValidationStatus.builder().submissionId(submission.getSubmissionId())
                .formId(formFields.formId()).validator(ValidatorEnum.ELIGIBILITY_CATEGORY)
                .failureReasons(Lists.newArrayList()).validationWarnings(Maps.newHashMap());
        I765EligibilityCategory categoryEnum = (I765EligibilityCategory) submission.getEligibilityCategory();
        if (categoryEnum == null)
            vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(ELIGIBILITY_CATEGORY_NOT_SELECTED));

            
        else {
            if (formFields.eligibilityCategory().isBlank() || formFields.eligibilityCategory() == null)
                vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(NO_CATEGORY_DETECTED_MESSAGE));
            else {
                if(categoryEnum.isValid(formFields.eligibilityCategory())){
                    vBuilder.status(ValidationResultEnum.PASS).build(); 
                } else {
                    vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(ELIGIBILITY_CATEGORY_MISMATCH));
                }
            }
        }
        validationStatusTable.putItem(PutItemEnhancedRequest.builder(ValidationStatus.class)
                .item(vBuilder.build())
                .build());

    }

    @Override
    public void validate(Submission submission, FormFieldResult eligibility) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unsupported method 'validate'");
    }

    

}
