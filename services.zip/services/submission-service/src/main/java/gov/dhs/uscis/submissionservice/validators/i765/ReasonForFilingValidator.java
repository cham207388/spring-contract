package gov.dhs.uscis.submissionservice.validators.i765;

import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.validation.FormFieldResult;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.services.FormService;
import gov.dhs.uscis.submissionservice.validators.FieldValidator;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;

@Component
@Slf4j
public class ReasonForFilingValidator implements FieldValidator {

    DynamoDbTable<ValidationStatus> validationStatusTable;
    FormService formService;

    public static final String REASON_FOR_FILING_NOT_DETECTED = "The Reason for Applying was not detected on the form. Please review your selection to prevent your application from being rejected.";
    public static final String REASON_FOR_FILING_MISMATCH = "The Reason for Filing you selected does not match the Reason for Applying on the form.";
    public static final String REASON_FOR_FILING_UNDEFINED = "The Reason for Applying on the form is not currently supported.";

    public ReasonForFilingValidator(DynamoDbTable<ValidationStatus> validationStatusTable, FormService formService) {
        this.validationStatusTable = validationStatusTable;
        this.formService = formService;
    }

    @Override
    public void validate(Submission submission, FormFields formFields) {
        String category = formFields.eligibilityCategory() != null ? formFields.eligibilityCategory().replaceAll("[\\s0]+", "") : null;
        if (submission.getFormType() == FormType.I765 && category != null && !I765EligibilityCategory.C9.getCategory().equalsIgnoreCase(StringUtils.deleteWhitespace(category)) ) {

            var vBuilder = ValidationStatus.builder().submissionId(submission.getSubmissionId())
                    .formId(formFields.formId()).validator(ValidatorEnum.REASON_FOR_FILING)
                    .failureReasons(Lists.newArrayList()).validationWarnings(Maps.newHashMap());

            try {
                String submissionReason = submission.getReasonForFiling();
                String formReason = ReasonForFiling.fromFormEntry(formFields.reasonForApplySelection()).toString();

                if (StringUtils.isEmpty(submissionReason)) {
                    vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(REASON_FOR_FILING_NOT_DETECTED));
                } else if (!Objects.equals(submissionReason, formReason)) {
                    vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(REASON_FOR_FILING_MISMATCH));
                } else {
                    vBuilder.status(ValidationResultEnum.PASS).build();
                }
            } catch (UnsupportedOperationException e) {
                vBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(REASON_FOR_FILING_UNDEFINED));
            }

            validationStatusTable.putItem(PutItemEnhancedRequest.builder(ValidationStatus.class)
                    .item(vBuilder.build())
                    .build());
        }
    }


    @Override
    public void validate(Submission submission, FormFieldResult eligibility) {
        // Reason for filing is not supported in FormFieldResult
        throw new UnsupportedOperationException("Unsupported method 'validate'");
    }
}