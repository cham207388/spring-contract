package gov.dhs.uscis.submissionservice.models.validation;

import lombok.Builder;

@Builder
public record FormFields(String formId, String submissionId, String validator, String eligibilityCategory, String alienNumber, String dateOfBirth,
        String reasonForApplySelection, Boolean abcBenefitsApplied) {

}
