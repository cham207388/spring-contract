package gov.dhs.uscis.submissionservice.services;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.models.ValidationRequest;
import gov.dhs.uscis.intake.models.EsignRequest;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;
import software.amazon.awssdk.services.sqs.model.SqsException;

@Slf4j
@Service
public class SqsService {
  @Value("${uscis.sqs.validation.elisRequest.queueUrl}")
  private String validationRequestQueueUrl;
  @Value("${uscis.sqs.evidence.validation.elisRequest.queueUrl}")
  private String evidenceValidationRequestQueueUrl;
  @Value("${uscis.sqs.esign.elisRequest.queueUrl}")
  private String esignRequestQueueUrl;

  private final SqsClient sqsClient;
  private final ObjectMapper mapper;

  public SqsService(SqsClient sqsClient, ObjectMapper mapper) {
    this.sqsClient = sqsClient;
    this.mapper = mapper;
  }

  private void sendMessage(String message, String sqsQueueUrl) {
    try {
      SendMessageRequest sendMsgRequest = SendMessageRequest.builder()
          .queueUrl(sqsQueueUrl)
          .messageBody(message)
          .build();

      log.info("Sending message to queue: {}\n{}", sqsQueueUrl, message);
      SendMessageResponse response = sqsClient.sendMessage(sendMsgRequest);
      log.info(response.toString());

    } catch (SqsException e) {
      log.error("Sending SQS message: {} to queue: {} failed due to {}", message, sqsQueueUrl, e.awsErrorDetails().errorMessage());
    } 
  } 

  public void sendValidationRequest(ValidationRequest request) {
    String message;
    try {
      message = mapper.writeValueAsString(request);
      sendMessage(message, validationRequestQueueUrl);
    } catch (JsonProcessingException e) {
      log.error("Failed to convert validation request: {} to message due to {}", request.toString(), e);
    } 
  }
  
  public void sendEvidenceValidationRequest(ValidationRequest request) {
	    String message;
	    try {
	      message = mapper.writeValueAsString(request);
	      sendMessage(message, evidenceValidationRequestQueueUrl);
	    } catch (JsonProcessingException e) {
	      log.error("Failed to convert validation request: {} to message due to {}", request.toString(), e);
	    } 
	  }

  public void sendEsignRequest(EsignRequest request) {
    String message;
    try {
      message = mapper.writeValueAsString(request);
      log.info("Sending esign request {} to PFVS on {}", message, esignRequestQueueUrl);
      sendMessage(message, esignRequestQueueUrl);
    } catch (JsonProcessingException e) {
      log.error("Failed to convert esign request: {} to message due to {}", request.toString(), e);
    } 
  }
}
