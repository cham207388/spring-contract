package gov.dhs.uscis.submissionservice.validators;

import static gov.dhs.uscis.intake.enums.ValidatorEnum.CORE;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.ELIGIBILITY_CATEGORY;
import static gov.dhs.uscis.intake.enums.ValidatorEnum.SIGNATURE;
import static gov.dhs.uscis.intake.enums.ValidationResultEnum.FAIL;

import gov.dhs.uscis.submissionservice.models.dto.FinalSubmissionDto;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class FormValidator implements ConstraintValidator<ValidForm, FinalSubmissionDto> {

    @Override
    public boolean isValid(FinalSubmissionDto value, ConstraintValidatorContext context) {
        if(hasCoreValidationFailure(value)) return false;

        if(hasEligibilityCategoryValidationFailure(value)) return false;

        if(hasSignatureValidationFailure(value) && doesNotHaveValidAttestion(value)) return false;

        return true;
    }

    private boolean hasCoreValidationFailure(FinalSubmissionDto value) {
        return value.getValidations().stream()
            .anyMatch(validator -> validator.validator().equals(CORE) && validator.result().equals(FAIL));
    }

    private boolean hasEligibilityCategoryValidationFailure(FinalSubmissionDto value) {
        return value.getValidations().stream()
            .anyMatch(validator -> validator.validator().equals(ELIGIBILITY_CATEGORY) && validator.result().equals(FAIL));
    }


    private boolean hasSignatureValidationFailure(FinalSubmissionDto value) {
        return value.getValidations().stream()
            .anyMatch(validator -> validator.validator().equals(SIGNATURE) && validator.result().equals(FAIL));
    }

    private boolean doesNotHaveValidAttestion(FinalSubmissionDto value) {
        return !(value.getAttested() != null && 
                value.getAttested().equals(Boolean.TRUE) && 
                value.getSignature() != null && 
                !value.getSignature().isEmpty());
    }
}
