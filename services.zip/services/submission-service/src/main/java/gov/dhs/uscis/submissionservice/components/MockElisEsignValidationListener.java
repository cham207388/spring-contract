package gov.dhs.uscis.submissionservice.components;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ELISValidationResponse;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

@Component
@Profile("mock_elis")
public class MockElisEsignValidationListener implements MessageListener {

    private final SqsClient sqsClient;

    @Value("${uscis.sqs.validation.elisResponse.queueUrl}")
    private String elisResponseQueueName;

    ObjectMapper mapper = new ObjectMapper();
    private static final Logger logger = LoggerFactory.getLogger(MockElisEsignValidationListener.class);

    @Autowired
	public MockElisEsignValidationListener(SqsClient sqsClient) {
		this.sqsClient = sqsClient;
	}

    @Override
    public void onMessage(Message message) {
        TextMessage textMessage = (TextMessage) message;
        try {
            ELISValidationResponse request = mapper.readValue(textMessage.getText(), ELISValidationResponse.class);

            logger.info("MOCK ELIS Esign, recieved Message: " + request.toString());

            ValidationStatus mockUpdatedStatus = ValidationStatus.builder()
                    .formId(request.formId())
                    .submissionId(request.submissionId())
                    .status(ValidationResultEnum.PASS)
                    .isMultipart(false)
                    .validator(ValidatorEnum.ESIGN)
                    .build();

            List<ValidationStatus> statusResponses = new ArrayList<>();
            statusResponses.addAll(Arrays.asList(mockUpdatedStatus));

            ELISValidationResponse elisValidationResponse = ELISValidationResponse.builder()
                    .results(statusResponses)
                    .formId(request.formId())
                    .formType(request.formType())
                    .pass(true)
                    .submissionId(request.submissionId())
                    .build();

            SendMessageRequest sendMsgRequest = SendMessageRequest.builder()
                    .queueUrl(elisResponseQueueName)
                    .messageBody(mapper.writeValueAsString(elisValidationResponse))
                    .build();

            logger.info("Sending mock validation response message to queue: {}\n{}", elisResponseQueueName, message);
            SendMessageResponse response = sqsClient.sendMessage(sendMsgRequest);
            logger.info(response.toString());
            textMessage.acknowledge();
        } catch (Exception e) {
            logger.error("Error with ELIS validaiton mock listener {}", e);
        }
    }

}