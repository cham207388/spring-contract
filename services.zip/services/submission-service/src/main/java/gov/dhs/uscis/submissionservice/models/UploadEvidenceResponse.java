package gov.dhs.uscis.submissionservice.models;

import java.time.ZonedDateTime;
import java.util.List;

import gov.dhs.uscis.submissionservice.models.elis.ElisPhotoValidationError;

public record UploadEvidenceResponse(String id, String name, String formId, ZonedDateTime uploadedAt, Boolean hasError, List<ElisPhotoValidationError> errors) {}