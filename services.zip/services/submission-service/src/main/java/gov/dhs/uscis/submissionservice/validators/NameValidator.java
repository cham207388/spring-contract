package gov.dhs.uscis.submissionservice.validators;

import java.util.Collections;
import java.util.Optional;
import java.util.List;
import org.springframework.stereotype.Component;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.validation.name_extract.ClientName;
import gov.dhs.uscis.intake.models.validation.name_extract.NameExtract;
import gov.dhs.uscis.intake.models.validation.name_extract.NameValidationResult;
import gov.dhs.uscis.submissionservice.repository.NameExtractRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import lombok.extern.slf4j.Slf4j;
import gov.dhs.uscis.intake.models.ValidationStatus.ValidationStatusBuilder;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import java.util.NoSuchElementException;


@Component
@Slf4j
public class NameValidator {
    private NameExtractRepository nameExtractDAO;
    private ValidationStatusRepository statusDAO;
    private SubmissionRepository submissionRepository;

    public static final String DEFAULT_FAILURE_MESSAGE = "Client's name on form does not match name on G-28. Please verify the client's name are the same on both forms.";
    public static final String MISSING_FAILURE_MESSAGE = "Client's full name was not detected on the form. Please verify the both the client's Given name and Family name are both filled in and re upload form";

    public NameValidator(NameExtractRepository nameExtractDAO, ValidationStatusRepository statusDAO, SubmissionRepository submissionRepository) {
        this.nameExtractDAO = nameExtractDAO;
        this.statusDAO = statusDAO;
        this.submissionRepository = submissionRepository;
    }

    public void validate(NameValidationResult result) {
        FormType formType = FormType.fromString(result.getFormType());
        String formId = result.getFormId();
        String submissionId = result.getSubmissionId();
        ClientName clientName = result.getClientName();

        nameExtractDAO.getBySubmissionId(submissionId).ifPresentOrElse(
                (existingNameExtract) -> updateExistingNameExtract(existingNameExtract, formId, formType, clientName),
                () -> createNewNameExtract(submissionId, formId, formType, clientName));
    }

    private NameExtract createNewNameExtract(String submissionId, String formId, FormType formType,
            ClientName clientName) {
        log.info("Creating NameExtract for submissionId {}, formType {}", submissionId, formType);
        NameExtract nameExtract = NameExtract.builder()
                .submissionId(submissionId)
                .form(formType)
                .build()
                .updateClientName(formType, clientName, formId);

        validateForEmptyClientName(clientName, submissionId, formId);

        log.info("Saving New NameExtract for submissionId {}, nameExtract: {}",
                submissionId, nameExtract
        );

        return nameExtractDAO.save(nameExtract);
    }

    private void updateExistingNameExtract(NameExtract existingNameExtract, String incomingFormId,
            FormType incomingFormType, ClientName incomingClientName) {
        log.info("Processing existing NameExtract for submissionId {}, formType {}, nameExtract {}",
                existingNameExtract.getSubmissionId(), incomingFormType, existingNameExtract);

        existingNameExtract.updateClientName(incomingFormType, incomingClientName, incomingFormId);

        deleteNonExistentFormData(existingNameExtract);

        boolean hasAllNamesForValidation = existingNameExtract.hasAllNamesForValidation();
        log.info("hasAllNamesForValidation: {}; formType: {}; submissionId: {}; nameExtract: {};",
        hasAllNamesForValidation,
        incomingFormType,
        existingNameExtract.getSubmissionId(),
        existingNameExtract
        );

        if (hasAllNamesForValidation) {
            performNameValidation(existingNameExtract);
        } else {
            validateForEmptyClientName(incomingClientName, existingNameExtract.getSubmissionId(), incomingFormId);
        }

        nameExtractDAO.update(existingNameExtract);

    }

    private void deleteNonExistentFormData(NameExtract nameExtract) {
        Submission submission = submissionRepository.getById(nameExtract.getSubmissionId())
                .orElseThrow(() -> new NoSuchElementException(
                        String.format("Submission Not Found: %s", nameExtract.getSubmissionId())));

        boolean hasNoForm = Optional.ofNullable(submission.getForms())
            .orElse(Collections.emptyList())
            .stream()
            .noneMatch(form -> form.getId().equals(nameExtract.getFormId()));

        if(hasNoForm) {
            nameExtract.setFormId(null);
            nameExtract.setClientNameOnForm(null);
        }

        boolean hasNoG28Form = Optional.ofNullable(submission.getForms())
            .orElse(Collections.emptyList())
            .stream()
            .noneMatch(form -> form.getId().equals(nameExtract.getG28FormId()));
        if(hasNoG28Form) {
            nameExtract.setG28FormId(null);
            nameExtract.setClientNameOnG28(null);
        }
    }

    private void performNameValidation(NameExtract existingNameExtract) {
        log.info("performNameValidation:: existingNameExtract: {};",
            existingNameExtract
        );
        ClientName g28Name = existingNameExtract.getClientNameOnG28();
        ClientName formName = existingNameExtract.getClientNameOnForm();

        ValidationStatusBuilder g28StatusBuilder = ValidationStatus.builder()
                .submissionId(existingNameExtract.getSubmissionId())
                .validator(ValidatorEnum.G28_COMP_NAME).formId(existingNameExtract.getG28FormId());
        ValidationStatusBuilder formStatusBuilder = ValidationStatus.builder()
                .submissionId(existingNameExtract.getSubmissionId())
                .validator(ValidatorEnum.G28_COMP_NAME).formId(existingNameExtract.getFormId());

        if (clientNamesMatchAndAreValid(formName, g28Name)) {
            log.info("Name validation passed for submissionId {}.", existingNameExtract.getSubmissionId());
            g28StatusBuilder
                    .status(ValidationResultEnum.PASS)
                    .failureReasons(Collections.emptyList());
            formStatusBuilder
                    .status(ValidationResultEnum.PASS)
                    .failureReasons(Collections.emptyList());
        } else {
            log.warn("Validation failed for submissionId {}: name on form does not match name on G-28",
                    existingNameExtract.getSubmissionId());
            g28StatusBuilder.status(ValidationResultEnum.FAIL).failureReasons(
                    List.of(g28Name.hasMissingNamePart() ? MISSING_FAILURE_MESSAGE : DEFAULT_FAILURE_MESSAGE));
            formStatusBuilder.status(ValidationResultEnum.FAIL).failureReasons(
                    List.of(formName.hasMissingNamePart() ? MISSING_FAILURE_MESSAGE : DEFAULT_FAILURE_MESSAGE));

        }

        ValidationStatus formStatus = formStatusBuilder.build();
        ValidationStatus g28FormStatus = g28StatusBuilder.build();

        log.info("performNameValidation (DAO SAVE):: submissionId: {}; formStatus: {}; g28FormStatus: {}",
            existingNameExtract.getSubmissionId(),
            formStatus,
            g28FormStatus
        );

        statusDAO.save(formStatus);
        statusDAO.save(g28FormStatus);

    }

        private boolean clientNamesMatchAndAreValid(ClientName clientNameForm, ClientName clientNameG28) {
        if(clientNameForm == null || clientNameG28 == null) {
            return false;
        }

        if(clientNameForm.hasMissingNamePart() || clientNameG28.hasMissingNamePart()) {
            return false;
        }

        return clientNameForm.equals(clientNameG28);
    }

    private void validateForEmptyClientName(ClientName clientName, String submissionId, String formId) {
        ValidationStatusBuilder statusBuilder = ValidationStatus.builder()
                .submissionId(submissionId)
                .formId(formId)
                .validator(ValidatorEnum.G28_COMP_NAME)
                .status(ValidationResultEnum.PENDING)
                .failureReasons(Collections.emptyList());

        if (clientName.getFamilyName() == null || clientName.getGivenName() == null)
            statusBuilder.status(ValidationResultEnum.FAIL).failureReasons(List.of(MISSING_FAILURE_MESSAGE));
        statusDAO.save(statusBuilder.build());
    }

}