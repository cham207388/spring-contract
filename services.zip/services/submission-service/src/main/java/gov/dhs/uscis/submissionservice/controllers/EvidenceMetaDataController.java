package gov.dhs.uscis.submissionservice.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.models.core.metadata.EvidencePages;
import gov.dhs.uscis.intake.models.dto.EvidenceData;
import gov.dhs.uscis.submissionservice.services.EvidenceMetaDataService;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Evidence MetaData", description = "Global configurations for platform")
@RestController
@RequestMapping("/api/v1/metadata")
public class EvidenceMetaDataController {

    private final EvidenceMetaDataService service;

    public EvidenceMetaDataController(EvidenceMetaDataService service) {
        this.service = service;
    }

    @GetMapping("/evidence/{evidenceId}")
    public ResponseEntity<EvidencePages> retrieveFormMetaData(@PathVariable("evidenceId")String evidenceMetadataId) {
        EvidenceData metaData = service.getEvidenceMetaData(evidenceMetadataId);
        if(metaData == null || metaData.evidencePages() == null )
        {
            return ResponseEntity.notFound().build();
        }

        EvidencePages evidencePage = metaData.evidencePages().get("pageContents");
        if(evidencePage == null)
        {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok().body(evidencePage);

    }

}