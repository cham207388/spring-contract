package gov.dhs.uscis.submissionservice.validators.i765;

import static gov.dhs.uscis.intake.enums.I765EligibilityCategory.C8;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ReasonForFiling;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.validation.FormFieldResult;
import gov.dhs.uscis.submissionservice.models.validation.FormFields;
import gov.dhs.uscis.submissionservice.services.FeeService;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import gov.dhs.uscis.submissionservice.services.fees.strategies.i765.I765FeeStrategyOptions;
import gov.dhs.uscis.submissionservice.validators.FieldValidator;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AbcBenefitsAppliedValidator implements FieldValidator {

    SubmissionService submissionService;
    FeeService feeService;

    public AbcBenefitsAppliedValidator(SubmissionService submissionService, FeeService feeService) {
        this.submissionService = submissionService;
        this.feeService = feeService;
    }

    @Override
    public void validate(Submission submission, FormFields formFields) {
        String category = formFields.eligibilityCategory();
        if (category != null && C8.getCategory().equals(category.replaceAll("[\\s0]+", ""))) {
            BigDecimal feeTotal = feeService.calculateFeeFor(FormType.I765, C8,
                    new I765FeeStrategyOptions(formFields.abcBenefitsApplied(), false, false, ReasonForFiling.fromFormEntry(formFields.reasonForApplySelection()).toString(), submission.getUserRequestedFeeWaiver()));
            submissionService.updateFee(formFields.submissionId(), feeTotal);
        } else {
            log.info("Incompatible eligibility category for ABC calculations: {}", formFields.eligibilityCategory());
        }

    }

    @Override
    public void validate(Submission submission, FormFieldResult eligibility) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unsupported method 'validate'");
    }

}
