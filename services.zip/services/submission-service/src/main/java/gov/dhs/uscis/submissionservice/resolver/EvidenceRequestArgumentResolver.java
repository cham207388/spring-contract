package gov.dhs.uscis.submissionservice.resolver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import org.springframework.core.MethodParameter;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.models.dto.EvidenceRequest;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Part;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class EvidenceRequestArgumentResolver implements HandlerMethodArgumentResolver {
	private final static String ORG_REQUEST_PARAM_NAME = "orgMyUscisId";
	
    private final Predicate<Part> isFile = (part) -> {
        String headerValue = part.getHeader(HttpHeaders.CONTENT_DISPOSITION);
        ContentDisposition disposition = ContentDisposition.parse(headerValue);
        return disposition.getFilename() != null && "files".equals(part.getName());
    };
    private final Predicate<Part> isEvidence = (part) -> {
        return "uploadEvidenceRequests".equals(part.getName());
    };
    private final SubmissionService service;
    private final ObjectMapper mapper;

    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        return parameter.getParameter().getType() == EvidenceRequest.class;
    }

    @Override
    public Object resolveArgument(MethodParameter parameter, 
            ModelAndViewContainer mavContainer,
            NativeWebRequest webRequest, 
            WebDataBinderFactory binderFactory) throws Exception {
        String[] paths = ((ServletWebRequest) webRequest).getRequest().getRequestURI().replaceFirst("/", "").split("/");
        String orgId = ((ServletWebRequest) webRequest).getRequest().getParameter(ORG_REQUEST_PARAM_NAME);
        
        log.info("Possible Paths uscis: {}, submission id: {} with request params {}", paths[2], paths[4], orgId);
        String myUscisId = paths[2];
        String submissionId = paths[4];
       
        
        List<UploadEvidenceRequest> evidences = parseEvidence(webRequest);
        List<Part> files = parseFiles(webRequest);
        EvidenceRequest result = new EvidenceRequest(evidences, files, service.retrieveSubmissionByIdAndUscisId(submissionId, myUscisId, orgId));
        
        if(isValidationRequired(parameter))  validate(result, webRequest, parameter, binderFactory);
    
        log.info("Validation seems fine");
        return result;
    }
    
    private boolean isValidationRequired(MethodParameter parameter) {
        return parameter.hasParameterAnnotation(Valid.class) ||
             parameter.hasParameterAnnotation(Validated.class);
    }

    private List<UploadEvidenceRequest> parseEvidence(NativeWebRequest request) throws IOException, ServletException {
        List<Part> evidences = ((ServletWebRequest)request).getRequest().getParts().stream().filter(isEvidence).toList();
        List<UploadEvidenceRequest> result = new ArrayList<>();
        for(Part evidence : evidences) result.add(mapper.readValue(evidence.getInputStream(), UploadEvidenceRequest.class));
        return result;
    }

    private List<Part> parseFiles(NativeWebRequest request) throws IOException, ServletException {
        return ((ServletWebRequest)request).getRequest().getParts().stream().filter(isFile).toList();
    }

    private void validate(EvidenceRequest request, NativeWebRequest webRequest, MethodParameter parameter, WebDataBinderFactory binderFactory) 
        throws Exception {
        WebDataBinder binder = binderFactory.createBinder(webRequest, request, parameter.getParameter().getName());
        binder.validate();
        BindingResult result = binder.getBindingResult();
        if(result.getErrorCount() > 0) throw new MethodArgumentNotValidException(parameter, result);
    }

}
