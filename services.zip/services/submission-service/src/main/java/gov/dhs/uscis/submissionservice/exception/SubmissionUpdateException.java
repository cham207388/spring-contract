package gov.dhs.uscis.submissionservice.exception;

public class SubmissionUpdateException extends RuntimeException {

    public SubmissionUpdateException(String errorMessage) {
        super(String.format("%s", errorMessage));
    }
}
