package gov.dhs.uscis.submissionservice.models.dto;

import java.util.List;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.EligibilityCategoryEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.validation.ValidationDetails;
import gov.dhs.uscis.submissionservice.validators.FeeWaiverEvidenceRequired;
import gov.dhs.uscis.submissionservice.validators.IsDraft;
import gov.dhs.uscis.submissionservice.validators.ValidEvidence;
import gov.dhs.uscis.submissionservice.validators.ValidForm;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FeeWaiverEvidenceRequired
@ValidForm
@ValidEvidence
public class FinalSubmissionDto {
    FormType type;
    EligibilityCategoryEnum category;
    String submissionId;
    @IsDraft
    SubmissionState status;
    @AssertTrue
    Boolean attested;
    @AssertTrue
    Boolean hasReviewedSignature;
    String signature;
    SubmissionEvidence feeWaiver;
    Boolean userRequestedFeeWaiver;
    Boolean userRequestedPartialFeeWaiver;
    List<ValidationDetails> validations;
    @NotEmpty
    List<SubmissionForm> forms;
    List<SubmissionEvidence> evidences;
}
