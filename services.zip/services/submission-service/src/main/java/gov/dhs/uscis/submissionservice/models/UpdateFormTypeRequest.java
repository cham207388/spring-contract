package gov.dhs.uscis.submissionservice.models;

import gov.dhs.uscis.intake.enums.FormType;
import lombok.Builder;

@Builder
public record UpdateFormTypeRequest(FormType formType){}