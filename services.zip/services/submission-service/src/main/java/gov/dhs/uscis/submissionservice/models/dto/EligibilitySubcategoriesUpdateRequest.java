package gov.dhs.uscis.submissionservice.models.dto;

import java.util.List;

import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EligibilitySubcategoriesUpdateRequest {
    List<EligibilitySubcategoryEnum> eligibilitySubcategories;
}
