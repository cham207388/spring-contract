package gov.dhs.uscis.submissionservice.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.dhs.uscis.submissionservice.entity.Toggle;

@Repository
public interface ToggleRepository extends CrudRepository<Toggle, String>{

}