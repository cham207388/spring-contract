package gov.dhs.uscis.submissionservice.services;

import java.time.ZonedDateTime;

import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.models.CoreMetaData;
import gov.dhs.uscis.intake.models.dto.CoreData;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;

@Service
public class CoreService {

    public static final String CORE_ID = "CORE";
    private DynamoDbTable<CoreMetaData> coreMetaDataTable;

    public CoreService(DynamoDbTable<CoreMetaData> coreMetaDataTable) {
        this.coreMetaDataTable = coreMetaDataTable;
    }

    public CoreData getCoreMetaData() {
        Key key = Key.builder().partitionValue(CORE_ID).build();
        GetItemEnhancedRequest request = GetItemEnhancedRequest.builder().key(key).build();
        CoreMetaData item = coreMetaDataTable.getItem(request);
        boolean beforeIncludingEnd = ZonedDateTime.now().isBefore(item.getPaygovMaintenanceWindow().getEnd()) ||  ZonedDateTime.now().isEqual(item.getPaygovMaintenanceWindow().getEnd());
        boolean afterIncludingStart = ZonedDateTime.now().isAfter(item.getPaygovMaintenanceWindow().getStart()) ||  ZonedDateTime.now().isEqual(item.getPaygovMaintenanceWindow().getStart());


        return CoreData.builder()
                .paygovMaintenanceEnabled(beforeIncludingEnd && afterIncludingStart)
                .betaBanners(item.getBetaBanners())
                .build();
    }
    
}
