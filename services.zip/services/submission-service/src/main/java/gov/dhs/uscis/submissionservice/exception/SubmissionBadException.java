package gov.dhs.uscis.submissionservice.exception;

public class SubmissionBadException extends RuntimeException  {

    public SubmissionBadException(String errorMessage) {
        super(String.format("%s", errorMessage));
    }
    
}
