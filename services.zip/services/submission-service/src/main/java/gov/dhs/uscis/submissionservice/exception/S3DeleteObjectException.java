package gov.dhs.uscis.submissionservice.exception;

import gov.dhs.uscis.intake.constants.S3Constants;

public class S3DeleteObjectException extends RuntimeException {
    public S3DeleteObjectException(String errorMessage) {
        super(String.format("%s : %s", S3Constants.DELETION_FAILURE_MESSAGE, errorMessage));
    }  
}
