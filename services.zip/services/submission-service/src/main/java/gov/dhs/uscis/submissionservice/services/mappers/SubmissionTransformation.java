package gov.dhs.uscis.submissionservice.services.mappers;

import gov.dhs.uscis.intake.models.Submission;

public interface SubmissionTransformation {
    Submission transform(Submission submission );
}
