package gov.dhs.uscis.submissionservice.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.submissionservice.exception.BackendValidationException;
import gov.dhs.uscis.submissionservice.exception.NoFormInSubmissionException;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/{myUscisId}/submissions")
public class SubmissionValidationController {

	private SubmissionService submissionService;
	
	public SubmissionValidationController(SubmissionService submissionService) {
		this.submissionService = submissionService;
	}
	
	@GetMapping("/{submissionId}/pfvs/validate")
	public ResponseEntity<String> validatePFVSSubmission(@PathVariable("myUscisId") String myUscisId,
			@PathVariable("submissionId") String submissionId) {
		try {
			submissionService.validateSubmission(myUscisId, submissionId);
		} catch(BackendValidationException | NoFormInSubmissionException e) {
			return ResponseEntity.internalServerError().body(e.getMessage());
		}
		String success = String.format("Successfully sent validation request to PFVS for submission %s", submissionId);
		return ResponseEntity.ok().body(success);
	}
	
}
