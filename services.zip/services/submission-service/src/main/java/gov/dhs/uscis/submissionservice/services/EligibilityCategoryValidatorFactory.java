package gov.dhs.uscis.submissionservice.services;

import java.util.EnumMap;
// import java.util.HashMap;

import org.springframework.stereotype.Component;

// import com.amazonaws.services.datazone.model.FormTypeData;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.submissionservice.validators.FieldValidator;
import gov.dhs.uscis.submissionservice.validators.n400.BasisOfEligibilityValidator;

@Component
public class EligibilityCategoryValidatorFactory {

    private EnumMap<FormType, FieldValidator> validators;

    public EligibilityCategoryValidatorFactory(
            BasisOfEligibilityValidator basisOfEligibilityCategory) {

        validators = new EnumMap<>(FormType.class);
        validators.put(FormType.N400, basisOfEligibilityCategory);
    }

    public FieldValidator getValidator(FormType formType) {
        return validators.get(formType);
    }
}