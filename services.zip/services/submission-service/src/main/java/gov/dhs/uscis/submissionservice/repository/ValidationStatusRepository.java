package gov.dhs.uscis.submissionservice.repository;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ValidationStatus;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.DeleteItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@Slf4j
@Component
@AllArgsConstructor
public class ValidationStatusRepository {

  private final DynamoDbTable<ValidationStatus> validationStatusTable;

  public List<ValidationStatus> getByFileId(String fileId) {
    Key key = Key.builder().partitionValue(fileId).build();
    QueryConditional queryConditional = QueryConditional.keyEqualTo(key);
    return validationStatusTable.query(queryConditional).items().stream().collect(Collectors.toList());
  }

  public ValidationStatus save(ValidationStatus validationStatus) {
    PutItemEnhancedRequest<ValidationStatus> enhancedRequest = PutItemEnhancedRequest
        .builder(ValidationStatus.class)
        .item(validationStatus)
        .build();
    validationStatusTable.putItem(enhancedRequest);

    return validationStatus;
  }

  
  public void deleteById(String formId, ValidatorEnum validator) {
    log.info("ValidationStatusDAO.deleteById :: formId: {}; validator: {};", formId, validator);
    DeleteItemEnhancedRequest deleteRequest = DeleteItemEnhancedRequest.builder()
        .key(builder -> builder.partitionValue(formId).sortValue(validator.name())).build();
    validationStatusTable.deleteItem(deleteRequest);
  }


  public ValidationStatus update(ValidationStatus validationStatus) {
    
    UpdateItemEnhancedRequest<ValidationStatus> enhancedRequest = UpdateItemEnhancedRequest
        .builder(ValidationStatus.class)
        .item(validationStatus)
        .build();
    
    return validationStatusTable.updateItem(enhancedRequest);
  }
}
