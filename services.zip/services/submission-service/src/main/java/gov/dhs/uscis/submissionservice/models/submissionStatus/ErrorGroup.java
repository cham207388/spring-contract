package gov.dhs.uscis.submissionservice.models.submissionStatus;

import java.util.List;

import lombok.Builder;

@Builder
public record ErrorGroup(String formType, String type, List<String> errors) {
}