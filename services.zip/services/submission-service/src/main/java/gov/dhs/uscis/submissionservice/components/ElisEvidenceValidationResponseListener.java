package gov.dhs.uscis.submissionservice.components;

import java.math.BigDecimal;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.constants.DocumentType.FeeWaiver;
import gov.dhs.uscis.intake.enums.PFVSEvidenceType;
import gov.dhs.uscis.intake.models.ELISValidationResponse;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.submissionservice.repository.SubmissionRepository;
import gov.dhs.uscis.submissionservice.repository.ValidationStatusRepository;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;

@Component
public class ElisEvidenceValidationResponseListener implements MessageListener {

    private final ValidationStatusRepository validationStatusDAO;
    private final SubmissionRepository submissionDAO;
    private final SubmissionService submissionService;

    ObjectMapper mapper = new ObjectMapper();
    private static final Logger logger = LoggerFactory.getLogger(ElisEvidenceValidationResponseListener.class);

    @Autowired
    public ElisEvidenceValidationResponseListener(ValidationStatusRepository validationStatusDAO,
            SubmissionRepository submissionDAO, SubmissionService submissionService) {
        this.validationStatusDAO = validationStatusDAO;
        this.submissionDAO = submissionDAO;
        this.submissionService = submissionService;
    }

    @Override
    public void onMessage(Message message) {
        TextMessage textMessage = (TextMessage) message;
        try {
            MDC.put("traceId", UUID.randomUUID().toString());
            ELISValidationResponse updatedStatuses = mapper.readValue(textMessage.getText(), ELISValidationResponse.class);
            
            logger.info("Received elis evidence validation respone with {} statuses, for submission {} resulting in a {}",
                    updatedStatuses.results().size(), updatedStatuses.submissionId(), updatedStatuses.pass());
                    
            updatedStatuses.results().stream().forEach(validationStatusDAO::update);
            
            Optional<Submission> existingSubmissionOpt = submissionDAO.getById(updatedStatuses.submissionId());
            if (existingSubmissionOpt.isPresent()) {
                Submission existingSubmission = existingSubmissionOpt.get();
                logger.info("Setting submission fee to {}", updatedStatuses.totalFee());
                existingSubmission.setFeeTotal(updatedStatuses.totalFee());
                
                if(PFVSEvidenceType.I912.getType().equals(updatedStatuses.formType())) {
                	logger.info("Determined to be an I-912");
                	existingSubmission = submissionService.updateFeeWaiverEvidence(existingSubmission, FeeWaiver.FORM_I912, true);
                }
                submissionDAO.save(existingSubmission);
            }
            textMessage.acknowledge();
        } catch (Exception e) {
            throw new RuntimeException("Could not deserialize the validation status object", e);
        } finally {
            MDC.clear();
        }
    }
}