package gov.dhs.uscis.submissionservice.services;

import java.util.NoSuchElementException;
import java.util.Optional;


import gov.dhs.uscis.intake.enums.ActionRequested;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I765EligibilityCategory;
import gov.dhs.uscis.intake.enums.RequestedAction;
import gov.dhs.uscis.intake.enums.eligibility.EligibilitySubcategoryEnum;
import gov.dhs.uscis.intake.enums.eligibility.I129H1BEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I129TNEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I129EEligibilitySubcategory;
import gov.dhs.uscis.intake.enums.eligibility.I129REligibilitySubcategory;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.additionalinformation.AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129H1BAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129H2AAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129TNAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129EAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I129RAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I130AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I140AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I485AAdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I485AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I751AdditionalInformation;
import gov.dhs.uscis.intake.models.additionalinformation.I765AdditionalInformation;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.intake.models.submission.form_specific_info.FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I129H1BFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I129TNFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I129EFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I129RFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I129H2AFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I130FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I140FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485AFormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I485FormSpecificInfo;
import gov.dhs.uscis.intake.models.submission.form_specific_info.I765FormSpecificInfo;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AdditionalInformationFactory {

    private AdditionalInformationFactory() {
        throw new IllegalStateException("Static class. Don't new it up.");
    }

    public static Optional<AdditionalInformation> createAdditionalInformation(Submission submission,
            FormService formService, FormType requestedFormType) {

        AdditionalInformation additionalInfo = null;
        SubmissionForm activeForm = submission.getForms()
				.stream()
				.filter(form -> requestedFormType.getType().equals(form.getType()))
				.findFirst().orElseThrow(() -> new NoSuchElementException(String.format("Form Not Found: %s", requestedFormType.getType())));

        FormSpecificInfo formSpecificInfo = null;
        if(activeForm.getFormSpecificInfo() != null){
            formSpecificInfo = activeForm.getFormSpecificInfo();
        } else if (submission.getFormSpecificInfo() != null && submission.getFormSpecificInfo().getFormType() == requestedFormType){
            formSpecificInfo = submission.getFormSpecificInfo();
        }

        switch (requestedFormType) {
            case I129H1B:
                   I129H1BAdditionalInformation i129AdditionalInformation = new I129H1BAdditionalInformation();
                ActionRequested actionRequested;
                EligibilitySubcategoryEnum eligibilitySubcategory;
                Boolean isCapGap;
                Boolean isCapEnabled;

                actionRequested = ((I129H1BFormSpecificInfo) formSpecificInfo).getActionRequested();
                isCapGap = ((I129H1BFormSpecificInfo) formSpecificInfo).getIsCapGap();
                isCapEnabled = ((I129H1BFormSpecificInfo) formSpecificInfo).getIsCapEnabled();
                eligibilitySubcategory = activeForm.getEligibilitySubcategory() != null ? activeForm.getEligibilitySubcategory() : submission.getEligibilitySubcategory();

                i129AdditionalInformation.setActionRequested(actionRequested);
                i129AdditionalInformation.setImmigrationClassCode((I129H1BEligibilitySubcategory) eligibilitySubcategory);
                i129AdditionalInformation.setIsCapGap(isCapGap);
                i129AdditionalInformation.setIsCapEnabled(isCapEnabled);
                additionalInfo = i129AdditionalInformation;
                break;
            case I129H2A:
                I129H2AAdditionalInformation i129H2AAdditionalInformation = new I129H2AAdditionalInformation();
                if(formSpecificInfo != null) {
        		    i129H2AAdditionalInformation.setRequestedAction(((I129H2AFormSpecificInfo) formSpecificInfo).getRequestedAction());
        	    }
                else {
                    i129H2AAdditionalInformation.setRequestedAction(RequestedAction.valueOf(submission.getReasonForFiling()));
                }
                additionalInfo = i129H2AAdditionalInformation;
                break;
            case I129TN:
                I129TNAdditionalInformation i129TNAdditionalInformation = new I129TNAdditionalInformation();
                actionRequested = ((I129TNFormSpecificInfo) formSpecificInfo).getActionRequested();
                i129TNAdditionalInformation.setActionRequested(actionRequested);

                eligibilitySubcategory = activeForm.getEligibilitySubcategory() != null ? activeForm.getEligibilitySubcategory() : submission.getEligibilitySubcategory();
                i129TNAdditionalInformation.setImmigrationClassCode((I129TNEligibilitySubcategory) eligibilitySubcategory);
                additionalInfo = i129TNAdditionalInformation;
                break;
            case I129E:
                I129EAdditionalInformation i129EAdditionalInformation = new I129EAdditionalInformation();
                actionRequested = ((I129EFormSpecificInfo) formSpecificInfo).getActionRequested();
                i129EAdditionalInformation.setActionRequested(actionRequested);

                eligibilitySubcategory = activeForm.getEligibilitySubcategory() != null ? activeForm.getEligibilitySubcategory() : submission.getEligibilitySubcategory();
                i129EAdditionalInformation.setImmigrationClassCode((I129EEligibilitySubcategory) eligibilitySubcategory);
                additionalInfo = i129EAdditionalInformation;
                break;
            case I129R:
                I129RAdditionalInformation i129RAdditionalInformation = new I129RAdditionalInformation();
                actionRequested = ((I129RFormSpecificInfo) formSpecificInfo).getActionRequested();
                i129RAdditionalInformation.setActionRequested(actionRequested);

                eligibilitySubcategory = activeForm.getEligibilitySubcategory() != null ? activeForm.getEligibilitySubcategory() : submission.getEligibilitySubcategory();
                i129RAdditionalInformation.setImmigrationClassCode((I129REligibilitySubcategory) eligibilitySubcategory);
                additionalInfo = i129RAdditionalInformation;
                break;
            case I130:
                I130AdditionalInformation i130addtionalInfo = new I130AdditionalInformation();
                if(formSpecificInfo != null) {
        		    i130addtionalInfo.setIsUSCitizen(((I130FormSpecificInfo) formSpecificInfo).getIsUSCitizen());
        	    }
                else {
                    i130addtionalInfo.setIsUSCitizen(submission.getIsUSCitizen());
                }
                additionalInfo = i130addtionalInfo;
                break;
            case I751:
                I751AdditionalInformation i751AdditionalInformation = new I751AdditionalInformation();
                // Confirm this value if for multiple eligibility sub categories
                // TODO Convert the EligibilitySubCategory to an integer
                // Determine if we should trust this is always set to an integer for each sub
                // category
                i751AdditionalInformation.setEligibilityCategories(formService.addApplicationReasonCodes(submission, requestedFormType));
                additionalInfo = i751AdditionalInformation;
                break;
            case I140:
                if (formSpecificInfo != null) {
                    I140AdditionalInformation i140AdditionalInformation = new I140AdditionalInformation();
                    i140AdditionalInformation.setScheduleA(((I140FormSpecificInfo) activeForm.getFormSpecificInfo()).getIsScheduleA());
                    additionalInfo = i140AdditionalInformation;
                }
                break;
            case I485:
                if (formSpecificInfo != null) {
                    I485AdditionalInformation i485AdditionalInformation = new I485AdditionalInformation();
                    if(activeForm.getFormSpecificInfo() != null) {
                        i485AdditionalInformation
                                .setMilitaryVeteran(
                                        ((I485FormSpecificInfo) activeForm.getFormSpecificInfo()).isMilitaryVeteran());
                        i485AdditionalInformation
                                .setUnder14(
                                        ((I485FormSpecificInfo) activeForm.getFormSpecificInfo()).isUnder14());
                        additionalInfo = i485AdditionalInformation;
                    }
                }
                break;
            case I485A:
                if (formSpecificInfo != null) {
                    I485AAdditionalInformation i485AAdditionalInformation = new I485AAdditionalInformation();
                    i485AAdditionalInformation.setI817Beneficiary(((I485AFormSpecificInfo) activeForm.getFormSpecificInfo()).calcIsI817Beneficiary());
                    additionalInfo = i485AAdditionalInformation;
                }
                break;
            case I765:
            	if(formSpecificInfo != null) {
            		I765FormSpecificInfo i765FormSpecificInfo = (I765FormSpecificInfo) formSpecificInfo;
            		I765AdditionalInformation i765AdditionalInformation = new I765AdditionalInformation();
                    if ((I765EligibilityCategory.C9.equals(activeForm.getEligibilityCategory()))) {
                    	i765AdditionalInformation.setOnOrAfterApril012024(i765FormSpecificInfo.isOnOrAfterApril012024());
                    	i765AdditionalInformation.setBefore04012024(i765FormSpecificInfo.isBefore04012024());
                    }
                    // if User requested fee waiver set additional information
                    i765AdditionalInformation.setImmvi(i765FormSpecificInfo.isImmvi());
                    additionalInfo = i765AdditionalInformation;
            	}
        		break;
            default:
                log.info("Form type {} is not implemented", submission.getFormType());
                return Optional.empty();
        }

        return Optional.ofNullable(additionalInfo);
    }
}
