package gov.dhs.uscis.submissionservice.models.dto;

import static java.util.Collections.emptyList;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.dto.SubmissionDto;
import gov.dhs.uscis.intake.models.dto.SubmissionEvidenceDto;
import gov.dhs.uscis.intake.models.dto.SubmissionFormDto;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class SubmissionMapper {

    public static SubmissionFormDto toSubmissionFormDto(SubmissionForm form) {
        if (form == null) {
            return null;
        }

        return SubmissionFormDto.builder()
                .type(form.getType())
                .eligibilityCategory(form.getEligibilityCategory())
                .eligibilitySubcategory(form.getEligibilitySubcategory())
                .id(form.getId())
                .name(form.getName())
                .feeTotal(form.getFeeTotal())
                .md5Hash(form.getMd5Hash())
                .paymentTrackingId(form.getPaymentTrackingId())
                .lockboxStatus(form.getLockboxStatus())
                .validations(form.getValidations())
                .rejectionReasons(form.getRejectionReasons())
                .uploadedAt(form.getUploadedAt())
                .benefitTypeCode(form.getBenefitTypeCode())
                .applicationReasonCode(form.getApplicationReasonCode())
                .formSpecificInfo(form.getFormSpecificInfo())
                .clientId(form.getClientId())
                .clientName(form.getClientName())
                .build();
    }

    public static List<SubmissionFormDto> toSubmissionFormDtoList(List<SubmissionForm> forms) {
        if (forms == null) {
            return emptyList();
        }

        return forms.stream().map(SubmissionMapper::toSubmissionFormDto).toList();
    }

    public static SubmissionEvidenceDto toSubmissionEvidenceDto(SubmissionEvidence evidence) {
        if (evidence == null) {
            return null;
        }

        return SubmissionEvidenceDto.builder()
                .type(evidence.getType())
                .evidenceGroupType(evidence.getEvidenceGroupType())
                .id(evidence.getId())
                .name(evidence.getName())
                .md5Hash(evidence.getMd5Hash())
                .uploadedAt(evidence.getUploadedAt())
                .isEditable(evidence.getIsEditable())
                .formId(evidence.getFormId())
                .build();
    }

    public static List<SubmissionEvidenceDto> toSubmissionEvidenceDtoList(List<SubmissionEvidence> evidences) {
        if (evidences == null) {
            return emptyList();
        }

        return evidences.stream().map(SubmissionMapper::toSubmissionEvidenceDto).toList();
    }

    public static SubmissionDto toSubmissionDTO(Submission submission) {
        if (submission == null) {
            return null;
        }

        return SubmissionDto.builder()
                .myUscisId(submission.getMyUscisId())
                .submissionId(submission.getSubmissionId())
                .formType(submission.getFormType())
                .formName(submission.getFormName())
                .eligibilityCategory(submission.getEligibilityCategory())
                .eligibilitySubcategories(submission.getEligibilitySubcategories())
                .eligibilitySubcategory(submission.getEligibilitySubcategory())
                .benefitTypeCode(submission.getBenefitTypeCode())
                .applicationReasonCode(submission.getApplicationReaonCode())
                .manifestId(submission.getManifestId())
                .status(submission.getStatus())
                .lockboxStatus(submission.getLockboxStatus())
                .lockboxErrors(submission.getLockboxErrors())
                .feeTotal(submission.getFeeTotal())
                .timestamp(submission.getTimestamp())
                .updatedAt(submission.getUpdatedAt())
                .expireDate(submission.getUpdatedAt() != null ? submission.getUpdatedAt().plusDays(30) : null)
                .forms(toSubmissionFormDtoList(submission.getForms()))
                .feeWaiver(toSubmissionEvidenceDto(submission.getFeeWaiver()))
                .evidences(toSubmissionEvidenceDtoList(submission.getEvidences()))
                .userRequestedFeeWaiver(submission.getUserRequestedFeeWaiver())
                .userRequestedPartialFeeWaiver(submission.getUserRequestedPartialFeeWaiver())
                .userIsEligibleForFeeWaiver(submission.getUserIsEligibleForFeeWaiver())
                .attested(submission.getAttested())
                .hasReviewedSignature(submission.getHasReviewedSignature())
                .attestedAt(submission.getAttestedAt())
                .attestationSignature(submission.getAttestationSignature())
                .applicant(submission.getApplicant())
                .submittedAt(submission.getSubmittedAt())
                .immvi(submission.getImmvi())
                .clientInformation(submission.getClientInformation())
                .c9UpdateRequest(submission.getC9updateRequest())
                .isUSCitizen(submission.getIsUSCitizen())
                .reasonForFiling(submission.getReasonForFiling())
                .formSpecificInfo(submission.getFormSpecificInfo())
                .sentNotification(submission.getSentNotify() != null? submission.getSentNotify() : Boolean.FALSE)
                .orgMyUscisId(submission.getOrgMyUscisId())
                .selectedConcurrentForms(submission.getSelectedConcurrentForms())               
                .build();

    }

    public static List<SubmissionDto> toSubmissionDtoList(List<Submission> submissions) {
        if (submissions.isEmpty()) {
            return List.of();
        }

        return submissions.stream().map(SubmissionMapper::toSubmissionDTO).collect(Collectors.toList());
    }
}
