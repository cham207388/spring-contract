package gov.dhs.uscis.submissionservice.configs;

import java.util.List;

import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.monitoring.MDCInterceptor;
import gov.dhs.uscis.submissionservice.converters.SubmissionParameterConverter;
import gov.dhs.uscis.submissionservice.resolver.EvidenceRequestArgumentResolver;
import gov.dhs.uscis.submissionservice.services.SubmissionService;
import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {

    private final SubmissionParameterConverter submissionIdToFinalSubmissionDtoConverter;
    private final SubmissionService service;
    private final ObjectMapper mapper;

    @Override
    public void addFormatters(FormatterRegistry registry) {
        registry.addConverter(submissionIdToFinalSubmissionDtoConverter);
    }

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
        resolvers.add(new EvidenceRequestArgumentResolver(service, mapper));
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new MDCInterceptor("X-CORRELATION-ID"));
    }
}
