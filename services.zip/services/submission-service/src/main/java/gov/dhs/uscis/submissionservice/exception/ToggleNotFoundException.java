package gov.dhs.uscis.submissionservice.exception;

public class ToggleNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = -134521376854072334L;

	public ToggleNotFoundException(String toggleName) {
		super(String.format("Toggle with name %s not found.", toggleName));
	}
}
