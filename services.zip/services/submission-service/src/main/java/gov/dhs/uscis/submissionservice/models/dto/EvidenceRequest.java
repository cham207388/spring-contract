package gov.dhs.uscis.submissionservice.models.dto;

import java.util.List;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.submissionservice.models.UploadEvidenceRequest;
import gov.dhs.uscis.submissionservice.validators.NoMissingEvidence;
import gov.dhs.uscis.submissionservice.validators.SubmissionHasRequiredFieldsForEvidenceRequest;
import gov.dhs.uscis.submissionservice.validators.ValidPdfDimensions;
import jakarta.servlet.http.Part;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@NoMissingEvidence
@SubmissionHasRequiredFieldsForEvidenceRequest
public record EvidenceRequest(@Valid @NotEmpty List<UploadEvidenceRequest> evidences, @ValidPdfDimensions @NotEmpty List<Part> files, @NotNull Submission submission) {}
