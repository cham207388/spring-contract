package gov.dhs.uscis.submissionservice.models.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReasonForFilingUpdateRequest {
    @NotNull
    private String reasonForFiling;
}
