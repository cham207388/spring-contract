package gov.dhs.uscis.submissionservice.controllers;

import gov.dhs.uscis.intake.models.core.Name;

public record AddClientRequestDetails(String emailAddress,  Name name, String aNumber, String dateOfBirth ){}