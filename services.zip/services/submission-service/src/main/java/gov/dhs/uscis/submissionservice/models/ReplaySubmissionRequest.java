package gov.dhs.uscis.submissionservice.models;

public record ReplaySubmissionRequest (String myUscisId, String submissionId) {

}
