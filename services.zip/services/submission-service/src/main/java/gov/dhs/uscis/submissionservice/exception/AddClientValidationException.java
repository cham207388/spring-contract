package gov.dhs.uscis.submissionservice.exception;

public class AddClientValidationException extends RuntimeException {
    public AddClientValidationException(String errorMessage) {
      super(String.format("%s", errorMessage));
    }
}