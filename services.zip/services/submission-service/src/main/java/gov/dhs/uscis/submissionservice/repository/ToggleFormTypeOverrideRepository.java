package gov.dhs.uscis.submissionservice.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.dhs.uscis.submissionservice.entity.ToggleFormTypeOverride;

@Repository
public interface ToggleFormTypeOverrideRepository extends CrudRepository<ToggleFormTypeOverride, String>{

	Optional<ToggleFormTypeOverride> findByIdToggleNameAndIdFormType(String toggleName, String formType);
}