package gov.dhs.uscis.submissionservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "concurrent_forms")
public class ConcurrentForms {

    public ConcurrentForms(String primaryFormType, String concurrentFormType, boolean active) {
        this.id = new ConcurrentFormPair(primaryFormType, concurrentFormType);
        this.active = active;
    }

    public ConcurrentForms(){}

    @EmbeddedId
    private ConcurrentFormPair id;

    @Column(name = "active")
    private boolean active;
}