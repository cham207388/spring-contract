package gov.dhs.uscis.submissionservice.models.dto;

import lombok.Data;
import jakarta.validation.constraints.NotNull;

@Data
public class ImmviUpdateRequest {
    @NotNull
    private Boolean immvi;
}
