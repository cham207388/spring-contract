package gov.dhs.uscis.submissionservice.validators;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.Collection; 
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.io.RandomAccessReadBuffer;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.Part;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class PdfDimensionValidator implements ConstraintValidator<ValidPdfDimensions, Object> {

    private static final float MAX_POINTS = 7200f;

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        if (value == null) return true;

        // Handle List/Collection directly to avoid ".<list element>" path
        if (value instanceof Collection<?> collection) {
            for (Object item : collection) {
                if (!validateSingleFile(item)) {
                    return false;
                }
            }
            return true;
        }

        return validateSingleFile(value);
    }

        private boolean validateSingleFile(Object value) {
        if (value == null) return true;

        String contentType = getContentType(value);
        if (contentType == null || !contentType.equalsIgnoreCase("application/pdf")) {
            return true; 
        }

        log.debug("Validating PDF dimensions for content type: {}", contentType);

        try (InputStream is = getInputStream(value)) {
             if (is == null) return true;
             
             try (RandomAccessReadBuffer ra = new RandomAccessReadBuffer(is);
                  PDDocument document = Loader.loadPDF(ra)) {

                int pageCount = document.getNumberOfPages();
                
                for (int i = 0; i < pageCount; i++) {
                    PDPage page = document.getPage(i);
                    float userUnit = page.getUserUnit();
                    float width = page.getMediaBox().getWidth() * userUnit;
                    float height = page.getMediaBox().getHeight() * userUnit;
                    
                    if (width > MAX_POINTS || height > MAX_POINTS) {
                        log.info("PDF Validation Failed: Page {} exceeds limits. Dimensions: {}x{} pts", 
                                 i + 1, width, height);
                        return false;
                    }
                }
                return true;
             }
        } catch (Exception e) {
            log.error("PDF Validation Error: Could not parse PDF structure.", e);
            return false;
        }
    }


    private String getContentType(Object value) {
        if (value instanceof MultipartFile mf) return mf.getContentType();
        if (value instanceof Part p) return p.getContentType();
        return null;
    }

    private InputStream getInputStream(Object value) {
        try {
        if (value instanceof MultipartFile mf) return mf.getInputStream();
        if (value instanceof Part p) return p.getInputStream();
        return null;
        }
        catch (IOException e) {
          throw new UncheckedIOException("Failed to get InputStream from " + value.getClass().getSimpleName(), e);
        }
    }
}
