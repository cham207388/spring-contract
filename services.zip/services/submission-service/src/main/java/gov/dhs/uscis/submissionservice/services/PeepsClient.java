package gov.dhs.uscis.submissionservice.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import gov.dhs.uscis.intake.exceptions.MyUscisProcessingException;
import gov.dhs.uscis.submissionservice.models.myUscis.peeps.PeepsProfileResponse;

public class PeepsClient {

    public static final String NO_PROFILE_EXISTS = "No profile exists";
    public static final String PROFILE_ERROR = "Profile fetch failed";
    private WebClient peepsClient;
    public static final String USER_QUERY_URL = "/api/peeps/search";
    public static final String USER_QUERY_BY_EMAIL_URL = "/api/icam/bulk_fetch_user_info";
    public static final String INVITE_USER_ENDPOINT = "/api/icam/invite-user";
    public static final String PROFILE_URL = "/api/user-profile/receipt-profile/latest";
    public static final String FORM_FIELD_DOB_FORMAT = "MM/dd/yyyy";

    private Logger logger = LoggerFactory.getLogger(PeepsClient.class);

    public PeepsClient(WebClient peepsClient) {
        this.peepsClient = peepsClient;
    }

    public PeepsProfileResponse retrieveUserInfo(String userUUID) throws MyUscisProcessingException {

        return peepsClient.get()
                .uri(PROFILE_URL)
                .header("ICAM-UUID", userUUID)
                .retrieve()
                .bodyToMono(PeepsProfileResponse.class)
                .doOnError(WebClientResponseException.class, e -> {
                    if (HttpStatusCode.valueOf(404) == e.getStatusCode()) {
                        throw new MyUscisProcessingException(NO_PROFILE_EXISTS);
                    } else {
                        logger.error("Error while retrieving user info peeps service {}", userUUID);
                        throw new MyUscisProcessingException(PROFILE_ERROR);
                    }
                })
                .block();

    }

}