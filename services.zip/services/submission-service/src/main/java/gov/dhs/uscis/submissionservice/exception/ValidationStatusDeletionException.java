package gov.dhs.uscis.submissionservice.exception;

public class ValidationStatusDeletionException extends RuntimeException {

  public ValidationStatusDeletionException(String errorMessage) {
    super(String.format("%s", errorMessage));
  }
}
