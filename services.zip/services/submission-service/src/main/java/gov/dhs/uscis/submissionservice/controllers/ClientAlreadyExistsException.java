package gov.dhs.uscis.submissionservice.controllers;

public class ClientAlreadyExistsException extends RuntimeException {

    public ClientAlreadyExistsException(String string) {
        //TODO Auto-generated constructor stub
    }

}
