package gov.dhs.uscis.submissionservice.services.fees;

import java.math.BigDecimal;
import java.util.Map;

public interface FeeStrategy<T> {
    public boolean canHandle(T handlingContext);

    public BigDecimal calculate(FeeStrategyOptions options, Map<String, BigDecimal> fees);
}
