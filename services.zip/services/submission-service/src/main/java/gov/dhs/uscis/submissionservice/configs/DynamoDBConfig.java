package gov.dhs.uscis.submissionservice.configs;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import gov.dhs.uscis.intake.entities.ClientInformation;
import gov.dhs.uscis.intake.entities.audit.Audit;
import gov.dhs.uscis.intake.models.CoreMetaData;
import gov.dhs.uscis.intake.models.EvidenceMetaData;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.validation.name_extract.NameExtract;
import gov.dhs.uscis.intake.models.validation.address_extract.AddressExtract;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.DynamoDbClientBuilder;

@Configuration
public class DynamoDBConfig {

    @Value("${uscis.dynamodb.endpoint}")
    private String amazonDynamoDBEndpoint;

    @Value("${uscis.dynamodb.prefix}")
    private String tablePrefix;

    @Bean
    public DynamoDbClient getDynamoDbClient() throws URISyntaxException {
        DynamoDbClientBuilder dynamoDbClientBuilder = DynamoDbClient.builder().region(Region.US_EAST_1);
        if (StringUtils.hasLength(amazonDynamoDBEndpoint))
            dynamoDbClientBuilder.endpointOverride(new URI(amazonDynamoDBEndpoint));

        return dynamoDbClientBuilder.build();
    }

    @Bean
    public DynamoDbEnhancedClient amazonDynamoDBEnhanced(DynamoDbClient dynamoDbClient) {
        return DynamoDbEnhancedClient.builder().dynamoDbClient(dynamoDbClient).build();
    }

    @Bean
    public DynamoDbTable<Submission> submissionsTable(DynamoDbEnhancedClient enhancedDbClient) {
        return retrieveTable(enhancedDbClient, "Submission", Submission.class);
    }

    @Bean
    public DynamoDbTable<ClientInformation> clientInformationTable(DynamoDbEnhancedClient enhancedDbClient) {
        return retrieveTable(enhancedDbClient, "ClientInformation", ClientInformation.class);
    }

    @Bean
    public DynamoDbTable<FormMetaData> formMetaDataTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        return retrieveTable(enhancedDbClient, "FormMetaData", FormMetaData.class);
    }

    @Bean
    public DynamoDbTable<CoreMetaData> coreMetaDataTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        return retrieveTable(enhancedDbClient, "CoreMetaData", CoreMetaData.class);
    }

    @Bean
    public DynamoDbTable<EvidenceMetaData> evidenceMetaDataTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        return retrieveTable(enhancedDbClient, "EvidenceMetaData", EvidenceMetaData.class);
    }

    @Bean
    public DynamoDbTable<ValidationStatus> validationStatusTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        return retrieveTable(enhancedDbClient, "ValidationStatus", ValidationStatus.class);

    }

    @Bean
    public DynamoDbTable<Audit> auditTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        return retrieveTable(enhancedDbClient, "Audit", Audit.class);
    }

    @Bean
    public DynamoDbTable<NameExtract> nameExtractTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        return retrieveTable(enhancedDbClient, "NameExtract", NameExtract.class);
    }

    @Bean
    public DynamoDbTable<AddressExtract> addressExtractTable(DynamoDbEnhancedClient enhancedDbClient,
                    DynamoDbClient dynamoDbClient) {
        return retrieveTable(enhancedDbClient, "AddressExtract", AddressExtract.class);
    }


    private <T> DynamoDbTable<T> retrieveTable(DynamoDbEnhancedClient enhancedDbClient, String tableName,
            Class<T> entityClass) {
        return enhancedDbClient.table("%s-%s".formatted(tablePrefix, tableName), TableSchema.fromBean(entityClass));
    }

}
