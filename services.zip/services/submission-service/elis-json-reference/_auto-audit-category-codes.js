/**
 * README:
 *
 * This automated script will audit and remediate our form metadata files
 * against the ELIS content category codes (given in a JSON file) and ensure that:
 *
 * - All contentCategoryCode(s) used actually exist in ELIS
 * - All evidenceType id's match a contentCategoryDescription
 * - If a contentCategoryCode is used for an evidenceType,
 *   then the id matches it's corresponding contentCategoryDescription
 * - No duplicate content categories are used in the same evidenceTypes list
 *
 * USAGE:
 * cd csai-pdf-intake/services/submission-service/_db_metadata
 * node _auto-audit-category-codes.js
*/

const fs = require('fs').promises;
const path = require('path')

const TARGET_DIRECTORY = 'forms';
const CATEGORY_CODES_FILE_PATH = 'elis-content-category-codes.json';

async function loadCategoriesMaps(categoryCodesPath) {
  const rawCategories = await fs.readFile(categoryCodesPath, 'utf8');
  const categories = JSON.parse(rawCategories);

  const codeToDescMap = new Map();
  const descToCodeMap = new Map();

  categories.forEach(category => {
    const codeStr = String(category.contentCategoryCode);
    const descStr = category.contentCategoryDescription;
    codeToDescMap.set(codeStr,descStr);
    descToCodeMap.set(descStr,codeStr);
  });

  return { categories, codeToDescMap, descToCodeMap };

}

function auditAndEditEvidenceType(evidenceType, codeToDescMap, descToCodeMap, uplicateEvidenceTypeIdLookup){
  if(!(evidenceType && evidenceType.M))
  {
    return;
  }

  let codeStr = null;
  let idStr = null;
  const evidenceTypeDoc = evidenceType.M;
  if(evidenceTypeDoc.contentCategoryCode && (evidenceTypeDoc.contentCategoryCode.S || evidenceTypeDoc.contentCategoryCode.N)) {
    codeStr = String(evidenceTypeDoc.contentCategoryCode.S || evidenceTypeDoc.contentCategoryCode.N)
  }
  if(evidenceTypeDoc.id && evidenceTypeDoc.id.S) {
    idStr = String(evidenceTypeDoc.id.S)
  }

  if(codeStr && !codeToDescMap.has(codeStr))
  {
    evidenceTypeDoc.contentCategoryCode = { S: `NO_SUCH_CATEGORY_CODE( ${codeStr} )` };
  }

  if(idStr && !descToCodeMap.has(idStr))
  {
    evidenceTypeDoc.id = { S: `NO_SUCH_CATEGORY_DESCRIPTION( ${idStr} )` };
  }

  if(codeStr && descToCodeMap.get(idStr))
  {
    evidenceTypeDoc.contentCategoryCode = { N: `${descToCodeMap.get(idStr)}` };
  }

  const updatedEvidenceTypeId = evidenceTypeDoc.id.S;
  if(uplicateEvidenceTypeIdLookup.has(updatedEvidenceTypeId)) {
    evidenceTypeDoc.id = { S: `DUPLICATE_ID_NOT_ALLOWED( ${updatedEvidenceTypeId} )` };
  }
  uplicateEvidenceTypeIdLookup.set(updatedEvidenceTypeId, true);


}

function traverseAndAudit(documentNode, codeToDescMap, descToCodeMap) {

  if(documentNode === null || typeof documentNode !== 'object')
  {
    return false;
  }
  if(Array.isArray(documentNode))
  {
    for(const arrayItem of documentNode) {
      traverseAndAudit(arrayItem, codeToDescMap, descToCodeMap);
    }
  }
  else
  {
    for(const key in documentNode) {
      if(Object.prototype.hasOwnProperty.call(documentNode, key))
      {
        if(key == 'evidenceTypes' && documentNode[key] && Array.isArray(documentNode[key].L))
        {
          const evidenceTypesList = documentNode[key].L;
          const duplicateEvidenceTypeIdLookup = new Map();
          for(evidenceType of evidenceTypesList) {
            auditAndEditEvidenceType(evidenceType, codeToDescMap, descToCodeMap, duplicateEvidenceTypeIdLookup);
          }
        }
        else
        {
          traverseAndAudit(documentNode[key], codeToDescMap, descToCodeMap);
        }
      }
    }
  }
}

async function auditFormMetadataFile(filePath, codeToDescMap, descToCodeMap) {

  console.log(filePath);
  const fileData = await fs.readFile(filePath);
  const jsonDocument = JSON.parse(fileData);

  traverseAndAudit(jsonDocument, codeToDescMap, descToCodeMap);

  const updatedJsonData = JSON.stringify(jsonDocument, null, 2);
  await fs.writeFile(filePath, updatedJsonData, 'utf-8');


}

async function auditCategoryCodesInFormMetadata(targetDirectory, categoryCodesPath) {
  try {
    const { categories, codeToDescMap, descToCodeMap } = await loadCategoriesMaps(categoryCodesPath);
    const formFiles = await fs.readdir(targetDirectory);

    for(formFile of formFiles) {
      const fullFilePath = path.join(targetDirectory, formFile);
      await auditFormMetadataFile(fullFilePath, codeToDescMap, descToCodeMap);
    }

   //const fullFilePath = path.join(targetDirectory, "i-485a-form.json");
   //await auditFormMetadataFile(fullFilePath, codeToDescMap, descToCodeMap);



  }
  catch(globalError)
  {
    console.error(globalError)
    process.exit(1)
  }
}

auditCategoryCodesInFormMetadata(path.join(__dirname, TARGET_DIRECTORY), path.join(__dirname, CATEGORY_CODES_FILE_PATH));