#!/bin/bash
echo "============= SEEDING METADATA ============="
for file in /opt/_db_metadata/**/*.json; do
    db_seed_script.sh -i "$file" -e http://localhost:4566
done
echo "============= SEEDING METADATA COMPLETE ============="