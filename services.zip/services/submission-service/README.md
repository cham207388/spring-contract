# Documentation

When this API is running ()`gradle :submission-service:clean :submission-service:build :submission-service:bR`), navigate to http://localhost:8080/swagger-ui.html