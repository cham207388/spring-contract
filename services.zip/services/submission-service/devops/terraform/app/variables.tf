variable "fullnameOverride" { default = "changeme" }
variable "nameOverride" { default = "changeme" }
variable "s3_buckets_form" {}
variable "s3_buckets_evidence" {}
variable "s3_buckets_backup" {}
variable "lockbox_gw_url" { default = "changeme" }
variable "downloader_url" { default = "changeme" }
variable "downloader_urls" {
  type = map(string)
  default = {
    "dev"     = "https://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov",
    "sint"    = "https://uscis-nonprod.api-nonprod.uscis.dhs.gov/csai-intake-downloader",
    "preprod" = "https://uscis-int.api.uscis.dhs.gov/csai-intake-downloader",
    "prod"    = "https://uscis-prod.api.uscis.dhs.gov/csai-intake-downloader"
  }
}

variable "old_downloader_urls" {
  type = map(string)
  default = {
    "dev"     = "https://csai-pdf-intake-s3-dev.apps.k8s-nonprod.uscis.dhs.gov",
    "sint"    = "https://csai-pdf-intake-s3-sint.apps.k8s-nonprod.uscis.dhs.gov",
    "preprod" = "https://csai-pdf-intake-s3-preprod.apps.k8s.uscis.dhs.gov",
    "prod"    = "https://csai-pdf-intake-s3-prod.apps.k8s.uscis.dhs.gov"
  }
}

variable "peeps_url" { default = "changeme" }
variable "peeps_urls" {
  type = map(string)
  default = {
    "dev"     = "https://development.peeps-nonprod.my.uscis.dhs.gov/peeps",
    "sint"    = "https://qa.peeps-nonprod.my.uscis.dhs.gov/peeps",
    "preprod" = "https://preprod.peeps-prod.my.uscis.dhs.gov/peeps",
    "prod"    = "https://production.peeps-prod.my.uscis.dhs.gov/peeps"
  }    
}

variable "usergroupservice_url" { default = "changeme" }
variable "usergroupservice_urls" {
  type = map(string)
  default = {
    "dev"     = "https://development.usergroupservice-nonprod.my.uscis.dhs.gov/user-group-service",
    "sint"    = "https://qa.usergroupservice-nonprod.my.uscis.dhs.gov/user-group-service",
    "preprod" = "https://preprod.usergroupservice-prod.my.uscis.dhs.gov/user-group-service",
    "prod"    = "https://production.usergroupservice-prod.my.uscis.dhs.gov/user-group-service"
  }    
}

variable "accountsdata_url" { default = "changeme" }
variable "accountsdata_urls" {
  type = map(string)
  default = {
    "dev"     = "https://development.accountsdata-nonprod.my.uscis.dhs.gov/accounts-data",
    "sint"    = "https://qa.accountsdata-nonprod.my.uscis.dhs.gov/accounts-data",
    "preprod" = "https://preprod.accountsdata-prod.my.uscis.dhs.gov/accounts-data",
    "prod"    = "https://production.accountsdata-prod.my.uscis.dhs.gov/accounts-data"
  }    
}

variable "sqs_validation_queueUrl" {}
variable "sqs_validation_field_queueUrl" {}
variable "sqs_elis_validation_request_queueUrl" {}
variable "sqs_elis_validation_response_queueUrl" {}
variable "sqs_elis_evidence_validation_request_queueUrl" {}
variable "sqs_elis_evidence_validation_response_queueUrl" {}
variable "sqs_elis_esign_request_queueUrl" {}
variable "sqs_validation_name_queueUrl" {}
variable "sqs_validation_address_queueUrl" {}
variable "sqs_validation_eligibility_queueUrl" {}
variable "sqs_validation_client_name_email_queueUrl" {}
variable "sqs_validation_attorney_name_queueUrl" {}
variable "sqs_validation_person_queueUrl" {}
variable "sqs_i912_validation_queue_url" {}
variable "values_environment" {}
variable "kubernetes_namespace" { default = "changeme" }
variable "helm_chart_version" { default = "changeme" }
variable "chart_repository" { default = "changeme" }
variable "image_tag" { default = "changeme" }
variable "chart_path_or_name" { default = "digital-intake-web" }
variable "eks_domain" { default = "changeme" }
variable "helm_history_max" { default = 3 }
variable "elisApiVolumeName" { default = "changeme" }
variable "elisApiSecretName" { default = "changeme" }
variable "elisApiEncodedJks" { default = "changeme" }
variable "jwt_public_key" {}
variable "tags" {}
variable "eks-domain" {}
variable "helm_values_path" {}
variable "peeps_username" {}
variable "peeps_password" {}
variable "usergroupservice_username" {}
variable "usergroupservice_password" {}
variable "accountsdata_username" {
    default = ""
}
variable "accountsdata_password" {
    default = ""
}
variable "cacheupdate_username" {}
variable "cacheupdate_password" {}
variable "draftbenefits_username" {}
variable "draftbenefits_password" {}
variable "payment_service_url" {}
variable "new_relic_license_key" {}
variable "eks_context" {}
variable "lockboxClientRetries" { default = 2 }
variable "lockboxClientRetryDurationSeconds" { default = 2 }
variable "lockboxClientTimeoutSeconds" { default = 120 }
variable "sqs_replay_submission_queue_url" {}
variable "postgres_url" {}
variable "postgres_password" {}