
data "aws_caller_identity" "current" {}

provider "kubernetes" {
  config_path    = "~/.kube/config"
  config_context = var.eks_context
}
// TODOO to disable authentication in environments
variable "core_oauth_enforce" {
  type = map(bool)
  default = {
    dev     = false
    sint    = true
    preprod = true
    prod    = true
  }
}

resource "helm_release" "pdfi-ss" {
  namespace   = var.kubernetes_namespace
  name        = var.fullnameOverride
  repository  = var.chart_repository
  chart       = var.chart_path_or_name
  version     = var.helm_chart_version
  max_history = var.helm_history_max
  atomic = true
  timeout = 1200

  values = [
    file(var.helm_values_path)
  ]

  set {
    name  = "fullnameOverride"
    value = var.fullnameOverride
  }
  set {
    name  = "nameOverride"
    value = var.fullnameOverride
  }
  set {
    name  = "image.tag"
    value = var.image_tag
  }

  set {
    name  = "s3_buckets_form"
    value = var.s3_buckets_form
  }
  set {
    name  = "s3_buckets_evidence"
    value = var.s3_buckets_evidence
  }
  set {
    name = "s3_buckets_backup"
    value = var.s3_buckets_backup
  }
  set {
    name  = "table_prefix"
    value = terraform.workspace
  }
  set {
    name  = "lockbox_gw_url"
    value = var.lockbox_gw_url
  }
  set {
    name  = "downloader_url"
    value = lookup(var.downloader_urls, terraform.workspace, var.downloader_url)
  }
  set {
    name  = "old_downloader_url"
    value = lookup(var.old_downloader_urls, terraform.workspace, var.downloader_url)
  }
  set {
    name  = "sqs_validation_queueUrl"
    value = var.sqs_validation_queueUrl
  }
  set {
    name  = "sqs_validation_field_queueUrl"
    value = var.sqs_validation_field_queueUrl
  }
  set {
    name  = "sqs_elis_validation_request_queueUrl"
    value = var.sqs_elis_validation_request_queueUrl
  }
  set {
    name  = "sqs_elis_validation_response_queueUrl"
    value = var.sqs_elis_validation_response_queueUrl
  }
  set {
    name  = "sqs_elis_evidence_validation_request_queueUrl"
    value = var.sqs_elis_evidence_validation_request_queueUrl
  }
  set {
    name  = "sqs_elis_evidence_validation_response_queueUrl"
    value = var.sqs_elis_evidence_validation_response_queueUrl
  }
  set {
    name  = "sqs_elis_esign_request_queueUrl"
    value = var.sqs_elis_esign_request_queueUrl
  }
  set {
    name  = "sqs_validation_name_queueUrl"
    value = var.sqs_validation_name_queueUrl
  }
  set {
    name  = "sqs_validation_address_queueUrl"
    value = var.sqs_validation_address_queueUrl
  }
  set {
    name  = "sqs_validation_attorney_name_queueUrl"
    value = var.sqs_validation_attorney_name_queueUrl
  }
  set {
    name  = "sqs_validation_client_name_email_queueUrl"
    value = var.sqs_validation_client_name_email_queueUrl
  }
  set {
    name  = "sqs_validation_eligibility_queueUrl"
    value = var.sqs_validation_eligibility_queueUrl
  }
  set {
    name  = "sqs_validation_person_queueUrl"
    value = var.sqs_validation_person_queueUrl
  }
  set {
    name  = "sqs_i912_validation_queue_url"
    value = var.sqs_i912_validation_queue_url
  }
  set {
    name  = "payment_service_url"
    value = var.payment_service_url
  }

  // in values file and should be set?
  # set {
  #   name  = "s3_form_upload_queue_url"
  #   value = var.s3_form_upload_queue_url
  # }

  set {
    name  = "elisApiEncodedJks"
    value = var.elisApiEncodedJks
  }
  set {
    name  = "elisApiSecretName"
    value = "elis-api-tls-${terraform.workspace}"
  }

  set {
    name  = "elisApiVolumeName"
    value = "elis-api-tls-${terraform.workspace}"
  }

  set {
    name  = "enforce_oauth"
    value = lookup(var.core_oauth_enforce, terraform.workspace, false)
  }

  set {
    name  = "jwt_public_key"
    value = var.jwt_public_key
  }

  set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com\\/role-arn"
    value = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/pdfi-ss-role-${terraform.workspace}"
  }

  set {
    name  = "ingress.hosts[0].host"
    value = "${var.fullnameOverride}.${var.eks-domain},ingress.hosts[0].paths[0].path=/,ingress.hosts[0].paths[0].pathType=ImplementationSpecific"
  }

  set {
    name  = "peeps_url"
    value = lookup(var.peeps_urls, terraform.workspace, var.peeps_url)
  }

  set {
    name  = "peeps_username"
    value = var.peeps_username
  }

  set {
    name  = "peeps_password"
    value = var.peeps_password
  }

  set {
    name  = "usergroupservice_url"
    value = lookup(var.usergroupservice_urls, terraform.workspace, var.usergroupservice_url)
  }

  set {
    name  = "usergroupservice_username"
    value = var.usergroupservice_username
  }

  set {
    name  = "usergroupservice_password"
    value = var.usergroupservice_password
  }

  set {
    name  = "accountsdata_url"
    value = lookup(var.accountsdata_urls, terraform.workspace, var.accountsdata_url)
  }

  set {
    name  = "accountsdata_username"
    value = var.accountsdata_username
  }

  set {
    name  = "accountsdata_password"
    value = var.accountsdata_password
  }

  set {
    name  = "cacheupdate_username"
    value = var.cacheupdate_username
  }

  set {
    name  = "cacheupdate_password"
    value = var.cacheupdate_password
  }

  set {
    name  = "draftbenefits_username"
    value = var.draftbenefits_username
  }

  set {
    name  = "draftbenefits_password"
    value = var.draftbenefits_password
  }

  set {
    name  = "new_relic_license_key"
    value = var.new_relic_license_key
  }
  set {
    name  = "sqs_replay_submission_queue_url"
    value = var.sqs_replay_submission_queue_url
  }

  set {
    name  = "appvars.spring_datasource_url"
    value = "jdbc:postgresql://${var.postgres_url}/postgres"
  }

  set {
    name  = "appvars.spring_datasource_password"
    value = var.postgres_password
  }
}

data "kubernetes_service" "ingress_svc" {
  metadata {
    name      = "csai-intake-submission-${terraform.workspace}"
    namespace = var.kubernetes_namespace
  }
}

output "url" {
  value = "${var.fullnameOverride}.${var.eks-domain}"
}

output "validation_status_table_arn" {
  value = aws_dynamodb_table.validation_status_table.arn
}

output "client_information_table_arn" {
    value = aws_dynamodb_table.client_information_table.arn
}
# output "url" {
#   value = data.kubernetes_service.ingress_svc.status.0.load_balancer.0.ingress[0].hostname
# }
