locals {
  deletion_protection = {
    "prod" : "true",
    "preprod" : "true"
  }
}

resource "aws_dynamodb_table" "validation_status_table" {
  name                        = "${terraform.workspace}-ValidationStatus"
  hash_key                    = "formId"
  range_key                   = "validator"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  attribute {
    name = "formId"
    type = "S"
  }

  attribute {
    name = "validator"
    type = "S"
  }

  tags = var.tags
}

resource "aws_dynamodb_table" "client_information_table" {
  name                        = "${terraform.workspace}-ClientInformation"
  hash_key                    = "submissionId"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

global_secondary_index {
    name            = "by_clientId"
    hash_key        = "clientId"
    projection_type = "ALL"
  }
  attribute {
    name = "submissionId"
    type = "S"
  }

  attribute {
    name = "clientId"
    type = "S"
  }

  tags = var.tags
}
