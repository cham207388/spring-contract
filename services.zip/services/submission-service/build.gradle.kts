import com.bmuschko.gradle.docker.tasks.image.DockerBuildImage

plugins {
    java
    jacoco
    `maven-publish`
    eclipse
    alias(libs.plugins.spring.boot)
    alias(libs.plugins.sonarqube)
    alias(libs.plugins.gatling)
    alias(libs.plugins.restdocs.api)
    alias(libs.plugins.swagger.core)
    alias(libs.plugins.spring.cloud.contract)
    // alias(libs.plugins.jib)
    alias(libs.plugins.swagger.hidetake) // Verify if we need this
    alias(libs.plugins.undercouch)       // Verify if we need this
    alias(libs.plugins.docker)
    alias(libs.plugins.pdfi.java.conventions)
}

val commitTag: String = System.getenv("COMMIT_HASH") ?: "latest"
val stubVersion = "0.0.1-RELEASE"

group = "gov.dhs.uscis"
version = "0.0.1-SNAPSHOT"

val asciidoctorExt: Configuration by configurations.creating

configurations {
    compileOnly {
        extendsFrom(configurations.annotationProcessor.get())
    }
}

docker {
    springBootApplication {
        baseImage.set("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/csai-java-base-image:21.0.8_11-jre-alpine")
        images.add("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/submission-service:$commitTag")
        maintainer.set("csai-dev-team")
        mainClassName.set("gov.dhs.uscis.submissionservice.SubmissionServiceApplication")
        jvmArgs.set(listOf("-XX:+UseContainerSupport", "-XX:MaxRAMPercentage=90", "-javaagent:/opt/newrelic.jar"))
    }
}

tasks.dockerCreateDockerfile {
    instruction("COPY --chown=apps:apps ./resources/newrelic.yaml /opt/newrelic.yml")
    instruction("EXPOSE 8080")
    instruction("USER apps")
}

tasks.named<DockerBuildImage>("dockerBuildImage") {
    platform.set("linux/amd64")
    pull.set(true)
}

tasks.build {
    dependsOn(tasks.dockerBuildImage)
}

publishing {
    publications {
        create<MavenPublication>("stubs") {
            artifactId = project.name
            version = stubVersion

            artifact(file("${layout.buildDirectory.get()}/libs/${project.name}-$stubVersion-stubs.jar")) {
                classifier = "stubs"
            }
        }
    }
    repositories {
        mavenLocal()
    }
}

contracts {
    baseClassForTests.set("gov.dhs.uscis.submissionservice.BaseContractTest")
}

springBoot {
    mainClass.set("gov.dhs.uscis.submissionservice.SubmissionServiceApplication")
}

dependencies {
    implementation(enforcedPlatform(libs.log4j.bom))

    val springBootDependencyBom = platform(libs.spring.boot.dependencies)
    implementation(platform(libs.aws.bom))
    
    implementation(springBootDependencyBom)
    testImplementation(springBootDependencyBom)
    compileOnly(springBootDependencyBom)
    testCompileOnly(springBootDependencyBom)
    annotationProcessor(springBootDependencyBom)
    testAnnotationProcessor(springBootDependencyBom)
    
    constraints{
        implementation(libs.spring.core) {
            because("CVE-2025-41249")
        }
        implementation(libs.commons.lang3) {
            because("CVE-2025-48924")
        }
        implementation(libs.spring.web) {
            because("CVE-2025-41234")
        }
        implementation(libs.spring.webmvc) {
            because("CVE-2025-41242")
        }
        implementation(libs.spring.jms) {
            because("Ensure consistent version for JMS messaging")
        }
        implementation(libs.fasterxml.jackson.core) {
            because("GHSA-72hv-8253-57qq")
        }
        implementation(libs.netty.codec.http) {
            because("CVE-2026-33870")
        }
        implementation(libs.netty.codec.http2) {
            because("CVE-2026-33871")
        }
        implementation(libs.tomcat.embed.core) {
            because("CVE-2026-34487")
        }
    }
    
    implementation(libs.spring.boot.starter.actuator) {
        exclude(group = "ch.qos.logback", module = "logback-classic")
        exclude(group = "ch.qos.logback", module = "logback-core")
    }
    implementation(libs.spring.boot.starter.webflux)
    implementation(libs.spring.boot.starter.web)
    implementation(libs.spring.boot.starter.data.jpa)
    implementation(libs.spring.jms)
    implementation(libs.spring.boot.starter.aop)
    implementation(libs.spring.boot.starter.oauth2.resource.server)
    implementation(libs.spring.boot.starter.validation)
    implementation(libs.logback.encoder)

    implementation(libs.pdfbox)

    implementation(libs.aws.dynamodb.enhanced) {
        exclude(group = "ch.qos.logback", module = "logback-classic")
        exclude(group = "ch.qos.logback", module = "logback-core")
    }

    implementation(libs.aws.s3)
    implementation(libs.aws.sns)
    implementation(libs.aws.sts)
    implementation(libs.aws.eventbridge)
    implementation(libs.aws.cloudwatch)
    
    implementation(libs.commons.codec)

    implementation(libs.amazonaws.lambda.events)
    implementation(libs.amazonaws.lambda.serialization)
    implementation(libs.amazonaws.sqs.messaging)

    implementation(libs.guava)
    implementation(libs.bouncycastle)
    implementation(libs.springdoc.openapi)
    implementation(libs.javax.jms)
    implementation(libs.micrometer)
    implementation(libs.postgresql)

    compileOnly(libs.lombok)
    testCompileOnly(libs.lombok)
    annotationProcessor(libs.lombok)
    testAnnotationProcessor(libs.lombok)
    annotationProcessor(libs.spring.boot.configuration.processor)
    
    asciidoctorExt(libs.spring.restdocs.asciidoctor)
    testImplementation(libs.spring.boot.starter.test)
    testImplementation(libs.spring.security.test)
    testImplementation(libs.instancio)
    testImplementation(libs.spring.restdocs.mockmvc)
    testImplementation(libs.spring.restdocs.webtestclient)
    testImplementation(libs.reactor.test)
    testImplementation(libs.test.containers)
    testImplementation(libs.test.containers.localstack)
    testImplementation(libs.test.containers.jupiter)
    testImplementation(libs.restdocs.api.spec)
    testImplementation(libs.squareup.okhttp3)
    testImplementation(libs.squareup.okhttp3.mockwebserver)
    testImplementation(libs.awaitility)
    testImplementation(libs.spring.cloud.starter.stub.runner)
    testImplementation(libs.spring.cloud.starter.verifier)

    testImplementation(libs.h2)
    "swaggerUI"("org.webjars:swagger-ui:5.13.0")
}

val jacocoExcludes = listOf(
    "gov/dhs/uscis/submissionservice/constants/**",
    "gov/dhs/uscis/submissionservice/components/aspects/**",
    "gov/dhs/uscis/submissionservice/exception/**",
    "gov/dhs/uscis/submissionservice/entities/**",
    "gov/dhs/uscis/submissionservice/models/**",
    "gov/dhs/uscis/submissionservice/configs/**"
)

jacoco {
    toolVersion = libs.versions.jacoco.get()
}

tasks.withType<JacocoReportBase> {
    classDirectories.setFrom(files(classDirectories.files.map {
        fileTree(it) { exclude(jacocoExcludes) }
    }))
}

tasks.jacocoTestReport {
    dependsOn(tasks.test)
    reports {
        xml.required.set(true)
        html.required.set(true)
    }
}

tasks.jacocoTestCoverageVerification {
    dependsOn(tasks.test)
    violationRules {
        rule {
            limit {
                minimum = 0.8.toBigDecimal()
            }
        }
    }
}

tasks.check { dependsOn(tasks.jacocoTestCoverageVerification) }

val snippetsDir by extra { file("build/generated-snippets") }

tasks.test {
    outputs.dir(snippetsDir)
    useJUnitPlatform()
    finalizedBy(tasks.jacocoTestReport)
    testLogging {
        events("PASSED", "SKIPPED", "FAILED", "STANDARD_OUT", "STANDARD_ERROR")
    }
}

tasks.named("sonar") {
    dependsOn(tasks.jacocoTestCoverageVerification)
}

openapi3 {
    setServer("https://localhost:8443/pdf-intake")
    title = "CSAI-Submission-Service"
    description = "An API handling the uploading of forms and supporting evidence for visa applicants"
    version = "0.1.0"
    format = "yaml"
}

swaggerSources {
    create("csai-pdf-intake").apply {
        setInputFile(file("${layout.buildDirectory.get()}/api-spec/openapi3.yaml"))
    }
}

tasks.register<Delete>("deleteOldSwaggerFiles") {
    delete("src/main/resources/public")
}

tasks.clean {
    dependsOn("deleteOldSwaggerFiles")
}

val copySwaggerFiles = tasks.register<Copy>("copySwaggerFiles") {
    group = "Documentation"
    description = "Copies Swagger files over to web server static directory"
    dependsOn("generateSwaggerUI")
    from("${layout.buildDirectory.get()}/swagger-ui-csai-pdf-intake")
    into("src/main/resources/public")
    into("${layout.buildDirectory.get()}/resources/main/public")
}

tasks.register("generateApiDocumentation") {
    dependsOn("generateSwaggerUI", "copySwaggerFiles")
    tasks.named("copySwaggerFiles") { mustRunAfter("generateSwaggerUI") }
}

tasks.named("generateSwaggerUI") {
    dependsOn("openapi3")
    mustRunAfter("openapi3")
    finalizedBy(copySwaggerFiles)
}

listOf("build", "jacocoTestReport", "jar", "bootJar", "resolveMainClassName").forEach { taskName ->
    tasks.named(taskName) { mustRunAfter(copySwaggerFiles) }
}

configurations {
    getByName("gatlingImplementation").extendsFrom(configurations.testImplementation.get())
    getByName("gatlingRuntimeOnly").extendsFrom(configurations.testRuntimeOnly.get())
}

val renameStubArtifact = tasks.register("renameStubArtifact") {
    val sourceFile = file("${layout.buildDirectory.get()}/libs/${project.name}-$version-stubs.jar")
    val targetFile = file("${layout.buildDirectory.get()}/libs/${project.name}-$stubVersion-stubs.jar")

    inputs.file(sourceFile)
    outputs.file(targetFile)

    doLast {
        if (sourceFile.exists()) {
            targetFile.parentFile.mkdirs()
            sourceFile.renameTo(targetFile)
            println("Renamed artifact created: $targetFile")
        }
    }
}

tasks.named("publishStubsPublicationToMavenLocalRepository") {
    dependsOn(renameStubArtifact)
}