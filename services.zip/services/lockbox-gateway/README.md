# Run locally:

1. At root of repository, run docker-compose up -d
2. In this directory, run `SPRING_PROFILES_ACTIVE=local ./gradlew bR`