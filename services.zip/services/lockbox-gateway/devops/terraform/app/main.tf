
data "aws_caller_identity" "current" {}

provider "kubernetes" {
  config_path    = "~/.kube/config"
  config_context =  var.eks_context
}

locals {
  workspace_fmt = replace(terraform.workspace, "-", "_")
}

resource "helm_release" "pdfi-lbg" {
  namespace  = var.kubernetes_namespace
  name       = var.fullnameOverride
  repository = var.chart_repository
  chart      = var.chart_path_or_name
  version    = var.helm_chart_version
  max_history = var.helm_history_max
  atomic = true
  timeout = 1200

  values = [
    file(var.helm_values_path)
  ]

  set {
    name  = "fullnameOverride"
    value = var.fullnameOverride
  }

  set {
    name  = "nameOverride"
    value = var.fullnameOverride
  }

  set {
    name  = "appvars.activemq.keyStoreValue"
    value = var.amqKeystore
  }

  set {
    name  = "appvars.activemq.keyStorePassword"
    value = var.amqKeystorePassword
  }

  set {
    name  = "appvars.activemq.trustStorePassword"
    value = var.amqTrustStorePassword
  }

  set {
    name  = "appvars.activemq.broker_url"
    value = var.brokerUrl
  }
   set {
    name  = "appvars.activemq.secondary_url"
    value = var.secondaryBrokerUrl
  }

   set {
    name  = "appvars.activemq.ternary_url"
    value = var.ternaryBrokerUrl
  }

  set {
    name  = "appvars.activemq.password"
    value = var.amqPassword
  }

  set {
    name  = "appvars.dynamodb.table_prefix"
    value = terraform.workspace
  }
  set {
    name  = "image.tag"
    value = var.image_tag
  }

  set {
    name = "appvars.submissionservice_url"
    value = var.submission_service_url
  }

  set {
    name = "appvars.paymentservice_url"
    value = var.paymentservice_url
  }

  set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com\\/role-arn"
    value = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/pdfi-lbg-role-${terraform.workspace}"
  }

  set {
    name  = "ingress.hosts[0].host"
    value = "${var.fullnameOverride}.${var.eks_domain},ingress.hosts[0].paths[0].path=/,ingress.hosts[0].paths[0].pathType=ImplementationSpecific"
  }
  set {
    name  = "new_relic_license_key"
    value = var.new_relic_license_key
  }

  set {
    name = "application.queues.lockbox.payments.request"
    value = "${var.amqQueuePrefix}US.DHS.USCIS.INTAKE.LOCKBOX.PaymentRequest.v1"
  }

  set {
    name = "application.queues.lockbox.payments.response"
    value = "${var.amqQueuePrefix}US.DHS.USCIS.INTAKE.LOCKBOX.PaymentResponse.v1"
  }

  set {
    name = "jms.intake.lockbox.manifest.queue"
    value = "${var.amqQueuePrefix}US.DHS.USCIS.INTAKE.LOCKBOX.ManifestSubmission.v1"
  }

  set {
    name = "jms.intake.lockbox.manifest.response.queue"
    value = "${var.amqQueuePrefix}US.DHS.USCIS.INTAKE.LOCKBOX.ManifestResponse.v1"
  }

  set {
    name = "jms.intake.lockbox.submission.update.queue"
    value = "${var.amqQueuePrefix}US.DHS.USCIS.INTAKE.LOCKBOX.SubmissionUpdate.v1"
  }

  set {
    name = "jms.intake.lockbox.submission.response.queue"
    value = "${var.amqQueuePrefix}US.DHS.USCIS.INTAKE.LOCKBOX.SubmissionResponse.v1"
  }

}

data "kubernetes_service" "ingress_svc" {
  metadata {
    name = "csai-intake-gateway-${terraform.workspace}"
    namespace = var.kubernetes_namespace
  }
}

output "url" {
  value = "${var.fullnameOverride}.${var.eks_domain}"
}
# output "url" {
#   value = data.kubernetes_service.ingress_svc.status.0.load_balancer.0.ingress[0].hostname
# }

resource "aws_cloudwatch_metric_alarm" "insufficient_accepted_payments" {
  alarm_name          = "Insufficient_Accepted_Payments"
  comparison_operator = "LessThanThreshold"
  evaluation_periods  = 1
  metric_name         = "${terraform.workspace}_AcceptedPayments"
  namespace           = "PDFI/Payments"
  period              = 12*60
  statistic           = "SampleCount"
  threshold           = 1
  alarm_description   = "Number of Payments Processed"
  actions_enabled     = "true"
  alarm_actions       = [aws_sns_topic.accepted_payments_alert_topic.arn]
  ok_actions          = [aws_sns_topic.accepted_payments_alert_topic.arn]
  dimensions = {
    Transactions="AcceptedPayments"
  }
}

resource "aws_cloudwatch_metric_alarm" "increase_payment_errors" {
  alarm_name          = "PDFI_payment_error"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  metric_name         = "${terraform.workspace}_PaymentProcessingError"
  namespace           = "PDFI/Payments"
  period              = 10
  statistic           = "Sum"
  threshold           = 5
  alarm_description   = "Number of Payments Errors"
  actions_enabled     = "true"
  alarm_actions       = [aws_sns_topic.payment_error_alert_topic.arn]
  ok_actions          = [aws_sns_topic.payment_error_alert_topic.arn]
  dimensions = {
    Transactions="PaymentProcessingError"
  }
}

resource "aws_cloudwatch_metric_alarm" "pending_submissions" {
  alarm_name                = "PDFI_pending_submissions"
  comparison_operator       = "GreaterThanThreshold"
  evaluation_periods        = 1
  threshold                 = 100
  alarm_description         = "Pending submissions are not being processed over a 12 hour window"
  insufficient_data_actions = []

  metric_query {
    id          = "${local.workspace_fmt}_pending_outcome"
    expression  = "${local.workspace_fmt}_completed-${local.workspace_fmt}_pending"
    label       = "Pending Submissions"
    return_data = "true"
  }

  metric_query {
    id = "${local.workspace_fmt}_pending"

    metric {
      metric_name = "${terraform.workspace}_PendingSubmission"
      namespace   = "PDFI/Submissions"
      period      = 12*60
      stat        = "Sum"
      unit        = "Count"

      dimensions = {
        Transactions = "RECEIVED"
      }
    }
  }

  metric_query {
    id = "${local.workspace_fmt}_completed"

    metric {
      metric_name = "${local.workspace_fmt}_SUBMISSION_COMPLETED"
      namespace   = "PDFI/Submissions"
      period      = 12*60
      stat        = "Sum"
      unit        = "Count"

      dimensions = {
        Transactions = "COMPLETED"
      }
    }
  }
}

resource "aws_sns_topic" "accepted_payments_alert_topic" {
  name = "${terraform.workspace}_payments_accepted_issue_notification"
}

resource "aws_sns_topic" "payment_error_alert_topic" {
  name = "${terraform.workspace}_payment_error_issue_notification"
}

resource "aws_sns_topic" "pending_submissions_alert_topic" {
  name = "${terraform.workspace}_pending_submissions_issue_notification"
}

resource "aws_sns_topic_subscription" "accepted_payments_email-sub" {
  topic_arn = aws_sns_topic.accepted_payments_alert_topic.arn
  protocol  = "email"
  endpoint  = "csai@uscis.dhs.gov"
}

resource "aws_sns_topic_subscription" "accepted_payments_email-odwayne" {
  topic_arn = aws_sns_topic.accepted_payments_alert_topic.arn
  protocol  = "email"
  endpoint  = "o'dwayne.s.irving@uscis.dhs.gov"
  endpoint_auto_confirms = true
}

resource "aws_sns_topic_subscription" "accepted_payments_email-carlyle" {
  topic_arn = aws_sns_topic.accepted_payments_alert_topic.arn
  protocol  = "email"
  endpoint  = "carlyle.davis@uscis.dhs.gov"
  endpoint_auto_confirms = true
}

resource "aws_sns_topic_subscription" "accepted_payments_email-sj" {
  count = terraform.workspace == "prod" ? 1 : 0
  topic_arn = aws_sns_topic.accepted_payments_alert_topic.arn
  protocol  = "email"
  endpoint  = "sammijo.l.hruby@uscis.dhs.gov"
  endpoint_auto_confirms = true
}

resource "aws_sns_topic_subscription" "accepted_payments_email-lynne" {
  count = terraform.workspace == "prod" ? 1 : 0
  topic_arn = aws_sns_topic.accepted_payments_alert_topic.arn
  protocol  = "email"
  endpoint  = "lynne.a.shaw@uscis.dhs.gov"
  endpoint_auto_confirms = true
}

resource "aws_sns_topic_subscription" "accepted_payments_email-chris" {
  count = terraform.workspace == "prod" ? 1 : 0
  topic_arn = aws_sns_topic.accepted_payments_alert_topic.arn
  protocol  = "email"
  endpoint  = "christopher.w.foley@uscis.dhs.gov"
  endpoint_auto_confirms = true
}

resource "aws_sns_topic_subscription" "accepted_payments_email-stacey" {
  count = terraform.workspace == "prod" ? 1 : 0
  topic_arn = aws_sns_topic.accepted_payments_alert_topic.arn
  protocol  = "email"
  endpoint  = "stacey.l.proctor@uscis.dhs.gov"
  endpoint_auto_confirms = true
}

resource "aws_sns_topic_subscription" "payment_error_email" {
  count = terraform.workspace == "prod" ? 1 : 0
  topic_arn = aws_sns_topic.payment_error_alert_topic.arn
  protocol  = "email"
  endpoint  = "o'dwayne.s.irving@uscis.dhs.gov"
  endpoint_auto_confirms = true
}

resource "aws_sns_topic_subscription" "pending_submissions_email-odwayne" {
  topic_arn = aws_sns_topic.pending_submissions_alert_topic.arn
  protocol  = "email"
  endpoint  = "o'dwayne.s.irving@uscis.dhs.gov"
  endpoint_auto_confirms = true
}

resource "aws_sns_topic_subscription" "pending_submissions_email-carlyle" {
  topic_arn = aws_sns_topic.pending_submissions_alert_topic.arn
  protocol  = "email"
  endpoint  = "carlyle.davis@uscis.dhs.gov"
  endpoint_auto_confirms = true
}