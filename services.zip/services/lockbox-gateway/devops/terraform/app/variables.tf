variable "fullnameOverride" { default = "changeme" }
variable "nameOverride" { default = "changeme" }
variable "values_environment" {}
variable "kubernetes_namespace" { default = "changeme" }
variable "helm_chart_version" { default = "changeme" }
variable "chart_repository" { default = "changeme" }
variable "image_tag" { default = "changeme" }
variable "chart_path_or_name" { default = "intake-gateway" }
variable "eks_domain" { default = "changeme" }
variable "amqKeystore" { default = "changeme" }
variable "amqKeystorePassword" { default = "changeme" }
variable "amqTrustStorePassword" { default = "changeme" }
variable "amqPassword" { default = "changeme" }
variable "brokerUrl" { default = "changeme" }
variable "secondaryBrokerUrl" { default = "changeme" }
variable "ternaryBrokerUrl" { default = "changeme" }
variable "helm_history_max" { default = 3 }
variable "tags" {}
variable "helm_values_path" {}
variable "submission_service_url" {}
variable "paymentservice_url" {}
variable "new_relic_license_key" {}

variable "amqQueuePrefix" { default = "" }
variable "eks_context" {}