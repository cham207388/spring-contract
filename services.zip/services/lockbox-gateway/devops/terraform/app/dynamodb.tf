locals {
  deletion_protection = {
    "prod" : "true",
    "preprod" : "true"
  }
}

resource "aws_dynamodb_table" "manifests_table" {
  name                        = "${terraform.workspace}-SubmissionManifest"
  hash_key                    = "manifestId"
  billing_mode                = "PAY_PER_REQUEST"
  stream_enabled              = true
  stream_view_type            = "NEW_AND_OLD_IMAGES"
  deletion_protection_enabled = try(local.deletion_protection[terraform.workspace], false)

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }
  attribute {
    name = "manifestId"
    type = "S"
  }

  tags = var.tags
}

# resource "aws_iam_policy" "dynamoDB_policy" {
#   name_prefix = "${terraform.workspace}-dig-intake-db-"

#   policy = jsonencode({
#     Version = "2012-10-17"
#     Statement = [
#       {
#         Effect = "Allow"
#         Action = [
#           "dynamodb:GetItem",
#           "dynamodb:PutItem",
#           "dynamodb:CreateTable",
#           "dynamodb:DeleteItem",
#           "dynamodb:UpdateItem",
#           "dynamodb:Scan",
#           "dynamodb:Query",
#           "dynamodb:BatchGetItem"
#         ]
#         Resource = [aws_dynamodb_table.manifests_table.arn, "${aws_dynamodb_table.manifests_table.arn}/index/*"]
#       }
#     ]
#   })

#   tags       = var.tags
#   depends_on = [aws_dynamodb_table.manifests_table]
# }
