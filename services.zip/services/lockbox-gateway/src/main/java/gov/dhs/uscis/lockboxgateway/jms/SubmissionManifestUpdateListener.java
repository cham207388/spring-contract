package gov.dhs.uscis.lockboxgateway.jms;

import java.util.UUID;

import org.slf4j.MDC;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.models.SubmissionManifestResponse;
import gov.dhs.uscis.lockboxgateway.exception.SubmissionBadRequestException;
import gov.dhs.uscis.lockboxgateway.service.SubmissionManifestService;
import gov.dhs.uscis.lockboxgateway.util.SubmissionManifestUtil;
import jakarta.jms.JMSException;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

@Slf4j
@Component
public class SubmissionManifestUpdateListener {

    private WebClient webClient;

    private SubmissionManifestService submissionManifestService;

    DynamoDbTable<SubmissionManifest> submissionManifestTable;

    public SubmissionManifestUpdateListener(WebClient webClient,
            SubmissionManifestService submissionManifestService,
            DynamoDbTable<SubmissionManifest> submissionManifestTable) {
        this.webClient = webClient;
        this.submissionManifestService = submissionManifestService;
        this.submissionManifestTable = submissionManifestTable;
    }

    @JmsListener(destination = "${jms.intake.lockbox-manifest-response.queue}", containerFactory = "jmsListenerContainerFactory")
    public void fromMessage(SubmissionManifestResponse submissionManifestResponse) throws JMSException {
        MDC.put("traceId", UUID.randomUUID().toString());
        try {
            log.info("Receiving SubmissionManifestResponse with uscisId: {} and Status: {}",
                    submissionManifestResponse.uscisId(), submissionManifestResponse.status());
            SubmissionManifest submissionManifest = submissionManifestService
                    .updateSubmissionManifestWithManifestStatus(submissionManifestResponse);
            log.info("Updated Submission with submissionId: {} and Status: {}",
                    submissionManifest.getSubmissionId(),
                    submissionManifest.getStatuses().getManifestStatus().getStatus());

            webClient
                    .put()
                    .uri("/api/v1/" + submissionManifest.getMyUscisId() + "/submissions/"
                            + submissionManifest.getSubmissionId().toLowerCase() + "/lockbox-status")
                    .bodyValue(SubmissionManifestUtil.createSubmissionUpdateRequestforManifest(
                            submissionManifest,
                            submissionManifestResponse))
                    .exchangeToMono(response -> {
                        log.info(response.statusCode().toString());
                        log.info(response.toBodilessEntity().toString());
                        if (response.statusCode().is2xxSuccessful()) {
                            return response.toBodilessEntity();
                        } else {
                            return Mono.error(new SubmissionBadRequestException(
                                    submissionManifest.getSubmissionId()));
                        }
                    }).block();
        } catch (Exception ex) {
            log.error("Exception encountered", ex.getMessage());
            throw new RuntimeException(ex);
        } finally {
            MDC.clear();
        }
    }
}