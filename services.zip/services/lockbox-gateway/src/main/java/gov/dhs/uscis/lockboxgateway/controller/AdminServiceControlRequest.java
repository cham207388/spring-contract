package gov.dhs.uscis.lockboxgateway.controller;

public class AdminServiceControlRequest {

    private ServiceAction action;

    public ServiceAction getAction() {
        return action;
    }

    public void setAction(ServiceAction action) {
        this.action = action;
    }

}
