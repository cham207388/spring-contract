package gov.dhs.uscis.lockboxgateway.controller;

public record FormMetaDataEnableRequest(boolean enabled){

}
