package gov.dhs.uscis.lockboxgateway.config;

import java.time.Clock;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import gov.dhs.uscis.intake.daos.AuditDAO;
import gov.dhs.uscis.intake.entities.audit.Audit;
import gov.dhs.uscis.intake.services.AuditService;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

@Configuration
public class CommonsConfig {

    @Bean
    public Clock clock() {
        return Clock.systemUTC();
    }

    @Bean
    public AuditDAO auditDAO (DynamoDbTable<Audit> auditTable) {
        return new AuditDAO(auditTable);
    }

    @Bean
    public AuditService auditService (AuditDAO auditDAO, Clock clock) {
        return new AuditService(auditDAO, clock);
    }
  
  }
