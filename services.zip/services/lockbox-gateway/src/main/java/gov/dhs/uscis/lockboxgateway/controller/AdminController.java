package gov.dhs.uscis.lockboxgateway.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.lockboxgateway.service.AdminService;
import gov.dhs.uscis.lockboxgateway.service.ELISAutoIngestionTriggerService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/administration")
public class AdminController {

    private AdminService service;
    private ELISAutoIngestionTriggerService autoIngestionService;

    public AdminController(AdminService service, ELISAutoIngestionTriggerService autoIngestionService) {
        this.service = service;
        this.autoIngestionService = autoIngestionService;
    }

    @PostMapping("/manifest/{manifestId}")
    public ResponseEntity<?> resubmit(@PathVariable String manifestId, AdminServiceControlRequest request) {
        var success = service.resubmitById(manifestId);
        return success ? ResponseEntity.ok().build() : ResponseEntity.internalServerError().build();
    }

    @PostMapping("/manifest")
    public ResponseEntity<?> resubmitIds(@RequestBody AdminServiceMultipleControlRequest request) {
        var response = service.resubmitByIds(request.ids());
        return ResponseEntity.ok().body(response);
    }
    
    @GetMapping("/autopublish/{submissionId}")
    public ResponseEntity<?> autopublishSubmissionId(@PathVariable("submissionId") String submissionId) {
    	autoIngestionService.publishIngestion(SubmissionManifest.builder().submissionId(submissionId).build());
        return ResponseEntity.ok().body("Success");
    }

    @PatchMapping("{formType}/metadata/enabled")
        public ResponseEntity<FormMetaData> updateFormMetadataEnable(@PathVariable("formType")
        String formType, @Valid @RequestBody FormMetaDataEnableRequest request){
        
        FormMetaData updateFormMetaData = service.updateFormMetadataEnable(formType, request.enabled());

        return ResponseEntity.ok().body(updateFormMetaData);
    }
}
