package gov.dhs.uscis.lockboxgateway.config;

import java.net.URI;
import java.net.URISyntaxException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.SubmissionSummary;
import gov.dhs.uscis.intake.entities.audit.Audit;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.Submission;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.DynamoDbClientBuilder;

@Configuration
public class DynamoDBConfig {

    @Value("${uscis.dynamodb.endpoint}")
    private String amazonDynamoDBEndpoint;

    @Value("${uscis.dynamodb.prefix}")
    private String tablePrefix;

    private Logger logger = LoggerFactory.getLogger(DynamoDBConfig.class);

    @Bean
    public DynamoDbClient getDynamoDbClient() throws URISyntaxException {
        logger.debug("Dynamodb endpoint:: " + amazonDynamoDBEndpoint);
        DynamoDbClientBuilder dynamoDbClientBuilder = DynamoDbClient.builder().region(Region.US_EAST_1);
        if (StringUtils.hasLength(amazonDynamoDBEndpoint))
            dynamoDbClientBuilder.endpointOverride(new URI(amazonDynamoDBEndpoint));

        return dynamoDbClientBuilder.build();
    }

    @Bean
    public DynamoDbEnhancedClient amazonDynamoDBEnhanced(DynamoDbClient dynamoDbClient) {
        logger.debug("Creating enhanced client");
        return DynamoDbEnhancedClient.builder().dynamoDbClient(dynamoDbClient).build();
    }

    @Bean
    public DynamoDbTable<SubmissionManifest> submissionManifestTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        return enhancedDbClient.table("%s-SubmissionManifest".formatted(tablePrefix),
                TableSchema.fromBean(SubmissionManifest.class));
    }
    
    @Bean
    public DynamoDbTable<Submission> submissionTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        return enhancedDbClient.table("%s-Submission".formatted(tablePrefix),
                TableSchema.fromBean(Submission.class));
    }

    @Bean
    public DynamoDbTable<Audit> auditTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        String tableName = "%s-Audit".formatted(tablePrefix);
        return enhancedDbClient.table(tableName, TableSchema.fromBean(Audit.class));
    }

    @Bean
    public DynamoDbTable<SubmissionSummary> submissionSummaryTable(DynamoDbEnhancedClient enhancedDbClient) {
        String tableName = "%s-SubmissionSummary".formatted(tablePrefix);
        return enhancedDbClient.table(tableName, TableSchema.fromBean(SubmissionSummary.class));
    }

    @Bean
    public DynamoDbTable<FormMetaData> formMetaDataTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        return enhancedDbClient.table("%s-FormMetaData".formatted(tablePrefix),
                TableSchema.fromBean(FormMetaData.class));
    }
}
