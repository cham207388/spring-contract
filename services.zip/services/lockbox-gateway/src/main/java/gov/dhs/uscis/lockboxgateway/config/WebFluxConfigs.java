package gov.dhs.uscis.lockboxgateway.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import gov.dhs.uscis.lockboxgateway.jms.listeners.PaymentServiceClient;
import reactor.netty.http.client.HttpClient;

@Configuration
public class WebFluxConfigs {

    @Value("${uscis.submission.baseUrl}")
    private String baseUrl;

    @Bean
    public PaymentServiceClient paymentServiceClient(@Value("${application.urls.payments}") String baseUrl, 
    @Value("${application.defaults.timeout}") int timeout ){
        HttpClient httpClient = HttpClient.create().responseTimeout(java.time.Duration.ofSeconds(timeout));
        var client = WebClient.builder()
        .clientConnector(new ReactorClientHttpConnector(httpClient))
        .baseUrl(baseUrl)
        .build();

        return new PaymentServiceClient(client, getObjectMapper());
    }
    @Bean
    WebClient getWebClient(@Value("${application.defaults.timeout}") int timeout) {
        HttpClient httpClient = HttpClient.create().responseTimeout(java.time.Duration.ofSeconds(timeout));

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .baseUrl(baseUrl)
                .build();
    }

    @Bean
    ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());

        return objectMapper;

    }
}
