package gov.dhs.uscis.lockboxgateway.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.entities.submissionmanifest.Application;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class AdminService {

    private SubmissionManifestRepository repository;
    private SubmissionManifestService submissionManifestService;
    private FormMetaDataRepository formMetaDatatRepository;

    public AdminService(SubmissionManifestRepository repository,
            SubmissionManifestService submissionManifestService, FormMetaDataRepository formMetaDatatRepository) {
        this.repository = repository;
        this.submissionManifestService = submissionManifestService;
        this.formMetaDatatRepository = formMetaDatatRepository;
    }

   
    public boolean resubmitById(String manifestId) {
        var manifest = repository.retrieveSubmissionManifest(manifestId);
        Statuses statuses = manifest.getStatuses();
        statuses.getManifestStatus().setStatus(StatusEnum.PUBLISHED);
        statuses.getSubmissionStatus().setStatus(StatusEnum.RECEIVED);
        SubmissionStatus submissionStatus = statuses.getSubmissionStatus();
        submissionStatus.getApplicationStatuses().removeIf(status -> !FormType.I765.getType().equals(status.getFormType()));
        submissionStatus.getApplicationStatuses().forEach(status -> {
            status.setRejectionReasons(null);
            status.setStatus(StatusEnum.RECEIVED);
            status.setUscisId(manifest.getSubmissionId());
        });
        repository.updateSubmissionManifest(manifest);
        
        FormType formType = FormType.I765;
        Optional<Application> primaryApp = manifest.getManifest().getApplications().stream().filter(app -> !FormType.G28.equals(app.getFormType())).findFirst();
        if(primaryApp.isPresent()) {
        	formType = FormType.fromStringIgnoreSpace(primaryApp.get().getFormType());
        }
        return submissionManifestService.publishToLockbox(manifest, formType);
    }

    public List<Map<String, Boolean>> resubmitByIds(List<String> manifestIds) {
        return manifestIds.stream().map(manifestId -> {
            return Map.of(manifestId, resubmitById(manifestId));
        }).toList();
    }

    public FormMetaData updateFormMetadataEnable(String formType, boolean enabled) {
        
        FormMetaData formMetaData = formMetaDatatRepository.retrieveFormMataData(formType);
        
        if(formMetaData == null){
            log.error("FormMetaData not found for form type {}", formType);
            throw new IllegalArgumentException("FormMetaData not found for formType " + formType);
        }

        formMetaData.setEnabled(enabled);
        
        try {
            FormMetaData updatedFormMetaData =  formMetaDatatRepository.update(formMetaData);
            log.info("Successfully updated FormMetaData enabled status for formType: {} to: {}", formType, enabled);
            return updatedFormMetaData;
        } catch (Exception e) {
            log.error("Exception encountered during updateItem for FormMetaData with formType {}: {}", 
            formType, e.getMessage());
            throw new RuntimeException("Failed to update FormMetaData enabled status", e);
        }
    }
}