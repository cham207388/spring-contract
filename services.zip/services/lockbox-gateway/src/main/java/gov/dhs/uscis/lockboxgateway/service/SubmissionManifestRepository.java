package gov.dhs.uscis.lockboxgateway.service;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.SubmissionSummary;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.TransactPutItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.TransactWriteItemsEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@Component
@Slf4j
public class SubmissionManifestRepository {
    private DynamoDbTable<SubmissionManifest> submissionManifestTable;
    private DynamoDbEnhancedClient dynamoClient;
    private DynamoDbTable<SubmissionSummary> submissionSummaryTable;

    public SubmissionManifestRepository(
            DynamoDbTable<SubmissionManifest> submissionManifestTable,
            DynamoDbTable<SubmissionSummary> submissionSummaryTable,
            DynamoDbEnhancedClient dynamoClient) {
        this.submissionManifestTable = submissionManifestTable;
        this.submissionSummaryTable = submissionSummaryTable;
        this.dynamoClient = dynamoClient;
    }

    public void saveSubmissionManifest(SubmissionManifest submissionManifest) {
        log.info("Saving submission manifest with submissionId: {} and LockBoxId: {}",
                submissionManifest.getSubmissionId(), submissionManifest.getManifestId());
        try {
            TransactWriteItemsEnhancedRequest transaction = TransactWriteItemsEnhancedRequest.builder()
                    .addPutItem(submissionManifestTable,
                            TransactPutItemEnhancedRequest
                                    .builder(SubmissionManifest.class)
                                    .item(submissionManifest)
                                    .build())
                    .addPutItem(submissionSummaryTable,
                            TransactPutItemEnhancedRequest
                                    .builder(SubmissionSummary.class)
                                    .conditionExpression(Expression.builder()
                                            .expression("attribute_not_exists(submissionId)").build())
                                    .item(new SubmissionSummary(submissionManifest.getSubmissionId(),
                                            submissionManifest.getManifestId()))
                                    .build())
                    .build();

            dynamoClient.transactWriteItems(transaction);
        } catch (Exception t) {
            log.error(String.format("Exception encountered saving submission manifest %s",
                    submissionManifest.getSubmissionId()), t.getMessage());
            throw t;
        } 

        log.info("Successfully saved submission manifest with submissionId: {} and LockBoxId: {}",
                submissionManifest.getSubmissionId(), submissionManifest.getManifestId());
    }

    public void updateSubmissionManifest(SubmissionManifest submissionManifest) {
        try {
            UpdateItemEnhancedRequest<SubmissionManifest> enhancedRequest = UpdateItemEnhancedRequest
                    .builder(SubmissionManifest.class)
                    .item(submissionManifest).build();
            submissionManifestTable.updateItem(enhancedRequest);
        } catch (Exception ex) {
            log.error("Exception encountered during updateItem", ex.getMessage());
        } 
    }

    public SubmissionManifest retrieveSubmissionManifest(String manifestId) {
        try {
            GetItemEnhancedRequest request = GetItemEnhancedRequest.builder()
                    .key(builder -> builder.partitionValue(manifestId.toLowerCase())).build();
            return submissionManifestTable.getItem(request);
        } catch (Exception ex) {
            log.error("Exception encountered during getItem", ex.getMessage());
            return null;
        } 
    }

    public SubmissionSummary retrieveSubmissionSummaryBySubmissionId(String submissionId) {
        try {
            GetItemEnhancedRequest request = GetItemEnhancedRequest.builder()
                    .key(builder -> builder.partitionValue(submissionId.toLowerCase())).build();
            return submissionSummaryTable.getItem(request);
        } catch (Exception ex) {
            log.error("Exception encountered during getItem", ex.getMessage());
            return null;
        } 
    }

    public SubmissionSummary retrieveSubmissionSummaryByManifestId(String manifestId) {
        try {
            DynamoDbIndex<SubmissionSummary> manifestIdIndex = submissionSummaryTable.index("summary_by_manifestId");
            QueryConditional queryConditional = QueryConditional.keyEqualTo(Key.builder()
                    .partitionValue(manifestId)
                    .build());

            SdkIterable<Page<SubmissionSummary>> result = manifestIdIndex.query(queryConditional);
            return result.stream().flatMap(page -> page.items().stream()).findFirst().orElse(null);
        } catch (Exception ex) {
            log.error("Exception encountered during getItem", ex.getMessage());
            return null;
        } 
    }
}
