package gov.dhs.uscis.lockboxgateway.jms;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.models.SubmissionStatusResponse;
import jakarta.jms.JMSException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SubmissionStatusPublisher {
    JmsTemplate jmsTemplate;

    public SubmissionStatusPublisher(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    public void publishSubmissionResponse(final String queueName,
            final SubmissionStatusResponse submissionStatusResponse, String submissionId) throws JMSException {

        jmsTemplate.convertAndSend(queueName, submissionStatusResponse);
        log.info("Successfully published Submission status for submissionId: {}", submissionId);
    }

}
