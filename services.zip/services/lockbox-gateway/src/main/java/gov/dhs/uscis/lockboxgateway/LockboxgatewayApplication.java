package gov.dhs.uscis.lockboxgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import org.springframework.context.annotation.Import;
import gov.dhs.uscis.intake.configs.EligibilityCategoryConfig;
@SpringBootApplication
@Import(EligibilityCategoryConfig.class)
@EnableAspectJAutoProxy
@ComponentScan(value = {"gov.dhs.uscis.intake.monitoring", "gov.dhs.uscis.lockboxgateway"})
public class LockboxgatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(LockboxgatewayApplication.class, args);
	}

}
