package gov.dhs.uscis.lockboxgateway.jms;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.models.SubmissionProcessingStatusEnum;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.intake.models.SubmissionStatusResponse;
import gov.dhs.uscis.intake.util.I129FormTypeConverter;
import gov.dhs.uscis.lockboxgateway.exception.SubmissionBadRequestException;
import gov.dhs.uscis.lockboxgateway.service.SubmissionStatusService;
import gov.dhs.uscis.lockboxgateway.util.SubmissionManifestUtil;
import jakarta.jms.JMSException;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

@Slf4j
@Component
public class SubmissionStatusUpdateListener {

    @Value("${jms.intake.lockbox-submission-response.queue}")
    private String submissionResponseQueue;

    private WebClient webClient;

    private SubmissionStatusService submissionStatusService;

    DynamoDbTable<SubmissionManifest> submissionManifestTable;

    private SubmissionStatusPublisher submissionStatusPublisher;

    public SubmissionStatusUpdateListener(WebClient webClient,
            SubmissionStatusService submissionStatusService,
            DynamoDbTable<SubmissionManifest> submissionManifestTable,
            SubmissionStatusPublisher submissionStatusPublisher) {
        this.webClient = webClient;
        this.submissionStatusService = submissionStatusService;
        this.submissionManifestTable = submissionManifestTable;
        this.submissionStatusPublisher = submissionStatusPublisher;
    }

    @JmsListener(destination = "${jms.intake.lockbox-submission-update.queue}", containerFactory = "jmsListenerContainerFactory")
    public void fromMessage(SubmissionStatus submissionStatus) throws JMSException {
        try {
            log.info("Receiving SubmissionUpdate with uscisId: {} and Status: {}",
                    submissionStatus.getUscisId(), submissionStatus.getStatus());
                submissionStatus.getApplicationStatuses().forEach(appStatus -> 
                    log.info("form types sent in are {} for submisisonId", appStatus.getFormType(), submissionStatus.getUscisId())
                );
                    
            handleI129FormTypeConversions(submissionStatus);
            
            final String correlationId = submissionStatus.getCorrelationId();
            SubmissionManifest submissionManifest = submissionStatusService
                    .updateSubmissionManifestWithSubmissionStatus(submissionStatus);
            log.info("Updated Submission with submissionId: {} and Status: {}",
                    submissionManifest.getSubmissionId(),
                    submissionManifest.getStatuses().getSubmissionStatus().getStatus());
            SubmissionStatusResponse submissionStatusResponse = SubmissionStatusResponse.builder()
                    .correlationId(correlationId).uscisId(submissionStatus.getUscisId().toLowerCase()).build();
            webClient
                    .put()
                    .uri("/api/v1/" + submissionManifest.getMyUscisId() + "/submissions/"
                            + submissionManifest.getSubmissionId().toLowerCase() + "/lockbox-status")
                    .bodyValue(SubmissionManifestUtil
                            .createSubmissionUpdateRequestForSubmission(submissionManifest))
                    .exchangeToMono(response -> {
                        if (response.statusCode().is2xxSuccessful()) {
                            submissionStatusResponse.setProcessingStatus(
                                    SubmissionProcessingStatusEnum.SUCCESS.name());
                            return response.toBodilessEntity();
                        } else {
                            submissionStatusResponse.setProcessingStatus(
                                    SubmissionProcessingStatusEnum.FAILURE.name());
                            switch (response.statusCode().value()) {
                                case 400:
                                    submissionStatusResponse
                                            .setErrorMessage(String.format(
                                                    "Invalid Submission status for SubmissionId: %s with error: %s",
                                                    submissionManifest.getSubmissionId(), response.statusCode()));
                                    break;
                                case 404:
                                    submissionStatusResponse.setErrorMessage(
                                            String.format("Submission not found for SubmissionId: %s with error: %s",
                                                    submissionManifest.getSubmissionId(), response.statusCode()));
                                    break;
                                default:
                                    submissionStatusResponse.setErrorMessage(
                                            String.format("Internal server error for SubmissionId: %s with error: %s",
                                                    submissionManifest.getSubmissionId(), response.statusCode()));
                                    break;
                            }
                            log.info("Sending Submission status SubmissionService failed: {}",
                                    submissionStatusResponse.getErrorMessage());
                            return Mono.error(new SubmissionBadRequestException(submissionManifest.getSubmissionId()));
                        }
                    }).block();

            log.info("Sending Submission status response to Lockbox with Processing status: {}",
                    submissionStatusResponse.getProcessingStatus());
            submissionStatusPublisher.publishSubmissionResponse(submissionResponseQueue,
                    submissionStatusResponse, submissionManifest.getSubmissionId());

        } catch (JMSException jms) {
            log.error("Exception from submission status response queue: {}", jms.getMessage());
        } catch (Exception ex) {
            log.error("Exception encountered", ex.getMessage());
            throw new RuntimeException(ex);
        } 
    }

    private void handleI129FormTypeConversions(SubmissionStatus submissionStatus) {
        if (submissionStatus.getApplicationStatuses() != null)
            submissionStatus.getApplicationStatuses()
                    .forEach(el -> el.setFormType(I129FormTypeConverter.toFormEnum(el.getFormType())));
    }
}
