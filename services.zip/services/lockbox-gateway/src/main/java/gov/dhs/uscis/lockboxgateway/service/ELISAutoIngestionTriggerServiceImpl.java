package gov.dhs.uscis.lockboxgateway.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Profile("!mock_elis")
public class ELISAutoIngestionTriggerServiceImpl implements ELISAutoIngestionTriggerService {

	@Override
	public void publishIngestion(SubmissionManifest submissionManifest) {
		log.info("Live service is runnning, ELIS Ingestion should be triggered through elis payment service. For submission {} with manifestId {}", 
				submissionManifest.getSubmissionId(),
				submissionManifest.getManifestId());
	}

}
