package gov.dhs.uscis.lockboxgateway.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.ActiveMQSslConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;

import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.models.SubmissionManifestResponse;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.intake.models.SubmissionStatusResponse;
import gov.dhs.uscis.lockboxgateway.jms.listeners.LockboxPaymentMessage;
import gov.dhs.uscis.lockboxgateway.jms.publisher.LockboxSubmissionPaymentProcessedEvent;

@Configuration
@EnableJms
public class JMSConnectionConfig {

    @Value("${spring.activemq.broker-url}")
    private String jmsBrokerUrl;

    @Value("${spring.activemq.secondary-url}")
    private String secondaryJmsBrokerUrl;

    @Value("${spring.activemq.ternary-url}")
    private String ternaryJmsBrokerUrl;

    @Value("${activemq.keyStore}")
    private String keystore;

    @Value("${activemq.keyStorePassword}")
    private String keystorePassword;

    @Value("${activemq.trustStore}")
    private String trustStore;

    @Value("${activemq.trustStorePassword}")
    private String trustStorePassword;

    @Value("${spring.activemq.user}")
	private String username;

	@Value("${spring.activemq.password}")
	private String password;


    @Bean
    @ConditionalOnProperty(prefix = "jms.intake", name = "enable-ssl", havingValue = "true", matchIfMissing = true)
    public ActiveMQConnectionFactory connectionFactory() throws Exception {
        ActiveMQSslConnectionFactory connectionFactory = new ActiveMQSslConnectionFactory();
        String failOverUrl = "failover:("+ secondaryJmsBrokerUrl  + "," + jmsBrokerUrl + "," + ternaryJmsBrokerUrl + ")?randomize=true";
        connectionFactory.setBrokerURL(failOverUrl);
        connectionFactory.setKeyStore(keystore);
        connectionFactory.setKeyStorePassword(keystorePassword);
        connectionFactory.setTrustStore(trustStore);
        connectionFactory.setTrustStorePassword(trustStorePassword);
        connectionFactory.setTrustedPackages(List.of("gov/dhs/uscis/lockboxgateway/model"));
        return connectionFactory;
    }

    @Bean
    @ConditionalOnProperty(prefix = "jms.intake", name = "enable-ssl", havingValue = "false")
    public ActiveMQConnectionFactory localConnectionFactory() {
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
        String failOverUrl = "failover:("+ secondaryJmsBrokerUrl  + "," + jmsBrokerUrl + "," + ternaryJmsBrokerUrl + ")?randomize=true";
		connectionFactory.setBrokerURL(failOverUrl);
		connectionFactory.setUserName(username);
		connectionFactory.setPassword(password);
		connectionFactory.setTrustedPackages(List.of("gov/dhs/uscis/lockboxgateway/model"));
		return connectionFactory;
	}

    @Bean
    public JmsTemplate jmsTemplate(ActiveMQConnectionFactory connectionFactory, MessageConverter messageConverter) {
        JmsTemplate template = new JmsTemplate();
        template.setConnectionFactory(connectionFactory);
        template.setMessageConverter(messageConverter);
        template.setPubSubDomain(false);
        return template;
    }

    @Bean
    public DefaultJmsListenerContainerFactory jmsListenerContainerFactory(ActiveMQConnectionFactory connectionFactory, MessageConverter messageConverter) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();

        factory.setConnectionFactory(connectionFactory);
        factory.setMessageConverter(messageConverter);
        factory.setConcurrency("5");
        factory.setPubSubDomain(false);

        return factory;
    }

    @Bean
    public MessageConverter getMessageConverter() {
        MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
        converter.setTargetType(MessageType.TEXT);
        converter.setTypeIdPropertyName("type");
        Map<String, Class<?>> typeIdMap = new HashMap<>();
        typeIdMap.put("intake.manifest.v1", Manifest.class);
        typeIdMap.put("intake.manifest.response.v1", SubmissionManifestResponse.class);
        typeIdMap.put("intake.submission.update.v1", SubmissionStatus.class);
        typeIdMap.put("intake.submission.update.response.v1", SubmissionStatusResponse.class);
        typeIdMap.put("intake.payment.request.v1", LockboxPaymentMessage.class);
        typeIdMap.put("intake.payment.response.v1", LockboxSubmissionPaymentProcessedEvent.class);
        converter.setTypeIdMappings(typeIdMap);
        return converter;
    }
}
