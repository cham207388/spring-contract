package gov.dhs.uscis.lockboxgateway.service;

import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.elis.ELISPayment;
import gov.dhs.uscis.intake.models.elis.ELISPaymentRequest;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;

@Service
@Slf4j
@Profile("mock_elis")
public class ELISAutoIngestionTriggerServiceMockImpl implements ELISAutoIngestionTriggerService {

    public static final String ELIS_I765_BENEFIT_CATEGORY_CODE = "44";
    public static final String ELIS_N400_BENEFIT_CATEGORY_CODE = "78";
    public static final String ELIS_I131_BENEFIT_CATEGORY_CODE = "20";
    public static final String ELIS_I130_BENEFIT_CATEGORY_CODE = "19";
    public static final String ELIS_I129H2A_BENEFIT_CATEGORY_CODE = "165";
    private static Map<String, String> benefitCategoryCodes = Map.of(
        FormType.I765.getType(), ELIS_I765_BENEFIT_CATEGORY_CODE,
        FormType.N400.getType(), ELIS_N400_BENEFIT_CATEGORY_CODE,
        FormType.I131.getType(), ELIS_I131_BENEFIT_CATEGORY_CODE,
        FormType.I130.getType(), ELIS_I130_BENEFIT_CATEGORY_CODE,
        FormType.I129H2A.getType(), ELIS_I129H2A_BENEFIT_CATEGORY_CODE);

	private JmsTemplate jmsTemplate;
    private String elisMockIngestionQueue;
    private DynamoDbTable<Submission> submissionTable;
	
	@Autowired
	public ELISAutoIngestionTriggerServiceMockImpl(
			JmsTemplate jmsTemplate, 
			@Value("${jms.intake.elis.queue}") String elisMockIngestionQueue,
			DynamoDbTable<Submission> submissionTable
			) {
		this.jmsTemplate = jmsTemplate;
		this.elisMockIngestionQueue = elisMockIngestionQueue;
		this.submissionTable = submissionTable;
	}

	@Override
	public void publishIngestion(SubmissionManifest submissionManifest) {
		log.info("Mock ELIS Ingestion is runnning for submission {} with manifestId {}", 
				submissionManifest.getSubmissionId(),
				submissionManifest.getManifestId());
		
		final GetItemEnhancedRequest request = GetItemEnhancedRequest.builder()
                .key(builder -> builder.partitionValue(submissionManifest.getSubmissionId()))
                .build();
		
		Submission submission = submissionTable.getItem(request);
		
		jmsTemplate.convertAndSend(elisMockIngestionQueue, createElisPaymentObject(submissionManifest, submission));
	}
	
	private ELISPaymentRequest createElisPaymentObject(SubmissionManifest submissionManifest, Submission submission) {
		String trackingId = submission.getFormType() + UUID.randomUUID().toString();
		
		ELISPaymentRequest request = new ELISPaymentRequest();
		request.setBenefitId(benefitCategoryCodes.get(submission.getFormType().getType()));
		request.setEmailAddress(submission.getApplicant().getEmail());
		request.setNew(true);
		request.setPayableFee(submission.getFeeTotal());
		request.setRefIds(List.of(submissionManifest.getSubmissionId()));
		request.setTrackingId(trackingId);
		
		ELISPayment payment = new ELISPayment();
		payment.setPayGovTrackingId(trackingId);
		payment.setPaymentAmount(submission.getFeeTotal());
		payment.setPaymentDate(new Date());
		payment.setPaymentStatus("Success");
		payment.setPaymentStatusDate(new Date());
		payment.setPaymentType("CREDITCARD");
		payment.setTransactionDate(new Date());
		
		request.setPayment(payment);
		return request;
	}
	
}
