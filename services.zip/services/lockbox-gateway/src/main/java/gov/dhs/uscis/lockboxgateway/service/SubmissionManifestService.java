package gov.dhs.uscis.lockboxgateway.service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.ManifestPublishedConfirmation;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.SubmissionManifestResponse;
import gov.dhs.uscis.intake.models.TransmissionError;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.intake.monitoring.AuditableTransaction;
import gov.dhs.uscis.intake.monitoring.MetricAware;
import gov.dhs.uscis.intake.util.LockboxTransmissionUtil;
import gov.dhs.uscis.lockboxgateway.jms.JmsMessageProducer;
import jakarta.jms.JMSException;
import lombok.extern.slf4j.Slf4j;
import static net.logstash.logback.argument.StructuredArguments.keyValue;

@Slf4j
@Service
public class SubmissionManifestService {
    ManifestError manifestError;
    private SubmissionManifestRepository submissionManifestDao;
    private JmsMessageProducer jmsMessageProducer;
    private String manifestQueue;
    private ELISAutoIngestionTriggerService elisAutoIngestionTriggerService;

    public SubmissionManifestService(
            JmsMessageProducer jmsMessageProducer,
            @Value("${jms.intake.lockbox-manifest.queue}") String manifestQueue,
            SubmissionManifestRepository submissionManifestDao,
            ELISAutoIngestionTriggerService elisAutoIngestionTriggerService) {
        this.submissionManifestDao = submissionManifestDao;
        this.jmsMessageProducer = jmsMessageProducer;
        this.manifestQueue = manifestQueue;
        this.elisAutoIngestionTriggerService = elisAutoIngestionTriggerService;
    }

    @SuppressWarnings("static-access")
    public SubmissionManifest updateSubmissionManifestWithManifestStatus(
            SubmissionManifestResponse submissionManifestResponse) {
        log.info("Receiving SubmissionManifestResponse with uscisId: {} and Status: {}",
                submissionManifestResponse.uscisId(), submissionManifestResponse.status());
        SubmissionManifest submissionManifest = submissionManifestDao
                .retrieveSubmissionManifest(submissionManifestResponse.uscisId());

        if (submissionManifest == null || submissionManifest.getSubmissionId() == null)
            throw new NoSuchElementException("SubmissionManifest Not Found");

        submissionManifest.getStatuses().getManifestStatus()
                .setStatus(submissionManifestResponse.status());
        log.info("Successfully updated ManifestUpdate status with SubmissionId: {} and Status; {}",
                submissionManifest.getSubmissionId(),
                submissionManifest.getStatuses().getManifestStatus().getStatus());

        List<TransmissionError> transmissionErrors = submissionManifestResponse.errors();
        if (transmissionErrors != null) {
            List<ManifestError> manifestErrorsList = new ArrayList<>();

            transmissionErrors.forEach((err) -> {
                manifestError.builder()
                        .id(err.uscisId())
                        .errorCode(err.errorCode())
                        .description(err.description())
                        .build();
                manifestErrorsList.add(manifestError);
                submissionManifest.getStatuses().getManifestStatus().setErrors(manifestErrorsList);
            });
        }

        submissionManifestDao.updateSubmissionManifest(submissionManifest);
        return submissionManifest;
    }

    public SubmissionManifest mapTransmissionToManifest(LockboxTransmission lockboxTransmission) {
        var manifestId = UUID.randomUUID().toString();
        

        log.info("ManifestId: {} for submission Id {}", manifestId,
                lockboxTransmission.getSubmission().getSubmissionId());
        SubmissionManifest submissionManifest = LockboxTransmissionUtil.submissionManifestFromLockboxTransmission(lockboxTransmission, manifestId);
        submissionManifestDao.saveSubmissionManifest(submissionManifest);
        return submissionManifest;
    }

    public ManifestPublishedConfirmation checkForExistingConfirmation(String submissionId) {
        var submissionSummary = submissionManifestDao.retrieveSubmissionSummaryBySubmissionId(submissionId);

        return submissionSummary == null ? null
                : new ManifestPublishedConfirmation(submissionSummary.getManifestId(), submissionId, true);
    }

    public ManifestPublishedConfirmation checkForExistingConfirmationByManifestId(String manifestId) {
        log.info("Retrieving submission id for manifest Id {}", manifestId );
        var submissionSummary = submissionManifestDao.retrieveSubmissionSummaryByManifestId(manifestId);

        return submissionSummary == null ? null
                : new ManifestPublishedConfirmation(submissionSummary.getManifestId(), submissionSummary.getSubmissionId(), true);
    }


    public SubmissionManifest getManifest(String manifestId) {
        return submissionManifestDao.retrieveSubmissionManifest(manifestId);
    }

    @MetricAware(transaction = AuditableTransaction.SubmissionPublished, namespace = "PDFI/Submissions")
    public boolean publishToLockbox(SubmissionManifest submissionManifest, FormType formType) {
    	if(!formType.isAutoIngested()) {
    		try {
                jmsMessageProducer.sendMessage(manifestQueue, submissionManifest);

                    log.info("Message sent to Lockbox successfully {} {} {}", 
                    keyValue("manifestId", submissionManifest.getManifestId()),
                    keyValue("submissionId", submissionManifest.getSubmissionId()),
                    keyValue("formType", formType));

                log.info("Message sent successfully submission {}, manifest {}", submissionManifest.getSubmissionId(),
                        submissionManifest.getManifestId());
                return true;
            } catch (JMSException jms) {
                log.error("exception from manifest queue: submission {}, manifest {}, exception {}",
                        submissionManifest.getSubmissionId(), submissionManifest.getManifestId(), jms.getMessage());
            } 
    	}
    	else {
    		elisAutoIngestionTriggerService.publishIngestion(submissionManifest);
    		return true;
    	}
        return false;
    }

    public ManifestPublishedConfirmation validateTransformAndPublish(LockboxTransmission lockboxTransmission) {
        var existingConfirmation = checkForExistingConfirmation(lockboxTransmission.getSubmission().getSubmissionId());
        log.info("Submission already sent {} for submission {}", existingConfirmation != null,
                lockboxTransmission.getSubmission().getSubmissionId());
        if (existingConfirmation == null) {
            SubmissionManifest submissionManifest = mapTransmissionToManifest(lockboxTransmission);
            return publishToLockbox(submissionManifest, FormType.fromString(lockboxTransmission.getSubmission().getPrimaryForm().getType()))
                    ? new ManifestPublishedConfirmation(submissionManifest.getManifestId(), lockboxTransmission.getSubmission().getSubmissionId(), false)
                    : null;
        } else {
            return existingConfirmation;
        }
    }
}
