package gov.dhs.uscis.lockboxgateway.controller;

public enum ServiceAction {
    Resubmit
}