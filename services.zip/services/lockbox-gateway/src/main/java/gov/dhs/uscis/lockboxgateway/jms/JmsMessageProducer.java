package gov.dhs.uscis.lockboxgateway.jms;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import jakarta.jms.JMSException;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.annotations.NotNull;

@Slf4j
@Component
public class JmsMessageProducer {

    JmsTemplate jmsTemplate;

    public JmsMessageProducer(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    public void sendMessage(@NotNull String queueName, @NotNull SubmissionManifest submissionManifest) throws JMSException {

        jmsTemplate.convertAndSend(queueName, submissionManifest.getManifest());
        log.info("Producer > message sent");
    }

}
