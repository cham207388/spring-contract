package gov.dhs.uscis.lockboxgateway.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.models.ManifestPublishedConfirmation;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.lockboxgateway.jms.JmsMessageProducer;
import gov.dhs.uscis.lockboxgateway.service.SubmissionManifestService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "LockBox Gateway", description = "LockBox Gateway Management API's")
@RestController
@RequestMapping("/api/v1")
public class LockBoxGatewayController {

    JmsTemplate jmsTemplate;
    SubmissionManifestService submissionManifestService;
    JmsMessageProducer jmsMessageProducer;

    public LockBoxGatewayController(SubmissionManifestService submissionManifestService) {
        this.submissionManifestService = submissionManifestService;
    }

    @PostMapping("/manifest")
    public ResponseEntity<ManifestPublishedConfirmation> publishManifest(
            @RequestBody LockboxTransmission lockboxTransmission) {

            var confirmation = submissionManifestService.validateTransformAndPublish(lockboxTransmission);
            return confirmation == null ? ResponseEntity.badRequest().build() : ResponseEntity.ok(confirmation);

    }

    @GetMapping("/manifest/{manifestId}")
    public ResponseEntity<SubmissionManifest> getManifest(@PathVariable("manifestId") String manifestId) {
        SubmissionManifest submissionManifest = submissionManifestService.getManifest(manifestId);
        return ResponseEntity.ok(submissionManifest);
    }

    @GetMapping("/manifest/{manifestId}/confirmation")
    public ResponseEntity<ManifestPublishedConfirmation> getBySubmissionId(@PathVariable String manifestId) {
        var confirmation = submissionManifestService
                .checkForExistingConfirmationByManifestId(manifestId);

        return confirmation == null ? ResponseEntity.notFound().build()
                : ResponseEntity.ok(confirmation);
    }
}
