package gov.dhs.uscis.lockboxgateway.exception;

public class SubmissionBadRequestException extends RuntimeException {
    public SubmissionBadRequestException(String submissionId) {
        super(String.format("Bad Request for submissionId: %s", submissionId));
    }  
}
