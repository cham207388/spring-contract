package gov.dhs.uscis.lockboxgateway.service;

import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.lockboxgateway.util.SubmissionManifestUtil;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@Slf4j
@Service
public class SubmissionStatusService {

    DynamoDbTable<SubmissionManifest> submissionManifestTable;

    public SubmissionStatusService(DynamoDbTable<SubmissionManifest> submissionManifestTable) {
        this.submissionManifestTable = submissionManifestTable;
    }

    public SubmissionManifest updateSubmissionManifestWithSubmissionStatus(
            SubmissionStatus submissionStatus) {
        log.info("Receiving SubmissionStatus with uscisId: {} and Status: {}",
                submissionStatus.getUscisId(), submissionStatus.getStatus());
        log.info("Status update: {} ", submissionStatus.toString());
        SubmissionManifest submissionManifest = retrieveSubmissionManifest(submissionStatus.getUscisId());

        if (submissionManifest == null || submissionManifest.getSubmissionId() == null)
            throw new NoSuchElementException("SubmissionManifest Not Found");

        submissionManifest = SubmissionManifestUtil.updateSubmissionManifest(submissionManifest, submissionStatus);
        log.info("Successfully updated Submission status with SubmissionId: {} and Status; {}",
                submissionManifest.getSubmissionId(),
                submissionManifest.getStatuses().getSubmissionStatus().getStatus());

        try {
            UpdateItemEnhancedRequest<SubmissionManifest> enhancedRequest = UpdateItemEnhancedRequest
                    .builder(SubmissionManifest.class)
                    .item(submissionManifest).build();
            submissionManifestTable.updateItem(enhancedRequest);
        } catch (Exception ex) {
            log.error("Exception encountered during updateItem", ex.getMessage());
        }
        return submissionManifest;
    }

    public SubmissionManifest retrieveSubmissionManifest(String uscisId) {
        try {
            GetItemEnhancedRequest request = GetItemEnhancedRequest.builder()
                    .key(builder -> builder.partitionValue(uscisId.toLowerCase())).build();
            return submissionManifestTable.getItem(request);
        } catch (Exception ex) {
            log.error("Exception encountered during getItem", ex.getMessage());
            return null;
        }
    }
}
