package gov.dhs.uscis.lockboxgateway.service;

import gov.dhs.uscis.intake.entities.SubmissionManifest;

public interface ELISAutoIngestionTriggerService {

	public void publishIngestion(SubmissionManifest submissionManifest);
}
