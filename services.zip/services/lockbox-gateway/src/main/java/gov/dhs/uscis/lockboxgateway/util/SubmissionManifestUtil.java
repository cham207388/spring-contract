package gov.dhs.uscis.lockboxgateway.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.models.EntityType;
import gov.dhs.uscis.intake.models.SubmissionManifestResponse;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;

@Component
@SuppressWarnings("java:S1118")
public class SubmissionManifestUtil {
    
    private static RejectionReason submissionUpdateRejectReasonBuilder;

    private static ApplicationStatus applicationStatusBuilder;

    private static RejectionReason rejectReasonBuilder;

    public static SubmissionUpdateRequest createSubmissionUpdateRequestforManifest(
            SubmissionManifest submissionManifest,
            SubmissionManifestResponse submissionManifestResponse) {

        List<ManifestError> manifestErrorBuilderList = new ArrayList<>();
        var submissionManifestErrors = submissionManifest.getStatuses().getManifestStatus().getErrors();
        if (submissionManifestErrors != null) {

            manifestErrorBuilderList = submissionManifestErrors.stream().map(err -> {
                return ManifestError.builder()
                        .errorCode(err.getErrorCode())
                        .id(err.getId())
                        .description(err.getDescription())
                        .build();
            }).collect(Collectors.toList());
        }

        SubmissionUpdateRequest.ManifestUpdate submissionManifestUpate = SubmissionUpdateRequest.ManifestUpdate
                .builder()
                .lockboxId(submissionManifest.getManifestId())
                .status(submissionManifestResponse.status())
                .errors(manifestErrorBuilderList)
                .build();

        return SubmissionUpdateRequest.builder().updateType(EntityType.MANIFEST)
                .manifestUpdate(submissionManifestUpate).build();

    }

    public static SubmissionUpdateRequest createSubmissionUpdateRequestForSubmission(
            SubmissionManifest submissionManifest) {

        var submissionManifestApplicationStatusList = submissionManifest.getStatuses()
                .getSubmissionStatus().getApplicationStatuses();

        SubmissionUpdateRequest.SubmissionUpdate submissionUpdate = SubmissionUpdateRequest.SubmissionUpdate
                .builder()
                .lockboxId(submissionManifest.getManifestId())
                .status(submissionManifest.getStatuses().getSubmissionStatus().getStatus())
                .totalCost(submissionManifest.getStatuses().getSubmissionStatus().getTotalCost())
                .applicationStatuses(submissionManifestApplicationStatusList)
                .build();

        return SubmissionUpdateRequest.builder().updateType(EntityType.SUBMISSION)
                .submissionUpdate(submissionUpdate).build();

    }

    public static SubmissionManifest updateSubmissionManifest(SubmissionManifest submissionManifest,
            SubmissionStatus submissionStatus) {

        List<gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus> submissionStatusApplicationStatusList = submissionStatus
                .getApplicationStatuses();
        List<ApplicationStatus> submissionManifestApplicationStatusList = new ArrayList<>();
        List<RejectionReason> submissionManifestRejectionReasonList = new ArrayList<>();

        if (submissionStatusApplicationStatusList != null) {
            submissionStatusApplicationStatusList.forEach((appStatus) -> {
                var rejectReasonList = appStatus.getRejectionReasons();
                rejectReasonList.forEach((rejectReason) -> {
                    rejectReasonBuilder = RejectionReason.builder().code(rejectReason.getCode())
                            .reason(rejectReason.getReason()).build();
                    submissionManifestRejectionReasonList.add(rejectReasonBuilder);
                });
                applicationStatusBuilder = ApplicationStatus.builder()
                        .uscisId(appStatus.getUscisId())
                        .formType(appStatus.getFormType())
                        .status(appStatus.getStatus())
                        .uscisReceiptNumber(appStatus.getUscisReceiptNumber())
                        .rejectionReasons(submissionManifestRejectionReasonList)
                        .build();
                submissionManifestApplicationStatusList.add(applicationStatusBuilder);
            });
            submissionManifest.getStatuses().getSubmissionStatus()
                    .setApplicationStatuses(submissionManifestApplicationStatusList);
        }

        submissionManifest.getStatuses().getSubmissionStatus().setStatus(submissionStatus.getStatus());

        return submissionManifest;
    }

}
