package gov.dhs.uscis.lockboxgateway.controller;

import java.util.List;

public record AdminServiceMultipleControlRequest(ServiceAction action, List<String> ids) {}
