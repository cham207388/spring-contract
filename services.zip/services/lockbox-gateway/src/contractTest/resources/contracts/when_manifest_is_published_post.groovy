package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

def customIso8601 = '([1-9]\\d{3}-((0[1-9]|1[0-2])-(0[1-9]|1\\d|2[0-8])|(0[13-9]|1[0-2])-(29|30)|(0[13578]|1[02])-31)|([1-9]\\d(0[48]|[2468][048]|[13579][26])|([2468][048]|[13579][26])00)-02-29)T([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d\\.\\d+[+-](0[0-9]|1[0-4])00'

Contract.make {
    request {
        method HttpMethods.POST
        urlPath('/api/v1/manifest')
        headers {
            header(contentType(), applicationJson())
        }
        body(
            [
                myUscisId: anyNonEmptyString(),
                submission: [
                    submissionId: anyNonEmptyString(),
                    feeWaiver: $(consumer(anyBoolean()), producer(true)),
                    feeTotal: $(consumer(number()), producer(0)),
                    lockboxStatus: $(consumer(regex('^(COMPLETE|ACCEPTED|REJECTED|RECEIVED|ERROR|PUBLISHED|PENDING)$')), producer('COMPLETE')),
                    form: [
                        type: $(consumer(regex('[a-zA-Z0-9\\-]+')), producer('I-795')),
                        id: anyNonEmptyString(),
                        url: $(consumer(url()), producer("http://foo.org")),
                        name: $(consumer(regex('[a-zA-Z0-9\\-]+')), producer("Form")),
                        md5Hash: $(consumer(alphaNumeric()), producer("123456789asdf")),
                        rejectionReasons: [
                            [
                                code: $(consumer(alphaNumeric()), producer("code")),
                                reason: $(consumer(alphaNumeric()), producer("reason"))
                            ]
                        ]
                    ],
                    evidence: [
                        [
                            type: $(consumer(regex('[a-zA-Z0-9\\-\s]+')), producer("2x2 photo")),
                            evidenceGroupType: $(consumer(alphaNumeric()), producer("type")),
                            id: anyNonEmptyString(),
                            url: $(consumer(url()), producer("http://foo.org")),
                            name: $(consumer(regex('[a-zA-Z0-9\\-\s]+')), producer("name")),
                            md5Hash: $(consumer(alphaNumeric()), producer("123456789asdf")),
                            uploadedAt: regex(customIso8601)
                        ]
                    ]
                ]
            ]
        )
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }
        body (
            [
                manifestId: anyUuid()
            ]
        )
    }
}
