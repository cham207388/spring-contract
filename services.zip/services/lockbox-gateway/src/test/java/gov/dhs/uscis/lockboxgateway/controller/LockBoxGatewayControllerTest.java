package gov.dhs.uscis.lockboxgateway.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatusCode;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.ManifestPublishedConfirmation;
import gov.dhs.uscis.intake.models.SubmissionManifestResponse;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.lockboxgateway.jms.JmsMessageProducer;
import gov.dhs.uscis.lockboxgateway.service.SubmissionManifestService;
import jakarta.jms.JMSException;

public class LockBoxGatewayControllerTest {
	private LockBoxGatewayController controller;
	private JmsMessageProducer jmsMessageProducer;
	private SubmissionManifestService submissionManifestService;
	private SubmissionManifest submissionManifest;

	@BeforeEach
	public void setup() {
		jmsMessageProducer = Mockito.mock(JmsMessageProducer.class);
		submissionManifest = Mockito.mock(SubmissionManifest.class);
		submissionManifestService = Mockito.mock(SubmissionManifestService.class);

		controller = new LockBoxGatewayController(submissionManifestService);
		new SubmissionManifestResponse("1111111111", StatusEnum.COMPLETE,
				null);
	}

	@Test
	public void testShouldSuccessfulPublishMessage() throws JMSException {
		LockboxTransmission lockboxTransmission = Instancio.create(LockboxTransmission.class);
		when(submissionManifestService.validateTransformAndPublish(any())).thenReturn(new ManifestPublishedConfirmation("fake", "submissionId", false));
		var response = controller.publishManifest(lockboxTransmission);
		assertTrue(response.getStatusCode().is2xxSuccessful());
	}

    @Test
	public void shouldReturnBadRequestIfUnableToValidateAndTransform() throws JMSException {
		LockboxTransmission lockboxTransmission = Instancio.create(LockboxTransmission.class);
		when(submissionManifestService.validateTransformAndPublish(any())).thenReturn(null);
		var response = controller.publishManifest(lockboxTransmission);
		assertTrue(response.getStatusCode().is4xxClientError());
	}

	@Test
	public void testShouldNotPublishMessageThrows400() throws JMSException {
		LockboxTransmission lockboxTransmission = Instancio.create(LockboxTransmission.class);
		when(submissionManifestService.publishToLockbox(any(), any())).thenReturn(false);
		var response = controller.publishManifest(lockboxTransmission);
		assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    public void shouldReturnNotFoundIfSubmissionWasNotSent(){
        when(submissionManifestService.checkForExistingConfirmation(any())).thenReturn(null);
        var response = controller.getBySubmissionId("foo");

        assertEquals(response.getStatusCode(), HttpStatusCode.valueOf(404) );
    }

    @Test
    public void shouldReturnExistingConfirmationIfSubmissionWasSent(){
        var confirmation = new ManifestPublishedConfirmation("manifestId", "submissionId",  true );
        when(submissionManifestService.checkForExistingConfirmationByManifestId(any())).thenReturn(confirmation);
        var response = controller.getBySubmissionId("foo");

        assertEquals(response.getBody(), confirmation);
        assertEquals(response.getStatusCode(), HttpStatusCode.valueOf(200));
    }

    @Test 
    public void shouldRetrieveManifestConfirmationIfExists() throws Exception{
        var mock = MockMvcBuilders.standaloneSetup(new LockBoxGatewayController(submissionManifestService)).build();
        String manifestId = "manifestId";
        String submissionId = "submissionId";

        when(submissionManifestService.checkForExistingConfirmationByManifestId(manifestId))
            .thenReturn(new ManifestPublishedConfirmation(manifestId, submissionId, false));
        
            mock.perform(MockMvcRequestBuilders.get("/api/v1/manifest/manifestId/confirmation"))
            .andExpect(MockMvcResultMatchers.status().isOk())
            .andExpect(MockMvcResultMatchers.jsonPath("$.submissionId", org.hamcrest.Matchers.is(submissionId)));
    }

    @Test 
    public void shouldReturn404IfDoesNotExist() throws Exception{
        var mock = MockMvcBuilders.standaloneSetup(new LockBoxGatewayController(submissionManifestService)).build();
        String manifestId = "manifestId";
        
        when(submissionManifestService.checkForExistingConfirmationByManifestId(manifestId))
            .thenReturn(null);
        
            mock.perform(MockMvcRequestBuilders.get("/api/v1/manifest/manifestId/confirmation"))
            .andExpect(MockMvcResultMatchers.status().isNotFound());
    }
}
