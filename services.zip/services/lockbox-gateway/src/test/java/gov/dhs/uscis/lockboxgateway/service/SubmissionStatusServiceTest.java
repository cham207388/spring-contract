package gov.dhs.uscis.lockboxgateway.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.ManifestStatus;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.SubmissionManifestResponse;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@ExtendWith(MockitoExtension.class)
class SubmissionStatusServiceTest {

    @Mock
    private WebClient webClient;

    @Mock
    DynamoDbTable<SubmissionManifest> mockDynamoDbTable;

    @Mock
    SubmissionManifest mockSubmissionManifest;

    @Mock
    Manifest manifest;

    @Mock
    Statuses statuses;

    @Mock
    ManifestStatus status;

    @Mock
    ManifestError manifestError;

    @Mock
    SubmissionManifestResponse submissionManifestResponse;

    @Mock
    // TODO Clean this up, both of these objects have the same name but they are
    // representing two different portions of the transactions.
    gov.dhs.uscis.intake.models.SubmissionStatus submissionStatus;

    @Mock
    SubmissionStatus submissionManifestStatus;

    List<ManifestError> manifestErrorList;

    @InjectMocks
    SubmissionStatusService service;

    @BeforeEach
    void setUp() {
        manifestErrorList = new ArrayList<>();
        String lockBoxId = "321321";

        manifestError = new ManifestError();
        manifestError.setId(UUID.randomUUID().toString());
        manifestError.setErrorCode("ERROR");
        manifestError.setDescription("ERRORCODE");
        manifestErrorList.add(manifestError);

        manifest = new Manifest();
        statuses = new Statuses();
        status = new ManifestStatus();

        status.setStatus(StatusEnum.ERROR);
        status.setErrors(manifestErrorList);

        statuses.setManifestStatus(status);

        submissionManifestStatus = new SubmissionStatus();

        ApplicationStatus appStatus = new ApplicationStatus();
        List<RejectionReason> rejectList = new ArrayList<>();
        List<ApplicationStatus> appList = new ArrayList<>();
        RejectionReason reject = new RejectionReason();
        reject.setCode("CODE");
        reject.setReason("REASON");
        rejectList.add(reject);
        appStatus.setUscisId(UUID.randomUUID().toString());
        appStatus.setStatus(StatusEnum.ACCEPTED);
        appStatus.setFormType("FORMTYPE");
        appStatus.setRejectionReasons(rejectList);
        appList.add(appStatus);
        submissionManifestStatus.setApplicationStatuses(appList);
        submissionManifestStatus.setStatus(StatusEnum.ACCEPTED);
        statuses.setSubmissionStatus(submissionManifestStatus);

        mockSubmissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                .submissionId(UUID.randomUUID().toString()).myUscisId(UUID.randomUUID().toString()).manifest(manifest)
                .statuses(statuses)
                .build();

        submissionManifestResponse = SubmissionManifestResponse.builder().status(StatusEnum.ERROR).build();

        var appSubmissionStatus = new ApplicationStatus();
        List<RejectionReason> rejectSubmissionList = new ArrayList<>();
        List<ApplicationStatus> appSubmissionList = new ArrayList<>();
        var rejectSubmission = new RejectionReason();
        rejectSubmission.setCode("CODE");
        rejectSubmission.setReason("REASON");
        rejectSubmissionList.add(rejectSubmission);
        appSubmissionStatus.setUscisId(UUID.randomUUID().toString());
        appSubmissionStatus.setStatus(StatusEnum.ACCEPTED);
        appSubmissionStatus.setFormType("FORMTYPE");
        appSubmissionStatus.setRejectionReasons(rejectSubmissionList);
        appSubmissionList.add(appSubmissionStatus);

        submissionStatus = new SubmissionStatus("COR1234", UUID.randomUUID().toString().toUpperCase(),
                StatusEnum.ACCEPTED, appSubmissionList, List.of(), new BigDecimal(0));

    }

    @DisplayName("Should update submissionManifest Submission Status in DynamoDB")
    @Test
    void shouldUpdateSubmissionManifestSubmissionStatus() {

        when(mockDynamoDbTable.getItem(any(GetItemEnhancedRequest.class))).thenReturn(mockSubmissionManifest);
        service.updateSubmissionManifestWithSubmissionStatus(submissionStatus);

        ArgumentCaptor<UpdateItemEnhancedRequest<SubmissionManifest>> captor = ArgumentCaptor.captor();
        ArgumentCaptor<GetItemEnhancedRequest> getCaptor = ArgumentCaptor.captor();

        verify(mockDynamoDbTable, times(1)).getItem(getCaptor.capture());
        verify(mockDynamoDbTable, times(1)).updateItem(captor.capture());

        GetItemEnhancedRequest actualGet = getCaptor.getValue();
        assertEquals(submissionStatus.getUscisId().toLowerCase(), actualGet.key().partitionKeyValue().s());

        UpdateItemEnhancedRequest<SubmissionManifest> actual = captor.getValue();
        assertNotNull(actual.item().getStatuses().getSubmissionStatus().getStatus());
        assertEquals(StatusEnum.ACCEPTED, actual.item().getStatuses().getSubmissionStatus().getStatus());
    }

    @DisplayName("Should throw NoSuchElementException when submissionManifest is null")
    @Test
    void shouldErrorOnUpdateSubmissionManifestWithSubmissionStatus_noSuchElementException() {
        assertThrows(NoSuchElementException.class, () -> service
                .updateSubmissionManifestWithSubmissionStatus(new SubmissionStatus(null, null, null, null,null, null)));
    }

    @DisplayName("Should return null when status does not match enum value")
    @Test
    void shouldReturnNullOnUpdateSubmissionManifestWithSubmissionStatus() {
        when(mockDynamoDbTable.getItem(any(GetItemEnhancedRequest.class)))
                .thenThrow(RuntimeException.class);

        assertThrows(NoSuchElementException.class, () -> {
            var actual = service.updateSubmissionManifestWithSubmissionStatus(submissionStatus);
            assertNull(actual);
        });
    }
}
