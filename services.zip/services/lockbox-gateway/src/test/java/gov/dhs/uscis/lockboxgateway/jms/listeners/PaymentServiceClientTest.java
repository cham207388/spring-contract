package gov.dhs.uscis.lockboxgateway.jms.listeners;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.net.URISyntaxException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersUriSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import gov.dhs.uscis.intake.models.PaymentAuthorizationResponse;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class PaymentServiceClientTest {

    @Mock
    RequestBodyUriSpec requestBodyUriSpec;
    @Mock
    RequestBodySpec requestBodySpec;
    @Mock
    ResponseSpec responseSpec;
    @Mock
    RequestHeadersSpec requestHeadersSpec;
    @Mock
    RequestHeadersUriSpec requestHeadersUriSpec;
    @Mock
    ObjectMapper objectMapper;

    @Test
    public void shouldSendRequestToPaymentServiceToCompleteAuthorizationReturns200()
            throws PaymentProcessingException, URISyntaxException {
        var webClient = mock(WebClient.class);
        var paymentServiceClient = new PaymentServiceClient(webClient, objectMapper);

        doReturn(requestBodyUriSpec).when(webClient).post();
        when(requestBodyUriSpec.uri("/api/v1/payments/{submissionId}/authorization", "submissionId"))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        var responseEntity = mock(ResponseEntity.class);
        when(responseSpec.toEntity(PaymentAuthorizationResponse.class)).thenReturn(Mono.just(responseEntity));
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        PaymentAuthorizationResponse response = paymentServiceClient.completeAuthorization("submissionId", BigDecimal.TEN);
        assertEquals(AuthorizationStatusCode.Success, response.result());
    }

    @Test
    public void shouldSendRequestToPaymentServiceToCompleteAuthorizationReturns400WhenDeclined()
            throws PaymentProcessingException, URISyntaxException, JsonProcessingException {
        var webClient = mock(WebClient.class);
        var paymentServiceClient = new PaymentServiceClient(webClient, objectMapper);
        PaymentAuthorizationResponse response = PaymentAuthorizationResponse.builder().result(AuthorizationStatusCode.Declined).build();
        WebClientResponseException mockException = mock(WebClientResponseException.class);
        when(mockException.getStatusCode()).thenReturn(HttpStatusCode.valueOf(400));
        when(mockException.getResponseBodyAs(PaymentAuthorizationResponse.class)).thenReturn(response);
        
        doReturn(requestBodyUriSpec).when(webClient).post();
        when(requestBodyUriSpec.uri("/api/v1/payments/{submissionId}/authorization", "submissionId"))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenThrow(mockException);

        PaymentAuthorizationResponse responseFromClient = paymentServiceClient.completeAuthorization("submissionId", BigDecimal.TEN);
        assertEquals(response, responseFromClient);
    }

    @Test
    public void shouldSendRequestToPaymentServiceToCompleteAuthorizationReturns400WhenError()
            throws PaymentProcessingException, URISyntaxException {
        var webClient = mock(WebClient.class);
        var paymentServiceClient = new PaymentServiceClient(webClient, objectMapper);
        PaymentAuthorizationResponse response = PaymentAuthorizationResponse.builder().result(AuthorizationStatusCode.Error).build();
        WebClientResponseException mockException = mock(WebClientResponseException.class);
        when(mockException.getStatusCode()).thenReturn(HttpStatusCode.valueOf(400));
        when(mockException.getResponseBodyAs(PaymentAuthorizationResponse.class)).thenReturn(response);

        doReturn(requestBodyUriSpec).when(webClient).post();
        when(requestBodyUriSpec.uri("/api/v1/payments/{submissionId}/authorization", "submissionId"))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenThrow(mockException);

        PaymentAuthorizationResponse responseFromClient = paymentServiceClient.completeAuthorization("submissionId", BigDecimal.TEN);
        assertEquals(response, responseFromClient);
    }

    @Test
    public void shouldThrowExceptionIfPaymentClientDoesNotReturnWith500OnSuccessfulPayment()
            throws PaymentProcessingException {
        var webClient = mock(WebClient.class);
        var paymentServiceClient = new PaymentServiceClient(webClient, objectMapper);
        
        WebClientResponseException mockException = mock(WebClientResponseException.class);
        when(mockException.getStatusCode()).thenReturn(HttpStatusCode.valueOf(500));
        
        doReturn(requestBodyUriSpec).when(webClient).post();
        when(requestBodyUriSpec.uri("/api/v1/payments/{submissionId}/authorization", "submissionId"))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenThrow(mockException);

        PaymentAuthorizationResponse responseFromClient = paymentServiceClient.completeAuthorization("submissionId", BigDecimal.TEN);
        assertEquals("Unable to complete authorization for transaction:  submissionId for amount:  10", responseFromClient.message());
    }

    @Test
    public void shouldCancelAuthorization() throws PaymentProcessingException {
        var webClient = mock(WebClient.class);
        var paymentServiceClient = new PaymentServiceClient(webClient, objectMapper);
        var responseEntity = mock(ResponseEntity.class);
        when(responseEntity.getStatusCode()).thenReturn(HttpStatusCode.valueOf(200));

        doReturn(requestHeadersUriSpec).when(webClient).delete();
        when(requestHeadersUriSpec.uri("/api/v1/payments/{submissionId}/authorization", "submissionId"))
                .thenReturn(requestHeadersSpec);
        when(responseSpec.toBodilessEntity()).thenReturn(Mono.just(responseEntity));
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        paymentServiceClient.cancelAuthorization("submissionId");
    }

    @Test
    public void shouldThrowExceptionIfPaymentFailsOnPaymentService() throws PaymentProcessingException{
        var webClient = mock(WebClient.class);
        var paymentServiceClient = new PaymentServiceClient(webClient, objectMapper);
        var responseEntity = mock(ResponseEntity.class);
        when(responseEntity.getStatusCode()).thenReturn(HttpStatusCode.valueOf(500));

        doReturn(requestHeadersUriSpec).when(webClient).delete();
        when(requestHeadersUriSpec.uri("/api/v1/payments/{submissionId}/authorization", "submissionId"))
                .thenReturn(requestHeadersSpec);
        when(responseSpec.toBodilessEntity()).thenReturn(Mono.just(responseEntity));
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        var exception = assertThrows(PaymentProcessingException.class, () -> paymentServiceClient.cancelAuthorization("submissionId"));
        assertEquals(exception.getMessage(), "Unable to cancel authorization for transaction:  submissionId");
    }

}
