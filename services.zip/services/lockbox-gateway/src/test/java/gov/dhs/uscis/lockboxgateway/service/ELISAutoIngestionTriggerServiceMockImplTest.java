package gov.dhs.uscis.lockboxgateway.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.jms.core.JmsTemplate;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submission.UserInformation;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.elis.ELISPayment;
import gov.dhs.uscis.intake.models.elis.ELISPaymentRequest;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;


@ExtendWith(MockitoExtension.class)
public class ELISAutoIngestionTriggerServiceMockImplTest {

    String elisMockIngestionQueue;

    @Mock
    JmsTemplate jmsTemplate;

    @Mock
    DynamoDbTable<Submission> submissionTable;

    @InjectMocks
    ELISAutoIngestionTriggerServiceMockImpl service;

    @BeforeEach
    void setUp() {
        elisMockIngestionQueue = "Operationalization.v1";
        service = new ELISAutoIngestionTriggerServiceMockImpl(jmsTemplate, elisMockIngestionQueue, submissionTable);
    }

    @Test
    void shouldPublishIngestion() {
        String emailAddress = "test@test.com";
        String manifestId = "testManifestId";
        BigDecimal feeTotal = BigDecimal.ZERO;


        SubmissionManifest mockSubmissionManifest = SubmissionManifest.builder()
            .submissionId("12345")
            .myUscisId("myUscisId")
            .manifestId(manifestId)
            .build();

        Submission mockSubmission = Submission.builder()
            .formType(FormType.I129H2A)
            .applicant(UserInformation.builder()
                .email(emailAddress)
                .build())
            .manifestId(manifestId)
            .feeTotal(feeTotal)
            .build();

        ELISPaymentRequest expectedPaymentRequest = new ELISPaymentRequest();
        expectedPaymentRequest.setBenefitId("165");
        expectedPaymentRequest.setEmailAddress(mockSubmission.getApplicant().getEmail());
        expectedPaymentRequest.setPayableFee(mockSubmission.getFeeTotal());
        expectedPaymentRequest.setRefIds(List.of(mockSubmissionManifest.getSubmissionId()));
        expectedPaymentRequest.setNew(true);

        when(submissionTable.getItem(any(GetItemEnhancedRequest.class))).thenReturn(mockSubmission);

        service.publishIngestion(mockSubmissionManifest);

        verify(jmsTemplate).convertAndSend(eq(elisMockIngestionQueue), refEq(expectedPaymentRequest, "trackingId", "payment"));
    }


}
