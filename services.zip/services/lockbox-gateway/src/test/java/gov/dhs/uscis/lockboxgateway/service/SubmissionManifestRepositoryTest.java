package gov.dhs.uscis.lockboxgateway.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.assertj.core.api.Assertions;
import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.SubmissionSummary;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.TransactWriteItemsEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@ExtendWith(MockitoExtension.class)
public class SubmissionManifestRepositoryTest {

    @Mock
    DynamoDbTable<SubmissionManifest> mockSubmissionManifestTable;

    @Mock
    DynamoDbTable<SubmissionSummary> mockSubmissionSummaryTable;

    @Mock
    DynamoDbEnhancedClient dynamoDbEnhancedClient;

    SubmissionManifestRepository manifestDao;

    private SubmissionManifest submissionManifest = Instancio.create(SubmissionManifest.class);

    @BeforeEach
    public void setup() {
        manifestDao = new SubmissionManifestRepository(mockSubmissionManifestTable, mockSubmissionSummaryTable,
                dynamoDbEnhancedClient);
    }

    @Test
    void shouldSaveSubmissionManifest() {
        when(mockSubmissionManifestTable.tableSchema()).thenReturn(TableSchema.fromBean(SubmissionManifest.class));
        when(mockSubmissionSummaryTable.tableSchema()).thenReturn(TableSchema.fromBean(SubmissionSummary.class));
        manifestDao.saveSubmissionManifest(submissionManifest);
        ArgumentCaptor<TransactWriteItemsEnhancedRequest> captor = ArgumentCaptor.captor();

        verify(dynamoDbEnhancedClient, times(1)).transactWriteItems(captor.capture());

        TransactWriteItemsEnhancedRequest actual = captor.getValue();
        var submissionManifestWrite = actual.transactWriteItems().get(0);
        var submissionSummaryWrite = actual.transactWriteItems().get(1);

        var manifestId = submissionManifestWrite.put().item().get("manifestId").s();
        var submissionId = submissionSummaryWrite.put().item().get("submissionId").s();

        Assertions.assertThat(manifestId).isEqualTo(submissionManifest.getManifestId());
        Assertions.assertThat(submissionId).isEqualTo(submissionManifest.getSubmissionId());
        Assertions.assertThat(submissionSummaryWrite.put().conditionExpression())
                .isEqualTo("attribute_not_exists(submissionId)");
    }

    @Test
    void shouldUpdateSubmissionManifest() {

        manifestDao.updateSubmissionManifest(submissionManifest);
        ArgumentCaptor<UpdateItemEnhancedRequest<SubmissionManifest>> captor = ArgumentCaptor.captor();

        verify(mockSubmissionManifestTable, times(1)).updateItem(captor.capture());

        UpdateItemEnhancedRequest<SubmissionManifest> actual = captor.getValue();
        SubmissionManifest actualSubmission = actual.item();

        assertEquals(submissionManifest.getSubmissionId(), actualSubmission.getSubmissionId());
        assertEquals(submissionManifest.getManifestId(), actualSubmission.getManifestId());
        assertEquals(submissionManifest.getManifest(), actualSubmission.getManifest());
    }

    @Test
    void shouldRetrieveSubmissionManifest() {

        String submissionId = UUID.randomUUID().toString();
        manifestDao.retrieveSubmissionManifest(submissionId);
        ArgumentCaptor<GetItemEnhancedRequest> captor = ArgumentCaptor.captor();

        verify(mockSubmissionManifestTable, times(1)).getItem(captor.capture());

        GetItemEnhancedRequest actual = captor.getValue();
        assertEquals(submissionId, actual.key().partitionKeyValue().s());
    }

    @Test
    public void shouldRetrieveSubmissionSummaryBySubmissionId() {
        String submissionId = UUID.randomUUID().toString();
        manifestDao.retrieveSubmissionSummaryBySubmissionId(submissionId);
        ArgumentCaptor<GetItemEnhancedRequest> captor = ArgumentCaptor.captor();

        verify(mockSubmissionSummaryTable, times(1)).getItem(captor.capture());
        verify(mockSubmissionManifestTable, never()).getItem(any(GetItemEnhancedRequest.class));

        GetItemEnhancedRequest actual = captor.getValue();
        assertEquals(submissionId, actual.key().partitionKeyValue().s());
    }

    @Test
    public void shouldRetrieveSubmissinIdBasedOnManifestId(){
        ArgumentCaptor<QueryConditional> captor = ArgumentCaptor.forClass(QueryConditional.class);

        var id = "submission-manifest-id-to-check";

        DynamoDbIndex<SubmissionSummary> mockIndex = mock(DynamoDbIndex.class);
        when(mockSubmissionSummaryTable.index("summary_by_manifestId")).thenReturn(mockIndex);

        manifestDao.retrieveSubmissionSummaryByManifestId(id);
        verify(mockIndex).query(captor.capture());

        QueryConditional query = captor.getValue();
        assertThat(query).isEqualTo(QueryConditional.keyEqualTo(Key.builder().partitionValue(id).build()));
        
    }

}
