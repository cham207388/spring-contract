package gov.dhs.uscis.lockboxgateway.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import gov.dhs.uscis.intake.entities.submissionmanifest.manifest.ManifestError;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.ManifestStatus;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.EntityType;
import gov.dhs.uscis.intake.models.SubmissionManifestResponse;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.intake.models.SubmissionUpdateRequest;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;

@ExtendWith(MockitoExtension.class)
public class SubmissionManifestUtilTest {

    private static final String TEST_SUBMISSION_ID = "b1f7cb67-a1e2-3b9e-a2a3-16c170425a4d";

    private static final String FORMTYPE = "FORMTYPE";

    SubmissionManifest submissionManifest;

    Manifest manifest;

    Statuses statuses;

    ManifestStatus status;

    ManifestError manifestError;

    SubmissionManifestResponse submissionManifestResponse;

    SubmissionStatus submissionStatus;

    SubmissionStatus submissionManifestStatus;

    List<ManifestError> manifestErrorList;

    @BeforeEach
    void setUp() {
        manifestErrorList = new ArrayList<>();
        String lockBoxId = "321321";

        manifestError = new ManifestError();
        manifestError.setId("123");
        manifestError.setErrorCode("ERROR");
        manifestError.setDescription("ERRORCODE");
        manifestErrorList.add(manifestError);

        manifest = new Manifest();
        statuses = new Statuses();
        status = new ManifestStatus();

        status.setStatus(StatusEnum.ERROR);
        status.setErrors(manifestErrorList);

        statuses.setManifestStatus(status);

        submissionManifestStatus = new SubmissionStatus();

        ApplicationStatus appStatus = new ApplicationStatus();
        List<RejectionReason> rejectList = new ArrayList<>();
        List<ApplicationStatus> appList = new ArrayList<>();
        RejectionReason reject = new RejectionReason();
        reject.setCode("CODE");
        reject.setReason("REASON");
        rejectList.add(reject);
        appStatus.setUscisId("USC5678");
        appStatus.setStatus(StatusEnum.ACCEPTED);
        appStatus.setFormType(FORMTYPE);
        appStatus.setRejectionReasons(rejectList);
        appList.add(appStatus);
        submissionManifestStatus.setApplicationStatuses(appList);
        submissionManifestStatus.setStatus(StatusEnum.ACCEPTED);
        submissionManifestStatus.setTotalCost(BigDecimal.valueOf(100.00));
        statuses.setSubmissionStatus(submissionManifestStatus);

        submissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                .submissionId(TEST_SUBMISSION_ID)
                .myUscisId("uscisid")
                .manifest(manifest)
                .statuses(statuses)
                .build();

        submissionManifestResponse = SubmissionManifestResponse.builder().status(StatusEnum.ERROR).build();

        var appSubmissionStatus = new gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus();
        var rejectSubmissionList = new ArrayList<>();
        List<gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus> appSubmissionList = new ArrayList<gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus>();
        var rejectSubmission = new RejectionReason();
        rejectSubmission.setCode("CODE");
        rejectSubmission.setReason("REASON");
        rejectSubmissionList.add(rejectSubmission);
        appSubmissionStatus.setUscisId("USC5678");
        appSubmissionStatus.setStatus(StatusEnum.ACCEPTED);
        appSubmissionStatus.setFormType(FORMTYPE);
        appSubmissionStatus.setRejectionReasons(java.util.Arrays.asList(rejectSubmission));
        appSubmissionList.add(appSubmissionStatus);

        submissionStatus = new SubmissionStatus("COR1234", "321321", StatusEnum.ACCEPTED, appSubmissionList, List.of(),
                new BigDecimal(0));

    }

    @Test
    void testCreateSubmissionUpdateRequestForManifest() {
        SubmissionUpdateRequest submissionUpdateRequest = SubmissionManifestUtil
                .createSubmissionUpdateRequestforManifest(submissionManifest, submissionManifestResponse);
        assertEquals("321321", submissionUpdateRequest.getManifestUpdate().getLockboxId());
        assertEquals(StatusEnum.ERROR, submissionUpdateRequest.getManifestUpdate().getStatus());
        assertNotNull(submissionUpdateRequest.getManifestUpdate().getErrors());

        assertEquals(1, submissionUpdateRequest.getManifestUpdate().getErrors().size());
        assertEquals("ERRORCODE", submissionUpdateRequest.getManifestUpdate().getErrors().get(0).getDescription());

        // TODO Discuss with Odwayne, not sure what the error codes should be.
        // assertEquals(StatusEnum.ERROR,
        // submissionUpdateRequest.getManifestUpdate().getErrors().get(0).getErrorCode());
        assertEquals(EntityType.MANIFEST, submissionUpdateRequest.getUpdateType());
    }

    @Test
    void testCreateSubmissionUpdateRequestforSubmission() {
        SubmissionUpdateRequest submissionUpdateRequest = SubmissionManifestUtil
                .createSubmissionUpdateRequestForSubmission(submissionManifest);
        assertEquals("321321", submissionUpdateRequest.getSubmissionUpdate().getLockboxId());
        assertEquals(StatusEnum.ACCEPTED, submissionUpdateRequest.getSubmissionUpdate().getStatus());
        assertNotNull(submissionUpdateRequest.getSubmissionUpdate().getApplicationStatuses());

        assertEquals(1, submissionUpdateRequest.getSubmissionUpdate().getApplicationStatuses().size());
        assertEquals(StatusEnum.ACCEPTED,
                submissionUpdateRequest.getSubmissionUpdate().getApplicationStatuses().get(0).getStatus());
        assertNotNull(
                submissionUpdateRequest.getSubmissionUpdate().getApplicationStatuses().get(0).getRejectionReasons());
        assertEquals("CODE", submissionUpdateRequest.getSubmissionUpdate().getApplicationStatuses().get(0)
                .getRejectionReasons().get(0).getCode());
        assertEquals("REASON", submissionUpdateRequest.getSubmissionUpdate().getApplicationStatuses().get(0)
                .getRejectionReasons().get(0).getReason());
        assertEquals(EntityType.SUBMISSION, submissionUpdateRequest.getUpdateType());
    }

    @Test
    void testUpdateSubmissionManifestFromsubmissionStatus() {
        submissionManifest = SubmissionManifestUtil.updateSubmissionManifest(submissionManifest, submissionStatus);
        assertEquals(StatusEnum.ACCEPTED, submissionManifest.getStatuses().getSubmissionStatus().getStatus());
        assertNotNull(submissionManifest.getStatuses().getSubmissionStatus().getApplicationStatuses());
        assertEquals(1, submissionManifest.getStatuses().getSubmissionStatus().getApplicationStatuses().size());
        assertEquals(StatusEnum.ACCEPTED,
                submissionManifest.getStatuses().getSubmissionStatus().getApplicationStatuses().get(0).getStatus());
        assertNotNull(submissionManifest.getStatuses().getSubmissionStatus().getApplicationStatuses().get(0)
                .getRejectionReasons());
        assertEquals("CODE", submissionManifest.getStatuses().getSubmissionStatus().getApplicationStatuses().get(0)
                .getRejectionReasons().get(0).getCode());
        assertEquals("REASON", submissionManifest.getStatuses().getSubmissionStatus().getApplicationStatuses().get(0)
                .getRejectionReasons().get(0).getReason());
    }

    @Test
    void shouldUpdateSubmissionManifestWithUscisReceiptNumberInSubmissionStatus() {
        String uscisReceiptNumber = "IOE-141241241241";
        var appSubmissionStatus = new gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus();
        var rejectSubmissionList = new ArrayList<>();
        List<gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus> appSubmissionList = new ArrayList<gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus>();
        var rejectSubmission = new RejectionReason();
        rejectSubmissionList.add(rejectSubmission);
        appSubmissionStatus.setUscisId("USC5678");
        appSubmissionStatus.setStatus(StatusEnum.ACCEPTED);
        appSubmissionStatus.setFormType(FORMTYPE);
        appSubmissionStatus.setUscisReceiptNumber(uscisReceiptNumber);
        appSubmissionStatus.setRejectionReasons(java.util.Arrays.asList(rejectSubmission));
        appSubmissionList.add(appSubmissionStatus);

        submissionStatus = new SubmissionStatus("COR1234", "321321",  StatusEnum.ACCEPTED, appSubmissionList, List.of(), new BigDecimal(0));
        SubmissionManifest updateSubmissionManifest = SubmissionManifestUtil.updateSubmissionManifest(submissionManifest, submissionStatus);
        assertThat(updateSubmissionManifest.getStatuses().getSubmissionStatus().getApplicationStatuses().getFirst().getUscisReceiptNumber()).isEqualTo(uscisReceiptNumber);
    }

}
