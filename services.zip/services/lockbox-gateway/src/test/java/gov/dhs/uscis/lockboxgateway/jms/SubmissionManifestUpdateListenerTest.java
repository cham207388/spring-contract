package gov.dhs.uscis.lockboxgateway.jms;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;
import java.util.function.Function;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.ManifestStatus;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.SubmissionManifestResponse;
import gov.dhs.uscis.lockboxgateway.service.SubmissionManifestService;
import jakarta.jms.JMSException;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

@ExtendWith(MockitoExtension.class)
class SubmissionManifestUpdateListenerTest {

        @Mock
        DynamoDbTable<SubmissionManifest> mockDynamoDbTable;

        @Mock
        WebClient mockWebClient;

        @Mock
        SubmissionManifestService mockService;

        @Mock
        private WebClient.RequestBodyUriSpec bodyUriSpec;

        @Mock
        private WebClient.RequestBodySpec bodySpec;

        @SuppressWarnings("rawtypes")
        @Mock
        private WebClient.RequestHeadersSpec headerSpec;

        @Mock
        private ClientResponse clientResponse;

        @InjectMocks
        SubmissionManifestUpdateListener listener;

        @Captor
        ArgumentCaptor<Function<ClientResponse, Mono<Void>>> captor;

        @SuppressWarnings("unchecked")
        @BeforeEach
        void setUp() {
                when(mockWebClient.put()).thenReturn(bodyUriSpec);
                when(bodyUriSpec.uri(anyString())).thenReturn(bodySpec);
                when(bodySpec.bodyValue(any())).thenReturn(headerSpec);
                when(clientResponse.toBodilessEntity()).thenReturn(Mono.empty());
        }

        @SuppressWarnings({ "unchecked" })
        @Test
        void shouldCallSubmissionServiceWithPutSubmissionUpdateRequest() throws JMSException {
                String uscisId = UUID.randomUUID().toString();
                String lockBoxId = UUID.randomUUID().toString();
                String submissionId = UUID.randomUUID().toString();
                Manifest manifest = new Manifest();
                Statuses statuses = new Statuses();
                ManifestStatus status = new ManifestStatus();
                statuses.setManifestStatus(status);

                SubmissionManifestResponse submissionManifestResponse = new SubmissionManifestResponse(uscisId,
                                StatusEnum.COMPLETE,
                                new ArrayList<>(Arrays.asList()));
                SubmissionManifest submissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                                .submissionId(submissionId).myUscisId(uscisId).manifest(manifest)
                                .statuses(statuses)
                                .build();

                when(mockService.updateSubmissionManifestWithManifestStatus(any(SubmissionManifestResponse.class)))
                                .thenReturn(submissionManifest);
                when(clientResponse.statusCode()).thenReturn(HttpStatus.OK);
                when(headerSpec.exchangeToMono(captor.capture())).thenAnswer(invocation -> {
                        Function<ClientResponse, Mono<Void>> func = invocation.getArgument(0);
                        return func.apply(clientResponse);
                });

                listener.fromMessage(submissionManifestResponse);

                verify(mockWebClient.put(), times(1))
                                .uri("/api/v1/" + uscisId + "/submissions/" + submissionId + "/lockbox-status");
        }

        @SuppressWarnings("unchecked")
        @Test
        void testFromMessage_Non2xxCode() {
                String uscisId = "uscis_id";
                String lockBoxId = "lockbox_id";
                String submissionId = "submission_id";
                Manifest manifest = new Manifest();
                Statuses statuses = new Statuses();
                ManifestStatus status = new ManifestStatus();
                statuses.setManifestStatus(status);

                SubmissionManifestResponse submissionManifestResponse = new SubmissionManifestResponse(uscisId,
                                StatusEnum.COMPLETE,
                                new ArrayList<>(Arrays.asList()));
                SubmissionManifest submissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                                .submissionId(submissionId).myUscisId(uscisId).manifest(manifest)
                                .statuses(statuses)
                                .build();

                when(mockService.updateSubmissionManifestWithManifestStatus(any(SubmissionManifestResponse.class)))
                                .thenReturn(submissionManifest);
                when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
                when(headerSpec.exchangeToMono(captor.capture())).thenAnswer(invocation -> {
                        Function<ClientResponse, Mono<Void>> func = invocation.getArgument(0);
                        return func.apply(clientResponse);
                });

                assertThrows(RuntimeException.class, () -> {
                        listener.fromMessage(submissionManifestResponse);
                });

        }

}
