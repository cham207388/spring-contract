package gov.dhs.uscis.lockboxgateway.jms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Function;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.intake.models.SubmissionStatusResponse;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;
import gov.dhs.uscis.lockboxgateway.service.SubmissionStatusService;
import jakarta.jms.JMSException;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

@ExtendWith(MockitoExtension.class)
class SubmissionStatusUpdateListenerTest {

        @Mock
        DynamoDbTable<SubmissionManifest> mockDynamoDbTable;

        @Mock
        WebClient mockWebClient;

        @Mock
        SubmissionStatusService mockService;

        @Mock
        SubmissionStatusPublisher submissionStatusPublisher;

        @Mock
        private WebClient.RequestBodyUriSpec bodyUriSpec;

        @Mock
        private WebClient.RequestBodySpec bodySpec;

        @SuppressWarnings("rawtypes")
        @Mock
        private WebClient.RequestHeadersSpec headerSpec;

        @Mock
        private ClientResponse clientResponse;

        @InjectMocks
        SubmissionStatusUpdateListener listener;

        @Captor
        ArgumentCaptor<Function<ClientResponse, Mono<Void>>> captor;

        @BeforeEach
        public void setup() {
                ReflectionTestUtils.setField(listener, "submissionResponseQueue", "PublisherQueue");
        }

        @SuppressWarnings({ "unchecked" })
        @Test
        void shouldCallSubmissionServiceWithPutSubmissionUpdateRequest() throws JMSException {
                String uscisId = UUID.randomUUID().toString();
                String lockBoxId = UUID.randomUUID().toString();
                String submissionId = UUID.randomUUID().toString();
                Manifest manifest = new Manifest();
                Statuses statuses = new Statuses();
                SubmissionStatus status = new SubmissionStatus();
                status.setStatus(StatusEnum.valueOf("ACCEPTED"));
                // status.setTotalCost(BigDecimal.valueOf(100.00));
                statuses.setSubmissionStatus(status);

                ApplicationStatus appStatus = new ApplicationStatus();

                List<RejectionReason> rejectList = new ArrayList<>();
                List<ApplicationStatus> appList = new ArrayList<>();
                RejectionReason reject = new RejectionReason();
                reject.setCode("CODE");
                reject.setReason("REASON");
                rejectList.add(reject);
                appStatus.setUscisId("USC5678");
                appStatus.setStatus(StatusEnum.ACCEPTED);
                appStatus.setFormType("FORMTYPE");
                appStatus.setRejectionReasons(rejectList);
                appList.add(appStatus);

                SubmissionStatus submissionStatus = new SubmissionStatus(
                                "COR1234", "USC1234", StatusEnum.ACCEPTED, appList, List.of(), new BigDecimal(0));
                SubmissionManifest submissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                                .submissionId(submissionId).myUscisId(uscisId.toLowerCase()).manifest(manifest)
                                .statuses(statuses)
                                .build();
                when(mockWebClient.put()).thenReturn(bodyUriSpec);
                when(bodyUriSpec.uri(anyString())).thenReturn(bodySpec);
                when(bodySpec.bodyValue(any())).thenReturn(headerSpec);
                when(mockService.updateSubmissionManifestWithSubmissionStatus(any(SubmissionStatus.class)))
                                .thenReturn(submissionManifest);

                when(clientResponse.statusCode()).thenReturn(HttpStatus.OK);
                when(clientResponse.toBodilessEntity()).thenReturn(Mono.empty());
                when(headerSpec.exchangeToMono(captor.capture())).thenAnswer(invocation -> {
                        Function<ClientResponse, Mono<Void>> func = invocation.getArgument(0);
                        return func.apply(clientResponse);
                });

                listener.fromMessage(submissionStatus);

                verify(mockWebClient.put(), times(1))
                                .uri("/api/v1/" + uscisId + "/submissions/" + submissionId + "/lockbox-status");
                verify(submissionStatusPublisher).publishSubmissionResponse(eq("PublisherQueue"),
                                any(SubmissionStatusResponse.class), eq(submissionId));

        }

        @SuppressWarnings({ "unchecked" })
        @Test
        void shouldCallSubmissionServiceWithPutSubmissionUpdateRequest_badRequest() {
                String uscisId = UUID.randomUUID().toString();
                String lockBoxId = UUID.randomUUID().toString();
                String submissionId = UUID.randomUUID().toString();
                Manifest manifest = new Manifest();
                Statuses statuses = new Statuses();
                SubmissionStatus status = new SubmissionStatus();
                status.setStatus(StatusEnum.valueOf("ACCEPTED"));
                statuses.setSubmissionStatus(status);

                ApplicationStatus appStatus = new ApplicationStatus();

                List<RejectionReason> rejectList = new ArrayList<>();
                List<ApplicationStatus> appList = new ArrayList<>();
                RejectionReason reject = new RejectionReason();
                reject.setCode("CODE");
                reject.setReason("REASON");
                rejectList.add(reject);
                appStatus.setUscisId("USC5678");
                appStatus.setStatus(StatusEnum.ACCEPTED);
                appStatus.setFormType("FORMTYPE");
                appStatus.setRejectionReasons(rejectList);
                appList.add(appStatus);

                SubmissionStatus submissionStatus = new SubmissionStatus(
                                "COR1234", "USC1234", StatusEnum.ACCEPTED, appList, List.of(), new BigDecimal(0));
                SubmissionManifest submissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                                .submissionId(submissionId).myUscisId(uscisId.toLowerCase()).manifest(manifest)
                                .statuses(statuses)
                                .build();
                when(mockWebClient.put()).thenReturn(bodyUriSpec);
                when(bodyUriSpec.uri(anyString())).thenReturn(bodySpec);
                when(bodySpec.bodyValue(any())).thenReturn(headerSpec);
                when(mockService.updateSubmissionManifestWithSubmissionStatus(any(SubmissionStatus.class)))
                                .thenReturn(submissionManifest);

                when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
                when(headerSpec.exchangeToMono(captor.capture())).thenAnswer(invocation -> {
                        Function<ClientResponse, Mono<Void>> func = invocation.getArgument(0);
                        return func.apply(clientResponse);
                });

                assertThrows(RuntimeException.class, () -> listener.fromMessage(submissionStatus));

                verify(mockWebClient.put(), times(1))
                                .uri("/api/v1/" + uscisId + "/submissions/" + submissionId + "/lockbox-status");
        }

        @SuppressWarnings({ "unchecked" })
        @Test
        void shouldCallSubmissionServiceWithPutSubmissionUpdateRequest_notFound() {
                String uscisId = UUID.randomUUID().toString();
                String lockBoxId = UUID.randomUUID().toString();
                String submissionId = UUID.randomUUID().toString();
                Manifest manifest = new Manifest();
                Statuses statuses = new Statuses();
                SubmissionStatus status = new SubmissionStatus();
                status.setStatus(StatusEnum.valueOf("ACCEPTED"));
                statuses.setSubmissionStatus(status);

                ApplicationStatus appStatus = new ApplicationStatus();

                List<RejectionReason> rejectList = new ArrayList<>();
                List<ApplicationStatus> appList = new ArrayList<>();
                RejectionReason reject = new RejectionReason();
                reject.setCode("CODE");
                reject.setReason("REASON");
                rejectList.add(reject);
                appStatus.setUscisId("USC5678");
                appStatus.setStatus(StatusEnum.ACCEPTED);
                appStatus.setFormType("FORMTYPE");
                appStatus.setRejectionReasons(rejectList);
                appList.add(appStatus);

                SubmissionStatus submissionStatus = new SubmissionStatus(
                                "COR1234", "USC1234", StatusEnum.ACCEPTED, appList, List.of(), new BigDecimal(0));
                SubmissionManifest submissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                                .submissionId(submissionId).myUscisId(uscisId.toLowerCase()).manifest(manifest)
                                .statuses(statuses)
                                .build();
                when(mockWebClient.put()).thenReturn(bodyUriSpec);
                when(bodyUriSpec.uri(anyString())).thenReturn(bodySpec);
                when(bodySpec.bodyValue(any())).thenReturn(headerSpec);
                when(mockService.updateSubmissionManifestWithSubmissionStatus(any(SubmissionStatus.class)))
                                .thenReturn(submissionManifest);

                when(clientResponse.statusCode()).thenReturn(HttpStatus.NOT_FOUND);
                when(headerSpec.exchangeToMono(captor.capture())).thenAnswer(invocation -> {
                        Function<ClientResponse, Mono<Void>> func = invocation.getArgument(0);
                        return func.apply(clientResponse);
                });

                assertThrows(RuntimeException.class, () -> listener.fromMessage(submissionStatus));

                verify(mockWebClient.put(), times(1))
                                .uri("/api/v1/" + uscisId + "/submissions/" + submissionId + "/lockbox-status");
        }

        @SuppressWarnings({ "unchecked" })
        @Test
        void shouldCallSubmissionServiceWithPutSubmissionUpdateRequest_internalServerError() {
                String uscisId = UUID.randomUUID().toString();
                String lockBoxId = UUID.randomUUID().toString();
                String submissionId = UUID.randomUUID().toString();
                Manifest manifest = new Manifest();
                Statuses statuses = new Statuses();
                SubmissionStatus status = new SubmissionStatus();
                status.setStatus(StatusEnum.valueOf("ACCEPTED"));
                statuses.setSubmissionStatus(status);

                ApplicationStatus appStatus = new ApplicationStatus();

                List<RejectionReason> rejectList = new ArrayList<>();
                List<ApplicationStatus> appList = new ArrayList<>();
                RejectionReason reject = new RejectionReason();
                reject.setCode("CODE");
                reject.setReason("REASON");
                rejectList.add(reject);
                appStatus.setUscisId("USC5678");
                appStatus.setStatus(StatusEnum.ACCEPTED);
                appStatus.setFormType("FORMTYPE");
                appStatus.setRejectionReasons(rejectList);
                appList.add(appStatus);

                SubmissionStatus submissionStatus = new SubmissionStatus(
                                "COR1234", "USC1234", StatusEnum.ACCEPTED, appList, List.of(), new BigDecimal(0));
                SubmissionManifest submissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                                .submissionId(submissionId).myUscisId(uscisId.toLowerCase()).manifest(manifest)
                                .statuses(statuses)
                                .build();
                when(mockWebClient.put()).thenReturn(bodyUriSpec);
                when(bodyUriSpec.uri(anyString())).thenReturn(bodySpec);
                when(bodySpec.bodyValue(any())).thenReturn(headerSpec);
                when(mockService.updateSubmissionManifestWithSubmissionStatus(any(SubmissionStatus.class)))
                                .thenReturn(submissionManifest);

                when(clientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
                when(headerSpec.exchangeToMono(captor.capture())).thenAnswer(invocation -> {
                        Function<ClientResponse, Mono<Void>> func = invocation.getArgument(0);
                        return func.apply(clientResponse);
                });

                assertThrows(RuntimeException.class, () -> listener.fromMessage(submissionStatus));

                verify(mockWebClient.put(), times(1))
                                .uri("/api/v1/" + uscisId + "/submissions/" + submissionId + "/lockbox-status");
        }

        @Test
        void testFromMessage() {
                String uscisId = "uscis_id";
                String lockBoxId = "lockbox_id";
                String submissionId = "submission_id";
                Manifest manifest = new Manifest();
                Statuses statuses = new Statuses();
                SubmissionStatus status = new SubmissionStatus();
                status.setStatus(StatusEnum.valueOf("ACCEPTED"));
                statuses.setSubmissionStatus(status);

                SubmissionStatus submissionStatus = SubmissionStatus.builder().build();
                SubmissionManifest submissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                                .submissionId(submissionId).myUscisId(uscisId).manifest(manifest)
                                .statuses(statuses)
                                .build();



                assertThrows(RuntimeException.class, () -> listener.fromMessage(submissionStatus));
        }
 
        @SuppressWarnings({ "unchecked" })
        @Test
        void shouldCallConvertFormTypeForI129BeforeCallingSubmissionService() throws JMSException {
                String uscisId = UUID.randomUUID().toString();
                String lockBoxId = UUID.randomUUID().toString();
                String submissionId = UUID.randomUUID().toString();
                Manifest manifest = new Manifest();
                Statuses statuses = new Statuses();
                SubmissionStatus status = new SubmissionStatus();
                status.setStatus(StatusEnum.valueOf("ACCEPTED"));
                // status.setTotalCost(BigDecimal.valueOf(100.00));
                statuses.setSubmissionStatus(status);

                ApplicationStatus appStatus = new ApplicationStatus();

                List<RejectionReason> rejectList = new ArrayList<>();
                List<ApplicationStatus> appList = new ArrayList<>();
                RejectionReason reject = new RejectionReason();
                reject.setCode("CODE");
                reject.setReason("REASON");
                rejectList.add(reject);
                appStatus.setUscisId("USC5678");
                appStatus.setStatus(StatusEnum.ACCEPTED);
                appStatus.setFormType("I-129");
                appStatus.setRejectionReasons(rejectList);
                appList.add(appStatus);

                SubmissionStatus submissionStatus = new SubmissionStatus(
                                "COR1234", "USC1234", StatusEnum.ACCEPTED, appList, List.of(), new BigDecimal(0));
                SubmissionManifest submissionManifest = SubmissionManifest.builder().manifestId(lockBoxId)
                                .submissionId(submissionId).myUscisId(uscisId.toLowerCase()).manifest(manifest)
                                .statuses(statuses)
                                .build();
                when(mockWebClient.put()).thenReturn(bodyUriSpec);
                when(bodyUriSpec.uri(anyString())).thenReturn(bodySpec);
                when(bodySpec.bodyValue(any())).thenReturn(headerSpec);
                when(mockService.updateSubmissionManifestWithSubmissionStatus(any(SubmissionStatus.class)))
                                .thenReturn(submissionManifest);

                when(clientResponse.statusCode()).thenReturn(HttpStatus.OK);
                when(clientResponse.toBodilessEntity()).thenReturn(Mono.empty());
                when(headerSpec.exchangeToMono(captor.capture())).thenAnswer(invocation -> {
                        Function<ClientResponse, Mono<Void>> func = invocation.getArgument(0);
                        return func.apply(clientResponse);
                });

                listener.fromMessage(submissionStatus);
                
                ArgumentCaptor<SubmissionStatus> captor = ArgumentCaptor.forClass(SubmissionStatus.class);

                verify(mockService).updateSubmissionManifestWithSubmissionStatus(captor.capture());

                assertThat(captor.getValue().getApplicationStatuses().get(0).getFormType()).isEqualTo("I-129H1B");

                verify(mockWebClient.put(), times(1))
                                .uri("/api/v1/" + uscisId + "/submissions/" + submissionId + "/lockbox-status");

                verify(submissionStatusPublisher).publishSubmissionResponse(eq("PublisherQueue"),
                                any(SubmissionStatusResponse.class), eq(submissionId));

        }

}
