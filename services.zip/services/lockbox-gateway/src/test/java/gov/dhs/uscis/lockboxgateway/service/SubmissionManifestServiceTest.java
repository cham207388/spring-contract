package gov.dhs.uscis.lockboxgateway.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.SubmissionSummary;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.ManifestStatus;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.SubmissionManifestResponse;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.lockboxgateway.jms.JmsMessageProducer;
import jakarta.jms.JMSException;

@ExtendWith(MockitoExtension.class)
class SubmissionManifestServiceTest {
    private static final String QUEUE_NAME = "fake";
    private String submissionId;
    private LockboxTransmission lockboxTransmission;

    @Mock
    private WebClient webClient;

    @Mock
    SubmissionManifestRepository manifestDao;
    
    @Mock
    ELISAutoIngestionTriggerService elisAutoIngestionTriggerService;

    @InjectMocks
    SubmissionManifestService service;

    @BeforeEach
    void setUp() {
        submissionId = "submissionId";
        lockboxTransmission = Instancio.create(LockboxTransmission.class);
        lockboxTransmission.getSubmission().getPrimaryForm().setType(FormType.I765.getType());

        lockboxTransmission.getSubmission().setSubmissionId(submissionId);
    }

    @Test
    void shouldCreateSubmissionManifest() {
        SubmissionManifest response = service.mapTransmissionToManifest(lockboxTransmission);
        verify(manifestDao, times(1)).saveSubmissionManifest(response);
    }

    @Test
    void shouldGetSubmissionManifest() {
        String manifestId = "someManifestId";
        service.getManifest(manifestId);
        verify(manifestDao, times(1)).retrieveSubmissionManifest(manifestId);
    }

    @DisplayName("Should update submissionManifest status in DynamoDB")
    @Test
    void shouldUpdateSubmissionManifestStatus() {
        String uscisId = UUID.randomUUID().toString().toUpperCase();
        SubmissionManifestResponse submissionManifestResponse = new SubmissionManifestResponse(uscisId,
                StatusEnum.COMPLETE,
                new ArrayList<>(Arrays.asList()));
        Statuses statuses = new Statuses();
        ManifestStatus status = new ManifestStatus();
        statuses.setManifestStatus(status);

        SubmissionManifest mockSubmissionManifest = SubmissionManifest.builder().submissionId("12345")
                .myUscisId("myUscisId").statuses(statuses)
                .build();

        when(manifestDao.retrieveSubmissionManifest(uscisId)).thenReturn(mockSubmissionManifest);
        service.updateSubmissionManifestWithManifestStatus(submissionManifestResponse);

        ArgumentCaptor<SubmissionManifest> captor = ArgumentCaptor.captor();
        verify(manifestDao, times(1)).updateSubmissionManifest(captor.capture());

        SubmissionManifest actual = captor.getValue();

        assertNotNull(actual.getStatuses().getManifestStatus().getStatus());
        assertEquals(StatusEnum.COMPLETE, actual.getStatuses().getManifestStatus().getStatus());
    }

    @DisplayName("Should throw NoSuchElementException when submissionManifest is null")
    @Test
    void shouldErrorOnUpdateSubmissionManifestWithStatus_noSuchElementException() {
        SubmissionManifestResponse submissionManifestResponse = new SubmissionManifestResponse(null, null,
                null);

        assertThrows(NoSuchElementException.class,
                () -> service.updateSubmissionManifestWithManifestStatus(submissionManifestResponse));
    }

    @Test
    void shouldPublishMessageToLockBox() throws JMSException {
        JmsMessageProducer producer = mock(JmsMessageProducer.class);
        var sms = new SubmissionManifestService(producer,
                QUEUE_NAME, mock(SubmissionManifestRepository.class), elisAutoIngestionTriggerService);
        SubmissionManifest manifest = mock(SubmissionManifest.class);
        var result = sms.publishToLockbox(manifest, FormType.I765);
        verify(producer).sendMessage(QUEUE_NAME, manifest);
        assertEquals(true, result);
    }

    @Test
    public void shouldReturnTheManifestIdForSubmissionIfThisIsAReplayedTransaction() throws JMSException {
        JmsMessageProducer producer = mock(JmsMessageProducer.class);
        var service = new SubmissionManifestService(producer, QUEUE_NAME, manifestDao, elisAutoIngestionTriggerService);
        String expected = "manifestId";
        var existingSummary = new SubmissionSummary(submissionId, expected);
        when(manifestDao.retrieveSubmissionSummaryBySubmissionId(submissionId)).thenReturn(existingSummary);
        var confirmation = service.validateTransformAndPublish(lockboxTransmission);

        assertThat(confirmation.alreadySubmitted()).isTrue();
        assertThat(confirmation.manifestId()).isEqualTo(expected);

        verify(producer, never()).sendMessage(anyString(), any(SubmissionManifest.class));
    }

    @Test
    public void shouldGenerateAndSaveNewManifestIfThisIsAUniqueTransaction() throws JMSException {
        JmsMessageProducer producer = mock(JmsMessageProducer.class);
        var service = new SubmissionManifestService(producer, QUEUE_NAME, manifestDao, elisAutoIngestionTriggerService);
        when(manifestDao.retrieveSubmissionSummaryBySubmissionId(submissionId)).thenReturn(null);
        var confirmation = service.validateTransformAndPublish(lockboxTransmission);

        assertThat(confirmation.alreadySubmitted()).isFalse();
        assertThat(confirmation.manifestId()).isNotNull();

        verify(producer, times(1)).sendMessage(anyString(), any(SubmissionManifest.class));
    }

    @Test
    public void shouldReturnNullForMessageConfirmationIfTheRequestIsInvalid() throws JMSException {
        JmsMessageProducer producer = mock(JmsMessageProducer.class);
        var service = new SubmissionManifestService(producer, QUEUE_NAME, manifestDao, elisAutoIngestionTriggerService);
        when(manifestDao.retrieveSubmissionSummaryBySubmissionId(submissionId)).thenReturn(null);
        doThrow(new JMSException("test")).when(producer).sendMessage(anyString(), any(SubmissionManifest.class));
        var confirmation = service.validateTransformAndPublish(lockboxTransmission);

        assertThat(confirmation).isNull();
    }

    @Test
    public void checkForExistingConfirmationByManifestId(){
        JmsMessageProducer producer = mock(JmsMessageProducer.class);
        var service = new SubmissionManifestService(producer, QUEUE_NAME, manifestDao, elisAutoIngestionTriggerService);

        SubmissionSummary submissionSummary = mock(SubmissionSummary.class);
        when(submissionSummary.getSubmissionId()).thenReturn(submissionId);
        String manifestId = "manifestId";

        when(manifestDao.retrieveSubmissionSummaryByManifestId(manifestId)).thenReturn(submissionSummary);
        var confirmation = service.checkForExistingConfirmationByManifestId(manifestId);

        assertThat(confirmation.alreadySubmitted()).isEqualTo(true);
        assertThat(confirmation.submissionId()).isEqualTo(submissionId);
    }

    @Test
    public void shouldHandleWhenTheConfirmationIsNotFound(){
        JmsMessageProducer producer = mock(JmsMessageProducer.class);
        var service = new SubmissionManifestService(producer, QUEUE_NAME, manifestDao, elisAutoIngestionTriggerService);

        String manifestId = "manifestId";

        var confirmation = service.checkForExistingConfirmationByManifestId(manifestId);

        assertThat(confirmation).isNull();
    }

    @Test
    public void shouldTriggerAutoIngestionAndSendMessage(){
        JmsMessageProducer producer = mock(JmsMessageProducer.class);
        var service = new SubmissionManifestService(producer, QUEUE_NAME, manifestDao, elisAutoIngestionTriggerService);

        String manifestId = "manifestId";

        SubmissionManifest mockSubmissionManifest = SubmissionManifest.builder().submissionId("12345")
                .myUscisId("myUscisId")
                .build();

        boolean confirmation = service.publishToLockbox(mockSubmissionManifest, FormType.I129H2A);

        verify(elisAutoIngestionTriggerService).publishIngestion(mockSubmissionManifest);
    }
}