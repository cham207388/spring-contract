package gov.dhs.uscis.lockboxgateway.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.FormMetaData;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;


@ExtendWith(MockitoExtension.class)
public class FormMetaDataRepositoryTest {

    @Mock
    DynamoDbTable<FormMetaData> formMetaData;

    FormMetaDataRepository formMetaDatatRepository;

    @BeforeEach
    public void setup() {
       formMetaDatatRepository = new FormMetaDataRepository(formMetaData);
    }

    @SuppressWarnings("null")
    @Test
    void shouldUpdateFormMetaData() {
        FormMetaData expected = FormMetaData.builder().formType(FormType.I765.getType()).enabled(false).build();

        formMetaDatatRepository.update(expected);
        
        ArgumentCaptor<UpdateItemEnhancedRequest<FormMetaData>> captor = ArgumentCaptor.captor();

        verify(formMetaData, times(1)).updateItem(captor.capture());

        UpdateItemEnhancedRequest<FormMetaData> actual = captor.getValue();
        FormMetaData actualUpdate = actual.item();

        assertEquals(actualUpdate.getEnabled(), expected.getEnabled());
    }

    @SuppressWarnings("null")
    @Test
    void shouldRetrieveFormMetaData() {
       String formType = "i-765";

       formMetaDatatRepository.retrieveFormMataData(FormType.I765.getType());

        ArgumentCaptor<GetItemEnhancedRequest> captor = ArgumentCaptor.captor();

        verify(formMetaData, times(1)).getItem(captor.capture());

        GetItemEnhancedRequest actual = captor.getValue();

        assertEquals(formType.toLowerCase(),  actual.key().partitionKeyValue().s().toLowerCase());
    }
}
