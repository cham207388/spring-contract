package gov.dhs.uscis.lockboxgateway.config;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.ActiveMQSslConnectionFactory;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

public class JMSConnectionConfigTest {
 private final ApplicationContextRunner contextRunner = new ApplicationContextRunner();

 @Test
 public void shouldCreateActiveMQConnectionFactoryWhenSslNotEnabled() {
  this.contextRunner
    .withPropertyValues("jms.intake.enable-ssl=false", "spring.activemq.broker-url=activemq.broker-url",
      "activemq.keyStore=keyStore", "spring.activemq.broker-url=broker",
      "spring.activemq.secondary-url=broker-2", "spring.activemq.ternary-url=broker-3",
      "activemq.keyStorePassword=keyStorePassword", "activemq.trustStore=trustStore",
      "activemq.trustStorePassword=trustStorePassword", "spring.activemq.user=username",
      "spring.activemq.password=password")
    .withUserConfiguration(JMSConnectionConfig.class)
    .run(context -> {
      String brokerUrl = "failover:(broker-2,broker,broker-3)?randomize=true";
     assertThat(context).hasBean("localConnectionFactory");
     assertThat(context).doesNotHaveBean("connectionFactory");
     ActiveMQConnectionFactory bean = context.getBean(ActiveMQConnectionFactory.class);
     assertEquals(bean.getBrokerURL(), brokerUrl);
     assertEquals(bean.getUserName(), "username");
     assertEquals(bean.getPassword(), "password");
    });
 }

 @Test
 public void shouldCreateActiveMQSSLConnectionFactoryWhenSslIsEnabled() {
  this.contextRunner.withPropertyValues("jms.intake.enable-ssl=true", "spring.activemq.broker-url=activemq.broker-url",
  "activemq.keyStore=keyStore", "spring.activemq.broker-url=broker",
  "spring.activemq.secondary-url=broker-2", "spring.activemq.ternary-url=broker-3",
  "activemq.keyStorePassword=keyStorePassword", "activemq.trustStore=trustStore",
  "activemq.trustStorePassword=trustStorePassword", "spring.activemq.user=username",
  "spring.activemq.password=password")
    .withUserConfiguration(JMSConnectionConfig.class)
    .run(context -> {
      String brokerUrl = "failover:(broker-2,broker,broker-3)?randomize=true";
     assertThat(context).hasBean("connectionFactory");
     assertThat(context).doesNotHaveBean("localConnectionFactory");
     ActiveMQSslConnectionFactory bean = context.getBean(ActiveMQSslConnectionFactory.class);
     assertEquals(bean.getBrokerURL(), brokerUrl);
     assertEquals(bean.getKeyStore(), "keyStore");
     assertEquals(bean.getKeyStorePassword(), "keyStorePassword");
     assertEquals(bean.getTrustStore(), "trustStore");
     assertEquals(bean.getTrustStorePassword(), "trustStorePassword");
     assertNull(bean.getUserName());
     assertNull(bean.getPassword());
    });
 }
 
}
