package gov.dhs.uscis.lockboxgateway.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;


import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Application;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Statuses;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.ManifestStatus;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.FormMetaData;
import gov.dhs.uscis.intake.models.SubmissionStatus;
import gov.dhs.uscis.intake.models.submissionstatus.ApplicationStatus;
import gov.dhs.uscis.intake.models.submissionstatus.RejectionReason;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;


public class AdminServiceTest {

    private static final String MANIFEST_ID = UUID.randomUUID().toString();
    private static final String SUBMISSION_ID = UUID.randomUUID().toString();
    private static final SubmissionManifestService service = mock(SubmissionManifestService.class);
  
    @Test
    public void shouldResetManifestStatusesWhenResubmitting() {
        SubmissionManifestRepository repository = mock(SubmissionManifestRepository.class);
        
        Statuses statuses = mock(Statuses.class);
        SubmissionManifest submissionManifest = SubmissionManifest.builder()
            	.manifest(Manifest.builder()
            			.applications(
            					Arrays.asList(Application.builder()
            							.formType(FormType.I765.getType())
            							.build())
            					)
            			.build())
            	.submissionId(SUBMISSION_ID)
            	.statuses(statuses)
            	.build();

        SubmissionStatus submissionStatus = SubmissionStatus.builder()
                .status(StatusEnum.REJECTED)
                .applicationStatuses(Lists.newArrayList(ApplicationStatus.builder()
                        .formType(FormType.I765.getType())
                        .status(StatusEnum.REJECTED)
                        .rejectionReasons(Lists.newArrayList(RejectionReason.builder()
                                .code("code")
                                .reason("reason")
                                .build()))
                        .build(),
                        ApplicationStatus.builder()
                                .formType("797")
                                .status(StatusEnum.REJECTED)
                                .rejectionReasons(Lists.newArrayList(RejectionReason.builder()
                                        .code("code")
                                        .reason("reason")
                                        .build()))
                                .build(), ApplicationStatus.builder()
                                .formType("cc")
                                .status(StatusEnum.REJECTED)
                                .rejectionReasons(Lists.newArrayList(RejectionReason.builder()
                                        .code("code")
                                        .reason("reason")
                                        .build()))
                                .build()))
                .build();
        ManifestStatus manifestStatus = ManifestStatus.builder().status(StatusEnum.COMPLETE).build();

        when(statuses.getManifestStatus()).thenReturn(manifestStatus);
        when(statuses.getSubmissionStatus()).thenReturn(submissionStatus);
        when(repository.retrieveSubmissionManifest(MANIFEST_ID)).thenReturn(submissionManifest);
        var adminService = new AdminService(repository, service, null);

        adminService.resubmitById(MANIFEST_ID);
        ArgumentCaptor<SubmissionManifest> captor = ArgumentCaptor.forClass(SubmissionManifest.class);
        verify(repository).updateSubmissionManifest(captor.capture());
        SubmissionManifest savedManifest = captor.getValue();
        Statuses savedStatuses = savedManifest.getStatuses();
        SubmissionStatus submissionStatuses = savedStatuses.getSubmissionStatus();
        ApplicationStatus applicationStatus = submissionStatuses.getApplicationStatuses().getFirst();

        verify(service).publishToLockbox(savedManifest, FormType.I765);
        assertThat(savedStatuses.getManifestStatus().getStatus()).isEqualTo(StatusEnum.PUBLISHED);
        assertThat(submissionStatuses.getStatus()).isEqualTo(StatusEnum.RECEIVED);
        assertThat(submissionStatuses.getApplicationStatuses().size()).isEqualTo(1);
        assertThat(applicationStatus.getFormType()).isEqualTo(FormType.I765.getType());
        assertThat(applicationStatus.getRejectionReasons()).isNull();
        assertThat(applicationStatus.getStatus()).isEqualTo(StatusEnum.RECEIVED);
        assertThat(applicationStatus.getUscisId()).isEqualTo(SUBMISSION_ID);
    }

    @Test
    public void shouldResetManifestStatusesWhenResubmittingAListOfIds() {
        SubmissionManifestRepository repository = mock(SubmissionManifestRepository.class);
        Statuses statuses = mock(Statuses.class);

        SubmissionStatus submissionStatus = SubmissionStatus.builder()
                .status(StatusEnum.REJECTED)
                .applicationStatuses(Lists.newArrayList(ApplicationStatus.builder()
                        .formType(FormType.I765.getType())
                        .status(StatusEnum.REJECTED)
                        .rejectionReasons(Lists.newArrayList(RejectionReason.builder()
                                .code("code")
                                .reason("reason")
                                .build()))
                        .build(),
                        ApplicationStatus.builder()
                                .formType("797")
                                .status(StatusEnum.REJECTED)
                                .rejectionReasons(Lists.newArrayList(RejectionReason.builder()
                                        .code("code")
                                        .reason("reason")
                                        .build()))
                                .build(), ApplicationStatus.builder()
                                .formType("cc")
                                .status(StatusEnum.REJECTED)
                                .rejectionReasons(Lists.newArrayList(RejectionReason.builder()
                                        .code("code")
                                        .reason("reason")
                                        .build()))
                                .build()))
                .build();
        ManifestStatus manifestStatus = ManifestStatus.builder().status(StatusEnum.COMPLETE).build();
        String manifestIdB = UUID.randomUUID().toString();

        SubmissionManifest submissionManifestA = SubmissionManifest.builder()
            	.manifest(Manifest.builder()
            			.applications(
            					Arrays.asList(Application.builder()
            							.formType(FormType.I765.getType())
            							.build())
            					)
            			.build())
            	.submissionId(SUBMISSION_ID)
            	.statuses(statuses)
            	.build();
        
        SubmissionManifest submissionManifestB = SubmissionManifest.builder()
            	.manifest(Manifest.builder()
            			.applications(
            					Arrays.asList(Application.builder()
            							.formType(FormType.I765.getType())
            							.build())
            					)
            			.build())
            	.submissionId(manifestIdB)
            	.statuses(statuses)
            	.build();
        
        when(statuses.getManifestStatus()).thenReturn(manifestStatus);
        when(statuses.getSubmissionStatus()).thenReturn(submissionStatus);
        when(repository.retrieveSubmissionManifest(MANIFEST_ID)).thenReturn(submissionManifestA);
        when(repository.retrieveSubmissionManifest(manifestIdB)).thenReturn(submissionManifestB);
        when(service.publishToLockbox(any(SubmissionManifest.class), eq(FormType.I765))).thenReturn(true);
        var adminService = new AdminService(repository, service, null);

        List<Map<String, Boolean>> response = adminService.resubmitByIds(List.of(MANIFEST_ID, manifestIdB));
        
        assertThat(response.size()).isEqualTo(2);
        assertThat(response.stream().filter(r -> r.containsKey(MANIFEST_ID)).findFirst().get().get(MANIFEST_ID)).isTrue();
        assertThat(response.stream().filter(r -> r.containsKey(manifestIdB)).findFirst().get().get(manifestIdB)).isTrue();
        ArgumentCaptor<SubmissionManifest> captor = ArgumentCaptor.forClass(SubmissionManifest.class);
        verify(repository, times(2)).updateSubmissionManifest(captor.capture());
        List<SubmissionManifest> savedManifests = captor.getAllValues();
        assertThat(savedManifests.size()).isEqualTo(2);
        verify(service, times(2)).publishToLockbox(any(SubmissionManifest.class), eq(FormType.I765));
    }

    @Test
    void shouldUpdateIsEnableFormMetaData() {
        SubmissionManifestRepository repository = mock(SubmissionManifestRepository.class);
        FormMetaDataRepository FormMetaDataRepo = mock(FormMetaDataRepository.class);
        AdminService adminService = new AdminService(repository, service, FormMetaDataRepo );
        

        //check if we can retrieve form meta data
        FormMetaData expected = FormMetaData.builder().formType(FormType.I765.getType()).enabled(true).build();
        FormMetaData actual = FormMetaData.builder().formType(FormType.I765.getType()).build();
        when(FormMetaDataRepo.retrieveFormMataData(FormType.I765.getType())).thenReturn(actual);
        
        //check if we can update formmetadata
        adminService.updateFormMetadataEnable(FormType.I765.getType(),true);
        FormMetaData updatedFormMetaData = FormMetaDataRepo.retrieveFormMataData(FormType.I765.getType());


        assertThat(updatedFormMetaData).isEqualTo(expected);
    }
}
