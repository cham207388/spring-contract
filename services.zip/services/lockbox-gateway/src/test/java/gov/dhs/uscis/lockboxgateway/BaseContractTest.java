package gov.dhs.uscis.lockboxgateway;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.models.ManifestPublishedConfirmation;
import gov.dhs.uscis.intake.models.dto.LockboxTransmission;
import gov.dhs.uscis.lockboxgateway.config.TestConfig;
import gov.dhs.uscis.lockboxgateway.controller.LockBoxGatewayController;
import gov.dhs.uscis.lockboxgateway.service.SubmissionManifestService;
import io.restassured.module.mockmvc.RestAssuredMockMvc;

@SpringBootTest
@ContextConfiguration(classes = TestConfig.class)
public abstract class BaseContractTest {

    @Autowired
    private LockBoxGatewayController lockBoxGatewayController;

    @MockitoBean
    private SubmissionManifestService submissionManifestService;

    @BeforeEach
    void setUp() {
        RestAssuredMockMvc.standaloneSetup(lockBoxGatewayController);
        when(submissionManifestService.validateTransformAndPublish(any(LockboxTransmission.class))).thenReturn(new ManifestPublishedConfirmation(UUID.randomUUID().toString(),UUID.randomUUID().toString(), false));
    }

    private SubmissionManifest mockSubManifest() {
        SubmissionManifest response = new SubmissionManifest();
        response.setSubmissionId("submissionId");
        response.setManifestId(UUID.randomUUID().toString());
        response.setMyUscisId("myuscisId");
        response.setStatuses(null);
        response.setManifest(null);
        return response;
    }
}
