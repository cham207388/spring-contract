package gov.dhs.uscis.lockboxgateway.jms;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.core.JmsTemplate;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import jakarta.jms.JMSException;

@ExtendWith(MockitoExtension.class)
public class JmsMessageProducerTest {
    static final String DESTINATION = "1234";

    @Mock
    JmsTemplate jmsTemplate;
    @InjectMocks
    JmsMessageProducer messageProducer;

    @Test
    void testSendMessageString() throws JMSException {
        Manifest manifest = Manifest.builder().manifestId(UUID.randomUUID().toString()).build();
        doNothing().when(jmsTemplate).convertAndSend(anyString(), any(Manifest.class));
        messageProducer.sendMessage(DESTINATION, SubmissionManifest.builder().manifest(manifest).build());
        verify(jmsTemplate, times(1)).convertAndSend(DESTINATION, manifest);
    }
}
