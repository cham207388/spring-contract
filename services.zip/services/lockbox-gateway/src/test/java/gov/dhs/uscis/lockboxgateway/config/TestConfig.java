package gov.dhs.uscis.lockboxgateway.config;

import static org.mockito.Mockito.mock;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import gov.dhs.uscis.lockboxgateway.controller.LockBoxGatewayController;
import gov.dhs.uscis.lockboxgateway.service.SubmissionManifestService;


@Configuration
public class TestConfig {

    @Bean
    public SubmissionManifestService submissionManifestService() {
        return mock(SubmissionManifestService.class);
    }

    @Bean
    public LockBoxGatewayController lockBoxGatewayController(SubmissionManifestService submissionManifestService) {
        return new LockBoxGatewayController(submissionManifestService);
    }
}
