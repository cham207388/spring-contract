package gov.dhs.uscis.lockboxgateway.controller;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.models.FormMetaData;

import gov.dhs.uscis.lockboxgateway.service.AdminService;
import gov.dhs.uscis.lockboxgateway.service.ELISAutoIngestionTriggerService;

public class AdminControllerTest {

    static final String I765 = "I-765";
 
    @Test
    public void shouldIssueARequestToSubmitAManifestBasedOnId() throws Exception{
        AdminService service = mock(AdminService.class);
        ELISAutoIngestionTriggerService autoIngestionService = mock(ELISAutoIngestionTriggerService.class);
        when(service.resubmitById(anyString())).thenReturn(true);
        
        var controller = MockMvcBuilders.standaloneSetup( new AdminController(service, autoIngestionService)).build();

        controller.perform(MockMvcRequestBuilders.post("/api/v1/administration/manifest/fake-id")
        .contentType(MediaType.APPLICATION_JSON).content("{\"action\":\"Resubmit\"}"))
        .andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
    }

    @Test
    public void shouldReturnA400IfSubmissionDidNotPublish() throws Exception{
        AdminService service = mock(AdminService.class);
        ELISAutoIngestionTriggerService autoIngestionService = mock(ELISAutoIngestionTriggerService.class);
        when(service.resubmitById(anyString())).thenReturn(false);
        
        var controller = MockMvcBuilders.standaloneSetup( new AdminController(service, autoIngestionService)).build();

        controller.perform(MockMvcRequestBuilders.post("/api/v1/administration/manifest/fake-id")
        .contentType(MediaType.APPLICATION_JSON).content("{\"action\":\"Resubmit\"}"))
        .andExpect(MockMvcResultMatchers.status().is5xxServerError());
    }

    @Test
    public void shouldIssueRequestsToSubmitManifestsBasedOnIds() throws Exception{
        AdminService service = mock(AdminService.class);
        ELISAutoIngestionTriggerService autoIngestionService = mock(ELISAutoIngestionTriggerService.class);
        when(service.resubmitByIds(anyList())).thenReturn(List.of(Map.of("fake1", true, "fake2", true)));
        
        var controller = MockMvcBuilders.standaloneSetup( new AdminController(service, autoIngestionService)).build();

        AdminServiceMultipleControlRequest request = new AdminServiceMultipleControlRequest(ServiceAction.Resubmit, List.of("fakeId1", "fakeId2"));
        controller.perform(MockMvcRequestBuilders.post("/api/v1/administration/manifest")
        .contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(request)))
        .andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
    }

    @Test
    void shouldReturnSuccessfulUpdateMetadataEnable() throws Exception {

        AdminService service = mock(AdminService.class);
        ELISAutoIngestionTriggerService autoIngestionService = mock(ELISAutoIngestionTriggerService.class);

        when(service.updateFormMetadataEnable(I765, false)).thenReturn(FormMetaData.builder().formType(I765).enabled(false).build());

        var controller = MockMvcBuilders.standaloneSetup( new AdminController(service, autoIngestionService)).build();
        controller.perform(MockMvcRequestBuilders.patch("/api/v1/administration/{formType}/metadata/enabled", I765)
        .contentType(MediaType.APPLICATION_JSON).content("{\"enabled\":\"false\"}"))
        .andExpect(MockMvcResultMatchers.status().is2xxSuccessful()).andExpect(jsonPath("$.enabled").value(false));
    }
}
