package gov.dhs.uscis.lockboxgateway.jms.publisher;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.jms.core.JmsTemplate;


public class PaymentTransactionStatusPublisherTest {

    private static final String TEST_QUEUE = "fakeQueue";

    @Test
    public void shouldPublishAMessageWhenSuccessful(){
        JmsTemplate jmsTemplate = mock(JmsTemplate.class);
        var publisher = new PaymentTransactionStatusPublisher(jmsTemplate, TEST_QUEUE);

        publisher.publishPaymentAccepted("correlationId","uscisId");
        ArgumentCaptor<Object> cap = ArgumentCaptor.forClass(Object.class);
        ArgumentCaptor<String> queue = ArgumentCaptor.forClass(String.class);
        verify(jmsTemplate).convertAndSend(queue.capture(), cap.capture());

        var message = (LockboxSubmissionPaymentProcessedEvent) cap.getValue();
        assertInstanceOf(LockboxSubmissionPaymentProcessedEvent.class, message);
        assertEquals(message.correlationId(), "correlationId");
        assertEquals(message.uscisId(), "uscisId");
        assertEquals(message.providerStatus(), "SUCCESS");
        assertEquals(queue.getValue(), TEST_QUEUE);
    }

    @Test
    public void shouldPublishAMessageWhenDeclined(){
        JmsTemplate jmsTemplate = mock(JmsTemplate.class);
        var publisher = new PaymentTransactionStatusPublisher(jmsTemplate, TEST_QUEUE);

        publisher.publishPaymentDeclined("correlationId","uscisId");
        ArgumentCaptor<Object> cap = ArgumentCaptor.forClass(Object.class);
        ArgumentCaptor<String> queue = ArgumentCaptor.forClass(String.class);
        verify(jmsTemplate).convertAndSend(queue.capture(), cap.capture());

        var message = (LockboxSubmissionPaymentProcessedEvent) cap.getValue();
        assertInstanceOf(LockboxSubmissionPaymentProcessedEvent.class, message);
        assertEquals(message.correlationId(), "correlationId");
        assertEquals(message.uscisId(), "uscisId");
        assertEquals(message.providerStatus(), "FAILURE");
        assertEquals(queue.getValue(), TEST_QUEUE);
    }

    @Test
    public void shouldPublishAMessageWhenError(){
        JmsTemplate jmsTemplate = mock(JmsTemplate.class);
        var publisher = new PaymentTransactionStatusPublisher(jmsTemplate, TEST_QUEUE);

        publisher.publishPaymentError("correlationId","uscisId");
        ArgumentCaptor<Object> cap = ArgumentCaptor.forClass(Object.class);
        ArgumentCaptor<String> queue = ArgumentCaptor.forClass(String.class);
        verify(jmsTemplate).convertAndSend(queue.capture(), cap.capture());

        var message = (LockboxSubmissionPaymentProcessedEvent) cap.getValue();
        assertInstanceOf(LockboxSubmissionPaymentProcessedEvent.class, message);
        assertEquals(message.correlationId(), "correlationId");
        assertEquals(message.uscisId(), "uscisId");
        assertEquals(message.providerStatus(), "FAILURE");
        assertEquals(queue.getValue(), TEST_QUEUE);
    }

    @Test
    public void shouldPostCancelMessageToLockBox(){
        JmsTemplate jmsTemplate = mock(JmsTemplate.class);
        var publisher = new PaymentTransactionStatusPublisher(jmsTemplate, TEST_QUEUE);

        publisher.publishPaymentCanceled("correlationId","uscisId");
        ArgumentCaptor<Object> cap = ArgumentCaptor.forClass(Object.class);
        ArgumentCaptor<String> queue = ArgumentCaptor.forClass(String.class);
        verify(jmsTemplate).convertAndSend(queue.capture(), cap.capture());

        var message = (LockboxSubmissionPaymentProcessedEvent) cap.getValue();
        assertInstanceOf(LockboxSubmissionPaymentProcessedEvent.class, message);
        assertEquals("correlationId", message.correlationId());
        assertEquals("uscisId", message.uscisId());
        assertEquals("SUCCESS", message.providerStatus());
        assertEquals(TEST_QUEUE, queue.getValue());
    }
}
