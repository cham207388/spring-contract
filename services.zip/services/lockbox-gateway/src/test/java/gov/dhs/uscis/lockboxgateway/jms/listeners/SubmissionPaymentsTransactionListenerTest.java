package gov.dhs.uscis.lockboxgateway.jms.listeners;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.audit.ActionPerformed;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import gov.dhs.uscis.intake.models.LockboxStatuses;
import gov.dhs.uscis.intake.models.PaymentAuthorizationResponse;
import gov.dhs.uscis.intake.services.AuditService;
import gov.dhs.uscis.lockboxgateway.jms.publisher.PaymentTransactionStatusPublisher;
import gov.dhs.uscis.lockboxgateway.service.SubmissionManifestService;
import jakarta.jms.JMSException;

public class SubmissionPaymentsTransactionListenerTest {
    
    private static final String CORRELATION_ID = "correlationId";
    private static final String MANIFEST_ID = "fakeId";
    //JPMC Sends the UUID Upper Case.
    private static final String SUBMISSION_ID = UUID.randomUUID().toString().toUpperCase();
    private static final String MYUSCIS_ID = "fakeMyUSCISId";
    private static final SubmissionManifest submissionManifest = SubmissionManifest.builder().myUscisId(MYUSCIS_ID).submissionId(SUBMISSION_ID).build();

    private SubmissionPaymentsTransactionListener listener;
    private PaymentServiceClient paymentServiceClient;
    private AuditService auditService;
    private PaymentTransactionStatusPublisher statusHandler;
    private LockboxPaymentMessage lpm;

    private BigDecimal totalCost = BigDecimal.TEN.setScale(2);

    @BeforeEach
    public void setup() {
      paymentServiceClient = mock(PaymentServiceClient.class);
      statusHandler = mock(PaymentTransactionStatusPublisher.class);
      auditService = mock(AuditService.class);
      lpm = mock(LockboxPaymentMessage.class);
      SubmissionManifestService submissionManifestService = mock(SubmissionManifestService.class);
      
      when(submissionManifestService.getManifest(MANIFEST_ID)).thenReturn(submissionManifest);
      listener = new SubmissionPaymentsTransactionListener(paymentServiceClient, statusHandler, auditService, submissionManifestService);
    }

    @Test
    public void shouldCallPaymentServicesWithAnAcceptRequestToCompleteAnAuthorizationSuccess() throws JMSException, PaymentProcessingException{        
        when(lpm.status()).thenReturn(LockboxStatuses.ACCEPTED);
        when(lpm.uscisId()).thenReturn(MANIFEST_ID);
        when(lpm.correlationId()).thenReturn(CORRELATION_ID);
        when(lpm.totalCost()).thenReturn(totalCost);
        when(paymentServiceClient.completeAuthorization(anyString(), any(BigDecimal.class))).thenReturn(PaymentAuthorizationResponse.builder().result(AuthorizationStatusCode.Success).build());

        listener.handleMessage(lpm);
        verify(auditService, times(1)).addEvent(MYUSCIS_ID, SUBMISSION_ID.toLowerCase(), ActionPerformed.PAYMENT_REQUEST_RECEIVED, SubmissionState.PUBLISHED, null);
        verify(paymentServiceClient).completeAuthorization(SUBMISSION_ID.toLowerCase(), totalCost);
        verify(statusHandler).publishPaymentAccepted(CORRELATION_ID, MANIFEST_ID);
        verify(auditService, times(1)).addEvent(MYUSCIS_ID, SUBMISSION_ID.toLowerCase(), ActionPerformed.PAYMENT_RESPONSE_SENT, SubmissionState.PUBLISHED, LockboxStatuses.ACCEPTED.toString());
    }

    @Test
    public void shouldCallPaymentServicesWithAnAcceptRequestToCompleteAnAuthorizationDecline() throws JMSException, PaymentProcessingException{
        when(lpm.status()).thenReturn(LockboxStatuses.ACCEPTED);
        when(lpm.uscisId()).thenReturn(MANIFEST_ID);
        when(lpm.correlationId()).thenReturn(CORRELATION_ID);
        when(lpm.totalCost()).thenReturn(totalCost);
        when(paymentServiceClient.completeAuthorization(anyString(), any(BigDecimal.class))).thenReturn(PaymentAuthorizationResponse.builder().result(AuthorizationStatusCode.Declined).build());

        listener.handleMessage(lpm);

        verify(paymentServiceClient).completeAuthorization(SUBMISSION_ID.toLowerCase(), totalCost);
        verify(statusHandler).publishPaymentDeclined(CORRELATION_ID, MANIFEST_ID);
    }

    @Test
    public void shouldCallPaymentServicesWithAnAcceptRequestToCompleteAnAuthorizationError() throws JMSException, PaymentProcessingException{
        when(lpm.status()).thenReturn(LockboxStatuses.ACCEPTED);
        when(lpm.uscisId()).thenReturn(MANIFEST_ID);
        when(lpm.correlationId()).thenReturn(CORRELATION_ID);
        when(lpm.totalCost()).thenReturn(totalCost);
        when(paymentServiceClient.completeAuthorization(anyString(), any(BigDecimal.class))).thenReturn(PaymentAuthorizationResponse.builder().result(AuthorizationStatusCode.Error).build());

        listener.handleMessage(lpm);

        verify(paymentServiceClient).completeAuthorization(SUBMISSION_ID.toLowerCase(), totalCost);
        verify(statusHandler).publishPaymentError(CORRELATION_ID, MANIFEST_ID);
    }

    @Test
    public void shouldCallPublishAnErrorBackToJPMC() throws JMSException, PaymentProcessingException{
        when(lpm.status()).thenReturn(LockboxStatuses.REJECTED);
        when(lpm.uscisId()).thenReturn(MANIFEST_ID);
        when(lpm.correlationId()).thenReturn(CORRELATION_ID);

        listener.handleMessage(lpm);

        verify(statusHandler).publishPaymentError(CORRELATION_ID, MANIFEST_ID, "Total Cost is missing");
    }

    @Test
    public void shouldCallPaymentServicesWithAnAcceptRequestWithZeroFeeToCancelAnAuthorizationSuccess() throws JMSException, PaymentProcessingException{
        when(lpm.status()).thenReturn(LockboxStatuses.ACCEPTED);
        when(lpm.uscisId()).thenReturn(MANIFEST_ID);
        when(lpm.correlationId()).thenReturn(CORRELATION_ID);
        when(lpm.totalCost()).thenReturn(BigDecimal.ZERO);

        listener.handleMessage(lpm);

        verify(paymentServiceClient).cancelAuthorization(SUBMISSION_ID.toLowerCase());
        verify(statusHandler).publishPaymentCanceled(CORRELATION_ID, MANIFEST_ID);
    }

    @Test
    public void shouldConvertOverBigDecimalsThatHave4DecimalDigits() throws JMSException, PaymentProcessingException{
        when(lpm.status()).thenReturn(LockboxStatuses.ACCEPTED);
        when(lpm.uscisId()).thenReturn(MANIFEST_ID);
        when(lpm.correlationId()).thenReturn(CORRELATION_ID);
        when(lpm.totalCost()).thenReturn(new BigDecimal("470.0000"));
        when(paymentServiceClient.completeAuthorization(anyString(), any(BigDecimal.class))).thenReturn(PaymentAuthorizationResponse.builder().result(AuthorizationStatusCode.Success).build());

        listener.handleMessage(lpm);

        ArgumentCaptor<BigDecimal> captor = ArgumentCaptor.forClass(BigDecimal.class);
        ArgumentCaptor<String> submissionIdCaptor = ArgumentCaptor.forClass(String.class);
        verify(paymentServiceClient).completeAuthorization(submissionIdCaptor.capture(), captor.capture());

        org.assertj.core.api.Assertions.assertThat(captor.getValue().toString()).isEqualTo("470.00");
        org.assertj.core.api.Assertions.assertThat(captor.getValue().toString()).isEqualTo("470.00");

    }

    @Test
    public void shouldCompleteAuthorizationWithUnmodifiedSubmissionId() throws JMSException, PaymentProcessingException{
        when(lpm.status()).thenReturn(LockboxStatuses.ACCEPTED);
        when(lpm.uscisId()).thenReturn(MANIFEST_ID);
        when(lpm.correlationId()).thenReturn(CORRELATION_ID);
        when(lpm.totalCost()).thenReturn(new BigDecimal("470.0000"));
        when(paymentServiceClient.completeAuthorization(anyString(), any(BigDecimal.class))).thenReturn(PaymentAuthorizationResponse.builder().result(AuthorizationStatusCode.Success).build());

        listener.handleMessage(lpm);

        verify(paymentServiceClient).completeAuthorization(eq(SUBMISSION_ID.toLowerCase()), any());
    }
}
