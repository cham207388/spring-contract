package gov.dhs.uscis.lockboxgateway.jms;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.core.JmsTemplate;

import gov.dhs.uscis.intake.models.SubmissionStatusResponse;
import jakarta.jms.JMSException;

@ExtendWith(MockitoExtension.class)
public class SubmissionStatusPublisherTest {
    static final String DESTINATION = "LOCKBOX_RESPONSE_QUEUE";
    static final String SUBMISSIONID = "12345";

    @Mock
    JmsTemplate jmsTemplate;
    @InjectMocks
    SubmissionStatusPublisher submissionStatusPublisher;

    @Test
    public void testPublishSubmissionResponse() throws JMSException {
        doNothing().when(jmsTemplate).convertAndSend(anyString(), any(SubmissionStatusResponse.class));
        submissionStatusPublisher.publishSubmissionResponse(DESTINATION, new SubmissionStatusResponse(), SUBMISSIONID);
        verify(jmsTemplate, times(1)).convertAndSend(DESTINATION, new SubmissionStatusResponse());

    }

}
