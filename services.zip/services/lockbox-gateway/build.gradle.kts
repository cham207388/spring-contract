import com.bmuschko.gradle.docker.tasks.image.DockerBuildImage

plugins {
    java
    jacoco
    `maven-publish`
    eclipse
    alias(libs.plugins.spring.boot)
    alias(libs.plugins.docker)
    alias(libs.plugins.sonarqube)
    alias(libs.plugins.swagger.core)
    alias(libs.plugins.spring.cloud.contract)
    alias(libs.plugins.undercouch)       // Verify if we need this
    alias(libs.plugins.pdfi.java.conventions)
}

val commitTag: String = System.getenv("COMMIT_HASH") ?: "latest"
val stubVersion = "0.0.1-RELEASE"

group = "gov.dhs.uscis"
version = "0.0.1-SNAPSHOT"

publishing {
    publications {
        create<MavenPublication>("stubs") {
            artifactId = project.name
            // Override version for publishing
            version = stubVersion

            artifact(file("${layout.buildDirectory.get()}/libs/${project.name}-$stubVersion-stubs.jar")) {
                classifier = "stubs"
            }
        }
    }
    repositories {
        mavenLocal()
    }
}

contracts {
    baseClassForTests.set("gov.dhs.uscis.lockboxgateway.BaseContractTest")
}

// extra["tomcat.version"] = "10.1.50" // fix for CVE-2025-55754

configurations {
    compileOnly {
        extendsFrom(configurations.annotationProcessor.get())
    }
    runtimeClasspath {
        extendsFrom(configurations.developmentOnly.get())
    }
}


dependencies {
    implementation(enforcedPlatform(libs.log4j.bom))

    val springBootDependencyBom = platform(libs.spring.boot.dependencies)
    implementation(platform(libs.aws.bom))

    implementation(springBootDependencyBom)
    testImplementation(springBootDependencyBom)
    compileOnly(springBootDependencyBom)
    testCompileOnly(springBootDependencyBom)
    annotationProcessor(springBootDependencyBom)
    testAnnotationProcessor(springBootDependencyBom)

    constraints{
        implementation(libs.spring.core) {
            because("CVE-2025-41249")
        }
        implementation(libs.commons.lang3) {
            because("CVE-2025-48924")
        }
        implementation(libs.spring.web) {
            because("CVE-2025-41234")
        }
        implementation(libs.spring.webmvc) {
            because("CVE-2025-41242")
        }
        implementation(libs.tomcat.embed.core) {
            because("CVE-2026-34487")
        }
        implementation(libs.spring.jms) {
            because("Ensure consistent version for JMS messaging")
        }
        implementation(libs.fasterxml.jackson.core) {
            because("GHSA-72hv-8253-57qq")
        }
        implementation(libs.activemq.client) {
            because("CVE-2025-66168")
        }
        implementation(libs.netty.codec.http) {
            because("CVE-2026-33870")
        }
        implementation(libs.netty.codec.http2) {
            because("CVE-2026-33871")
        }
    }

    implementation("org.springframework.boot:spring-boot-starter")
    implementation(libs.spring.boot.starter.actuator) {
        exclude(group = "org.apache.tomcat.embed", module = "tomcat-embed-core")
        exclude(group = "org.apache.logging.log4j", module = "log4j-api")
        exclude(group = "ch.qos.logback", module = "logback-classic")
        exclude(group = "ch.qos.logback", module = "logback-core")
    }
    implementation(libs.spring.boot.starter.activemq)
    implementation(libs.spring.boot.starter.webflux)
    implementation(libs.spring.boot.starter.web)
    implementation(libs.springdoc.openapi)
    
    implementation(libs.aws.dynamodb.enhanced) 
    implementation(libs.aws.sts)
    implementation(libs.fasterxml.jackson.datatype)
    implementation(libs.fasterxml.jackson.databind)
    implementation(libs.logback.encoder)
    
    implementation(libs.javax.jms)
    implementation(libs.micrometer)
    implementation(libs.logstash.encoder)

    compileOnly(libs.lombok)
    annotationProcessor(libs.lombok)
    
    testImplementation(libs.spring.boot.starter.test)
    testImplementation(libs.spring.restdocs.webtestclient)
    testImplementation(libs.instancio)
    testImplementation(libs.spring.cloud.starter.verifier)
}

docker {
    springBootApplication {
        baseImage.set("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/csai-java-base-image:21.0.8_11-jre-alpine")
        images.add("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/lockbox-gateway:$commitTag")
        maintainer.set("csai-dev-team")
        mainClassName.set("gov.dhs.uscis.lockboxgateway.LockboxgatewayApplication")
        jvmArgs.set(listOf("-XX:+UseContainerSupport", "-XX:MaxRAMPercentage=90", "-javaagent:/opt/newrelic.jar"))
    }
}

tasks.named<DockerBuildImage>("dockerBuildImage") {
    platform.set("linux/amd64")
    pull.set(true)
}

tasks.dockerCreateDockerfile {
    instruction("RUN cp ./resources/newrelic.yaml /opt/newrelic.yml")
    instruction("EXPOSE 8080")
    instruction("USER apps")
}

tasks.build {
    dependsOn(tasks.dockerBuildImage)
}

tasks.named<Test>("test") {
    useJUnitPlatform()
    finalizedBy(tasks.jacocoTestReport)
    testLogging {
        events("PASSED", "SKIPPED", "FAILED", "STANDARD_OUT", "STANDARD_ERROR")
    }
}

jacoco {
    toolVersion = libs.versions.jacoco.get()
}

val jacocoExcludes = listOf(
    "gov/dhs/uscis/lockboxgateway/exception/**",
    "gov/dhs/uscis/lockboxgateway/entities/**",
    "gov/dhs/uscis/lockboxgateway/model/**",
    "gov/dhs/uscis/lockboxgateway/config/**"
)

tasks.withType<JacocoReportBase> {
    classDirectories.setFrom(files(classDirectories.files.map {
        fileTree(it) { exclude(jacocoExcludes) }
    }))
}

tasks.jacocoTestReport {
    reports {
        xml.required.set(true)
        html.required.set(true)
    }
}

tasks.jacocoTestCoverageVerification {
    dependsOn(tasks.test)
    violationRules {
        rule {
            limit {
                minimum = 0.8.toBigDecimal()
            }
        }
    }
}

tasks.check {
    dependsOn(tasks.jacocoTestCoverageVerification)
}

tasks.named("sonar") {
    dependsOn(tasks.jacocoTestCoverageVerification)
}

val renameStubArtifact = tasks.register("renameStubArtifact") {
    val sourceFile = file("${layout.buildDirectory.get()}/libs/${project.name}-$version-stubs.jar")
    val targetFile = file("${layout.buildDirectory.get()}/libs/${project.name}-$stubVersion-stubs.jar")

    inputs.file(sourceFile)
    outputs.file(targetFile)

    doLast {
        if (sourceFile.exists()) {
            targetFile.parentFile.mkdirs()
            sourceFile.renameTo(targetFile)
            println("Renamed artifact created: $targetFile")
        }
    }
}

tasks.named("publishStubsPublicationToMavenLocalRepository") {
    dependsOn(renameStubArtifact)
}