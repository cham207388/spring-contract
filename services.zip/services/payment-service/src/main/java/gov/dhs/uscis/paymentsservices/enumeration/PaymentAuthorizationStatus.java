package gov.dhs.uscis.paymentsservices.enumeration;

public enum PaymentAuthorizationStatus {
    Authorized,
    NotAuthorized
}
