package gov.dhs.uscis.paymentsservices.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.services.SystemClockService;
import gov.dhs.uscis.paymentsservices.entity.PaymentAuthorization;
import gov.dhs.uscis.paymentsservices.entity.PaymentConfirmation;
import gov.dhs.uscis.paymentsservices.model.ElisPaymentRequest;
import gov.dhs.uscis.paymentsservices.model.PaymentStartResponse;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class ElisPaymentsClient {

    static final String SECURE_PAY_COMPLETE_AUTHORIZATION = "/secure/pay/completeAuthorization";
    static final String SECURE_PAY_COMPLETE_AUTOINGESTION = "/secure/pay/pdfi/complete";
    static final String GET_PAYMENT_DETAILS = "/secure/pay/getDetails?tcsAppId=%s&agencyTrackingId=%s";
    public static final String ELIS_I765_BENEFIT_CATEGORY_CODE = "44";
    public static final String ELIS_N400_BENEFIT_CATEGORY_CODE = "78";
    public static final String ELIS_I131_BENEFIT_CATEGORY_CODE = "20";
    public static final String ELIS_I130_BENEFIT_CATEGORY_CODE = "19";
    public static final String ELIS_I129H2A_BENEFIT_CATEGORY_CODE = "165";
    public static final String ELIS_I129H1B_BENEFIT_CATEGORY_CODE = "166";
    public static final String ELIS_I129E_BENEFIT_CATEGORY_CODE = "189";
    public static final String ELIS_I129R_BENEFIT_CATEGORY_CODE = "96";
    public static final String ELIS_I129TN_BENEFIT_CATEGORY_CODE = "96";
    public static final String ELIS_I751_BENEFIT_CATEGORY_CODE = "106";
    public static final String ELIS_I140_BENEFIT_CATEGORY_CODE = "112";
    public static final String ELIS_I485_BENEFIT_CATEGORY_CODE = "86";
    public static final String ELIS_I485A_BENEFIT_CATEGORY_CODE = "105";
    public static final String ELIS_I485J_BENEFIT_CATEGORY_CODE = "119";
    public static final String ELIS_I907_BENEFIT_CATEGORY_CODE = "148";
    public static final String ELIS_I90_BENEFIT_CATEGORY_CODE = "58";
    public static final String ELIS_I539_BENEFIT_CATEGORY_CODE = "32";
    static final String START_AUTHORIZATION_PATH = "/secure/pay/startAuthorization";
    static final String START_AUTOINGESTION_PATH = "/secure/pay/pdfi/start";
    static final String CANCEL_AUTHORIZATION_PATH = "/secure/pay/cancelAuthorization?tcsAppId=%s&agencyTrackingId=%s";
    static final String CANCEL_AUTOINGESTION_PATH = "/secure/pay/pdfi/cancel?tcsAppId=%s&agencyTrackingId=%s";
    private WebClient elisWebClient;

    @Value("${uscis.elis.enable:false}")
    private boolean enabled;
    private String successUrl;
    private String cancelUrl;
    private Map<String, String> tcsAppIds;
    private Map<String, String> benefitCategoryCodes;
    private SystemClockService systemClockService;

  public ElisPaymentsClient(WebClient elisWebClient,
      @Value("${application.payments.client.url.success}") String successUrl,
      @Value("${application.payments.client.url.cancel}") String cancelUrl,
      @Value("${application.payments.i765AppId}") String i765AppId,
      @Value("${application.payments.n400AppId}") String n400AppId,
      @Value("${application.payments.i131AppId}") String i131AppId,
      @Value("${application.payments.i130AppId}") String i130AppId,
      @Value("${application.payments.i129H2AAppId}") String i129H2AAppId,
      @Value("${application.payments.i129H1BAppId}") String i129H1BAppId,
      @Value("${application.payments.i129EAppId}") String i129EAppId,
      @Value("${application.payments.i129RAppId}") String i129RAppId,
      @Value("${application.payments.i129TNAppId}") String i129TNAppId,
      @Value("${application.payments.i751AppId}") String i751AppId,
      @Value("${application.payments.i140AppId}") String i140AppId,
      @Value("${application.payments.i485AppId}") String i485AppId,
      @Value("${application.payments.i485AAppId}") String i485AAppId,
      @Value("${application.payments.i485JAppId}") String i485JAppId,
      @Value("${application.payments.i907AppId}") String i907AppId,
      @Value("${application.payments.i90AppId}") String i90AppId,
      @Value("${application.payments.i539AppId}") String i539AppId,
      SystemClockService systemClockService) {
    this.elisWebClient = elisWebClient;
    this.successUrl = successUrl;
    this.cancelUrl = cancelUrl;
    this.tcsAppIds = new HashMap<>();
    this.benefitCategoryCodes = new HashMap<>();

    this.tcsAppIds.put(FormType.I765.getType(), i765AppId);
    this.tcsAppIds.put(FormType.N400.getType(), n400AppId);
    this.tcsAppIds.put(FormType.I131.getType(), i131AppId);
    this.tcsAppIds.put(FormType.I130.getType(), i130AppId);
    this.tcsAppIds.put(FormType.I129H1B.getType(), i129H1BAppId);
    this.tcsAppIds.put(FormType.I129H2A.getType(), i129H2AAppId);
    this.tcsAppIds.put(FormType.I129E.getType(), i129EAppId);
    this.tcsAppIds.put(FormType.I129R.getType(), i129RAppId);
    this.tcsAppIds.put(FormType.I129TN.getType(), i129TNAppId);
    this.tcsAppIds.put(FormType.I751.getType(), i751AppId);
    this.tcsAppIds.put(FormType.I140.getType(), i140AppId);
    this.tcsAppIds.put(FormType.I485.getType(), i485AppId);
    this.tcsAppIds.put(FormType.I485A.getType(), i485AAppId);
    this.tcsAppIds.put(FormType.I485J.getType(), i485JAppId);
    this.tcsAppIds.put(FormType.I907.getType(), i907AppId);
    this.tcsAppIds.put(FormType.I90.getType(), i90AppId);
    this.tcsAppIds.put(FormType.I539.getType(), i539AppId);
    this.benefitCategoryCodes.put(FormType.I765.getType(), ELIS_I765_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.N400.getType(), ELIS_N400_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I131.getType(), ELIS_I131_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I130.getType(), ELIS_I130_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I129H1B.getType(), ELIS_I129H1B_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I129H2A.getType(), ELIS_I129H2A_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I129E.getType(), ELIS_I129E_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I129R.getType(), ELIS_I129R_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I129TN.getType(), ELIS_I129TN_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I751.getType(), ELIS_I751_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I140.getType(), ELIS_I140_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I485.getType(), ELIS_I485_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I485A.getType(), ELIS_I485A_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I485J.getType(), ELIS_I485J_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I907.getType(), ELIS_I907_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I90.getType(), ELIS_I90_BENEFIT_CATEGORY_CODE);
    this.benefitCategoryCodes.put(FormType.I539.getType(), ELIS_I539_BENEFIT_CATEGORY_CODE);
    this.systemClockService = systemClockService;
  }

    private ElisPaymentRequest toElisPaymentRequest(BigDecimal amount, String formType,
            String submissionId, String successUrl, String cancelUrl, String eligibilityCategory, List<String> formTypeList,  boolean isUnder14) { // pass eligibilityCategory param
        ElisPaymentRequest elisPaymentRequest = new ElisPaymentRequest();
        String[] refIds = new String[1];
        refIds[0] = submissionId;

        elisPaymentRequest.setTcsAppId(tcsAppIds.get(formType));
        elisPaymentRequest.setBenefitType(benefitCategoryCodes.get(formType));
        elisPaymentRequest.setRefIds(refIds);
        elisPaymentRequest.setTransactionAmount(amount);
        elisPaymentRequest.setSuccessUrl(successUrl);
        elisPaymentRequest.setCancelUrl(cancelUrl);
        elisPaymentRequest.setEligibilityCategory(eligibilityCategory);
        elisPaymentRequest.setFormTypeList(formTypeList);
        elisPaymentRequest.setUnder14(isUnder14);

        elisPaymentRequest.setRedirect(false);

        return elisPaymentRequest;

    }

    public PaymentAuthorization startAuthorization(BigDecimal amount, String formType, String submissionid,
            String successUrl, String cancelUrl, String eligibilityCategory, List<String> formTypeList, boolean isUnder14) {
        ElisPaymentRequest elisPaymentRequest = toElisPaymentRequest(amount, formType, submissionid, successUrl, cancelUrl, eligibilityCategory, formTypeList, isUnder14);

        String urlPath = START_AUTHORIZATION_PATH;
        if(FormType.fromString(formType).isAutoIngested()) {
        	urlPath = START_AUTOINGESTION_PATH;
        }

        var response = elisWebClient.post().uri(urlPath)
                .body(Mono.just(elisPaymentRequest),
                        ElisPaymentRequest.class)
                .retrieve()
                .onStatus(status -> status.isError(), res -> res.bodyToMono(String.class).map(RuntimeException::new))
                .bodyToMono(PaymentStartResponse.class)
                .block();
                 log.info("Calling pay.gov with {} and request body {}", submissionid, elisPaymentRequest);


        return new PaymentAuthorization(submissionid.toString(), response.getAgencyTrackingId(),
                response.getRedirectUrl(),
                amount, formType, elisPaymentRequest.getTcsAppId(), eligibilityCategory);

    }

    public PaymentConfirmation completeAuthorization(String tcspAppId, String agencyTrackingId, BigDecimal amount,
            String formType, String eligibilityCategory) {
        var elisPaymentRequest = new ElisPaymentRequest();

    elisPaymentRequest.setTcsAppId(tcspAppId);
    elisPaymentRequest.setBenefitType(benefitCategoryCodes.get(formType));
    elisPaymentRequest.setTransactionAmount(amount);
    elisPaymentRequest.setAgencyTrackingId(agencyTrackingId);

        elisPaymentRequest.setRefIds(new String[] { agencyTrackingId });
        elisPaymentRequest.setSuccessUrl(successUrl);
        elisPaymentRequest.setCancelUrl(cancelUrl);
        elisPaymentRequest.setEligibilityCategory(eligibilityCategory);

        try {
            log.info("Completing payment authorization for {}", elisPaymentRequest.getTcsAppId());
        	String completeurlPath = SECURE_PAY_COMPLETE_AUTHORIZATION;
            if(FormType.fromString(formType).isAutoIngested()) {
            	completeurlPath = SECURE_PAY_COMPLETE_AUTOINGESTION;
            }

        	elisWebClient.post().uri(completeurlPath)
                .contentType(MediaType.APPLICATION_JSON)
                .body(Mono.just(elisPaymentRequest), ElisPaymentRequest.class)
                .retrieve().toBodilessEntity()
                .retry(3)
                .block();

            return new PaymentConfirmation(systemClockService.getSystemTime(), agencyTrackingId,
                    AuthorizationStatusCode.Success);
        } catch (WebClientResponseException exception) {
            log.info(String.format("Webclient exception from ELISPaymentService: %s", exception.getMessage()));
            if (exception.getStatusCode().isSameCodeAs(HttpStatusCode.valueOf(409)))
                return new PaymentConfirmation(systemClockService.getSystemTime(), agencyTrackingId,
                        AuthorizationStatusCode.Declined);
            return new PaymentConfirmation(systemClockService.getSystemTime(), agencyTrackingId,
                    AuthorizationStatusCode.Error);
        }
    }

    public void cancelAuthorization(String agencyTrackingId, String formType) {
        log.debug("About to cancel payment:  " + agencyTrackingId);
        try {
        	String url = CANCEL_AUTHORIZATION_PATH;
        	if(FormType.fromString(formType).isAutoIngested()) {
            	url = CANCEL_AUTOINGESTION_PATH;
            }
            elisWebClient.get().uri(String.format(url, tcsAppIds.get(formType), agencyTrackingId))
                    .retrieve()
                    .toBodilessEntity()
                    .block();
        } catch (WebClientResponseException e) {
            log.error("Exception was identified when processing:  " + agencyTrackingId, e);
            if (!e.getStatusCode().isSameCodeAs(HttpStatusCode.valueOf(404))) {
                throw e;
            }
        }
        log.debug("Payment cancelation complete:  " + agencyTrackingId);
    }

    public AuthorizationStatusCode getAuthorizationStatusCode(String agencyTrackingId, String formType) {
        try {
            var response = elisWebClient.get()
                    .uri(String.format(GET_PAYMENT_DETAILS, tcsAppIds.get(formType), agencyTrackingId))
                    .retrieve()
                    .bodyToMono(ElisGetDetailsResponse.class)
                    .block();

            if (response == null || response.getPayment() == null)
                return AuthorizationStatusCode.Pending;

            return "Success".equals(response.getPayment().getPaymentStatus())
                    ? AuthorizationStatusCode.Success
                    : AuthorizationStatusCode.Pending;
        } catch (WebClientResponseException wcre) {
            if (wcre.getStatusCode().value() == 409) {
                log.debug("Payment has not successfully been registered for " + agencyTrackingId);
            } else {
                log.error("server error while validating payment:  " + agencyTrackingId);
            }
            return AuthorizationStatusCode.Pending;
        }

    }

}