package gov.dhs.uscis.paymentsservices.exception;

public class PaymentDeclinedException extends RuntimeException {
  public PaymentDeclinedException(String submissionId) {
      super(String.format("Payment was Declined for Submission with id: %s", submissionId));
  }  
}
