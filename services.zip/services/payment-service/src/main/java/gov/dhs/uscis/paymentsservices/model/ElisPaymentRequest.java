package gov.dhs.uscis.paymentsservices.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class ElisPaymentRequest {

  private String tcsAppId;
  private String benefitType;
  private String[] refIds;
  private BigDecimal transactionAmount;
  private List<String> formTypeList;
  private boolean isUnder14;
  // private String emailAddress;
  // private boolean receiptRequested;
  // private String payerId;
  // private String accountHolderName;
  // private String billingAddress;
  // private String billingAddress2;
  // private String billingCity;
  // private String billingState;
  // private String billingProvince;
  // private String billingZip;
  // private String billingPostalCode;
  // private String billingCountry;
  private String successUrl;
  private String cancelUrl;
  // private String draftNotESignedUrl;
  private Boolean redirect;
  private String agencyTrackingId;
  private String eligibilityCategory;
}