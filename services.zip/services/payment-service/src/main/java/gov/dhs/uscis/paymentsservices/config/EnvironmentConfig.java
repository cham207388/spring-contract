package gov.dhs.uscis.paymentsservices.config;

import java.time.ZonedDateTime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import gov.dhs.uscis.intake.services.SystemClockService;

@Configuration
public class EnvironmentConfig {

    @Bean
    public SystemClockService systemClockService(){
        return () -> ZonedDateTime.now();
    }

}
