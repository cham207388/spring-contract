package gov.dhs.uscis.paymentsservices.service;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.monitoring.AuditableTransaction;
import gov.dhs.uscis.intake.monitoring.MetricAware;
import gov.dhs.uscis.paymentsservices.entity.PaymentAuthorization;
import gov.dhs.uscis.paymentsservices.entity.PaymentConfirmation;
import gov.dhs.uscis.paymentsservices.enumeration.PaymentAuthorizationStatus;
import gov.dhs.uscis.paymentsservices.exception.PaymentDeclinedException;
import gov.dhs.uscis.paymentsservices.exception.PaymentErrorException;
import gov.dhs.uscis.paymentsservices.exception.PaymentNotFoundException;
import gov.dhs.uscis.paymentsservices.exception.SubmissionNotFoundException;
import gov.dhs.uscis.paymentsservices.repository.PaymentRepository;
import gov.dhs.uscis.intake.util.I129FormTypeConverter;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Service
@Primary
public class PaymentsService {

    private PaymentRepository repository;
    private ElisPaymentsClient elisPayments;
    private SubmissionServiceClient submissionServiceClient;
    private Logger logger = LoggerFactory.getLogger(PaymentsService.class);

    public PaymentsService(PaymentRepository repository,
            ElisPaymentsClient elisPayments,
            SubmissionServiceClient submissionServiceClient) {
        this.repository = repository;
        this.elisPayments = elisPayments;
        this.submissionServiceClient = submissionServiceClient;
    }

    // Todo: Refactor to use reactive implementation.
    public PaymentAuthorization startAuthorization(String submissionId, String formType,
            String successUrl, String cancelUrl) {
        // return type will also change to feeDetails: amount to fd.amount
        var feeDetails = submissionServiceClient.getFeeForSubmissionAmount(submissionId);
        var amount = feeDetails.amount();
        if (amount == null)
            throw new SubmissionNotFoundException(submissionId);

        logger.info("Payment amount for {} retrieved as ${} with category {}", submissionId, amount, feeDetails.eligibilityCategory());
        var paymentAuthorization = getPayment(submissionId, false);
        if (paymentAuthorization == null) {
            paymentAuthorization = elisPayments.startAuthorization(amount, formType, submissionId,
                    successUrl, cancelUrl, feeDetails.eligibilityCategory(), feeDetails.formTypeList(), feeDetails.isUnder14());
            repository.save(paymentAuthorization);

        } else {
            log.info("Authorization already done for submissionId: {}", submissionId);
        }

        return paymentAuthorization;
    }

    public void completeAuthorization(String submissionId, BigDecimal amount)
            throws NotFoundException, PaymentDeclinedException, PaymentErrorException {
        var payment = getPayment(submissionId, true);

        String formType = I129FormTypeConverter.toFormEnum(payment.getFormType());
        PaymentConfirmation confirmation = elisPayments.completeAuthorization(payment.getTcsAppId(),
                payment.getAgencyTrackingId(), amount, formType, payment.getEligibilityCategory());
        log.info("Response from elis payment service, submissionId {} confirmation {} ", submissionId,
                confirmation.toString());

        if (AuthorizationStatusCode.Declined.equals(confirmation.getAuthorizationStatusCode()))
            throw new PaymentDeclinedException(submissionId);
        if (AuthorizationStatusCode.Error.equals(confirmation.getAuthorizationStatusCode()))
            throw new PaymentErrorException(submissionId);

        // Todo: Update that database to append the confirmation.
        payment.setFinalPaymentAmount(amount);
        payment.setForcedDate(LocalDate.now());
        repository.save(payment);
    }

    public void cancelAuthorization(String submissionId) throws PaymentNotFoundException {
        var payment = getPayment(submissionId, true);
        String formType = I129FormTypeConverter.toFormEnum(payment.getFormType());
        elisPayments.cancelAuthorization(payment.getAgencyTrackingId(), formType);
    }

    public PaymentAuthorizationStatus getPaymentAuthorizationStatus(String submissionId, BigDecimal amount, String formTypeString) {
        log.info("getPaymentAuthorizationStatus: {} {} {}", submissionId, amount, formTypeString);
        FormType formType = FormType.fromString(formTypeString);
        if(formType != null && formType.isAutoIngested()) {
        	return PaymentAuthorizationStatus.NotAuthorized;
        }
        var payment = getPayment(submissionId, false);

        if (payment == null) {
            return (amount.compareTo(BigDecimal.ZERO) == 0)
                    ? PaymentAuthorizationStatus.Authorized
                    : PaymentAuthorizationStatus.NotAuthorized;
        }

        if (payment.getAuthorizedAmount().compareTo(amount) == 0) {
            return PaymentAuthorizationStatus.Authorized;
        }

        return elisPayments.getAuthorizationStatusCode(payment.getAgencyTrackingId(),
                payment.getFormType()) == AuthorizationStatusCode.Success
                        ? PaymentAuthorizationStatus.Authorized
                        : PaymentAuthorizationStatus.NotAuthorized;

    }

    @MetricAware(transaction = AuditableTransaction.CanceledAuthorization)
    public void removeAuthorization(String submissionId) {
        log.info("remove payment authorization due to a cancel: {} ", submissionId);

        var payment = getPayment(submissionId, false);
        if (payment != null)
            repository.delete(payment);
    }

    private PaymentAuthorization getPayment(String submissionId, boolean requirePayment) {
        var payment = repository.findPaymentBySubmissionId(submissionId);

        // Validate that there is a payment or throw a 404.
        if (payment == null && requirePayment)
            throw new PaymentNotFoundException(submissionId);
        return payment;
    }
}
