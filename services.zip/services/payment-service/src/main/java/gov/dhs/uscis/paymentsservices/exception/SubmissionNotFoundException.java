package gov.dhs.uscis.paymentsservices.exception;


public class SubmissionNotFoundException extends RuntimeException {
    public SubmissionNotFoundException(String submissionId) {
        super(String.format("Submission with id: %s, not found", submissionId));
    }  
}
