package gov.dhs.uscis.paymentsservices.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class PaymentAcceptanceRequest{
    String submissionId;
    BigDecimal feeTotal;
  }