package gov.dhs.uscis.paymentsservices.exception;

public class PaymentErrorException extends RuntimeException {
  public PaymentErrorException(String submissionId) {
      super(String.format("There was an error when transacting Authorization for Submission with id: %s", submissionId));
  }  
}
