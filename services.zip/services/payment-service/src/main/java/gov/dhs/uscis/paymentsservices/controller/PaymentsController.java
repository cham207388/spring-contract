package gov.dhs.uscis.paymentsservices.controller;

import java.math.BigDecimal;

import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import gov.dhs.uscis.intake.models.PaymentAuthorizationResponse;
import gov.dhs.uscis.paymentsservices.enumeration.PaymentAuthorizationStatus;
import gov.dhs.uscis.paymentsservices.exception.PaymentDeclinedException;
import gov.dhs.uscis.paymentsservices.exception.PaymentErrorException;
import gov.dhs.uscis.paymentsservices.exception.SubmissionNotFoundException;
import gov.dhs.uscis.paymentsservices.model.AuthorizationStatusResponse;
import gov.dhs.uscis.paymentsservices.model.CreateAuthorizationResponse;
import gov.dhs.uscis.paymentsservices.model.PaymentAcceptanceRequest;
import gov.dhs.uscis.paymentsservices.service.PaymentsService;
import gov.dhs.uscis.intake.util.I129FormTypeConverter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Tag(name = "Payments Service", description = "Payments API's")
@RestController
@RequestMapping("/api/v1/payments")
public class PaymentsController {

    private PaymentsService service;

    public PaymentsController(PaymentsService service) {
        this.service = service;
    }

    @GetMapping(value = "/{submissionId}/authorization", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CreateAuthorizationResponse> getAuthorization(@PathVariable String submissionId,
            @RequestParam String formType, @RequestParam String successUrl, @RequestParam String cancelUrl) {

        formType = I129FormTypeConverter.toFormEnum(formType);
        log.info("Authorization request received for submissionId: {} and for formType: {}", submissionId,
                formType);
        try {
            var authorization = service.startAuthorization(submissionId, formType, successUrl, cancelUrl);
            return authorization == null ? ResponseEntity.notFound().build()
                    : ResponseEntity.ok(new CreateAuthorizationResponse(authorization));
        } catch (SubmissionNotFoundException s) {
            log.error("Submission id provided does not exist {}", submissionId);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{submissionId}/authorization/status")
    public ResponseEntity<AuthorizationStatusResponse> getAuthorizationStatus(@PathVariable String submissionId,
            @RequestParam String feeTotal, @RequestParam String formType) {
        formType = I129FormTypeConverter.toFormEnum(formType);
        log.info("Authorization status request received for submissionId: {} ", submissionId);
        PaymentAuthorizationStatus paymentAuthorizationStatus = service.getPaymentAuthorizationStatus(submissionId,
                new BigDecimal(feeTotal), formType);
        if (paymentAuthorizationStatus.equals(PaymentAuthorizationStatus.Authorized)) {
            log.info("Payment authorization successful for submission: {}", submissionId);
        }
        return ResponseEntity.ok(
                new AuthorizationStatusResponse(
                        paymentAuthorizationStatus));
    }

    @PostMapping("/{submissionId}/authorization")
    public ResponseEntity<PaymentAuthorizationResponse> acceptPayment(@PathVariable String submissionId,
            @RequestBody PaymentAcceptanceRequest request) {
        try {
            service.completeAuthorization(submissionId, request.getFeeTotal());
        } catch (NotFoundException ne) {
            log.error("Submission id does not have an authorized payment: {}", submissionId);
            return ResponseEntity.notFound().build();
        } catch (PaymentDeclinedException pd) {
            log.error("Payment has been Declined for submission id: {}", submissionId);
            return ResponseEntity.badRequest()
                    .body(PaymentAuthorizationResponse.builder().result(AuthorizationStatusCode.Declined).build());
        } catch (PaymentErrorException pe) {
            log.error("There was an error completing payment of authorization for submission id: {}", submissionId);
            return ResponseEntity.badRequest()
                    .body(PaymentAuthorizationResponse.builder().result(AuthorizationStatusCode.Error).build());
        }

        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{submissionId}/authorization")
    public ResponseEntity<?> cancelAuthorization(@PathVariable String submissionId) throws NotFoundException {
        service.cancelAuthorization(submissionId);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{submissionId}/payment")
    public ResponseEntity<?> deletePayment(@PathVariable String submissionId) throws NotFoundException {
        service.removeAuthorization(submissionId);
        return ResponseEntity.noContent().build();
    }
}
