package gov.dhs.uscis.paymentsservices.service;

public class ElisGetDetailsResponse {
    private ElisPayment payment;

    public ElisPayment getPayment() {
      return payment;
    }
  }