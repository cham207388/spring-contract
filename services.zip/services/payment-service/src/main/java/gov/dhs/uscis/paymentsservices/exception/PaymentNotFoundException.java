package gov.dhs.uscis.paymentsservices.exception;

public class PaymentNotFoundException extends RuntimeException {
  public PaymentNotFoundException(String submissionId) {
      super(String.format("No payment found for Submission with id: %s", submissionId));
  }  
}
