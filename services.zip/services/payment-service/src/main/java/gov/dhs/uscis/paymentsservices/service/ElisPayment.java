package gov.dhs.uscis.paymentsservices.service;

public class ElisPayment {
    private String paymentStatus;

    public String getPaymentStatus() {
      return paymentStatus;
    }
  }