package gov.dhs.uscis.paymentsservices.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "payment_authorization")
public class PaymentAuthorization {
        public PaymentAuthorization(String submissionId, String agencyTrackingId, String redirectUrl,
                BigDecimal authorizedAmount, String formType, String tcsAppId,String eligibilityCategory ) {
            this.submissionId = submissionId;
            this.agencyTrackingId = agencyTrackingId;
            this.redirectUrl = redirectUrl;
            this.authorizedAmount = authorizedAmount;
            this.formType = formType;
            this.tcsAppId = tcsAppId;
            this.authorizedDate = LocalDate.now();
            this.eligibilityCategory = eligibilityCategory;
    }

    public PaymentAuthorization(){}

    @Id
    @Column(name = "submission_id")
    private String submissionId;

    @Column(name = "agency_trackingid")
    private String agencyTrackingId;

    @Column(name = "redirect_url")
    private String redirectUrl;

    @Column(name = "authorized_amount")
    private BigDecimal authorizedAmount;

    @Column(name = "final_payment_amount")
    private BigDecimal finalPaymentAmount;

    @Column(name = "authorized_date")
    private LocalDate authorizedDate;

    @Column(name = "forced_date")
    private LocalDate forcedDate;

    @Column(name = "form_type")
    private String formType;

    @Column(name = "tcs_app_id")
    private String tcsAppId;
    
    @Column(name = "eligibility_category")
    private String  eligibilityCategory;
}
