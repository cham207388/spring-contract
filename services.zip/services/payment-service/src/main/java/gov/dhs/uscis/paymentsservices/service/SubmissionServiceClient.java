package gov.dhs.uscis.paymentsservices.service;

import java.math.BigDecimal;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

import gov.dhs.uscis.paymentsservices.exception.SubmissionNotFoundException;
import gov.dhs.uscis.paymentsservices.model.FeeDetails;
import reactor.core.publisher.Mono;

@Service
public class SubmissionServiceClient {

    private WebClient client;
    private Logger logger = LoggerFactory.getLogger(SubmissionServiceClient.class);

    public SubmissionServiceClient(WebClient client) {
        this.client = client;
    }
    
    private ResponseSpec fetchSubmissionFee(String submissionId) {
		return client.get()
                .uri(String.format("/api/v1/submissions/%s/fee", submissionId))
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .onStatus((f) -> f.is4xxClientError(),
                        response -> {
                            logger.error("Response from submission service failed {}", response.toString());
                            return Mono.error(
                                    new SubmissionNotFoundException("submission id not found:  " + submissionId));
                        });
	}

    // map it to the response type with amount and eligibilityCategory fields
    // change the return type
    public FeeDetails getFeeForSubmissionAmount(String submissionId) {
        logger.info("Checking payment information for submission id {}", submissionId);
        return fetchSubmissionFee(submissionId)
                .bodyToMono(FeeDetails.class) 
                .block();
    }

}
