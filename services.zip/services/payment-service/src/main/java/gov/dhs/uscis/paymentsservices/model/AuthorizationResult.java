package gov.dhs.uscis.paymentsservices.model;

import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;

public class AuthorizationResult{
    String agencyTrackingId;
    public String getAgencyTrackingId() {
        return agencyTrackingId;
    }
    public void setAgencyTrackingId(String agencyTrackingId) {
        this.agencyTrackingId = agencyTrackingId;
    }
    public String getTcsAppId() {
        return tcsAppId;
    }
    public void setTcsAppId(String tcsAppId) {
        this.tcsAppId = tcsAppId;
    }
    public AuthorizationStatusCode getStatus() {
        return status;
    }
    public void setStatus(AuthorizationStatusCode status) {
        this.status = status;
    }
    String tcsAppId;
    AuthorizationStatusCode status;
}