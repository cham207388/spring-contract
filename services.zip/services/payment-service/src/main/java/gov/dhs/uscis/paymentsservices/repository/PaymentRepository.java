package gov.dhs.uscis.paymentsservices.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.dhs.uscis.paymentsservices.entity.PaymentAuthorization;

@Repository
public interface PaymentRepository extends CrudRepository<PaymentAuthorization, String>{

    public PaymentAuthorization findPaymentBySubmissionId(String submissionId);

}
