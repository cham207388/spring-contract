package gov.dhs.uscis.paymentsservices.entity;

import java.io.Serializable;
import java.time.ZonedDateTime;

import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaymentConfirmation implements Serializable {

  //Adding this annotation to surpress a SonarQube
  @SuppressWarnings("java:S2057")
  private static final long serialVersionUID = 1;
  @SuppressWarnings("java:S3437")
  private ZonedDateTime timestamp;
  private String agencyTrackingId;
  private AuthorizationStatusCode authorizationStatusCode;

    public PaymentConfirmation(ZonedDateTime timestamp, String agencyTrackingId, AuthorizationStatusCode authorizationStatusCode) {
        this.timestamp = timestamp;
        this.agencyTrackingId = agencyTrackingId;
        this.authorizationStatusCode = authorizationStatusCode;
    }

}
