package gov.dhs.uscis.paymentsservices.enumeration;

public enum StatusEnum {
  ACCEPTED,
  REJECTED;
}

