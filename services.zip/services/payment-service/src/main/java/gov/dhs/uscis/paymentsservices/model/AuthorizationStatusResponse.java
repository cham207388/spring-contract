package gov.dhs.uscis.paymentsservices.model;

import gov.dhs.uscis.paymentsservices.enumeration.PaymentAuthorizationStatus;

public class AuthorizationStatusResponse {

    private PaymentAuthorizationStatus status;

    public AuthorizationStatusResponse(PaymentAuthorizationStatus status) {
        this.status = status;
    }

    public PaymentAuthorizationStatus getStatus() {
        return status;
    }
}
