package gov.dhs.uscis.paymentsservices.config;

import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import gov.dhs.uscis.paymentsservices.service.SubmissionServiceClient;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import reactor.netty.http.client.HttpClient;

@Configuration
public class WebFluxConfigs {

    @Value("${uscis.submission.baseUrl}")
    private String baseUrl;
    @Value("${uscis.elis.payments.baseUrl}")
    private String elisBaseUrl;
    @Value("${uscis.elis.keystore}")
    private String elisKeyStore;
    @Value("${uscis.elis.keyStorePassword}")
    private String elisKeyStorePassword;

    @Bean()
    public SubmissionServiceClient submissionServiceClient(
            @Value("${uscis.submission.baseUrl}") String submissionServiceUrl,
            HttpClient httpClient) {
        return new SubmissionServiceClient(WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .baseUrl(submissionServiceUrl)
                .build());
    }

    @Bean()
    WebClient elisWebClient(HttpClient httpClient) {
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .baseUrl(elisBaseUrl)
                .build();
    }

    @Bean
    @ConditionalOnProperty(prefix = "uscis.elis", name = "enable", havingValue = "true")
    HttpClient getSecureHttpClient() {
        return HttpClient.create().secure(spec -> spec.sslContext(createSSLContext()));
    }

    @Bean
    @ConditionalOnProperty(prefix = "uscis.elis", name = "enable", havingValue = "false", matchIfMissing = true)
    HttpClient getHttpClient() {
        return HttpClient.create();
    }

    private SslContext createSSLContext() {
        try {
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            keyStore.load(getClass().getClassLoader().getResourceAsStream(elisKeyStore),
                    elisKeyStorePassword.toCharArray());

            KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
            keyManagerFactory.init(keyStore, elisKeyStorePassword.toCharArray());

            return SslContextBuilder.forClient()
                    .keyManager(keyManagerFactory)
                    .build();

        } catch (Exception e) {
            throw new RuntimeException("Error creating SSL context.");
        }
    }

    @Bean
    ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());

        return objectMapper;
    }
}
