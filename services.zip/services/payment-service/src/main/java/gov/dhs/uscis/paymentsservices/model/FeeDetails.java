package gov.dhs.uscis.paymentsservices.model;

import java.math.BigDecimal;
import java.util.List;

public record FeeDetails(BigDecimal amount, String eligibilityCategory, boolean isUnder14, List<String> formTypeList){};
