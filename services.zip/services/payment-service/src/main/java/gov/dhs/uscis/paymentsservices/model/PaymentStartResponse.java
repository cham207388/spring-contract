package gov.dhs.uscis.paymentsservices.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class PaymentStartResponse {

  private String agencyTrackingId;
  private String redirectUrl;

}
