package gov.dhs.uscis.paymentsservices.model;

import gov.dhs.uscis.paymentsservices.entity.PaymentAuthorization;

public class CreateAuthorizationResponse {

    private String redirectUrl;

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public CreateAuthorizationResponse(PaymentAuthorization authorization) {
        this.redirectUrl = authorization.getRedirectUrl();
    }

}
