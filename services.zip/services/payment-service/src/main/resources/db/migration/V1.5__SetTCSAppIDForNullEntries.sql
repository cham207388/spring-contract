update payment_authorization set tcs_app_id = 'TCSDHSUSCISI765PDF' where tcs_app_id is null and form_type is null;
update payment_authorization set tcs_app_id = 'TCSDHSUSCISI765PDF' where tcs_app_id is null and form_type = 'I-765';
update payment_authorization set tcs_app_id = 'TCSDHSUSCISN400PDF' where tcs_app_id is null and form_type = 'N-400';