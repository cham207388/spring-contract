ALTER TABLE payment_authorization
ADD COLUMN eligibility_category VARCHAR(1000);