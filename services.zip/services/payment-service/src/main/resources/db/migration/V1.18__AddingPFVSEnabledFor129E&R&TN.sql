INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-129E', false);
INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-129R', false);
INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-129TN', false);