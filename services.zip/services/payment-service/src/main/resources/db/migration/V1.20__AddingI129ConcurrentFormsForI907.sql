-- Add I-907 to be concurrently filed with all I-129 variants (besides H2A)
INSERT INTO concurrent_forms (primary_form_type, concurrent_form_type, active)
VALUES
    ('I-129H1B', 'I-907', false),
    ('I-129E', 'I-907', false),
    ('I-129R', 'I-907', false),
    ('I-129TN', 'I-907', false);
