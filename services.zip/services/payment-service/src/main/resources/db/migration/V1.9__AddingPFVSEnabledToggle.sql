INSERT INTO toggle(toggle_name, toggle_description, active) 
VALUES ('PFVS_ENABLED', 'Toggle to determine if PFVS validations are enabled.', false);

INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-130', true);

INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-140', true);

INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-485', true);

INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-485A', true);

INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-485J', true);

INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-131', true);

INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-751', true);

INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-129H2A', true);

INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'I-907', true);