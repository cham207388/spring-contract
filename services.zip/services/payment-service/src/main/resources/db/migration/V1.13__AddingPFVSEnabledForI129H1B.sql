UPDATE toggle_form_type_override 
SET active = true 
WHERE toggle_name = 'PFVS_ENABLED' AND form_type = 'I-129H1B';
