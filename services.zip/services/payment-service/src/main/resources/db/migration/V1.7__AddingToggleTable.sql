CREATE TABLE if not exists toggle (
    toggle_name varchar(250) not null,
    toggle_description varchar(250) not null,
    active boolean not null,
    PRIMARY KEY (toggle_name)
);

CREATE TABLE if not exists toggle_form_type_override (
    toggle_name varchar(250) not null,
    form_type varchar(250),
    active boolean not null,
    foreign key (toggle_name) references toggle (toggle_name),
    PRIMARY KEY (toggle_name, form_type)
);