-- Updating existing toggle overrides to inactive for specific I-129 variants
UPDATE toggle_form_type_override
SET active = true
WHERE toggle_name = 'PFVS_ENABLED'
  AND form_type IN ('I-129E', 'I-129R', 'I-129TN');