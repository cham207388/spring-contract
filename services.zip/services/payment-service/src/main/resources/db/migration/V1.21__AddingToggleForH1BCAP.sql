INSERT INTO toggle
(
    toggle_name,
    toggle_description,
    active
)
VALUES
(
    'H1B_CAP',
    'Display H-1B Cap Season related functionality (questions, evidence pages, etc)',
    false
);

INSERT INTO toggle_form_type_override
(
    toggle_name,
    form_type,
    active
)
VALUES (
    'H1B_CAP',
    'I-129H1B',
    false
);