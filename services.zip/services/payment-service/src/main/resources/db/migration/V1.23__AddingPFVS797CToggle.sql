INSERT INTO toggle 
(toggle_name, toggle_description, active) VALUES 
('PFVS_797C', 'Validate 797 & 797C through PFVS', false);

