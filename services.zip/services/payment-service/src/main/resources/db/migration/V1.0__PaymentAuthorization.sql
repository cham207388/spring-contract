CREATE TABLE if not exists payment_authorization (
submission_id varchar(250),
agency_trackingid varchar(250),
PRIMARY KEY (submission_id)
);