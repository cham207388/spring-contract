CREATE TABLE if not exists concurrent_forms (
    primary_form_type varchar(250) not null,
    concurrent_form_type varchar(250) not null,
    active boolean not null,
    PRIMARY KEY (primary_form_type, concurrent_form_type)
);