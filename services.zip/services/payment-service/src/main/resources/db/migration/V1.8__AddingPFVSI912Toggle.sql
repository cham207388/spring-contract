INSERT INTO toggle 
(toggle_name, toggle_description, active) VALUES 
('PFVS_I912', 'Validate I912 through PFVS', false);

INSERT INTO toggle_form_type_override
(toggle_name, form_type, active) VALUES 
('PFVS_I912', 'I-131', false);