ALTER TABLE payment_authorization
ADD COLUMN redirect_url VARCHAR(1000),
ADD COLUMN authorized_amount DECIMAL,
ADD COLUMN final_payment_amount DECIMAL;