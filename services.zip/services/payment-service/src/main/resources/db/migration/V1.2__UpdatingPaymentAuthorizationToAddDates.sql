ALTER TABLE payment_authorization
ADD COLUMN authorized_date DATE NULL,
ADD COLUMN forced_date DATE NULL;