INSERT INTO concurrent_forms 
(primary_form_type, concurrent_form_type, active) VALUES 
('I-485', 'I-485A', true);