insert into concurrent_forms
(primary_form_type, concurrent_form_type, active) 
VALUES 
	('I-485', 'I-131', false),
	('I-485', 'I-765', false),
	('I-485', 'I-485J', false),
    ('I-485', 'I-140', false);
