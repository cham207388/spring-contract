INSERT INTO toggle_form_type_override(toggle_name, form_type, active)
VALUES ('PFVS_ENABLED', 'N-400', false);