ALTER TABLE payment_authorization
ADD COLUMN form_type VARCHAR(10) NULL;