ALTER TABLE payment_authorization
ADD COLUMN tcs_app_id VARCHAR(50) NULL;

update payment_authorization set tcs_app_id = 'TCSDHSUSCISI765PDF' where tcs_app_id = null