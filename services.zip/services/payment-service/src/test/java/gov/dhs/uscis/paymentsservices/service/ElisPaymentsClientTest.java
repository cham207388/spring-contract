package gov.dhs.uscis.paymentsservices.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.UUID;
import java.util.stream.IntStream;

import static org.junit.Assert.assertThrows;
import org.junit.jupiter.api.AfterAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.Mock;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import java.util.List;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.I129H2AEligibilityCategory;
import gov.dhs.uscis.intake.services.SystemClockService;
import gov.dhs.uscis.paymentsservices.entity.PaymentAuthorization;
import gov.dhs.uscis.paymentsservices.entity.PaymentConfirmation;
import gov.dhs.uscis.paymentsservices.model.ElisPaymentRequest;
import gov.dhs.uscis.paymentsservices.model.PaymentStartResponse;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import reactor.core.publisher.Mono;

public class ElisPaymentsClientTest {

  public static MockWebServer mockElis;
  public ElisPaymentsClient elisPaymentsClient;

  @Mock
  private PaymentAuthorization paymentAuthorization;

  final String elisGetDetailsSuccessResponse = "{\"trackingId\":\"agencyTracking\",\"payableFee\":123.12,\"payment\":{\"transactionDate\":1704085200000,\"paymentDate\":1704085200000,\"paymentAmount\":123.12,\"payGovTrackingId\":\"trackingID\",\"paymentStatus\":\"Success\",\"paymentType\":\"CREDITCARD\"},\"isNew\":true}";
  final String elisGetDetailsFailureResponse = "{\"trackingId\":\"agencyTracking\",\"payableFee\":123.12,\"payment\":{\"transactionDate\":1704085200000,\"paymentDate\":1704085200000,\"paymentAmount\":123.12,\"payGovTrackingId\":\"trackingID\",\"paymentStatus\":\"Anything\",\"paymentType\":\"CREDITCARD\"},\"isNew\":true}";
  private String successUrl = "url/payment/success";
  private String cancelUrl = "url/payment/cancel";
  private String i765TcsAppId = "TCS123";
  private String n400TcsAppId = "TCS456";
  private String i131TcsAppId = "TCS789";
  private String i130TcsAppId = "TCS012";
  private String i129H2ATcsAppId = "TCSI129H2A";
  private String i129H1BTcsAppId = "TCSELISI129H1B";
  private String i129EAppId = "TCSUSCISI129PDF";
  private String i129RAppId = "TCSUSCISI129PDF";
  private String i129TNAppId = "TCSUSCISI129PDF";
  private String i751AppId = "TCSDHSUSCISI751PDF";
  private String i140AppId = "TCSDHSUSCISI140PDF";
  private String i485AppId = "TCSUSCISI485PDF";
  private String i485AAppId = "TCSUSCISI485PDF";
  private String i485JAppId = "TCSUSCISI485PDF";
  private String i907TcsAppId = "TCSELISI907";
  private String i90AppId = "TCSELECIMMSYS";
  private String i539AppId = "TCSUSCISI539ELIS";
  private String i765FormType = FormType.I765.getType();
  private String n400FormType = FormType.N400.getType();
  private String i129FormType = FormType.I129H2A.getType();
  private String tcspAppId = "tcsAppId";

  private SystemClockService systemClockService;

  @BeforeEach
  void initialize() throws IOException {
    mockElis = new MockWebServer();
    mockElis.start();
    systemClockService = mock(SystemClockService.class);
    elisPaymentsClient = new ElisPaymentsClient(
        WebClient.create(
            String.format("http://localhost:%s", mockElis.getPort())
        ),
        successUrl,
        cancelUrl,
        i765TcsAppId,
        n400TcsAppId,
        i131TcsAppId,
        i130TcsAppId,
        i129H2ATcsAppId,
        i129H1BTcsAppId,
        i129EAppId,
        i129RAppId,
        i129TNAppId,
        i751AppId,
        i140AppId,
        i485AppId,
        i485AAppId,
        i485JAppId,
        i907TcsAppId,
        i90AppId,
        i539AppId,
        systemClockService
    );
  }

  @AfterAll
  static void tearDown() throws IOException {
    mockElis.shutdown();
  }

  @Test
  void shouldStartAuthorizationI765_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(470), i765FormType, submissionId,
        successUrl, cancelUrl, "C9", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i765TcsAppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I765_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void shouldStartAuthorizationN400_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(470), n400FormType, submissionId,
        successUrl, cancelUrl, "C9", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", n400TcsAppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_N400_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void shouldStartAuthorizationI140_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(715), FormType.I140.getType(), submissionId,
        successUrl, cancelUrl, "112", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i140AppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I140_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void shouldStartAuthorizationI751_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(750), FormType.I751.getType(), submissionId,
        successUrl, cancelUrl, "111", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i751AppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I751_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void shouldStartAuthorizationI485_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(1390), FormType.I485.getType(), submissionId,
        successUrl, cancelUrl, "86", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i485AppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I485_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void shouldStartAuthorizationI485A_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(1390), FormType.I485A.getType(), submissionId,
        successUrl, cancelUrl, "105", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i485AAppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I485A_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void shouldStartAuthorizationH1B_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(460), FormType.I129H1B.getType(), submissionId,
        successUrl, cancelUrl, "166", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i129H1BTcsAppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I129H1B_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void startAuthorizationH2ASuccess() throws JsonProcessingException {
	  BigDecimal amount = BigDecimal.valueOf(460.0);
	  String submissionId = UUID.randomUUID().toString();
	  PaymentStartResponse mockResponse = PaymentStartResponse.builder()
			  .agencyTrackingId("mockAgencyTrackingId")
			  .redirectUrl("mockRedirectUrl")
			  .build();

	  mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
		        .setBody(new ObjectMapper().writeValueAsString(mockResponse)));

	  PaymentAuthorization result = elisPaymentsClient.startAuthorization(amount, FormType.I129H2A.getType(), submissionId, successUrl, cancelUrl, I129H2AEligibilityCategory.NEW_EMPLOYMENT.getCategory(), List.of(), false);
	  assertEquals(submissionId, result.getSubmissionId());
	  assertEquals(mockResponse.getAgencyTrackingId(), result.getAgencyTrackingId());
	  assertEquals(mockResponse.getRedirectUrl(), result.getRedirectUrl());
	  assertEquals(amount, result.getAuthorizedAmount());
	  assertEquals(i129H2ATcsAppId, result.getTcsAppId());
	  assertEquals(I129H2AEligibilityCategory.NEW_EMPLOYMENT.getCategory(), result.getEligibilityCategory());
  }

  @Test
  void shouldStartAuthorizationI129E_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(460), FormType.I129E.getType(), submissionId,
        successUrl, cancelUrl, "189", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i129EAppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I129E_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void shouldStartAuthorizationI129R_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(460), FormType.I129R.getType(), submissionId,
        successUrl, cancelUrl, "96", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i129RAppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I129R_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void shouldStartAuthorizationI129TN_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(460), FormType.I129TN.getType(), submissionId,
        successUrl, cancelUrl, "96", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i129TNAppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I129TN_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void shouldStartAuthorizationI190_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(460), FormType.I90.getType(), submissionId,
        successUrl, cancelUrl, "58", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i90AppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I90_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

    @Test
  void shouldStartAuthorizationII539_Success() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();

    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("url/payment/redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(objectMapper.writeValueAsString(expected)));
    PaymentAuthorization response = elisPaymentsClient.startAuthorization(BigDecimal.valueOf(460), FormType.I539.getType(), submissionId,
        successUrl, cancelUrl, "166", List.of(), false);

    assertNotNull(response.getAgencyTrackingId());

    try {
      RecordedRequest recordedRequest = mockElis.takeRequest();
      assertEquals("POST", recordedRequest.getMethod());
      assertEquals(ElisPaymentsClient.START_AUTHORIZATION_PATH, recordedRequest.getPath());
      String body = recordedRequest.getBody().readUtf8();
      assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i539AppId)));
      assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I539_BENEFIT_CATEGORY_CODE)));
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Test
  void startAuthorizationH2AFailure() {
	  BigDecimal amount = BigDecimal.valueOf(460.0);
	  String submissionId = UUID.randomUUID().toString();

	  mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(400)
		        .setBody("Error"));
	  try {
		  elisPaymentsClient.startAuthorization(amount, FormType.I129H2A.getType(), submissionId, successUrl, cancelUrl, I129H2AEligibilityCategory.NEW_EMPLOYMENT.getCategory(), List.of(), false);
	  } catch(Exception e) {
		  assertEquals(RuntimeException.class, e.getClass());
		  assertEquals("Error", e.getMessage());
	  }
  }

  @Test
  void startAuthorization907Success() throws JsonProcessingException {
	  BigDecimal amount = BigDecimal.valueOf(1685.0);
	  String submissionId = UUID.randomUUID().toString();
	  PaymentStartResponse mockResponse = PaymentStartResponse.builder()
			  .agencyTrackingId("mockAgencyTrackingId")
			  .redirectUrl("mockRedirectUrl")
			  .build();

	  mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
		        .setBody(new ObjectMapper().writeValueAsString(mockResponse)));

	  PaymentAuthorization result = elisPaymentsClient.startAuthorization(amount, FormType.I907.getType(), submissionId, successUrl, cancelUrl, null, List.of(), false);
	  assertEquals(submissionId, result.getSubmissionId());
	  assertEquals(mockResponse.getAgencyTrackingId(), result.getAgencyTrackingId());
	  assertEquals(mockResponse.getRedirectUrl(), result.getRedirectUrl());
	  assertEquals(amount, result.getAuthorizedAmount());
	  assertEquals(i907TcsAppId, result.getTcsAppId());
  }

  @Test
  void startAuthorization907Failure() {
	  BigDecimal amount = BigDecimal.valueOf(1685.0);
	  String submissionId = UUID.randomUUID().toString();

	  mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(400)
		        .setBody("Error"));
	  try {
		  elisPaymentsClient.startAuthorization(amount, FormType.I907.getType(), submissionId, successUrl, cancelUrl, null, List.of(), false);
	  } catch(Exception e) {
		  assertEquals(RuntimeException.class, e.getClass());
		  assertEquals("Error", e.getMessage());
	  }
  }

  @Test
  void shouldStartAuthorization_Fail() throws JsonProcessingException {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String submissionId = UUID.randomUUID().toString();
    var objectMapper = new ObjectMapper();
    String agencyTrackingId = UUID.randomUUID().toString();
    PaymentStartResponse expected = PaymentStartResponse.builder()
        .agencyTrackingId(agencyTrackingId)
        .redirectUrl("redirect")
        .build();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(400)
        .setBody(objectMapper.writeValueAsString(expected)));

    assertThrows(RuntimeException.class,
        () -> elisPaymentsClient.startAuthorization(BigDecimal.valueOf(470), i765FormType, submissionId, successUrl,
            cancelUrl, "C9", List.of(), false));

  }

  @Test
  void shouldCompleteAuthorizationI765_Success() throws Exception {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String agencyTrackingId = UUID.randomUUID().toString();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200));
    PaymentConfirmation confirmation = elisPaymentsClient.completeAuthorization(i765TcsAppId,agencyTrackingId, BigDecimal.valueOf(470), i765FormType,"MOCKED_CATEGORY");

    assertNotNull(confirmation.getAgencyTrackingId());
    assertEquals(AuthorizationStatusCode.Success, confirmation.getAuthorizationStatusCode());

    RecordedRequest recordedRequest = mockElis.takeRequest();
    assertEquals("POST", recordedRequest.getMethod());
    assertEquals(ElisPaymentsClient.SECURE_PAY_COMPLETE_AUTHORIZATION, recordedRequest.getPath());
    String body = recordedRequest.getBody().readUtf8();
    assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", i765TcsAppId)));
    assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_I765_BENEFIT_CATEGORY_CODE)));
  }

  @Test
  void shouldCompleteAuthorizationN400_Success() throws Exception {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String agencyTrackingId = UUID.randomUUID().toString();

    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200));
    PaymentConfirmation confirmation = elisPaymentsClient.completeAuthorization(n400TcsAppId, agencyTrackingId, BigDecimal.valueOf(470), n400FormType,"MOCKED_CATEGORY");

    assertNotNull(confirmation.getAgencyTrackingId());
    assertEquals(AuthorizationStatusCode.Success, confirmation.getAuthorizationStatusCode());

    RecordedRequest recordedRequest = mockElis.takeRequest();
    assertEquals("POST", recordedRequest.getMethod());
    assertEquals(ElisPaymentsClient.SECURE_PAY_COMPLETE_AUTHORIZATION, recordedRequest.getPath());
    String body = recordedRequest.getBody().readUtf8();
    assertTrue(body.contains(String.format("\"tcsAppId\":\"%s\"", n400TcsAppId)));
    assertTrue(body.contains(String.format("\"benefitType\":\"%s\"", ElisPaymentsClient.ELIS_N400_BENEFIT_CATEGORY_CODE)));
  }

  @Test
  void completeAuthorizationH2ASuccess() throws Exception {
	  String agencyTrackingId = "mockAgencyTrackingId";
	  BigDecimal amount = BigDecimal.valueOf(460.0);
	  ZonedDateTime zdt = ZonedDateTime.of(LocalDateTime.now(), ZoneId.systemDefault());

	  doReturn(zdt).when(systemClockService).getSystemTime();

	  mockElis.enqueue(new MockResponse().setResponseCode(200));

	  PaymentConfirmation result = elisPaymentsClient.completeAuthorization(i129H2ATcsAppId, agencyTrackingId, amount, FormType.I129H2A.getType(), I129H2AEligibilityCategory.NEW_EMPLOYMENT.getCategory());
	  assertEquals(zdt, result.getTimestamp());
	  assertEquals(agencyTrackingId, result.getAgencyTrackingId());
	  assertEquals(AuthorizationStatusCode.Success, result.getAuthorizationStatusCode());

	  RecordedRequest recordedRequest = mockElis.takeRequest();
	  ElisPaymentRequest elisPaymentRequest = new ObjectMapper().readValue(recordedRequest.getBody().readUtf8(), ElisPaymentRequest.class);
	  assertEquals(i129H2ATcsAppId, elisPaymentRequest.getTcsAppId());
	  assertEquals(ElisPaymentsClient.ELIS_I129H2A_BENEFIT_CATEGORY_CODE, elisPaymentRequest.getBenefitType());
	  assertEquals(amount, elisPaymentRequest.getTransactionAmount());
	  assertEquals(agencyTrackingId, elisPaymentRequest.getAgencyTrackingId());
	  assertEquals(I129H2AEligibilityCategory.NEW_EMPLOYMENT.getCategory(), elisPaymentRequest.getEligibilityCategory());
  }

  @Test
  void completeAuthorization907Success() throws Exception {
	  String agencyTrackingId = "mockAgencyTrackingId";
	  BigDecimal amount = BigDecimal.valueOf(1685.0);
	  ZonedDateTime zdt = ZonedDateTime.of(LocalDateTime.now(), ZoneId.systemDefault());

	  doReturn(zdt).when(systemClockService).getSystemTime();

	  mockElis.enqueue(new MockResponse().setResponseCode(200));

	  PaymentConfirmation result = elisPaymentsClient.completeAuthorization(i907TcsAppId, agencyTrackingId, amount, FormType.I907.getType(), null);
	  assertEquals(zdt, result.getTimestamp());
	  assertEquals(agencyTrackingId, result.getAgencyTrackingId());
	  assertEquals(AuthorizationStatusCode.Success, result.getAuthorizationStatusCode());

	  RecordedRequest recordedRequest = mockElis.takeRequest();
	  ElisPaymentRequest elisPaymentRequest = new ObjectMapper().readValue(recordedRequest.getBody().readUtf8(), ElisPaymentRequest.class);
	  assertEquals(i907TcsAppId, elisPaymentRequest.getTcsAppId());
	  assertEquals(ElisPaymentsClient.ELIS_I907_BENEFIT_CATEGORY_CODE, elisPaymentRequest.getBenefitType());
	  assertEquals(amount, elisPaymentRequest.getTransactionAmount());
	  assertEquals(agencyTrackingId, elisPaymentRequest.getAgencyTrackingId());
  }

  @Test
  void completeAuthorizationH2ADeclined() throws Exception {
	  String agencyTrackingId = "mockAgencyTrackingId";
	  BigDecimal amount = BigDecimal.valueOf(460.0);
	  ZonedDateTime zdt = ZonedDateTime.of(LocalDateTime.now(), ZoneId.systemDefault());

	  doReturn(zdt).when(systemClockService).getSystemTime();

	  MockResponse response = new MockResponse().setResponseCode(409);
	  IntStream.range(0, 4).forEach(i -> mockElis.enqueue(response));

	  PaymentConfirmation result = elisPaymentsClient.completeAuthorization(i129H2ATcsAppId, agencyTrackingId, amount, FormType.I129H2A.getType(), I129H2AEligibilityCategory.NEW_EMPLOYMENT.getCategory());
	  assertEquals(zdt, result.getTimestamp());
	  assertEquals(agencyTrackingId, result.getAgencyTrackingId());
	  assertEquals(AuthorizationStatusCode.Declined, result.getAuthorizationStatusCode());

	  RecordedRequest recordedRequest = mockElis.takeRequest();
	  ElisPaymentRequest elisPaymentRequest = new ObjectMapper().readValue(recordedRequest.getBody().readUtf8(), ElisPaymentRequest.class);
	  assertEquals(i129H2ATcsAppId, elisPaymentRequest.getTcsAppId());
	  assertEquals(ElisPaymentsClient.ELIS_I129H2A_BENEFIT_CATEGORY_CODE, elisPaymentRequest.getBenefitType());
	  assertEquals(amount, elisPaymentRequest.getTransactionAmount());
	  assertEquals(agencyTrackingId, elisPaymentRequest.getAgencyTrackingId());
	  assertEquals(I129H2AEligibilityCategory.NEW_EMPLOYMENT.getCategory(), elisPaymentRequest.getEligibilityCategory());
  }

  @Test
  void completeAuthorization907Declined() throws Exception {
	  String agencyTrackingId = "mockAgencyTrackingId";
	  BigDecimal amount = BigDecimal.valueOf(1685.0);
	  ZonedDateTime zdt = ZonedDateTime.of(LocalDateTime.now(), ZoneId.systemDefault());

	  doReturn(zdt).when(systemClockService).getSystemTime();

	  MockResponse response = new MockResponse().setResponseCode(409);
	  IntStream.range(0, 4).forEach(i -> mockElis.enqueue(response));

	  PaymentConfirmation result = elisPaymentsClient.completeAuthorization(i907TcsAppId, agencyTrackingId, amount, FormType.I907.getType(), null);
	  assertEquals(zdt, result.getTimestamp());
	  assertEquals(agencyTrackingId, result.getAgencyTrackingId());
	  assertEquals(AuthorizationStatusCode.Declined, result.getAuthorizationStatusCode());

	  RecordedRequest recordedRequest = mockElis.takeRequest();
	  ElisPaymentRequest elisPaymentRequest = new ObjectMapper().readValue(recordedRequest.getBody().readUtf8(), ElisPaymentRequest.class);
	  assertEquals(i907TcsAppId, elisPaymentRequest.getTcsAppId());
	  assertEquals(ElisPaymentsClient.ELIS_I907_BENEFIT_CATEGORY_CODE, elisPaymentRequest.getBenefitType());
	  assertEquals(amount, elisPaymentRequest.getTransactionAmount());
	  assertEquals(agencyTrackingId, elisPaymentRequest.getAgencyTrackingId());
  }

  @Test
  void completeAuthorizationH2AError() throws Exception {
	  String agencyTrackingId = "mockAgencyTrackingId";
	  BigDecimal amount = BigDecimal.valueOf(460.0);
	  ZonedDateTime zdt = ZonedDateTime.of(LocalDateTime.now(), ZoneId.systemDefault());

	  doReturn(zdt).when(systemClockService).getSystemTime();

	  MockResponse response = new MockResponse().setResponseCode(500);
	  IntStream.range(0, 4).forEach(i -> mockElis.enqueue(response));

	  PaymentConfirmation result = elisPaymentsClient.completeAuthorization(i129H2ATcsAppId, agencyTrackingId, amount, FormType.I129H2A.getType(), I129H2AEligibilityCategory.NEW_EMPLOYMENT.getCategory());
	  assertEquals(zdt, result.getTimestamp());
	  assertEquals(agencyTrackingId, result.getAgencyTrackingId());
	  assertEquals(AuthorizationStatusCode.Error, result.getAuthorizationStatusCode());

	  RecordedRequest recordedRequest = mockElis.takeRequest();
	  ElisPaymentRequest elisPaymentRequest = new ObjectMapper().readValue(recordedRequest.getBody().readUtf8(), ElisPaymentRequest.class);
	  assertEquals(i129H2ATcsAppId, elisPaymentRequest.getTcsAppId());
	  assertEquals(ElisPaymentsClient.ELIS_I129H2A_BENEFIT_CATEGORY_CODE, elisPaymentRequest.getBenefitType());
	  assertEquals(amount, elisPaymentRequest.getTransactionAmount());
	  assertEquals(agencyTrackingId, elisPaymentRequest.getAgencyTrackingId());
	  assertEquals(I129H2AEligibilityCategory.NEW_EMPLOYMENT.getCategory(), elisPaymentRequest.getEligibilityCategory());
  }

  @Test
  void shouldCompleteAuthorization_Decline() throws Exception {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String agencyTrackingId = UUID.randomUUID().toString();

    MockResponse response = new MockResponse()
      .addHeader("Content-Type", "application/json")
      .setResponseCode(409)
      .setBody("Card declined");
    IntStream.range(0, 4).forEach(i -> mockElis.enqueue(response)); // multiple retries
    PaymentConfirmation confirmation = elisPaymentsClient.completeAuthorization(tcspAppId,agencyTrackingId, BigDecimal.valueOf(470), i765FormType,"MOCKED_CATEGORY");

    assertNotNull(confirmation.getAgencyTrackingId());
    assertEquals(AuthorizationStatusCode.Declined, confirmation.getAuthorizationStatusCode());

    RecordedRequest recordedRequest = mockElis.takeRequest();
    assertEquals("POST", recordedRequest.getMethod());
    assertEquals(ElisPaymentsClient.SECURE_PAY_COMPLETE_AUTHORIZATION, recordedRequest.getPath());
  }

  @Test
  void shouldCompleteAuthorization_Failure() throws Exception {
    ReflectionTestUtils.setField(elisPaymentsClient, "enabled", true);
    String agencyTrackingId = UUID.randomUUID().toString();

    MockResponse response = new MockResponse()
      .addHeader("Content-Type", "application/json")
      .setResponseCode(500)
      .setBody("Internal server exception");
    IntStream.range(0, 4).forEach(i -> mockElis.enqueue(response)); // multiple retries
    PaymentConfirmation confirmation = elisPaymentsClient.completeAuthorization(tcspAppId,agencyTrackingId, BigDecimal.valueOf(470), i765FormType,"MOCKED_CATEGORY");

    assertNotNull(confirmation.getAgencyTrackingId());
    assertEquals(AuthorizationStatusCode.Error, confirmation.getAuthorizationStatusCode());

    RecordedRequest recordedRequest = mockElis.takeRequest();
    assertEquals("POST", recordedRequest.getMethod());
    assertEquals(ElisPaymentsClient.SECURE_PAY_COMPLETE_AUTHORIZATION, recordedRequest.getPath());
  }

  @Test
  public void shouldHandleAResponseCodeThatIs200ButTheBodyIsEmpty() throws Exception {
    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200));
    var statusCode = elisPaymentsClient.getAuthorizationStatusCode("agencyTrackingId", i765FormType);
    assertEquals(statusCode, AuthorizationStatusCode.Pending);

    RecordedRequest recordedRequest = mockElis.takeRequest();
    assertEquals("GET", recordedRequest.getMethod());
    assertTrue(recordedRequest.getPath().contains(i765TcsAppId));
  }

  @Test
  public void shouldHandleAResponseCodeThatIsNot200() throws Exception {
    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(409));
    var statusCode = elisPaymentsClient.getAuthorizationStatusCode("agencyTrackingId", n400FormType);
    assertEquals(statusCode, AuthorizationStatusCode.Pending);

    RecordedRequest recordedRequest = mockElis.takeRequest();
    assertEquals("GET", recordedRequest.getMethod());
    assertTrue(recordedRequest.getPath().contains(n400TcsAppId));
  }

  @Test
  public void shouldReturnAuthorizationStatusWhenAuthorized() throws JsonProcessingException {
    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(elisGetDetailsSuccessResponse));
    AuthorizationStatusCode code = elisPaymentsClient.getAuthorizationStatusCode("agencyTrackingId", i765FormType);

    assertEquals(code, AuthorizationStatusCode.Success);
  }

  @Test
  public void shouldReturnNotAuthorizedWhenTheResponseIsNotSuccess() throws JsonProcessingException {
    mockElis.enqueue(new MockResponse().addHeader("Content-Type", "application/json").setResponseCode(200)
        .setBody(elisGetDetailsFailureResponse));
    AuthorizationStatusCode code = elisPaymentsClient.getAuthorizationStatusCode("agencyTrackingId", i765FormType);

    assertEquals(code, AuthorizationStatusCode.Pending);
  }

  @Test
  public void shouldCancelAuthorization() throws InterruptedException {
    WebClient webClient = mock(WebClient.class);
    
    var client = new ElisPaymentsClient(webClient, successUrl, cancelUrl, i765TcsAppId, n400TcsAppId, i131TcsAppId, i130TcsAppId, i129H2ATcsAppId, i751AppId, i140AppId, i485AppId, i485AAppId, i485JAppId, i907TcsAppId, i129H1BTcsAppId, i129EAppId, i129RAppId, i129TNAppId, i90AppId, i539AppId, mock(SystemClockService.class));
    
    @SuppressWarnings("rawtypes")
    WebClient.RequestHeadersUriSpec get = mock(WebClient.RequestHeadersUriSpec.class);

    when(webClient.get()).thenReturn(get);
    when(get.uri(anyString())).thenReturn(get);
    ResponseSpec responseSpec = mock(ResponseSpec.class);
    when(get.retrieve()).thenReturn(responseSpec);
    when(responseSpec.toBodilessEntity()).thenReturn(Mono.just(ResponseEntity.ok().build()));

    client.cancelAuthorization("agencyTrackingId", i765FormType);
    ArgumentCaptor<String> arg = ArgumentCaptor.forClass(String.class);

    verify(get).uri(arg.capture());
    assertEquals("/secure/pay/cancelAuthorization?tcsAppId=" + i765TcsAppId + "&agencyTrackingId=agencyTrackingId", arg.getValue());
  }

  @Test
  public void shouldCancelAutoingestionPayment() throws InterruptedException {
    WebClient webClient = mock(WebClient.class);

    var client = new ElisPaymentsClient(webClient, successUrl, cancelUrl, i765TcsAppId, n400TcsAppId, i131TcsAppId, i130TcsAppId, i129H2ATcsAppId, i751AppId, i140AppId, i485AppId, i485AAppId, i485JAppId, i907TcsAppId, i129H1BTcsAppId, i129EAppId, i129RAppId, i129TNAppId, i90AppId, i539AppId, mock(SystemClockService.class));

    @SuppressWarnings("rawtypes")
    WebClient.RequestHeadersUriSpec get = mock(WebClient.RequestHeadersUriSpec.class);

    when(webClient.get()).thenReturn(get);
    when(get.uri(anyString())).thenReturn(get);
    ResponseSpec responseSpec = mock(ResponseSpec.class);
    when(get.retrieve()).thenReturn(responseSpec);
    when(responseSpec.toBodilessEntity()).thenReturn(Mono.just(ResponseEntity.ok().build()));

    client.cancelAuthorization("agencyTrackingId", i129FormType);
    ArgumentCaptor<String> arg = ArgumentCaptor.forClass(String.class);

    verify(get).uri(arg.capture());
    assertEquals("/secure/pay/pdfi/cancel?tcsAppId=" + i129H2ATcsAppId + "&agencyTrackingId=agencyTrackingId", arg.getValue());
  }

  @Test
  public void shouldHandleIfServiceReturnsA404() throws InterruptedException {

    WebClient webClient = mock(WebClient.class);

    var client = new ElisPaymentsClient(webClient, successUrl, cancelUrl, i765TcsAppId, n400TcsAppId, i131TcsAppId, i130TcsAppId, i129H2ATcsAppId, i751AppId, i140AppId, i485AppId, i485AAppId, i485JAppId, i907TcsAppId, i129H1BTcsAppId, i129EAppId, i129RAppId, i129TNAppId, i90AppId,i539AppId, mock(SystemClockService.class));

    @SuppressWarnings("rawtypes")
    WebClient.RequestHeadersUriSpec get = mock(WebClient.RequestHeadersUriSpec.class);

    when(webClient.get()).thenReturn(get);
    when(get.uri(anyString())).thenReturn(get);
    when(get.retrieve())
        .thenThrow(new WebClientResponseException(404, null, null, "".getBytes(), Charset.defaultCharset()));

    client.cancelAuthorization("agencyTrackingId", n400FormType);
    ArgumentCaptor<String> arg = ArgumentCaptor.forClass(String.class);

    verify(get).uri(arg.capture());
    assertEquals("/secure/pay/cancelAuthorization?tcsAppId=" + n400TcsAppId + "&agencyTrackingId=agencyTrackingId", arg.getValue());
  }

  @Test
  public void shouldHandleIfServiceReturnsA500() throws InterruptedException {
    WebClient webClient = mock(WebClient.class);

    var client = new ElisPaymentsClient(webClient, successUrl, cancelUrl, i765TcsAppId, n400TcsAppId, i131TcsAppId, i130TcsAppId, i129H2ATcsAppId, i751AppId, i140AppId, i485AppId, i485AAppId, i485JAppId, i907TcsAppId, i129H1BTcsAppId, i129EAppId, i129RAppId, i129TNAppId, i90AppId, i539AppId, mock(SystemClockService.class));

    @SuppressWarnings("rawtypes")
    WebClient.RequestHeadersUriSpec get = mock(WebClient.RequestHeadersUriSpec.class);

    when(webClient.get()).thenReturn(get);
    when(get.uri(anyString())).thenReturn(get);
    when(get.retrieve())
        .thenThrow(new WebClientResponseException(500, null, null, "".getBytes(), Charset.defaultCharset()));

    WebClientResponseException e = assertThrows(WebClientResponseException.class, () ->
        client.cancelAuthorization("agencyTrackingId", i765FormType));
    assertEquals(500, e.getStatusCode().value());
  }
}
