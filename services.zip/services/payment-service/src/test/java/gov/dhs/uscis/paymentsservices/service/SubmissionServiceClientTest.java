package gov.dhs.uscis.paymentsservices.service;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.Duration;

import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.paymentsservices.exception.SubmissionNotFoundException;
import okhttp3.mockwebserver.MockWebServer;
import reactor.netty.http.client.HttpClient;
import gov.dhs.uscis.paymentsservices.model.FeeDetails;

public class SubmissionServiceClientTest {

    private MockWebServer webServer;
    private SubmissionServiceClient submissionServiceClient;

    @BeforeEach
    public void setup() throws IOException {
        webServer = new MockWebServer();
        webServer.start();

        HttpClient httpClient = HttpClient.create().responseTimeout(Duration.ofSeconds(1));

        WebClient webClient = WebClient.builder()
                .baseUrl(String.format("http://localhost:%s", webServer.getPort()))
                .clientConnector(new ReactorClientHttpConnector(httpClient))

                .build();

        submissionServiceClient = new SubmissionServiceClient(webClient);
    }

    @Test
    public void shouldParseValueForI765() {
        webServer.enqueue(new okhttp3.mockwebserver.MockResponse().addHeader("Content-Type", "application/json")
                .setBody("{\"amount\":470, \"eligibilityCategory\":\"C9\",\"isUnder14\": false, \"formTypeList\": []}"));
        Assertions.assertThat(
                submissionServiceClient.getFeeForSubmissionAmount("6f5ed4db-77a0-3218-86d9-9b1403f7870d"))
                .isEqualTo(new FeeDetails(new BigDecimal("470"), "C9", false, List.of()));
    }

    @Test
    public void shouldHandleNoSubmissionFound() {
        webServer.enqueue(new okhttp3.mockwebserver.MockResponse().setResponseCode(404));
        assertThrows(SubmissionNotFoundException.class,
                () -> submissionServiceClient.getFeeForSubmissionAmount("6f5ed4db-77a0-3218-86d9-9b1403f7870d"));
    }

}
