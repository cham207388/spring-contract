package gov.dhs.uscis.paymentsservices;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;

import gov.dhs.uscis.paymentsservices.config.TestConfig;
import gov.dhs.uscis.paymentsservices.controller.PaymentsController;
import gov.dhs.uscis.paymentsservices.entity.PaymentAuthorization;
import gov.dhs.uscis.paymentsservices.enumeration.PaymentAuthorizationStatus;
import gov.dhs.uscis.paymentsservices.service.PaymentsService;
import io.restassured.module.mockmvc.RestAssuredMockMvc;

@SpringBootTest
@ContextConfiguration(classes = TestConfig.class)
public abstract class BaseContractTest {

    @Autowired
    private PaymentsController paymentsController;

    @MockBean
    private PaymentsService paymentsService;

    @BeforeEach
    void setUp() throws Exception {
        RestAssuredMockMvc.standaloneSetup(paymentsController);
        when(paymentsService.getPaymentAuthorizationStatus(anyString(), any(BigDecimal.class), anyString()))
            .thenReturn(PaymentAuthorizationStatus.Authorized);

        PaymentAuthorization mockPaymentAuthorization = mock(PaymentAuthorization.class);
        when(paymentsService.startAuthorization(anyString(), anyString(), anyString(), anyString()))
            .thenReturn(mockPaymentAuthorization);
        when(mockPaymentAuthorization.getRedirectUrl()).thenReturn("http://redirect.org");
        doNothing().when(paymentsService).completeAuthorization(anyString(), any(BigDecimal.class));
        doNothing().when(paymentsService).cancelAuthorization(anyString());
    }
}