package gov.dhs.uscis.paymentsservices.config;

import static org.mockito.Mockito.mock;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import gov.dhs.uscis.paymentsservices.controller.PaymentsController;
import gov.dhs.uscis.paymentsservices.service.PaymentsService;

@Configuration
public class TestConfig {

    @Bean
    public PaymentsService postService() {
        return mock(PaymentsService.class); // Provide a mocked PostService
    }

    @Bean
    public PaymentsController postController(PaymentsService postService) {
        return new PaymentsController(postService); // Provide PostController using mocked PostService
    }
}
