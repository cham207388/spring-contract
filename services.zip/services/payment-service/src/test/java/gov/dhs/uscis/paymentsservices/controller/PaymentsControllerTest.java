package gov.dhs.uscis.paymentsservices.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.UUID;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.paymentsservices.entity.PaymentAuthorization;
import gov.dhs.uscis.paymentsservices.enumeration.PaymentAuthorizationStatus;
import gov.dhs.uscis.paymentsservices.exception.PaymentDeclinedException;
import gov.dhs.uscis.paymentsservices.exception.PaymentErrorException;
import gov.dhs.uscis.paymentsservices.exception.SubmissionNotFoundException;
import gov.dhs.uscis.paymentsservices.model.FeeDetails;
import gov.dhs.uscis.paymentsservices.model.PaymentAcceptanceRequest;
import gov.dhs.uscis.paymentsservices.service.PaymentsService;
import gov.dhs.uscis.paymentsservices.service.SubmissionServiceClient;

public class PaymentsControllerTest {

    @Test
    public void shouldCreateAnAuthorizationForASubmissionId() throws Exception {
        PaymentsService service = mock(PaymentsService.class);
        String uuid = UUID.randomUUID().toString();

        String value = "responseRedirectUrl";
        var paymentAuthorization = new PaymentAuthorization(uuid, "tracking", value, BigDecimal.TEN,
                FormType.I765.getType(), "tcspAppId","C9");
        var submissionServiceClient = mock(SubmissionServiceClient.class);
        when(submissionServiceClient.getFeeForSubmissionAmount(any()))
            .thenReturn(new FeeDetails(BigDecimal.TEN, "C9", false, List.of("I-765")));

        when(service.startAuthorization(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(paymentAuthorization);

        WebTestClient controller = WebTestClient
                .bindToController(new PaymentsController(service))
                .build()
                .mutate()
                .responseTimeout(Duration.ofMillis(30000))
                .build();

        controller.get().uri("/api/v1/payments/" + uuid
                + "/authorization?feeTotal=10.00&formType=I-765&successUrl=htt://localhost/success&cancelUrl=htt://localhost/cancel")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().is2xxSuccessful()
                .expectBody().jsonPath("$.redirectUrl").isEqualTo(value);
    }

    @Test
    public void shouldReturna404IfSubmissionDoesNotExist() throws Exception {
        PaymentsService service = mock(PaymentsService.class);
        String uuid = UUID.randomUUID().toString();
        String value = "responseRedirectUrl";

        when(service.startAuthorization(anyString(), anyString(), anyString(), anyString()))
                .thenThrow(SubmissionNotFoundException.class);

        WebTestClient controller = WebTestClient
                .bindToController(new PaymentsController(service))
                .build()
                .mutate()
                .responseTimeout(Duration.ofMillis(30000))
                .build();

        controller.get().uri("/api/v1/payments/" + uuid
                + "/authorization?feeTotal=10.00&formType=I-765&successUrl=htt://localhost/success&cancelUrl=htt://localhost/cancel")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound();
    }

    @Test
    public void shouldAcceptAPaymentOnAnExistingAuthorization() throws Exception {

        PaymentsService service = mock(PaymentsService.class);
        String uuid = UUID.randomUUID().toString();

        PaymentAcceptanceRequest request = new PaymentAcceptanceRequest();
        request.setFeeTotal(BigDecimal.TEN);
        request.setSubmissionId(uuid);

        MockMvc controller = MockMvcBuilders.standaloneSetup(new PaymentsController(service)).build();
        controller.perform(post("/api/v1/payments/" + uuid + "/authorization")
                .content(new ObjectMapper().writeValueAsString(request))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(service).completeAuthorization(uuid, BigDecimal.TEN);
    }

    @Test
    public void shouldNotAcceptAPaymentOnAnAuthorizationThatDoesNotExist() throws Exception {

        PaymentsService service = mock(PaymentsService.class);
        doThrow(NotFoundException.class).when(service).completeAuthorization(any(), any());
        String uuid = UUID.randomUUID().toString();

        PaymentAcceptanceRequest request = new PaymentAcceptanceRequest();
        request.setFeeTotal(BigDecimal.TEN);
        request.setSubmissionId(uuid);

        MockMvc controller = MockMvcBuilders.standaloneSetup(new PaymentsController(service)).build();
        controller.perform(post("/api/v1/payments/" + uuid + "/authorization")
                .content(new ObjectMapper().writeValueAsString(request))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(service).completeAuthorization(uuid, BigDecimal.TEN);
    }

    @Test
    public void shouldReturn400ForDeclinedPayment() throws Exception {

        PaymentsService service = mock(PaymentsService.class);
        String uuid = UUID.randomUUID().toString();

        PaymentAcceptanceRequest request = new PaymentAcceptanceRequest();
        request.setFeeTotal(BigDecimal.TEN);
        request.setSubmissionId(uuid);
        doThrow(PaymentDeclinedException.class).when(service).completeAuthorization(uuid, BigDecimal.TEN);

        MockMvc controller = MockMvcBuilders.standaloneSetup(new PaymentsController(service)).build();
        controller.perform(post("/api/v1/payments/" + uuid + "/authorization")
                .content(new ObjectMapper().writeValueAsString(request))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError())
                .andExpect(jsonPath("$.result", org.hamcrest.Matchers.is(AuthorizationStatusCode.Declined.name())));

        verify(service).completeAuthorization(uuid, BigDecimal.TEN);
    }

    @Test
    public void shouldReturn400ForErrorCompletingPayment() throws Exception {

        PaymentsService service = mock(PaymentsService.class);
        String uuid = UUID.randomUUID().toString();

        PaymentAcceptanceRequest request = new PaymentAcceptanceRequest();
        request.setFeeTotal(BigDecimal.TEN);
        request.setSubmissionId(uuid);
        doThrow(PaymentErrorException.class).when(service).completeAuthorization(uuid, BigDecimal.TEN);

        MockMvc controller = MockMvcBuilders.standaloneSetup(new PaymentsController(service)).build();
        controller.perform(post("/api/v1/payments/" + uuid + "/authorization")
                .content(new ObjectMapper().writeValueAsString(request))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError())
                .andExpect(jsonPath("$.result", org.hamcrest.Matchers.is(AuthorizationStatusCode.Error.name())));

        verify(service).completeAuthorization(uuid, BigDecimal.TEN);
    }

    @Test
    public void shouldCancelATransactionThatIsCurrentlyAuthorized() throws Exception {
        PaymentsService service = mock(PaymentsService.class);
        String uuid = UUID.randomUUID().toString();
        MockMvc controller = MockMvcBuilders.standaloneSetup(new PaymentsController(service)).build();
        controller.perform(delete("/api/v1/payments/" + uuid + "/authorization")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(service).cancelAuthorization(uuid);
    }

    @Test
    @Disabled
    public void shouldCancelATransactionThatIsCurrentlyNotAuthorized() throws Exception {
        // PaymentsService service = mock(PaymentsService.class);
        // String uuid = UUID.randomUUID().toString();

        // //
        // doThrow(PaymentNotFoundException.class).when(service).cancelAuthorization(uuid);
        // // when(service.cancelAuthorization(any())).thenReturn(Mono.error(new
        // PaymentNotFoundException(uuid)));
        // // .thenThrow(new PaymentNotFoundException("foo"));

        // WebTestClient controller = WebTestClient
        // .bindToController(new PaymentsController(service))
        // .build()
        // .mutate()
        // .responseTimeout(Duration.ofMillis(30000))
        // .build();

        // var result = controller.delete().uri("/api/v1/payments/" + uuid +
        // "/authorization")
        // .accept(MediaType.APPLICATION_JSON)
        // .exchange()
        // .expectStatus().is4xxClientError();

        // verify(service).cancelAuthorization(uuid);
        // assertEquals(result, "404");
    }

    @Test
    public void shouldReturnNotAuthorizedResponseWhenServiceReturnsNotAuthorized() throws Exception {
        PaymentsService service = mock(PaymentsService.class);
        String uuid = UUID.randomUUID().toString();

        var status = PaymentAuthorizationStatus.NotAuthorized;
        when(service.getPaymentAuthorizationStatus(any(), any(), any())).thenReturn(status);
        MockMvc controller = MockMvcBuilders.standaloneSetup(new PaymentsController(service)).build();

        controller.perform(get("/api/v1/payments/" + uuid + "/authorization/status?feeTotal=10.00&formType=I-765")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status", org.hamcrest.Matchers.is("NotAuthorized")))
                .andExpect(status().isOk());
    }

    @Test
    public void shouldReturnAuthorizedResponseWhenServiceReturnsNotAuthorized() throws Exception {
        PaymentsService service = mock(PaymentsService.class);
        String uuid = UUID.randomUUID().toString();

        var status = PaymentAuthorizationStatus.Authorized;
        when(service.getPaymentAuthorizationStatus(any(), any(), any())).thenReturn(status);
        MockMvc controller = MockMvcBuilders.standaloneSetup(new PaymentsController(service)).build();

        controller.perform(get("/api/v1/payments/" + uuid + "/authorization/status?feeTotal=10.00&formType=I-765")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status", org.hamcrest.Matchers.is("Authorized")))
                .andExpect(status().isOk());
    }

    @Test
    public void shouldDeleteAnAuthorizationForASubmissionIdWhenUserCancels() throws Exception {
        PaymentsService service = mock(PaymentsService.class);
        String uuid = UUID.randomUUID().toString();

        MockMvc controller = MockMvcBuilders.standaloneSetup(new PaymentsController(service)).build();

        controller.perform(delete("/api/v1/payments/" + uuid + "/payment")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(service, times(1)).removeAuthorization(uuid);
    }
}
