package gov.dhs.uscis.paymentsservices.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.UUID;
import java.util.List;

import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import gov.dhs.uscis.intake.enums.AuthorizationStatusCode;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.exceptions.S3DeleteObjectException;
import gov.dhs.uscis.paymentsservices.entity.PaymentAuthorization;
import gov.dhs.uscis.paymentsservices.entity.PaymentConfirmation;
import gov.dhs.uscis.paymentsservices.enumeration.PaymentAuthorizationStatus;
import gov.dhs.uscis.paymentsservices.exception.PaymentDeclinedException;
import gov.dhs.uscis.paymentsservices.exception.PaymentErrorException;
import gov.dhs.uscis.paymentsservices.exception.SubmissionNotFoundException;
import gov.dhs.uscis.paymentsservices.model.FeeDetails;
import gov.dhs.uscis.paymentsservices.repository.PaymentRepository;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

public class PaymentsServiceTest {
    private ElisPaymentsClient elisPaymentClient;
    private SubmissionServiceClient submissionServiceClient;
    private PaymentRepository paymentRepository;
    private PaymentsService service;
    private String submissionId;
    private String testAgencyTrackingId = "agencyTrackingId";
    private String tcsAppId = "tcsAppId";

    @BeforeEach
    void setup() {
        paymentRepository = mock(PaymentRepository.class);
        elisPaymentClient = mock(ElisPaymentsClient.class);
        submissionServiceClient = mock(SubmissionServiceClient.class);
        service = new PaymentsService(paymentRepository, elisPaymentClient, submissionServiceClient);
        submissionId = UUID.randomUUID().toString();
    }

    @Test
    public void shouldCreateNewAuthorizationIfNoSubmission() {
        BigDecimal feeTotal = BigDecimal.valueOf(200);
        String formType = FormType.I765.getType();
        String success = "http://localhost/success";
        String cancel = "http://localhost/cancel";

        String eligibilityCategory = "C9";
		when(submissionServiceClient.getFeeForSubmissionAmount(submissionId)).thenReturn(new FeeDetails(feeTotal, eligibilityCategory, false, List.of()));
        when(paymentRepository.findPaymentBySubmissionId(submissionId)).thenReturn(null);
        PaymentAuthorization expected = new PaymentAuthorization(submissionId, "agencyTrackingId", "redirectUrl",
                feeTotal, formType, tcsAppId, eligibilityCategory);
        when(elisPaymentClient.startAuthorization(feeTotal, formType, submissionId, success, cancel, eligibilityCategory, List.of(), false))
                .thenReturn(expected);
        service.startAuthorization(submissionId, formType, success, cancel);

        verify(elisPaymentClient, times(1)).startAuthorization(feeTotal, formType, submissionId, success, cancel, eligibilityCategory, List.of(), false);
        verify(paymentRepository, times(1)).save(expected);
        assertThat(expected.getAuthorizedDate()).isEqualTo(LocalDate.now());
        assertThat(expected.getForcedDate()).isNull();
    }

    @Test
    public void shouldNotNewAuthorizationIfNoSubmissionFee() {
        BigDecimal feeTotal = BigDecimal.valueOf(200);
        String formType = FormType.I765.getType();
        String success = "http://localhost/success";
        String cancel = "http://localhost/cancel";
        String eligibilityCategory = "C9";
        when(submissionServiceClient.getFeeForSubmissionAmount(submissionId)).thenReturn(null);
        when(paymentRepository.findPaymentBySubmissionId(submissionId)).thenReturn(null);
        PaymentAuthorization expected = new PaymentAuthorization(submissionId, "agencyTrackingId", "redirectUrl",
                feeTotal, formType, tcsAppId,eligibilityCategory);
        
		when(elisPaymentClient.startAuthorization(feeTotal, formType, submissionId, success, cancel, eligibilityCategory, List.of(), false))
                .thenReturn(expected);
        // service.startAuthorization(submissionId, formType, success, cancel);

        assertThrows(NullPointerException.class, () -> {
            service.startAuthorization(submissionId, formType, success, cancel);
        });
    }

    @Test
    public void shouldCancelAnAuthorizationThatIsCurrentlyPendingBecauseOfAReject() throws NotFoundException {
        PaymentAuthorization payment = mock(PaymentAuthorization.class);
        when(payment.getAgencyTrackingId()).thenReturn(testAgencyTrackingId);
        String formType = FormType.N400.getType();
        when(payment.getFormType()).thenReturn(formType);
        when(paymentRepository.findPaymentBySubmissionId(submissionId.toString())).thenReturn(payment);

        service.cancelAuthorization(submissionId);

        verify(paymentRepository).findPaymentBySubmissionId(submissionId.toString());
        verify(elisPaymentClient).cancelAuthorization(testAgencyTrackingId, formType);

        // Todo: Discuss with Odwayne if we should consider this being the statusof why
        // it was canceled or that it is of status canceled.
        // verify(submissionServiceClient).updateSubmissionWithCanceledPaymentById(submissionId,
        // AuthorizationStatusCode.Canceled);
        // ArgumentCaptor<PaymentAuthorization> paymentRepositoryCaptor = ArgumentCaptor
        // .forClass(PaymentAuthorization.class);
        // verify(paymentRepository).save(paymentRepositoryCaptor.capture());

        // var savedPayment = paymentRepositoryCaptor.getValue();
        // assertThat(savedPayment.getAgencyTrackingId()).isEqualTo(testAgencyTrackingId);
    }

    @Test
    public void shouldCompleteAPaymentThatCurrentlyExists() throws NotFoundException {
        var submissionId = UUID.randomUUID().toString();
        PaymentRepository repository = mock(PaymentRepository.class);
        PaymentAuthorization authorization = mock(PaymentAuthorization.class);
        String formType = FormType.I765.getType();
        String eligibilityCategory = "C9";

        when(authorization.getAgencyTrackingId()).thenReturn(testAgencyTrackingId);
        when(authorization.getSubmissionId()).thenReturn(submissionId.toString());
        when(authorization.getFormType()).thenReturn(formType);
        when(authorization.getTcsAppId()).thenReturn(tcsAppId);
        when(authorization.getEligibilityCategory()).thenReturn(eligibilityCategory);

        when(repository.findPaymentBySubmissionId(submissionId.toString())).thenReturn(authorization);

        var elisClient = mock(ElisPaymentsClient.class);
        PaymentConfirmation confirmation = new PaymentConfirmation(ZonedDateTime.now(), testAgencyTrackingId,
                AuthorizationStatusCode.Success);
        when(elisClient.completeAuthorization(any(), any(), any(), anyString(),anyString())).thenReturn(confirmation);
        var service = new PaymentsService(repository, elisClient, submissionServiceClient);

        BigDecimal finalPaymentAmount = BigDecimal.TEN;
        service.completeAuthorization(submissionId, finalPaymentAmount);
        verify(elisClient).completeAuthorization(tcsAppId, testAgencyTrackingId, finalPaymentAmount, formType,eligibilityCategory);

        verify(authorization).setFinalPaymentAmount(finalPaymentAmount);
        verify(authorization).setForcedDate(LocalDate.now());
        verify(repository).save(authorization);

    }

    @Test
    public void shouldReturnAuthorizedIfTheCalculatedFeeIsZero() {
        var submissionId = UUID.randomUUID().toString();
        PaymentRepository repository = mock(PaymentRepository.class);
        var service = new PaymentsService(repository, mock(ElisPaymentsClient.class), submissionServiceClient);

        var paymentAuthorizationStatus = service.getPaymentAuthorizationStatus(submissionId, BigDecimal.ZERO, FormType.I765.getType());

        assertThat(paymentAuthorizationStatus).isEqualTo(PaymentAuthorizationStatus.Authorized);
    }

    @Test
    public void shouldReturnPaymentStatusOfAuthorizedIfAPaymentAuthorizationExistsForTheFeeAmount() {
        var submissionId = UUID.randomUUID().toString();
        PaymentRepository repository = mock(PaymentRepository.class);
        PaymentAuthorization authorization = mock(PaymentAuthorization.class);
        var service = new PaymentsService(repository, mock(ElisPaymentsClient.class), submissionServiceClient);
        when(authorization.getAuthorizedAmount()).thenReturn(BigDecimal.TEN);
        when(authorization.getAgencyTrackingId()).thenReturn(testAgencyTrackingId);
        when(authorization.getSubmissionId()).thenReturn(submissionId.toString());
        when(authorization.getFormType()).thenReturn(FormType.I765.getType());
        when(authorization.getTcsAppId()).thenReturn(tcsAppId);

        when(repository.findPaymentBySubmissionId(submissionId.toString())).thenReturn(authorization);
        var paymentAuthorizationStatus = service.getPaymentAuthorizationStatus(submissionId, BigDecimal.TEN, FormType.I765.getType());

        assertThat(paymentAuthorizationStatus).isEqualTo(PaymentAuthorizationStatus.Authorized);
    }

    @Test
    public void shouldReturnPaymentStatusOfNotAuthorizedIfPaymentDoesNotExist() {
        var submissionId = UUID.randomUUID().toString();
        PaymentRepository repository = mock(PaymentRepository.class);
        var service = new PaymentsService(repository, mock(ElisPaymentsClient.class), submissionServiceClient);

        var paymentAuthorizationStatus = service.getPaymentAuthorizationStatus(submissionId, BigDecimal.TEN, FormType.I765.getType());

        assertThat(paymentAuthorizationStatus).isEqualTo(PaymentAuthorizationStatus.NotAuthorized);
    }

    @Test
    public void shouldReturnThatItIsNotAuthorizedIfAuthorizationExistsButNotForTheCorrectAmount() {
        var submissionId = UUID.randomUUID().toString();
        PaymentRepository repository = mock(PaymentRepository.class);
        PaymentAuthorization authorization = mock(PaymentAuthorization.class);
        var service = new PaymentsService(repository, mock(ElisPaymentsClient.class), submissionServiceClient);
        when(authorization.getAuthorizedAmount()).thenReturn(BigDecimal.TEN.add(new BigDecimal(1)));
        when(authorization.getAgencyTrackingId()).thenReturn(testAgencyTrackingId);
        when(authorization.getSubmissionId()).thenReturn(submissionId.toString());
        when(authorization.getTcsAppId()).thenReturn(tcsAppId);

        when(repository.findPaymentBySubmissionId(submissionId.toString())).thenReturn(authorization);
        var paymentAuthorizationStatus = service.getPaymentAuthorizationStatus(submissionId, BigDecimal.TEN, FormType.I765.getType());

        assertThat(paymentAuthorizationStatus).isEqualTo(PaymentAuthorizationStatus.NotAuthorized);
    }

    @Test
    public void shouldReturnAsAuthorizedIfAuthorizationExistsWithMatchingAmountIgnoreDecimals() {

        BigDecimal inputAmount = BigDecimal.valueOf(710.00);
        BigDecimal authorizedAmount = BigDecimal.valueOf(710);

        var submissionId = UUID.randomUUID().toString();
        PaymentRepository repository = mock(PaymentRepository.class);
        PaymentAuthorization authorization = mock(PaymentAuthorization.class);
        var service = new PaymentsService(repository, mock(ElisPaymentsClient.class), submissionServiceClient);
        when(authorization.getAuthorizedAmount()).thenReturn(authorizedAmount);
        when(authorization.getAgencyTrackingId()).thenReturn(testAgencyTrackingId);
        when(authorization.getSubmissionId()).thenReturn(submissionId.toString());
        when(authorization.getTcsAppId()).thenReturn(tcsAppId);

        when(repository.findPaymentBySubmissionId(submissionId.toString())).thenReturn(authorization);

        var paymentAuthorizationStatus = service.getPaymentAuthorizationStatus(submissionId, inputAmount, FormType.I765.getType());
        assertThat(paymentAuthorizationStatus).isEqualTo(PaymentAuthorizationStatus.Authorized);
    }

    @Test
    public void shouldReturnAsAuthorizedIfAuthorizationNotExistsWithZeroAmountIgnoreDecimals() {

        BigDecimal inputAmount = BigDecimal.valueOf(0.00);

        var submissionId = UUID.randomUUID().toString();
        PaymentRepository repository = mock(PaymentRepository.class);

        var service = new PaymentsService(repository, mock(ElisPaymentsClient.class), submissionServiceClient);
        when(repository.findPaymentBySubmissionId(submissionId.toString())).thenReturn(null);

        var paymentAuthorizationStatus = service.getPaymentAuthorizationStatus(submissionId, inputAmount, FormType.I765.getType());
        assertThat(paymentAuthorizationStatus).isEqualTo(PaymentAuthorizationStatus.Authorized);
    }

    @Test
    public void shouldProcessAuthorizationAsSuccess() {
        BigDecimal feeTotal = BigDecimal.valueOf(200);
        String eligibilityCategory = "C9";

        PaymentAuthorization paymentAuthorization = Instancio.create(PaymentAuthorization.class);
        paymentAuthorization.setEligibilityCategory(eligibilityCategory);
        paymentAuthorization.setTcsAppId(tcsAppId);
        paymentAuthorization.setSubmissionId(submissionId);
        paymentAuthorization.setFormType("I-765");
        LocalDate authorizedDate = LocalDate.now().minusDays(2);
        paymentAuthorization.setAuthorizedDate(authorizedDate);
        paymentAuthorization.setForcedDate(null);
        PaymentAuthorization expected = new PaymentAuthorization(paymentAuthorization.getSubmissionId(),
                paymentAuthorization.getAgencyTrackingId(), paymentAuthorization.getRedirectUrl(),
                paymentAuthorization.getAuthorizedAmount(), paymentAuthorization.getFormType(), tcsAppId,
                paymentAuthorization.getEligibilityCategory());
        expected.setFinalPaymentAmount(feeTotal);
        expected.setAuthorizedDate(authorizedDate);
        expected.setForcedDate(LocalDate.now());

        when(paymentRepository.findPaymentBySubmissionId(submissionId)).thenReturn(paymentAuthorization);
        when(elisPaymentClient.completeAuthorization(paymentAuthorization.getTcsAppId(),
                paymentAuthorization.getAgencyTrackingId(), feeTotal, paymentAuthorization.getFormType(),paymentAuthorization.getEligibilityCategory()))
                .thenReturn(PaymentConfirmation.builder().agencyTrackingId(paymentAuthorization.getAgencyTrackingId())
                        .authorizationStatusCode(AuthorizationStatusCode.Success).build());
        try {
            service.completeAuthorization(paymentAuthorization.getSubmissionId(), feeTotal);
        } catch (NotFoundException e) {
            fail("did not find paymentAuthorization, interaction with paymentRepository not stubbed");
        }

        verify(elisPaymentClient, times(1)).completeAuthorization(anyString(), anyString(), any(BigDecimal.class),
                anyString(),anyString());
        verify(paymentRepository, times(1)).save(expected);
    }

    @Test
    public void shouldProcessAuthorizationAsDeclined() {
        BigDecimal feeTotal = BigDecimal.valueOf(200);
        String eligibilityCategory = "C9";

        PaymentAuthorization paymentAuthorization = Instancio.create(PaymentAuthorization.class);
        paymentAuthorization.setEligibilityCategory(eligibilityCategory);
        paymentAuthorization.setSubmissionId(submissionId);
        paymentAuthorization.setFormType("I-765");

        when(paymentRepository.findPaymentBySubmissionId(submissionId)).thenReturn(paymentAuthorization);
        when(elisPaymentClient.completeAuthorization(paymentAuthorization.getTcsAppId(),
                paymentAuthorization.getAgencyTrackingId(), feeTotal, paymentAuthorization.getFormType(),paymentAuthorization.getEligibilityCategory()))
                .thenReturn(PaymentConfirmation.builder().agencyTrackingId(paymentAuthorization.getAgencyTrackingId())
                        .authorizationStatusCode(AuthorizationStatusCode.Declined).build());
        assertThrows(PaymentDeclinedException.class,
                () -> service.completeAuthorization(paymentAuthorization.getSubmissionId(), feeTotal));

        verify(elisPaymentClient, times(1)).completeAuthorization(anyString(), anyString(), any(BigDecimal.class),
                anyString(),anyString());
        verify(paymentRepository, times(0)).save(any());
    }

    @Test
    public void shouldProcessAuthorizationAsError() {
        BigDecimal feeTotal = BigDecimal.valueOf(200);
        String eligibilityCategory = "C9";

        PaymentAuthorization paymentAuthorization = Instancio.create(PaymentAuthorization.class);
        paymentAuthorization.setEligibilityCategory(eligibilityCategory);
        paymentAuthorization.setSubmissionId(submissionId);
        paymentAuthorization.setFormType("I-765");

        when(paymentRepository.findPaymentBySubmissionId(submissionId)).thenReturn(paymentAuthorization);
        when(elisPaymentClient.completeAuthorization(paymentAuthorization.getTcsAppId(),
                paymentAuthorization.getAgencyTrackingId(), feeTotal, paymentAuthorization.getFormType(), eligibilityCategory))
                .thenReturn(PaymentConfirmation.builder().agencyTrackingId(paymentAuthorization.getAgencyTrackingId())
                        .authorizationStatusCode(AuthorizationStatusCode.Error).build());
        assertThrows(PaymentErrorException.class,
                () -> service.completeAuthorization(paymentAuthorization.getSubmissionId(), feeTotal));

        verify(elisPaymentClient, times(1)).completeAuthorization(anyString(), anyString(), any(BigDecimal.class),
                anyString(),anyString());
        verify(paymentRepository, times(0)).save(any());
    }

    @Test
    public void shouldDeletePaymentAuthorizationOnCancel() {
        BigDecimal feeTotal = BigDecimal.valueOf(200);
        String eligibilityCategory = "C9";

        PaymentAuthorization expected = new PaymentAuthorization("submissionId", "agencyTrackingId", "redirectUrl",
                feeTotal, FormType.I765.getType(), tcsAppId,eligibilityCategory);
        when(paymentRepository.findPaymentBySubmissionId(submissionId)).thenReturn(expected);
        service.removeAuthorization(submissionId);

        verifyNoInteractions(elisPaymentClient);
        verify(paymentRepository, times(1)).delete(expected);
    }

    WebClient getElisWebClient() {
        HttpClient httpClient = HttpClient.create().responseTimeout(java.time.Duration.ofSeconds(45));

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .baseUrl("http://localhost:8083")
                .build();
    }
}
