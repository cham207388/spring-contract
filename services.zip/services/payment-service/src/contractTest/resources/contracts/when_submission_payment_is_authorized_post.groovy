package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        method HttpMethods.POST
        url value(consumer(regex('/api/v1/payments/[a-zA-Z0-9\\-]+/authorization')))
        headers {
            header(contentType(), applicationJson())
        }
        body(
            [
                submissionId: $(consumer(regex('[a-zA-Z0-9\\-]+')), producer('12345-abc')),
                feeTotal: $(consumer(regex('\\d+\\.\\d{2}')), producer(100.00))
            ]
        )
    }
    response {
        status 200
    }
    priority(3)

}
