package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        method HttpMethods.DELETE
        url value(consumer(regex('/api/v1/payments/[a-zA-Z0-9\\-]+/authorization')))
    }
    response {
        status 204
    }
    priority(4)
}
