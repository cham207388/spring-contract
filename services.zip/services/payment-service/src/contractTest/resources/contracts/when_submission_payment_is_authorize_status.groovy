/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        urlPath('/api/v1/payments/submissionId/authorization/status') {
            queryParameters {
                parameter "feeTotal" : equalTo("470.00")
                parameter "formType" : equalTo("I-765")
            }
        }
        method HttpMethods.GET
        headers {
            header(accept(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            header(contentType(), applicationJson())
        }
        body(
                status: 'Authorized'
        )
    }
    priority(1)

}
