/* groovylint-disable CompileStatic, DuplicateStringLiteral */
package contracts

import org.springframework.cloud.contract.spec.Contract
import org.springframework.cloud.contract.spec.internal.HttpMethods

Contract.make {
    request {
        urlPath('/api/v1/payments/submissionId/authorization') {
            queryParameters {
                parameter('feeTotal', equalTo('470.00'))
                parameter('formType', equalTo('I-765'))
                parameter('successUrl'), equalTo('http://successful.com/')
                parameter('cancelUrl'), equalTo('http://cancel.com/')
            }
        }
        method HttpMethods.GET
        headers {
            header(accept(), applicationJson())
        }
    }
    response {
        status 200
        headers {
            contentType applicationJson()
        }
        body(
            redirectUrl: "http://redirect.org"
        )
    }

}
