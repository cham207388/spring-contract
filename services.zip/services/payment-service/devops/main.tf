data "aws_caller_identity" "current" {}

provider "kubernetes" {
  config_path    = "~/.kube/config"
  config_context =  var.eks_context
}

variable "elis_payment_urls" {
  type = map(string)
  default = {
    sint = "https://elis-payment-pt.k8s.elis.nonprod.uscis.dhs.gov"
    preprod = "https://elis-payment-pp.k8s.elis.uscis.dhs.gov"
    prod = "https://elis-payment-prod.k8s.elis.uscis.dhs.gov"
  }
}

resource "helm_release" "pdfi-payment" {
  namespace  = var.kubernetes_namespace
  name       = var.fullnameOverride
  repository = var.chart_repository
  chart      = var.chart_path_or_name
  version    = var.helm_chart_version
  max_history = var.helm_history_max
  atomic = true
  timeout = 1200

  values = [
    file(var.helm_values_path)
  ]

  set {
    name  = "fullnameOverride"
    value = var.fullnameOverride
  }

  set {
    name  = "nameOverride"
    value = var.fullnameOverride
  }

  set {
    name  = "image.tag"
    value = var.image_tag
  }

  set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com\\/role-arn"
    value = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/pdfi-payment-role-${terraform.workspace}"
  }

  set {
    name  = "ingress.hosts[0].host"
    value = "${var.fullnameOverride}.${var.eks_domain},ingress.hosts[0].paths[0].path=/,ingress.hosts[0].paths[0].pathType=ImplementationSpecific"
  }

  set {
    name= "appvars.spring_datasource_url"
    value = "jdbc:postgresql://${module.postgres.database_url}/postgres"
  }

  set {
    name= "appvars.spring_datasource_password"
    value = module.postgres.database_password
  }

  set {
    name = "appvars.elisApiKeystorePath"
    value = var.elisApiKeystorePath
  }

  set {
    name = "appvars.elis.payments.url"
    value = lookup(var.elis_payment_urls, terraform.workspace, var.elisPaymentUrl)
  }

  set {
    name = "appvars.uscis.submission.baseUrl"
    value = var.uscis_submission_url
  }

  set {
    name  = "new_relic_license_key"
    value = var.new_relic_license_key
  }
}

resource "aws_db_subnet_group" "postgres" {
  name_prefix       = "pdfi_${terraform.workspace}"
  subnet_ids = var.subnet_ids

  tags = var.tags
}

module "postgres" {
  # if you are going to run locally, you will need to download the modules repo locally or configure ssh access to download them
  source                     = "git::ssh://git@git.uscis.dhs.gov/USCIS/csai-terraform-modules.git//postgres-rds"
  environment                = terraform.workspace
  db_subnet_group_name       = aws_db_subnet_group.postgres.name
  vpc_id                     = var.vpc_id
  database_name              = "pdfi${replace(terraform.workspace, "-", "")}"
  enable_deletion_protection = var.db_enable_deletion_protection
  ec2_startstop              = var.ec2_scheduler
  instance_class             = terraform.workspace == "prod" || terraform.workspace == "preprod" ? "db.m5d.xlarge" : "db.t3.micro"

  additional_tags = var.additional_rds_tags
  skip_final_snapshot        = terraform.workspace == "prod" || terraform.workspace == "preprod" ? false : true
  backup_retention_period = var.backup_retention_period
  engine_version = "15.10"
}

output "database_url" {
  value=module.postgres.database_url
}


output "database_arn" {
  value = module.postgres.database_arn
}

output "database_password"{
    value = module.postgres.database_password
}

data "kubernetes_service" "ingress_svc" {
  metadata {
    name = "csai-intake-payment-${terraform.workspace}"
    namespace = var.kubernetes_namespace
  }
}

output "url"{
  value = "${var.fullnameOverride}.${var.eks_domain}"
}