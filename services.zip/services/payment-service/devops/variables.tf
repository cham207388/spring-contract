variable "vpc_id" {}
variable "subnet_ids" {}
variable "db_enable_deletion_protection" {default = false}
variable "ec2_scheduler" {}
variable "fullnameOverride" { default = "changeme" }
variable "nameOverride" { default = "changeme" }
variable "values_environment" {}
variable "kubernetes_namespace" { default = "changeme" }
variable "helm_chart_version" { default = "changeme" }
variable "chart_repository" { default = "changeme" }
variable "image_tag" { default = "changeme" }
variable "chart_path_or_name" { default = "intake-gateway" }
variable "eks_domain" { default = "changeme" }
variable "helm_history_max" { default = 3 }
variable "tags" {}
variable "helm_values_path" {}
variable "elisApiKeystorePath" {}
variable "elisPaymentUrl" {}
variable "new_relic_license_key" {}
variable "uscis_submission_url" {}
variable "additional_rds_tags" {
  type = map(string)
  default = {
    "ECS:System" = "CSAI/DigitalIntake",
    "team" = "CSAI",
    "system"="CSAI/Pdfi"
  }
}
variable "backup_retention_period" {
  default = 7
}
variable "eks_context" {}