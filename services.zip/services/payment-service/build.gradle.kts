// Gradle 9 compliant. Need to test
import com.bmuschko.gradle.docker.tasks.image.DockerBuildImage
import org.gradle.api.tasks.testing.logging.TestLogEvent

plugins {
    java
    jacoco
    `maven-publish`
    eclipse
    alias(libs.plugins.spring.boot)
    alias(libs.plugins.swagger.core)
    alias(libs.plugins.sonarqube)
    alias(libs.plugins.docker)
    alias(libs.plugins.undercouch)
    alias(libs.plugins.spring.cloud.contract)
    alias(libs.plugins.pdfi.java.conventions)
}

val commitTag: String = System.getenv("COMMIT_HASH") ?: "latest"
val stubVersion = "0.0.1-RELEASE"

group = "gov.dhs.uscis"
version = "0.0.1-SNAPSHOT"

configurations {
    developmentOnly
    compileOnly {
        extendsFrom(configurations.annotationProcessor.get())
    }
}

dependencies {
    implementation(enforcedPlatform(libs.log4j.bom))

    // Standard Platforms
    implementation(platform(libs.spring.boot.dependencies))
    implementation(platform(libs.aws.bom))

    // Security Overrides (Constraints)
    constraints {
        implementation(libs.spring.core) { because("CVE-2025-41249") }
        implementation(libs.commons.lang3) { because("CVE-2025-48924") }
        implementation(libs.spring.web) { because("CVE-2025-41234") }
        implementation(libs.spring.webmvc) { because("CVE-2025-41242") }
        implementation(libs.tomcat.embed.core) { because("CVE-2026-34487") }
        implementation(libs.fasterxml.jackson.core) { because("GHSA-72hv-8253-57qq") }
        implementation(libs.netty.codec.http) { because("CVE-2026-33870") }
        implementation(libs.netty.codec.http2) { because("CVE-2026-33871") }
    }

    // Implementation
    implementation(libs.spring.boot.starter.actuator) {
        exclude(group = "ch.qos.logback", module = "logback-classic")
        exclude(group = "ch.qos.logback", module = "logback-core")
    }
    implementation(libs.spring.boot.starter.data.jpa)
    implementation(libs.spring.boot.starter.webflux)
    implementation(libs.spring.boot.starter.web)
    implementation(libs.springdoc.openapi) {
        exclude(group = "org.springframework", module = "spring-webmvc")
    }
    implementation(libs.aws.sts)
    implementation(libs.fasterxml.jackson.datatype)
    implementation(libs.fasterxml.jackson.databind)
    implementation(libs.javax.jms)
    implementation(libs.postgresql)
    implementation(libs.flyway.core)
    implementation(libs.flyway.postgresql)
    implementation(libs.micrometer)
    implementation(libs.logback.encoder)

    // Annotation Processors
    compileOnly(libs.lombok)
    annotationProcessor(libs.lombok)

    // Test Suite
    testImplementation(libs.spring.boot.starter.test)
    testImplementation(libs.mockito)
    testImplementation(libs.spring.restdocs.webtestclient)
    testImplementation(libs.instancio)
    testImplementation(libs.assertj.core)
    testImplementation(libs.squareup.okhttp3)
    testImplementation(libs.squareup.okhttp3.mockwebserver)
    testImplementation(libs.spring.cloud.starter.verifier)
    testImplementation(libs.h2)
    testImplementation(libs.rest.assured)
}

contracts {
    baseClassForTests.set("gov.dhs.uscis.paymentsservices.BaseContractTest")
}

docker {
    springBootApplication {
        baseImage.set("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/csai-java-base-image:21.0.8_11-jre-alpine")
        images.add("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/payment-service:$commitTag")
        maintainer.set("csai-dev-team")
        mainClassName.set("gov.dhs.uscis.paymentsservices.PaymentServicesApplication")
        jvmArgs.set(listOf("-XX:+UseContainerSupport", "-XX:MaxRAMPercentage=90", "-javaagent:/opt/newrelic.jar"))
    }
}

tasks.dockerCreateDockerfile {
    instruction("COPY --chown=apps:apps ./resources/newrelic.yaml /opt/newrelic.yml")
    instruction("EXPOSE 8080")
    instruction("USER apps")
}

tasks.named<DockerBuildImage>("dockerBuildImage") {
    platform.set("linux/amd64")
    pull.set(true)
}

tasks.build {
    dependsOn(tasks.dockerBuildImage)
}

// Consolidate Test settings and RestDocs snippets
val snippetsDir = layout.buildDirectory.dir("generated-snippets")

tasks.test {
    outputs.dir(snippetsDir)
    useJUnitPlatform()
    finalizedBy(tasks.jacocoTestReport)
    testLogging {
        events(
            TestLogEvent.PASSED,
            TestLogEvent.SKIPPED,
            TestLogEvent.FAILED,
            TestLogEvent.STANDARD_OUT,
            TestLogEvent.STANDARD_ERROR
        )
    }
}

// JaCoCo Configuration
val jacocoExcludes = listOf(
    "gov/dhs/uscis/paymentsservices/exception/**",
    "gov/dhs/uscis/paymentsservices/entities/**",
    "gov/dhs/uscis/paymentsservices/model/**",
    "gov/dhs/uscis/paymentsservices/config/**"
)

jacoco {
    toolVersion = libs.versions.jacoco.get()
}

// Modern way to apply excludes to all Jacoco tasks (Report and Coverage)
tasks.withType<JacocoReportBase>().configureEach {
    classDirectories.setFrom(
        classDirectories.files.map {
            fileTree(it) { exclude(jacocoExcludes) }
        }
    )
}

tasks.jacocoTestReport {
    dependsOn(tasks.test)
    reports {
        xml.required.set(true)
        html.required.set(true)
    }
}

tasks.jacocoTestCoverageVerification {
    dependsOn(tasks.test)
    violationRules {
        rule {
            limit {
                minimum = "0.8".toBigDecimal()
            }
        }
    }
}

tasks.check {
    dependsOn(tasks.jacocoTestCoverageVerification)
}

// Artifact Renaming Logic
val renameStubArtifact by tasks.registering {
    // Define providers for the files
    val originalFile = layout.buildDirectory.file("libs/${project.name}-$version-stubs.jar")
    val targetFile = layout.buildDirectory.file("libs/${project.name}-$stubVersion-stubs.jar")

    // Declare inputs and outputs for incremental build support
    inputs.file(originalFile)
    outputs.file(targetFile)

    doLast {
        val source = originalFile.get().asFile
        val target = targetFile.get().asFile
        
        if (source.exists()) {
            // Use copyTo with overwrite for better reliability than renameTo
            source.copyTo(target, overwrite = true)
            println("Stub artifact prepared: ${target.path}")
        } else {
            throw GradleException("Source stub jar not found at ${source.path}")
        }
    }
}

publishing {
    publications {
        create<MavenPublication>("stubs") {
            artifactId = project.name
            version = stubVersion

            // Correct way for Gradle 9: Point to the file provider and link the task
            artifact(layout.buildDirectory.file("libs/${project.name}-$stubVersion-stubs.jar")) {
                classifier = "stubs"
                builtBy(renameStubArtifact)
            }
        }
    }
    repositories {
        mavenLocal()
    }
}