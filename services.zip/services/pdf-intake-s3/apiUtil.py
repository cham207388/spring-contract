

def format_filename(filename):
  return filename.replace("%20", " ").replace("%28", "(").replace("%29", ")")

def get_file_key(uuid, user, filename):
    return f'{uuid}/{user}/{format_filename(filename)}'

