# Downloader service (pdf-intake-s3)

## Up and Running

### Requirements
- Python3 *tested with v3.10.11* (you can use [pyenv](https://github.com/pyenv/pyenv))
- Pip 

### Setup Steps

```
cd services/pdf-intake-s3
```
#### 1. create and activate a virtual environment
```
python -m venv .venv
chmod 777 .venv/bin/activate # (if permission denied)
source .venv/bin/activate
```
#### 2. install dependencies
```
pip install -r requirements.txt
```
#### 3. run tests
```
pytest --cov --cov-config=.coveragerc --cov-report xml:coverage.xml tests/
``` 

If that doesn't work here's an alterative command: 
``` 
coverage run -m pytest tests/
coverage xml
``` 

#### 4. build and run with docker compose
```
first time or to start over: docker compose up --build --force-recreate
(alternative build wihout buildKit): DOCKER_BUILDKIT=0 docker compose up --build --force-recreate

(typical option) build only if there are changes to config: docker compose up
```

#### 5. confirm api is working in web browser
```
http://localhost:8080/health # ( should return '{status:up}' )

http://localhost:8080/test-uuid/test-user-id/test-form-file.jpg

http://localhost:8080/test-uuid/test-user-id/test-form-file.pdf 

http://localhost:8080/url/test-uuid/test-user-id/test-form-file.pdf

http://localhost:8080/evidence/test-uuid/test-user-id/test-evidence-file.jpg

http://localhost:8080/url/evidence/test-uuid/test-user-id/test-evidence-file.jpg

```

#### Troubleshooting: To deactivate your virtual environment and return to a clean state

```
run this command in your venv shelll: `deactivate`
delete your local .venv file
```

#### 6. Simple S3 Environment Loader 
Add python-dotenv==1.2.1 to requirements.txt and run:
```
pip install -r requirements.txt
```
Create a .env (locally ony) in the project root to store AWS Account ID:
```
# Example value: Replace with actual AWS Account ID
S3_BUCKET_OWNER=12345678
```

At the very top of the Python file (e.g., apiS3_download.py),
load the local file:
```
from dotenv import load_dotenv

load_dotenv() 
```

Inside the function, this now pulls the ID loaded by load_dotenv() above:
```
expected_owner = os.environ.get('S3_BUCKET_OWNER')
```

If you are using Docker Desktop, you can verify that the variable was successfully injected into your container:

1. Open Docker Desktop and navigate to the `Containers` tab
2. Click on container name: `csai-pdf-intake-s3-downloader-1`
3. Select the `Inspect` tab at the top of the container details view
4. Look under the `Env` section: You should see `S3_BUCKET_OWNER` with AWS Account ID
