import boto3
from moto import mock_aws
import re
from tests._utils import isValidS3SignedURL
import pytest
from api import app

@pytest.fixture(autouse=True)
def set_env(monkeypatch):
    monkeypatch.setenv("S3_BUCKET_OWNER", "412097299655")

@mock_aws
def test_get_form_success():

    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="form-staging")
    s3.put_object(Bucket="form-staging", Key="test-uuid/test-user-id/test-filename.pdf", Body="Test form body")

    response = app.test_client().get('/test-uuid/test-user-id/test-filename.pdf')
    assert response.data == b"Test form body"
    assert response.status_code == 200

@mock_aws
def test_get_form_does_not_exist():

    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="form-staging")

    response = app.test_client().get('/test-uuid/test-user-id/test-filename.pdf')
    assert response.data == b"File not found"
    assert response.status_code == 400

@mock_aws
def test_get_form_url_success():

    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="form-staging")
    s3.put_object(Bucket="form-staging", Key="test-uuid/test-user-id/test-filename", Body="Test form body")

    response = app.test_client().get('/url/test-uuid/test-user-id/test-filename')
    response_url = response.data.decode("utf-8")

    print(response_url)

    assert isValidS3SignedURL(response_url,"form-staging","test-uuid/test-user-id/test-filename")
    assert response.status_code == 200

@mock_aws
def test_get_form_url_does_not_exist():

    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="form-staging")

    response = app.test_client().get('/url/test-uuid/test-user-id/test-filename-not-exist')
    
    assert response.data == b"File for presigned url not found"
    assert response.status_code == 404

