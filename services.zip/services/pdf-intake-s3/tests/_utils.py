import re

def isValidS3SignedURL(url, bucket, key):
    def gen_url_regex(bucket, key):
        return "https://{bucket}.s3.amazonaws.com/{key}\?AWSAccessKeyId=[A-Za-z]+&Signature=[^\s]+&Expires=[0-9]+".format(bucket=bucket, key=key)

    url_regex_string = gen_url_regex(bucket, key)
    return re.fullmatch(url_regex_string, url) is not None