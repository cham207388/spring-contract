from api import app
import os
from unittest import mock

@mock.patch.dict(os.environ, {"ALLOWED_IP_ADDRESSES": "192.168.1.1,192.0.2.146"})
def test_should_deny_ips_not_on_list():
    response = app.test_client().get('/health', environ_base={'REMOTE_ADDR': '127.0.0.1'})
    assert response.status_code == 403

@mock.patch.dict(os.environ, {"ALLOWED_IP_ADDRESSES": "192.168.1.1,192.0.2.146,127.0.0.1"})
def test_should_allow_ips_on_list():
    response = app.test_client().get('/health', environ_base={'REMOTE_ADDR': '127.0.0.1'})
    assert response.status_code == 200

@mock.patch.dict(os.environ, {"ALLOWED_IP_ADDRESSES": "192.168.1.1,192.0.2.146"})
def test_should_allow_forwarded_ip():
    response = app.test_client().get('/health', environ_base={'REMOTE_ADDR': '127.0.0.1', 'HTTP_X_FORWARDED_FOR': '192.168.1.1'})
    assert response.status_code == 200
