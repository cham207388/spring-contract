#!/bin/bash

awslocal s3api \
create-bucket --bucket form-staging \
--region us-east-1

awslocal s3api \
put-object --bucket form-staging \
--key test-uuid/test-user-id/test-form-file.pdf \
--body test-form-file.pdf \
--region us-east-1

awslocal s3api \
put-object --bucket form-staging \
--key test-uuid/test-user-id/test-form-file.jpg \
--body test-form-file.jpg \
--region us-east-1

awslocal s3api \
create-bucket --bucket evidence \
--region us-east-1

awslocal s3api \
put-object --bucket evidence \
--key test-uuid/test-user-id/test-evidence-file.jpg \
--body test-evidence-file.jpg \
--region us-east-1
