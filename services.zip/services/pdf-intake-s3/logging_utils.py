import logging
import uuid

class TraceIdAdapter(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        trace_id = uuid.uuid4()
        if trace_id:
            kwargs["extra"] = {"trace_id": trace_id}
        return msg, kwargs

def get_logger(name) -> logging.Logger:
    logger = logging.getLogger(__name__)
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - [%(trace_id)s] - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    trace_logger = TraceIdAdapter(logger, {})
    return trace_logger

