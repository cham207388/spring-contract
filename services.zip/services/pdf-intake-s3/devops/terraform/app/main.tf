
data "aws_caller_identity" "current" {}

provider "kubernetes" {
  config_path    = "~/.kube/config"
  config_context =  var.eks_context
}

resource "helm_release" "pdfi-s3api" {
  namespace  = var.kubernetes_namespace
  name       = var.fullnameOverride
  repository = var.chart_repository
  chart      = var.chart_path_or_name
  version    = var.helm_chart_version
  max_history = var.helm_history_max
  atomic = true
  timeout = 1200
  
  values = [
    file(var.helm_values_path)
  ]

  set {
    name  = "fullnameOverride"
    value = var.fullnameOverride
  }

  set {
    name  = "nameOverride"
    value = var.fullnameOverride
  }

  set {
    name  = "s3_buckets_evidence"
    value = var.s3_buckets_evidence
  }

  set {
    name  = "s3_buckets_form"
    value = var.s3_buckets_form
  }

  set {
    name  = "image.tag"
    value = var.image_tag
  }

  set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com\\/role-arn"
    value = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/pdfi-upload-role-${terraform.workspace}"
  }

  set {
    name  = "ingress.hosts[0].host"
    value = "${var.fullnameOverride}.${var.eks_domain},ingress.hosts[0].paths[0].path=/,ingress.hosts[0].paths[0].pathType=ImplementationSpecific"
  }

  set {
    name  = "new_relic_license_key"
    value = var.new_relic_license_key
  }

  set {
    name  = "s3_bucket_owner"
    value = var.s3_bucket_owner
    type  = "string"
  }
}

data "kubernetes_service" "ingress_svc" {
  metadata {
    name = "csai-pdf-intake-s3-${terraform.workspace}"
    namespace = var.kubernetes_namespace
  }
}

output "url"{
  value = "${var.fullnameOverride}.${var.eks_domain}"
}
# output "url" {
#   value = data.kubernetes_service.ingress_svc.status.0.load_balancer.0.ingress[0].hostname
# }