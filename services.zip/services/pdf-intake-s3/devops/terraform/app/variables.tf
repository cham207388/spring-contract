variable "fullnameOverride" { default = "changeme" }
variable "nameOverride" { default = "changeme" }
variable "values_environment" {}
variable "kubernetes_namespace" { default = "changeme" }
variable "helm_chart_version" { default = "changeme" }
variable "chart_repository" { default = "changeme" }
variable "image_tag" { default = "changeme" }
variable "chart_path_or_name" { default = "pdf-intake-s3" }
variable "eks_domain" { default = "changeme" }
variable "helm_history_max" { default = 3 }
variable "s3_buckets_form" { default = "changeme" }
variable "s3_buckets_evidence" { default = "changeme" }
variable "helm_values_path" {}
variable "new_relic_license_key" {}
variable "eks_context" {}
variable "s3_bucket_owner" { default = "changeme" }