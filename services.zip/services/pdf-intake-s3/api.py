import contextvars
import logging
from flask import Flask,request, abort
import os
from ipaddress import ip_address
from ipaddress import ip_network

from apiS3_download import get_s3_file, get_s3_presigned_url
from apiUtil import get_file_key
from flask_wtf import CSRFProtect 
from logging_utils import get_logger

logging.basicConfig(level=logging.DEBUG)

logger = get_logger(__name__)

app = Flask(__name__)
csrf = CSRFProtect()
csrf.init_app(app) # Compliant

formBucket = os.environ.get('S3_FORM_BUCKET','form-staging')
evidenceBucket = os.environ.get('S3_EVIDENCE_BUCKET','evidence')

@app.before_request
def limit_remote_addr():
    allowed_ips = os.environ.get("ALLOWED_IP_ADDRESSES", "0.0.0.0/0")
    ip_addresses = [request.remote_addr]
    if request.environ.get('HTTP_X_FORWARDED_FOR') is not None:
        ip_addresses.append(request.environ['HTTP_X_FORWARDED_FOR'])

    logger.debug( f'Filtering from the following addresses: {ip_addresses}')
    for ip in allowed_ips.split(","):
        for inbound_ip in ip_addresses:
            if ip_address(inbound_ip) in ip_network(ip):
                logger.debug(f'Client {inbound_ip} allowed access to services.')
                return
                
    logger.debug( f'Client {ip_addresses} access not allowed')
    abort(403)

@app.route('/health')
def health():
    return '{status:up}'

@app.route('/<uuid>/<user>/<filename>', methods=['GET'])
def get_form_files(uuid, user, filename):
    logger.debug('In form download file method')
    logger.debug(request.path)
    logger.debug(filename)
    return get_s3_file(bucket=formBucket,key=get_file_key(uuid,user,filename))

@app.route('/evidence/<uuid>/<user>/<filename>', methods=['GET'])
def get_evidence_files(uuid, user, filename):
    logger.debug('In form download file method')
    logger.debug(request.path)
    logger.debug(filename)
    return get_s3_file(bucket=evidenceBucket,key=get_file_key(uuid,user,filename))
    
@app.route('/url/<uuid>/<user>/<filename>', methods=['GET'])
def get_form_presigned_url(uuid, user, filename):
    logger.debug("In get presigned url method")
    logger.debug(request.path)
    return get_s3_presigned_url(bucket=formBucket,key=get_file_key(uuid,user,filename))
    
@app.route('/url/evidence/<uuid>/<user>/<filename>', methods=['GET'])
def get_evidence_presigned_url(uuid, user, filename):
    logger.debug("In evidence get presigned url method")
    logger.debug(request.path.strip("/url/evidence/"))
    return get_s3_presigned_url(bucket=evidenceBucket,key=get_file_key(uuid,user,filename))

# main driver function
# if __name__ == "__main__":
#     app.run(host='0.0.0.0', port=os.environ.get("FLASK_SERVER_PORT", 8080), debug=True)