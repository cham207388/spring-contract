import boto3
import os

from flask import Response
from botocore.exceptions import ClientError
from logging_utils import get_logger


logger = get_logger(__name__)

def get_s3_file(bucket, key):
    expected_owner = os.environ.get('S3_BUCKET_OWNER')

    try: 
        s3 = boto3.client('s3')   
        logger.debug("key:: " + key)
        resp=s3.get_object(Bucket=bucket, Key=key, ExpectedBucketOwner=expected_owner)
        return Response(resp['Body'].read(), mimetype='text/plain')   
    except Exception:
        logger.debug("Could not find the requested file : %s, %s", bucket, key)
        return Response("File not found", status=400)

def get_s3_presigned_url(bucket,key):
    expected_owner = os.environ.get('S3_BUCKET_OWNER')

    try:
        s3 = boto3.client('s3') 
        resp=s3.get_object(Bucket=bucket, Key=key, ExpectedBucketOwner=expected_owner)
        logger.debug("Head Obj Response: %s", resp)
        logger.debug("Found requested form presigned url with key: %s", key)
        return s3.generate_presigned_url('get_object', Params={'Bucket': bucket, 'Key': key}, ExpiresIn=60)     
    except ClientError as err:
        if err.response['Error']['Code'] == '404' or err.response['Error']['Code'] == 'NoSuchKey':
            logger.debug(" Error logged for Form presigned url not found with error message %s", err.response)
            return Response("File for presigned url not found", status=404)
        else: 
            logger.debug("Form presigned url not found with error code: %s", err.response['Error']['Code'])     
            return Response("File for presigned url not found")