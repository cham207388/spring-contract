import com.bmuschko.gradle.docker.tasks.image.DockerBuildImage

plugins {
    java
    jacoco

    alias(libs.plugins.docker)
    alias(libs.plugins.spring.boot)
    alias(libs.plugins.sonarqube)
    alias(libs.plugins.swagger.core)
    alias(libs.plugins.undercouch)       // Verify if we need this
    alias(libs.plugins.pdfi.java.conventions)
}

val commitTag: String = System.getenv("COMMIT_HASH") ?: "latest"

group = "gov.dhs.uscis.pdfintake"
version = "0.0.1-SNAPSHOT"

docker {
    springBootApplication {
        baseImage.set("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/csai-java-base-image:21.0.8_11-jre-alpine")
        images.add("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/admin:$commitTag")
        mainClassName.set("gov.dhs.uscis.pdfintake.admin.AdminApplication")
        maintainer.set("csai-dev-team")
        jvmArgs.set(listOf("-XX:+UseContainerSupport", "-XX:MaxRAMPercentage=90", "-javaagent:/opt/newrelic.jar"))
    }
}

tasks.dockerCreateDockerfile {
    instruction("USER apps")
}

tasks.named<DockerBuildImage>("dockerBuildImage") {
    platform.set("linux/amd64")
    pull.set(true)
}

tasks.build {
    dependsOn(tasks.dockerBuildImage)
}

dependencies {
    implementation(enforcedPlatform(libs.log4j.bom))

    val springBootDependencyBom = platform(libs.spring.boot.dependencies)
    implementation(platform(libs.aws.bom))
    
    implementation(springBootDependencyBom)
    testImplementation(springBootDependencyBom)
    compileOnly(springBootDependencyBom)
    testCompileOnly(springBootDependencyBom)
    annotationProcessor(springBootDependencyBom)
    testAnnotationProcessor(springBootDependencyBom)

    constraints{
        implementation(libs.spring.core) {
            because("CVE-2025-41249")
        }
        implementation(libs.commons.lang3) {
            because("CVE-2025-48924")
        }
        implementation(libs.spring.web) {
            because("CVE-2025-41234")
        }
        implementation(libs.fasterxml.jackson.core) {
            because("GHSA-72hv-8253-57qq")
        }
        implementation(libs.netty.codec.http) {
            because("CVE-2026-33870")
        }
        implementation(libs.netty.codec.http2) {
            because("CVE-2026-33871")
        }
        implementation(libs.tomcat.embed.core) {
            because("CVE-2026-34487")
        }
    }
    
    implementation(libs.spring.boot.starter.security)
    implementation(libs.spring.boot.starter.actuator) 
    implementation(libs.spring.boot.starter.web)
    implementation(libs.spring.boot.starter.webflux)

    implementation(libs.aws.dynamodb.enhanced)
    implementation(libs.aws.s3)
    implementation(libs.aws.sts)
    implementation(libs.amazonaws.sqs.messaging)
    testImplementation(libs.spring.boot.starter.test)
    testImplementation(libs.spring.boot.testcontainers)
    testImplementation(libs.spring.security.test)
    testImplementation(libs.test.containers.jupiter)
    testImplementation(libs.instancio)

    compileOnly(libs.lombok)
    testCompileOnly(libs.lombok)
    annotationProcessor(libs.lombok)
    testAnnotationProcessor(libs.lombok)
}

jacoco {
    toolVersion = libs.versions.jacoco.get()
}

val jacocoExcludes = listOf(
    "gov/dhs/uscis/pdfintake/admin/config/**",
    "gov/dhs/uscis/pdfintake/admin/handler/**",
    "gov/dhs/uscis/pdfintake/admin/repository/**"
)

tasks.withType<JacocoReportBase> {
    classDirectories.setFrom(files(classDirectories.files.map {
        fileTree(it) { exclude(jacocoExcludes) }
    }))
}

tasks.jacocoTestReport {
    reports {
        xml.required.set(true)
        html.required.set(true)
    }
}

tasks.jacocoTestCoverageVerification {
    dependsOn(tasks.test)
    violationRules {
        rule {
            limit {
                minimum = 0.8.toBigDecimal()
            }
        }
    }
}

tasks.check {
    dependsOn(tasks.jacocoTestCoverageVerification)
}

tasks.test {
    useJUnitPlatform()
    finalizedBy(tasks.jacocoTestReport)
    testLogging {
        events("PASSED", "SKIPPED", "FAILED", "STANDARD_OUT", "STANDARD_ERROR")
    }
}

tasks.named("sonar") {
    dependsOn(tasks.jacocoTestCoverageVerification)
}