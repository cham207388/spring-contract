variable "fullnameOverride" { default = "changeme" }
variable "nameOverride" { default = "changeme" }
variable "s3_buckets_form" {}
variable "pdfiadminpassword" {}
variable "s3_buckets_evidence" {}
variable "kubernetes_namespace" { default = "changeme" }
variable "helm_chart_version" { default = "changeme" }
variable "chart_repository" { default = "changeme" }
variable "image_tag" { default = "changeme" }
variable "chart_path_or_name" { default = "digital-intake-web" }
variable "eks_domain" { default = "changeme" }
variable "helm_history_max" { default = 3 }
variable "tags" {}
variable "helm_values_path" {}
variable "eks_context" {}
variable "sqs_elis_validation_request_queueUrl" {}
variable "sqs_elis_validation_response_queueUrl" {}
variable "submission_service_url" {}
##variable "sqs_elis_evidence_validation_request_queueUrl" {}
##variable "sqs_elis_evidence_validation_response_queueUrl" {}