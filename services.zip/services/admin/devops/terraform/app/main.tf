
data "aws_caller_identity" "current" {}

provider "kubernetes" {
  config_path    = "~/.kube/config"
  config_context =  var.eks_context
}

resource "random_password" "password" {
  length           = 16
  special          = true
  override_special = "!#$%&*()-_=+[]<>:?"
}

resource "helm_release" "pdfi-admin" {
  namespace  = var.kubernetes_namespace
  name       = var.fullnameOverride
  repository = var.chart_repository
  chart      = var.chart_path_or_name
  version    = var.helm_chart_version
  max_history = var.helm_history_max
  atomic = true
  timeout = 1200
 
  values = [
    file(var.helm_values_path)
  ]

  set {
    name  = "fullnameOverride"
    value = var.fullnameOverride
  }
  set {
    name  = "nameOverride"
    value = var.fullnameOverride
  }
  set {
    name  = "image.tag"
    value = var.image_tag
  }

  set {
    name  = "s3_buckets_form"
    value = var.s3_buckets_form
  }
  set {
    name  = "s3_buckets_evidence"
    value = var.s3_buckets_evidence
  }
  set {
    name  = "table_prefix"
    value = terraform.workspace
  }
  set {
    name  = "api_key"
    value = var.pdfiadminpassword
  }
   set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com\\/role-arn"
    value = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/pdfi-admin-role-${terraform.workspace}"
  }
  set {
    name  = "ingress.hosts[0].host"
    value = "${var.fullnameOverride}.${var.eks_domain},ingress.hosts[0].paths[0].path=/,ingress.hosts[0].paths[0].pathType=ImplementationSpecific"
  }
    set {
    name  = "sqs_elis_validation_request_queueUrl"
    value = var.sqs_elis_validation_request_queueUrl
  }
  set {
    name  = "sqs_elis_validation_response_queueUrl"
    value = var.sqs_elis_validation_response_queueUrl
  }
  set {
    name = "submission_service_url"
    value = var.submission_service_url
  }
}

data "kubernetes_service" "ingress_svc" {
  metadata {
    name = "csai-intake-submission-${terraform.workspace}"
    namespace = var.kubernetes_namespace
  }
}


output url {
  value = "${var.fullnameOverride}.${var.eks_domain}"
}