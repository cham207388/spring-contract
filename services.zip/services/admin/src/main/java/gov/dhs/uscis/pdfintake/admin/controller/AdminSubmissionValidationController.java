
package gov.dhs.uscis.pdfintake.admin.controller;

import java.util.List;

import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.pdfintake.admin.service.AdminValidationService;

@RestController
@Profile("!production")
@RequestMapping("/api/v1/admin/submission")
public class AdminSubmissionValidationController {
    
    private AdminValidationService service;

    public AdminSubmissionValidationController(AdminValidationService service) {
        this.service = service;
    }

    @PostMapping("/{submissionId}/validationStatus")
    public ResponseEntity<?> updateSubmissionValidationStatus(@PathVariable("submissionId") String submissionId,
            @RequestBody SubmissionValidationRequest validator) {

        boolean response = service.updateSubmissionValidationStatus(submissionId, validator.validator(), validator.feeTotal());

        return ResponseEntity.ok().body(response);
    }
}
