package gov.dhs.uscis.pdfintake.admin.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.enhanced.dynamodb.Expression.Builder;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

@Component
@Slf4j
public class SubmissionRepository {
    private DynamoDbTable<Submission> submissionTable;

    public SubmissionRepository(DynamoDbTable<Submission> submissionTable) {
        this.submissionTable = submissionTable;
    }

    public Optional<Submission> retrieveSubmissionByManifestId(String manifestId) {
        DynamoDbIndex<Submission> index = submissionTable.index("requests_by_manifestId");
        Key key = Key.builder().partitionValue(manifestId.toLowerCase()).build();
        SdkIterable<Page<Submission>> query = index
                .query(builder -> builder.queryConditional(QueryConditional.keyEqualTo(key)));
        return query.stream().flatMap(page -> page.items().stream()).findFirst();
    }

    public Optional<Submission> retrieveSubmissionBySubmissionId(String id) {
        return Optional.ofNullable(submissionTable.getItem(Key.builder().partitionValue(id).build()));
    }

    public Optional<Submission> updateSubmission(Submission submission) {
        return Optional.ofNullable(submissionTable.updateItem(submission));
    }

    public void save(Submission submission) {
        submissionTable.putItem(submission);
    }

    public List<Submission> retrieveSubmissionsByFormType(FormType formType, List<SubmissionState> statuses) {
        Builder expressionBuilder = Expression.builder();

        String expression = "formType = :formType";
        Map<String, AttributeValue> values = new HashMap<>();
        values.put(":formType", AttributeValue.fromS(formType.getType()));
        Map<String, String> names = null;

        if (!statuses.isEmpty()) {
            expression = String.format("%s AND #status in (:statuses)", expression);
            values.put(":statuses", AttributeValue
                    .fromS(statuses.stream().map(SubmissionState::toString).collect(Collectors.joining(","))));
            names = Map.of("#status", "status");
        }

        Expression filterExpression = expressionBuilder
                .expression(expression)
                .expressionValues(values)
                .expressionNames(names)
                .build();
                
        QueryEnhancedRequest conditional = QueryEnhancedRequest.builder()
                .filterExpression(filterExpression)
                .build();
        PageIterable<Submission> result = submissionTable.query(conditional);
        return result.stream().flatMap(page -> page.items().stream()).toList();
    }
}
