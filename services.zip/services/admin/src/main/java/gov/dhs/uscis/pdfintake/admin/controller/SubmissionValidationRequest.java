package gov.dhs.uscis.pdfintake.admin.controller;

import gov.dhs.uscis.intake.enums.ValidatorEnum;

public record SubmissionValidationRequest(ValidatorEnum validator, Integer feeTotal) {
    
}
