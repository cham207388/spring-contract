package gov.dhs.uscis.pdfintake.admin.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.ELISValidationResponse;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.ValidationStatus;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.pdfintake.admin.repository.SubmissionRepository;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;




@Service
@Slf4j
public class AdminValidationService {
    private ObjectMapper objectMapper;
    private SubmissionRepository submissionRepository;
    private SqsClient sqsClient;
    private ObjectMapper mapper = new ObjectMapper();

	@Value("${uscis.sqs.validation.elisResponse.queueUrl}")
    private String elisResponseQueueName;

    // Todo: Change these to api calls.
    public AdminValidationService(SubmissionRepository submissionRepository,
            SqsClient sqsClient, ObjectMapper objectMapper) {
        this.submissionRepository = submissionRepository;
        this.sqsClient = sqsClient;
        this.objectMapper = objectMapper;

    }

    private String createMessage(String submissionId, ValidatorEnum validator, Integer feeTotal, SubmissionForm firstForm) throws JsonProcessingException{
        // We will assume the first form is the main form and second is G28
        
        boolean pass = false;
        List<ValidationStatus> statusResponses = new ArrayList<>();

                ValidationStatus coreValidation = ValidationStatus.builder().submissionId(submissionId).formId(firstForm.getId()).validator(ValidatorEnum.CORE).build();
                ValidationStatus signatureValidation =  ValidationStatus.builder().submissionId(submissionId).formId(firstForm.getId()).validator(ValidatorEnum.SIGNATURE).build();
                ValidationStatus pfvsValidationStatus =  ValidationStatus.builder().submissionId(submissionId).formId(firstForm.getId()).validator(ValidatorEnum.PFVS).build();
                ValidationStatus eligibilityCateegory =  ValidationStatus.builder().submissionId(submissionId).formId(firstForm.getId()).validator(ValidatorEnum.ELIGIBILITY_CATEGORY).build();

                //g28 validations
                ValidationStatus g28Comp =  ValidationStatus.builder().submissionId(submissionId).formId(firstForm.getId()).validator(ValidatorEnum.G28_COMP).status(ValidationResultEnum.PASS).build();
                ValidationStatus g28CompName =  ValidationStatus.builder().submissionId(submissionId).formId(firstForm.getId()).validator(ValidatorEnum.G28_COMP_NAME).status(ValidationResultEnum.PASS).build();
                ValidationStatus g28Name =  ValidationStatus.builder().submissionId(submissionId).formId(firstForm.getId()).validator(ValidatorEnum.G28_NAME_EMAIL).status(ValidationResultEnum.PASS).build();
                ValidationStatus g28Attorney =  ValidationStatus.builder().submissionId(submissionId).formId(firstForm.getId()).validator(ValidatorEnum.G28_ATTORNEY_NAME).status(ValidationResultEnum.PASS).build();
                if(validator == ValidatorEnum.SIGNATURE) {
                        signatureValidation.setFormId(firstForm.getId());
                        signatureValidation.setStatus(ValidationResultEnum.FAIL);
                        signatureValidation.setFailureReasons(Arrays.asList("Signature is Missing"));
                        coreValidation.setStatus(ValidationResultEnum.PASS);
                        coreValidation.setFailureReasons(Arrays.asList("Signature is missing"));
                        pfvsValidationStatus.setStatus(ValidationResultEnum.PASS);

                    }
                
                else if  (validator == ValidatorEnum.CORE) {
                    coreValidation.setStatus(ValidationResultEnum.FAIL);
                    coreValidation.setFailureReasons(Arrays.asList("Core is wrong"));
                    signatureValidation.setStatus(ValidationResultEnum.PASS);
                    signatureValidation.setFailureReasons(Arrays.asList("Core is wrong"));

                    signatureValidation.setFailureReasons(Arrays.asList("Core is wrong"));
                    pfvsValidationStatus.setStatus(ValidationResultEnum.FAIL);


                }
                // if we pass in something unrecognizable we wil pas
                else {
                    eligibilityCateegory.setStatus(ValidationResultEnum.PASS);
                    pfvsValidationStatus.setStatus(ValidationResultEnum.PASS);
                    coreValidation.setStatus(ValidationResultEnum.PASS);
                    coreValidation.setFailureReasons(Arrays.asList("Core is wrong"));
                    signatureValidation.setStatus(ValidationResultEnum.PASS);
                    pass = true;
                }
                pfvsValidationStatus.setFailureReasons(Arrays.asList("There is an error"));
                eligibilityCateegory.setStatus(ValidationResultEnum.PASS);
                eligibilityCateegory.setFailureReasons(Arrays.asList("There is an error"));
                statusResponses.addAll(Arrays.asList(pfvsValidationStatus, signatureValidation, coreValidation, eligibilityCateegory, g28Attorney,g28Name, g28Comp, g28CompName));
              
              // the mock defualt is PASS everything so we don't need to do anything here
    

        ELISValidationResponse elisValidationResponse = ELISValidationResponse.builder()
        .results(statusResponses)
        .formId(firstForm.getId())
        .formType(firstForm.getType())
        .fee(feeTotal!= null ? BigDecimal.valueOf(feeTotal) : BigDecimal.valueOf(999))
        .pass(pass)
        .submissionId(submissionId)
        .build();
        
        return mapper.writeValueAsString(elisValidationResponse);
    }
    
    public boolean updateSubmissionValidationStatus(String submissionId, ValidatorEnum validator, Integer feeTotal){
        try {
            boolean messageSent = false;
                    Submission optional = submissionRepository.retrieveSubmissionBySubmissionId(submissionId).get();
                    for (SubmissionForm form: optional.getForms()) {
           messageSent = sendMessage(createMessage(submissionId, validator, feeTotal, form));
                    }
                    return messageSent;
        } catch (Exception e) {
            log.error("Failure to update Message with error with {}", e.getMessage());
            return false;
        }
    }

    private boolean sendMessage(String message){
        try {
            SendMessageRequest sendMsgRequest = SendMessageRequest.builder()
            .queueUrl(elisResponseQueueName)
            .messageBody(message)
            .build();
            log.info("Sending message to queue: {}\n{}", elisResponseQueueName, message);
            SendMessageResponse response = sqsClient.sendMessage(sendMsgRequest);
            log.info(response.toString());
            return true;

        } catch (Exception e) {
            log.error("Failure to sendMessage", e.getMessage());
            return false;
        }
    }
}
