package gov.dhs.uscis.pdfintake.admin.config;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazon.sqs.javamessaging.ProviderConfiguration;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.models.Submission;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.sqs.SqsClient;

@Configuration
public class AwsConfig {

    @Value("${application.s3.endpoint}")
    private String s3Endpoint;

    @Value("${application.dynamodb.endpoint}")
    private String amazonDynamoDBEndpoint;

    @Value("${application.dynamodb.prefix}")
    private String tablePrefix;

    @Value("${uscis.sqs.endpoint}")
    private String sqsEndpoint;

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        return objectMapper;
    }

    @Bean
    public S3Client getS3Client() {
        return S3Client.builder()
                .region(Region.US_EAST_1)
                .endpointOverride(URI.create(s3Endpoint))
                .forcePathStyle(true)
                .build();
    }

    @Bean
    public DynamoDbClient getDynamoDbClient() throws URISyntaxException {
        return DynamoDbClient.builder().region(Region.US_EAST_1).endpointOverride(new URI(amazonDynamoDBEndpoint)).build();
    }

    @Bean
    public DynamoDbEnhancedClient amazonDynamoDBEnhanced(DynamoDbClient dynamoDbClient) {
        return DynamoDbEnhancedClient.builder().dynamoDbClient(dynamoDbClient).build();
    }

    @Bean
    public DynamoDbTable<Submission> submissionTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        String tableName = "%s-Submission".formatted(tablePrefix);
        return enhancedDbClient.table(tableName, TableSchema.fromBean(Submission.class));
    }

    @Bean
    public DynamoDbTable<SubmissionManifest> submissionManifestTable(DynamoDbEnhancedClient enhancedDbClient,
            DynamoDbClient dynamoDbClient) {
        String tableName = "%s-SubmissionManifest".formatted(tablePrefix);
        return enhancedDbClient.table(tableName, TableSchema.fromBean(SubmissionManifest.class));
    }

   
    @Bean
    public SqsClient sqsClient() {
        return SqsClient.builder()
                .region(Region.US_EAST_1)
                .endpointOverride(URI.create(sqsEndpoint))
                .build();
    }
 
    @Bean(name = "sqsConnection")
    public SQSConnectionFactory sqsConnectionFactory(SqsClient sqsClient){
        return new SQSConnectionFactory(new ProviderConfiguration(), sqsClient);
    }
}
