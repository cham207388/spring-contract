package gov.dhs.uscis.pdfintake.admin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

import reactor.core.publisher.Mono;

@Service
public class SubmissionServiceClient {

    private static final String SUBMISSION_ERR_STRING = "Error calling SubmissionService for submissionId [%s]. Reason: %s";

    protected WebClient submissionServiceClient;

    @Autowired
    public SubmissionServiceClient(@Qualifier("submissionServiceWebClient") WebClient submissionServiceClient) {
        this.submissionServiceClient = submissionServiceClient;
    }

    public String recompleteSubmission(String myUscisId, String submissionId, String orgMyUscisId) {
        return submissionServiceClient
            .post()
            .uri(uriBuilder -> uriBuilder
                .path(String.format("/api/v1/%s/submissions/%s", myUscisId, submissionId))
                .queryParam("orgMyUscisId", orgMyUscisId)
                .build())
            .retrieve()
            .onStatus(HttpStatusCode::isError, res -> res.bodyToMono(String.class).flatMap(
                body -> Mono.error(new ResponseStatusException(res.statusCode(), String.format(SUBMISSION_ERR_STRING, submissionId, body)))
            ))
            .bodyToMono(String.class)
            .block();
    }
}
