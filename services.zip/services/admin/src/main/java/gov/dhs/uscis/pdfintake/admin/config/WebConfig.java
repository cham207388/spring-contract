package gov.dhs.uscis.pdfintake.admin.config;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.netty.http.client.HttpClient;

@Configuration
public class WebConfig {

    @Value("${application.submissionService.baseUrl}")
    private String submissionServiceBaseUrl;

    @Value("${application.submissionService.timeoutSeconds:120}")
    private int TIMEOUT_SECONDS;

    @Bean(name = "submissionServiceWebClient")
    WebClient webClient() {
        return WebClient.builder()
            .baseUrl(submissionServiceBaseUrl)
            .clientConnector(new ReactorClientHttpConnector(getHttpClient()))
            .build();
    }

    private HttpClient getHttpClient() {
        return HttpClient.create().responseTimeout(Duration.ofSeconds(TIMEOUT_SECONDS));
    }
}
