package gov.dhs.uscis.pdfintake.admin.service;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;

import gov.dhs.uscis.pdfintake.admin.config.security.ApiKeyAuthentication;
import jakarta.servlet.http.HttpServletRequest;

public class AuthenticationService {

    private static final String AUTH_TOKEN_HEADER_NAME = "X-API-KEY";
    
    private AuthenticationService() {}

    public static Authentication getAuthentication(String authToken, final HttpServletRequest request) {
        final String apiKey = request.getHeader(AUTH_TOKEN_HEADER_NAME);
        if (apiKey == null || !apiKey.equals(authToken)) {
            throw new BadCredentialsException("Invalid API Key");
        }

        ApiKeyAuthentication authentication = new ApiKeyAuthentication(apiKey, AuthorityUtils.NO_AUTHORITIES);
        authentication.setAuthenticated(true); 

        return authentication;
    }
}
