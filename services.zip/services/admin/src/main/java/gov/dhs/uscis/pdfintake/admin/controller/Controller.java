package gov.dhs.uscis.pdfintake.admin.controller;

import java.io.IOException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.pdfintake.admin.service.AdminService;

@RestController
@RequestMapping("/api/v1/admin")
public class Controller {

    private AdminService service;

    public Controller(AdminService service) {
        this.service = service;
    }

    @GetMapping("/documents/manifest/{manifestId}")
    public ResponseEntity<?> downloadArchiveForManifestId(@PathVariable String manifestId) {
        String id = manifestId.toLowerCase();
        try {
            byte[] bytes = service.downloadArchiveForManifestId(id);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", String.format("%s.zip", id));
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(bytes);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("/documents/submission/{submissionId}")
    public ResponseEntity<?> downloadArchiveForSubmissionId(@PathVariable String submissionId) {
        String id = submissionId.toLowerCase();
        try {
            byte[] bytes = service.downloadArchiveForSubmissionId(id);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", String.format("%s.zip", id));
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(bytes);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PostMapping("/manifest/{manifestId}/resubmit")
    public ResponseEntity<?> resubmit(@PathVariable String manifestId, @RequestBody String idLabel ){
        Submission resubmittedSubmission = service.prepareForElisRetry(manifestId, idLabel == null ? "RESUBMITTED" : idLabel);
        return ResponseEntity.ok().body(resubmittedSubmission);
    }

}