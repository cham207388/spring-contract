package gov.dhs.uscis.pdfintake.admin.handler;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
  
  @ExceptionHandler(NoSuchElementException.class)
  protected ResponseEntity<Object> handleBackendValidationException(NoSuchElementException exception) {
    logger.error(exception.getMessage(), exception);
    Map<String, String> errors = new HashMap<>();
    errors.put("error", exception.getMessage());
    return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
  }
}
