package gov.dhs.uscis.pdfintake.admin.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.ELISValidationResponse;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.util.SubmissionUtils;
import gov.dhs.uscis.pdfintake.admin.repository.SubmissionManifestRepository;
import gov.dhs.uscis.pdfintake.admin.repository.SubmissionRepository;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.services.sqs.SqsClient;




@Service
@Slf4j
public class AdminService {

    
        private ObjectMapper mapper = new ObjectMapper();

        private SubmissionRepository submissionRepository;
    private S3Service s3Service;
    private SubmissionManifestRepository submissionManifestRepository;
    private ObjectMapper objectMapper;
    private SubmissionServiceClient submissionServiceClient;

    public enum AcceptableValidatorEnum {
        CORE,
        SIGNATURE,
        ELIGIBILITY_CATEGORY,
        PFVS
    }

    // Todo: Change these to api calls.
    public AdminService(SubmissionRepository submissionRepository,
            SubmissionManifestRepository submissionManifestREpository,
            S3Service s3Service,
            ObjectMapper objectMapper,
            SubmissionServiceClient submissionServiceClient) {
        this.submissionRepository = submissionRepository;
        this.submissionManifestRepository = submissionManifestREpository;
        this.s3Service = s3Service;
        this.objectMapper = objectMapper;
        this.submissionServiceClient = submissionServiceClient;
    }

    public String recompleteSubmission(String myUscisId, String submissionId, String orgMyUscisId) {
        return submissionServiceClient.recompleteSubmission(myUscisId, submissionId, orgMyUscisId);
    }

    public Submission prepareForElisRetry(String manifestId, String currentRecordLabel) {
        var submission = submissionRepository.retrieveSubmissionByManifestId(manifestId).get();
        SubmissionManifest submissionManifest = submissionManifestRepository.retrieveSubmissionManifest(manifestId);

        var submissionResubmit = cloneDomain(submission);
        submission.setManifestId(String.format("%s-%s", manifestId, currentRecordLabel));
        submissionRepository.updateSubmission(submission);

        regenerateDocumentIdentifiers(submissionResubmit);
        submissionResubmit.setSubmissionId(UUID.randomUUID().toString());
        submissionRepository.save(submissionResubmit);

        updateManifest(submissionManifest, submissionResubmit);

        submissionManifestRepository.updateSubmissionManifest(submissionManifest);

        return submissionResubmit;
    }

    private void updateManifest(SubmissionManifest submissionManifest, Submission submissionResubmit) {
        submissionManifest.setSubmissionId(submissionResubmit.getSubmissionId());
        submissionManifest.getStatuses().getManifestStatus().setStatus(StatusEnum.PUBLISHED);
        submissionManifest.getStatuses().getSubmissionStatus().setStatus(StatusEnum.RECEIVED);
        submissionManifest.getStatuses().getSubmissionStatus().getApplicationStatuses()
                .forEach(appStatus -> appStatus.setStatus(StatusEnum.RECEIVED));
        Manifest manifest = submissionManifest.getManifest();
        manifest.getApplications().forEach(application -> {
            application.setSubmissionId(submissionResubmit.getSubmissionId());
            submissionResubmit.getForms().forEach(form -> application.getFiles().parallelStream()
                    .filter(file -> file.getMd5Hash().equals(form.getMd5Hash()))
                    .findFirst()
                    .ifPresent(file -> file.setId(form.getId())));

            submissionResubmit.getEvidences().parallelStream()
                    .collect(Collectors.groupingBy(SubmissionEvidence::getType)).forEach((type, evidences) -> {
                        application.getSupportDocuments().parallelStream()
                                .filter(document -> document.getCategory().equals(type))
                                .findFirst()
                                .ifPresent(document -> {
                                    evidences.forEach(evidence -> document.getFiles().parallelStream()
                                            .filter(file -> file.getMd5Hash().equals(evidence.getMd5Hash()))
                                            .findFirst()
                                            .ifPresent(file -> file.setId(evidence.getId())));
                                });
                    });
            
            if (submissionResubmit.getUserRequestedFeeWaiver()) {
                SubmissionEvidence feeWaiver = submissionResubmit.getFeeWaiver();
                application.getSupportDocuments().parallelStream()
                .filter(document -> "I-912".equals(document.getCategory()))
                .findFirst()
                .ifPresent(document -> document.getFiles().parallelStream().filter(file -> {
                    
                    if (feeWaiver == null) return false;
                    return file.getMd5Hash().equals(feeWaiver.getMd5Hash());
                }).findFirst().ifPresent(file -> file.setId(feeWaiver.getId())));
            }
        });
    }

    private <T> T cloneDomain(T domain) {
        try {
            return (T) objectMapper.readValue(objectMapper.writeValueAsString(domain), domain.getClass());
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // Todo: Decide on whether or not we are going to do this or throw an exception.
        return null;
    }

    private void regenerateDocumentIdentifiers(Submission submission) {

        if (submission.getForms() != null)
            submission.getForms().stream().forEach(f -> f.setId(UUID.randomUUID().toString()));

        if (submission.getEvidences() != null)
            submission.getEvidences().stream().forEach(e -> e.setId(UUID.randomUUID().toString()));

        if (submission.getFeeWaiver() != null)
            submission.getFeeWaiver().setId(UUID.randomUUID().toString());

    }

    public byte[] downloadArchiveForManifestId(String manifestId) throws IOException {
        Optional<Submission> optional = submissionRepository.retrieveSubmissionByManifestId(manifestId);

        if (!optional.isPresent())
            throw new NoSuchElementException(String.format("Submission with manifestId %s not found", manifestId));

        return processZipArchiveRequest(optional);
    }

    public byte[] downloadArchiveForSubmissionId(String id) throws IOException {
        Optional<Submission> optional = submissionRepository.retrieveSubmissionBySubmissionId(id);

        if (!optional.isPresent())
            throw new NoSuchElementException(String.format("Submission with SubmissionId %s not found", id));

        return processZipArchiveRequest(optional);
    }

    private byte[] processZipArchiveRequest(Optional<Submission> optional) throws IOException {
        Submission submission = optional.get();

        List<Map<String, byte[]>> formBytesList = submission.getForms().parallelStream()
                .map(form -> {
                    Map<String, byte[]> map = new HashMap<String, byte[]>();
                    map.put(form.getName(), s3Service.downloadForm(form.getS3Key()));
                    return map;
                })
                .toList();

        List<Map<String, byte[]>> evidenceBytesList = submission.getEvidences().parallelStream()
                .map(evidence -> {
                    Map<String, byte[]> map = new HashMap<String, byte[]>();
                    map.put(evidence.getName(), s3Service.downloadEvidence(evidence.getS3Key()));
                    return map;
                })
                .toList();

        HashMap<String, byte[]> feeWaiverBytesMap = new HashMap<>();

        SubmissionEvidence feeWaiver = submission.getFeeWaiver();
        if (feeWaiver != null) {
            feeWaiverBytesMap.put(feeWaiver.getName(), s3Service.downloadEvidence(feeWaiver.getS3Key()));
        }

        return generateZipBytes(formBytesList, evidenceBytesList, feeWaiver != null ? feeWaiverBytesMap : null);
    }

    private byte[] generateZipBytes(List<Map<String, byte[]>> formBytes, List<Map<String, byte[]>> evidenceBytesList,
            Map<String, byte[]> feeWaiverBytes) throws IOException {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);

        formBytes.forEach(formByteMap -> {
            addToZipOutputStream(zos, formByteMap);
        });

        evidenceBytesList.forEach(evidenceByteMap -> {
            addToZipOutputStream(zos, evidenceByteMap);
        });

        if (feeWaiverBytes != null) {
            addToZipOutputStream(zos, feeWaiverBytes);
        }

        zos.closeEntry();
        zos.close();
        return baos.toByteArray();
    }

    private void addToZipOutputStream(ZipOutputStream zos, Map<String, byte[]> byteMap) {
        String nameKey = (String) byteMap.keySet().toArray()[0];
        byte[] bytes = byteMap.get(nameKey);

        ZipEntry entry = new ZipEntry(nameKey);
        entry.setSize(bytes.length);
        try {
            zos.putNextEntry(entry);
            zos.write(bytes);
        } catch (IOException e) {
            log.error("Failure to add entry to zip");
            e.printStackTrace();
        }
    }

    public List<Submission> retrieveSubmissions(FormType formType, String filters) {
        return submissionRepository.retrieveSubmissionsByFormType(formType, SubmissionUtils.convertAndValidateFilters(filters));
    }
}
