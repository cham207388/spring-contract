
package gov.dhs.uscis.pdfintake.admin.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.pdfintake.admin.service.AdminService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/admin/submission")
public class AdminSubmissionController {
    
    private AdminService service;

    public AdminSubmissionController(AdminService service) {
        this.service = service;
    }

    @GetMapping()
    public ResponseEntity<List<Submission>> retrieveSubmissions(@RequestParam() FormType formType, @RequestParam() String statuses) {
        
        return ResponseEntity.ok().body(service.retrieveSubmissions(formType, statuses));
    }

    @PostMapping("/{myUscisId}/recompleteSubmission/{submissionId}")
    public ResponseEntity recompleteSubmission(@PathVariable("myUscisId") String myUscisId, @PathVariable("submissionId") String submissionId,
                                                    @RequestParam(value="orgMyUscisId", required=false) String orgMyUscisId) {
        log.info("Received request to recomplete submission for submissionId [{}]", submissionId);
        return ResponseEntity.ok(service.recompleteSubmission(myUscisId, submissionId, orgMyUscisId));
    }
}
