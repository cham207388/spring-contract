package gov.dhs.uscis.pdfintake.admin.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.UpdateItemEnhancedRequest;

@Component
@Slf4j
public class SubmissionManifestRepository {
    private DynamoDbTable<SubmissionManifest> submissionManifestTable;
    private Logger log = LoggerFactory.getLogger(SubmissionManifestRepository.class);

    public SubmissionManifestRepository(DynamoDbTable<SubmissionManifest> submissionManifestTable) {
        this.submissionManifestTable = submissionManifestTable;
    }

    public void saveSubmissionManifest(SubmissionManifest submissionManifest) {

        try {
            PutItemEnhancedRequest<SubmissionManifest> enhancedRequest = PutItemEnhancedRequest
                    .builder(SubmissionManifest.class)
                    .item(submissionManifest)
                    .build();

            submissionManifestTable.putItem(enhancedRequest);
        } catch (Exception ex) {
            log.error("Exception encountered during putItem", ex.getMessage());
        }
    }

    public void updateSubmissionManifest(SubmissionManifest submissionManifest) {
        try {
            UpdateItemEnhancedRequest<SubmissionManifest> enhancedRequest = UpdateItemEnhancedRequest
                    .builder(SubmissionManifest.class)
                    .item(submissionManifest).build();
            submissionManifestTable.updateItem(enhancedRequest);
        } catch (Exception ex) {
            log.error("Exception encountered during updateItem", ex.getMessage());
        }
    }

    public SubmissionManifest retrieveSubmissionManifest(String manifestId) {
        try {
            GetItemEnhancedRequest request = GetItemEnhancedRequest.builder()
                    .key(builder -> builder.partitionValue(manifestId.toLowerCase())).build();
            return submissionManifestTable.getItem(request);
        } catch (Exception ex) {
            log.error("Exception encountered during getItem", ex.getMessage());
            return null;
        }
    }
}

