package gov.dhs.uscis.pdfintake.admin.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;

@Service
public class S3Service {

    private String formBucket;
    private String evidenceBucket;
    private S3Client s3Client;

    public S3Service(@Value("${application.s3.buckets.form}") String formBucket,
            @Value("${application.s3.buckets.evidence}") String evidenceBucket, S3Client s3Client) {
        this.formBucket = formBucket;
        this.evidenceBucket = evidenceBucket;
        this.s3Client = s3Client;
    }

    public byte[] downloadForm(String formS3Key) {
        return s3Client.getObjectAsBytes(GetObjectRequest.builder().bucket(formBucket).key(formS3Key).build()).asByteArray();
    }

    public byte[] downloadEvidence(String evidenceS3Key) {
        return s3Client.getObjectAsBytes(GetObjectRequest.builder().bucket(evidenceBucket).key(evidenceS3Key).build()).asByteArray();
    }

}
