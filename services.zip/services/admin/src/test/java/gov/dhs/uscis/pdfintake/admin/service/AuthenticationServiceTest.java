package gov.dhs.uscis.pdfintake.admin.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;

import jakarta.servlet.http.HttpServletRequest;

public class AuthenticationServiceTest {

    @Test
    void shouldThrowExceptionWhenApiKeyIsNull() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getHeader("X-API-KEY")).thenReturn(null);
        assertThrows(BadCredentialsException.class, () -> AuthenticationService.getAuthentication("apiKey", request));
    }

    @Test
    void shouldThrowExceptionWhenApiKeyIsNotCorrect() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getHeader("X-API-KEY")).thenReturn("notkey");
        assertThrows(BadCredentialsException.class, () -> AuthenticationService.getAuthentication("apiKey", request));
    }

    @Test
    void shouldNotThrowExceptionWhenApiKeyIsCorrect() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        String apiKey = "key";
        when(request.getHeader("X-API-KEY")).thenReturn(apiKey);
        
        Authentication authentication = AuthenticationService.getAuthentication(apiKey, request);
        assertThat(authentication.isAuthenticated()).isTrue();
    }
}
