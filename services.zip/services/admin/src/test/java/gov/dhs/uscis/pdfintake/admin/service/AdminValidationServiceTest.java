package gov.dhs.uscis.pdfintake.admin.service;

import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import static org.junit.jupiter.api.Assertions.assertFalse;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.pdfintake.admin.repository.SubmissionManifestRepository;
import gov.dhs.uscis.pdfintake.admin.repository.SubmissionRepository;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;
import software.amazon.awssdk.services.sqs.model.SqsException;
public class AdminValidationServiceTest {

    private static final String I_912 = "I-912";
    SubmissionRepository repository = mock(SubmissionRepository.class);
    SubmissionManifestRepository manifestRepository = mock(SubmissionManifestRepository.class);
    Submission submission = mock(Submission.class);
    private SqsClient sqsClient = mock(SqsClient.class);
    ObjectMapper objectMapper = new ObjectMapper();

    AdminValidationService service;
    String id = UUID.randomUUID().toString();
    String formKey = "formS3Key";
    String evidenceKey = "evidenceS3Key";

    @BeforeEach
    void setUp() {
        objectMapper.registerModule(new JavaTimeModule());
        service = new AdminValidationService(repository, sqsClient, objectMapper);
    }

    
    @Test
    void shouldUpdateSubmissionValidationStatusWithCore() {
        var submission = Submission.builder().submissionId(UUID.randomUUID().toString()).formType(FormType.I765).forms(Arrays.asList(SubmissionForm.builder().id("test").build())).build();
        String SubmissionID = submission.getSubmissionId();
        ValidatorEnum validator = ValidatorEnum.CORE;

        when(repository.retrieveSubmissionBySubmissionId(SubmissionID)).thenReturn(Optional.of(submission));
        
        service.updateSubmissionValidationStatus(SubmissionID, validator, 230);
        ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
        verify(sqsClient, times(1)).sendMessage(captor.capture());

        SendMessageRequest sendMessageRequest = captor.getValue();
        String publishedMessage = sendMessageRequest.messageBody();

        assertTrue(sendMessageRequest.messageBody().contains(SubmissionID));

        assertNotNull(publishedMessage);
    }
    

    @Test
    void shouldUpdateSubmissionValidationStatusWithNull() {
        var submission = Submission.builder().submissionId(UUID.randomUUID().toString()).formType(FormType.I765).forms(Arrays.asList(SubmissionForm.builder().id("test").build())).build();
        String SubmissionID = submission.getSubmissionId();
       
        when(repository.retrieveSubmissionBySubmissionId(SubmissionID)).thenReturn(Optional.of(submission));
        
        service.updateSubmissionValidationStatus(SubmissionID, null, 230);
        ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
        verify(sqsClient, times(1)).sendMessage(captor.capture());

        SendMessageRequest sendMessageRequest = captor.getValue();
        String publishedMessage = sendMessageRequest.messageBody();

        assertTrue(sendMessageRequest.messageBody().contains(SubmissionID));

        assertNotNull(publishedMessage);
    }

        @Test
    void shouldReturnFalseWhenSQSThrowsException() {
        var submission = Submission.builder().submissionId(UUID.randomUUID().toString()).formType(FormType.I765).forms(Arrays.asList(SubmissionForm.builder().id("test").build())).build();
        String SubmissionID = submission.getSubmissionId();
       
        when(repository.retrieveSubmissionBySubmissionId(SubmissionID)).thenReturn(Optional.of(submission));
              when(sqsClient.sendMessage(any(SendMessageRequest.class)))
            .thenThrow(SqsException.builder().message("Service Unavailable").build());

        boolean result =  service.updateSubmissionValidationStatus(SubmissionID, null, 230);
        ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
        verify(sqsClient, times(1)).sendMessage(captor.capture());


        assertFalse(result);
    }

            @Test
    void shouldReturnFalseWhenSThrowsException() {
        var submission = Submission.builder().submissionId(UUID.randomUUID().toString()).formType(FormType.I765).forms(Arrays.asList(SubmissionForm.builder().id("test").build())).build();
        String SubmissionID = submission.getSubmissionId();
       
        when(repository.retrieveSubmissionBySubmissionId(SubmissionID)).thenThrow(SqsException.builder().message("Service Unavailable").build());;

        boolean result =  service.updateSubmissionValidationStatus(SubmissionID, null, 230);
        assertFalse(result);
    }
    

      @Test
    void shouldUpdateSubmissionValidationStatusWithSignature() {
        var submission = Submission.builder().submissionId(UUID.randomUUID().toString()).formType(FormType.I765).forms(Arrays.asList(SubmissionForm.builder().id("test").build())).build();
        String SubmissionID = submission.getSubmissionId();
        ValidatorEnum validaitor = ValidatorEnum.SIGNATURE;
    SendMessageResponse mockResponse = SendMessageResponse.builder()
            .messageId("mock-msg-id")
            .build();
        when(repository.retrieveSubmissionBySubmissionId(SubmissionID)).thenReturn(Optional.of(submission));
    when(sqsClient.sendMessage(any(SendMessageRequest.class))).thenReturn(mockResponse);
        service.updateSubmissionValidationStatus(SubmissionID, validaitor, 230);
        ArgumentCaptor<SendMessageRequest> captor = ArgumentCaptor.forClass(SendMessageRequest.class);
        verify(sqsClient, times(1)).sendMessage(captor.capture());

        SendMessageRequest sendMessageRequest = captor.getValue();
        String publishedMessage = sendMessageRequest.messageBody();

        assertTrue(sendMessageRequest.messageBody().contains(SubmissionID));

        assertNotNull(publishedMessage);
    }
}
