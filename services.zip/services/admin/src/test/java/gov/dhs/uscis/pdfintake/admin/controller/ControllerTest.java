package gov.dhs.uscis.pdfintake.admin.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.UUID;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.pdfintake.admin.service.AdminService;

public class ControllerTest {
    AdminService service = Mockito.mock(AdminService.class);

    Controller controller = new Controller(service);

    @Test
    void shouldReturnZipArchiveUsingManifestId() throws IOException {
        byte[] content = "fileContent".getBytes();

        String manifestId = UUID.randomUUID().toString().toUpperCase();
        when(service.downloadArchiveForManifestId(manifestId)).thenReturn(content);

        ResponseEntity<?> response = controller.downloadArchiveForManifestId(manifestId);

        verify(service, times(1)).downloadArchiveForManifestId(manifestId.toLowerCase());

        assertThat(response.getHeaders().getContentDisposition().isFormData()).isTrue();
        assertThat(response.getHeaders().getContentDisposition().getFilename())
                .isEqualTo(String.format("%s.zip", manifestId.toLowerCase()));
    }

    @Test
    void shouldHaveRequestMappingForZipArchiveOperationUsingManifestId() throws Exception {
        String manifestId = UUID.randomUUID().toString().toUpperCase();
        byte[] content = "fileContent".getBytes();
        
        when(service.downloadArchiveForManifestId(manifestId)).thenReturn(content);
        MockMvc mockController = MockMvcBuilders.standaloneSetup(controller).build();

        mockController.perform(get("/api/v1/admin/documents/manifest/" + manifestId)
                .accept(MediaType.APPLICATION_OCTET_STREAM))
                .andExpect(status().isOk());
    }

    @Test
    void shouldReturnZipArchiveUsingSubmissionId() throws IOException {
        byte[] content = "fileContent".getBytes();

        String id = UUID.randomUUID().toString().toUpperCase();
        when(service.downloadArchiveForSubmissionId(id)).thenReturn(content);

        ResponseEntity<?> response = controller.downloadArchiveForSubmissionId(id);

        verify(service, times(1)).downloadArchiveForSubmissionId(id.toLowerCase());

        assertThat(response.getHeaders().getContentDisposition().isFormData()).isTrue();
        assertThat(response.getHeaders().getContentDisposition().getFilename())
                .isEqualTo(String.format("%s.zip", id.toLowerCase()));
    }

    @Test
    void shouldHaveRequestMappingForZipArchiveOperationUsingSubmissionId() throws Exception {
        String id = UUID.randomUUID().toString().toUpperCase();
        byte[] content = "fileContent".getBytes();
        
        when(service.downloadArchiveForSubmissionId(id)).thenReturn(content);
        MockMvc mockController = MockMvcBuilders.standaloneSetup(controller).build();

        mockController.perform(get("/api/v1/admin/documents/submission/" + id)
                .accept(MediaType.APPLICATION_OCTET_STREAM))
                .andExpect(status().isOk());
    }

    @Test
    void shouldGenerateNewSubmissionForResubmittedCaseForELIS() throws Exception {
        String id = UUID.randomUUID().toString().toUpperCase();
        
        String idLabel = "resubmit";
        var submission = Instancio.create(Submission.class);
        when(service.prepareForElisRetry(id, idLabel)).thenReturn(submission);
        MockMvc mockController = MockMvcBuilders.standaloneSetup(controller).build();

        MvcResult result = mockController.perform(post(String.format("/api/v1/admin/manifest/%s/resubmit", id))
                .accept(MediaType.APPLICATION_JSON).content(idLabel))
                .andExpect(status().isOk()).andReturn();

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        assertThat(objectMapper.readValue(result.getResponse().getContentAsString(), Submission.class).getSubmissionId()).isEqualTo(submission.getSubmissionId());
    }
}
