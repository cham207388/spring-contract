package gov.dhs.uscis.pdfintake.admin.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidationResultEnum;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.pdfintake.admin.service.AdminService;

public class AdminSubmissionControllerTest {

    AdminService service = Mockito.mock(AdminService.class);

    AdminSubmissionController controller = new AdminSubmissionController(service);

    @Test
    void shouldRetrieveSubmissionsByFormTypeAndStatus() throws Exception {
        var submission = Submission.builder().submissionId(UUID.randomUUID().toString()).build();

        FormType formType = FormType.I765;
        String statuses = "DRAFT,ACCEPTED";

        when(service.retrieveSubmissions(formType, statuses)).thenReturn(List.of(submission));
        MockMvc mockController = MockMvcBuilders.standaloneSetup(controller).build();

        MvcResult result = mockController
                .perform(get(String.format("/api/v1/admin/submission?formType=%s&statuses=%s", FormType.I765, statuses))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andReturn();

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        List<Submission> submissions = objectMapper.readValue(result.getResponse().getContentAsString(), List.class);
        assertThat(submissions).isNotEmpty();
    }

    @Test
    public void shouldReturn200OnSuccessfulRecomplete() throws Exception {
        String myUscisId = "anonymousUser";
        String submissionId = "testSubmissionId";
        String manifestId = "testManifestId";

        when(service.recompleteSubmission(myUscisId, submissionId, null)).thenReturn(manifestId);

        MockMvc mockController = MockMvcBuilders.standaloneSetup(controller).build();

        mockController.perform(MockMvcRequestBuilders.post(String.format("/api/v1/admin/submission/%s/recompleteSubmission/%s", myUscisId, submissionId))).andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
    }
}
