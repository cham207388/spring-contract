package gov.dhs.uscis.pdfintake.admin.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.pdfintake.admin.service.AdminValidationService;

public class AdminSubmissionValidationControllerTest {

    AdminValidationService service = Mockito.mock(AdminValidationService.class);

    AdminSubmissionValidationController controller = new AdminSubmissionValidationController(service);

     @Test
    void shouldReturnSuccessfulUpdateSubmissionValidation() throws Exception {
        var submission = Submission.builder().submissionId(UUID.randomUUID().toString()).build();
        String SubmissionID = UUID.randomUUID().toString();
        ValidatorEnum validaitor = ValidatorEnum.CORE;

        when(service.updateSubmissionValidationStatus(SubmissionID, validaitor, 230)).thenReturn(true);

        MockMvc mockController = MockMvcBuilders.standaloneSetup(controller).build();
        mockController.perform(MockMvcRequestBuilders.post("/api/v1/admin/submission/{submissionId}/validationStatus", submission.getSubmissionId())
        .contentType(MediaType.APPLICATION_JSON).content("{\"validaitor\":\"CORE\"}")).andExpect(status().isOk())
                .andReturn();
    }
}
