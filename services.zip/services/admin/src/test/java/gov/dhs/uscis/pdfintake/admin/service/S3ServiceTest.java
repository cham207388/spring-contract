package gov.dhs.uscis.pdfintake.admin.service;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;

public class S3ServiceTest {
    String formBucket = "formBucket";
    String evidenceBucket = "evidenceBucket";

    S3Client s3Client = mock(S3Client.class);

    S3Service service = new S3Service(formBucket, evidenceBucket, s3Client);

    @Test
    void shouldGetForm() {
        String formS3Key = "s3Key";
        byte[] expectedBytes = "expected bytes".getBytes();
        
        ResponseBytes<GetObjectResponse> responseBytes = mock(ResponseBytes.class);

        when(s3Client.getObjectAsBytes(any(GetObjectRequest.class))).thenReturn(responseBytes);
        when(responseBytes.asByteArray()).thenReturn(expectedBytes);

        byte[] contents = service.downloadForm(formS3Key);

        verify(s3Client, times(1)).getObjectAsBytes(GetObjectRequest.builder().bucket(formBucket).key(formS3Key).build());
        assertThat(contents).isEqualTo(expectedBytes);
    }   

    @Test
    void shouldGetEvidence() {
        String evidenceS3Key = "s3Key";
        byte[] expectedBytes = "expected bytes".getBytes();
        
        ResponseBytes<GetObjectResponse> responseBytes = mock(ResponseBytes.class);

        when(s3Client.getObjectAsBytes(any(GetObjectRequest.class))).thenReturn(responseBytes);
        when(responseBytes.asByteArray()).thenReturn(expectedBytes);

        byte[] contents = service.downloadEvidence(evidenceS3Key);

        verify(s3Client, times(1)).getObjectAsBytes(GetObjectRequest.builder().bucket(evidenceBucket).key(evidenceS3Key).build());
        assertThat(contents).isEqualTo(expectedBytes);
    }   
}
