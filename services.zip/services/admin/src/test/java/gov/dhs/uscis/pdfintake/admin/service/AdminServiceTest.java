package gov.dhs.uscis.pdfintake.admin.service;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.assertj.core.api.Assertions;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import org.instancio.Instancio;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import gov.dhs.uscis.intake.entities.SubmissionManifest;
import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.entities.submissionmanifest.Application;
import gov.dhs.uscis.intake.entities.submissionmanifest.Manifest;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.ApplicationFile;
import gov.dhs.uscis.intake.entities.submissionmanifest.applications.ApplicationSupportDocument;
import gov.dhs.uscis.intake.entities.submissionmanifest.statuses.StatusEnum;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.enums.ValidatorEnum;
import gov.dhs.uscis.intake.models.Submission;
import gov.dhs.uscis.intake.models.submission.SubmissionEvidence;
import gov.dhs.uscis.intake.models.submission.SubmissionForm;
import gov.dhs.uscis.pdfintake.admin.repository.SubmissionManifestRepository;
import gov.dhs.uscis.pdfintake.admin.repository.SubmissionRepository;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
public class AdminServiceTest {

    private static final String I_912 = "I-912";
    SubmissionRepository repository = mock(SubmissionRepository.class);
    SubmissionManifestRepository manifestRepository = mock(SubmissionManifestRepository.class);
    Submission submission = mock(Submission.class);
    SubmissionManifest submissionManifest = mock(SubmissionManifest.class);
    private S3Service s3Service = mock(S3Service.class);
    ObjectMapper objectMapper = new ObjectMapper();
    SubmissionServiceClient submissionServiceClient = mock(SubmissionServiceClient.class);

    AdminService service;
    String id = UUID.randomUUID().toString();
    String formKey = "formS3Key";
    String evidenceKey = "evidenceS3Key";

    @BeforeEach
    void setUp() {
        objectMapper.registerModule(new JavaTimeModule());
        service = new AdminService(repository, manifestRepository, s3Service, objectMapper, submissionServiceClient);
        when(s3Service.downloadForm(anyString())).thenReturn("test return".getBytes());
        when(s3Service.downloadEvidence(anyString())).thenReturn("test return".getBytes());
    }

    @Test
    void shouldFetchSubmissionByManifestId() throws IOException {
        when(repository.retrieveSubmissionByManifestId(id)).thenReturn(Optional.of(mock(Submission.class)));

        service.downloadArchiveForManifestId(id);

        verify(repository, times(1)).retrieveSubmissionByManifestId(id);
    }

    @Test
    void shouldThrowNoSuchElementExceptionWhenNoSubmissionFound_ManifestId() {
        when(repository.retrieveSubmissionByManifestId(id)).thenReturn(Optional.empty());

        assertThatExceptionOfType(NoSuchElementException.class)
                .isThrownBy(() -> service.downloadArchiveForManifestId(id))
                .withMessage(String.format("Submission with manifestId %s not found", id));
        verify(repository, times(1)).retrieveSubmissionByManifestId(id);
    }

    @Test
    void shouldFetchSubmissionForm_ManifestId() throws IOException {
        Submission submission = mock(Submission.class);
        SubmissionForm submissionForm = mock(SubmissionForm.class);

        when(repository.retrieveSubmissionByManifestId(id)).thenReturn(Optional.of(submission));

        when(submission.getForms()).thenReturn(List.of(submissionForm));
        when(submissionForm.getName()).thenReturn("formName.pdf");
        when(submissionForm.getS3Key()).thenReturn(formKey);

        service.downloadArchiveForManifestId(id);

        verify(s3Service, times(1)).downloadForm(formKey);
    }

    @Test
    void shouldNotCallS3ClientWhenNothingExists() throws IOException {
        Submission submission = mock(Submission.class);

        when(repository.retrieveSubmissionByManifestId(id)).thenReturn(Optional.of(submission));

        when(submission.getForms()).thenReturn(List.of());
        when(submission.getEvidences()).thenReturn(List.of());

        service.downloadArchiveForManifestId(id);

        verifyNoInteractions(s3Service);
    }

    @Test
    void shouldFetchSubmissionEvidences() throws IOException {
        String evidenceBKey = "evidenceBS3Key";

        Submission submission = mock(Submission.class);
        SubmissionEvidence evidenceA = mock(SubmissionEvidence.class);
        SubmissionEvidence evidenceB = mock(SubmissionEvidence.class);

        when(repository.retrieveSubmissionByManifestId(id)).thenReturn(Optional.of(submission));
        when(submission.getEvidences()).thenReturn(List.of(evidenceA, evidenceB));
        when(evidenceA.getName()).thenReturn("evidenceAName");
        when(evidenceA.getS3Key()).thenReturn(evidenceKey);
        when(evidenceB.getName()).thenReturn("evidenceBName");
        when(evidenceB.getS3Key()).thenReturn(evidenceBKey);

        service.downloadArchiveForManifestId(id);

        verify(s3Service, times(1)).downloadEvidence(evidenceKey);
        verify(s3Service, times(1)).downloadEvidence(evidenceBKey);
    }

    @Test
    void shouldFetchFeeWaiver() throws IOException {
        Submission submission = mock(Submission.class);
        SubmissionEvidence feeWaiver = mock(SubmissionEvidence.class);

        when(repository.retrieveSubmissionByManifestId(id)).thenReturn(Optional.of(submission));
        when(submission.getFeeWaiver()).thenReturn(feeWaiver);
        when(feeWaiver.getName()).thenReturn("evidenceName");
        when(feeWaiver.getS3Key()).thenReturn(evidenceKey);

        service.downloadArchiveForManifestId(id);

        verify(s3Service, times(1)).downloadEvidence(evidenceKey);
    }

    @Test
    void shouldFetchSubmissionBySubmissionId() throws IOException {
        when(repository.retrieveSubmissionBySubmissionId(id)).thenReturn(Optional.of(mock(Submission.class)));

        service.downloadArchiveForSubmissionId(id);

        verify(repository, times(1)).retrieveSubmissionBySubmissionId(id);
    }

    @Test
    void shouldThrowNoSuchElementExceptionWhenNoSubmissionFound_SubmissionId() {
        when(repository.retrieveSubmissionBySubmissionId(id)).thenReturn(Optional.empty());

        assertThatExceptionOfType(NoSuchElementException.class)
                .isThrownBy(() -> service.downloadArchiveForSubmissionId(id))
                .withMessage(String.format("Submission with SubmissionId %s not found", id));
        verify(repository, times(1)).retrieveSubmissionBySubmissionId(id);
    }

    @Test
    void shouldFetchSubmissionForm_SubmissionId() throws IOException {
        Submission submission = mock(Submission.class);
        SubmissionForm submissionForm = mock(SubmissionForm.class);

        when(repository.retrieveSubmissionBySubmissionId(id)).thenReturn(Optional.of(submission));

        when(submission.getForms()).thenReturn(List.of(submissionForm));
        when(submissionForm.getName()).thenReturn("formName.pdf");
        when(submissionForm.getS3Key()).thenReturn(formKey);

        service.downloadArchiveForSubmissionId(id);

        verify(s3Service, times(1)).downloadForm(formKey);
    }

    @Test
    void shouldArchiveSubmission() {
        String manifestId = UUID.randomUUID().toString();
        Submission submission = Instancio.create(Submission.class);
        SubmissionManifest submissionManifest = Instancio.create(SubmissionManifest.class);
        submission.setManifestId(manifestId);

        when(repository.retrieveSubmissionByManifestId(manifestId)).thenReturn(Optional.of(submission));
        when(manifestRepository.retrieveSubmissionManifest(manifestId)).thenReturn(submissionManifest);

        String currentRecordLabel = "RESUBMITTED";
        service.prepareForElisRetry(manifestId, currentRecordLabel);

        ArgumentCaptor<Submission> captor = ArgumentCaptor.forClass(Submission.class);
        verify(repository, times(1)).updateSubmission(captor.capture());

        Submission archivedSubmission = captor.getValue();
        assertThat(archivedSubmission.getSubmissionId()).isEqualTo(submission.getSubmissionId());
        assertThat(archivedSubmission.getManifestId()).isEqualTo(manifestId + "-" + currentRecordLabel);
    }

    @Test
    void shouldCreateResubmittedSubmissionWithUpdatedDocumentIds() {
        String manifestId = UUID.randomUUID().toString();
        Submission submission = Instancio.create(Submission.class);
        SubmissionManifest submissionManifest = Instancio.create(SubmissionManifest.class);
        submission.setManifestId(manifestId);

        when(repository.retrieveSubmissionByManifestId(manifestId)).thenReturn(Optional.of(submission));
        when(manifestRepository.retrieveSubmissionManifest(manifestId)).thenReturn(submissionManifest);

        String currentRecordLabel = "RESUBMITTED";
        Submission transformed = service.prepareForElisRetry(manifestId, currentRecordLabel);

        ArgumentCaptor<Submission> captor = ArgumentCaptor.forClass(Submission.class);
        verify(repository, times(1)).save(captor.capture());

        Submission resubmitSubmission = captor.getValue();
        assertThat(transformed).isEqualTo(resubmitSubmission);
        assertThat(resubmitSubmission.getSubmissionId()).isNotEqualTo(submission.getSubmissionId());
        assertThat(resubmitSubmission.getFeeWaiver().getId()).isNotEqualTo(submission.getFeeWaiver().getId());
        resubmitSubmission.getForms().forEach(form -> {
            assertThat(submission.getForms().stream()
                    .noneMatch(subForm -> subForm.getId().equals(form.getId())))
                    .isTrue();
        });
        resubmitSubmission.getEvidences().forEach(evidence -> {
            assertThat(submission.getEvidences().stream()
                    .noneMatch(subEvidence -> subEvidence.getId().equals(evidence.getId())))
                    .isTrue();
        });
    }

    @Test
    void shouldUpdateManifestSubmissionWithResubmittedSubmissionThatHasUpdatedDocumentIds() {
        String manifestId = UUID.randomUUID().toString();
        String submissionId = UUID.randomUUID().toString();
        Submission submission = Instancio.create(Submission.class);
        SubmissionManifest submissionManifest = Instancio.create(SubmissionManifest.class);

        submission.setManifestId(manifestId);
        submission.setSubmissionId(submissionId);
        submission.setUserRequestedFeeWaiver(true);

        submissionManifest.setManifestId(manifestId);
        submissionManifest.setSubmissionId(submissionId);
        Map<String, List<SubmissionEvidence>> evidenceGroups = submission.getEvidences().parallelStream()
                .collect(Collectors.groupingBy(SubmissionEvidence::getType));

        Manifest manifest = submissionManifest.getManifest();
        manifest.setManifestId(manifestId);
        manifest.setApplications(List.of(Application.builder()
                .formType(submission.getFormType().getType())
                .files(submission.getForms().parallelStream()
                        .map(form -> ApplicationFile.builder()
                                .id(form.getId())
                                .md5Hash(form.getMd5Hash())
                                .name(form.getName())
                                .uri(form.getUrl())
                                .build())
                        .toList())
                .supportDocuments(evidenceGroups.keySet().parallelStream()
                        .map(key -> ApplicationSupportDocument.builder()
                                .category(key)
                                .supportId(UUID.nameUUIDFromBytes(key.getBytes())
                                        .toString())
                                .files(evidenceGroups.get(key).parallelStream()
                                        .map(evidence -> ApplicationFile
                                                .builder()
                                                .id(evidence.getId())
                                                .md5Hash(evidence
                                                        .getMd5Hash())
                                                .name(evidence.getName())
                                                .uri(evidence.getUrl())
                                                .build())
                                        .toList())
                                .build())
                        .collect(Collectors.toList()))
                .submissionId(submissionId)
                .build()));
        SubmissionEvidence feeWaiver = submission.getFeeWaiver();
        manifest.getApplications().get(0).getSupportDocuments().add(ApplicationSupportDocument.builder()
                .category(I_912)
                .supportId(UUID.nameUUIDFromBytes(I_912.getBytes()).toString())
                .files(List.of(ApplicationFile.builder()
                        .id(feeWaiver.getId())
                        .md5Hash(submission.getFeeWaiver().getMd5Hash())
                        .name(submission.getFeeWaiver().getName())
                        .uri(submission.getFeeWaiver().getUrl())
                        .build()))
                .build());
        when(repository.retrieveSubmissionByManifestId(manifestId)).thenReturn(Optional.of(submission));
        when(manifestRepository.retrieveSubmissionManifest(manifestId)).thenReturn(submissionManifest);

        String currentRecordLabel = "RESUBMITTED";
        Submission transformed = service.prepareForElisRetry(manifestId, currentRecordLabel);

        ArgumentCaptor<SubmissionManifest> captor = ArgumentCaptor.forClass(SubmissionManifest.class);
        verify(manifestRepository, times(1)).updateSubmissionManifest(captor.capture());

        SubmissionManifest updatedManifest = captor.getValue();
        assertThat(updatedManifest.getManifestId()).isEqualTo(manifestId);
        assertThat(updatedManifest.getSubmissionId()).isEqualTo(transformed.getSubmissionId());
        assertThat(updatedManifest.getStatuses().getManifestStatus().getStatus())
                .isEqualByComparingTo(StatusEnum.PUBLISHED);
        assertThat(updatedManifest.getStatuses().getSubmissionStatus().getStatus())
                .isEqualByComparingTo(StatusEnum.RECEIVED);
        assertThat(updatedManifest.getStatuses().getSubmissionStatus().getApplicationStatuses().get(0)
                .getStatus())
                .isEqualByComparingTo(StatusEnum.RECEIVED);
        Manifest lockboxManifestUpdate = updatedManifest.getManifest();
        assertThat(lockboxManifestUpdate.getManifestId()).isEqualTo(manifestId);
        Application application = lockboxManifestUpdate.getApplications().get(0);
        assertThat(application.getSubmissionId()).isEqualTo(transformed.getSubmissionId());

        List<ApplicationFile> files = application.getFiles();
        assertThat(files.size()).isEqualTo(transformed.getForms().size());
        transformed.getForms()
                .forEach(form -> assertThat(files.parallelStream()
                        .anyMatch(file -> file.getId().equals(form.getId())))
                        .isTrue());

        List<ApplicationSupportDocument> supportDocuments = application.getSupportDocuments();
        Map<String, List<SubmissionEvidence>> evidenceGroup = transformed.getEvidences().parallelStream()
                .collect(Collectors.groupingBy(SubmissionEvidence::getType));

        evidenceGroup.keySet().parallelStream().forEach(key -> {
            Optional<ApplicationSupportDocument> optionalGroup = supportDocuments.parallelStream()
                    .filter(supportDocument -> supportDocument.getCategory().equals(key))
                    .findFirst();
            optionalGroup.ifPresentOrElse((document) -> {
                evidenceGroup.get(key).forEach(evidence -> assertThat(
                        document.getFiles().parallelStream().anyMatch(
                                file -> file.getId().equals(evidence.getId())))
                        .isTrue());
            }, () -> Assertions.fail("Supporting document group not found"));
        });

        supportDocuments.parallelStream()
                .filter(document -> document.getCategory().equals(I_912))
                .findFirst()
                .ifPresent(
                        doc -> assertThat(doc.getFiles().get(0).getId()).isEqualTo(transformed.getFeeWaiver().getId()));

    }

    @Test
    void shouldRetrieveSubmissionsByFormType() {
        FormType formType = FormType.I765;
        when(repository.retrieveSubmissionsByFormType(formType, List.of())).thenReturn(List.of(mock(Submission.class)));
        List<Submission> submissionDtos = service.retrieveSubmissions(formType, null);

        assertThat(submissionDtos).isNotEmpty();
    }

    @Test
    void shouldRetrieveSubmissionsByFormTypeAndStatus() {
        FormType formType = FormType.I765;
        when(repository.retrieveSubmissionsByFormType(formType, List.of(SubmissionState.ACCEPTED, SubmissionState.DRAFT))).thenReturn(List.of(mock(Submission.class)));
        List<Submission> submissionDtos = service.retrieveSubmissions(formType, "ACCEPTED,DRAFT");

        assertThat(submissionDtos).isNotEmpty();
    }

    @Test
    public void recompleteSubmissionReturnsManifestId() {
        String submissionId = "testSubmissionId";
        String myUscisId = "anonymousUser";
        String manifestId = "testManifestId";

        when(submissionServiceClient.recompleteSubmission(myUscisId, submissionId, null)).thenReturn(manifestId);

        assertEquals(manifestId, service.recompleteSubmission(myUscisId, submissionId, null));
    }
}
