package gov.dhs.uscis.pdfintake.admin.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.Stream;

import org.instancio.Instancio;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import gov.dhs.uscis.intake.entities.submission.SubmissionState;
import gov.dhs.uscis.intake.enums.FormType;
import gov.dhs.uscis.intake.models.Submission;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbIndex;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

public class SubmissionRepositoryTest {

    @SuppressWarnings("unchecked")
    DynamoDbTable<Submission> table = mock(DynamoDbTable.class);

    SubmissionRepository repository = new SubmissionRepository(table);

    @Test
    void shouldFetchSubmissionByManifestId() {

        DynamoDbIndex<Submission> mockIndex = mock(DynamoDbIndex.class);
        SdkIterable<Page<Submission>> sdkIterable = mock(PageIterable.class);
        Submission submission = Submission.builder().build();

        when(mockIndex.query(any(Consumer.class))).thenReturn(sdkIterable);
        when(sdkIterable.stream())
                .thenReturn(Stream.of(Page.builder(Submission.class).items(List.of(submission)).build()));
        when(table.index("requests_by_manifestId")).thenReturn(mockIndex);

        Optional<Submission> response = repository.retrieveSubmissionByManifestId(UUID.randomUUID().toString());

        assertThat(response.isPresent()).isTrue();
        assertThat(response.get()).isEqualTo(submission);

    }

    @Test
    void shouldFetchSubmissionBySubmissionId() {

        Submission submission = Submission.builder().build();

        String id = UUID.randomUUID().toString();
        when(table.getItem(Key.builder().partitionValue(id).build())).thenReturn(submission);

        Optional<Submission> response = repository.retrieveSubmissionBySubmissionId(id);

        assertThat(response.isPresent()).isTrue();
        assertThat(response.get()).isEqualTo(submission);
    }

    @Test
    void shouldFetchSubmissionBySubmissionIdWhenNotFound() {
        String id = UUID.randomUUID().toString();
        when(table.getItem(Key.builder().partitionValue(id).build())).thenReturn(null);

        Optional<Submission> response = repository.retrieveSubmissionBySubmissionId(id);

        assertThat(response.isPresent()).isFalse();
    }

    @Test
    void shouldUpdateSubmission() {
        Submission mock = mock(Submission.class);
        Submission createdSubmission = Instancio.create(Submission.class);
        when(table.updateItem(mock)).thenReturn(createdSubmission);
        Optional<Submission> updateSubmission = repository.updateSubmission(mock);

        assertThat(updateSubmission.isPresent()).isTrue();
        assertThat(updateSubmission.get()).isEqualTo(createdSubmission);
        verify(table, times(1)).updateItem(mock);
    }

    @Test
    void shouldSaveSubmission() {
        Submission mock = mock(Submission.class);
        repository.save(mock);

        verify(table, times(1)).putItem(mock);
    }

    @Test
    void shouldFetchSubmissionsByFormType() {
        PageIterable<Submission> sdkIterable = mock(PageIterable.class);
        Submission submission = Submission.builder().build();

        when(sdkIterable.stream())
                .thenReturn(Stream.of(Page.builder(Submission.class).items(List.of(submission)).build()));
        when(table.query(any(QueryEnhancedRequest.class))).thenReturn(sdkIterable);

        var formType = FormType.I765;
        List<Submission> response = repository.retrieveSubmissionsByFormType(formType, List.of());

        assertThat(response).isNotEmpty();

        ArgumentCaptor<QueryEnhancedRequest> captor = ArgumentCaptor.forClass(QueryEnhancedRequest.class);
        verify(table, times(1)).query(captor.capture());

        QueryEnhancedRequest request = captor.getValue();
        var filter = request.filterExpression();
        assertThat(filter.expression()).isEqualTo("formType = :formType");
        assertThat(filter.expressionValues()).isEqualTo(Map.of(":formType", AttributeValue.fromS(formType.getType())));
    }

    @Test
    void shouldFetchSubmissionsByFormTypeAndStatuses() {
        PageIterable<Submission> sdkIterable = mock(PageIterable.class);
        Submission submission = Submission.builder().build();

        when(sdkIterable.stream())
                .thenReturn(Stream.of(Page.builder(Submission.class).items(List.of(submission)).build()));
        when(table.query(any(QueryEnhancedRequest.class))).thenReturn(sdkIterable);

        var formType = FormType.I765;
        List<SubmissionState> statuses = List.of(SubmissionState.DRAFT, SubmissionState.ACCEPTED);
        List<Submission> response = repository.retrieveSubmissionsByFormType(formType, statuses);

        assertThat(response).isNotEmpty();

        ArgumentCaptor<QueryEnhancedRequest> captor = ArgumentCaptor.forClass(QueryEnhancedRequest.class);
        verify(table, times(1)).query(captor.capture());

        QueryEnhancedRequest request = captor.getValue();
        var filter = request.filterExpression();
        assertThat(filter.expression()).isEqualTo("formType = :formType AND #status in (:statuses)");
        assertThat(filter.expressionNames()).isEqualTo(Map.of("#status", "status"));
        assertThat(filter.expressionValues()).isEqualTo(Map.of(":formType", AttributeValue.fromS(formType.getType()), ":statuses", AttributeValue.fromS("DRAFT,ACCEPTED")));
    }
}
