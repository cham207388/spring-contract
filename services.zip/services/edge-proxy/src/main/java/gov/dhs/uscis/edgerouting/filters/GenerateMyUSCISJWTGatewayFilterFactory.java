package gov.dhs.uscis.edgerouting.filters;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.stereotype.Component;

@Component("GenerateMyUSCISJWT")//NOSONAR
public class GenerateMyUSCISJWTGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    Logger logger = LoggerFactory.getLogger(GenerateMyUSCISJWTGatewayFilterFactory.class);


    @Override
    public GatewayFilter apply(Object config) {
        return (exchange, chain) -> {
            logger.debug("Filtering request" );
            logger.debug(exchange.getRequest().getHeaders().toSingleValueMap().toString());
            logger.debug(exchange.getRequest().getCookies().toSingleValueMap().toString());
            return chain.filter(exchange);
        };
    }

}