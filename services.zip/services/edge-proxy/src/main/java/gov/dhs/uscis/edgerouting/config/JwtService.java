package gov.dhs.uscis.edgerouting.config;

import static gov.dhs.uscis.edgerouting.config.SecurityConfiguration.getUserIdFrom;
import static java.util.stream.Collectors.joining;
import static org.springframework.security.oauth2.jwt.JwtEncoderParameters.from;

import java.time.Duration;
import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.stereotype.Service;

import gov.dhs.uscis.intake.clients.ReactiveUserGroupServiceClient;
import reactor.core.publisher.Mono;

@Service
@ConditionalOnBean(value = JwtEncoder.class)
public class JwtService {

    private String jwtIssuer;
    private Duration jwtTimeout;
    private final JwtEncoder jwtEncoder;
    private ReactiveUserGroupServiceClient userGroupServiceClient;
    private Logger logger = LoggerFactory.getLogger(JwtService.class);

    public String getJwtIssuer() {
        return jwtIssuer;
    }

    public JwtService(@Value("${application.security.jwt.issuer}") String jwtIssuer,
            @Value("${application.security.jwt.timeout:30m}") Duration jwtTimeout,
            ReactiveUserGroupServiceClient userGroupServiceClient, 
            JwtEncoder jwtEncoder ) {
                this.jwtIssuer = jwtIssuer;
                this.jwtTimeout = jwtTimeout;
                this.userGroupServiceClient = userGroupServiceClient;
                this.jwtEncoder = jwtEncoder;
    }

    public Mono<Jwt> generateAccessToken(Authentication authentication) {
        Instant now = Instant.now();
        String scope = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(joining(" "));
        String userId = getUserIdFrom(authentication);
        return getUserGroupsByUserId(userId).map( f-> {
            JwtClaimsSet claims = JwtClaimsSet.builder()
                .issuer(jwtIssuer)
                .issuedAt(now)
                .expiresAt(now.plus(jwtTimeout))
                .subject(userId)
                .claim("name", authentication.getName())
                .claim("userGroupId", f) 
                .claim("scope", scope)
                .build();

                logger.info("Completed initializing session for: {}", userId );
                return jwtEncoder.encode(from(claims));
        });
        
    }

    private Mono<String> getUserGroupsByUserId(String userId) {
        return userGroupServiceClient.getRepGroupId(userId).map(f-> f.getUserGroupId());
    }

}
