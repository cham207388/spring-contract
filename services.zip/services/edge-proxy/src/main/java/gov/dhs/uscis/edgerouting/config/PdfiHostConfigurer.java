package gov.dhs.uscis.edgerouting.config;

import static org.springframework.http.HttpHeaders.COOKIE;

import java.net.MalformedURLException;
import java.net.URI;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.http.HttpStatus;

import gov.dhs.uscis.edgerouting.config.StaticRouteConfiguration.StripBasePathGatewayFilterFactory;
import gov.dhs.uscis.edgerouting.filters.CheckPathMyUscisIdFilter;
import gov.dhs.uscis.edgerouting.filters.SetBearerTokenFilter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class PdfiHostConfigurer {
    private static final String PDF_INTAKE = "/pdf-intake";
    private final String submissionServiceUrl;
    private final String paymentsServiceUrl;
    private final URI myAccountUri;

    public RouteLocator build(
            RouteLocatorBuilder builder,
            StripBasePathGatewayFilterFactory stripBasePath,
            CheckPathMyUscisIdFilter checkMyUscisId,
            SetBearerTokenFilter setBearer) {
        log.debug("Generating all routes.");
        var routes = builder.routes();
        // Path predicates must NOT include spring.webflux.base-path (/pdf-intake): Gateway prepends it
        // automatically (see Spring Cloud Gateway Path Route Predicate + spring.webflux.base-path).
        routes.route("myAccountRedirect", r -> r.path("/*/redirect/account")
                .filters(f -> {
                    try {
                        return f.redirect(HttpStatus.FOUND, myAccountUri.toURL());
                    } catch (MalformedURLException e) {
                        log.error(e.getMessage());
                        return f;
                    }
                }).uri(myAccountUri))
                .route("submissionManifest", r -> r.path("/api/intake/submissions/manifest/**")
                        .filters(f -> f
                                .rewritePath("/pdf-intake/api/intake/submissions/manifest/(?<suffix>.*)",
                                        "/pdf-intake/api/v1/submissions/manifest/${suffix}")
                                .removeRequestHeader(COOKIE)
                                .filter(stripBasePath.apply(PDF_INTAKE))
                                .filter(setBearer))
                        .uri(submissionServiceUrl))
                .route("submissionService", r -> r.path("/api/intake/*/submissions/**")
                        .filters(f -> f
                                .rewritePath("/pdf-intake/api/intake/(?<myUscisId>.+)/submissions(?<suffix>/?.*)",
                                        "/pdf-intake/api/v1/${myUscisId}/submissions${suffix}")
                                .removeRequestHeader(COOKIE)
                                .filter(stripBasePath.apply(PDF_INTAKE))
                                .filter(checkMyUscisId)
                                .filter(setBearer))
                        .uri(submissionServiceUrl))
                .route("myUscisDownload", r -> r.path("/download/*/submissions/**")
                        .filters(f -> f
                                .rewritePath("/pdf-intake/download/(?<myUscisId>.+)/submissions(?<suffix>/?.*)",
                                        "/pdf-intake/api/v1/${myUscisId}/submissions${suffix}")
                                .removeRequestHeader(COOKIE)
                                .filter(stripBasePath.apply(PDF_INTAKE))
                                .filter(checkMyUscisId)
                                .filter(setBearer))
                        .uri(submissionServiceUrl))
                .route("submissionForms", r -> r.path("/api/intake/forms/**")
                        .filters(f -> f
                                .rewritePath("/pdf-intake/api/intake/forms/(?<suffix>.*)",
                                        "/pdf-intake/api/v1/forms/${suffix}")
                                .removeRequestHeader(COOKIE)
                                .filter(stripBasePath.apply(PDF_INTAKE))
                                .filter(setBearer))
                        .uri(submissionServiceUrl))
                .route("pdfiMetadata", r -> r.path("/api/intake/metadata/**")
                        .filters(f -> f
                                .rewritePath("/pdf-intake/api/intake/metadata/(?<suffix>.*)",
                                        "/pdf-intake/api/v1/metadata/${suffix}")
                                .removeRequestHeader(COOKIE)
                                .filter(stripBasePath.apply(PDF_INTAKE))
                                .filter(setBearer))
                        .uri(submissionServiceUrl))
                .route("pdfiToggle", r -> r.path("/api/intake/toggle/**")
                        .filters(f -> f
                                .rewritePath("/pdf-intake/api/intake/toggle/(?<suffix>.*)",
                                        "/pdf-intake/api/v1/toggle/${suffix}")
                                .removeRequestHeader(COOKIE)
                                .filter(stripBasePath.apply(PDF_INTAKE))
                                .filter(setBearer))
                        .uri(submissionServiceUrl))
                .route("paymentsService", r -> r.path("/api/intake/payments/**")
                        .filters(f -> f.rewritePath("/pdf-intake/api/intake/payments/(?<suffix>.*)",
                                "/pdf-intake/api/v1/payments/${suffix}").filter(stripBasePath.apply(PDF_INTAKE)))
                        .uri(paymentsServiceUrl))
                .route("index",
                        r -> r.path("/**")
                                .uri("forward:/pdf-intake/index.html"));

        log.debug("Route building complete");
        return routes.build();
    }
}