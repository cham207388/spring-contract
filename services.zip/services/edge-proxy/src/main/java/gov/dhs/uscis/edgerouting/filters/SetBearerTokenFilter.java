package gov.dhs.uscis.edgerouting.filters;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

/**
 * Forwards the user's JWT token (cookie) to the resource service as a Bearer 
 * token header. Similar to SCG's TokenRelayGatewayFilterFactory.
 */
@Component
public class SetBearerTokenFilter implements GatewayFilter {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        return exchange.getPrincipal()
            .flatMap(p -> p instanceof JwtAuthenticationToken jwtAuthenticationToken ? Mono.just(jwtAuthenticationToken) : Mono.empty())
            .map(JwtAuthenticationToken::getToken)
            .map(jwt -> withBearerAuth(exchange, jwt))
            .defaultIfEmpty(exchange)
            .flatMap(chain::filter)
        ;
    }

    private ServerWebExchange withBearerAuth(ServerWebExchange exchange, Jwt jwt) {
		return exchange.mutate()
			.request(r -> r.headers(headers -> headers.setBearerAuth(jwt.getTokenValue())))
			.build();
	}    
}
