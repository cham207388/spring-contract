package gov.dhs.uscis.edgerouting.config;

import static java.util.Collections.emptyList;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpCookie;
import org.springframework.http.ResponseCookie;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.web.server.context.ServerSecurityContextRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(name = "application.security.enforce.oauth", havingValue = "true", matchIfMissing = true)
public class JwtCookieSecurityContextRepository implements ServerSecurityContextRepository {

    private final JwtService jwtService;
    private final ReactiveJwtDecoder jwtDecoder;
    public static final String JWT_COOKIE_NAME = "PDF-Intake-Access";

    /**
     * @param context Will be null during logout
     */
    @Override
    public Mono<Void> save(ServerWebExchange exchange, SecurityContext context) {
        return null == context ? Mono.empty()
                : jwtService.generateAccessToken(context.getAuthentication()).map(token -> {
                    var value = token.getTokenValue();
                    log.debug("save {} -> \n{}", context, value);
                    int expiration = getExpiration(context);
                    ResponseCookie cookie = ResponseCookie.from(JWT_COOKIE_NAME, value)
                            .maxAge(expiration)
                            // Changed to true for Sonar scan security issue
                            .path("/").httpOnly(true).sameSite("Lax").build();
                    exchange.getResponse().addCookie(cookie);
                    return Mono.empty();
                }).then();

    }

    private int getExpiration(SecurityContext context) {
        if (context == null) {
            /* expire immediately */
            return 0;
        } 
        return -1; /* default */
        
    }

    @Override
    public Mono<SecurityContext> load(ServerWebExchange swe) {
        return Mono.justOrEmpty(swe.getRequest().getCookies().getFirst(JWT_COOKIE_NAME))
                .map(HttpCookie::getValue)
                .flatMap(jwtDecoder::decode)
                .onErrorResume(ex -> {
                    log.warn(ex.getMessage());
                    return Mono.empty(); // pass thru to try a different method
                })
                .map(jwt -> new JwtAuthenticationToken(jwt, emptyList()))
                .map(SecurityContextImpl::new)
                .cast(SecurityContext.class)
                .doOnNext(sc -> log.debug("load {} -> \n{}", swe.getRequest().getPath(), sc));
    }
}
