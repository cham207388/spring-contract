package gov.dhs.uscis.edgerouting.filters;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dhs.uscis.edgerouting.config.SecurityConfiguration;
import reactor.core.publisher.Mono;

@RestController
public class SecuritySessionController {

    @GetMapping("/api/intake/users/myUscisId")
    public Mono<ResponseEntity<String>> getUserSubjectUUID() {
        return ReactiveSecurityContextHolder.getContext()
            .map(SecurityContext::getAuthentication)
            .map(SecurityConfiguration::getUserIdFrom)
            .map(ResponseEntity::ok)
        ;
    }

    @GetMapping( "/api/intake/users/session/details")
    public Mono<ResponseEntity<SessionDetails>> getMyUscisUserGroupId(){
        return ReactiveSecurityContextHolder.getContext()
            .map(SecurityContext::getAuthentication)
            .map(f -> new SessionDetails(SecurityConfiguration.getUserIdFrom(f), SecurityConfiguration.getUserGroupId(f)))
            .map(ResponseEntity::ok)
        ;
    }

    public record SessionDetails(String myUscisId, String userGroupId ){}
}
