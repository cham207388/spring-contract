package gov.dhs.uscis.edgerouting.config;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.NimbusJwtEncoder;
import org.springframework.security.oauth2.jwt.NimbusReactiveJwtDecoder;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.web.reactive.function.client.WebClient;

import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;

import gov.dhs.uscis.intake.clients.MockReactiveUserGroupServiceClient;
import gov.dhs.uscis.intake.clients.ReactiveUserGroupServiceClient;
import reactor.netty.http.client.HttpClient;

@Configuration
@ConditionalOnProperty(name = "application.security.enforce.oauth", havingValue = "true", matchIfMissing = true)
public class JwtConfig {
    
    // If OAuth is enabled, these must point to valid key files (classpath: or file: refs).
    @Value("${application.security.jwt.public-key}")
    private RSAPublicKey jwtPublicKey;
    @Value("${application.security.jwt.private-key}")
    private RSAPrivateKey jwtPrivateKey;
    private static final int TIMEOUT_SECONDS = 60;

    @Bean
    public ReactiveJwtDecoder jwtDecoder() {
        return NimbusReactiveJwtDecoder 
            .withPublicKey(jwtPublicKey)
            .build();
    }

    @Bean
    public JWKSet jwkSet() {
        RSAKey rsaKey = new RSAKey.Builder(jwtPublicKey)
            .privateKey(jwtPrivateKey)
            .keyID(UUID.randomUUID().toString())
            .build();
        return new JWKSet(rsaKey);
    }

    @Bean
    public JwtEncoder jwtEncoder(JWKSet jwkSet) {
        return new NimbusJwtEncoder(new ImmutableJWKSet<>(jwkSet));
    }

    @Bean
    @Profile("!test")
    public ReactiveUserGroupServiceClient userGroupServiceClient(@Value("${uscis.usergroupservice.url}") String url,
            @Value("${uscis.usergroupservice.username}") String username,
            @Value("${uscis.usergroupservice.password}") String password) {

        var webClient = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(HttpClient.create().responseTimeout(java.time.Duration.ofSeconds(TIMEOUT_SECONDS))))
                .defaultHeaders(headers -> headers.setBasicAuth(username, password))
                .baseUrl(url)
                .build();

        return new ReactiveUserGroupServiceClient(webClient);
    }

    @Bean
    @Profile("test")
    public ReactiveUserGroupServiceClient mockUserGroupServiceClient(){
        return new MockReactiveUserGroupServiceClient();
    }
    
}
