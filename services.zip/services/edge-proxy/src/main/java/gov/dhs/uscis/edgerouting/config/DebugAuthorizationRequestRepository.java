package gov.dhs.uscis.edgerouting.config;

import static gov.dhs.uscis.edgerouting.config.SecurityConfiguration.getStateParameter;

import java.util.Objects;
import java.util.Optional;

import org.springframework.security.oauth2.client.web.server.ServerAuthorizationRequestRepository;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
import org.springframework.web.server.ServerWebExchange;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Signal;

/**
 * Adds debug instrumentation to the authorization request repository to diagnose why stashed
 * requests are going missing in PROD and DEV environments.
 */
@Slf4j
@RequiredArgsConstructor
public class DebugAuthorizationRequestRepository
        implements ServerAuthorizationRequestRepository<OAuth2AuthorizationRequest> {
    private final ServerAuthorizationRequestRepository<OAuth2AuthorizationRequest> delegate;

    @Override
    public Mono<Void> saveAuthorizationRequest(OAuth2AuthorizationRequest req,
            ServerWebExchange exchange) {
        log.debug("saveAuthorizationRequest({}, {})", req, req.getState());
        return delegate.saveAuthorizationRequest(req, exchange);
    }

    @Override
    public Mono<OAuth2AuthorizationRequest> loadAuthorizationRequest(ServerWebExchange exchange) {
        return delegate.loadAuthorizationRequest(exchange)
            .doOnSuccess(req -> 
                log.debug("loadAuthorizationRequest({}) -> {}", getStateParameter(exchange), req)
        );
    }

    @Override
    public Mono<OAuth2AuthorizationRequest> removeAuthorizationRequest(ServerWebExchange exchange) {
        return delegate.removeAuthorizationRequest(exchange)
            .doOnEach(signal -> 
                log.debug("removeAuthorizationRequest({}) -> {}", getStateParameter(exchange), toDebugString(signal))
        );
    }

    private String toDebugString (Signal<?> signal) {
        if (signal.hasValue()) 
            return Objects.toString(signal.get());
        else if (signal.hasError())
            return Optional.ofNullable(signal.getThrowable()).map(Object::getClass).map(Class::getSimpleName).orElse("null");
        else 
            return ("(empty)");
    }
}