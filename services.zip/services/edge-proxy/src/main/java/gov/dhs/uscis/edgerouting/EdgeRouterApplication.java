package gov.dhs.uscis.edgerouting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.context.annotation.Import;
import gov.dhs.uscis.intake.configs.EligibilityCategoryConfig;
@SpringBootApplication
@Import(EligibilityCategoryConfig.class)
public class EdgeRouterApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdgeRouterApplication.class, args);
	}
	
}
