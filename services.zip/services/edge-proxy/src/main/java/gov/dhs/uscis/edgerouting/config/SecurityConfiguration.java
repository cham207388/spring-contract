package gov.dhs.uscis.edgerouting.config;

import static java.util.Objects.requireNonNull;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.security.oauth2.core.OAuth2TokenIntrospectionClaimNames.SUB;
import static org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers.pathMatchers;

import java.net.URI;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.lang.Nullable;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity.CsrfSpec;
import org.springframework.security.config.web.server.ServerHttpSecurity.FormLoginSpec;
import org.springframework.security.config.web.server.ServerHttpSecurity.HttpBasicSpec;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.client.oidc.web.server.logout.OidcClientInitiatedServerLogoutSuccessHandler;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.server.ServerAuthorizationRequestRepository;
import org.springframework.security.oauth2.client.web.server.WebSessionOAuth2ServerAuthorizationRequestRepository;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
import org.springframework.security.oauth2.core.endpoint.OAuth2ParameterNames;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.web.server.DefaultServerRedirectStrategy;
import org.springframework.security.web.server.DelegatingServerAuthenticationEntryPoint;
import org.springframework.security.web.server.DelegatingServerAuthenticationEntryPoint.DelegateEntry;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
import org.springframework.security.web.server.ServerRedirectStrategy;
import org.springframework.security.web.server.WebFilterExchange;
import org.springframework.security.web.server.authentication.HttpStatusServerEntryPoint;
import org.springframework.security.web.server.authentication.RedirectServerAuthenticationEntryPoint;
import org.springframework.security.web.server.authentication.RedirectServerAuthenticationFailureHandler;
import org.springframework.security.web.server.authentication.ServerAuthenticationFailureHandler;
import org.springframework.security.web.server.authentication.logout.HeaderWriterServerLogoutHandler;
import org.springframework.security.web.server.authentication.logout.ServerLogoutSuccessHandler;
import org.springframework.security.web.server.csrf.CookieServerCsrfTokenRepository;
import org.springframework.security.web.server.csrf.CsrfToken;
import org.springframework.security.web.server.csrf.XorServerCsrfTokenRequestAttributeHandler;
import org.springframework.security.web.server.header.ClearSiteDataServerHttpHeadersWriter;
import org.springframework.security.web.server.header.ClearSiteDataServerHttpHeadersWriter.Directive;
import org.springframework.util.MultiValueMap;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class SecurityConfiguration {

	@Value("${application.redirects.myAccount.uri}")
	private URI myAccountUri;
	@Value("${application.redirects.logout.uri}")
	protected URI logoutUri;
	@Value("${application.security.enforce.csrf:true}")
	private boolean enforceCsrf;
	@Value("${application.security.enforce.oauth:true}")
	private boolean enforceOauth;

	@Autowired //NOSONAR
	private ReactiveClientRegistrationRepository oidcRepository; //NOSONAR

	@Bean
	SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http,
			@Nullable JwtCookieSecurityContextRepository contextRepository) throws Exception {

		if (enforceCsrf) {
			http.csrf(csrf -> {
				CookieServerCsrfTokenRepository tokenRepository = CookieServerCsrfTokenRepository.withHttpOnlyFalse();
				tokenRepository.setCookiePath("/");
				XorServerCsrfTokenRequestAttributeHandler delegate = new XorServerCsrfTokenRequestAttributeHandler();
				csrf.csrfTokenRepository(tokenRepository).csrfTokenRequestHandler(delegate::handle);
			});
		} else {
			http.csrf(CsrfSpec::disable);
		}

		http.cors(Customizer.withDefaults())
			.httpBasic(HttpBasicSpec::disable)
			.formLogin(FormLoginSpec::disable)
			.logout(logout -> logout.logoutSuccessHandler(oidcLogoutSuccessHandler()));

        HeaderWriterServerLogoutHandler cookieClearingLogoutHandler = new HeaderWriterServerLogoutHandler(
                new ClearSiteDataServerHttpHeadersWriter(Directive.ALL));

		if (enforceOauth) {
			requireNonNull(contextRepository);
			http.authorizeExchange(exchange -> exchange.pathMatchers("/actuator/health").permitAll()
					.pathMatchers("/resource").hasAuthority("SCOPE_resource.read").anyExchange().authenticated())
					.oauth2Login(login -> login.authorizationRequestRepository(authorizationRequestRepository())
							.authorizationRedirectStrategy(logAuthRedirect())
							.authenticationFailureHandler(authFailureHandler()))
					.oauth2ResourceServer(server -> server.jwt(Customizer.withDefaults()))
					.securityContextRepository(contextRepository)
					.logout(logout -> logout.logoutHandler(cookieClearingLogoutHandler)
							.logoutSuccessHandler(oidcLogoutSuccessHandler()))
					.exceptionHandling(eh -> eh.authenticationEntryPoint(authenticationEntryPoint()));
		} else {
			log.warn("Configuring server with OAuth DISABLED");
			http.authorizeExchange(exchange -> exchange.anyExchange().permitAll()).anonymous(Customizer.withDefaults());
		}

		return http.build();
	}

	private ServerAuthenticationEntryPoint authenticationEntryPoint() {
		// If authorization is missing, API calls get a 401
		var entry = new DelegateEntry(pathMatchers("/api/**"), new HttpStatusServerEntryPoint(UNAUTHORIZED));
		var delegate = new DelegatingServerAuthenticationEntryPoint(entry);
		// All others go to OAuth
		delegate.setDefaultEntryPoint(new RedirectServerAuthenticationEntryPoint("/oauth2/authorization/pdfintake"));
		return delegate;
	}

	private ServerRedirectStrategy logAuthRedirect() {
		return new DefaultServerRedirectStrategy() {
			@Override
			public Mono<Void> sendRedirect(ServerWebExchange exchange, URI location) {
				return super.sendRedirect(exchange, location)
						.then(Mono.fromRunnable(() -> log.info("sent redirect: {}", location.toString())));
			}
		};
	}

	ServerAuthenticationFailureHandler authFailureHandler() {
		return new RedirectServerAuthenticationFailureHandler(myAccountUri.toString()) {
			@Override
			public Mono<Void> onAuthenticationFailure(WebFilterExchange webFilterExchange,
					AuthenticationException exception) {
				ServerWebExchange exchange = webFilterExchange.getExchange();
				ServerHttpRequest request = exchange.getRequest();
				log.warn("Authentication failure, uri = {}", request.getURI(), exception);

				return exchange.getSession().doOnSuccess(session -> logSessionRequestRepository(session, exchange))
						.then(super.onAuthenticationFailure(webFilterExchange, exception));
			}
		};
	}

	static @Nullable String getStateParameter(ServerWebExchange exchange) {
		MultiValueMap<String, String> params = exchange.getRequest().getQueryParams();
		return params.getFirst(OAuth2ParameterNames.STATE);
	}

	private Mono<Void> logSessionRequestRepository(WebSession session, ServerWebExchange exchange) {
		String state = getStateParameter(exchange);
		if (null != state) {
			// In the OAuth handshake
			Map<String, Object> attribs = session.getAttributes();
			log.debug("looking for {} but found {}", state, attribs.keySet());
			if (attribs.containsKey(state)) {
				log.debug("{} = {}", state, attribs.get(state));
			} else {
				log.debug("{} not found", state);
			}
		}

		return Mono.empty();
	}

	private ServerAuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository() {
		return new DebugAuthorizationRequestRepository(new WebSessionOAuth2ServerAuthorizationRequestRepository());
	}

	private ServerLogoutSuccessHandler oidcLogoutSuccessHandler() {
		var handler = new OidcClientInitiatedServerLogoutSuccessHandler(this.oidcRepository);
		handler.setPostLogoutRedirectUri(logoutUri.toString());
		handler.setLogoutSuccessUrl(logoutUri);
		return handler;
	}

	@Bean
	public WebFilter csrfCookieWebFilter() {
		return (exchange, chain) -> {
			Mono<CsrfToken> csrfToken = exchange.getAttributeOrDefault(CsrfToken.class.getName(), Mono.empty());
			return csrfToken.doOnSuccess(token -> {
				if (token != null) {
					exchange.getResponse().getHeaders().set(token.getHeaderName(), token.getToken());
				}
			}).then(chain.filter(exchange));
		};
	}

	public static String getUserIdFrom(Authentication authentication) {
        switch (authentication) {
            case JwtAuthenticationToken token -> {
                return token.getToken().getSubject();
            }
            case OAuth2AuthenticationToken token -> {
                return token.getPrincipal().getAttribute(SUB);
            }
            default -> {
                return authentication.getPrincipal().toString();
            }
        }
	}

	public static String getUserGroupId(Authentication authentication) {
		if (authentication instanceof JwtAuthenticationToken token) {
			return token.getToken().getClaimAsString("userGroupId");
		} 
		return "";
	}

	/**
	 * Temporary workaround for severe bug in Spring Framework. ETA for fix is
	 * v6.1.15 November 2024.
	 * https://github.com/spring-projects/spring-security/issues/15989#issuecomment-2442660753
	 * https://github.com/spring-projects/spring-framework/issues/33789
	 */
	@Bean
	@Order(Ordered.HIGHEST_PRECEDENCE)
	WebFilter writeableHeaders() {
		return (exchange, chain) -> {
			HttpHeaders writeableHeaders = HttpHeaders.writableHttpHeaders(exchange.getRequest().getHeaders()); //NOSONAR
			ServerHttpRequestDecorator writeableRequest = new ServerHttpRequestDecorator(exchange.getRequest()) {
				@Override
				public HttpHeaders getHeaders() {
					return writeableHeaders;
				}
			};
			ServerWebExchange writeableExchange = exchange.mutate().request(writeableRequest).build();
			return chain.filter(writeableExchange);
		};
	}

}