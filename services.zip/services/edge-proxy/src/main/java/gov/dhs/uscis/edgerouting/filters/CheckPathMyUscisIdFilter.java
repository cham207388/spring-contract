package gov.dhs.uscis.edgerouting.filters;

import static gov.dhs.uscis.edgerouting.config.SecurityConfiguration.getUserIdFrom;
import static org.springframework.http.HttpStatus.FORBIDDEN;

import java.util.Objects;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.server.PathContainer.Element;
import org.springframework.http.server.PathContainer.PathSegment;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class CheckPathMyUscisIdFilter implements GatewayFilter {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

        String pathUser = exchange.getRequest().getPath().pathWithinApplication()
            .elements().stream().filter(PathSegment.class::isInstance)
            .skip(2).map(Element::value).findFirst()
            .orElseThrow(() -> new IllegalStateException("Missing user ID in path, this shouldn't happen"));

        return exchange.<Authentication>getPrincipal().flatMap(authentication -> {
            String loggedInUser = getUserIdFrom(authentication);
            if (Objects.equals(loggedInUser, pathUser)) {
                log.debug("verified myUscisId {}", pathUser);
                return chain.filter(exchange);
            } else {
                String message = String.format("User in path (%s) does not match logged in", pathUser);
                log.warn(message + " ({})", loggedInUser);
                return abort(exchange, FORBIDDEN, message);
            }
        });
    }

    private Mono<Void> abort (ServerWebExchange exchange, HttpStatusCode statusCode, String message) {
        var response = exchange.getResponse();
        response.setStatusCode(statusCode);
        response.getHeaders().add("X-Message", message);
        return Mono.empty();
    }
}
