package gov.dhs.uscis.edgerouting.config;

import java.net.MalformedURLException;
import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileUrlResource;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;

import gov.dhs.uscis.edgerouting.filters.CheckPathMyUscisIdFilter;
import gov.dhs.uscis.edgerouting.filters.SetBearerTokenFilter;

@Configuration
public class StaticRouteConfiguration {
    private Logger logger = LoggerFactory.getLogger(StaticRouteConfiguration.class);

    @Bean
    public PdfiHostConfigurer hostConfiguration(
            @Value("${application.services.urls.submission}") String submissionServiceUrl,
            @Value("${application.services.urls.payments}") String paymentsServiceUrl,
            @Value("${application.redirects.myAccount.uri}") URI myAccountUri) {
        return new PdfiHostConfigurer(submissionServiceUrl, paymentsServiceUrl, myAccountUri);
    }

    @Bean
    public RouterFunction<?> staticResourceLocatorWildcard( //NOSONAR
            @Value("${application.static.assets.directory}") String directory) throws MalformedURLException {
        return RouterFunctions.resources("/**", new FileUrlResource(directory));
    }

    @Bean
    public org.springframework.cloud.gateway.route.RouteLocator customRouteLocator(
            PdfiHostConfigurer configuration,
            RouteLocatorBuilder builder, 
            StripBasePathGatewayFilterFactory stripBasePathGatewayFilterFactory,
            CheckPathMyUscisIdFilter checkPathMyUscisIdFilter,
            SetBearerTokenFilter setBearer
    ) {
        return configuration.build(builder, stripBasePathGatewayFilterFactory, checkPathMyUscisIdFilter, setBearer);
    }

    @Component
    public class StripBasePathGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

        @Value("${spring.webflux.base-path}")
        private String basePath;

        @Override
        public GatewayFilter apply(Object config) {
            return (exchange, chain) -> {
                ServerHttpRequest req = exchange.getRequest();
                String rawPath = req.getURI().getRawPath();
                String newPath = rawPath.replaceFirst(basePath, "");

                logger.debug(String.format("Path %s -> %s", rawPath, newPath));
                ServerHttpRequest request = req.mutate().path(newPath).contextPath(null).build();

                return chain.filter(exchange.mutate().request(request).build());
            };
        }

    }

}
