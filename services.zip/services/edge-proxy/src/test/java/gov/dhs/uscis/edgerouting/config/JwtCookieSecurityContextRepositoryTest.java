package gov.dhs.uscis.edgerouting.config;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.ResponseCookie;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

class JwtCookieSecurityContextRepositoryTest {

    @Test
    void shouldSaveCookieSession(){
        JwtService jwtService = mock(JwtService.class);
        ReactiveJwtDecoder jwtDecoder = mock(ReactiveJwtDecoder.class);
        var cookieRepository = new JwtCookieSecurityContextRepository(jwtService, jwtDecoder);

        SecurityContext securityContext = mock(SecurityContext.class);
        ServerWebExchange securityExchange = mock(ServerWebExchange.class);

        Authentication authentication = mock(Authentication.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);

        Jwt jwt = mock(Jwt.class);
        when(jwt.getTokenValue()).thenReturn("fakeString");
        ServerHttpResponse httpResponse = mock(ServerHttpResponse.class);
        when(securityExchange.getResponse()).thenReturn(httpResponse);
        Mono<Jwt> monoJwt = Mono.just(jwt);
        monoJwt.doOnSubscribe(f->System.out.println("somthing")); 

        when(jwtService.generateAccessToken(any())).thenAnswer(f -> monoJwt);
        cookieRepository.save(securityExchange, securityContext).block();

        
        ArgumentCaptor<ResponseCookie> cookieCaptor = ArgumentCaptor.forClass(ResponseCookie.class);
        verify(httpResponse).addCookie(cookieCaptor.capture());

        var cookie = cookieCaptor.getValue();
        Assertions.assertThat(cookie.getName()).isEqualTo("PDF-Intake-Access");
        Assertions.assertThat(cookie.getValue()).isNotBlank();
    }

    @Test
    void shouldReturnEmptyMono(){
        JwtService jwtService = mock(JwtService.class);
        ReactiveJwtDecoder jwtDecoder = mock(ReactiveJwtDecoder.class);
        var cookieRepository = new JwtCookieSecurityContextRepository(jwtService, jwtDecoder);

        var response = cookieRepository.save(mock(ServerWebExchange.class), null);
        Assertions.assertThat(response).isEqualTo(Mono.empty());
    }
}
