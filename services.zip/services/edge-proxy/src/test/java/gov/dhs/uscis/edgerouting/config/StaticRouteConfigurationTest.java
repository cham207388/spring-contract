package gov.dhs.uscis.edgerouting.config;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static gov.dhs.uscis.edgerouting.config.JwtCookieSecurityContextRepository.JWT_COOKIE_NAME;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

import gov.dhs.uscis.edgerouting.TestUtils;

@SpringBootTest(webEnvironment = RANDOM_PORT, properties = {
    "application.services.urls.submission=http://localhost:${wiremock.server.port}/",
    "application.security.enforce.oauth=true"
})
@AutoConfigureWireMock(port = 0)
@AutoConfigureWebTestClient
@ActiveProfiles("test")
class StaticRouteConfigurationTest {

    private static final String FAKE_BODY = "{ \"key\": \"value\" }";

    @Autowired
    private JwtService jwtService;
    @Autowired
    private WebTestClient webClient;

    private String myUscisId = UUID.randomUUID().toString();
    private Jwt jwt;

    @BeforeEach
    void before () {
        jwt = TestUtils.generateJwt(jwtService, myUscisId);
    }

    @Test
    void forms_shouldRoute ()  {
        stubFor(get(urlPathMatching("/api/v1/forms/.*"))
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .withBody(FAKE_BODY) ));

        webClient.get()
            .uri("/pdf-intake/api/intake/forms/I-765")
            .cookie(JWT_COOKIE_NAME, jwt.getTokenValue())
            .exchange()
            .expectStatus().isOk()
            .expectHeader().contentType(APPLICATION_JSON)
            .expectBody().json(FAKE_BODY)
        ;

        verify(getRequestedFor(urlEqualTo("/api/v1/forms/I-765"))
            .withHeader(AUTHORIZATION, matching("Bearer " + jwt.getTokenValue()))
        );
    }

    @Test
    void toggle_shouldRoute ()  {
        stubFor(get(urlPathMatching("/api/v1/toggle/.*"))
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .withBody(FAKE_BODY) ));

        webClient.get()
            .uri("/pdf-intake/api/intake/toggle/get-toggle/formType/I-129H1B/H1B_CAP")
            .cookie(JWT_COOKIE_NAME, jwt.getTokenValue())
            .exchange()
            .expectStatus().isOk()
            .expectHeader().contentType(APPLICATION_JSON)
            .expectBody().json(FAKE_BODY)
        ;

        verify(getRequestedFor(urlEqualTo("/api/v1/toggle/get-toggle/formType/I-129H1B/H1B_CAP"))
            .withHeader(AUTHORIZATION, matching("Bearer " + jwt.getTokenValue()))
        );
    }

    @Test
    void submissions_shouldCheckValidUserId ()  {
        stubFor(get(urlPathMatching("/api/v1/(.*)/submissions/drafts"))
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .withBody(FAKE_BODY) ));

        // When the user in session matches the user ID on the path
        // Then the response is OK
        webClient.get()
            .uri("/pdf-intake/api/intake/{myUscisId}/submissions/drafts", myUscisId)
            .cookie(JWT_COOKIE_NAME, jwt.getTokenValue())
            .exchange()
            .expectStatus().isOk()
            .expectHeader().contentType(APPLICATION_JSON)
            .expectBody().json(FAKE_BODY);

        verify(getRequestedFor(urlPathMatching("/api/v1/(.*)/submissions/drafts"))
            .withHeader(AUTHORIZATION, matching("Bearer " + jwt.getTokenValue()))
        );

        // When the user in session does not match the user on the path
        // Then the response is forbidden
        webClient.get()
            .uri("/pdf-intake/api/intake/{myUscisId}/submissions/drafts", UUID.randomUUID().toString())
            .cookie(JWT_COOKIE_NAME, jwt.getTokenValue())
            .exchange()
            .expectStatus().isForbidden();
    }

    @Test
    void submissions_shouldHandleParams ()  {
        stubFor(get(urlPathMatching("/api/v1/(.*)/submissions"))
            .withQueryParam("filters", equalTo("DRAFT"))
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withBody(FAKE_BODY)));

        webClient.get()
            .uri("/pdf-intake/api/intake/{myUscisId}/submissions?filters=DRAFT", myUscisId)
            .cookie(JWT_COOKIE_NAME, jwt.getTokenValue())
            .exchange()
            .expectStatus().isOk()
            .expectBody().json(FAKE_BODY);
    }
}
