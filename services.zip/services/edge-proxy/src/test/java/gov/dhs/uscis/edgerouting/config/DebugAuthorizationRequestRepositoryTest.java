package gov.dhs.uscis.edgerouting.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.lenient;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.oauth2.client.web.server.WebSessionOAuth2ServerAuthorizationRequestRepository;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
import org.springframework.security.oauth2.core.endpoint.OAuth2ParameterNames;
import org.springframework.util.MultiValueMapAdapter;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = RANDOM_PORT, properties = {
    "application.security.enforce.oauth=false",
    "logging.level.gov.dhs.uscis.edgerouting.config.DebugAuthorizationRequestRepository=DEBUG",
})
@ExtendWith({MockitoExtension.class, OutputCaptureExtension.class})
class DebugAuthorizationRequestRepositoryTest {

    @Mock
    WebSessionOAuth2ServerAuthorizationRequestRepository delegate;
    @Mock
    OAuth2AuthorizationRequest authRequest;
    @Mock
    ServerHttpRequest request;
    @Mock
    ServerWebExchange exchange;

    DebugAuthorizationRequestRepository instance;

    @BeforeEach
    void beforeEach () {
        lenient().when(authRequest.toString()).thenReturn("meaningless garbage");
        lenient().when(authRequest.getState()).thenReturn("statevalue");
        lenient().when(request.getQueryParams()).thenReturn(new MultiValueMapAdapter<String, String>(
            Map.of(OAuth2ParameterNames.STATE, List.of("statevalue"))));
        lenient().when(exchange.getRequest()).thenReturn(request);
        instance = new DebugAuthorizationRequestRepository(delegate);
    }

    @Test
    void loadAuthorizationRequest_shouldLog (CapturedOutput output) {
        given(delegate.loadAuthorizationRequest(any())).willReturn(Mono.just(authRequest));
        assertSame(authRequest, instance.loadAuthorizationRequest(exchange).block());
        assertThat(output.getOut()).contains("loadAuthorizationRequest(statevalue) -> ");
    }

    @Test
    void removeAuthorizationRequest_shouldLogObj (CapturedOutput output) {
        given(delegate.removeAuthorizationRequest(exchange)).willReturn(Mono.just(authRequest));
        assertSame(authRequest, instance.removeAuthorizationRequest(exchange).block());
        assertThat(output.getOut()).contains("removeAuthorizationRequest(statevalue) -> meaningless garbage");
    }

    @Test
    void removeAuthorizationRequest_shouldLogEmpty (CapturedOutput output) {
        given(delegate.removeAuthorizationRequest(exchange)).willReturn(Mono.empty());
        assertNull(instance.removeAuthorizationRequest(exchange).block());
        assertThat(output.getOut()).contains("removeAuthorizationRequest(statevalue) -> (empty)");
    }

    @Test
    void removeAuthorizationRequest_shouldLogException (CapturedOutput output) {
        given(delegate.removeAuthorizationRequest(exchange)).willReturn(Mono.error(new Exception("simulated")));
        assertThrows(Exception.class, () -> instance.removeAuthorizationRequest(exchange).block());
        assertThat(output.getOut()).contains("removeAuthorizationRequest(statevalue) -> Exception");
    }

    @Test
    void saveAuthorizationRequest_shouldLog (CapturedOutput output) {
        given(delegate.saveAuthorizationRequest(authRequest, exchange)).willReturn(Mono.empty());
        instance.saveAuthorizationRequest(authRequest, exchange).block();
        assertThat(output.getOut()).contains("saveAuthorizationRequest(meaningless garbage, statevalue)");
    }
}
