package gov.dhs.uscis.edgerouting;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.security.test.web.reactive.server.SecurityMockServerConfigurers.mockAuthentication;

import java.net.URI;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.web.reactive.server.WebTestClient;

/**
 * Groups together tests that require OAuth to be disabled when the application
 * context loads.
 */
@SpringBootTest(webEnvironment = RANDOM_PORT, properties = {
    "application.services.urls.submission=http://localhost:${wiremock.server.port}/",
    "application.security.enforce.oauth=false",
    "application.security.enforce.csrf=false",
})
@AutoConfigureWireMock(port = 0)
@AutoConfigureWebTestClient
class OAuthDisabledTest {
    
    private static final String FAKE_BODY = "{ \"key\": \"value\" }";

    @Autowired
    private WebTestClient webClient;
    @Value("${application.redirects.logout.uri}")
    private URI logoutUri;

    @Test
    void contextLoads () {}

    @Test
    void myUscisId_shouldHandleOauthDisabled () {

        Authentication anon = new AnonymousAuthenticationToken("key", "anonymousUser", 
            List.of(new SimpleGrantedAuthority("ROLE_ANONYMOUS")) );

        webClient
            .mutateWith(mockAuthentication(anon))
            .get().uri("/api/intake/users/myUscisId")
            .exchange()
            .expectStatus().isOk()
            .expectBody(String.class).isEqualTo(anon.getPrincipal().toString());
    }

    @Test
    void forms_shouldRoute () {
        stubFor(get(urlPathMatching("/api/v1/forms/.*"))
            .willReturn(aResponse()
                .withStatus(OK.value())
                .withHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .withBody(FAKE_BODY) ));

        webClient.get()
            .uri("/pdf-intake/api/intake/forms/I-765")
            .exchange()
            .expectStatus().isOk()
            .expectHeader().contentType(APPLICATION_JSON)
            .expectBody().json(FAKE_BODY)
        ;

        verify(getRequestedFor(urlEqualTo("/api/v1/forms/I-765"))
            .withoutHeader(AUTHORIZATION)
        );
    }

    @Test
    void forms_shouldHandle404 () {
        stubFor(get(urlPathMatching("/api/v1/forms/.*"))
            .willReturn(aResponse()
                .withStatus(NOT_FOUND.value())));

        webClient.get()
            .uri("/pdf-intake/api/intake/forms/G-765")
            .exchange()
            .expectStatus().isNotFound();

        verify(getRequestedFor(urlEqualTo("/api/v1/forms/G-765"))
            .withoutHeader(AUTHORIZATION)
        );
    }

    @Test
    void logout_shouldSucceed () {
        webClient
            .post().uri("/logout")
            .exchange()
            .expectStatus().isFound()
            .expectHeader().location(logoutUri.toString())
            .expectBody().isEmpty();
    }
}
