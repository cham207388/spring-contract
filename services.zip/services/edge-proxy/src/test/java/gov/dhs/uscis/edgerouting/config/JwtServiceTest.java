package gov.dhs.uscis.edgerouting.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Answers.CALLS_REAL_METHODS;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.security.oauth2.core.OAuth2TokenIntrospectionClaimNames.ISS;
import static org.springframework.security.oauth2.core.OAuth2TokenIntrospectionClaimNames.SCOPE;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import gov.dhs.uscis.edgerouting.TestUtils;
import gov.dhs.uscis.intake.clients.ReactiveUserGroupServiceClient;
import gov.dhs.uscis.intake.models.user_group.UserGroupRole;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = RANDOM_PORT, properties = {
        "application.security.enforce.oauth=true",
        "application.security.jwt.timeout=15m",
})
@ActiveProfiles("test")
class JwtServiceTest {

    @Autowired
    JwtEncoder jwtEncoder;
    @Autowired
    JwtService jwtService;
    @MockitoBean
    private ReactiveUserGroupServiceClient userGroupServiceClient;

    @Test
    void generateAccessToken_shouldSucceed() {

        try (
                MockedStatic<Instant> mockedInstant = mockStatic(Instant.class, CALLS_REAL_METHODS);
                MockedStatic<SecurityConfiguration> mockedSecurityConfig = mockStatic(SecurityConfiguration.class,
                        CALLS_REAL_METHODS);

        ) {
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(Mono.just(new UserGroupRole("myId", "SCOPE", "displayName", null, null, null, null, null)));
            Instant fixed = Instant.parse("2024-09-23T12:00:00Z");
            mockedInstant.when(Instant::now).thenReturn(fixed);

            String myUscisId = UUID.randomUUID().toString();
            List<GrantedAuthority> authorities = List.of(
                    new SimpleGrantedAuthority("ROLE_ONE"),
                    new SimpleGrantedAuthority("ROLE_TWO"));

            Jwt jwt = TestUtils.generateJwt(jwtService, myUscisId, authorities);

            // Verify the expected claims
            assertEquals(jwtService.getJwtIssuer(), jwt.getClaimAsString(ISS));
            assertEquals(fixed, jwt.getIssuedAt());
            assertEquals(fixed.plus(Duration.ofMinutes(15)), jwt.getExpiresAt());
            assertEquals(myUscisId, jwt.getSubject());
            assertEquals("example@example.com", jwt.getClaimAsString("name"));
            assertEquals("ROLE_ONE ROLE_TWO", jwt.getClaimAsString(SCOPE));
            assertEquals("myId", jwt.getClaimAsString("userGroupId"));

            mockedSecurityConfig.verify(
                    () -> SecurityConfiguration.getUserIdFrom(any(OAuth2AuthenticationToken.class)),
                    times(1));
        }
    }

    @Test
    void generateAccessTokenShouldHandleIfUserHasNoGroupId() {

        try (
                MockedStatic<Instant> mockedInstant = mockStatic(Instant.class, CALLS_REAL_METHODS);
                MockedStatic<SecurityConfiguration> mockedSecurityConfig = mockStatic(SecurityConfiguration.class,
                        CALLS_REAL_METHODS);

        ) {
            when(userGroupServiceClient.getRepGroupId(any()))
                    .thenReturn(Mono.just(UserGroupRole.emptyUserGroupRole()));
            Instant fixed = Instant.parse("2024-09-23T12:00:00Z");
            mockedInstant.when(Instant::now).thenReturn(fixed);

            String myUscisId = UUID.randomUUID().toString();
            List<GrantedAuthority> authorities = List.of(
                    new SimpleGrantedAuthority("ROLE_ONE"),
                    new SimpleGrantedAuthority("ROLE_TWO"));

            Jwt jwt = TestUtils.generateJwt(jwtService, myUscisId, authorities);

            // Verify the expected claims
            assertEquals(jwtService.getJwtIssuer(), jwt.getClaimAsString(ISS));
            assertEquals(fixed, jwt.getIssuedAt());
            assertEquals(fixed.plus(Duration.ofMinutes(15)), jwt.getExpiresAt());
            assertEquals(myUscisId, jwt.getSubject());
            assertEquals("example@example.com", jwt.getClaimAsString("name"));
            assertEquals("ROLE_ONE ROLE_TWO", jwt.getClaimAsString(SCOPE));
            assertEquals("", jwt.getClaimAsString("userGroupId"));

            mockedSecurityConfig.verify(
                    () -> SecurityConfiguration.getUserIdFrom(any(OAuth2AuthenticationToken.class)),
                    times(1));
        }
    }
}
