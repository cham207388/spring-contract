package gov.dhs.uscis.edgerouting.config;

import static gov.dhs.uscis.edgerouting.config.JwtCookieSecurityContextRepository.JWT_COOKIE_NAME;
import static java.util.Collections.emptyMap;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.http.HttpHeaders.LOCATION;
import static org.springframework.security.test.web.reactive.server.SecurityMockServerConfigurers.csrf;
import static org.springframework.web.reactive.function.BodyInserters.fromFormData;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
import org.springframework.security.oauth2.core.endpoint.OAuth2ParameterNames;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.web.server.WebFilterExchange;
import org.springframework.security.web.server.authentication.ServerAuthenticationFailureHandler;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.MultiValueMapAdapter;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebSession;

import gov.dhs.uscis.edgerouting.TestUtils;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = RANDOM_PORT, properties = {
    "application.security.enforce.oauth=true"
})
@AutoConfigureWebTestClient(timeout = "36000")
@ActiveProfiles("test")
@ExtendWith(OutputCaptureExtension.class)
class SecurityConfigurationTest {
    
    @Value("${spring.security.oauth2.client.provider.accounts.authorization-uri}")
    private String authorizationUri;
    @Value("${spring.security.oauth2.client.registration.pdfintake.redirect-uri}")
    private String redirectUri;

    private static final String EXAMPLE_URI = "http://example.com";

    @Autowired
    private SecurityConfiguration config;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private WebTestClient rest;

    @Mock
    ServerHttpRequest request;
    @Mock 
    WebSession session;
    @Mock
    ServerHttpResponse response;
    @Mock
    ServerWebExchange swe;
    @Mock
    WebFilterExchange wfe;


    private String myUscisId = UUID.randomUUID().toString();
    private Jwt jwt;

    @BeforeEach
    void before () {
        jwt = TestUtils.generateJwt(jwtService, myUscisId);
    }

    @Test
    void csrf_shouldRejectInvalid () {
        rest
            .post().uri("/logout")
            .cookie(JWT_COOKIE_NAME, jwt.getTokenValue())
            .body(fromFormData("_csrf", "invalid"))
            .exchange()
            .expectStatus().isForbidden();
    }

    @Test
    void logout_shouldSucceed () {
        rest
            .mutateWith(csrf())
            .post().uri("/logout")
            .cookie(JWT_COOKIE_NAME, jwt.getTokenValue())
            .cookie("JSESSIONID", LOCATION)
            .cookie("XSRF-TOKEN", LOCATION)
            .exchange()
            .expectStatus().isFound()
            .expectCookie().doesNotExist(JWT_COOKIE_NAME)
            .expectHeader().location(config.logoutUri.toString())
            .expectBody().isEmpty();
    }

    @Test
    void getUserIdFrom_JWT () {
        JwtAuthenticationToken token = new JwtAuthenticationToken(jwt);
        String result = SecurityConfiguration.getUserIdFrom(token);
        assertEquals(myUscisId, result);
    }

    @Test
    void getUserIdFrom_Anon () {
        Authentication anon = new AnonymousAuthenticationToken("key", "anonymousUser", 
            List.of(new SimpleGrantedAuthority("ROLE_ANONYMOUS")) );
        String result = SecurityConfiguration.getUserIdFrom(anon);
        assertEquals(anon.getPrincipal().toString(), result);
    }

    @Test
    void authorize_shouldRedirect (CapturedOutput output) {
        rest
            .get().uri("/oauth2/authorization/pdfintake")
            .exchange()
            .expectStatus().isFound()
            .expectHeader().valueMatches(LOCATION, authorizationUri + "\\?.*");
        assertThat(output.getOut()).contains("sent redirect: " + authorizationUri);
        assertThat(output.getOut()).contains("redirect_uri=" + redirectUri);
    }

    @Test
    void authFailureHandler_shouldLog (CapturedOutput output) {
        setupMockExchange();

        given(request.getQueryParams()).willReturn(new MultiValueMapAdapter<String, String>(
            Map.of(OAuth2ParameterNames.STATE, List.of("goodstateparam"))));
        given(session.getAttributes()).willReturn(Map.of("goodstateparam", Mockito.mock(OAuth2AuthorizationRequest.class)));

        ServerAuthenticationFailureHandler handler = config.authFailureHandler();
        handler.onAuthenticationFailure(wfe, new OAuth2AuthenticationException("simulated")).block();

        assertThat(output.getOut()).contains("Authentication failure, uri = " + EXAMPLE_URI);
        assertThat(output.getOut()).contains("looking for goodstateparam but found [goodstateparam]");
        assertThat(output.getOut()).contains("goodstateparam = ");
    }

    @Test
    void authFailureHandler_shouldLogMissingState (CapturedOutput output) {
        setupMockExchange();

        given(request.getQueryParams()).willReturn(new MultiValueMapAdapter<String, String>(
            Map.of(OAuth2ParameterNames.STATE, List.of("badstateparam"))));
        given(session.getAttributes()).willReturn(emptyMap());

        ServerAuthenticationFailureHandler handler = config.authFailureHandler();
        handler.onAuthenticationFailure(wfe, new OAuth2AuthenticationException("simulated")).block();
        assertThat(output.getOut()).contains("looking for badstateparam but found []");
        assertThat(output.getOut()).contains("badstateparam not found");
    }

    @Test
    void authFailure_forApi_should401 () {
        rest.get().uri("/api/whatever")
            .cookie(JWT_COOKIE_NAME, "meaningless and/or expired garbage")
            .exchange()
            .expectStatus().isUnauthorized();
    }

    @Test
    void authFailure_forContent_shouldRedirect () {
        rest.get().uri("index.html")
            .cookie(JWT_COOKIE_NAME, "meaningless and/or expired garbage")
            .exchange()
            .expectStatus().isFound()
            .expectHeader().location("/oauth2/authorization/pdfintake");
    }

    private void setupMockExchange() {
        given(request.getURI()).willReturn(URI.create(EXAMPLE_URI));
        given(response.getHeaders()).willReturn((new HttpHeaders()));
        given(swe.getRequest()).willReturn(request);
        given(swe.getSession()).willReturn(Mono.just(session));
        given(swe.getResponse()).willReturn(response);
        given(wfe.getExchange()).willReturn(swe);
    }
    
}
