package gov.dhs.uscis.edgerouting.filters;

import static gov.dhs.uscis.edgerouting.config.JwtCookieSecurityContextRepository.JWT_COOKIE_NAME;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

import gov.dhs.uscis.edgerouting.TestUtils;
import gov.dhs.uscis.edgerouting.config.JwtService;

@SpringBootTest(webEnvironment = RANDOM_PORT, properties = {
        "application.security.enforce.oauth=true"
})
@AutoConfigureWebTestClient
@ActiveProfiles("test")
class SecuritySessionControllerTest {

    @Autowired
    private JwtService jwtService;
    @Autowired
    private WebTestClient webClient;

    private String myUscisId = UUID.randomUUID().toString();
    private Jwt jwt;

    @BeforeEach
    void before() {
        jwt = TestUtils.generateJwt(jwtService, myUscisId);
    }

    @Test
    void myUscisId_shouldReturnOK() {

        webClient.get()
                .uri("/api/intake/users/session/details")
                .cookie(JWT_COOKIE_NAME, jwt.getTokenValue())
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json")
                .expectBody()
                .jsonPath("$.myUscisId").isEqualTo(myUscisId)
                .jsonPath("$.userGroupId").isEqualTo("fakeGroupId");
    }
}
