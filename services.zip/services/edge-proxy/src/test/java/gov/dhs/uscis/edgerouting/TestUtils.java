package gov.dhs.uscis.edgerouting;

import static java.util.Collections.emptyList;
import static org.springframework.security.oauth2.core.OAuth2TokenIntrospectionClaimNames.SUB;
import static org.springframework.security.oauth2.core.OAuth2TokenIntrospectionClaimNames.USERNAME;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.oauth2.jwt.Jwt;

import gov.dhs.uscis.edgerouting.config.JwtService;

public class TestUtils {
    
    public static Jwt generateJwt (JwtService jwtService, String myUscisId) {
        return generateJwt(jwtService, myUscisId, emptyList());
    }

    public static Jwt generateJwt (JwtService jwtService, String myUscisId, Collection<GrantedAuthority> authorities) {
        OAuth2User user = new DefaultOAuth2User(authorities, 
            Map.of(
                SUB, myUscisId,
                USERNAME, "example@example.com"), USERNAME);
        Authentication auth = new OAuth2AuthenticationToken(user, user.getAuthorities(), UUID.randomUUID().toString());
        return jwtService.generateAccessToken(auth).block();
    }
}
