import com.bmuschko.gradle.docker.tasks.image.DockerBuildImage

plugins {
    java
    alias(libs.plugins.spring.boot)
    // Shouldn't need this anymore, but tests break if removed
    alias(libs.plugins.spring.dependency.management)
    jacoco
    alias(libs.plugins.asciidoctor.jvm.convert)
    alias(libs.plugins.swagger.core)
    alias(libs.plugins.sonarqube)
    alias(libs.plugins.docker)
    alias(libs.plugins.undercouch)       // Verify if we need this
    alias(libs.plugins.pdfi.java.conventions)
}

group = "gov.dhs.uscis"
version = "0.0.1-SNAPSHOT"

configurations {
    create("asciidoctorExt")
    compileOnly {
        extendsFrom(configurations.annotationProcessor.get())
    }
}

val commitTag: String by extra(System.getenv("COMMIT_HASH") ?: "latest")
val snippetsDir by extra(file("build/generated-snippets"))

docker {
    springBootApplication {
        maintainer.set("csai-dev-team")
        baseImage.set("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/csai-java-base-image:21.0.8_11-jre-alpine")
        images.set(listOf("nexus-nonprod-gss.uscis.dhs.gov:8126/myuscis-csai-docker/edge-proxy:$commitTag"))
        mainClassName.set("gov.dhs.uscis.edgerouting.EdgeRouterApplication")
        jvmArgs.set(listOf("-XX:+UseContainerSupport", "-XX:MaxRAMPercentage=90", "-javaagent:/opt/newrelic.jar"))
    }
}

tasks.named<DockerBuildImage>("dockerBuildImage") {
    platform.set("linux/amd64")
    pull.set(true)
}

tasks.dockerCreateDockerfile {
    instruction("COPY --chown=apps:apps ./resources/newrelic.yaml /opt/newrelic.yml")
    instruction("COPY web web/")
    instruction("ENV APPLICATION_STATIC_ASSETS_DIRECTORY=/app/web/")
    instruction("USER apps")
}

extra["tomcat.version"] = libs.versions.tomcatEmbedCore.get()

dependencies {
    implementation(enforcedPlatform(libs.log4j.bom))

    val springBootDependencyBom = platform(libs.spring.boot.dependencies)
    val springCloudDependencyBom = platform(libs.spring.cloud.dependencies)

    implementation(springBootDependencyBom)
    implementation(springCloudDependencyBom)
    testImplementation(springBootDependencyBom)
    testImplementation(springCloudDependencyBom)
    compileOnly(springBootDependencyBom)
    testCompileOnly(springBootDependencyBom)
    annotationProcessor(springBootDependencyBom)
    testAnnotationProcessor(springBootDependencyBom)

    constraints{
        implementation(libs.minidev.json.smart) {
            because("override from 2.5.1 for CVE-2024-57699")
        }
        implementation(libs.spring.core) {
            because("CVE-2025-41249")
        }
        implementation(libs.commons.lang3) {
            because("UNKNOWN")
        }
        implementation(libs.spring.web) {
            because("CVE-2025-41234")
        }
        implementation(libs.spring.security.oauth2.jose) {
            because("override from 6.4.2 CVE-2025-53864 12/26/2025")
        }
    }

    implementation(libs.spring.cloud.starter.gateway.server.webflux)
    implementation(libs.spring.boot.starter.actuator)
    implementation(libs.spring.boot.starter.webflux)
    implementation(libs.spring.boot.starter.oauth2.client)
    implementation(libs.spring.boot.starter.oauth2.resource.server)
    implementation(libs.logback.encoder)
    implementation(libs.spring.security.web)
    implementation(libs.fasterxml.jackson.core)
    implementation(libs.netty.codec.http2)
    implementation(libs.netty.codec.http)
    testImplementation(libs.spring.boot.starter.test)
    testImplementation(libs.spring.cloud.starter.stub.runner)
    testImplementation(libs.spring.security.test)
    testImplementation(libs.reactor.test)

    compileOnly(libs.lombok)
    testCompileOnly(libs.lombok)
    annotationProcessor(libs.lombok)
    testAnnotationProcessor(libs.lombok)
}

jacoco {
    toolVersion = libs.versions.jacoco.get()
    reportsDirectory.set(layout.buildDirectory.dir("reports/jacoco"))
}

tasks.jacocoTestReport {
    reports {
        xml.required.set(true)
        html.required.set(true)
    }
}

tasks.jacocoTestCoverageVerification {
    dependsOn(tasks.test)

    violationRules {
        rule {
            limit {
                minimum = 0.5.toBigDecimal()
            }
        }
    }
}

tasks.check {
    dependsOn(tasks.jacocoTestCoverageVerification)
}

tasks.test {
    outputs.dir(snippetsDir)
    useJUnitPlatform()
    finalizedBy(tasks.jacocoTestReport)
    testLogging {
        events("PASSED", "SKIPPED", "FAILED", "STANDARD_OUT", "STANDARD_ERROR")
    }
}

tasks.asciidoctor {
    inputs.dir(snippetsDir)
    configurations("asciidoctorExt")
    dependsOn(tasks.test)
}

val copyWebFiles = tasks.register<Copy>("copyWebFiles") {
    println("${projectDir}/web")
    from("${projectDir}/web")
    into(layout.buildDirectory.dir("docker/web"))
    include("**")
}

tasks.assemble {
    dependsOn(copyWebFiles)
}

copyWebFiles.configure {
    dependsOn(tasks.named("dockerCreateDockerfile"))
}

tasks.build {
    dependsOn("dockerBuildImage")
}

tasks.named("dockerBuildImage") {
    dependsOn(copyWebFiles)
}

tasks.named("sonar") {
    dependsOn("jacocoTestCoverageVerification")
}

tasks.register("printEnvVariables") {
    doLast {
        println("JAVA_OPTS: ${System.getenv("JAVA_OPTS")}")
    }
}