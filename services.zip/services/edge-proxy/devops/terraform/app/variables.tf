variable "fullnameOverride" { default = "changeme" }
variable "nameOverride" { default = "changeme" }
variable "base_url" {}
variable "oauth_url" {}
variable "submission_service_url" { default = "changeme" }
variable "payment_service_url" { default = "changeme" }
variable "values_environment" {}
variable "kubernetes_edgeproxy_namespace" { default = "changeme" }
variable "helm_chart_version" { default = "changeme" }
variable "chart_repository" { default = "changeme" }
variable "image_tag" { default = "changeme" }
variable "chart_path_or_name" { default = "digital-intake-edge" }
variable "helm_history_max" { default = 3 }
variable "ap_oidc_client_id" { }
variable "ap_oidc_client_secret" { }
variable "myuscis_encoded_key" { }
variable "myuscis_encoded_cert" { }
variable "jwt_secret_name" { }
variable "jwt_public_key" { }
variable "jwt_private_key" { }
variable "jwt_timeout" { default = "30m" }
variable "tags" {}
variable "eks_edgeproxy_domain" {}
variable "helm_values_path" {}
variable "eks_context" {}
variable "new_relic_license_key" {}
variable "app_version" { default = "changeme"}
variable "usergroupservice_username" {}
variable "usergroupservice_password" {}