provider "helm" {
  kubernetes {
    config_path = "~/.kube/config"
    config_context = var.eks_context
  }
}

provider "kubernetes" {
  config_path    = "~/.kube/config"
  config_context =  var.eks_context
}


data "aws_caller_identity" "current" {}

# variable "core_base_urls" {
#   type = map(string)
#   default = {
#     dev = "https://lab-my.uscis.dhs.gov"
#     sint = "https://qa-my.uscis.dhs.gov"
#     preprod = "https://preprod-my.uscis.dhs.gov" 
#     prod = "https://my.uscis.gov"
#   }
# }

variable "core_oauth_urls" {
  type = map(string)
  default = {
    dev = "https://myaccount-dt.uscis.dhs.gov"
    sint = "https://myaccount-dt.uscis.dhs.gov"
    preprod = "https://myaccount-preprod.uscis.dhs.gov" 
    prod = "https://myaccount.uscis.gov"
  }
}
// TODO update this if you want to disable authentication in a specific environment
variable "core_oauth_enforce" {
  type = map(bool)
  default = {
    dev = false
    sint = true
    preprod = true
    prod = true
    perf = false
  }
}

resource "helm_release" "pdfi-edge" {
  namespace  = var.kubernetes_edgeproxy_namespace
  name       = var.fullnameOverride
  repository = var.chart_repository
  chart      = var.chart_path_or_name
  version    = var.helm_chart_version
  max_history = var.helm_history_max
  atomic = true
  timeout = 1200
  
  values = [
    file(var.helm_values_path)
  ]

  set {
    name  = "fullnameOverride"
    value = var.fullnameOverride
  }
  set {
    name  = "nameOverride"
    value = var.fullnameOverride
  }
  set {
    name  = "image.tag"
    value = var.image_tag
  }
  set {
    name  = "submission_service_url"
    value = var.submission_service_url
  }
  set {
    name  = "payment_service_url"
    value = var.payment_service_url
  }

  set {
    name  = "oauth_url"
    value = lookup(var.core_oauth_urls, terraform.workspace, var.oauth_url)
  }
  
  set {
    name  = "ap_oidc_client_id"
    value = var.ap_oidc_client_id
  }
  set {
    name  = "ap_oidc_client_secret"
    value = var.ap_oidc_client_secret
  }
  set {
    name  = "enforce_oauth"
    value = lookup(var.core_oauth_enforce, terraform.workspace, false)
  }
  set {
    name  = "myuscis_encoded_key"
    value = var.myuscis_encoded_key
  }
  set {
    name  = "myuscis_encoded_cert"
    value = var.myuscis_encoded_cert
  }
  set {
    name  = "myuscis_secret_name"
    value = "myuscis-tls-${terraform.workspace}"
  }
  set {
    name = "jwt_secret_name"
    value = "jwt-secret-${terraform.workspace}"
  }
  set {
    name = "jwt_public_key"
    value = var.jwt_public_key
  }
  set {
    name = "jwt_private_key"
    value = var.jwt_private_key
  }
  set {
    name = "jwt_timeout"
    value = var.jwt_timeout
  }

  set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com\\/role-arn"
    value = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/pdfi-edge-role-${terraform.workspace}"
  }

  set {
    name  = "ingress.hosts[0].host"
    value = "${var.fullnameOverride}.${var.eks_edgeproxy_domain},ingress.hosts[0].paths[0].path=/,ingress.hosts[0].paths[0].pathType=ImplementationSpecific"
  }
  set {
    name  = "new_relic_license_key"
    value = var.new_relic_license_key
  }
  set {
    name  = "app_version"
    value = var.app_version
  }
  set {
    name  = "usergroupservice_username"
    value = var.usergroupservice_username
  }

  set {
    name  = "usergroupservice_password"
    value = var.usergroupservice_password
  }
  
  recreate_pods = true
}

data "kubernetes_service" "ingress_svc" {
  metadata {
    name = "csai-intake-edge-${terraform.workspace}"
    namespace = var.kubernetes_edgeproxy_namespace
  }
}

output "url"{
  value = "${var.fullnameOverride}.${var.eks_edgeproxy_domain}"
}
# output "url" {
#   value = data.kubernetes_service.ingress_svc.status.0.load_balancer.0.ingress[0].hostname
# }
