import { ACCORDION_HEADERS, AccordionHeaders } from "../types/Accordion";
import React, { ReactNode, createContext, useEffect, useState } from "react";
import { useSteps } from "../hooks/useSteps";
import { useMediaQuery, useTheme } from "@mui/material";

type AccordionState = {
  activeAccordionHeader: AccordionHeaders | null;
  setActiveAccordionHeader: React.Dispatch<
    React.SetStateAction<AccordionHeaders | null>
  >;
  isMobile: boolean;
  isMobileAccordionExpanded: boolean;
  setIsMobileAccordionExpanded: React.Dispatch<React.SetStateAction<boolean>>;
};
export const AccordionContext = createContext<AccordionState>({
  activeAccordionHeader: ACCORDION_HEADERS.GETTING_STARTED,
  setActiveAccordionHeader: () => {},
  isMobile: false,
  isMobileAccordionExpanded: false,
  setIsMobileAccordionExpanded: () => {},
});

export const AccordionProvider = ({ children }: { children: ReactNode }) => {
  const [activeAccordionHeader, setActiveAccordionHeader] =
    useState<AccordionHeaders | null>(ACCORDION_HEADERS.GETTING_STARTED);
  const [isMobileAccordionExpanded, setIsMobileAccordionExpanded] =
    useState(false);
  const { currentStep } = useSteps();

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"), {
    defaultMatches: true,
  });

  useEffect(() => {
    setActiveAccordionHeader(currentStep.header);
  }, [currentStep]);

  return (
    <AccordionContext.Provider
      value={{
        activeAccordionHeader,
        setActiveAccordionHeader,
        isMobileAccordionExpanded,
        setIsMobileAccordionExpanded,
        isMobile,
      }}
    >
      {children}
    </AccordionContext.Provider>
  );
};
