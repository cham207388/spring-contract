import { ReactNode, createContext, useState } from "react";

type DocumentUploadState = {
  loading: boolean;
  setLoading: (loading: boolean) => void;
  loadingForPayment: boolean;
  setLoadingForPayment: (loading: boolean) => void;
  submissionId: string;
  setSubmissionId: (submissionId: string) => void;
  isNextClicked: boolean;
  setIsNextClicked: (isNextClicked: boolean) => void;
};

export const DocumentUploadContext = createContext<DocumentUploadState>({
  loading: false,
  setLoading: () => {},
  loadingForPayment: false,
  setLoadingForPayment: () => {},
  submissionId: "",
  setSubmissionId: () => {},
  isNextClicked: false,
  setIsNextClicked: () => {},
});

export const DocumentUploadProvider = ({
  children,
}: {
  children: ReactNode;
}) => {
  const [loading, setLoading] = useState(false);
  const [loadingForPayment, setLoadingForPayment] = useState(false);
  const [isNextClicked, setIsNextClicked] = useState(false);
  const [submissionId, setSubmissionId] = useState<string>("");

  return (
    <DocumentUploadContext.Provider
      value={{
        isNextClicked,
        setIsNextClicked,
        loading,
        setLoading,
        loadingForPayment,
        setLoadingForPayment,
        submissionId,
        setSubmissionId,
      }}
    >
      {children}
    </DocumentUploadContext.Provider>
  );
};
