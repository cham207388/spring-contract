import useInterval from "./useInterval";
import { useContext } from "react";
import { DocumentUploadContext } from "../contexts/DocumentUploadContext";
import { useAlertSnackbar } from "./useAlertSnackbar";
import { SubmissionService } from "../api/SubmissionService";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../redux/store";
import {
  FINAL_TRANSMISSION_STATUS_ENUM,
  FinalTransmissionStatus,
} from "../types/Submission";
import {
  setIsPollingForFinalSubmissionStatus,
  setIsSubmissionSubmitted,
} from "../redux/submissionSlice";
import { useNavigate } from "react-router-dom";

const SUBMISSION_FAILURE_MESSAGE =
  "Draft was not able to be submitted for processing. Please try again later";
export function useFinalSubmit(isPaymentSummaryPage: boolean = false) {
  //TODO: look into consolidating polling bool and loading bool
  const POLLING_DELAY = 5000;
  const { setLoading } = useContext(DocumentUploadContext);
  const { addAlert } = useAlertSnackbar();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { submissionId, isPollingForFinalSubmissionStatus, formType } =
    useSelector((state: RootState) => state.submission);
  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);

  useInterval(
    async () => {
      try {
        const response: FinalTransmissionStatus =
          await SubmissionService.pollForFinalTransmissionStatus(
            myUscisId,
            submissionId,
            userGroupId,
          );

        if (response.status === FINAL_TRANSMISSION_STATUS_ENUM.SUCCESS) {
          dispatch(setIsSubmissionSubmitted(true));
          dispatch(setIsPollingForFinalSubmissionStatus(false));
          setLoading(false);
          navigate(`/pdf-intake/${formType}/success`);
        } else if (response.status === FINAL_TRANSMISSION_STATUS_ENUM.FAILURE) {
          addAlert(SUBMISSION_FAILURE_MESSAGE);
          dispatch(setIsPollingForFinalSubmissionStatus(false));
          setLoading(false);
          console.error(
            "Final transmission failed with message: ",
            response.message,
          );
        }
      } catch (exception) {
        addAlert(
          "Something went wrong when polling for final submission status",
        );
        dispatch(setIsPollingForFinalSubmissionStatus(false));
      }
    },
    isPollingForFinalSubmissionStatus ? POLLING_DELAY : null,
  );

  const sendFinalSubmission = () => {
    setLoading(true);
    SubmissionService.submitFinalSubmission(myUscisId, submissionId, userGroupId)
      .then((response) => {
        dispatch(setIsPollingForFinalSubmissionStatus(true));
      })
      .catch((error) => {
        addAlert(SUBMISSION_FAILURE_MESSAGE);
        setIsSubmissionSubmitted(false);
        setLoading(false);
        if (isPaymentSummaryPage)
          navigate(`/pdf-intake/${formType}/${submissionId}`);
      });
  };
  return { sendFinalSubmission };
}

export default useFinalSubmit;
