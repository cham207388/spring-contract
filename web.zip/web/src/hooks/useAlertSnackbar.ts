import { useDispatch } from "react-redux";
import { pushAlert } from "../redux/alertSnackbarSlice";
import { AppDispatch } from "../redux/store";
import { AlertColor } from "@mui/material";

export function useAlertSnackbar(): {
  addAlert: (messageToDisplay: string, severity?: AlertColor) => void;
} {
  const dispatch = useDispatch<AppDispatch>();

  const addAlert = (message: string, severity: AlertColor = "error") => {
    dispatch(pushAlert({ message, severity }));
  };

  return { addAlert };
}
