import { useMemo } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../redux/store";
import { useSubmissionIsComplete } from "./useSubmissionIsComplete";
import { useEligibilityCategory } from "./useEligibilityCategory";
import { SubmissionEvidence } from "../types/Submission";
import { ACCORDION_HEADERS, AccordionHeaders } from "../types/Accordion";
import { useLocation } from "react-router-dom";
import {
  AccountType,
  AccountTypes,
  selectIsRepresentative,
} from "../redux/userSlice";
import { Paths } from "../router/Paths";
import { FormTypes } from "../types/FormMetaData";
import { EvidenceGroup } from "../types/FormMetaData";


interface Headers {
  label: AccordionHeaders;
  shouldRender?: boolean;
}

export interface Step {
  id: string;
  name: string;
  header: AccordionHeaders;
  disabled?: boolean;
  showInNav?: boolean;
}

export const Steps: Record<string, Step> = {
  BasisOfEligibility: {
    id: Paths.selectEligibility,
    name: "Basis of Eligibility",
    header: ACCORDION_HEADERS.GETTING_STARTED,
    showInNav: true,
  },
  EligibilityCategory: {
    id: Paths.selectEligibility,
    name: "Eligibility Category",
    header: ACCORDION_HEADERS.GETTING_STARTED,
    showInNav: true,
  },
  ConcurrentEligibilityCategory: {
    id: Paths.selectEligibility,
    name: `Eligibility Category`,
    header: ACCORDION_HEADERS.GETTING_STARTED,
    showInNav: true,
  },
  AboutThisPetition: {
    id: Paths.selectEligibility,
    name: "About this Petition",
    header: ACCORDION_HEADERS.GETTING_STARTED,
    showInNav: true,
  },
  ConcurrentFiling: {
    id: Paths.selectConcurrentForms,
    name: "Concurrent Filing",
    header: ACCORDION_HEADERS.GETTING_STARTED
  },
  ReasonForRequest: {
    id: Paths.selectEligibility,
    name: "Reason for request",
    header: ACCORDION_HEADERS.GETTING_STARTED,
    showInNav: true,
  },
  FeeWaiver: {
    id: Paths.ableToPay,
    name: "Upload Form I-912",
    header: ACCORDION_HEADERS.UPLOAD_PDF,
    showInNav: false,
  },
  ClientInformation: {
    id: Paths.clientInfo,
    name: "About your new client",
    header: ACCORDION_HEADERS.CLIENT_INFORMATION,
    showInNav: true,
  },
  UploadPDF: {
    id: Paths.form,
    name: "Upload PDF",
    header: ACCORDION_HEADERS.UPLOAD_PDF,
    showInNav: true,
  },
  UploadG28: {
    id: Paths.formG28,
    name: "Upload G-28 PDF",
    header: ACCORDION_HEADERS.UPLOAD_PDF,
    showInNav: true,
  },
  UploadConcurrentForms: {
    id: Paths.concurrentForms,
    name: "Upload Concurrent PDF(s)",
    header: ACCORDION_HEADERS.UPLOAD_PDF,
    showInNav: true,
  },
  ReviewYourApplication: {
    id: Paths.review,
    name: "Review your Application",
    header: ACCORDION_HEADERS.REVIEW_SUBMIT,
    showInNav: true,
  },
  ApplicationSummary: {
    id: Paths.summary,
    name: "Your Application Summary",
    header: ACCORDION_HEADERS.REVIEW_SUBMIT,
    showInNav: true,
  },
  Certification: {
    id: Paths.certify,
    name: "Certification",
    header: ACCORDION_HEADERS.REVIEW_SUBMIT,
    showInNav: true,
  },
  Signature: {
    id: Paths.signature,
    name: "Your Signature",
    header: ACCORDION_HEADERS.REVIEW_SUBMIT,
    showInNav: true,
  },
  ReviewSignature: {
    id: Paths.reviewSignature,
    name: "Review Your Signature",
    header: ACCORDION_HEADERS.REVIEW_SUBMIT,
    showInNav: true,
  },
  PayAndSubmit: {
    id: Paths.submit,
    name: "Pay & Submit",
    header: ACCORDION_HEADERS.REVIEW_SUBMIT,
    showInNav: true,
  },
  NotifyAdministrator: {
    id: Paths.notifyAdministrator,
    name: "Notify Administrator",
    header: ACCORDION_HEADERS.REVIEW_SUBMIT,
    showInNav: true,
  },
  Landing: {
    id: Paths.landing,
    name: "Landing",
    header: ACCORDION_HEADERS.REVIEW_SUBMIT,
    showInNav: false,
  }
};

const mapIdToUrl = (id: SubmissionEvidence["id"], formType: string) =>
  id.toLowerCase().replace(/[\W_]/g, " ").split(" ").join("-") + "/" + formType + "/evidence";

export const useSteps = () => {
  const { pathname } = useLocation();

  const { formType, feeWaiverEnabled } = useSelector(
    (state: RootState) => state.formMetadata.formMetadata,
  );

  const eligibilityCategories = useSelector(
    (state: RootState) => state.formMetadata.formMetadata.eligibilityCategories,
  );

  const evidenceGroups = useSelector(
    (state: RootState) => state.evidence.evidenceGroups,
  );

  const concurrentEvidenceGroups = useSelector(
    (state: RootState) => state.evidence.concurrentEvidenceGroups,
  )

  const { formMetadata } = useSelector(
    (state: RootState) => state.formMetadata,
  );

  const { accountType, canUserPayAndSubmit, isUserPartOfOrg } = useSelector((state: RootState) => state.user);
  const isRepresentative = useSelector((state: RootState) =>
    selectIsRepresentative(state),
  );

  const {
    selectedConcurrentForms
  } = useSelector((state: RootState) => state.submission);

  const {
    eligibilityCategory,
    eligibilitySubcategory,
    eligibilitySubcategories,
    reviewed,
    feeTotal,
    feeWaiver: { requested },
    attestation: { attested, attestationSignature },
    hasReviewedSignature,
    isSignaturePresent,
    userIsEligibleForFeeWaiver,
    showPayAndSubmitInAccordion,
    clientInformation
  } = useSelector((state: RootState) => state.submission);

  const { ready, hasEvidenceErrors } = useSubmissionIsComplete();
  const { isEligibilitySelectionPending } = useEligibilityCategory();

  const hasClientInfo = !!clientInformation?.name?.firstName?.trim() || !!clientInformation?.name?.lastName?.trim();


  const dynamicSteps = useMemo(() => {
    const updatedSteps = { ...Steps };

    updatedSteps.UploadPDF = {
       ...updatedSteps.UploadPDF,
      name: `Upload Form ${formType}`,
    };

    return updatedSteps;
  }, [formType, isRepresentative]);

  const stepName = useMemo(
    () => pathname.substring(pathname.lastIndexOf("/") + 1) != "evidence"
            ? pathname.substring(pathname.lastIndexOf("/") + 1)
            : pathname.substring(pathname.split("/", 4).join("/").length + 1),
    [pathname],
  );

  const availableHeaders: Headers[] = useMemo(
    () => [
      {
        label: ACCORDION_HEADERS.GETTING_STARTED,
        shouldRender: formType !== FormTypes.I907,
      },
      {
        label: ACCORDION_HEADERS.CLIENT_INFORMATION,
        shouldRender: isRepresentative && formType !== FormTypes.I129H2A && (!isUserPartOfOrg),
      },
      { label: ACCORDION_HEADERS.UPLOAD_PDF },
      {
        label: ACCORDION_HEADERS.EVIDENCE,
        shouldRender: formType !== FormTypes.I907,
      },
      { label: ACCORDION_HEADERS.REVIEW_SUBMIT },
    ],
    [isRepresentative, formType],
  );

  // TODO: Maybe this should be in the metadata too?
  const formToStepMap: Map<FormTypes, Step> = new Map<FormTypes, Step>([
        [FormTypes.N400,  dynamicSteps.BasisOfEligibility],
        [FormTypes.I907, dynamicSteps.UploadPDF],
        [FormTypes.I129H1B, dynamicSteps.ReasonForRequest],
        [FormTypes.I129H2A, dynamicSteps.AboutThisPetition],
        [FormTypes.I539, dynamicSteps.BasisOfEligibility],
  ])
  ;

  const accountTypeToStepMap: Record<AccountType, Step> = useMemo(
    () => ({
      [AccountTypes.APPLICANT]: dynamicSteps.Signature,
      [AccountTypes.REPRESENTATIVE]: dynamicSteps.Certification,
      [AccountTypes.REGISTRANT]: dynamicSteps.Signature,
    }),
    [dynamicSteps.Certification, dynamicSteps.Signature],
  );

  const isEligibilityCategoryFeeWaivable = useMemo(() => {

    if(formType === "I-765") {
      return userIsEligibleForFeeWaiver;
    }

    if ( feeWaiverEnabled ) {
      const selectedEligibilityCategory = eligibilityCategories?.find(
        (category) => category.category === eligibilityCategory,
      );
      if (eligibilitySubcategories?.length === 0) {
        if (!selectedEligibilityCategory?.metaData.feeWaivable) {
          const selectedEligibilitySubCategory =
            selectedEligibilityCategory?.metaData?.subcategories?.find(
              (subcategory) => subcategory.category === eligibilitySubcategory,
            );
          return selectedEligibilitySubCategory?.feeWaivable;
        }
      } else {
        if (eligibilitySubcategories?.length > 0) {
          return eligibilitySubcategories?.every(
            value => selectedEligibilityCategory?.metaData.subcategories
              .filter(sub => sub.feeWaivable)
              .map(sub => sub.category)?.includes(value)
          );
        }
      }
      return selectedEligibilityCategory?.metaData.feeWaivable;
    }
    return feeTotal > 0;

  }, [
    eligibilityCategory,
    eligibilitySubcategory,
    userIsEligibleForFeeWaiver,
    eligibilitySubcategories,
    eligibilityCategories,
    feeTotal,
    formType
  ]);

  const gettingStartedSteps = useMemo(() => {
    Steps.FeeWaiver.showInNav = requested === true;
    const selectEligibilityStep = formToStepMap.get(formType as FormTypes) || dynamicSteps.EligibilityCategory;
    const shouldShowFeeWaiver =
      feeWaiverEnabled && (requested || isEligibilityCategoryFeeWaivable);
      
    return shouldShowFeeWaiver
      ? [selectEligibilityStep, dynamicSteps.FeeWaiver]
      : [selectEligibilityStep];
  }, [
    formToStepMap,
    formType,
    feeWaiverEnabled,
    requested,
    feeTotal,
    dynamicSteps.FeeWaiver,
    eligibilityCategory,
    eligibilitySubcategory,
    userIsEligibleForFeeWaiver,
    isEligibilityCategoryFeeWaivable
  ]);

  const shouldIncludeEvidenceGroup = (evidenceGroup: EvidenceGroup, isPrimaryForm: boolean) => {
    //TODO remove filter when EOIR Decision Notice pages have been created
    if (["EOIR Decision Notice"].includes(evidenceGroup.id)) {
      return false
    } else if(!isPrimaryForm && formType === FormTypes.I485 && selectedConcurrentForms.length > 0 && evidenceGroup.id.includes("797")) {
      return false
    } else if(isPrimaryForm && formType === FormTypes.I485 && selectedConcurrentForms.includes(FormTypes.I140) && evidenceGroup.id.includes("797")) {
      return false
    } else {
      return true
    }
  }

  const evidenceSteps = useMemo(
    () =>
      evidenceGroups
        ?.filter(
          (evidenceGroup) => shouldIncludeEvidenceGroup(evidenceGroup, true))
        .map((evidenceGroup) => ({
          id: mapIdToUrl(evidenceGroup.id, formType),
          name: `${selectedConcurrentForms.length > 0 ? `(${formType})` : ''} ${evidenceGroup.name}`,
          header: ACCORDION_HEADERS.EVIDENCE,
        })),
    [evidenceGroups],
  );

  const concurrentEvidenceSteps = useMemo(
    () =>
      concurrentEvidenceGroups.flatMap((form) =>
          form.evidenceGroups
            ?.filter(
              (evidenceGroup) => shouldIncludeEvidenceGroup(evidenceGroup, false))
            .map((evidenceGroup) => ({
              id: mapIdToUrl(evidenceGroup.id, form.formType),
              name: `(${form.formType}) ${evidenceGroup.name}`,
              header: ACCORDION_HEADERS.EVIDENCE,
            })),
      ),
    [concurrentEvidenceGroups]
  );

  const reviewSteps = useMemo(() => {
    const attestationStep = accountTypeToStepMap[accountType as AccountType];

    if (!ready || hasEvidenceErrors) return [Steps.ReviewYourApplication];

    const baseReviewSteps: Step[] = [
      dynamicSteps.ReviewYourApplication,
      dynamicSteps.ApplicationSummary,
    ];

    const userHasAttested =
      (attested && attestationSignature && !isSignaturePresent) ||
      (attested && !attestationSignature && isSignaturePresent);

    if (!reviewed) {
      return baseReviewSteps;
    }

    if (!userHasAttested) {
      return [...baseReviewSteps, attestationStep];
    }

    const submitStep = canUserPayAndSubmit ? dynamicSteps.PayAndSubmit : dynamicSteps.NotifyAdministrator;
    const showSubmitStep = showPayAndSubmitInAccordion ? [submitStep] : []

    if (hasReviewedSignature) {
      return isSignaturePresent ||
        isRepresentative ||
        formMetadata.elisEsignFlowEnabled
        ? [...baseReviewSteps, attestationStep, ...showSubmitStep]
        : [
            ...baseReviewSteps,
            attestationStep,
            dynamicSteps.ReviewSignature,
            submitStep,
          ];
    }

    if (!hasReviewedSignature) {
      if (isSignaturePresent || isRepresentative) {
        return [...baseReviewSteps, attestationStep, ...showSubmitStep];
      } else if (formMetadata.elisEsignFlowEnabled) {
        return [...baseReviewSteps, attestationStep];
      } else {
        return [
          ...baseReviewSteps,
          attestationStep,
          dynamicSteps.ReviewSignature
        ];
      }
    }

    return [
      ...baseReviewSteps,
      attestationStep,
      dynamicSteps.ReviewSignature,
      submitStep,
    ];
  }, [
    accountTypeToStepMap,
    accountType,
    ready,
    dynamicSteps.ReviewYourApplication,
    dynamicSteps.ApplicationSummary,
    dynamicSteps.ReviewSignature,
    dynamicSteps.PayAndSubmit,
    attested,
    attestationSignature,
    isSignaturePresent,
    reviewed,
    hasReviewedSignature,
    isRepresentative,
    hasEvidenceErrors,
    formMetadata.elisEsignFlowEnabled,
    canUserPayAndSubmit,
    showPayAndSubmitInAccordion
  ]);

  const steps = useMemo(() => {
    const pdfUploadSteps = isRepresentative
      ? selectedConcurrentForms.length > 0
        ? [dynamicSteps.UploadPDF, dynamicSteps.UploadG28, dynamicSteps.UploadConcurrentForms]
        : [dynamicSteps.UploadPDF, dynamicSteps.UploadG28]
      : selectedConcurrentForms.length > 0
        ? [dynamicSteps.UploadPDF, dynamicSteps.UploadConcurrentForms]
        : [dynamicSteps.UploadPDF];

    const clientInformationSteps = isRepresentative && formType !== FormTypes.I129H2A && (!isUserPartOfOrg)
      ? [
          {
            ...Steps.ClientInformation,
            name: hasClientInfo ? `Information About Your Client`: `About your new client`,
          }
        ]
      : [];

      return formType === FormTypes.I907 ?
      [
        ...clientInformationSteps,
        ...pdfUploadSteps,
        ...reviewSteps,
      ] :
      [
        ...gettingStartedSteps,
        ...clientInformationSteps,
        ...pdfUploadSteps,
        ...evidenceSteps,
        ...concurrentEvidenceSteps,
        ...reviewSteps,
      ];
  }, [
    isRepresentative,
    dynamicSteps.UploadPDF,
    dynamicSteps.UploadG28,
    gettingStartedSteps,
    evidenceSteps,
    concurrentEvidenceSteps,
    reviewSteps,
    formType,
    isUserPartOfOrg
  ]);

  const currentStep = useMemo(() => {
    const matchingSteps = steps.filter((step) => {
      return step.id === stepName;
    });
    return matchingSteps.length === 1 ? matchingSteps[0] : steps[0];
  }, [steps, stepName]);

  const mapHeadersToAccordionSteps = useMemo(
    () =>
      availableHeaders
        .filter((header) => header.shouldRender !== false)
        .map((header) => ({
          label: header.label,
          disabled: header.label == "Getting Started" ? false : isEligibilitySelectionPending,
          group: steps.filter((step) => step.header === header.label),
        })),
    [availableHeaders, steps],
  );

  const stepIsValidTarget = useMemo(
    () => steps.some((step) => step.id === stepName),
    [steps, stepName],
  );

  return { currentStep, steps, stepIsValidTarget, mapHeadersToAccordionSteps };
};