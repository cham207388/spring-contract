import { useSelector } from "react-redux";
import { RootState } from "../redux/store";
import { Validation } from "../types/Validations";

export const useValidations = () => {
  const { formValidations, evidenceValidations, i912FeeWaiverValidation } =
    useSelector((state: RootState) => state.validations);

  const getValidationForFormType = (
    formType: String,
  ): Validation | undefined => {
    return formValidations.find(
      (formValidation) => formValidation.groupType === formType,
    );
  };

  const getValidationForEvidenceType = (
    evidenceType: String,
  ): Validation | undefined => {
    return evidenceValidations.find(
      (evidenceValidation) => evidenceValidation.groupType === evidenceType,
    );
  };

  const getValidationForFeeWaiver = () => {
    return i912FeeWaiverValidation;
  };

  return {
    getValidationForFormType,
    getValidationForEvidenceType,
    getValidationForFeeWaiver,
  };
};
