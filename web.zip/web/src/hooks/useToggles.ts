import { useCallback } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../redux/store";


export const useToggles = () => {
  const { toggles } = useSelector((state: RootState) => state);

  const isToggleEnabled = useCallback((toggleCode : string) => {
    if( toggleCode in toggles ) {
      return toggles[toggleCode];
    }
    return false;
  },
  [toggles]
  );

  return { isToggleEnabled };
};