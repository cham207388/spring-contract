
import { Form } from "../redux/types/Submission";
import { useMemo } from "react";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "../redux/store";
import { FormMetaData, FormTypes } from "../types/FormMetaData";
import { C9, CHILD, SPOUSE } from "../constants/EligibilityConstants";
import { calculateAndSetEvidenceGroups } from "../redux/thunks/calculateAndSetEvidenceGroups";
import { I140ScheduleAPetitionTypeList } from "../types/I140Types";

const isFormValid = (
    currentForm: Partial<Form>,
    currentFormMetadata: FormMetaData,
    reasonForFiling: string,

    isC9Complete: boolean,
    isUSCitizen?: string,

  ): boolean => {
    if (!currentFormMetadata) return false;

    const {
      formType,
      eligibilityCategory,
      eligibilitySubcategory,
      eligibilitySubcategoryList,
      formSpecificInfo,
    } = currentForm;

    if (formType == 'G-28') return true;
    if (formType === FormTypes.I907) return true;
    if ( formType === FormTypes.I129H2A && !reasonForFiling ) {
      return false;
    }
    if (formType === FormTypes.I539 && formSpecificInfo?.isOnlyApplicantApplying !== true ) {
      return false;
    }
    if (formType === FormTypes.I140 && I140ScheduleAPetitionTypeList.includes(eligibilityCategory || "")) {
      return (formSpecificInfo?.isScheduleA) ||
        (typeof formSpecificInfo?.dolNumber === 'string' && formSpecificInfo?.dolNumber.trim().length > 0);
    }


    const selectedEligibilityCategory = currentFormMetadata.eligibilityCategories?.find(
      (cat) => cat.category === eligibilityCategory,
    );

    if (!selectedEligibilityCategory) return false;

    if(eligibilityCategory === C9 && !isC9Complete) {
      return false;
    }
    if((eligibilityCategory === SPOUSE || eligibilityCategory === CHILD) && isUSCitizen == undefined) {
      return false;
    }



    const subCategories = selectedEligibilityCategory.metaData.subcategories;

    if (!subCategories || subCategories.length === 0) return true;

    if (formType === FormTypes.I751) {
      return !!eligibilitySubcategoryList && eligibilitySubcategoryList.length > 0;
    }


    const selectedSub = subCategories.find(
      (sub) => sub.category === eligibilitySubcategory,
    );

    if (!selectedSub) return false;



    const actionOptions = selectedSub.actionRequestedOptions;
    if (!actionOptions || actionOptions.length === 0) return true;

    return actionOptions.some(
      (action) => action.category === formSpecificInfo?.actionRequested
    );
  };


export function useEligibilityCategory () {

  const {
    eligibilityCategory,
    eligibilitySubcategory,
    eligibilitySubcategories,
    formSpecificInfo,
    forms = [],
    formType: primaryFormType,
    selectedConcurrentForms,
    isUSCitizen,
    reasonForFiling
  } = useSelector((state: RootState) => state.submission);

  const { formMetadata, concurrentFormMetadata } = useSelector(
    (state: RootState) => state.formMetadata,
  );

  const {
    isComplete: isC9Complete,
  } = useSelector((state: RootState) => state.c9feeCalculation);

  const dispatch = useAppDispatch();

  const isEligibilitySelectionPending = useMemo(() => {

    const primaryForm: Partial<Form> = {
      formType: primaryFormType,
      eligibilityCategory,
      eligibilitySubcategory,
      eligibilitySubcategoryList: eligibilitySubcategories,
      formSpecificInfo,
    };

    const isPrimaryValid = isFormValid(primaryForm, formMetadata, reasonForFiling, isC9Complete, isUSCitizen);
    if (!isPrimaryValid) return true;

    let isEligibilitySelectionPending = false;
    if (selectedConcurrentForms.length != 0) {
      const areAllConcurrentFormsValid = (forms || [])
        .filter((currentForm) => currentForm.formType !== primaryFormType && currentForm.formType !== 'G-28')
        .every((currentForm) => {
          const specificMetadata = concurrentFormMetadata.find(
            (meta) => meta.formType === currentForm.formType,
          );

          if (!specificMetadata) return false;
          return isFormValid(currentForm, specificMetadata, reasonForFiling, isC9Complete, isUSCitizen);
        });

      isEligibilitySelectionPending = !areAllConcurrentFormsValid;
    }
    dispatch(calculateAndSetEvidenceGroups())
    return isEligibilitySelectionPending;
  }, [
    primaryFormType,
    eligibilityCategory,
    eligibilitySubcategory,
    eligibilitySubcategories,
    formSpecificInfo,
    formMetadata,
    selectedConcurrentForms,
    concurrentFormMetadata,
    isC9Complete,
    isUSCitizen
  ]);

  return {
    isEligibilitySelectionPending
  };

}
