import { Submission } from "../types/Submission";
import { hydrateState } from "../redux/submissionSlice";

import {
  setIsPollingForFormValidation,
  setIsPollingForEvidenceValidation,
  setIsPollingForFeeWaiverValidation,
} from "../redux/validationsSlice";

import { FormService } from "../api/FormService";
import { useCallback } from "react";
import { AccountType, AccountTypes, setAccountType, setUserPartOfOrg, setApplicantOrRep } from "../redux/userSlice";
import { EvidenceGroup } from "../types/FormMetaData";
import { RootState, useAppDispatch } from "../redux/store";
import { isClientInOrg } from "../utils/ClientHelper";
import { useSelector } from "react-redux";
import { ConcurrentEvidenceGroups } from "../redux/evidenceSlice";
import { setFormMetadata } from "../redux/formMetadataSlice";


export const useHydrateDraft = () => {
  const dispatch = useAppDispatch();
  const { concurrentFormMetadata } = useSelector(
    (state: RootState) => state.formMetadata
  );

  const hydrateDraft = useCallback(
    async (draftSubmission: Submission) => {
      if(draftSubmission?.forms?.filter((form) => form.name != null).length > 0){
        dispatch(setIsPollingForFormValidation(true));
      }
      dispatch(
        setAccountType(draftSubmission.applicant.accountType as AccountType),
      );
      if (isClientInOrg(draftSubmission?.orgMyUscisId) || AccountTypes.REGISTRANT == draftSubmission.applicant.accountType ) {
        const isUserPartOfOrg = true;
            dispatch(setUserPartOfOrg(isUserPartOfOrg));

      }
      dispatch(setApplicantOrRep(AccountTypes.APPLICANT == draftSubmission.applicant.accountType || AccountTypes.REPRESENTATIVE == draftSubmission.applicant.accountType));
      if (draftSubmission.feeWaiver && draftSubmission.feeWaiver.type) {
        dispatch(setIsPollingForFeeWaiverValidation(true));
      }

      const formMetadata = await FormService.getFormMetadata(draftSubmission.formType)
      let evidenceGroups: EvidenceGroup[] = formMetadata.eligibilityCategories.filter(el => el.category === draftSubmission.eligibilityCategory).pop()?.metaData.evidenceGroups ?? []
      dispatch(setFormMetadata(formMetadata))

      let concurrentEvidenceGroups: ConcurrentEvidenceGroups[] = [];
      draftSubmission.forms?.forEach((form) => {
        let groups = concurrentFormMetadata.find((metadata) => metadata.formType === form.type)
            ?.eligibilityCategories.filter(el => el.category === form.eligibilityCategory).pop()?.metaData.evidenceGroups ?? []
        concurrentEvidenceGroups.push({formType: form.type, evidenceGroups: groups})
      });

      const uploadedGroups = draftSubmission.evidences
        ? draftSubmission.evidences
          .filter((evidence) => evidence.evidenceGroupType !== "feeWaiver")
          .map(
            (evidence) =>
              evidenceGroups.filter(
                (group) => group.id === evidence.evidenceGroupType,
              )[0],
          )
        : [];
      if (uploadedGroups.some((group) => group && group.validations.length > 0))
        dispatch(setIsPollingForEvidenceValidation(true));

      dispatch(hydrateState({ submission: draftSubmission, evidenceGroups }));
    },
    [dispatch],
  );
  return { hydrateDraft };
};
