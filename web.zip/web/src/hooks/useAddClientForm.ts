import { useCallback, useMemo, useState } from "react";
import { SubmissionService } from "../api/SubmissionService";
import { store } from "../redux/store";
import { useHydrateDraft } from "./useHydrateDraft";

type ErrorType =
  | "clientExists"
  | "clientAlreadyHasApplication"
  | "infoMismatch"
  | "cantAddAccount"
  | "generic"
  | "repEmail";
export interface AddClientFormStatus {
  clientAlreadyExists: boolean;
  clientAlreadyHasApplication: boolean;
  informationMismatch: boolean;
  cantAddAccount: boolean;
  clientAdded: boolean;
  isSuccess: boolean;
  errorMessage: string;
  loading: boolean;
}

const initialStatus: AddClientFormStatus = {
  // TODO we are not worrying about if the client already exists in the back-end. It is being auto-associated
  clientAlreadyExists: false,
  clientAlreadyHasApplication: false,
  informationMismatch: false,
  cantAddAccount: false,
  clientAdded: false,
  isSuccess: false,
  errorMessage: "",
  loading: false,
};

export function useAddClientForm() {
  const [status, setStatus] = useState(initialStatus);
  const [alertVisible, setAlertVisible] = useState(false);
  const {
    user: { myUscisId, userGroupId },
    submission: { submissionId },
  } = store.getState();
  const { hydrateDraft } = useHydrateDraft();

  const formHasErrors = useMemo(
    () =>
      status.errorMessage ||
      status.cantAddAccount ||
      status.clientAlreadyExists ||
      status.clientAlreadyHasApplication ||
      status.informationMismatch,
    [
      status.cantAddAccount,
      status.clientAlreadyExists,
      status.clientAlreadyHasApplication,
      status.errorMessage,
      status.informationMismatch,
    ],
  );

  const resetErrors = useCallback(() => {
    setStatus((prev) => ({
      ...prev,
      clientAlreadyExists: false,
      clientAlreadyHasApplication: false,
      informationMismatch: false,
      cantAddAccount: false,
      errorMessage: "",
    }));
  }, []);

  const startLoading = useCallback(() => {
    resetErrors();
    setStatus((prev) => ({
      ...prev,
      loading: true,
      isSuccess: false,
    }));
  }, [resetErrors]);

  const setSuccess = useCallback(() => {
    setStatus((prev) => ({
      ...prev,
      isSuccess: true,
      loading: false,
      clientAdded: true,
    }));
    setAlertVisible(true);
  }, []);

  const setError = useCallback((type: ErrorType, message?: string) => {
    const updates = {
      ...initialStatus,
      loading: false,
    };

    if (type === "clientExists") updates.clientAlreadyExists = true;
    if (type === "clientAlreadyHasApplication")
      updates.clientAlreadyHasApplication = true;
    if (type === "infoMismatch") updates.informationMismatch = true;
    if (type === "cantAddAccount") {
      updates.cantAddAccount = true;
      updates.errorMessage = message ?? "";
    }
    if (type === "generic") {
      updates.errorMessage = message ?? "";
      setAlertVisible(true);
    }

    setStatus((prev) => ({ ...prev, ...updates }));
  }, []);

  const dismiss = useCallback(async () => {
    setAlertVisible(false);
    if (status.isSuccess) {
      const submission = await SubmissionService.getSubmission(
        myUscisId,
        submissionId,
        userGroupId,
      );
      await hydrateDraft(submission);
      setStatus((prev) => ({ ...prev, clientAdded: true, isSuccess: true }));
    } else {
      setStatus((prev) => ({ ...prev, isSuccess: false }));
    }
  }, [status.isSuccess, myUscisId, userGroupId, submissionId, hydrateDraft]);

  return {
    formHasErrors,
    status,
    resetErrors,
    startLoading,
    setSuccess,
    setError,
    dismiss,
    alertVisible,
  };
}
