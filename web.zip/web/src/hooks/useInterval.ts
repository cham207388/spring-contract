import { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import {
  setIsPollingForFormValidation,
  setIsPollingForValidationTimedOut,
} from "../redux/validationsSlice";

import { useAlertSnackbar } from "./useAlertSnackbar";

function useInterval(
  callback: () => void,
  delay: number | null,
  timeoutMinutes?: number,
) {
  const savedCallback = useRef(callback);
  const [intervalTimeout, setIntervalTimeout] = useState<number | undefined>(
    timeoutMinutes,
  );
  const [intervalId, setIntervalId] = useState<any>();
  const { addAlert } = useAlertSnackbar();

  let timeoutId: any = useRef();
  const dispatch = useDispatch();

  useEffect(() => {
    setIntervalTimeout(
      timeoutMinutes ? timeoutMinutes * 60000 : timeoutMinutes,
    );
  }, [timeoutMinutes]);

  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  useEffect(() => {
    function tick() {
      savedCallback.current();
    }

    if (delay !== null) {
      const id = setInterval(tick, delay);
      setIntervalId(id);
      return () => clearInterval(id);
    }
  }, [delay]);

  useEffect(() => {
    clearTimeout(timeoutId.current);

    if (intervalTimeout && delay) {
      timeoutId.current = setTimeout(() => {
        clearInterval(intervalId);
        addAlert(
          "Validation Error: Please try again by re-uploading the document",
        );
        dispatch(setIsPollingForFormValidation(false));
        dispatch(setIsPollingForValidationTimedOut(true));
      }, intervalTimeout);
    }

    return () => {
      clearTimeout(timeoutId.current);
    };
  }, [addAlert, dispatch, intervalId, intervalTimeout, delay]);
}

export default useInterval;
