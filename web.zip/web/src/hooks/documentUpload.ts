import { SubmissionService as service } from "../api/SubmissionService";
import {
  EvidenceUploadResponse,
  FormUploadResponse,
  UploadRequest,
} from "../types/Upload";

export const useUploadDocument = () => {
  const uploadDocument = async (uploadRequest: UploadRequest, userGroupId: string) => {
    const response: FormUploadResponse =
      await service.uploadForm(uploadRequest, userGroupId);

    return response;
  };
  return { uploadDocument };
};

export const useUploadEvidence = () => {
  const uploadEvidence = async (uploadRequest: UploadRequest, userGroupId: string) => {
    const response: EvidenceUploadResponse[] =
      await service.uploadEvidence(uploadRequest, userGroupId);

    return response;
  };

  return { uploadEvidence };
};
