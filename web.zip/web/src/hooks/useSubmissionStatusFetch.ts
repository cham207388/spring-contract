import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "../redux/store";
import { useEffect } from "react";
import { fetchSubmissionStatus } from "../redux/submissionStatusSlice";

export function useSubmissionStatusFetch() {
  const dispatch = useDispatch<AppDispatch>();
  const submission = useSelector((state: RootState) => state.submission);
  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);

  const { response, loading, error } = useSelector(
    (state: RootState) => state.submissionStatus,
  );

  const { isPollingForFormValidation, isPollingForEvidenceValidation } =
    useSelector((state: RootState) => state.validations);

  useEffect(() => {
    if (submission.submissionId) {
      dispatch(
        fetchSubmissionStatus({
          myUscisId,
          submissionId: submission.submissionId,
          userGroupId,
        }),
      );
    }
  }, [
    dispatch,
    myUscisId,
    userGroupId,
    submission.submissionId,
    submission.evidences,
    submission.evidenceHasError,
    submission.forms,
    submission.formSpecificInfo,
    submission.feeWaiver.requested,
    submission.feeWaiver.files,
    submission.formHasError,
    isPollingForFormValidation,
    isPollingForEvidenceValidation,
  ]);

  return {
    isLoading: loading,
    error,
    response,
  };
}
