import { useSelector } from "react-redux";
import { RootState } from "../redux/store";
import { selectIsRepresentative } from "../redux/userSlice";
import { useClientInformation } from "./useClientInformation";
import { EvidenceFile } from "../redux/types/Submission";
import { ValidationResults, Validators } from "../types/Validations";
import { SubmissionStatusResponse } from "../types/SubmissionStatusResponse";
import { useValidations } from "./useValidations";
import { FormTypes } from "../types/FormMetaData";

export function useSubmissionIsComplete(): {
  isComplete: boolean;
  ready: boolean;
  hasEvidenceError: (file: EvidenceFile) => boolean;
  hasEvidenceErrors: boolean;
  hasEligibilityWarning: boolean;
  hasPhotoValidationWarning: boolean;
  hasMissingEligibilityCategories: boolean;
} {
  const submission = useSelector((root: RootState) => root.submission);
  const { response: submissionStatusResponse } = useSelector(
    (root: RootState) => root.submissionStatus,
  );
  const { getValidationForFormType } = useValidations();
  const files = submission.evidences.flatMap((evidence) => evidence.files);
  const primaryFormValidation = getValidationForFormType(submission.formType);

  const primaryEvidenceTypes = useSelector(
    (root: RootState) => root.evidence.evidenceGroups,
  ).flatMap((group) => group.evidenceTypes);

  const concurrentEvidenceTypes = useSelector(
    (root: RootState) => root.evidence.concurrentEvidenceGroups,
  ).flatMap((group) => group.evidenceGroups).flatMap((group) => group.evidenceTypes);

  const evidenceTypes = [...primaryEvidenceTypes, ...concurrentEvidenceTypes];

  let hasUploadedForm = false;
  const {
    formHasError,
    evidenceHasError,
    eligibilityCategory,
    eligibilitySubcategory,
    formSpecificInfo,
    feeWaiver,
    evidences,
    forms,
    formType,
  } = useSelector((root: RootState) => root.submission);

  const isRepresentative = useSelector((state: RootState) =>
    selectIsRepresentative(state),
  );

  const { missingClientInformationForRepresentative } = useClientInformation();

  hasUploadedForm = forms.some((form) => form.formType === formType);
  if (isRepresentative)
    hasUploadedForm = forms.some((form) => form.formType === "G-28");

  const {
    formValidations,
    i912FeeWaiverValidation,
    isPollingForEvidenceValidation,
    isPollingForFeeWaiverValidation,
    isPollingForFormValidation,
  } = useSelector((root: RootState) => root.validations);

  const hasSupportingEvidences = evidences.some(
    (evidence) => evidence.evidenceGroup === "feeWaiver",
  );

  const hasEvidenceError = (file: EvidenceFile) => {
    return (
      !evidenceTypes.map((type) => type.id).includes(file.type) &&
      file.type !== "Other"
    );
  };

  function allErrorMessages(response?: SubmissionStatusResponse) {
    if (!response) {
      return [];
    }

    const errors = [
      ...(response?.submissionErrors ?? []),
      ...(response?.formErrors?.flatMap((s) => s.errors) ?? []),
      ...(response?.evidenceErrors?.flatMap((s) => s.errors) ?? []),
    ];
    return errors;
  }

  const feeWaiverRequestedWithSupportingEvidences: boolean =
    !!feeWaiver.requested &&
    feeWaiver.files.length > 0 &&
    hasSupportingEvidences;

  const feeWaiverValid =
    feeWaiverRequestedWithSupportingEvidences &&
    !!i912FeeWaiverValidation &&
    i912FeeWaiverValidation.result === "PASS";

  const partialFeeWaiverRequestedWithSupportingEvidences: boolean =
    feeWaiver.partialRequested && hasSupportingEvidences;

  const formValidationsComplete = formValidations?.every(
    (validation) => validation.status === "COMPLETE",
  );

  const eligibilityCategoryValidation = primaryFormValidation?.details?.find(
    (validation: { validator: Validators }) =>
      validation.validator === Validators.ELIGIBILITY_CATEGORY,
  );

  const hasEligibilityWarning =
    eligibilityCategoryValidation?.result === ValidationResults.WARN;

  const hasEvidenceErrors = files.some((file) => hasEvidenceError(file));

  const photoValidationWarnings = useSelector(
    (root: RootState) => root.evidence.photoUploadErrors,
  );

  const hasPhotoValidationWarning = photoValidationWarnings?.length > 0;

  const hasMissingEligibilityCategories =
    ([FormTypes.I129H1B, FormTypes.I129E, FormTypes.I129R, FormTypes.I129TN].includes(formType as FormTypes) &&
    (!eligibilityCategory ||
      !eligibilitySubcategory ||
      !formSpecificInfo?.actionRequested
    ));

  const isComplete =
    (!!eligibilityCategory || formType === FormTypes.I907) &&
    formValidationsComplete &&
    hasUploadedForm &&
    !formHasError &&
    !isPollingForFormValidation &&
    !isPollingForEvidenceValidation &&
    !isPollingForFeeWaiverValidation &&
    !evidenceHasError &&
    (feeWaiverValid ||
      !feeWaiver.requested ||
      partialFeeWaiverRequestedWithSupportingEvidences) &&
    !missingClientInformationForRepresentative &&
    !hasMissingEligibilityCategories;

  const ready =
    isComplete &&
    !!submissionStatusResponse &&
    0 === allErrorMessages(submissionStatusResponse).length &&
    !hasEvidenceErrors &&
    eligibilityCategoryValidation?.result !== ValidationResults.FAIL;

  return {
    isComplete,
    ready,
    hasEvidenceErrors,
    hasEvidenceError,
    hasPhotoValidationWarning,
    hasEligibilityWarning,
    hasMissingEligibilityCategories,
  };
}
