// hooks/useRouteChangeFocus.js
import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';

export function useRouteChangeFocus<T extends HTMLElement = HTMLHeadingElement>() {
  const location = useLocation();
  const mainContentRef = useRef<T>(null);
  const previousPathname = useRef(location.pathname);

  useEffect(() => {
    // Only trigger on actual route changes, not hash or search changes
    if (previousPathname.current !== location.pathname) {
      previousPathname.current = location.pathname;

      // Small delay ensures content has rendered
      const timeoutId = setTimeout(() => {
        const keyboardFocusTarget  = mainContentRef.current;
        if (keyboardFocusTarget ) {

          // Remove from tab order temporarily
          keyboardFocusTarget.setAttribute('tabindex', '-1');
          keyboardFocusTarget.focus();

          // Clean up tabindex after focus
          const cleanupTimeout = setTimeout(() => {
            keyboardFocusTarget?.removeAttribute('tabindex');
          }, 100);

          return () => clearTimeout(cleanupTimeout);
        }
      }, 100);

      return () => clearTimeout(timeoutId);
    }
  }, [location.pathname]);

  return mainContentRef;
}