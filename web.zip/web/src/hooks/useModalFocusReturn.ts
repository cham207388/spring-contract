import { useEffect, useRef, RefObject } from 'react';

function focusNext (
  containerElementRef: RefObject<HTMLElement|null>
) : void {

  if(!(containerElementRef && containerElementRef.current && containerElementRef.current.isConnected)) return;

  const focusable = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
  const focusableElements = Array.from(containerElementRef.current.querySelectorAll(focusable));
  const firstFocusableElement = (focusableElements[0] || null) as HTMLElement;
  if(firstFocusableElement) {
    firstFocusableElement.focus();
  }

}

function useModalFocusReturn (
  isOpen: boolean,
  focusReturnFallbackElementRef: RefObject<HTMLElement|null>
) : void {
  const previousFocusRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if(isOpen) {
      previousFocusRef.current = document.activeElement as HTMLElement;
      return;
    }
    if(!(previousFocusRef && previousFocusRef.current)) return;

    setTimeout(() => {
      const triggerElement = previousFocusRef.current;
      if(triggerElement && triggerElement.isConnected) {
        triggerElement.focus();
      }
      else if(focusReturnFallbackElementRef && focusReturnFallbackElementRef.current) {
        focusNext(focusReturnFallbackElementRef);
      }
      previousFocusRef.current = null;

    }, 0);

  },[isOpen,focusReturnFallbackElementRef]);

}

export default useModalFocusReturn;