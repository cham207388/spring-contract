import { useMemo } from "react";
import { RootState } from "../redux/store";
import { useSelector } from "react-redux";
import { selectIsRepresentative } from "../redux/userSlice";

export const useClientInformation = () => {
  const { clientInformation } = useSelector(
    (state: RootState) => state.submission,
  );
  const isRepresentative = useSelector((state: RootState) =>
    selectIsRepresentative(state),
  );

  const { isUserPartOfOrg } = useSelector((state: RootState) => state.user);


  const clientObjectMissing = useMemo(
    () => clientInformation === null,
    [clientInformation],
  );
  const clientNotAssociated = useMemo(
    () =>
      !clientObjectMissing &&
      clientInformation !== undefined &&
      !clientInformation.clientId,
    [clientInformation, clientObjectMissing],
  );

  const missingClientInformationForRepresentative = useMemo(
    () => isRepresentative && !isUserPartOfOrg && (clientObjectMissing || clientNotAssociated),
    [clientObjectMissing, clientNotAssociated, isRepresentative],
  );

  return {
    clientObjectMissing,
    clientNotAssociated,
    missingClientInformationForRepresentative,
  };
};
