import { useLocation, useNavigate } from "react-router-dom";

export const useRouteNavigator = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
    const routeTo = (childRoute: string) => {
      const lastSlashPosition = location.pathname.lastIndexOf("/");
      const beforeLastSlash = location.pathname.substring(0, lastSlashPosition);
      navigate(`${beforeLastSlash}/${childRoute}`);
    };
  
  return { routeTo };
}