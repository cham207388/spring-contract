import { useDispatch } from "react-redux";
import { AccountType, setAccountType, setUserPartOfOrg } from "../redux/userSlice";
import { setClientInformation } from "../redux/submissionSlice";
import { ClientInformation } from "../redux/types/Submission";

export const Environments = {
  LOCAL: "localhost",
  DEVELOPMENT: "dev-my.uscis.dhs.gov",
  PR: "apps.k8s-nonprod.uscis.dhs.gov",
} as const;

export function useEnvironment() {
  const { origin } = window.location;
  const dispatch = useDispatch();
  const isLocal = origin.includes(Environments.LOCAL);
  const isDevelopment = origin.includes(Environments.DEVELOPMENT);
  const isPR = origin.includes(Environments.PR);
  const isDev = origin.includes(Environments.DEVELOPMENT);


  const isLowerEnvironment = isLocal || isPR || isDev;

  const setAccountTypeWrapper = (accountType: AccountType) => {
    dispatch(setAccountType(accountType));
  };

  const setUserPartOfOrgWrapper = (isOrgUser: boolean) => {
    dispatch(setUserPartOfOrg(isOrgUser));
  };

  const associateTestClient = () => {
    const testClientInformation: ClientInformation = {
      submissionId: "TEST_SUBMISSION_ID",
      clientId: "TEST_CLIENT_ID",
      attorneyId: "TEST_ATTORNEY_ID",
      userGroupIds: [],
      name: {
        firstName: "TEST_CLIENT_FIRST_NAME",
        lastName: "TEST_CLIENT_LAST_NAME",
      },
    };
    // console.log("ASSOCIATE TEST_CLIENT");
    dispatch(setClientInformation(testClientInformation));
  };

  const disassociateTestClient = () => {
    // console.log("DISASSOCIATE_TEST_CLIENT");
    dispatch(setClientInformation(null as unknown as ClientInformation));
  };

  return {
    isLowerEnvironment,
    isDevelopment,
    setAccountTypeWrapper,
    setUserPartOfOrgWrapper,
    associateTestClient,
    disassociateTestClient,
  };
}
