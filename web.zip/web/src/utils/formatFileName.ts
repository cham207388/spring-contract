export const formatFileName = (fileName: string | undefined) => {
  let parts: string[] = fileName!.split(".");
  const fileType: string = parts.pop() || "";

  const combined = parts.join(".");

  if (combined.length > 16 && combined !== fileType)
    return combined.substring(0, 15) + "...." + fileType;
  else return fileName;
};
