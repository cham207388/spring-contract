import AcceptedFormTypes from "../constants/AcceptedFormTypes";

export type ShouldShowEsignFormParams = {
  isSignaturePresent: boolean;
  attested: boolean;
  isUserPartOfOrg: boolean;
  accountType: "applicant" | "representative" | "registrant" | undefined;
  canUserPayAndSubmit: boolean;
  formType: string;
};

 export const ORG_FORM_TYPES: string[] = [
    AcceptedFormTypes.I_129H2A,
    AcceptedFormTypes.I_129H1B, 
    AcceptedFormTypes.I_140, 
    AcceptedFormTypes.I_129E, 
    AcceptedFormTypes.I_129R, 
    AcceptedFormTypes.I_129TN,
    AcceptedFormTypes.I_907
  ]

export function shouldShowEsignForm({
  isSignaturePresent,
  attested,
  isUserPartOfOrg,
  accountType,
  canUserPayAndSubmit,
  formType,
}: ShouldShowEsignFormParams): boolean {
  if (isSignaturePresent) return false;
  if (!attested) return false;

  const isOrgFormType = ORG_FORM_TYPES.includes(formType);
  if (isOrgFormType && isUserPartOfOrg) {
    if (accountType === "representative") return false;
    // Admin or member (registrant)
    if (accountType === "registrant") return true;
    if (accountType === "applicant") return true;
    return false;
  }

  // Non-org filings
  if (accountType === "applicant") return true;
  // Registrants: only if part of org and org form type (already handled above)
  return false;
}

export function isNextDisabled({
  attested,
  attestationSignature,
  isSignaturePresent,
  isRepresentative,
  isUserPartOfOrg,
  nextButtonValidation,
}: {
  attested: boolean;
  attestationSignature: string;
  isSignaturePresent: boolean;
  isRepresentative: boolean;
  isUserPartOfOrg: boolean;
  nextButtonValidation: () => boolean;
}): boolean {
  // Must pass main attestation validation
  if (!nextButtonValidation()) return true;

  // If not a representative, no signature present, and no e-signature entered
  if (!isRepresentative && !isSignaturePresent && !attestationSignature) return true;

  // If user is part of org, has attested, and no signature present
  if (isUserPartOfOrg && attested && !isSignaturePresent && !attestationSignature) return true;

  return false;
}


export function nextButtonValidation({
  formType,
  eligibilitySubcategory,
  attested,
  attestationFirstCheckbox,
  attestationSecondCheckox,
}: {
  formType: string;
  eligibilitySubcategory?: string;
  attested: boolean;
  attestationFirstCheckbox: boolean;
  attestationSecondCheckox: boolean;
}): boolean {
  if (formType === "I-129H1B") {
    if (!attested) return false;
    if (eligibilitySubcategory === "H1B3_FASHION_MODEL") {
      return attestationSecondCheckox;
    }
    return attestationFirstCheckbox && attestationSecondCheckox;
  }
  return attested;
}

