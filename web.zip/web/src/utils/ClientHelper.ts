import { ClientName } from "../redux/types/Submission";

export type RepDataParam = {
  clientId: string;
  clientName: string;
  repGroupId: string;
};

type Client = {
  uuid: string;
  name: string;
  formsToFile: string[];
  role: string;
}

export const getClientInfoFromUrl = (
  myUscisId: string,
  searchParams: URLSearchParams,
) => {
  const repDataParam = searchParams.get("r");
  if (repDataParam) {
    try {
      const repData: RepDataParam = JSON.parse(atob(repDataParam as string));
      return {
        clientId: repData.clientId,
        name: extractClientName(repData.clientName),
        attorneyId: myUscisId,
        userGroupIds: [repData.repGroupId],
      };
    } catch (error) {
      throw new Error("error parsing Json");
    }
  }
  return undefined;
};

export const getConcurrentClientInformationFromUrl = (
  myUscisId: string,
  searchParams: URLSearchParams,
  formType: string
) => {
  const searchParamsClientInfo = searchParams.get("clients");
  if(searchParamsClientInfo) {
    const repGroupId = searchParams.get("repGroupId");
    const clients = JSON.parse(atob(searchParamsClientInfo)) as Client[];
    const clientInformation = clients
      .find((c) => c.formsToFile.indexOf(formType) >= 0)
    if(clientInformation && clientInformation.uuid) {
      return {
            clientId: clientInformation.uuid,
            name: extractClientName(clientInformation.name),
            attorneyId: myUscisId,
            userGroupIds: [repGroupId],
      }
    }
    return undefined;
  }
  return undefined;
}

const extractClientName = (clientName: string) => {
  let name: ClientName | undefined;
  if (clientName) {
    const nameSplit = clientName.split(", ");
    if (nameSplit.length > 1)
      name = { firstName: nameSplit[1], lastName: nameSplit[0] };
    else name = { firstName: nameSplit[0] };
  }
  return name;
}

export const isClientInOrg = (
  clientId: string | undefined
) => {
  if (clientId != null) {
    return clientId?.startsWith("O-") ? true : false
  }
  else return false;

};
