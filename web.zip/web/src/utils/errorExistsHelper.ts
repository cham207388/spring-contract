export const formErrorIsEligibilitySelectPageRelated = (error: string) => {
  const excludeList: RegExp[] = [
    /There was no Eligibility Category detected on the form./,
    /There were multiple Bases of Eligibility detected on the form./,
    /You did not select a basis for eligibility in (.*?) of the Form [A-Za-z]+-[A-Za-z0-9]+./,
  ];
  for (const regex of excludeList) {
    if (regex.test(error)) return false;
  }

  const includeList: RegExp[] = [/eligibility/i];
  for (const regex of includeList) {
    if (regex.test(error)) return true;
  }

  return false;
};

export const eligibilityErrorExists = (error: string) => {
  const regexList: RegExp[] = [
    /The basis for eligibility you selected does not match/i,
    /Basis of Eligibility/i,
    /eligibility category/i,
    /Petition Type/i,
  ];

  for (const regex of regexList) {
    if (regex.test(error)) return true;
  }

  return false;
};
