let USDollar = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
});

export const formatToMoney: (amount: number | undefined) => string = (
  amount: number | undefined,
): string => {
  if (amount !== undefined && amount >= 0) return USDollar.format(amount);
  return "";
};
