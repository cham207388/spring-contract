const getFileExtension = (filePath: string): string => {
  const parts = filePath.split(".");
  if (parts.length > 1) {
    return parts.pop() ?? "";
  }
  return "";
};

export const fileHasExtension = (filePath: string, fileExtension: string) => {
  const fileExtFound = getFileExtension(filePath).toLowerCase();
  const fileExtMatch = fileExtension.replace(".", "").toLowerCase();
  return fileExtFound === fileExtMatch;
};
