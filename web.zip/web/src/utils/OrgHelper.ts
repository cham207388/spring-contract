import { store } from "../redux/store";
import { AccountTypes, setUserPartOfOrg } from "../redux/userSlice";
import { isClientInOrg } from "./ClientHelper";


export const setUserInOrg = (
  clientId: string | undefined,
  accountType: string) => {
  var isUserPartOfOrg = false;
  if (isClientInOrg(clientId) || AccountTypes.REGISTRANT === accountType) {
    isUserPartOfOrg = true;
  }
  store.dispatch(setUserPartOfOrg(isUserPartOfOrg));
};