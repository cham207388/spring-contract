// Returns format of MM/DD/YYYY
export function getDateFromNanoSeconds(uploadedAt: string | undefined) {
  if (!uploadedAt) return null;
  return new Date(uploadedAt).toLocaleDateString();
}

// Returns format of May 8, 2024
export const formatDate = (dateTime: string) => {
  return new Date(dateTime).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
};

// Returns format of June 7, 2024
export function formatDateThirtyDaysFromNow(updatedAtDate: string): string {
  const date = new Date(updatedAtDate);
  date.setDate(date.getDate() + 30);
  return date.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}
