export const fileNameValidator = (file: File) => {
  const pattern = /^[a-zA-Z0-9().\s\-_]*$/;
  const extensionStartIndex = file.name?.lastIndexOf(".");
  const fileName =
    extensionStartIndex === -1
      ? file.name
      : file.name?.slice(0, extensionStartIndex);

  return !pattern.test(fileName)
    ? {
        code: "filename-error",
        message:
          "Your file name must only contain, English letters, numbers, certain special characters _ , - , . , () , and/or spaces.",
      }
    : null;
};
