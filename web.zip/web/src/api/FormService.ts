import { EvidenceGroup, FormMetaData } from "../types/FormMetaData";
import { api } from "./axios";

export const FormService = {
  getFormMetadata: async function (formType: string): Promise<FormMetaData> {
    const response = await api.request({
      url: `api/intake/forms/${formType}/metadata`,
      method: "GET",
    });
    return response.data;
  },
  getEvidenceGroups: async function (
    formType: string,
    eligibilityCategory: string,
  ): Promise<EvidenceGroup[]> {
    const response = await api.request({
      url: `api/intake/forms/${formType}/metadata/${eligibilityCategory}/evidence`,
      method: "GET",
    });
    return response.data;
  },
  canUserFileFor: async function (
    formType: string,
    myUscisId: string,
  ): Promise<{ result: boolean }> {
    const response = await api.request({
      url: `api/intake/forms/${formType}/ableToFile/${myUscisId}`,
      method: "GET",
    });
    return response.data;
  },
  getConcurrentForms: async function (
    formType: string,
  ): Promise<string[]> {
    const response = await api.request({
      url: `api/intake/forms/${formType}/concurrentForms`,
      method: "GET",
    });
    return response.data;
  },
};
