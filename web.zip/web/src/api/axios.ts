import axios, { AxiosError, AxiosResponse } from "axios";

export type SerializedError = {
  data: string;
};

const PAGE_ALREADY_RELOADED_HASH_FLAG = "reloaded";
const shouldReloadPageForUnauthenticated = (
  response: AxiosResponse,
): boolean => {
  return (
    response.status === 401 &&
    (response.config.url?.includes("api/") || false) &&
    !window.location.href.includes(`#${PAGE_ALREADY_RELOADED_HASH_FLAG}`)
  );
};

const successResponseInterceptor = (response: AxiosResponse) => {
  return response;
};
const errorResponseInterceptor = (error: AxiosError) => {
  if (!(error.isAxiosError && error.response)) {
    return Promise.reject(error);
  }

  if (shouldReloadPageForUnauthenticated(error.response)) {
    window.location.hash = PAGE_ALREADY_RELOADED_HASH_FLAG;
    window.location.reload();
  }

  const responseBody: any = error.response.data;
  const errorMessage: any = responseBody ? responseBody.error : null;

  return Promise.reject(errorMessage || error);
};

const api = axios.create({ baseURL: "/pdf-intake" });
api.interceptors.response.use(
  successResponseInterceptor,
  errorResponseInterceptor,
);

export { api, errorResponseInterceptor };
