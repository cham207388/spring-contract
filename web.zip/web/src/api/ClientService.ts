import { api } from "./axios";

export const ClientService = {
  addClient: async function (
    myUscisId: string,
    submissionId: string,
    data: any,
  ): Promise<string> {
    const { clientData } = data;
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/clients/add-client`,
      method: "POST",
      data: clientData,
    });
    return response.data;
  },
};
