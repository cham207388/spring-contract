
import { api } from "./axios";
export interface CheckToggleRequest {
  toggleCode: string,
  formType?: string,
}

export interface CheckToggleResponse {
  toggleExists: boolean,
  toggleEnabled: boolean
}

export const ToggleService = {
  checkToggle : async function (
    checkToggleRequest: CheckToggleRequest
  ): Promise<CheckToggleResponse> {
    try {

      const response = await api.request({
        url: `/api/intake/toggle/get-toggle/formType/${checkToggleRequest.formType || 'NA'}/${checkToggleRequest.toggleCode}`,
        method: "GET"
      });

      const checkToggleResponse : CheckToggleResponse = {
        toggleExists : response.status === 200,
        toggleEnabled : response.data
      }

      return checkToggleResponse;
    }
    catch(error) {
      return {
        toggleExists : false,
        toggleEnabled : false
      }
    };
  }
};
