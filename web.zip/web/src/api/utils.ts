interface MakeParams {
  filters?: string;
  isUSCitizen?: string;
  orgMyUscisId?: string;
}

export const makeParams = ({filters, isUSCitizen, orgMyUscisId} : MakeParams) => {
  return {
      ...(filters && { filters: filters }),
      ...(isUSCitizen  && { residencyStatus: isUSCitizen }),
      ...(orgMyUscisId && { orgMyUscisId: orgMyUscisId   })
  }
}

export const makeParamString = (params : MakeParams) => {
  let paramsString = "";
  const paramsObject = makeParams(params);

  for (const [key, value] of Object.entries(paramsObject)) {
    paramsString = paramsString + `?${key}=${value}`
  }
  return paramsString;
}