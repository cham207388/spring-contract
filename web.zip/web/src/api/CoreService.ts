import {
  CoreMetaData,
  EvidencePage,
} from "../types/FormMetaData";
import { api } from "./axios";

export const CoreService = {
  getCoreMetadata: async function (): Promise<CoreMetaData> {
    const response = await api.request({
      url: `api/intake/metadata/core`,
      method: "GET",
    });
    return response.data;
  },
  getEvidenceMetadata:
    async function (
      evidenceMetadataId: string
    ): Promise<EvidencePage> {
      const evidencePageUrl = `api/intake/metadata/evidence/${evidenceMetadataId}`
      const response = await api.request({
        url: evidencePageUrl,
        method: "GET",
      });
      return response.data;
    },
};
