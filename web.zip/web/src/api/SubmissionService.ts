import { store } from "../redux/store";
import { RepData } from "../redux/types/Submission";
import { AccountType, AccountTypes } from "../redux/userSlice";
import { AttestationStatus } from "../types/Attestation";
import { FinalTransmissionStatus, FormSpecificInfo, Submission } from "../types/Submission";
import { EsignData } from "../types/EsignData";
import { SubmissionStatusResponse } from "../types/SubmissionStatusResponse";
import { UpdateFeeWaiverEvidenceRequest } from "../types/UpdateFeeWaiverEvidenceRequest";
import {
  EvidenceUploadResponse,
  FormUploadResponse,
  UploadRequest,
} from "../types/Upload";
import { ValidationStatusResponse } from "../types/Validations";
import { api } from "./axios";
import { OrganizationFormTypes } from "../types/FormMetaData";
import { Admin } from "../types/Admin";
import { makeParams, makeParamString } from "./utils";
import { ConcurrentForm } from "../redux/thunks/createSubmissionAndFetchEvidence";

export interface UpdateSubmissionResponse {
  submission: Submission;
}

export interface SessionDetail {
  myUscisId: string;
  userGroupId: string;
}

export interface C9Options {
  onOrAfterApril012024: boolean | null;
  beforeApril012024: boolean | null;
}

export interface C9UpdateRequest {
  options: C9Options;
  feeWaiverEligible: boolean;
}

export const SubmissionService = {
  uploadForm: async function (
    data: UploadRequest,
    orgMyUscisId?: string
  ): Promise<FormUploadResponse> {
    const { formData, myUscisId, submissionId } = data;
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/form`,
      params: makeParams({orgMyUscisId}),
      method: "POST",
      data: formData,
    });
    return response.data;
  },
  uploadEvidence: async function (
    data: UploadRequest,
    orgMyUscisId?: string
  ): Promise<EvidenceUploadResponse[]> {
    const { formData, myUscisId, submissionId, selectedFormType } = data;
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/evidence/${selectedFormType}`,
      params: makeParams({orgMyUscisId}), 
      method: "POST",
      data: formData,
    });
    return response.data;
  },
  uploadFeeWaiver: async function (
    data: UploadRequest,
    orgMyUscisId?: string
  ): Promise<UpdateSubmissionResponse> {
    const { formData, myUscisId, submissionId } = data;
    const response = await api.post(
      `api/intake/${myUscisId}/submissions/${submissionId}/feeWaiver${makeParamString({orgMyUscisId})}`,
      formData,
    );
    return response.data;
  },
  deleteUploadedForm: async function (
    myUscisId: string,
    submissionId: string,
    formId: string,
    orgMyUscisId?: string
  ) {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/forms/${formId}`,
      params: makeParams({orgMyUscisId}),
      method: "DELETE",
    });
    return response.data;
  },
  deleteUploadedEvidence: async function (
    myUscisId: string,
    submissionId: string,
    evidenceId: string,
    orgMyUscisId?: string
  ) {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/evidence/${evidenceId}`,
      params: makeParams({orgMyUscisId}),
      method: "DELETE",
    });
    return response.data;
  },
  updateFeeWaiverEvidence: async function (
    myUscisId: string,
    submissionId: string,
    feeWaiverId: string,
    data: UpdateFeeWaiverEvidenceRequest,
    orgMyUscisId?: string
  ): Promise<UpdateSubmissionResponse> {
    const response = await api.patch(
      `api/intake/${myUscisId}/submissions/${submissionId}/feeWaiver/${feeWaiverId}${makeParamString({orgMyUscisId})}`,
      data,
    );
    return response.data;
  },
  updateEvidence: async (
    myUscisId: string,
    submissionId: string,
    evidenceId: string,
    evidenceType: string,
    orgMyUscisId?: string
  ): Promise<UpdateSubmissionResponse> => {
    const response = await api.patch(
      `api/intake/${myUscisId}/submissions/${submissionId}/evidence/${evidenceId}${makeParamString({orgMyUscisId})}`,
      { type: evidenceType },
    );
    return response.data;
  },
  deleteUploadedFeeWaiver: async function (
    myUscisId: string,
    submissionId: string,
    feeWaiverId: string,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/feeWaiver/${feeWaiverId}`,
      params: makeParams({orgMyUscisId}),
      method: "DELETE",
    });
    return response.data;
  },
  pollForValidationStatus: async function (
    myUscisId: string,
    submissionId: string,
    orgMyUscisId?: string
  ): Promise<ValidationStatusResponse> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/validation-status`,
      params: makeParams({orgMyUscisId}),
      method: "GET",
    });
    return response.data;
  },
  pollForI912ValidationStatus: async function (
    myUscisId: string,
    submissionId: string,
    formId: string,
    orgMyUscisId?: string
  ): Promise<ValidationStatusResponse> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/forms/${formId}/i912-validation-status`,
      params: makeParams({orgMyUscisId}),
      method: "GET",
    });
    return response.data;
  },
  createInitialSubmission: async function (
    myUscisId: string,
    formType: string,
    formDescription: string,
    eligibilityCategory: string | null,
    accountType: AccountType,
    concurrentForms: ConcurrentForm[],
    applicationReasonCode: number,
    clientInformation?: RepData,
  ): Promise<Submission> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/`,
      method: "POST",
      data: {
        formType,
        formDescription,
        eligibilityCategory,
        accountType,
        concurrentForms,
        applicationReasonCode,
        clientInformation,
      },
    });

    return response.data;
  },
  
  submitFinalSubmission: async function (
    myUscisId: string,
    submissionId: string,
    orgMyUscisId?: string
  ): Promise<string> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}`,
      params: makeParams({orgMyUscisId}),
      method: "POST",
    });
    return response.data;
  },
  checkValidationStatuses: async function (
    myUscisId: string,
    submissionId: string,
  ): Promise<String[]> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/validations`,
      method: "GET",
    });
    return response.data;
  },
  getSubmissionStatus: async function (
    myUscisId: string,
    submissionId: string,
    orgMyUscisId?: string
  ): Promise<SubmissionStatusResponse> {
    const response = await api.get(
      `api/intake/${myUscisId}/submissions/${submissionId}/status${makeParamString({orgMyUscisId})}`,
    );
    return response.data;
  },

  getSessionDetails: async function (): Promise<SessionDetail> {
    const response = await api.request({
      url: `api/intake/users/session/details`,
      method: "GET",
    });
    return response.data;
  },

  getOrgId: async function (
    myUscisId: string,
  ): Promise<string> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/orgId`,
      method: "GET",
    });
    return response.data;
  },

  retrieveAccountType: async function (
    myUscisId: string,
    orgMyUscisId?: string
  ): Promise<AccountType> {
    const {
      formMetadata: {
        formMetadata: { formType, representativeEnabled },
      },
    } = store.getState();
    const response = representativeEnabled || (Object.values(OrganizationFormTypes) as string[]).includes(formType)
      ? await api.get(`api/intake/${myUscisId}/submissions/userRole${makeParamString({orgMyUscisId})}`)
      : { data: { accountType: AccountTypes.APPLICANT } }; // Short circuit call if form not enabled
    return response.data.accountType;
  },
  getSubmission: async function (
    myUscisId: string,
    submissionId: string,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}`,
      params: makeParams({orgMyUscisId}),
      method: "GET",
    });
    return response.data;
  },
  getDraftSubmissions: async function (
    myUscisId: string,
    orgMyUscisId?: string
  ): Promise<Submission[]> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/drafts`,
      params: makeParams({orgMyUscisId}),
      method: "GET",
    });
    return response.data;
  },
  getCurrentSubmissions: async function (
    myUscisId: string,
    orgMyUscisId?: string
  ): Promise<Submission[]> {
    const filters = "DRAFT,PUBLISHED,RECEIVED";
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions`,
      params: makeParams({filters, orgMyUscisId}),
      method: "GET",
    });
    return response.data;
  },
  updateUserRequestedFeeWaiver: async function (
    myUscisId: string,
    submissionId: string,
    userRequestedFeeWaiver: boolean,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.put(
      `api/intake/${myUscisId}/submissions/${submissionId}/fee-waiver${makeParamString({orgMyUscisId})}`,
      { userRequestedFeeWaiver },
    );
    return response.data;
  },
  updateUserRequestedPartialFeeWaiver: async function (
    myUscisId: string,
    submissionId: string,
    userRequestedPartialFeeWaiver: boolean,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.put(
      `api/intake/${myUscisId}/submissions/${submissionId}/partial-fee-waiver${makeParamString({orgMyUscisId})}`,
      { userRequestedPartialFeeWaiver },
    );
    return response.data;
  },
  updateImmvi: async function (
    myUscisId: string,
    submissionId: string,
    immvi: boolean,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.put(
      `api/intake/${myUscisId}/submissions/${submissionId}/immvi${makeParamString({orgMyUscisId})}`,
      { immvi },
    );
    return response.data;
  },
  updateC9fee: async function (
    myUscisId: string,
    submissionId: string,
    options: C9Options,
    feeWaiverEligible: boolean,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.put(
      `api/intake/${myUscisId}/submissions/${submissionId}/c9fee${makeParamString({orgMyUscisId})}`,
      { options, feeWaiverEligible },
    );
    return response.data;
  },
  updateReasonForFiling: async function (
    myUscisId: string,
    submissionId: string,
    reasonForFiling: string,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.put(
      `api/intake/${myUscisId}/submissions/${submissionId}/reason-for-filing${makeParamString({orgMyUscisId})}`,
      { reasonForFiling },
    );
    return response.data;
  },
  updateEligibility: async function (
    myUscisId: string,
    submissionId: string,
    eligibilityCategory: string,
    eligibilitySubcategory: string | undefined,
    benefitTypeCode: number | undefined,
    applicationReasonCode: number | undefined,
    formType: string,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.put(
      `api/intake/${myUscisId}/submissions/${submissionId}/category${makeParamString({orgMyUscisId})}`,
      {
        eligibilityCategory,
        eligibilitySubcategory,
        benefitTypeCode,
        applicationReasonCode,
        formType
      },
    );
    return response.data;
  },

  updateEligibilitySubcategories: async function (
    myUscisId: string,
    submissionId: string,
    eligibilitySubcategories: string[],
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.put(
      `api/intake/${myUscisId}/submissions/${submissionId}/eligibility-subcategories${makeParamString({orgMyUscisId})}`,
      {
        eligibilitySubcategories,
      },
    );
    return response.data;
  },
  updateSignatureReviewed: async function (
    myUscisId: string,
    submissionId: string,
    hasReviewedSignature: boolean,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.put(
      `api/intake/${myUscisId}/submissions/${submissionId}/review-signature${makeParamString({orgMyUscisId})}`,
      { hasReviewedSignature },
    );
    return response.data;
  },
  updateDraftSubmissionLock: async function (
    myUscisId: string,
    submissionId: string,
    orgMyUscisId?: string
  ) {
    const response = await api.patch(
      `api/intake/${myUscisId}/submissions/${submissionId}/lock${makeParamString({orgMyUscisId})}`,
    );
    return response.data;
  },
  deleteDraftSubmission: async function (
    myUscisId: string,
    submissionId: string,
    orgMyUscisId?: string
  ) {
    const response = await api.delete(
      `api/intake/${myUscisId}/submissions/${submissionId}${makeParamString({orgMyUscisId})}`,
    );
    return response.status;
  },
  pollForAttestationStatus: async function (
    myUscisId: string,
    submissionId: string,
    formId: string,
    orgMyUscisId?: string
  ): Promise<AttestationStatus> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/forms/${formId}/attestation-status`,
      params: makeParams({orgMyUscisId}),
      method: "GET",
    });
    return response.data;
  },
  attestForm: async function (
    myUscisId: string,
    submissionId: string,
    formId: string,
    submissionUpdate: Partial<Submission>,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.post(
      `api/intake/${myUscisId}/submissions/${submissionId}/attest/${formId}${makeParamString({orgMyUscisId})}`,
      submissionUpdate,
    );
    return response.data;
  },
  esignForm: async function (
    myUscisId: string,
    submissionId: string,
    formId: string,
    esignData: EsignData,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.post(
      `api/intake/${myUscisId}/submissions/${submissionId}/esign/${formId}${makeParamString({orgMyUscisId})}`,
      esignData,
    );
    return response.data;
  },
  downloadForm: async function (uri: string): Promise<ArrayBuffer> {
    const response = await api.get(uri, { responseType: "arraybuffer" });
    return response.data;
  },
  pollForFinalTransmissionStatus: async function (
    myUscisId: string,
    submissionId: string,
    orgMyUscisId?: string
  ): Promise<FinalTransmissionStatus> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/final-transmission-status`,
      params: makeParams({orgMyUscisId}),
      method: "GET",
    });
    return response.data;
  },
  setResidencyStatus: async function (
    submissionId: string,
    myUscisId: string,
    isUSCitizen: string | undefined,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/residency-status`,
      params: makeParams({isUSCitizen, orgMyUscisId}),
      method: "PUT",
    });
    return response.data;
  },
  updateFormSpecificInfo: async function (
    submissionId: string,
    myUscisId: string,
    formSpecificInfo: FormSpecificInfo,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.put(
      `api/intake/${myUscisId}/submissions/${submissionId}/form-specific-info${makeParamString({orgMyUscisId})}`,
      formSpecificInfo
    );
    return response.data;
  },
  resetFormSpecificInfo: async function (
    submissionId: string,
    myUscisId: string,
    orgMyUscisId?: string
  ): Promise<Submission> {
    const response = await api.delete(
      `api/intake/${myUscisId}/submissions/${submissionId}/delete-form-specific-info${makeParamString({orgMyUscisId})}`,
    );
    return response.data;
  },

  canUserPayAndSubmit: async function (
    myUscisId: string,
    submissionId: string,
    orgMyUscisId?: string
  ): Promise<boolean> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/can-pay-and-submit`,
      params: makeParams({orgMyUscisId}),
      method: "GET",
    });
    return response.data;
  },

  getAdministrators: async function (
    myUscisId: string,
    submissionId: string,
    orgMyUscisId?: string
  ): Promise<Admin[]> {
    const response = await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/administrators`,
      params: makeParams({orgMyUscisId}),
      method: "GET"
    });
    return response.data;
  },
  notifyAdministrator: async function(
    myUscisId: string,
    submissionId: string,
    admins: string[],
    orgMyUscisId?: string
  ): Promise<void> {
    await api.request({
      url: `api/intake/${myUscisId}/submissions/${submissionId}/notify`,
      params: makeParams({orgMyUscisId}),
      method: "POST",
      data: admins
    });
  }
};
