import { PaymentAuthorizationStatus } from "../types/Upload";
import { api } from "./axios";

export const PaymentService = {
  getPaymentAuthorizationStatus: async function (
    submissionId: string,
    feeTotal: number,
    formType: string,
  ): Promise<PaymentAuthorizationStatus> {
    const response = await api.request({
      url: `api/intake/payments/${submissionId}/authorization/status?feeTotal=${feeTotal}&formType=${formType}`,
      method: "GET",
    });
    return response.data;
  },
  getPaymentAuthorization: async function (
    submissionId: string,
    feeTotal: number,
    formType: string,
    successUrl: string,
    cancelUrl: string,
  ): Promise<{ redirectUrl: string }> {
    const response = await api.request({
      url: `api/intake/payments/${submissionId}/authorization?feeTotal=${feeTotal}&formType=${formType}&successUrl=${successUrl}&cancelUrl=${cancelUrl}`,
      method: "GET",
    });
    return response.data;
  },
  removePaymentAuthorization: async function (
    submissionId: string,
  ): Promise<void> {
    await api.request({
      url: `api/intake/payments/${submissionId}/payment`,
      method: "DELETE",
    });
  },
};
