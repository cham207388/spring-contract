import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

import {
  Validation,
  ValidationDetails,
  ValidationStatusResponse,
} from "../types/Validations";
import { Form } from "./types/Submission";

export interface ValidationsState {
  formValidations: Validation[];
  evidenceValidations: Validation[];
  i912FeeWaiverValidation?: ValidationDetails;

  isPollingForFormValidation: boolean;
  isPollingForEvidenceValidation: boolean;
  isPollingForFeeWaiverValidation: boolean;

  isPollingForValidationTimedOut: boolean;
}

const initialState: ValidationsState = {
  formValidations: [],
  evidenceValidations: [],
  i912FeeWaiverValidation: undefined,

  isPollingForFormValidation: false,
  isPollingForEvidenceValidation: false,
  isPollingForFeeWaiverValidation: false,

  isPollingForValidationTimedOut: false,
};

export const validationsSlice = createSlice({
  name: "validations",
  initialState,
  reducers: {
    setValidations: (
      state,
      action: PayloadAction<ValidationStatusResponse>,
    ) => {
      state.formValidations = action.payload.formValidations;
      state.evidenceValidations = action.payload.evidenceValidations;
    },
    setFormValidations: (state, action: PayloadAction<Validation[]>) => {
      state.formValidations = action.payload;
    },
    deleteFormValidation: (state, action: PayloadAction<Form>) => {
      state.formValidations = state.formValidations.filter(
        (validation) => validation.groupType !== action.payload.formType,
      );
    },
    setEvidenceValidations: (state, action: PayloadAction<Validation[]>) => {
      state.evidenceValidations = action.payload;
    },
    deleteEvidenceValidation: (state, action: PayloadAction<string>) => {
      state.evidenceValidations = state.evidenceValidations.filter(
        (validation) => validation.id !== action.payload,
      );
    },
    setFeeWaiverValidation: (
      state,
      action: PayloadAction<ValidationDetails | undefined>,
    ) => {
      state.i912FeeWaiverValidation = action.payload;
    },
    resetFeeWaiverValidation: (state) => {
      state.i912FeeWaiverValidation = undefined;
    },

    setIsPollingForFormValidation: (state, action: PayloadAction<boolean>) => {
      state.isPollingForFormValidation = action.payload;
    },
    setIsPollingForEvidenceValidation: (
      state,
      action: PayloadAction<boolean>,
    ) => {
      state.isPollingForEvidenceValidation = action.payload;
    },
    setIsPollingForFeeWaiverValidation: (
      state,
      action: PayloadAction<boolean>,
    ) => {
      state.isPollingForFeeWaiverValidation = action.payload;
    },

    setIsPollingForValidationTimedOut: (
      state,
      action: PayloadAction<boolean>,
    ) => {
      state.isPollingForValidationTimedOut = action.payload;
    },
  },
});

export const {
  setValidations,
  setFormValidations,
  deleteFormValidation,
  setEvidenceValidations,
  deleteEvidenceValidation,
  setFeeWaiverValidation,
  resetFeeWaiverValidation,
  setIsPollingForFormValidation,
  setIsPollingForEvidenceValidation,
  setIsPollingForFeeWaiverValidation,

  setIsPollingForValidationTimedOut,
} = validationsSlice.actions;

export default validationsSlice.reducer;
