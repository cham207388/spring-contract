import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

export interface SnackbarSlice {
  title?: string;
  message?: string;
  isLoading: boolean;
}

const initialState: SnackbarSlice = {
  title: "Processing",
  message:
    "Your request is being processed. Please wait and do not refresh the page.",
  isLoading: false,
};
export const loaderSlice = createSlice({
  name: "loaderSlice",
  initialState,
  reducers: {
    showLoader: (
      state,
      action: PayloadAction<{
        title?: string;
        message?: string;
      }>,
    ) => {
      state.isLoading = true;
      state.title = action.payload.title || initialState.title;
      state.message = action.payload.message || initialState.message;
    },
    resetLoader: (state) => {
      state.isLoading = false;
      state.title = initialState.title;
      state.message = initialState.message;
    },
  },
});

export const { showLoader, resetLoader } = loaderSlice.actions;
export default loaderSlice.reducer;
