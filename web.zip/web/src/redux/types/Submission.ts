import { FormSpecificInfo } from "../../types/Submission";
import { ValidationDetails, ValidationStatus } from "../../types/Validations";

export const enum FeeWaiverFileType {
  I_912 = "I-912",
  FEE_DECLARATION = "Fee Declaration",
}

export interface FeeWaiverFile {
  fileName: string;
  id: string;
  documentType: string;
  url?: string;
  dateTime: string;
  isEditable: boolean;
}

export interface FeeWaiver {
  requested: boolean | null;
  files: FeeWaiverFile[];
  partialRequested: boolean;
}

export interface Validation {
  status: ValidationStatus;
  validations: ValidationDetails[];
}

export interface Form {
  formId: string;
  fileName: string | undefined;
  formType: string;
  dateTime: string;
  url?: string;
  eligibilityCategory: string;
  eligibilitySubcategory: string;
  eligibilitySubcategoryList: string[];
  benefitTypeCode: Number;
  applicationReasonCode: Number;
  formSpecificInfo?: FormSpecificInfo;
}

export interface EvidenceFile {
  fileName: string;
  id: string;
  formId?: string;
  url?: string;
  dateTime: string;
  type: string;
  hasError: boolean;
}

export interface Evidence {
  evidenceGroup?: string;
  confirmed?: boolean;
  files: EvidenceFile[];
}

export interface Attestation {
  attested: boolean;
  attestedAt: string;
  attestationType: string,
  attestationFirstCheckbox: boolean,
  attestationSecondCheckox: boolean,
  attestationSignature: string;
}

export interface ClientInformation extends RepData {
  submissionId: string;
}

export interface RepData {
  clientId: string;
  name?: ClientName;
  attorneyId: string;
  userGroupIds: string[];
}

export interface ClientName {
  firstName: string;
  lastName?: string;
}
