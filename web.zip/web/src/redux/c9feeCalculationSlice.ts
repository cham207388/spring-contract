import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

export interface C9FeeCalculationState {
  onOrAfterApril012024Answer: boolean | null;
  beforeApril012024Answer: boolean | null;
  showBeforeAprilQuestion: boolean;
  isComplete: boolean;
}

const initialState: C9FeeCalculationState = {
  onOrAfterApril012024Answer: true,
  beforeApril012024Answer: false,
  showBeforeAprilQuestion: false,
  isComplete: true,
};

const c9FeeCalculationSlice = createSlice({
  name: "feeCalculation",
  initialState,
  reducers: {
    setQuestion1Answer: (state, action: PayloadAction<boolean>) => {
      state.onOrAfterApril012024Answer = action.payload as boolean;
      state.beforeApril012024Answer = null;

      if (action.payload === true) {
        state.showBeforeAprilQuestion = false;
        state.isComplete = true;
      } else {
        state.showBeforeAprilQuestion = true;
        state.isComplete = false;
      }
    },
    setQuestion2Answer: (state, action: PayloadAction<boolean>) => {
      state.beforeApril012024Answer = action.payload;
      state.isComplete = true;
    },
  },
});

export const { setQuestion1Answer, setQuestion2Answer } =
  c9FeeCalculationSlice.actions;
export default c9FeeCalculationSlice.reducer;
