import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import { ToggleState, AddToggle } from "../types/Toggles";

const initialState: ToggleState = {};

export const toggleSlice = createSlice({
  name: "toggles",
  initialState,
  reducers: {
    addToggle: (state, action: PayloadAction<AddToggle>) => {
      state[action.payload.toggleCode] = action.payload.toggleEnabled;
    },
  }
});

export const { addToggle } = toggleSlice.actions;
export default toggleSlice.reducer;