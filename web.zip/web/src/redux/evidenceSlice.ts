import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { EvidenceGroup } from "../types/FormMetaData";
import { createSelector } from "reselect";
import { RootState } from "./store";
import { Evidence } from "./types/Submission";

export interface EvidenceState {
  evidenceGroups: EvidenceGroup[];
  concurrentEvidenceGroups: ConcurrentEvidenceGroups[];
  photoUploadErrors: string[];
}
export type ConcurrentEvidenceGroups = {
  formType: string;
  evidenceGroups: EvidenceGroup[];
};

const initialState: EvidenceState = {
  evidenceGroups: [],
  concurrentEvidenceGroups: [],
  photoUploadErrors: [],
};
export const evidenceSlice = createSlice({
  name: "evidenceGroups",
  initialState,
  reducers: {
    setEvidenceGroups: (state, action: PayloadAction<EvidenceGroup[]>) => {
      state.evidenceGroups = action.payload;
    },
    setConcurrentEvidenceGroups: (state, action: PayloadAction<ConcurrentEvidenceGroups[]>) => {
      state.concurrentEvidenceGroups = action.payload;
    },
    setPhotoUploadErrors: (state, action: PayloadAction<string[]>) => {
      state.photoUploadErrors = action.payload;
    },
  },
});

export const { setEvidenceGroups, setPhotoUploadErrors, setConcurrentEvidenceGroups} =
  evidenceSlice.actions;
export default evidenceSlice.reducer;

export const selectedEvidencesForGroup = createSelector(
  (state: RootState) => state.submission.evidences,
  (_: any, evidenceGroupId: string) => evidenceGroupId,
  (evidences: Evidence[], evidenceGroupId: string) => {
    if (evidences)
      return evidences.filter(
        (evidence) => evidence.evidenceGroup === evidenceGroupId,
      );
    else return [];
  },
);

export const selectedEvidenceGroup = createSelector(
  (state: RootState) => state.evidence.evidenceGroups,
  (_: any, evidenceGroupId: string) => evidenceGroupId,
  (evidenceGroups: EvidenceGroup[], evidenceGroupId: string) =>
    evidenceGroups.find((group) => group.id === evidenceGroupId),
);
