import { createAsyncThunk } from "@reduxjs/toolkit";
import { SubmissionService } from "../../api/SubmissionService";
import { RootState } from "../store";

export const fetchSubmissionStatus = createAsyncThunk(
  "submissionStatus/fetchStatus",
  async (_, { getState, rejectWithValue }) => {
    const state = getState() as RootState;
    try {
      const response = await SubmissionService.getSubmissionStatus(
        state.user.myUscisId,
        state.submission.submissionId,
        state.user.userGroupId
      );
      return response;
    } catch (err) {
      return rejectWithValue(err);
    }
  },
);
