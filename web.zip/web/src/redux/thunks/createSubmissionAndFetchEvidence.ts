import { createAsyncThunk } from "@reduxjs/toolkit";
import { RootState } from "../store";
import { SubmissionService } from "../../api/SubmissionService";
import { FormService } from "../../api/FormService";
import { setEvidenceGroups } from "../evidenceSlice";
import { hydrateState } from "../submissionSlice";
import { getClientInfoFromUrl, getConcurrentClientInformationFromUrl } from "../../utils/ClientHelper";
import { EvidenceGroup } from "../../types/FormMetaData";
import { useSelector } from "react-redux";
import { RepData } from "../types/Submission";

export type RepDataParam = {
  clientId: string;
  clientName: string;
  repGroupId: string;
};

export type ConcurrentForm = {
  formType: string;
  clientInformation?: RepData
}

export type ConcurrentEvidenceGroups = {
  formType: string;
  evidenceGroups: EvidenceGroup[];
}

export const createSubmissionAndFetchEvidence = createAsyncThunk(
  "submission/createAndFetchEvidence",
  async (_, { getState, dispatch }) => {
    const state = getState() as RootState;
    const { accountType, myUscisId } = state.user;
    const { formType, eligibilityCategories, formDescription } =
      state.formMetadata.formMetadata;
    const searchParams = new URLSearchParams(window.location.search);

    let clientAndRepInfo = getClientInfoFromUrl(myUscisId, searchParams);
    if(clientAndRepInfo == undefined) {
      clientAndRepInfo = getConcurrentClientInformationFromUrl(myUscisId, searchParams, formType);
    }
    const concurrentForms: ConcurrentForm[] = Object.values(state.submission.selectedConcurrentForms ?? [])
      .map((concurrentFormType) => ({
        formType: concurrentFormType,
        clientInformation: getConcurrentClientInformationFromUrl(myUscisId, searchParams, concurrentFormType)
      }));
    const categoryMatch = eligibilityCategories.filter(
      (category) => `${category.code}` === searchParams.get("category"),
    );
    const categoryId = Number(searchParams.get("category"));

    const category =
      categoryMatch.length > 0 ? categoryMatch[0].category : null;

    const submission = await SubmissionService.createInitialSubmission(
      myUscisId,
      formType,
      formDescription,
      category,
      accountType!,
      concurrentForms,
      categoryId,
      clientAndRepInfo,
    );

    const evidenceGroups = category
      ? await FormService.getEvidenceGroups(formType, category)
      : [];

    if (evidenceGroups.length > 0) {
      dispatch(setEvidenceGroups(evidenceGroups));
    }

    dispatch(hydrateState({ submission, evidenceGroups }));

    return { submission };
  },
);
