import { I129H2A_REQUESTED_ACTIONS } from "../../pages/eligibility-information/I129H2ARequestedAction";
import { EvidenceGroup, FormMetaData, FormTypes } from "../../types/FormMetaData";
import { setEvidenceGroups, setConcurrentEvidenceGroups, ConcurrentEvidenceGroups } from "../evidenceSlice";
import { RESIDENCY_STATUS } from "../../types/Submission";
import { RootState } from "../store";


export function calculateAndSetEvidenceGroups() {
  return function calculateAndSetEvidenceGroupsThunk(dispatch: any, getState: any) {
    const store: RootState = getState()
    let evidenceGroups = store.evidence.evidenceGroups;
    switch (store.submission.formType) {
      case FormTypes.I751:
        evidenceGroups = calcI751EvidenceGroups(store)
        break;
      case FormTypes.I485A:
        evidenceGroups = calcI485AEvidenceGroups(store, undefined, undefined)
        break;
      default:
        evidenceGroups = calcEvidenceGroups(store)
    }
    calculateAndSetConcurrentEvidenceGroupsThunk(dispatch, getState);
    dispatch(setEvidenceGroups(evidenceGroups))
  }
}

export function calculateAndSetConcurrentEvidenceGroupsThunk(dispatch: any, getState: any) {
  const store: RootState = getState()

  let evidenceGroups: EvidenceGroup[] = [];
  let concurrentGroups: ConcurrentEvidenceGroups[] = [];
  store.submission.forms.filter((form) => form.formType != store.submission.formType).map((concurrentForm) => {
    switch (concurrentForm.formType) {
      case FormTypes.I751:
        evidenceGroups = calcI751EvidenceGroups(store)
        break;
      default:
        evidenceGroups = calcConcurrentEvidenceGroups(store, concurrentForm.formType)
    }
    const concurrentGroup: ConcurrentEvidenceGroups = {
      formType: concurrentForm.formType,
      evidenceGroups: evidenceGroups
    };
    concurrentGroups.push(concurrentGroup);
  })
  dispatch(setConcurrentEvidenceGroups(concurrentGroups))
}

const additionalEvidenceId = "additional-evidence";

const moveEvidenceToTheEnd = (evidenceList: EvidenceGroup[], evidenceId: string): EvidenceGroup[] => {
  const deferredEvidence = evidenceList.find(evidence => evidence.id === evidenceId);
  let result;
  if (deferredEvidence) {
    result = evidenceList.filter(evidence => evidence !== deferredEvidence);
    result.push(deferredEvidence);
  }
  return result ?? evidenceList;
}

function calcI751EvidenceGroups(store: RootState): EvidenceGroup[] {
  const underOrdersEvidenceExlusions: string[] = ["fingerprint-cards", "military-or-government-orders", "2x2-photos-of-applicants"]
  const selectedSubCategories = store.submission.eligibilitySubcategories
  const categoryMetadata = store.formMetadata.formMetadata.eligibilityCategories
    .find((evidenceCategory: { category: string; }) => evidenceCategory.category === store.submission.eligibilityCategory)
    ?.metaData;

  if (!categoryMetadata) return []

  const baseEvidenceGroups = store.submission.formSpecificInfo?.isUnderOrders ? categoryMetadata.evidenceGroups : categoryMetadata.evidenceGroups.filter(evidence => !underOrdersEvidenceExlusions.includes(evidence.id))

  if (store.submission.eligibilitySubcategories.length === 0) return moveEvidenceToTheEnd(baseEvidenceGroups, additionalEvidenceId)

  const evidenceGroupsToInclude: EvidenceGroup[] = selectedSubCategories.flatMap(checkedSubCategory => categoryMetadata.subcategories?.find(el => el.category === checkedSubCategory)?.evidenceGroupsToInclude ?? []);
  let allEvidenceGroups: EvidenceGroup[] = baseEvidenceGroups.concat(evidenceGroupsToInclude);

  allEvidenceGroups = allEvidenceGroups.reduce((result: EvidenceGroup[], current: EvidenceGroup) => {
    const isDuplicate = result.some(item => item.id === current.id);
    if (!isDuplicate) result.push(current);
    return result;
  }, []);


  return moveEvidenceToTheEnd(allEvidenceGroups, additionalEvidenceId);
};

function calcI485AEvidenceGroups(store: RootState, concurrentFormMetadata: FormMetaData | undefined, concurrentCategory: string | undefined ): EvidenceGroup[] {
  const form817EvidenceExlusion: string = "form-i-817"
  const show817Form: boolean | undefined = store.submission.formSpecificInfo?.isApplicantUnder17Unmarried || store.submission.formSpecificInfo?.isSpouseOfLegalizedAlien || store.submission.formSpecificInfo?.isUnmarriedChildUnder21
  let formMetadata = concurrentFormMetadata ?? store.formMetadata.formMetadata;
  let category = concurrentCategory ?? store.submission.eligibilityCategory;
  const categoryMetadata = formMetadata.eligibilityCategories
    .find((evidenceCategory: { category: string; }) => evidenceCategory.category === category)
    ?.metaData;

  if (!categoryMetadata) return []

  const baseEvidenceGroups = show817Form ? categoryMetadata.evidenceGroups : categoryMetadata.evidenceGroups.filter(evidence => evidence.id !== form817EvidenceExlusion)

  return moveEvidenceToTheEnd(baseEvidenceGroups, additionalEvidenceId);
};

function calcEvidenceGroups(store: RootState): EvidenceGroup[] {
  const CHILD = "PETITION_FOR_CHILD";
  const SPOUSE = "PETITION_FOR_SPOUSE";
  const PROOF_OF_CITIZENSHIP = "proof-of-citizenship";
  const PROOF_OF_LPR = "proof-of-lawful-permanent-residency";
  const MAINTENANCE_OF_STATUS = "maintenance-of-status";

  const category: string = store.submission.eligibilityCategory
  const subCategory: string | undefined = store.submission.eligibilitySubcategory
  const formSpecificInfo = store.submission.formSpecificInfo;
  const formMetadata = store.formMetadata.formMetadata
  const { isUSCitizen, reasonForFiling } = store.submission

  let evidenceGroups;
  if (subCategory || category === SPOUSE) {
    const selectedCategoryMetadata = formMetadata.eligibilityCategories.find((evidenceCategory) => evidenceCategory.category === category)?.metaData;

    let excludedCategories: string[] = [];
    let evidenceGroupsToInclude: EvidenceGroup[] = [];

    let lprOrUscGroup =
      isUSCitizen == RESIDENCY_STATUS.LPR
        ? PROOF_OF_CITIZENSHIP
        : isUSCitizen == RESIDENCY_STATUS.USC
          ? PROOF_OF_LPR
          : undefined;

    if (subCategory) {

      evidenceGroupsToInclude = selectedCategoryMetadata?.subcategories.find(el => el.category === subCategory)?.evidenceGroupsToInclude ?? [];

      const eligibilitySubCategory = selectedCategoryMetadata?.subcategories.find(
          (evidenceSubCategory) =>
            evidenceSubCategory.category === subCategory,
        );
        excludedCategories = excludedCategories.concat(eligibilitySubCategory?.evidenceCategoriesToExclude || []);
        if(eligibilitySubCategory?.actionRequestedOptions) {
          const actionRequestedOption = eligibilitySubCategory.actionRequestedOptions.find(
            option => option.category === formSpecificInfo?.actionRequested
          );
          excludedCategories = excludedCategories?.concat(actionRequestedOption?.evidenceCategoriesToExclude || [])
        }
    }

    if (lprOrUscGroup) {
      if (category === SPOUSE || category === CHILD) {
        let additionalExcludedCategories = [lprOrUscGroup];
        excludedCategories = [...additionalExcludedCategories];
      }
    }

    evidenceGroups = selectedCategoryMetadata?.evidenceGroups.filter(
        (group) => !excludedCategories?.includes(group.id)) ?? [];

    evidenceGroups = evidenceGroups.concat(evidenceGroupsToInclude)
  } else {
    evidenceGroups = formMetadata.eligibilityCategories.find(
      (evidenceCategory) => evidenceCategory.category === category,
    )?.metaData.evidenceGroups;
    if (formMetadata.formType === FormTypes.I129H2A && reasonForFiling === I129H2A_REQUESTED_ACTIONS.NOTIFY_OFFICE) {
      evidenceGroups = evidenceGroups?.filter((evidenceGroup => evidenceGroup.id !== MAINTENANCE_OF_STATUS));
    }
  }

  const hideCapEvidencePages = !(formSpecificInfo?.isCapEnabled || formSpecificInfo?.isCapGap);
  if(hideCapEvidencePages){
    evidenceGroups = evidenceGroups?.filter(
      evidenceGroup => ![
        "form-i-129h1b-passport",
        "h-1b-registration-selection-notice",
        "trade-agreement-supplement"
      ].includes(evidenceGroup.id)
    )
  }
  return evidenceGroups ? moveEvidenceToTheEnd(evidenceGroups, additionalEvidenceId) : [];
};

function calcConcurrentEvidenceGroups(store: RootState, formType: String): EvidenceGroup[] {
  const CHILD = "PETITION_FOR_CHILD";
  const SPOUSE = "PETITION_FOR_SPOUSE";
  const PROOF_OF_CITIZENSHIP = "proof-of-citizenship";
  const PROOF_OF_LPR = "proof-of-lawful-permanent-residency";
  const MAINTENANCE_OF_STATUS = "maintenance-of-status";

  const category: string | undefined = store.submission.forms.find((form) => form.formType === formType)?.eligibilityCategory;
  const subCategory: string | undefined = store.submission.forms.find((form) => form.formType === formType)?.eligibilitySubcategory;
  const formMetadata = store.formMetadata.concurrentFormMetadata.find((metadata) => metadata.formType === formType);

  if(formType === FormTypes.I485A) {
    return calcI485AEvidenceGroups(store, formMetadata, category)
  }
  const { isUSCitizen, reasonForFiling } = store.submission

  let evidenceGroups;
  if (subCategory || category === SPOUSE) {
    let excludedCategories: string[] | undefined = [];
    let lprOrUscGroup =
      isUSCitizen == RESIDENCY_STATUS.LPR
        ? PROOF_OF_CITIZENSHIP
        : isUSCitizen == RESIDENCY_STATUS.USC
          ? PROOF_OF_LPR
          : undefined;

    if (subCategory) {
      excludedCategories = formMetadata?.eligibilityCategories
        .find((evidenceCategory) => evidenceCategory.category === category)
        ?.metaData.subcategories.find(
          (evidenceSubCategory) =>
            evidenceSubCategory.category === subCategory,
        )?.evidenceCategoriesToExclude;
    }

    if (lprOrUscGroup) {
      if (category === SPOUSE || category === CHILD) {
        let additionalExcludedCategories = [lprOrUscGroup];
        excludedCategories = [...additionalExcludedCategories];
      }
    }

    evidenceGroups = formMetadata?.eligibilityCategories
      .find((evidenceCategory) => evidenceCategory.category === category)
      ?.metaData.evidenceGroups.filter(
        (group) => !excludedCategories?.includes(group.id),
      );
  } else {
    evidenceGroups = formMetadata?.eligibilityCategories.find(
      (evidenceCategory) => evidenceCategory.category === category,
    )?.metaData.evidenceGroups;
    if (formMetadata?.formType === FormTypes.I129H2A && reasonForFiling === I129H2A_REQUESTED_ACTIONS.NOTIFY_OFFICE) {
      evidenceGroups = evidenceGroups?.filter((evidenceGroup => evidenceGroup.id !== MAINTENANCE_OF_STATUS));
    }
  }

  return evidenceGroups ? moveEvidenceToTheEnd(evidenceGroups, additionalEvidenceId) : [];
};