import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import {
  CompleteYourFormSection,
  ContentSection,
  DropdownContent,
  FormMetaData,
  UploadForm,
} from "../types/FormMetaData";

export interface FormMetaDataState {
  formMetadata: FormMetaData;
  concurrentFormMetadata: FormMetaData[];
}
const initialState: FormMetaDataState = {
  formMetadata: {
    formType: "",
    formDescription: "",
    enabled: false,
    feeWaiverEnabled: false,
    elisEsignFlowEnabled: false,
    representativeEnabled: false,
    showBanner: false,
    editions: [],
    eligibilityCategories: [],
    pages: {
      beforeYouStart: {} as ContentSection,
      completeYourForm: {} as CompleteYourFormSection,
      eligibility: {} as DropdownContent,
      uploadForm: {} as UploadForm,
    },
    concurrentFormTypes: [],
  },
  concurrentFormMetadata: []
};

export const formMetadataSlice = createSlice({
  name: "formMetadata",
  initialState,
  reducers: {
    setFormMetadata: (state, action: PayloadAction<FormMetaData>) => {
      state.formMetadata = action.payload;
    },
    setConcurrentFormMetadata: (state, action: PayloadAction<FormMetaData[]>) => {
      state.concurrentFormMetadata = action.payload;
    }
  },
});

export const { setFormMetadata, setConcurrentFormMetadata } = formMetadataSlice.actions;
export default formMetadataSlice.reducer;
