import { combineReducers, configureStore } from "@reduxjs/toolkit";
import userSlice from "./userSlice";
import submissionSlice from "./submissionSlice";
import evidenceSlice from "./evidenceSlice";
import draftSubmissionsSlice from "./draftSubmissionsSlice";
import listener from "./listenerMiddleware";
import alertSnackbarSlice from "./alertSnackbarSlice";
import formMetadataSlice from "./formMetadataSlice";
import coreMetaDataSlice from "./coreMetadataSlice";
import validationSlice from "./validationsSlice";
import submissionStatusSlice from "./submissionStatusSlice";
import loaderSlice from "./loaderSlice";
import toggleSlice from "./toggleSlice";
import c9FeeCalculationSlice from "./c9feeCalculationSlice";
import { useDispatch, TypedUseSelectorHook, useSelector } from "react-redux";

const rootReducer = combineReducers({
  snackbar: alertSnackbarSlice,
  user: userSlice,
  submission: submissionSlice,
  evidence: evidenceSlice,
  draftSubmissions: draftSubmissionsSlice,
  formMetadata: formMetadataSlice,
  coreMetadata: coreMetaDataSlice,
  validations: validationSlice,
  submissionStatus: submissionStatusSlice,
  loader: loaderSlice,
  c9feeCalculation: c9FeeCalculationSlice,
  toggles: toggleSlice
});

export const setupStore = (preloadedState?: Partial<any>) => {
  return configureStore({
    reducer: rootReducer,
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware().prepend(listener.middleware),
    preloadedState,
    devTools:
      window.location.hostname.includes("csai-intake") ||
      window.location.hostname.includes("localhost"),
  });
};

export const store = setupStore();

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
export type AppStore = ReturnType<typeof setupStore>;
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
export type AppDispatch = typeof store.dispatch;

export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
