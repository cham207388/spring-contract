import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { SubmissionService } from "../api/SubmissionService";
import { SubmissionStatusResponse } from "../types/SubmissionStatusResponse";

interface FetchSubmissionStatusParams {
  myUscisId: string;
  submissionId: string;
  userGroupId: string;
}

export interface SubmissionStatusState {
  response: SubmissionStatusResponse | null;
  loading: boolean;
  error: string | null;
}

export const fetchSubmissionStatus = createAsyncThunk<
  SubmissionStatusResponse,
  FetchSubmissionStatusParams,
  { rejectValue: string }
>(
  "submissionStatus/fetchStatus",
  async (
    params: { myUscisId: string; submissionId: string; userGroupId: string },
    { rejectWithValue },
  ) => {
    const { myUscisId, submissionId, userGroupId } = params;
    try {
      const response = await SubmissionService.getSubmissionStatus(
        myUscisId,
        submissionId,
        userGroupId,
      );
      return response;
    } catch (err) {
      return rejectWithValue(
        err instanceof Error ? err.message : "Error fetching submission status",
      );
    }
  },
);

const initialState: SubmissionStatusState = {
  response: null,
  loading: false,
  error: null,
};

const submissionStatusSlice = createSlice({
  name: "submissionStatus",
  initialState,
  reducers: {
    clearSubmissionStatus: (state) => {
      state.response = null;
      state.error = null;
      state.loading = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchSubmissionStatus.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSubmissionStatus.fulfilled, (state, action) => {
        state.response = action.payload;
        state.loading = false;
      })
      .addCase(fetchSubmissionStatus.rejected, (state, action) => {
        state.error = action.payload || "Failed to fetch status";
        state.loading = false;
      });
  },
});

export const { clearSubmissionStatus } = submissionStatusSlice.actions;
export default submissionStatusSlice.reducer;
