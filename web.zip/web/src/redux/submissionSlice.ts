import type { PayloadAction, TypedStartListening } from "@reduxjs/toolkit";
import { createSlice, isAnyOf } from "@reduxjs/toolkit";
import { EvidenceGroup, FormTypes } from "../types/FormMetaData";
import {
  FormSpecificInfo,
  Submission,
  SubmissionEvidence,
  SubmissionForm,
} from "../types/Submission";
import {
  EvidenceRequest,
  EvidenceUploadResponse,
  FormRequest,
  FormUploadResponse,
} from "../types/Upload";
import listener from "./listenerMiddleware";
import { AppDispatch, RootState } from "./store";
import {
  Attestation,
  ClientInformation,
  Evidence,
  FeeWaiver,
  FeeWaiverFile,
  Form,
} from "./types/Submission";
import { createSelector } from "reselect";

export interface SubmissionState {
  attestation: Attestation;
  eligibilityCategory: string;
  eligibilitySubcategory: string | undefined;
  eligibilitySubcategories: string[];
  benefitTypeCode: number | undefined;
  applicationReasonCode: number | undefined;
  evidences: Evidence[];
  feeWaiver: FeeWaiver;
  forms: Form[];
  feeTotal: number;

  formHasError: boolean;
  evidenceHasError: boolean;
  formHasWarnings: boolean;

  formType: string;
  isNotFeeExempt: boolean;
  isFeeExempt: boolean;
  userIsEligibleForFeeWaiver: boolean;

  isSubmissionSubmitted: boolean;

  isSignaturePresent: boolean;
  hasReviewedSignature: boolean;

  immvi: boolean;
  reasonForFiling: string;
  reviewed: boolean;
  submissionId: string;
  submissionStatus: string;
  isPollingForAttestationStatus: boolean;
  isPollingForFinalSubmissionStatus: boolean;

  clientInformation?: ClientInformation;
  isUSCitizen?: string;
  formSpecificInfo?: FormSpecificInfo;
  sentNotify: boolean;
  selectedConcurrentForms: FormTypes[];
  showPayAndSubmitInAccordion: boolean;
}

const initialState: SubmissionState = {
  formType: "",
  submissionId: "",
  submissionStatus: "",
  eligibilityCategory: "",
  eligibilitySubcategory: "",
  eligibilitySubcategories: [],
  benefitTypeCode: undefined,
  applicationReasonCode: undefined,
  feeTotal: 0,
  feeWaiver: {
    requested: false,
    files: [],
    partialRequested: false,
  },
  forms: [],
  evidences: [],
  reviewed: false,
  attestation: {
    attested: false,
    attestedAt: "",
    attestationType: "",
    attestationFirstCheckbox: false,
    attestationSecondCheckox: false,
    attestationSignature: "",
  },
  isNotFeeExempt: false,
  isFeeExempt: false,
  userIsEligibleForFeeWaiver: false,
  isSubmissionSubmitted: false,
  immvi: false,
  reasonForFiling: "",
  isSignaturePresent: false,
  showPayAndSubmitInAccordion: false,
  hasReviewedSignature: false,
  formHasError: false,
  evidenceHasError: false,
  formHasWarnings: false,

  isPollingForAttestationStatus: false,
  isPollingForFinalSubmissionStatus: false,
  isUSCitizen: undefined,

  clientInformation: {
    clientId: "",
    submissionId: "",
    attorneyId: "",
    userGroupIds: [],
  },
  sentNotify:false,

  selectedConcurrentForms: [],
};

export const submissionSlice = createSlice({
  name: "submission",
  initialState,
  reducers: {
    setFormType: (state, action: PayloadAction<string>) => {
      state.formType = action.payload;
    },
    setSubmissionId: (state, action: PayloadAction<string>) => {
      state.submissionId = action.payload;
    },
    setFeeTotal: (state, action: PayloadAction<number>) => {
      state.feeTotal = action.payload;
    },
    setSubmissionStatus: (state, action: PayloadAction<string>) => {
      state.submissionStatus = action.payload;
    },
    setEligibilityCategory: (state, action: PayloadAction<string>) => {
      state.eligibilityCategory = action.payload;
    },
    setEligibilitySubcategory: (
      state,
      action: PayloadAction<string | undefined>,
    ) => {
      state.eligibilitySubcategory = action.payload;
    },
    setEligibilitySubcategories: (
      state,
      action: PayloadAction<string[]>,
    ) => {
      state.eligibilitySubcategories = action.payload;
    },
    setBenefitTypeCode: (state, action: PayloadAction<number>) => {
      state.benefitTypeCode = action.payload;
    },
    setApplicationReasonCode: (
      state,
      action: PayloadAction<number | undefined>,
    ) => {
      state.applicationReasonCode = action.payload;
    },
    setFeeWaiverRequested: (state, action: PayloadAction<boolean>) => {
      state.feeWaiver.requested = action.payload;
    },
    setPartialFeeWaiverRequested: (state, action: PayloadAction<boolean>) => {
      state.feeWaiver.partialRequested = action.payload;
    },
    setImmvi: (state, action: PayloadAction<boolean>) => {
      state.immvi = action.payload;
    },
    setUserIsEligibleForFeeWaiver: (state, action: PayloadAction<boolean>) => {
      state.userIsEligibleForFeeWaiver = action.payload;
    },
    setReasonForFiling: (state, action: PayloadAction<string>) => {
      state.reasonForFiling = action.payload;
    },
    setIsNotFeeExempt: (state, action: PayloadAction<boolean>) => {
      state.isNotFeeExempt = action.payload;
    },
    setIsFeeExempt: (state, action: PayloadAction<boolean>) => {
      state.isFeeExempt = action.payload;
    },
    updateFeeWaiverFiles: (state, action: PayloadAction<FeeWaiverFile[]>) => {
      state.feeWaiver.files = action.payload;
    },
    setFormUpload: (
      state,
      action: PayloadAction<{
        request: FormRequest;
        response: FormUploadResponse;
      }>,
    ) => {
      const payload = action.payload;

      const existingForm = (state.forms.find((form) => form.formType === payload.request.formType) as Form);
        
      const newForm: Form = {
        fileName: payload.request.fileName,
        formId: payload.response.formId,
        formType: payload.request.formType,
        dateTime: payload.response.uploadedAt,
        eligibilityCategory: existingForm != undefined ? existingForm.eligibilityCategory : "",
        eligibilitySubcategory: existingForm != undefined ? existingForm.eligibilitySubcategory : "",
        eligibilitySubcategoryList: existingForm != undefined ? existingForm.eligibilitySubcategoryList : [],
        benefitTypeCode: existingForm != undefined ? existingForm.benefitTypeCode : 0,
        applicationReasonCode: existingForm != undefined ? existingForm.applicationReasonCode : 0,
        formSpecificInfo: existingForm.formSpecificInfo,
      };
      if (newForm.formType == state.forms[0].formType) {
        state.forms = state.forms.map((form, index) => 
          index === 0 ? newForm : form
        );  
      }
      else {
        if (newForm.formType === state.formType || state.forms.some((submissions) => newForm.formType === submissions.formType)) {
          state.forms = state.forms.filter((form) => form.formType != newForm.formType)
          state.forms.unshift(newForm);
        } else {
          state.forms.push(newForm);
        }
      }
    },
    resetFormUpload: (state, action: PayloadAction<Form>) => {
      if (action.payload && action.payload.formType) {
        state.forms = state.forms.filter(
          (form) => form.formType !== action.payload.formType,
        );
      }
    },
    setEvidenceConfirmed: (
      state,
      action: PayloadAction<EvidenceGroup["id"]>,
    ) => {
      const payload = action.payload;
      const evidenceGroupIndex = state.evidences.findIndex(
        (evidence) => evidence.evidenceGroup === payload,
      );
      if (evidenceGroupIndex < 0) {
        state.evidences.push({
          evidenceGroup: payload,
          confirmed: true,
          files: [],
        });
      } else {
        state.evidences[evidenceGroupIndex].confirmed = true;
      }
    },
    addEvidenceUpload: (
      state,
      action: PayloadAction<{
        request: EvidenceRequest[];
        evidenceGroup: string;
        response: EvidenceUploadResponse[];
      }>,
    ) => {
      const payload = action.payload;
      const evidenceGroupIndex = state.evidences.findIndex(
        (evidence) => evidence.evidenceGroup === payload.evidenceGroup,
      );
      const uploadedFile = payload.response.map((r, index) => {
        const req = payload.request.filter((req) => req.fileName === r.name)[0];
        return {
          fileName: req.fileName,
          id: r.id as string,
          formId: r.formId,
          dateTime: r.uploadedAt as string,
          hasError: r.hasError ?? false,
          type: req.type,
        };
      });

      if (evidenceGroupIndex < 0) {
        state.evidences.push({
          evidenceGroup: payload.evidenceGroup,
          files: uploadedFile,
        });
      } else {
        state.evidences[evidenceGroupIndex].files.push(...uploadedFile);
      }
    },

    deleteEvidence: (state, action: PayloadAction<string>) => {
      state.evidences.forEach(
        (evidence) =>
          (evidence.files = evidence.files.filter(
            (file) => file.id !== action.payload,
          )),
      );
      state.evidences = state.evidences.filter(
        (evidence) => evidence.files.length > 0,
      );
    },
    deleteFeeWaiver: (state, action: PayloadAction<string>) => {
      state.feeWaiver.files = state.feeWaiver.files.filter(
        (file) => file.id !== action.payload,
      );
    },
    resetEvidenceUpload: (state) => {
      state.evidences = initialState.evidences;
    },
    setClientInformation: (state, action: PayloadAction<ClientInformation>) => {
      state.clientInformation = action.payload;
    },
    setIsUSCitizen: (state, action: PayloadAction<string | undefined>) => {
      state.isUSCitizen = action.payload;
    },
    setUserAttested: (state, action: PayloadAction<boolean>) => {
      state.attestation.attested = action.payload;
    },
    setUserAttestedAt: (state, action: PayloadAction<string>) => {
      state.attestation.attestedAt = action.payload;
    },
    setAttestationSignature: (state, action: PayloadAction<string>) => {
      state.attestation.attestationSignature = action.payload;
    },
    setFirstAttestationSignature: (state, action: PayloadAction<boolean>) => {
      state.attestation.attestationFirstCheckbox = action.payload;
    },
    setSecondAttestationSignature: (state, action: PayloadAction<boolean>) => {
      state.attestation.attestationSecondCheckox = action.payload;
    },
    setIsSubmissionSubmitted: (state, action: PayloadAction<boolean>) => {
      state.isSubmissionSubmitted = action.payload;
    },
    setHasReviewedSignature: (state, action: PayloadAction<boolean>) => {
      state.hasReviewedSignature = action.payload;
    },
    setFormHasError: (state, action: PayloadAction<boolean>) => {
      state.formHasError = action.payload;
    },
    setEvidenceHasError: (state, action: PayloadAction<boolean>) => {
      state.evidenceHasError = action.payload;
    },
    setFormHasWarnings: (state, action: PayloadAction<boolean>) => {
      state.formHasWarnings = action.payload;
    },
    setIsSignaturePresent: (state, action: PayloadAction<boolean>) => {
      state.isSignaturePresent = action.payload;
    },
    setShowPayAndSubmitInAccordion: (state, action: PayloadAction<boolean>) => {
      state.showPayAndSubmitInAccordion = action.payload;
    },
    setReviewed: (state, action: PayloadAction<boolean>) => {
      state.reviewed = action.payload;
    },
    setIsPollingForAttestationStatus: (
      state,
      action: PayloadAction<boolean>,
    ) => {
      state.isPollingForAttestationStatus = action.payload;
    },
    setIsPollingForFinalSubmissionStatus: (
      state,
      action: PayloadAction<boolean>,
    ) => {
      state.isPollingForFinalSubmissionStatus = action.payload;
    },
    setFormSpecificInfo: (state, action: PayloadAction<FormSpecificInfo>) => {
      if(action.payload.formType === state.formType) {
        state.formSpecificInfo = action.payload;
      }
      state.forms.find((form) => form.formType === action.payload.formType)!.formSpecificInfo = action.payload;
    },
    setSentNotify: (state, action: PayloadAction<boolean>) => {
      state.sentNotify = action.payload;
    },
    setSelectedConcurrentForms: (state, action: PayloadAction<FormTypes[]>) => {
      state.selectedConcurrentForms = action.payload;
    },
    setForms: (state, action: PayloadAction<Form[]>) => {
      state.forms = action.payload;
    },
    /** Rehydrates client-side state whenever SubmissionDto received from server */
    hydrateState: (
      state,
      action: PayloadAction<{
        submission: Submission;
        evidenceGroups: EvidenceGroup[];
      }>,
    ) => {
      const submissionPayload = action.payload.submission;
      const formsPayload = submissionPayload.forms || [];
      const feeWaiverPayload = submissionPayload.feeWaiver;
      const evidencePayload = submissionPayload.evidences || [];
      let evidenceList: Evidence[] = [];

      evidencePayload.forEach((evidence) => {
        const foundEvidenceGroup = action.payload.evidenceGroups.find(
          (group) => group.id === evidence.evidenceGroupType,
        );
        const newEvidence = {
          fileName: evidence.name,
          id: evidence.id,
          formId: evidence.formId,
          dateTime: evidence.uploadedAt,
          type: evidence.type,
          hasError: false,
        };

        if (foundEvidenceGroup) {
          const index = evidenceList.findIndex(
            (evidenceListEntry) =>
              evidenceListEntry.evidenceGroup === foundEvidenceGroup.id,
          );

          if (index < 0)
            evidenceList.push({
              evidenceGroup: foundEvidenceGroup.id,
              files: [newEvidence],
            });
          else evidenceList[index].files.push(newEvidence);
        } else {
          const index = evidenceList.findIndex(
            (evidenceListEntry) =>
              evidenceListEntry.evidenceGroup === evidence.evidenceGroupType,
          );

          if (index < 0)
            evidenceList.push({
              evidenceGroup: evidence.evidenceGroupType,
              files: [newEvidence],
            });
          else evidenceList[index].files.push(newEvidence);
        }
      });
      return {
        ...state,
        submissionId: submissionPayload.submissionId,
        submissionStatus: submissionPayload.status,
        formType: submissionPayload.formType,
        eligibilityCategory: submissionPayload.eligibilityCategory || "",
        eligibilitySubcategory: submissionPayload.eligibilitySubcategory,
        eligibilitySubcategories: submissionPayload.eligibilitySubcategories || [],
        benefitTypeCode: submissionPayload.benefitTypeCode,
        applicationReasonCode: submissionPayload.applicationReasonCode,
        feeTotal: submissionPayload.feeTotal,
        immvi: submissionPayload.immvi,
        reasonForFiling:
          submissionPayload.reasonForFiling ?? state.reasonForFiling,
        feeWaiver: hydrateFeeWaiver(
          submissionPayload.userRequestedFeeWaiver,
          submissionPayload.userRequestedPartialFeeWaiver,
          feeWaiverPayload,
        ),
        forms: hydrateForms(formsPayload),
        evidences: evidenceList,
        userRequestedFeeWaiver: submissionPayload.userRequestedFeeWaiver,
        userIsEligibleForFeeWaiver:
          submissionPayload.userIsEligibleForFeeWaiver,
        isSubmissionSubmitted: false,
        isSignaturePresent: false,
        showPayAndSubmitInAccordion: false,
        formHasError: false,
        clientInformation: submissionPayload.clientInformation,
        isUSCitizen: submissionPayload.isUSCitizen,
        formSpecificInfo: submissionPayload.formSpecificInfo ?? state.formSpecificInfo,
        sentNotify: submissionPayload.sentNotify ?? false,
        selectedConcurrentForms: submissionPayload.selectedConcurrentForms ?? []
      };
    },
  },
});

/** Helper method */
function hydrateFeeWaiver(
  requested: boolean,
  partialRequested: boolean,
  fw?: SubmissionEvidence,
): SubmissionState["feeWaiver"] {
  // TODO: Move+rename fields in SubmissionState to make this mapping more straightforward.
  return {
    requested,
    partialRequested,
    files: fw //TODO: ahhh?
      ? [
          {
            id: fw.id,
            fileName: fw.name,
            documentType: fw.type,
            dateTime: fw.uploadedAt,
            isEditable: (fw.isEditable ??= true),
          },
        ]
      : [],
  };
}

/** Helper method */
function hydrateForms(
  submissionForms: SubmissionForm[],
): SubmissionState["forms"] {
  // TODO: Move+rename fields in SubmissionState to make this mapping more straightforward.
  return submissionForms.map((submissionForm) => {
    return {
      formId: submissionForm.id,
      fileName: submissionForm.name,
      formType: submissionForm.type,
      dateTime: submissionForm.uploadedAt,
      eligibilityCategory: submissionForm.eligibilityCategory,
      eligibilitySubcategory: submissionForm.eligibilitySubcategory,
      eligibilitySubcategoryList: submissionForm.eligibilitySubcategoryList,
      benefitTypeCode: submissionForm.benefitTypeCode,
      applicationReasonCode: submissionForm.applicationReasonCode,
      formSpecificInfo: submissionForm.formSpecificInfo
    };
  });
}

export const {
  setFormType,
  setSubmissionId,
  setSubmissionStatus,
  setEligibilityCategory,
  setEligibilitySubcategory,
  setEligibilitySubcategories,
  setBenefitTypeCode,
  setApplicationReasonCode,
  setFeeTotal,
  setFeeWaiverRequested,
  setPartialFeeWaiverRequested,
  setFormUpload,
  addEvidenceUpload,
  setReviewed,
  setUserAttested,
  setUserAttestedAt,
  setAttestationSignature,
  updateFeeWaiverFiles,
  resetFormUpload,
  deleteEvidence,
  deleteFeeWaiver,
  resetEvidenceUpload,
  setIsSubmissionSubmitted,
  setClientInformation,
  setIsUSCitizen,

  setIsSignaturePresent,
  setShowPayAndSubmitInAccordion,
  setHasReviewedSignature,
  setFormHasError,
  setEvidenceHasError,
  setFormHasWarnings,

  hydrateState,
  setEvidenceConfirmed,
  setIsPollingForAttestationStatus,
  setIsNotFeeExempt,
  setIsFeeExempt,
  setIsPollingForFinalSubmissionStatus,
  setImmvi,
  setUserIsEligibleForFeeWaiver,
  setReasonForFiling,
  setFormSpecificInfo,
  setSentNotify,
  setForms,
  setSelectedConcurrentForms,
  setSecondAttestationSignature,
  setFirstAttestationSignature
} = submissionSlice.actions;

const startAppListening = listener.startListening as TypedStartListening<
  SubmissionState,
  AppDispatch
>;
startAppListening({
  matcher: isAnyOf(
    setEligibilityCategory,
    setEligibilitySubcategory,
    setEligibilitySubcategories,
    setBenefitTypeCode,
    setApplicationReasonCode,
    setIsUSCitizen,
    setFeeWaiverRequested,
    setPartialFeeWaiverRequested,
    updateFeeWaiverFiles,
    setFormUpload,
    resetFormUpload,
    addEvidenceUpload,
    deleteEvidence,
    deleteFeeWaiver,
    resetEvidenceUpload,
    
  ),
  effect: (_action, listener) => {
    listener.dispatch(setUserAttested(false));
    listener.dispatch(setUserAttestedAt(""));
    listener.dispatch(setAttestationSignature(""));
    listener.dispatch(setSecondAttestationSignature(false))
    listener.dispatch(setFirstAttestationSignature(false))
    listener.dispatch(setReviewed(false));
  },
});

export const selectUserUploadedG28 = createSelector(
  (state: RootState) => state.submission.forms,
  (forms) => forms.some((form) => form.formType === "G-28"),
);

export default submissionSlice.reducer;