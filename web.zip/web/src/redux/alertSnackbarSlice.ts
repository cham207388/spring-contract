import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { AlertColor } from "@mui/material";

export interface SnackbarAlert {
  message: string;
  severity: AlertColor;
}

export interface SnackbarSlice {
  alerts: SnackbarAlert[];
}

const initialState: SnackbarSlice = {
  alerts: [],
};
export const alertSnackbarSlice = createSlice({
  name: "alertSnackbarSlice",
  initialState,
  reducers: {
    pushAlert: (
      state,
      action: PayloadAction<{
        message: string;
        severity: AlertColor;
      }>,
    ) => {
      state.alerts.push(action.payload);
    },
    popAlert: (state) => {
      state.alerts.pop();
    },
    reset: (state) => {
      state.alerts = [];
    },
  },
});

export const { pushAlert, popAlert, reset } = alertSnackbarSlice.actions;
export default alertSnackbarSlice.reducer;
