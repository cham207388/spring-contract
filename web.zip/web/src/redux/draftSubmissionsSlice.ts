import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { Submission } from "../types/Submission";

export interface DraftSubmissions {
  draftSubmissions: Submission[];
  isDraftSubmissionDeleted: boolean;
  isDraftSubmissionContinued: boolean;
}
const initialState: DraftSubmissions = {
  draftSubmissions: [],
  isDraftSubmissionDeleted: false,
  isDraftSubmissionContinued: false,
};
export const dratfSubmissionsSlice = createSlice({
  name: "draftSubmissions",
  initialState,
  reducers: {
    setDraftSubmissions: (state, action: PayloadAction<Submission[]>) => {
      state.draftSubmissions = action.payload;
    },
    setIsDraftSubmissionDeleted: (state, action: PayloadAction<boolean>) => {
      state.isDraftSubmissionDeleted = action.payload;
    },
    setIsDraftSubmissionContinued: (state, action: PayloadAction<boolean>) => {
      state.isDraftSubmissionContinued = action.payload;
    },
  },
});

export const {
  setDraftSubmissions,
  setIsDraftSubmissionDeleted,
  setIsDraftSubmissionContinued,
} = dratfSubmissionsSlice.actions;
export default dratfSubmissionsSlice.reducer;
