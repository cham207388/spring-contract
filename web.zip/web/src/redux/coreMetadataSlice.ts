import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import { CoreMetaData, EvidenceMap, NewEvidencePage } from "../types/FormMetaData";

export interface CoreMetaDataState extends CoreMetaData {}
const initialState: CoreMetaDataState = {
  paygovMaintenanceEnabled: false,
  betaBanners: [],
  evidencePages: {} as EvidenceMap,
};

export const coreMetaDataSlice = createSlice({
  name: "coreMetaData",
  initialState,
  reducers: {
    setCoreMetaData: (state, action: PayloadAction<CoreMetaData>) => {
      state.paygovMaintenanceEnabled = action.payload.paygovMaintenanceEnabled;
      state.betaBanners = action.payload.betaBanners;
    },
    addEvidenceMetaData: (state, action: PayloadAction<NewEvidencePage>) => {
      console.log("Add evidence page ", action.payload);
      state.evidencePages[action.payload.evidencePageKey] = action.payload.evidencePage;
    },
  }
});

export const { setCoreMetaData, addEvidenceMetaData } =
  coreMetaDataSlice.actions;
export default coreMetaDataSlice.reducer;
