import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import { ObjectValues } from "../types/utility";
import { createSelector } from "reselect";
import { RootState } from "./store";

export const AccountTypes = {
  APPLICANT: "applicant",
  REPRESENTATIVE: "representative",
  REGISTRANT: "registrant"
} as const;


export type AccountType = ObjectValues<typeof AccountTypes>;

export const BeforeYouStartSteps = {
  BEFORE_YOU_START: "before-you-start",
  COMPLETE_YOUR_FORM: "complete-your-form",
  FORM: "form",
} as const;

export type BeforeYouStartStep = ObjectValues<typeof BeforeYouStartSteps>;

export interface UserState {
  myUscisId: string;
  userGroupId: string;
  accountType: AccountType | undefined;
  canUserPayAndSubmit: boolean;
  isUserPartOfOrg: boolean;
  isApplicantOrRep: boolean;
  showDocumentUpload: boolean;
  showCompleteYourForm: boolean;
  showBeforeYouStart: boolean;
  showLogoutConfirmationDialog: boolean;
  currentBeforeYouStartStep: BeforeYouStartStep;
}
const initialState: UserState = {
  myUscisId: "",
  userGroupId: "",
  accountType: undefined,
  canUserPayAndSubmit: false,
  showDocumentUpload: false,
  showCompleteYourForm: false,
  showBeforeYouStart: false,
  isUserPartOfOrg: false,
  isApplicantOrRep: false,
  showLogoutConfirmationDialog: false,
  currentBeforeYouStartStep: BeforeYouStartSteps.BEFORE_YOU_START,
};
export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setMyUscisId: (state: UserState, action: PayloadAction<string>) => {
      state.myUscisId = action.payload;
    },
    setUserGroupId: (state: UserState, action: PayloadAction<string>) => {
      state.userGroupId = action.payload;
    },
    setAccountType: (state: UserState, action: PayloadAction<AccountType>) => {
      state.accountType = action.payload;
    },
    setUserPartOfOrg: (state: UserState, action: PayloadAction<boolean>) => {
      state.isUserPartOfOrg = action.payload;
    },
    setApplicantOrRep: (state: UserState, action: PayloadAction<boolean>) => {
      state.isApplicantOrRep = action.payload;
    },
    setCanUserPayAndSubmit: (state: UserState, action: PayloadAction<boolean>) => {
      state.canUserPayAndSubmit = action.payload;
    },
    setShowDocumentUpload: (
      state: UserState,
      action: PayloadAction<boolean>,
    ) => {
      state.showDocumentUpload = action.payload;
    },
    setShowCompleteYourForm: (
      state: UserState,
      action: PayloadAction<boolean>,
    ) => {
      state.showCompleteYourForm = action.payload;
    },
    setShowBeforeYouStart: (
      state: UserState,
      action: PayloadAction<boolean>,
    ) => {
      state.showBeforeYouStart = action.payload;
    },
    setCurrentBeforeYouStartStep: (
      state: UserState,
      action: PayloadAction<BeforeYouStartStep>,
    ) => {
      state.currentBeforeYouStartStep = action.payload;
    },
    setShowLogoutConfirmationDialog: (
      state: UserState,
      action: PayloadAction<boolean>,
    ) => {
      state.showLogoutConfirmationDialog = action.payload;
    },
  },
});

// Action creators are generated for each case reducer function
export const {
  setMyUscisId,
  setUserGroupId,
  setAccountType,
  setCanUserPayAndSubmit,
  setUserPartOfOrg,
  setApplicantOrRep,
  setShowDocumentUpload,
  setShowCompleteYourForm,
  setShowBeforeYouStart,
  setCurrentBeforeYouStartStep,
  setShowLogoutConfirmationDialog,
} = userSlice.actions;

export const selectIsRepresentative = createSelector(
  (state: RootState) => state.user.accountType,
  (accountType) => accountType === AccountTypes.REPRESENTATIVE,
);

export default userSlice.reducer;
