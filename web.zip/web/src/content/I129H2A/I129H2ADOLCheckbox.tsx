import USCISDivider from "../../components/shared/USCISDivider";

export const I129H2ADOLCheckbox = () => {

    return (
        <>
            <label style={{display: 'flex'}}>
                <input id="agreement_checkbox"
                    name="applicant agreement"
                    style={{
                    position: "relative",
                    margin: "unset",
                    marginRight: "5px",
                    }}
                    type="checkbox" />
                    If I have selected this box, I am certifying that I have received a notice of acceptance from the Department of Labor for the 
                    ETA Case Number identified in Part 5., Item Number 2. and am not required to submit the temporary labor certification at the time of filing.
            </label>
            <USCISDivider />
        </>
    );
}
