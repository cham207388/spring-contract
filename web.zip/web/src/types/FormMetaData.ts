/* eslint-disable no-unused-vars */
import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { EvidenceDropzoneProps } from "./Dropzone";

export interface FormMetaData {
  formType: string;
  formDescription: string;
  feeWaiverEnabled: boolean;
  elisEsignFlowEnabled: boolean;
  enabled: boolean;
  showBanner: boolean;
  representativeEnabled: boolean;
  editions: FormEdition[];
  eligibilityCategories: EligibilityCategory[];
  pages: Pages;
  concurrentFormTypes: FormTypes[];
}

interface Pages {
  beforeYouStart: ContentSection;
  completeYourForm: CompleteYourFormSection;
  eligibility: DropdownContent;
  uploadForm: UploadForm;
}

export interface ContentSection {
  title: string;
  description: string;
  beforeYouStartCategories: ContentCategory[];
  afterYouFileCategories: ContentCategory[];
}

export interface CompleteYourFormSection {
  title: string;
  categories: Omit<ContentCategory, "accordionCategories">[];
  notices: Pick<ContentCategory, "title" | "body">[];
}

export interface ContentCategory {
  title: string;
  body: string;
  icon?: IconProp;
  orgSpecificText?: string;
  accordionCategories?: AccordionCategory[];
}

export interface DropdownContent {
  header: string;
}

export interface UploadForm {
  additionalInfoPartNumber?: string;
  optionalLinkText?: string;
  pageMarkdown?: string;
}

interface AccordionCategory {
  title: string;
  id: string;
  body: string;
}

export interface FormEdition {
  numberOfPages: number;
  edition: string;
  ombNo: string;
  expires: string;
}

export interface BetaBanner {
  bannerText: string;
  formType: string;
  showBanner: boolean;
  showBannerFor: string;
}

export interface EvidencePage {
  component: string;
  dropzoneProps: EvidenceDropzoneProps;
}

export type EvidenceMap = Record<string, EvidencePage>;

export type NewEvidencePage = {
  evidencePageKey: string,
  evidencePage: EvidencePage
}

export type EvidencePageMetadataResponse = {
  evidencePages: EvidenceMap;
};

export interface CoreMetaData {
  paygovMaintenanceEnabled: boolean;
  betaBanners: BetaBanner[];
  evidencePages: EvidenceMap;
}

// export interface PaygovMaintenance {
//     start: string;
//     end: string;
// }

export type EvidenceGroup = {
  id: string;
  name: string;
  evidenceTypes: EvidenceType[];
  validations: string[];
  maxNumberOfFiles: number;
  allowMediaTypes: string[];
};

export type EvidenceType = {
  id: string;
  name: string;
};

export type EligibilityCategory = {
  category: string;
  label: string;
  code: number;
  benefitTypeCode: string;
  applicationReasonCode: string;
  metaData: EligibilityCategoryMetadata;
};

export type ActionRequestedOption = {
  category: string;
  label: string;
  evidenceCategoriesToExclude: string[];
}

export type EligibilitySubcategory = {
  category: string;
  label: string;
  disabled: boolean;
  filterValue: string;
  evidenceCategoriesToExclude: string[];
  evidenceGroupsToInclude: EvidenceGroup[];
  feeWaivable: boolean;
  applicationReasonCode: string;
  immigrationClassCode: string;
  benefitTypeCodeOverride: string;
  actionRequestedOptions: ActionRequestedOption[];
};

export type EligibilityCategoryMetadata = {
  feeWaivable: boolean;
  feeExemptable: boolean;
  evidenceGroups: EvidenceGroup[];
  feeExemptQuestions: string;
  subCategoryHeader: string;
  subcategories: EligibilitySubcategory[];
  disabled: boolean;
  roleTypes:  string[]
  excludeForParentFormTypes: string[];
};

export enum N400Codes {
  GENERAL_PROVISION = "191",
  SPOUSE_OF_US_CITIZEN = "192",
  VAWA = "189",
  SPOUSE_OF_ABROAD_US_CITIZEN = "193",
  MILITARY_DURING_HOSTILITIES = "194",
  MILITARY_ONE_YEAR_HONORABLE = "190",
  OTHER = "195",
}

export enum FormTypes {
  I129R = "I-129R",
  I129H1B = "I-129H1B",
  I129H2A = "I-129H2A",
  I129TN = "I-129TN",
  I129E = "I-129E",
  I129CW = "I-129CW",
  I129E3 = "I-129E3",
  I129H3 = "I-129H3",
  I129L = "I-129L",
  I129OP = "I-129OP",
  I129Q = "I-129Q",
  I129S = "I-129S",
  I129H2B = "I-129H2B",
  I765 = "I-765",
  N400 = "N-400",
  I130 = "I-130",
  I131 = "I-131",
  I140 = "I-140",
  I751 = "I-751",
  I907 = "I-907",
  I485 = "I-485",
  I485A = "I-485A",
  I485J = "I-485J",
  I90 = "I-90",
  I539 = "I-539",
  I360 = "I-360"
}

export enum OrganizationFormTypes {
  I129H1B = FormTypes.I129H1B,
  I129H2A = FormTypes.I129H2A,
  I129TN = FormTypes.I129TN,
  I129E = FormTypes.I129E,
  I129R = FormTypes.I129R,
  I129CW = FormTypes.I129CW,
  I129E3 = FormTypes.I129E3, 
  I129H3 = FormTypes.I129H3,
  I129L = FormTypes.I129L,
  I129O = FormTypes.I129OP,
  I129Q = FormTypes.I129Q,
  I129S = FormTypes.I129S,
  I129H2B = FormTypes.I129H2B,
  I140 = FormTypes.I140,
}

export enum FormDescriptions {
  I765 = "Application for Employment Authorization",
}
