export const I485SubTypes = {
  FAMILY_BASED: "FAMILY_BASED",
  EMPLOYMENT_BASED: "EMPLOYMENT_BASED", 
 
} as const;