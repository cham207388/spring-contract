export interface SubmissionStatusResponse {
  submissionErrors: string[];
  formErrors: ErrorGroup[];
  evidenceErrors: ErrorGroup[];
}

export interface ErrorGroup {
  type: string;
  errors: string[];
  formType: string;
}
