import { ObjectValues } from "./utility";

export const I140PetitionTypes = {
  EXTRAORDINARY_ABILITY: "ExtraordinaryAbility",
  OUTSTANDING_PROFESSOR: "OutstandingProfessor",
  MULTINATIONAL_EXECUTIVE: "MultinationalExecutive",
  MEMBER_OF_PROFESSIONS: "MemberOfProfessionsHoldingAnAdvancedDegree",
  PROFESSIONAL: "Professional",
  SKILLED_WORKER: "SkilledWorker",
  ANY_OTHER_WORKER: "AnyOtherWorker",
  ALIEN_APPLYING_FOR_NIW: "AlienApplyingForNiw"
} as const;


export const I140ScheduleAPetitionTypes = {
  MEMBER_OF_PROFESSIONS: "MemberOfProfessionsHoldingAnAdvancedDegree",
  PROFESSIONAL: "Professional",
  SKILLED_WORKER: "SkilledWorker",
} as const;


export type I140ScheduleAPetitionType = ObjectValues<typeof I140ScheduleAPetitionTypes>;
export const I140ScheduleAPetitionTypeList: string[] = Object.values(I140ScheduleAPetitionTypes);
