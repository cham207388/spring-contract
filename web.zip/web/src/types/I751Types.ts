export const I751EligiilityCategories = {
  WAIVER_OR_INDIVIDUAL_FILING: "WaiverOrIndividualFiling",
  MY_PARENT_SPOUSE: "MyParentSpouse",
  SPOUSE: "Spouse"
} as const;

export const I751EligiilitySubcategories = {
  ACTIVE_MILITARY_OR_GOVERNMENT_ORDERS: "ACTIVE_MILITARY_OR_GOVERNMENT_ORDERS",
  SPOUSE_DECEASED: "SpouseDeceased", 
  DIVORCE_ANNULMENT: "DivorceAnnulment", 
  GOOD_FAITH_SPOUSE_EXTREME_CRUELTY: "GoodFaithSpouseExtremeCruelty",
  PARENT_GOOD_FAITH_EXTREME_CRUELTY: "ParentGoodFaithExtremeCruelty",
  EXTREME_HARDSHIP: "ExtremeHardship"
} as const;