export type ToggleState = Record<string, boolean>;

export type AddToggle = {
  toggleCode: string,
  toggleEnabled: boolean
}