export type EsignData = {
  esignDate: Date;
  applicantFullName: string;
  timeZone: string;
  browserInformation: string;
  ipAddress: string;
};
