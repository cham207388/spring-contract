export interface UpdateFeeWaiverEvidenceRequest {
  type: string;
}
