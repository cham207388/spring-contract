import { ObjectValues } from "./utility";

export const VALIDATION_STATUS = {
  IN_PROGRESS: "IN_PROGRESS",
  COMPLETE: "COMPLETE",
  AWAITING: "AWAITING",
} as const;

export type ValidationStatus = ObjectValues<typeof VALIDATION_STATUS>;

export interface EligibilityCategoryWarning {
  categoryOnSubmission?: string;
  categoryOnForm?: string;
}

/* eslint-disable no-unused-vars */
export enum Validators {
  CORE = "CORE",
  SIGNATURE = "SIGNATURE",
  ELIGIBILITY_CATEGORY = "ELIGIBILITY_CATEGORY",
  REASON_FOR_FILING = "REASON_FOR_FILING",
  PERSON = "PERSON",
  I912 = "I912",
  G28_COMP = "G28_COMP",
  G28_COMP_NAME = "G28_COMP_NAME",
  G28_NAME_EMAIL = "G28_NAME_EMAIL",
  ADDRESS = "ADDRESS",
  G28_ATTORNEY_NAME = "G28_ATTORNEY_NAME",
  PFVS = "PFVS",
}

export enum ValidationResults {
  PASS = "PASS",
  FAIL = "FAIL",
  WARN = "WARN",
}
export interface ValidationDetails {
  validator: Validators;
  result: ValidationResults;
  reasons: string[];
  warnings?: { [key: string]: string };
}

export interface Validation {
  groupType: string;
  id: string;
  status: ValidationStatus;
  details: ValidationDetails[];
}

export interface ValidationStatusResponse {
  status: ValidationStatus;

  formValidations: Validation[];
  evidenceValidations: Validation[];
  i912FeeWaiverValidation?: ValidationDetails;
}

const COMPLETE = "COMPLETE";
export function isAllValidationsComplete(
  response: ValidationStatusResponse,
  isEvidence: boolean = false,
) {
  //if (isEvidence) return response.evidences.every((i) => COMPLETE === i.status);
  return COMPLETE === response.status;
}
