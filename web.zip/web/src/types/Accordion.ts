import { ObjectValues } from "./utility";

export const ACCORDION_HEADERS = {
  GETTING_STARTED: "Getting Started",
  CLIENT_INFORMATION: "Client Information",
  UPLOAD_PDF: "Upload PDF",
  EVIDENCE: "Evidence",
  REVIEW_SUBMIT: "Review & Submit",
} as const;

export type AccordionHeaders = ObjectValues<typeof ACCORDION_HEADERS>;
