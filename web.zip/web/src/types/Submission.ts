import { ClientInformation } from "../redux/types/Submission";
import { FormTypes } from "./FormMetaData";

export type Submission = {
  myUscisId: string;
  submissionId: string;
  formType: string;
  eligibilityCategory: string;
  eligibilitySubcategory: string;
  eligibilitySubcategories: string[];
  benefitTypeCode: number;
  applicationReasonCode: number;
  manifestId: string;
  status: SubmissionStatus;
  lockboxStatus: LockboxStatuses;
  lockboxErrors: ManifestError[];
  feeTotal: number;
  timestamp: string;
  updatedAt: string;
  forms: SubmissionForm[];
  evidences: SubmissionEvidence[];
  feeWaiver: SubmissionEvidence;
  userRequestedFeeWaiver: boolean;
  userRequestedPartialFeeWaiver: boolean;
  userIsEligibleForFeeWaiver: boolean;
  attested: boolean;
  attestedAt: string;
  attestationSignature: string;
  applicant: UserInformation;
  hasReviewedSignature: boolean;
  immvi: boolean;
  reasonForFiling: string;
  transmissionStatus: FinalTransmissionStatus;
  clientInformation?: ClientInformation;
  isUSCitizen?: ObjectValues<typeof RESIDENCY_STATUS>;
  formSpecificInfo?: FormSpecificInfo;
  sentNotify: boolean;
  orgMyUscisId: string;
  selectedConcurrentForms: FormTypes[];
};

export interface ConcurrentSubmission {
  formType: string;
  eligibilityCategory: string | undefined;
  eligibilitySubcategory: string | undefined;
  benefitTypeCode: number;
  applicationReasonCode: number | undefined;
  evidences: SubmissionEvidence[];
}

export interface FormSpecificInfo {
  formType: string;
  isUnderOrders?: boolean;
  isScheduleA?: boolean;
  dolNumber?: string;
  isMilitaryVeteran?: boolean;
  isApplicantUnder17Unmarried?: boolean;
  isSpouseOfLegalizedAlien?: boolean;
  isUnmarriedChildUnder21?: boolean;
  Immvi?: boolean
  before04012024?: boolean | null
  onOrAfterApril012024?: boolean | null
  actionRequested?: string;
  isFamilyBased?: boolean;
  isCapEnabled?: boolean;
  isCapGap?: boolean;
  isOnlyApplicantApplying?: boolean;
}

export interface ManifestError {
  id: string;
  errorCode: string;
  description: string;
}

export interface SubmissionForm {
  type: string;
  eligibilityCategory: string;
  eligibilitySubcategory: string;
  eligibilitySubcategoryList: string[];
  benefitTypeCode: Number;
  applicationReasonCode: Number;
  id: string;
  name: string;
  feeTotal: number;
  md5Hash: string;
  paymentTrackingId: string;
  lockboxStatus: string;
  validations: string[];
  rejectionReasons: RejectionReason[];
  uploadedAt: string;
  formSpecificInfo: FormSpecificInfo;
}

export interface SubmissionEvidence {
  type: string;
  evidenceGroupType: string;
  id: string;
  formId?: string;
  name: string;
  md5Hash: string;
  uploadedAt: string;
  isEditable?: boolean;
}
export interface UserInformation {
  myUscisId: string;
  email: string;
  accountType: string;
}

export interface RejectionReason {
  code: string;
  reason: string;
}

const SUBMISSION_STATUS = {
  DRAFT: "DRAFT",
  PUBLISHED: "PUBLISHED",
  ACCEPTED: "ACCEPTED",
  REJECTED: "REJECTED",
  RECEIVED: "RECEIVED",
} as const;

type ObjectValues<T> = T[keyof T];

export type SubmissionStatus = ObjectValues<typeof SUBMISSION_STATUS>;

const LOCKBOX_STATUS = {
  RECEIVED: "RECEIVED",
  REJECTED: "REJECTED",
  ACCEPTED: "ACCEPTED",
  PROCESSING: "PROCESSING",
  PENDING: "PENDING",
  ERROR: "ERROR",
} as const;

export type LockboxStatuses = ObjectValues<typeof LOCKBOX_STATUS>;

export const FINAL_TRANSMISSION_STATUS_ENUM = {
  SUCCESS: "SUCCESS",
  FAILURE: "FAILURE",
  IN_PROGRESS: "IN_PROGRESS",
} as const;

export const RESIDENCY_STATUS = {
  USC: "USC",
  LPR: "LPR",
} as const;

export interface FinalTransmissionStatus {
  status: ObjectValues<typeof FINAL_TRANSMISSION_STATUS_ENUM>;
  message: string;
}
