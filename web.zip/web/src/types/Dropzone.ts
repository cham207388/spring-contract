import { ObjectValues } from "./utility";

export const FileExtension = {
  JPEG: ".jpeg",
  JPG: ".jpg",
  TIFF: ".tiff",
  TIF: ".tif",
  PNG: ".png",
  PDF: ".pdf",
} as const;

const acceptedMimeTypes = {
  image: "image/jpeg",
  pdf: "application/pdf",
} as const;

export const possibleFileTypes = {
  jpegTiff: [
    FileExtension.JPEG,
    FileExtension.JPG,
    FileExtension.TIF,
    FileExtension.TIFF,
  ],
  jpegPng: [FileExtension.JPEG, FileExtension.PNG, FileExtension.JPG],
  images: [
    FileExtension.JPEG,
    FileExtension.JPG,
    FileExtension.TIF,
    FileExtension.TIFF,
    FileExtension.PNG,
  ],
  pdf: [FileExtension.PDF],
};

export type AcceptedMimeTypes = ObjectValues<typeof acceptedMimeTypes>;

export interface DropzoneProps {
  maxSize: number;
  maxFiles: number;
  isFeeWaiverSupport?: boolean;
  validated?: boolean;
  accept: Partial<Record<AcceptedMimeTypes, string[]>>;
}

export interface EvidenceDropzoneProps {
  maxSize: number;
  isFeeWaiverSupport?: boolean;
  validated?: boolean;
  maxDrop: number;
  maxUploads: number;
  accept: Partial<Record<AcceptedMimeTypes, string[]>>;
}
