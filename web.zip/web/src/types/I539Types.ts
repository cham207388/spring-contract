export const I539DerivativeAlertCategories = {
  E1: "E1",
  E2: "E2",
  E2C: "E2C",
  E3: "E3",
} as const;

export const I539DerivativeAlertSubCategories = {
  EXTENSION_OF_STAY_IN_CURRENT_STATUS: "EXTENSION_OF_STAY_IN_CURRENT_STATUS",
} as const;