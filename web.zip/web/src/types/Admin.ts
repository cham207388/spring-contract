export type Admin = {
  lastName: string;
  firstName: string;
  uuid: string
}