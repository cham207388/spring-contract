export interface ClientRequest {
  formData: FormData;
  myUscisId: string;
  icam_user_role: string;
}
//interface userData {}
