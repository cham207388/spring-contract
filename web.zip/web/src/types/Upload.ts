export interface FormRequest {
  fileName: string;
  isForm: boolean;
  type: string;
  formType: string;
}

export interface UploadRequest {
  formData: FormData;
  myUscisId: string;
  submissionId: string;
  selectedFormType?: string;
}

export interface EvidenceRequest {
  fileName: string;
  type: string;
  evidenceGroupType: string;
}
export interface FeeWaiverRequest {
  fileName: string;
}

export interface FormUploadResponse {
  formId: string;
  uploadedAt: string;
}

export interface EvidenceUploadResponse {
  id?: string;
  formId?: string;
  name?: string;
  uploadedAt?: string;
  hasError?: boolean;
  errors?: ElisPhotoValidationError[];
}
export interface ElisPhotoValidationError {
  code: string;
  message: string;
  correlationID: string;
  field: string;
}

export interface PaymentAuthorizationStatus {
  status: "Authorized" | "NotAuthorized";
}
