import {
  faFacebook,
  faInstagram,
  faLinkedinIn,
  faTwitter,
  faYoutube,
} from "@fortawesome/free-brands-svg-icons";
import { faEnvelope, IconDefinition } from "@fortawesome/free-solid-svg-icons";
import { AccountTypes } from "../redux/userSlice";

// Header
export const applicantAccountSpecificActions: AccountAction[] = [
  { name: "Home", url: (id?: string) => `/account/applicant` },
  {
    name: "Settings",
    url: (id?: string) => "/account/applicant/settings",
  },
];

export const repAccountSpecificActions: AccountAction[] = [
  { name: "Home", url: (id?: string) => `/accounts` },
  {
    name: "My Profile",
    url: (id?: string) => "/accounts/my-profile",
  },
  {
    name: "Inbox",
    url: (id?: string) => "/secure-messaging/representative/inquiries",
  },
];

export const citizenshipLinks: AccountAction[] = [
  {
    name: "Find an English or citizenship class",
    url: () => "https://www.uscis.gov/citizenship/findcitizenshiphelp",
    newPage: true,
  },
  {
    name: "Learn about the naturalization process",
    url: () => `/citizenship/what_to_expect`,
    newPage: false,
  },
  {
    name: "Learn about citizenship rights and responsibilities",
    url: () => `/citizenship/information`,
    newPage: false,
  },
];

export type AccountAction = {
  name: string;
  url: (id?: string) => string;
  newPage?: boolean;
  iconName?: IconDefinition;
};

export const repActions: AccountAction[] = [
  {
    name: "My Clients",
    url: (id) => `/accounts/${id}/my-clients/companies/manage-companies`,
    newPage: false,
  },
  {
    name: "File a form online",
    url: (id) => `/accounts/${id}/file-form`,
    newPage: false,
  },
  {
    name: "My legal team",
    url: (id) => `/accounts/${id}/my-team`,
    newPage: false,
  },
  {
    name: "View withdrawn G-28s",
    url: () => `/accounts/withdrawn-g28s`,
    newPage: false,
  },
  {
    name: "Change your client's address",
    url: () => `/accounts/change-of-address/start/overview`,
    newPage: false,
  },
  {
    name: "Reschedule biometrics",
    url: () => `/accounts/biometrics/overview`,
    newPage: false,
  },
  {
    name: "Archived H-1B registrations",
    url: (id) => `/accounts/${id}/my-cases/h-1b-registrations/archived`,
    newPage: false,
  },
];
export const applicantActions: AccountAction[] = [
  {
    name: "Add a case to your account",
    url: () => `/account/onboarding/track/new`,
    newPage: false,
  },
  {
    name: "File a form online",
    url: () => `/account/onboarding/filing/new`,
    newPage: false,
  },
  {
    name: "Pay a fee online",
    url: () => `/account/pay-fees`,
    newPage: false,
  },
  {
    name: "Enter a representative passcode",
    url: () => `/account/onboarding/add_representative/new`,
    newPage: false,
  },
  {
    name: "Verify your identity",
    url: () => `/uscis-immigrant-fee/verify-identity`,
    newPage: true,
  },
  {
    name: "Reschedule Biometrics",
    url: () => `/accounts/biometrics/overview`,
    newPage: false,
  },
  {
    name: "Change your address",
    url: () => `/accounts/change-of-address/start/overview`,
    newPage: false,
  },
];

export const askLinks: AccountAction[] = [
  {
    name: "Schedule an appointment",
    url: () => `/appointment/v2`,
    newPage: false,
  },

  {
    name: "Ask about missing mail ",
    url: () => "https://egov.uscis.gov/e-Request/Intro.do",
    newPage: true,
  },
  {
    name: "Correct a typographical error ",
    url: () =>
      "https://egov.uscis.gov/e-request/displayTypoForm.do?entryPoint=init&sroPageType=typoError",
    newPage: true,
  },
  {
    name: "How to avoid immigration scams ",
    url: () => "https://www.uscis.gov/avoid-scams",
    newPage: true,
  },
];

export const toolLinks: AccountAction[] = [
  {
    name: "Find a doctor",
    url: () => "https://www.uscis.gov/tools/find-a-civil-surgeon",
    newPage: true,
  },

  {
    name: "Explore my options",
    url: () => "https://www.uscis.gov/forms/explore-my-options",
    newPage: true,
  },
];

export const allLinks = [
  {
    title: "Account Actions",
    links: applicantActions,
    userRole: AccountTypes.APPLICANT,
  },
  {
    title: "Account Actions",
    links: repActions,
    userRole: AccountTypes.REPRESENTATIVE,
  },
  { title: "Ask USCIS", links: askLinks },
  { title: "Tools", links: toolLinks },
  { title: "Citizenship", links: citizenshipLinks },
];

export const resourceLinks = [
  { title: "Ask USCIS", links: askLinks },
  { title: "Tools", links: toolLinks },
  { title: "Citizenship", links: citizenshipLinks },
];

// Footer
export const internalRowLinks: AccountAction[] = [
  { name: "Topics", url: () => "https://www.uscis.gov/topics" },
  { name: "Citizenship", url: () => "https://www.uscis.gov/citizenship" },
  {
    name: "Schedule an Appointment",
    url: () => `/appointment/v2`,
  },
  {
    name: "Find a Doctor",
    url: () => "https://www.uscis.gov/tools/find-a-civil-surgeon",
  },
  {
    name: "Find a Class",
    url: () => "https://www.uscis.gov/citizenship/findcitizenshiphelp",
  },
];

export const socialLinks: AccountAction[] = [
  {
    name: "facebook",
    iconName: faFacebook,
    url: () => "https://www.facebook.com/uscis",
  },
  {
    name: "twitter",
    iconName: faTwitter,
    url: () => "https://www.twitter.com/uscis",
  },
  {
    name: "linkedin",
    iconName: faLinkedinIn,
    url: () => "https://www.linkedin.com/company/uscis",
  },
  {
    name: "instagram",
    iconName: faInstagram,
    url: () => "https://www.instagram.com/uscis",
  },
  {
    name: "youtube",
    iconName: faYoutube,
    url: () => "https://www.youtube.com/uscis",
  },
  {
    name: "email",
    iconName: faEnvelope,
    url: () =>
      "https://public.govdelivery.com/accounts/USDHSCIS/subscriber/new",
  },
];

export const externalRowLinks: AccountAction[] = [
  { name: "About USCIS", url: () => "https://www.uscis.gov/about-us" },
  {
    name: "Accessibility",
    url: () => "https://www.uscis.gov/website-policies/accessibility",
  },
  {
    name: "Budget and Performance",
    url: () => "https://www.uscis.gov/about-us/budget-planning-and-performance",
  },
  {
    name: "DHS Components",
    url: () => "https://www.uscis.gov/website-policies/dhs-component-websites",
  },
  {
    name: "FOIA Requests",
    url: () =>
      "https://www.uscis.gov/records/request-records-through-the-freedom-of-information-act-or-privacy-act",
  },
  {
    name: "No FEAR Act Data",
    url: () =>
      "https://www.uscis.gov/about-us/equal-employment-opportunity/equal-employment-opportunity-data-posted-pursuant-to-the-no-fear-act",
  },
  {
    name: "Privacy and Legal Disclaimers",
    url: () =>
      "https://www.uscis.gov/website-policies/privacy-and-legal-disclaimers",
  },
  { name: "Site Map", url: () => "https://www.uscis.gov/sitemap" },
  {
    name: "Office of the Inspector General",
    url: () => "https://www.oig.dhs.gov/",
  },
  { name: "The White House", url: () => "https://www.whitehouse.gov/" },
  { name: "USA.gov", url: () => "https://www.usa.gov/" },
];
