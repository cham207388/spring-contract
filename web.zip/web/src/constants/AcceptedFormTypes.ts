import { ObjectValues } from "../types/utility";

const AcceptedFormTypes = {
  I_129H2A: "I-129H2A",
  I_129H1B: "I-129H1B",
  I_129TN: "I-129TN",
  I_129E: "I-129E",
  I_129R: "I-129R",
  I_129CW: "I-129CW",
  I_129E3: "I-129E3",
  I_129H3: "I-129H3",
  I_129L: "I-129L",
  I_129OP: "I-129OP",
  I_129Q: "I-129Q",
  I_129S: "I-129S",
  I_129H2B: "I-129H2B",
  I_765: "I-765",
  N_400: "N-400",
  I_130: "I-130",
  I_140: "I-140",
  I_131: "I-131",
  I_751: "I-751",
  I_907: "I-907",
  I_485: "I-485",
  I_485A: "I-485A",
  I_485J: "I-485J",
  I_90: "I-90",
  I_539: "I-539",
  I_360: "I-360",
} as const;

export const acceptedFormTypesList: string[] = Object.values(AcceptedFormTypes);
export type FormTypes = ObjectValues<typeof AcceptedFormTypes>;
export default AcceptedFormTypes;
