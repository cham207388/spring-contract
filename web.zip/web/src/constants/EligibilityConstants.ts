export const C11_PAROLE = "C11 - Parole";
export const C9 = "C9";
export const PARENT = "US_CITIZEN_PETITION_FOR_PARENT";
export const CHILD = "PETITION_FOR_CHILD";
export const SPOUSE = "PETITION_FOR_SPOUSE";
export const SPOUSE_APP_REASON = "39";
