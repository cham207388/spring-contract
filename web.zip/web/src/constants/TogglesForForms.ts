import AcceptedFormTypes from "./AcceptedFormTypes";

export const ToggleCodes = {
  H1B_CAP: "H1B_CAP",
} as const;

export const TogglesForForms = {
  [AcceptedFormTypes.I_129H1B] : [
    ToggleCodes.H1B_CAP
  ]
}