import { createBrowserRouter, redirect } from "react-router-dom";
import DocumentUpload from "../components/DocumentUpload";
import ErrorBoundary from "../components/ErrorBoundary";
import { EvidenceContainer } from "../components/EvidenceContainer";
import ExternalRedirect from "../components/ExternalRedirect";
import Layout from "../components/Layout/Layout";
import ProtectedRoute from "../components/ProtectedRoute";
import { ApplicationSummary } from "../pages/ApplicationSummary";
import EligibilityCategory from "../pages/EligibilityCategory";
import { PayAndSubmit } from "../pages/PayAndSubmit";
import { PaymentSummaryScreen } from "../pages/PaymentSummary";
import { ReviewSignature } from "../pages/ReviewSignature";
import { ReviewSubmission } from "../pages/ReviewSubmission";
import { SuccessfulSubmission } from "../pages/SuccessfulSubmission";
import UploadPdf from "../pages/UploadPdf";
import YourSignature from "../pages/YourSignature";
import {
  g28MetadataLoader,
  paymentSummaryLoader,
  beforeYouStartLoader,
  submissionLoader,
  concurrentFormMetadataLoader,
  evidenceMetadataLoader
} from "./loaders";
import FeeWaiver from "../pages/FeeWaiver";
import { Paths } from "./Paths";
import ClientInformationPage from "../components/ClientInformation";
import BeforeYouStartPage from "../pages/before-you-start";
import UploadG28Pdf from "../components/UploadG28Pdf";
import NotifyAdministrator from "../pages/NotifyAdministrator";
import ConcurrentUploadPdf from "../pages/ConcurrentUploadPdf";

const uploadFormRoutes = [
  {
    path: Paths.form,
    element: <UploadPdf />,
  },
  {
    path: Paths.formG28,
    element: (
      <ProtectedRoute redirectTo={Paths.selectEligibility}>
        <UploadG28Pdf />
      </ProtectedRoute>
    ),
    loader: g28MetadataLoader,
  },
  {
    path: Paths.concurrentForms,
    element: <ConcurrentUploadPdf />,
  },
];

const reviewSubmitRoutes = [
  {
    path: Paths.review,
    element: <ReviewSubmission isMobile={false} />,
    loader: concurrentFormMetadataLoader
  },
  {
    path: Paths.summary,
    element: (
      <ProtectedRoute>
        <ApplicationSummary />
      </ProtectedRoute>
    ),
    loader: concurrentFormMetadataLoader,
  },
  {
    path: Paths.signature,
    element: (
      <ProtectedRoute>
        <YourSignature />
      </ProtectedRoute>
    ),
  },
  {
    path: Paths.certify,
    element: (
      <ProtectedRoute>
        <YourSignature />
      </ProtectedRoute>
    ),
    loader: concurrentFormMetadataLoader,
  },
  {
    path: Paths.reviewSignature,
    element: (
      <ProtectedRoute>
        <ReviewSignature />
      </ProtectedRoute>
    ),
  },
  {
    path: Paths.submit,
    element: (
      <ProtectedRoute>
        <PayAndSubmit />
      </ProtectedRoute>
    ),
  },
  {
    path: Paths.notifyAdministrator,
    element: (
      <ProtectedRoute>
        <NotifyAdministrator />
      </ProtectedRoute>
    )
  }
];

const clientInfoRoutes = [
  {
    path: Paths.clientInfo,
    element: (
      <ProtectedRoute redirectTo={Paths.selectEligibility}>
        <ClientInformationPage />
      </ProtectedRoute>
    ),
  },
];

export const router = createBrowserRouter([
  {
    element: <Layout />,
    errorElement: <ErrorBoundary />,
    children: [
      {
        path: Paths.root,
        element: <ExternalRedirect />,
      },
      {
        path: Paths.landing,
        loader: beforeYouStartLoader,
        element: <BeforeYouStartPage />,
      },
      {
        path: Paths.success,
        element: <SuccessfulSubmission isNotify={false} />,
      },
      {
        path: Paths.notifySuccess,
        element: <SuccessfulSubmission isNotify={true} />
      },
      {
        path: Paths.submission,
        element: <DocumentUpload />,
        loader: submissionLoader,
        children: [
          {
            index: true,
            loader: async () => redirect(Paths.selectEligibility),
          },
          {
            path: Paths.selectEligibility,
            element: <EligibilityCategory isMobile={false} />,
            loader: concurrentFormMetadataLoader
          },
          {
            path: Paths.ableToPay,
            element: <FeeWaiver />,
          },
          ...clientInfoRoutes,
          ...uploadFormRoutes,
          ...reviewSubmitRoutes,
          {
            path: Paths.evidence,
            loader: evidenceMetadataLoader,
            element: (
              //   <ProtectedRoute>
              <EvidenceContainer />
              //   </ProtectedRoute>
            ),
          },
          {
            path: Paths.paymentAuthorizationSummary,
            loader: paymentSummaryLoader,
            element: <PaymentSummaryScreen />,
          },
        ],
      },
    ],
  },
]);
