import { ObjectValues } from "../types/utility";

export const Paths = {
  root: "/pdf-intake",
  landing: "pdf-intake/:formType",
  submission: "pdf-intake/:formType/:submissionId",
  success: "pdf-intake/:formType/success",
  notifySuccess: "pdf-intake/:formType/notify-success",

  // child routes
  selectEligibility: "select-eligibility",
  ableToPay: "able-to-pay",
  form: "form",
  formG28: "form-g28",
  concurrentForms: "concurrent-forms",
  clientInfo: "client-information",
  evidence: ":evidenceId/:selectedFormType/evidence",
  review: "review",
  summary: "summary",
  signature: "signature",
  certify: "certify",
  reviewSignature: "review-signature",
  submit: "submit",
  paymentAuthorizationSummary: "payment/:status",
  notifyAdministrator: "notify-administrator",
  selectConcurrentForms: "concurrent-filing"
} as const;

export type Path = ObjectValues<typeof Paths>;
