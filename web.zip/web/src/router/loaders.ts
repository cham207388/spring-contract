import {
  ActionFunctionArgs,
  Params,
  ParamParseKey,
  LoaderFunction,
} from "react-router-dom";
import { FormService } from "../api/FormService";
import { SubmissionService } from "../api/SubmissionService";
import { store } from "../redux/store";
import { setConcurrentFormMetadata, setFormMetadata } from "../redux/formMetadataSlice";
import { Paths } from "./Paths";
import {
  setMyUscisId,
  setAccountType,
  AccountTypes,
  AccountType,
  setUserGroupId,
  setCanUserPayAndSubmit,
  setApplicantOrRep
} from "../redux/userSlice";
import { CoreService } from "../api/CoreService";
import {
  setCoreMetaData,
  addEvidenceMetaData,
} from "../redux/coreMetadataSlice";
import {
  resetLoader
} from "../redux/loaderSlice";
import { CoreMetaData, FormMetaData, FormTypes } from "../types/FormMetaData";
import { getClientInfoFromUrl } from "../utils/ClientHelper";
import { setUserInOrg } from "../utils/OrgHelper";
import { TogglesForForms } from "../constants/TogglesForForms";
import { ToggleService } from "../api/ToggleService";
import { addToggle } from "../redux/toggleSlice";
import { setSelectedConcurrentForms } from "../redux/submissionSlice";
export interface FormTypeLoaderArgs extends ActionFunctionArgs {
  params: Params<ParamParseKey<typeof Paths.landing>>;
}

export interface TogglesLoaderArgs extends ActionFunctionArgs {
  params: Params<ParamParseKey<typeof Paths.landing>>;
}

interface SubmissionLoaderArgs extends ActionFunctionArgs {
  params: Params<ParamParseKey<typeof Paths.submission>>;
}

interface EvidencePageLoaderArgs extends ActionFunctionArgs {
  params: Params<ParamParseKey<typeof Paths.evidence>>;
}

interface PaymentSummaryLoaderArgs extends ActionFunctionArgs {
  params: Params<ParamParseKey<typeof Paths.paymentAuthorizationSummary>>;
}

const formMetadataLoader: LoaderFunction = async ({
  params,
}: FormTypeLoaderArgs | SubmissionLoaderArgs) => {
  const metadata = await FormService.getFormMetadata(params.formType ?? "");
  store.dispatch(setFormMetadata(metadata));
  return metadata;
};

function hasKey<T extends object>(obj: T, key: PropertyKey): key is keyof T {
  return key in obj;
}

const toggleLoader = async (formType : string) => {
  if (hasKey(TogglesForForms, formType)) {
    for(const toggleCode of TogglesForForms[formType]) {
      const { toggleEnabled, toggleExists } = await ToggleService.checkToggle({formType, toggleCode});
      if(toggleExists) {
        store.dispatch(addToggle({toggleCode, toggleEnabled}));
      }
    }
  }
}

async function hydrateConcurrentFormMetadata(formType: string) {
  let concurrentFormMetadata: FormMetaData[] = [];
  const concurrentFormTypes = await FormService.getConcurrentForms(formType ?? "");
  for (const form of concurrentFormTypes) {
    const metaData = await FormService.getFormMetadata(form);
    concurrentFormMetadata = [...concurrentFormMetadata, metaData];
  }
  store.dispatch(setConcurrentFormMetadata(concurrentFormMetadata));
  return concurrentFormMetadata;
}

export const concurrentFormMetadataLoader: LoaderFunction = async ({
  params,
}: FormTypeLoaderArgs) => {
  return await hydrateConcurrentFormMetadata(params.formType ?? '');
};

const coreMetadataLoader: LoaderFunction = async () => {
  const coreMetadata: CoreMetaData = await CoreService.getCoreMetadata();
  store.dispatch(setCoreMetaData(coreMetadata));
  return coreMetadata;
};


export const evidenceMetadataLoader: LoaderFunction = async ({
  params,
}: EvidencePageLoaderArgs) => {
  const evidenceId = params.evidenceId ?? "";

  const selectEvidencePageMetadata = (state : any, pageKey : string) => state.coreMetadata.evidencePages[pageKey];
  const evidencePageMetadata = selectEvidencePageMetadata(store.getState(), evidenceId);

  if (!evidencePageMetadata){
    CoreService.getEvidenceMetadata(evidenceId ?? "")
      .then(evidencePage => {
        console.log('evidencePage: ', evidencePage)
        store.dispatch(addEvidenceMetaData({
            evidencePageKey: evidenceId,
            evidencePage: evidencePage
        }));
        console.log("Added evidence page ", evidenceId, evidencePage);
      })
  }
  else {
    console.log(`${evidenceId} already in cache, no need to call backend`)
  }
  return params;
};


export const g28MetadataLoader: LoaderFunction = async () => {
  const metadata = await FormService.getFormMetadata("G-28");
  return metadata;
};

export const beforeYouStartLoader: LoaderFunction = async (
  args: FormTypeLoaderArgs,
) => {
  const CONCURRENT_FORMS_QUERY_PARAM = "concurrentForms";

  const searchParams = new URLSearchParams(window.location.search);
  await toggleLoader(args.params.formType || "");
  const primaryFormMetadata = await formMetadataLoader(args);
  await coreMetadataLoader({} as any);
  const { myUscisId } =
    (await SubmissionService.getSessionDetails()) ?? {};

  const orgId = (await SubmissionService.getOrgId(myUscisId)) ?? "";
  let accountType: AccountType = AccountTypes.APPLICANT;

  try {
    accountType = await SubmissionService.retrieveAccountType(myUscisId);
    store.dispatch(setAccountType(accountType));
  } catch {
    store.dispatch(setAccountType(AccountTypes.APPLICANT));
  }
  store.dispatch(setApplicantOrRep(AccountTypes.APPLICANT == accountType || AccountTypes.REPRESENTATIVE == accountType))
  store.dispatch(setMyUscisId(myUscisId));
  store.dispatch(setUserGroupId(orgId));
  const g28Metadata = await g28MetadataLoader({} as any);
  const concurrentFormMetadata = await concurrentFormMetadataLoader(args);
  const isRepresentative = accountType === AccountTypes.REPRESENTATIVE;
  const formType = args.params.formType ?? "";
  const concurrentFormTypes = await FormService.getConcurrentForms(formType);

  let showConcurrentFiling = true;
  const searchParamsConcurrentForms = searchParams.get(CONCURRENT_FORMS_QUERY_PARAM);
  if(searchParamsConcurrentForms) {
    const searchParamsConcurrentFormTypes = searchParamsConcurrentForms.split(',')
      .map(concurrentFormType => concurrentFormType.trim())
      .filter(concurrentFormType => concurrentFormTypes.indexOf(concurrentFormType) >= 0)
      .filter((concurrentFormType): concurrentFormType is FormTypes => Object.values(FormTypes).includes(concurrentFormType as FormTypes));
    if(searchParamsConcurrentFormTypes.length > 0) {
      store.dispatch(setSelectedConcurrentForms(searchParamsConcurrentFormTypes));
      showConcurrentFiling = false;
    }
  }
  const canUserFile = await handleCanAUserFile(
    myUscisId,
    isRepresentative,
    formType,
    accountType,
    searchParams
  );
  return {
    canUserFile,
    g28Metadata,
    primaryFormMetadata,
    concurrentFormMetadata,
    concurrentFormTypes,
    showConcurrentFiling
  };
};

export const submissionLoader: LoaderFunction = async ({
  params,
}: SubmissionLoaderArgs) => {
  await toggleLoader(params.formType || "");
  await coreMetadataLoader({} as any);
  const { myUscisId: userId } =
    (await SubmissionService.getSessionDetails()) ?? "";

  const userGroupId = (await SubmissionService.getOrgId(userId)) ?? "";
  store.dispatch(setUserGroupId(userGroupId));

  const submission = await SubmissionService.getSubmission(
    userId,
    params.submissionId!,
    userGroupId
  );
  if (submission.applicant.accountType !== null) {
    setUserInOrg(submission?.orgMyUscisId, submission.applicant.accountType);
    store.dispatch(setAccountType(submission.applicant.accountType as AccountType));
  }

  const canUserPayAndSubmit = await SubmissionService.canUserPayAndSubmit(
    userId,
    params.submissionId!,
    userGroupId
  );

  const metadata = await FormService.getFormMetadata(submission.formType ?? "");
  hydrateConcurrentFormMetadata(submission.formType ?? "")

  store.dispatch(setFormMetadata(metadata));
  store.dispatch(setCanUserPayAndSubmit(canUserPayAndSubmit));
  store.dispatch(resetLoader());

  return { userId, submission, userGroupId };
};

export const paymentSummaryLoader: LoaderFunction = async ({
  params,
}: PaymentSummaryLoaderArgs) => {
  return params;
};

async function handleCanAUserFile(
  myUscisId: string,
  isRepresentative: boolean,
  formType: string,
  accountType: AccountType,
  params: URLSearchParams
) {
  const clientAndRepInfo = getClientInfoFromUrl(myUscisId, params);
    let canUserFile = true;

  // extract the client ID
  // if it has O- then we are part of an org
  setUserInOrg(clientAndRepInfo?.clientId, accountType);
  if (isRepresentative && clientAndRepInfo && clientAndRepInfo.clientId) {
    canUserFile = await canUserFileForForm(formType, clientAndRepInfo.clientId);
  }

  if (!isRepresentative) {
    canUserFile = await canUserFileForForm(formType, myUscisId);

  }
  return canUserFile;
}

async function canUserFileForForm(formType: string, userId: string) {
  const canUserFile: { result: boolean } = await FormService.canUserFileFor(
    formType,
    userId,
  );

  return canUserFile.result;
}