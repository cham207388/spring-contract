import { useCallback, useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { makeStyles } from "tss-react/mui";
import useId from "@mui/material/utils/useId";
import {
  AlertDescription,
  Button,
  Dropdown,
  Typography,
  RadioButtons,
  DataWrapper,
  FormControlSpacer,
  Box
} from "myuscis-material";
import { useNavigate } from "react-router-dom";


import { C9UpdateRequest, SubmissionService } from "../api/SubmissionService";
import AlertDialog from "../components/Dialogs/AlertDialog";
import EligibilityInformation from "../components/EligibilityInformation";
import NavigationButtons from "../components/NavigationButtons";
import AlertWindow from "../components/shared/AlertWindow";
import USCISDivider from "../components/shared/USCISDivider";
import YesNoChoiceComponent from "../components/YesNoChoice";
import ReasonForFilingComponent from "../components/ReasonForFiling";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";
import { useValidations } from "../hooks/useValidations";
import { RootState, useAppDispatch } from "../redux/store";
import { RESIDENCY_STATUS } from "../types/Submission";
import {
  hydrateState,
  setEligibilityCategory,
  setEligibilitySubcategory,
  setImmvi,
  setFeeWaiverRequested,
  setIsFeeExempt,
  setIsNotFeeExempt,
  setBenefitTypeCode,
  setApplicationReasonCode,
  setReasonForFiling,
  setIsUSCitizen,
  setEligibilitySubcategories,
  setFormSpecificInfo,
} from "../redux/submissionSlice";
import {
  setFormValidations,
  setIsPollingForFormValidation,
  setIsPollingForFeeWaiverValidation,
} from "../redux/validationsSlice";

import { Evidence } from "../redux/types/Submission";
import { FormMetaData, FormTypes, N400Codes } from "../types/FormMetaData";
import {
  setQuestion1Answer,
  setQuestion2Answer,
} from "../redux/c9feeCalculationSlice";
import { useLocation } from "react-router-dom";
import {
  I130Info,
  ParentWarning,
  SpouseWarning,
} from "./eligibility-information/I130Banners";
import I129H2ARequestedAction from "./eligibility-information/I129H2ARequestedAction";
import I751SubCategoryCheckboxes from "../components/I751/I751SubCategoryCheckboxes";
import I751UnderOrdersRadioButtons from "../components/I751/I751UnderOrdersRadioButtons";
import { I751EligiilityCategories } from "../types/I751Types";
import I140ScheduleARadioButtons from "../components/I140/I140ScheduleARadioButtons";
import { AccountType, AccountTypes } from "../redux/userSlice";
import { I140ScheduleAPetitionTypeList } from "../types/I140Types";
import { VALIDATION_STATUS } from "../types/Validations";
import AcceptedFormTypes from "../constants/AcceptedFormTypes";
import I485MilitaryVetSelection from "../components/I485/I485MilitaryVetSelection";
import I485ACheckboxes from "../components/I485A/I485ACheckboxes";
import ActionRequested from "./eligibility-information/ActionRequested";
import I485SubTypeSelection from "../components/I485/I485SubTypeSelection";
import { I485SubTypes } from "../types/I485Types";
import I129H1BCapSelection from "../components/I129H1B/I129H1BCapSelection";
import I539IsOnlyApplicantApplying from "../components/I539/I539IsOnlyApplicantApplying";
import { ToggleCodes } from "../constants/TogglesForForms";
import { useToggles } from "../hooks/useToggles";

import {
  C11_PAROLE,
  C9,
  PARENT,
  CHILD,
  SPOUSE_APP_REASON,
  SPOUSE
} from "../constants/EligibilityConstants"
import { useEligibilityCategory } from "../hooks/useEligibilityCategory";
import { EligibilityAlerts } from "./eligibility-information/EligibilityAlerts";


const useStyles = makeStyles()({
  dropdown: {
    margin: "2px 0",
  },
  mobileDropdown: {
    margin: "0 24px",
  },
  alertModalParagraph: {
    marginTop: "1rem",
  },
  alertModalButtons: {
    display: "flex",
    marginTop: "2rem",
    alignContent: "center",
  },
  textInputLabel: {
    display: "flex",
    flexDirection: "column-reverse",
    marginTop: "32px",
  },
  questionTextLabel: {
    fontWeight: "bold",
    lineHeight: "1.15",
    color: "black"
  }
});

export type EligibilityCategoryProps = {
  isMobile: boolean;
};

export type ConcurrentEligibilitySelection = {
  formType: string;
  eligibilityCategory: string;
  eligibilitySubcategory: string | undefined;
}



const FormSpecificWarnings = ({ formMetadata, eligibilityType, eligibilitySubtype }: {
  formMetadata: FormMetaData,
  eligibilityType: string,
  eligibilitySubtype: string | undefined
}) => {
  return (
    <>
      {formMetadata.formType === FormTypes.N400 || formMetadata.formType === FormTypes.I539 && (
        <p>
          You must complete all fields with an asterisk (
          <span style={{ color: "red" }}>*</span>) to submit this form.
        </p>
      )}
      {formMetadata.formType === FormTypes.I130 && <I130Info />}
      <h2>
        {formMetadata.pages.eligibility?.header}
        {formMetadata.formType === FormTypes.N400 && (
          <span style={{ color: "red" }}>*</span>
        )}
      </h2>
      {formMetadata.formType === FormTypes.I765 && (
        <AlertWindow
          variant="warning"
          headerText={`You can only submit a PDF form for certain eligibility categories`}
        >
          If your eligibility category is not listed in the dropdown menu, you
          may be able to file your form using your online account and selecting
          &quot;Fill Out Form Fields Online&quot; or by submitting a paper form
          by mail.
        </AlertWindow>
      )}
      {(formMetadata.formType === FormTypes.I539 || formMetadata.formType === FormTypes.I360) && (
        <EligibilityAlerts formType={formMetadata.formType} eligibilityType={eligibilityType} eligibilitySubType={eligibilitySubtype} />
      )}
      <br />
      {formMetadata.formType === FormTypes.I765 && (
        <h3>Eligibility Category</h3>
      )}
      {formMetadata.formType === FormTypes.I129H2A && (
        <>
          <h2>About This Petition</h2>
          <h3>Basis for Classification</h3>
        </>
      )}
    </>
  );
};

const FormSpecificCheckBoxes = ({ formType, eligibilityType, formMetadata }: {
  formType: string,
  eligibilityType: string | undefined,
  formMetadata: FormMetaData
}) => {
  const showUnderOrdersRadioButtons = FormTypes.I751 === formType && eligibilityType
  const showI751SubCategoryCheckBoxes = useMemo(() => showUnderOrdersRadioButtons && I751EligiilityCategories.WAIVER_OR_INDIVIDUAL_FILING === eligibilityType, [showUnderOrdersRadioButtons, eligibilityType])
  return (
    <>
      {showI751SubCategoryCheckBoxes && eligibilityType && <I751SubCategoryCheckboxes formMetadata={formMetadata} eligibilityCategory={eligibilityType} />}

      {showUnderOrdersRadioButtons && <I751UnderOrdersRadioButtons key={eligibilityType} />}

      {formType === AcceptedFormTypes.I_485A && eligibilityType &&  <I485ACheckboxes key={eligibilityType} selectedFormType={formType} />}
    </>
  );
};


const EligibilityCategory = ({ isMobile }: EligibilityCategoryProps) => {
  useEffect(() => {document.title = "USCIS | Eligibility Category";}, []);
  const { classes } = useStyles();
  const paroleRadioId = useId();
  const reasonRadioId = useId();
  const pendingFormRadioID = useId();
  const { addAlert } = useAlertSnackbar();
  const dispatch = useAppDispatch();
  const { appReasonCode, benefitTypeCode, immigrationClassCode } = useLocation().state || {};
  const { myUscisId, userGroupId, isApplicantOrRep } = useSelector((state: RootState) => state.user);
  const { getValidationForFormType } = useValidations();
  const { isToggleEnabled } = useToggles();
  const { isEligibilitySelectionPending } = useEligibilityCategory();
  const navigate = useNavigate();
  const {
    eligibilityCategory: eligibilityType,
    eligibilitySubcategory: eligibilitySubtype,
    submissionId,
    evidences,
    immvi,
    reasonForFiling,
    isUSCitizen,
    formType,
    eligibilitySubcategories,
    forms,
    formSpecificInfo,
    selectedConcurrentForms
  } = useSelector((state: RootState) => state.submission);
  const formValidationState = getValidationForFormType(formType);

  const {accountType,
    isUserPartOfOrg
  }
  = useSelector((state: RootState) => state.user)

  let accountTypeNotOptional: AccountType = accountType ? accountType : AccountTypes.APPLICANT

  const accountTypeOrg140 =  isUserPartOfOrg && accountType=== AccountTypes.REPRESENTATIVE ? AccountTypes.REGISTRANT : accountTypeNotOptional

  const shouldShow485SubTypeSelection = !isApplicantOrRep || !selectedConcurrentForms.includes(FormTypes.I485J);

  const { evidenceGroups } = useSelector((state: RootState) => state.evidence);
  const { formMetadata, concurrentFormMetadata } = useSelector(
    (state: RootState) => state.formMetadata,
  );

  const [categoryChangeAlertOpen, setCategoryChangeAlertOpen] =
    useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<string>();

  const {
    onOrAfterApril012024Answer,
    beforeApril012024Answer,
    showBeforeAprilQuestion
  } = useSelector((state: RootState) => state.c9feeCalculation);
  const [firstRadioSelect, setFirstRadioSelect] = useState<boolean>(false);

  const hasSubcategories = function (selectedEligibility: string) {
    return (
      formMetadata.eligibilityCategories.find(
        (cat) => cat.category === selectedEligibility,
      )?.metaData.subcategories != null &&
      formMetadata.eligibilityCategories.find(
        (cat) => cat.category === selectedEligibility,
      )!.metaData.subcategories!.length > 0
    );
  };

  const concurrentHasSubcategories = function (form: string, selectedEligibility: string | undefined) {
    return (
      getConcurrentFormEligibilityCategories(form).find(
        (cat) => cat.category === selectedEligibility,
      )?.metaData.subcategories != null &&
      getConcurrentFormEligibilityCategories(form).find(
        (cat) => cat.category === selectedEligibility,
      )!.metaData.subcategories!.length > 0
    );
  };

  const hasSubcategoryHeader = function (selectedEligibility: string) {
    return formMetadata.eligibilityCategories.find(
      (cat) => cat.category === selectedEligibility,
    )?.metaData.subCategoryHeader;
  };

  const concurrentHasSubcategoryHeader = function (form: string, selectedEligibility: string | undefined) {
    return getConcurrentFormEligibilityCategories(form).find(
      (cat) => cat.category === selectedEligibility,
    )?.metaData.subCategoryHeader;
  };

  const handleChange = useCallback(
    async (category: string, subCategory: string | undefined) => {
      await clearFormSpecificLogic(category)

      let benefitType = Number(
        formMetadata.eligibilityCategories.find(
          (cat) => cat.category === category,
        )?.benefitTypeCode,
      );
      let appReason = formMetadata.eligibilityCategories.find(
        (cat) => cat.category === category,
      )?.applicationReasonCode;

      if (subCategory) {
        appReason = formMetadata.eligibilityCategories
          .find((cat) => cat.category === category)
          ?.metaData.subcategories.find(
            (subcat) => subcat.category === subCategory,
          )?.applicationReasonCode;
        let benefitTypeOverride = formMetadata.eligibilityCategories
          .find((cat) => cat.category === category)
          ?.metaData.subcategories.find(
            (subcat) => subcat.category === subCategory,
          )?.benefitTypeCodeOverride;
        if (benefitTypeOverride) {
          benefitType = Number(benefitTypeOverride);
        }
      }
      let convertedAppReason = appReason ? Number(appReason) : undefined;

      dispatch(setIsFeeExempt(false));
      dispatch(setIsNotFeeExempt(false));
      dispatch(setBenefitTypeCode(benefitType));
      dispatch(setApplicationReasonCode(convertedAppReason));

      const submission = await SubmissionService.updateEligibility(
        myUscisId,
        submissionId,
        category,
        subCategory,
        benefitType,
        convertedAppReason,
        formType,
        userGroupId,
      );

      dispatch(setEligibilityCategory(category));
      dispatch(setEligibilitySubcategory(subCategory));

      if (evidenceGroups) {
        dispatch(hydrateState({ submission, evidenceGroups }));
      }

      if (submission?.forms?.filter((form) => form.name != null).length > 0) {
        setInProgressFormValidation();
        dispatch(setIsPollingForFormValidation(true));
      }

      if (!submission?.userRequestedFeeWaiver)
        dispatch(setIsPollingForFeeWaiverValidation(false));

      setCategoryChangeAlertOpen(false);
    },
    [dispatch, myUscisId, submissionId, evidenceGroups],
  );

  const handleConcurrentFormChange = useCallback(
    async (formType: string, category: string | undefined, subCategory: string | undefined) => {

      let benefitType = Number(
        getConcurrentFormEligibilityCategories(formType).find(
          (cat) => cat.category === category,
        )?.benefitTypeCode,
      );
      let appReason = getConcurrentFormEligibilityCategories(formType).find(
        (cat) => cat.category === category,
      )?.applicationReasonCode;

      if (subCategory) {
        appReason = getConcurrentFormEligibilityCategories(formType)
          .find((cat) => cat.category === category)
          ?.metaData.subcategories.find(
            (subcat) => subcat.category === subCategory,
          )?.applicationReasonCode;
        let benefitTypeOverride = getConcurrentFormEligibilityCategories(formType)
          .find((cat) => cat.category === category)
          ?.metaData.subcategories.find(
            (subcat) => subcat.category === subCategory,
          )?.benefitTypeCodeOverride;
        if (benefitTypeOverride) {
          benefitType = Number(benefitTypeOverride);
        }
      }
      let convertedAppReason = appReason ? Number(appReason) : undefined;

      const submission = await SubmissionService.updateEligibility(
        myUscisId,
        submissionId,
        category!,
        subCategory,
        benefitType,
        convertedAppReason,
        formType,
        userGroupId,
      );
      dispatch(hydrateState({ submission, evidenceGroups }));
   },
   [dispatch, myUscisId, submissionId, forms],
  );

  const checkEvidence = async (category: string, evidences: Evidence[]) => {
    const evidenceGroups = formMetadata.eligibilityCategories.find(
      (evidenceCategory) => evidenceCategory.category === category,
    )?.metaData.evidenceGroups;

    const evidenceGroupIds = evidenceGroups?.map((group) => group.id);

    if (evidenceGroupIds)
      return (
        evidences?.filter(
          (evidence) =>
            ![...evidenceGroupIds, "feeWaiver"].includes(
              evidence.evidenceGroup!,
            ),
        ).length > 0 && evidences.some((evidence) => evidence.files.length > 0)
      );
  };

  const handleImmviSelection = (requestingImmvi: boolean) => {
    SubmissionService.updateImmvi(myUscisId, submissionId, requestingImmvi, userGroupId)
      .then((submission) => {
        dispatch(setImmvi(requestingImmvi));
        dispatch(hydrateState({ submission, evidenceGroups }));
        dispatch(setFeeWaiverRequested(false));
        dispatch(setIsPollingForFeeWaiverValidation(false));
        if (submission?.forms?.filter((form) => form.name != null).length > 0)
          dispatch(setIsPollingForFormValidation(true));
      })
      .catch(() => {
        addAlert(
          "Special Parole selection was not able to be updated. Please try again later",
        );
      });
  };

  // update accordingly
  const handlec9Selection = (request: C9UpdateRequest, formType: string) => {
    SubmissionService.updateC9fee(
      myUscisId,
      submissionId,
      request.options,
      request.feeWaiverEligible,
      userGroupId,
    )
      .then((submission) => {
        dispatch(hydrateState({ submission, evidenceGroups }));
        dispatch(setFeeWaiverRequested(false));
        dispatch(setIsPollingForFeeWaiverValidation(false));
          SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        { formType, onOrAfterApril012024: request.options.onOrAfterApril012024, before04012024: request.options.beforeApril012024 },
      );
      dispatch(setFormSpecificInfo({
        formType,
        onOrAfterApril012024: request.options.onOrAfterApril012024,
        before04012024: request.options.beforeApril012024
      }))
        if (submission?.forms?.filter((form) => form.name != null).length > 0)
          dispatch(setIsPollingForFormValidation(true));
      })
      .catch(() => {
        addAlert("C9 was not able to be updated. Please try again later");
      });


  };

  const handleReasonForFilingSelection = (reason: string) => {
    SubmissionService.updateReasonForFiling(myUscisId, submissionId, reason, userGroupId)
      .then((submission) => {
        dispatch(hydrateState({ submission, evidenceGroups }));
        dispatch(setReasonForFiling(reason));

        if (submission?.forms?.filter((form) => form.name != null).length > 0) {
          setInProgressFormValidation();
          dispatch(setIsPollingForFormValidation(true));
        }
      })
      .catch(() => {
        addAlert(
          "Reason for filing selection was not able to be updated. Please try again later",
        );
      });
      if(formType == FormTypes.I129H2A && reason.length > 0){
        SubmissionService.updateFormSpecificInfo(
          submissionId,
          myUscisId,
          {
            formType,
            actionRequested: reason
          },
        );
      }
  };

  const setInProgressFormValidation = () => {
    if(formValidationState && formValidationState.status) {
      let newFormValidationState = {
            ...formValidationState,
            status: VALIDATION_STATUS.IN_PROGRESS,
            details: []
          };

        dispatch(setFormValidations([newFormValidationState]))
    }
  }

  const preselectEligibilityCategory = async () => {
    let category = determineEligibility(benefitTypeCode, appReasonCode);
    if (category) {
      await handleChange(category, undefined);
      return category;
    }
    return "Select one";
  };

  const preselectEligbilitySubcategory = async () => {
    let subcategory = findEligibilitySubcategory(
      eligibilityType,
      appReasonCode,
      immigrationClassCode
    );
    if (!firstRadioSelect && subcategory) {
      await handleChange(eligibilityType, subcategory);
      setFirstRadioSelect(true);
      return subcategory;
    }
    return eligibilitySubtype;
  };

  const determineEligibility = (
    benefitTypeCode: string,
    appReasonCode: string,
  ) => {
    if (appReasonCode === SPOUSE_APP_REASON) {
      return SPOUSE;
    }
    let categories = formMetadata.eligibilityCategories.filter(
      (category) => category.benefitTypeCode === benefitTypeCode,
    );
    if (categories.length == 1) {
      return categories.at(0)!.category;
    }
    return categories.find(
      (parentCat) =>
        parentCat.metaData.subcategories?.filter((subCat) => {
          return subCat.applicationReasonCode == appReasonCode;
        }).length > 0,
    )?.category;
  };

const findEligibilitySubcategory = (
  eligibilityType: string,
  appReasonCode: string,
  immigrationClassCode: string
) => {
  const category = formMetadata.eligibilityCategories.find(
    (c) => c.category === eligibilityType
  );

  return category?.metaData.subcategories.find((sub) =>
    immigrationClassCode
      ? sub.immigrationClassCode === immigrationClassCode
      : sub.applicationReasonCode === appReasonCode
  )?.category;
};


  const handleQuestion1Change = (answer: boolean) => {
    dispatch(setQuestion1Answer(answer));
    if (answer) {

      handlec9Selection({
        options: { onOrAfterApril012024: true, beforeApril012024: false },
        feeWaiverEligible: true,
      }, formType);
    }
  };

  const handleQuestion2Change = (answer: boolean, formType: string) => {
    dispatch(setQuestion2Answer(answer));
    if (answer) {
      handlec9Selection({
        options: { onOrAfterApril012024: false, beforeApril012024: true },
        feeWaiverEligible: false,
      }, formType);
    } else {
      handlec9Selection({
        options: { onOrAfterApril012024: false, beforeApril012024: false },
        feeWaiverEligible: true,
      }, formType);
    }
  };

  const getConcurrentFormEligibilityCategories = (form: string) => {
    let eligibilityCategories = concurrentFormMetadata.find(metadata => metadata.formType === form)?.eligibilityCategories;
    return eligibilityCategories ?? [];
  }

  const showSubCategoryRadioButtons = () => {
    return (hasSubcategories(eligibilityType) || hasSubcategoryHeader(eligibilityType)) && FormTypes.I751 !== formType && FormTypes.I140 !== formType
  }

  const showConcurrentSubCategoryRadioButtons = (formType: string) => {
    return (concurrentHasSubcategories(formType, forms.find(submission => submission.formType === formType)?.eligibilityCategory)
      || concurrentHasSubcategoryHeader(formType, forms.find(submission => submission.formType === formType)?.eligibilityCategory)) && FormTypes.I751 !== formType && FormTypes.I140 !== formType
  }

  const clearFormSpecificLogic = useCallback(async (category: string) => {
    if (FormTypes.I751 === formType) {
      dispatch(setEligibilitySubcategories([]));
      await SubmissionService.updateEligibilitySubcategories(
        myUscisId,
        submissionId,
        [],
        userGroupId
      );
    }
    else if (FormTypes.I140 === formType) {
      if (I140ScheduleAPetitionTypeList.includes(category))
      await SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        {
          formType,
          dolNumber: "",
          isScheduleA: false
        },
      );
      else {
        dispatch(setFormSpecificInfo({ formType, dolNumber: "", isScheduleA: false }))
      await SubmissionService.resetFormSpecificInfo(
        submissionId,
      myUscisId)
    }
  } else if (formType === FormTypes.I485A){
      try {
        await SubmissionService.updateFormSpecificInfo(
          submissionId,
          myUscisId,
          {
            formType
          },
        );
        dispatch(setFormSpecificInfo({ formType }))
      } catch (error) {
        console.error(error)
      }
    } else if(formType === FormTypes.I129H2A) {
      handleReasonForFilingSelection("");
    }
  }, [eligibilitySubcategories, setEligibilitySubcategories, myUscisId, submissionId, setFormSpecificInfo])

  const getConcurrentEligibility = (formType: string, category: String | undefined) => {
    if (category === undefined) {
      return "Select one";
    }
    return getConcurrentFormEligibilityCategories(formType).find((cat) => cat.category === category)?.label
  }

  const categoryStrategies: Record<string, () => any> & { DEFAULT: () => any } = {
    [AcceptedFormTypes.I_485]: () => {
      return [
        ...formMetadata.eligibilityCategories
          .find((cat) => cat.category === eligibilityType)!
          .metaData.subcategories.filter(
            (subCategory) => {
              const currSubType = formSpecificInfo?.isFamilyBased ? I485SubTypes.FAMILY_BASED : I485SubTypes.EMPLOYMENT_BASED
              const notDisabled = subCategory.disabled === null || !subCategory.disabled
              return notDisabled && subCategory.filterValue === currSubType
            })

          .map((eligibilityCategory) => {
            return {
              value: eligibilityCategory.category,
              label: eligibilityCategory.label,
            };
          }),
      ]
    },
    DEFAULT: () => {
      return [
        ...formMetadata.eligibilityCategories
          .find((cat) => cat.category === eligibilityType)!
          .metaData.subcategories.filter(
            (subCategory) => subCategory.disabled === null || !subCategory.disabled
          )
          .map((eligibilityCategory) => {
            return {
              value: eligibilityCategory.category,
              label: eligibilityCategory.label,
            };
          }),
      ]
    }
  };

  const getSubcategoryOptions = (formType: string) => {
    const strategy = categoryStrategies[formType] || categoryStrategies.DEFAULT;
    return strategy();
  };

  return (
    <>
      <AlertDialog
        showDialog={categoryChangeAlertOpen}
        setShowDialog={setCategoryChangeAlertOpen}
        headerText="Are you sure you want to change eligibility category?"
      >
        <AlertDescription>
          <Typography className={classes.alertModalParagraph}>
            The evidence you have uploaded may no longer apply to your
            submission if you make this change.
          </Typography>
          <Typography className={classes.alertModalParagraph}>
            If you continue, all documents you have added in the Evidence
            section that are not applicable with the new category will be
            removed. Revisit Evidence section to add relevant documents
          </Typography>
          <div className={classes.alertModalButtons}>
            <Button
              variant="contained"
              data-testid="eligibility-category-continue"
              isModalAlert
              onClick={async () =>
                await handleChange(selectedCategory!, undefined)
              }
            >
              Yes, continue
            </Button>
            <Button
              variant="text"
              data-testid="eligibility-category-cancel"
              isModalAlert
              style={{ padding: "10px 4rem" }}
              onClick={() => setCategoryChangeAlertOpen(false)}
            >
              Cancel
            </Button>
          </div>
        </AlertDescription>
      </AlertDialog>


      <FormSpecificWarnings formMetadata={formMetadata} eligibilityType={eligibilityType} eligibilitySubtype={eligibilitySubtype}/>
      <h2> {`${formMetadata.formType} eligibility selection`}</h2>
      <Dropdown
        name="eligibility-choice"
        onChange={async (e) => {
          const category = String(e.target.value);
          setSelectedCategory(category);
          const hasNonMatchingEvidenceGroups = await checkEvidence(
            category,
            evidences,
          );
          if (hasNonMatchingEvidenceGroups) setCategoryChangeAlertOpen(true);
          else await handleChange(category, undefined);
        }}
        value={eligibilityType}
        defaultValue={
          benefitTypeCode && !eligibilityType
            ? preselectEligibilityCategory()
            : "Select one"
        }
        className={isMobile ? classes.mobileDropdown : classes.dropdown}
        options={[
          {
            value: "",
            label: "Select one",
            disabled: true,
          },
          ...formMetadata.eligibilityCategories
          .filter(
            eligibilityCategory => !eligibilityCategory.metaData.disabled && (formType === FormTypes.I140 && isUserPartOfOrg? eligibilityCategory.metaData?.roleTypes?.includes(accountTypeOrg140) : true)
          )
          .filter(
            eligibilityCategory => !eligibilityCategory.metaData.disabled && (formType === FormTypes.I140 && !isUserPartOfOrg? eligibilityCategory.metaData?.roleTypes?.includes('applicant') : true)
          )
            .map((eligibilityCategory) => {
              return {
                value: eligibilityCategory.category,
                label: eligibilityCategory.label,
              };
            }),
        ]}
      />
      {formMetadata.formType === FormTypes.I129H2A && eligibilityType && (
        <I129H2ARequestedAction eligibilityType={eligibilityType}
          handleOnChange={(e) =>
            handleReasonForFilingSelection(e.target.value)
          } />
      )}
      {eligibilityType === SPOUSE && <SpouseWarning />}

      <FormSpecificCheckBoxes
        formType={formType}
        eligibilityType={eligibilityType}
        formMetadata={formMetadata}
      />

      {formType === FormTypes.I907 && navigate(`/pdf-intake/${formType}/${submissionId}/form`)}
      {FormTypes.I485 === formType && shouldShow485SubTypeSelection && <I485SubTypeSelection key={`isFamilyBased${formSpecificInfo?.isFamilyBased}`} />}

      {showSubCategoryRadioButtons() && (
        <>
          <USCISDivider />
          {eligibilityType === PARENT && <ParentWarning />}
          <Box
            sx={{
              '& h3': {
                fontWeight: "bold",
                lineHeight: "1.15",
                color: "black"
              },
            }}>
          <DataWrapper
            noDivider={true}
            question={formMetadata.eligibilityCategories.find(
              (cat) => cat.category === eligibilityType,
            )?.metaData.subCategoryHeader}
          >
            <FormControlSpacer columns={1}>
              {hasSubcategories(eligibilityType) && (
              <RadioButtons
                srOnlyQuestionText={formMetadata.eligibilityCategories.find(
                  (cat) => cat.category === eligibilityType,
                )?.metaData.subCategoryHeader}
              onChange={async (e) => {
                const subcategory = String(e.target.value);
                await handleChange(eligibilityType, subcategory);
              }}
              name={eligibilityType + "-subcategories"}
              value={
                !eligibilitySubtype
                  ? preselectEligbilitySubcategory()
                  : eligibilitySubtype
              }
              options={getSubcategoryOptions(formType)}
            />
          )}
          </FormControlSpacer>
        </DataWrapper>
        </Box>
       </>
      )}

      {FormTypes.I485 === formType  && eligibilityType && <I485MilitaryVetSelection key={`isMilitaryVet${formSpecificInfo?.isMilitaryVeteran}`} />}

      {formMetadata.formType === FormTypes.I140 && I140ScheduleAPetitionTypeList.includes(eligibilityType) && <I140ScheduleARadioButtons key={eligibilityType} />}

      {FormTypes.I129H1B === formType && eligibilityType && isToggleEnabled(ToggleCodes.H1B_CAP) && <I129H1BCapSelection key={`isCapEnabled${formSpecificInfo?.isCapEnabled}`}/>}
      {FormTypes.I539 === formType && eligibilityType && eligibilitySubtype && <I539IsOnlyApplicantApplying key={`isCapEnabled${formSpecificInfo?.isOnlyApplicantApplying}`}/>}

      {formMetadata.formType === FormTypes.I130 &&
        (eligibilityType === SPOUSE || eligibilityType === CHILD) && (
          <>
            <USCISDivider />
            <Typography variant="h6" className={classes.questionTextLabel}>
              Are you a US Citizen or a Lawful Permanent Resident?
            </Typography>
            <RadioButtons
              onChange={async (e) => {
                let usc = e.target.value;
                dispatch(setIsUSCitizen(usc));
                const submission = await SubmissionService.setResidencyStatus(
                  submissionId,
                  myUscisId,
                  usc,
                  userGroupId,
                );
                if (submission?.forms?.filter((form) => form.name != null).length > 0) {
                  dispatch(setIsPollingForFormValidation(true));
                }
              }}
              value={isUSCitizen}
              options={[
                { label: "A US Citizen", value: RESIDENCY_STATUS.USC },
                {
                  label: "A Lawful Permanent Resident",
                  value: RESIDENCY_STATUS.LPR,
                },
              ]}
            />
          </>
        )}

      {formMetadata.formType === FormTypes.N400 &&
        eligibilityType === N400Codes.OTHER && (
          <>
            <USCISDivider />
            <label className={classes.textInputLabel}>
              <input
                type="text"
                required
                name="other_eligibility"
                style={{
                  position: "relative",
                  margin: "unset",
                  marginTop: "10px",
                  height: "40px",
                }}
              />
              <b>Provide an explanation.</b>
            </label>
          </>
        )}

      {formMetadata.formType === FormTypes.N400 &&
        eligibilityType === N400Codes.SPOUSE_OF_ABROAD_US_CITIZEN && (
          <>
            <USCISDivider />
            <Typography
              style={{
                fontSize: "20px",
                marginBottom: "32px",
                marginRight: "20%",
              }}
            >
              If your residential address is outside the United States and you
              are filing under Immigration and Nationality Act (INA) section 318
              (b), select the USCIS field office where you would like to have
              your naturalization interview.
            </Typography>
            <Dropdown
              name="field-office-choice"
              defaultValue="Select one"
              className={isMobile ? classes.mobileDropdown : classes.dropdown}
              options={[
                {
                  value: "",
                  label: "Select one",
                  disabled: true,
                },
              ]}
            />
          </>
        )}

      {formMetadata.formType === FormTypes.I765 &&
        eligibilityType &&
         (
          // This component is available to all I765 categories except for C9.
          <div style={{ margin: "2rem 0 3rem 0" }}>
            <ReasonForFilingComponent
              direction="column"
              radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
              radioLabelId={reasonRadioId}
              classes={classes}
              choiceText={
                "Is this an initial, replacement, or renewal request?"
              }
              label={["Initial", "Replacement", "Renewal"]}
              choiceTextVariant="h3"
              alignment={"flex-start"}
              value={reasonForFiling ? reasonForFiling : "Initial"}
              handleOnChange={(e) =>
                handleReasonForFilingSelection(e.target.value)
              }
            />
          </div>
        )}

      {eligibilityType === C11_PAROLE && (
        <div style={{ margin: "2rem 0 3rem 0" }}>
          <YesNoChoiceComponent
            direction="column"
            radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
            radioLabelId={paroleRadioId}
            classes={classes}
            choiceText={
              "Are you filing under the special Parole process for Immigrant Military Members and Veterans Initiative?"
            }
            label={["Yes", "No"]}
            choiceTextVariant="h3"
            alignment={"flex-start"}
            value={immvi ? "Yes" : "No"}
            handleOnChange={(e) =>
              handleImmviSelection(e.target.value === "Yes")
            }
          />
        </div>
      )}

      {eligibilityType === C9 && (
        <>
          <div style={{ margin: "2rem 0 3rem 0" }}>
            <YesNoChoiceComponent
              direction="column"
              radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
              radioLabelId={pendingFormRadioID}
              classes={classes}
              choiceText={
                "You filed your I-485 with a fee on or after 04/01/2024 and your form is still pending."
              }
              label={["Yes", "No"]}
              choiceTextVariant="h3"
              alignment={"flex-start"}
              value={
                onOrAfterApril012024Answer === true
                  ? "Yes"
                  : onOrAfterApril012024Answer === false
                    ? "No"
                    : ""
              }
              handleOnChange={(event) =>
                handleQuestion1Change(
                  event.target.value === "Yes" ? true : false,
                )
              }
            />
          </div>
          {showBeforeAprilQuestion && onOrAfterApril012024Answer === false && (
            <div style={{ margin: "2rem 0 3rem 0" }}>
              <YesNoChoiceComponent
                direction="column"
                radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
                radioLabelId={pendingFormRadioID}
                classes={classes}
                choiceText={
                  "You filed your I-485 with a fee on or after 07/30/2007 and before 04/01/2024 and your form is still pending."
                }
                label={["Yes", "No"]}
                choiceTextVariant="h3"
                alignment={"flex-start"}
                value={
                  beforeApril012024Answer === true
                    ? "Yes"
                    : beforeApril012024Answer === false
                      ? "No"
                      : ""
                }
                handleOnChange={(event) =>
                  handleQuestion2Change(
                    event.target.value === "Yes" ? true : false, formType
                  )
                }
              />
            </div>
          )}
        </>
      )}

      <ActionRequested />

      <EligibilityInformation eligibilityCategory={eligibilityType} />

      {selectedConcurrentForms.length > 0 && (
        <div>
          {selectedConcurrentForms.map((form) => (
            <>
            {form !== FormTypes.I907 && (
              <div key={form}>
                <USCISDivider />
                <FormSpecificWarnings formMetadata={concurrentFormMetadata.find(metadata => metadata.formType === form)!} eligibilityType={eligibilityType} eligibilitySubtype={eligibilitySubtype}/>
                  <h2> {`${form} eligibility selection`}</h2>
                  <Dropdown
                    name="eligibility-choice"
                    onChange={async (e) => {
                      const category = String(e.target.value);
                      handleConcurrentFormChange(form, category, undefined);
                    }}
                    displayEmpty
                    renderValue={() => getConcurrentEligibility(form, forms.find(submission => submission.formType === form)?.eligibilityCategory) ?? "Select one"}
                    className={isMobile ? classes.mobileDropdown : classes.dropdown}
                    options={[
                      {
                        value: "",
                        label: "Select one",
                        disabled: true,
                      },
                      ...getConcurrentFormEligibilityCategories(form)
                        .filter(
                          eligibilityCategory => !eligibilityCategory.metaData.disabled && (formType === FormTypes.I140 && isUserPartOfOrg? eligibilityCategory.metaData?.roleTypes?.includes(accountTypeOrg140) : true)
                        )
                        .filter(
                          eligibilityCategory => !eligibilityCategory.metaData.disabled && (formType === FormTypes.I140 && !isUserPartOfOrg? eligibilityCategory.metaData?.roleTypes?.includes('applicant') : true)
                        )
                        .filter(
                          eligibilityCategory => !eligibilityCategory.metaData.excludeForParentFormTypes?.includes(formType)
                        )
                          .map((eligibilityCategory) => {
                            return {
                              value: eligibilityCategory.category,
                              label: eligibilityCategory.label,
                            };
                          }),
                    ]}
                  />
              {form === FormTypes.I765 && getConcurrentEligibility(form, forms.find(submission => submission.formType === form)?.eligibilityCategory) && (
                <div style={{ margin: "2rem 0 3rem 0" }}>
                  <ReasonForFilingComponent
                    direction="column"
                    radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
                    radioLabelId={reasonRadioId}
                    classes={classes}
                    choiceText={
                      "Is this an initial, replacement, or renewal request?"
                    }
                    label={["Initial", "Replacement", "Renewal"]}
                    choiceTextVariant="h3"
                    alignment={"flex-start"}
                    value={reasonForFiling ? reasonForFiling : "Initial"}
                    handleOnChange={(e) =>
                      handleReasonForFilingSelection(e.target.value)
                    }
                  />
                </div>
              )}

              {forms.find(submission => submission.formType === form)?.eligibilityCategory === C11_PAROLE && (
                <div style={{ margin: "2rem 0 3rem 0" }}>
                  <YesNoChoiceComponent
                    direction="column"
                    radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
                    radioLabelId={paroleRadioId}
                    classes={classes}
                    choiceText={
                      "Are you filing under the special Parole process for Immigrant Military Members and Veterans Initiative?"
                    }
                    label={["Yes", "No"]}
                    choiceTextVariant="h3"
                    alignment={"flex-start"}
                    value={immvi ? "Yes" : "No"}
                    handleOnChange={(e) =>
                      handleImmviSelection(e.target.value === "Yes")
                    }
                  />
                </div>
              )}

              {forms.find(submission => submission.formType === form)?.eligibilityCategory === C9 && (
                <>
                  <div style={{ margin: "2rem 0 3rem 0" }}>
                    <YesNoChoiceComponent
                      direction="column"
                      radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
                      radioLabelId={pendingFormRadioID}
                      classes={classes}
                      choiceText={
                        "You filed your I-485 with a fee on or after 04/01/2024 and your form is still pending."
                      }
                      label={["Yes", "No"]}
                      choiceTextVariant="h3"
                      alignment={"flex-start"}
                      value={
                        onOrAfterApril012024Answer === true
                          ? "Yes"
                          : onOrAfterApril012024Answer === false
                            ? "No"
                            : ""
                      }
                      handleOnChange={(event) =>
                        handleQuestion1Change(
                          event.target.value === "Yes" ? true : false,
                        )
                      }
                    />
                  </div>
                  {showBeforeAprilQuestion && onOrAfterApril012024Answer === false && (
                    <div style={{ margin: "2rem 0 3rem 0" }}>
                      <YesNoChoiceComponent
                        direction="column"
                        radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
                        radioLabelId={pendingFormRadioID}
                        classes={classes}
                        choiceText={
                          "You filed your I-485 with a fee on or after 07/30/2007 and before 04/01/2024 and your form is still pending."
                        }
                        label={["Yes", "No"]}
                        choiceTextVariant="h3"
                        alignment={"flex-start"}
                        value={
                          beforeApril012024Answer === true
                            ? "Yes"
                            : beforeApril012024Answer === false
                              ? "No"
                              : ""
                        }
                        handleOnChange={(event) =>
                          handleQuestion2Change(
                            event.target.value === "Yes" ? true : false, form
                          )
                        }
                      />
                    </div>
                  )}
                </>
              )}

              {form === FormTypes.I130 &&
                (forms.find(submission => submission.formType === form)?.eligibilityCategory === SPOUSE || forms.find(submission => submission.formType === form)?.eligibilityCategory === CHILD) && (
                <>
                  <USCISDivider />
                  <Typography variant="h6" className={classes.questionTextLabel}>
                    Are you a US Citizen or a Lawful Permanent Resident?
                  </Typography>
                  <RadioButtons
                    onChange={async (e) => {
                      let usc = e.target.value;
                      dispatch(setIsUSCitizen(usc));
                      const submission = await SubmissionService.setResidencyStatus(
                        submissionId,
                        myUscisId,
                        usc,
                        userGroupId,
                      );
                      if (submission?.forms?.filter((form) => form.name != null).length > 0) {
                        dispatch(setIsPollingForFormValidation(true));
                      }
                    }}
                    value={isUSCitizen}
                    options={[
                      { label: "A US Citizen", value: RESIDENCY_STATUS.USC },
                      {
                        label: "A Lawful Permanent Resident",
                        value: RESIDENCY_STATUS.LPR,
                      },
                    ]}
                  />
                </>
              )}

              <EligibilityInformation eligibilityCategory={forms.find(submission => submission.formType === form)?.eligibilityCategory!} />

              <br />

                  {forms.find(submission => submission.formType === formType)?.eligibilityCategory === SPOUSE && <SpouseWarning />}

                  <FormSpecificCheckBoxes
                    formType={form}
                    eligibilityType={forms.find(submission => submission.formType === form)?.eligibilityCategory}
                    formMetadata={concurrentFormMetadata.find(metadata => metadata.formType === form)!}
                  />

                  {showConcurrentSubCategoryRadioButtons(form) && (
                    <>
                      <USCISDivider />

                      {forms.find(submission => submission.formType === form)?.eligibilityCategory === PARENT && <ParentWarning />}

                      <Typography variant="h3" className={classes.questionTextLabel}>
                        {
                          getConcurrentFormEligibilityCategories(form).find(
                            (cat) => cat.category === forms.find(submission => submission.formType === form)?.eligibilityCategory,
                          )?.metaData.subCategoryHeader
                        }
                      </Typography>
                      {concurrentHasSubcategories(form, forms.find(submission => submission.formType === form)?.eligibilityCategory) && (
                        <RadioButtons
                          onChange={async (e) => {
                            const subcategory = String(e.target.value);
                            await handleConcurrentFormChange(form, forms.find(submission => submission.formType === form)?.eligibilityCategory, subcategory);
                          }}
                          name={forms.find(submission => submission.formType === form)?.eligibilityCategory + "-subcategories"}
                          value= {forms.find(submission => submission.formType === form)?.eligibilitySubcategory}
                          options={[
                            ...getConcurrentFormEligibilityCategories(form)
                              .find((cat) => cat.category === forms.find(submission => submission.formType === form)?.eligibilityCategory)!
                              .metaData.subcategories.filter(
                                (subCategory) =>
                                  subCategory.disabled === null || !subCategory.disabled,
                              )
                              .map((eligibilityCategory) => {
                                return {
                                  value: eligibilityCategory.category,
                                  label: eligibilityCategory.label,
                                };
                              }),
                          ]}
                        />
                      )}
                    </>
                  )}
              </div>
            )}
            </>
          ))}
        </div>
      )}

      <USCISDivider />

      <NavigationButtons showBackButton={false} disableNext={isEligibilitySelectionPending} />
    </>
  );
};

export default EligibilityCategory;
