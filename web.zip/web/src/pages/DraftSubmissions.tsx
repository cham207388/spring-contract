import { faTrashCan } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useMediaQuery, useTheme } from "@mui/material";
import { Button, Grid, MaterialTable, Typography } from "myuscis-material";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { makeStyles } from "tss-react/mui";
import { SubmissionService } from "../api/SubmissionService";
import { DeleteDraftSubmissionDialog } from "../components/Dialogs/DeleteDraftSubmissionDialog";
import DocumentUpload from "../components/DocumentUpload";
import { WarningBadge } from "../components/shared/WarningBadge";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";
import { setIsDraftSubmissionDeleted } from "../redux/draftSubmissionsSlice";
import { RootState } from "../redux/store";
import { formatDate, formatDateThirtyDaysFromNow } from "../utils/dates";
import { SuccessfulSubmission } from "./SuccessfulSubmission";
import { Submission } from "../types/Submission";

const useStyles = makeStyles()({
  desktopContainer: {
    backgroundColor: "#ffffff",
    margin: "64px 0",
  },
  mobileContainer: {
    backgroundColor: "#ffffff",
    margin: "64px 0",
    padding: "32px",
  },
  desktopButton: {
    padding: "42px 12px",
    overflowWrap: "break-word",
    whiteSpace: "normal",
    marginRight: "6px",
  },
  mobileButton: {
    width: "auto",
    overflowWrap: "break-word",
    whiteSpace: "normal",
  },
  bigMarginBottom: {
    marginBottom: "64px",
  },
  mediumMarginBottom: {
    marginBottom: "0",
    marginTop: "64px",
    fontSize: "20px",
  },
  topRowOfCard: {
    margin: "32px 24px 32px 24px",
    marginTop: "32px",
  },
  centerRowOfCard: {
    margin: "12px 24px",
    height: "100px",
  },
  bottomRowOfCard: {
    margin: "0",
    height: "150px",
  },
  horizontalSpace: {
    margin: "0px 12px",
  },
  widestColumn: {
    width: "50%",
    borderRight: "1px solid rgba(0, 0, 0, .1)",
    borderTop: "1px solid rgba(0, 0, 0, .1)",
  },
  centerColumn: {
    borderRight: "1px solid rgba(0, 0, 0, .1)",
    borderTop: "1px solid rgba(0, 0, 0, .1)",
  },
  rightColumn: {
    borderLeft: "1px solid rgba(0, 0, 0, .1)",
    borderTop: "1px solid rgba(0, 0, 0, .1)",
  },
  tableItemTitle: {
    fontWeight: "bold",
    marginBottom: "6px",
  },
  card: {
    border: "1px solid rgba(0, 0, 0, .2)",
    margin: "16px 64px",
    borderRadius: "5px",
    boxShadow: "0 4px 2px -2px rgba(0, 0, 0, .3)",
  },
  draftsHeader: {
    margin: "0 64px",
  },
});

export const DraftSubmissions = () => {
  useEffect(() => {document.title = "USCIS | Draft Submissions";}, []);
  const { classes } = useStyles();
  const theme = useTheme();
  const { addAlert } = useAlertSnackbar();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"), {
    defaultMatches: true,
  });

  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);

  const handleContinue = async (draftSubmission: Submission) => {
    try {
      await SubmissionService.updateDraftSubmissionLock(
        myUscisId,
        draftSubmission.submissionId,
        userGroupId
      );
    } catch (error) {
      return;
    }
    navigate(
      `/pdf-intake/${draftSubmission.formType}/${draftSubmission.submissionId}/select-eligibility`,
    );
  };

  const { draftSubmissions, isDraftSubmissionContinued } = useSelector(
    (state: RootState) => state.draftSubmissions,
  );

  const { isSubmissionSubmitted } = useSelector(
    (state: RootState) => state.submission,
  );

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const confirmDelete = (draftSubmissionId: string) => {
    SubmissionService.deleteDraftSubmission(myUscisId, draftSubmissionId, userGroupId)
      .then(() => {
        dispatch(setIsDraftSubmissionDeleted(true));
        setIsDeleteDialogOpen(false);
      })
      .catch((e) => {
        addAlert("Draft was not able to be deleted. Please try again later");
        setIsDeleteDialogOpen(false);
      });

    dispatch(setIsDraftSubmissionDeleted(false));
  };

  return (
    <>
      {isSubmissionSubmitted ? (
        <SuccessfulSubmission isNotify={false} />
      ) : isDraftSubmissionContinued ? (
        <DocumentUpload />
      ) : (
        <Grid
          container
          flexDirection="column"
          className={
            isMobile ? classes.mobileContainer : classes.desktopContainer
          }
        >
          <Typography variant={"h1"} className={classes.draftsHeader}>
            Your Drafts
          </Typography>
          {draftSubmissions.map((draftSubmission, index) => (
            <Grid className={classes.card} key={index}>
              <Grid flexDirection="column">
                <Grid className={classes.topRowOfCard}>
                  <Typography
                    variant={"h2"}
                    className={classes.bigMarginBottom}
                  >
                    Continue I-765 Application for Employment Authorization
                  </Typography>

                  <Typography
                    variant="body1"
                    className={classes.mediumMarginBottom}
                  >
                    You need to finish your draft
                  </Typography>
                </Grid>
                <Grid className={classes.centerRowOfCard}>
                  <Button
                    title="Continue draft I-765"
                    variant="contained"
                    onClick={() => handleContinue(draftSubmission)}
                    className={
                      isMobile ? classes.mobileButton : classes.desktopButton
                    }
                  >
                    Continue
                  </Button>
                  <Button
                    title="Delete draft I-765"
                    variant="text"
                    className={classes.horizontalSpace}
                    onClick={() => setIsDeleteDialogOpen(true)}
                    startIcon={
                      <FontAwesomeIcon
                        style={{ fontSize: "16px", color: "#08588F" }}
                        icon={faTrashCan}
                      />
                    }
                    role="button"
                    aria-label="Delete file"
                  >
                    Delete
                  </Button>
                  <DeleteDraftSubmissionDialog
                    isDialogOpen={isDeleteDialogOpen}
                    handleDialogClose={() => setIsDeleteDialogOpen(false)}
                    handleDelete={() =>
                      confirmDelete(draftSubmission.submissionId)
                    }
                  />
                </Grid>

                <Grid className={classes.bottomRowOfCard}>
                  <MaterialTable
                    tableCellBorder={false}
                    headerContents={[]}
                    tableContents={[
                      [
                        <td key={`rc0`} className={classes.widestColumn}>
                          <Typography className={classes.tableItemTitle}>
                            <b>Status</b>
                          </Typography>
                          <Typography>Your draft is in progress</Typography>
                        </td>,
                        <td key={`rc1`} className={classes.centerColumn}>
                          <Typography className={classes.tableItemTitle}>
                            <b>Last Updated</b>
                          </Typography>
                          <Typography>
                            {formatDate(draftSubmission.updatedAt)}
                          </Typography>
                        </td>,
                        <td key={`rc2`} className={classes.rightColumn}>
                          <Typography className={classes.tableItemTitle}>
                            <b>Expires</b>
                          </Typography>
                          <WarningBadge
                            expirationDate={formatDateThirtyDaysFromNow(
                              draftSubmission.updatedAt,
                            )}
                          />
                        </td>,
                      ],
                    ]}
                  />
                </Grid>
              </Grid>
            </Grid>
          ))}
        </Grid>
      )}
    </>
  );
};
