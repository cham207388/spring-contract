import { makeStyles } from "tss-react/mui";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../redux/store";
import {
  setAttestationSignature,
  setFirstAttestationSignature,
  setSecondAttestationSignature,
  setUserAttested,
  setUserAttestedAt,
  setIsPollingForAttestationStatus,
  setHasReviewedSignature,
  setShowPayAndSubmitInAccordion,
} from "../redux/submissionSlice";
import RoundLogo from "../components/shared/round-logo.svg";
import Section from "../components/shared/Section";
import USCISDivider from "../components/shared/USCISDivider";
import NavigationButtons from "../components/NavigationButtons";
import { SubmissionService } from "../api/SubmissionService";
import useInterval from "../hooks/useInterval";
import { Validators } from "../types/Validations";
import { ATTESTATION_STATUS } from "../types/Attestation";
import { Step, useSteps } from "../hooks/useSteps";
import AttestationLoadingDialog from "../components/Dialogs/AttestationLoadingDialog";
import { useNavigate } from "react-router-dom";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";
import Markdown from "react-markdown";
import { selectIsRepresentative } from "../redux/userSlice";
import { getCertificationContent } from "../content/attestation";
import { FormTypes } from "../types/FormMetaData";
import { Alert, AlertDescription, AlertHeader } from "myuscis-material";
import { useValidations } from "../hooks/useValidations";
import { useEffect, useState } from "react";
import { shouldShowEsignForm, ShouldShowEsignFormParams, isNextDisabled, nextButtonValidation } from "../utils/SignatureUtils";

const { timeZone } = Intl.DateTimeFormat().resolvedOptions();

const YourSignature = () => {
  const { classes } = useStyles();
  const dispatch = useDispatch();
  const { currentStep, steps } = useSteps();
  const navigate = useNavigate();
  const { addAlert } = useAlertSnackbar();
  const [shouldNavigateNext, setShouldNavigateNext] = useState<boolean>(false);

  const POLLING_DELAY = 5000;
  const { getValidationForFormType } = useValidations();

  const {
    myUscisId,
    accountType,
    isUserPartOfOrg,
    userGroupId,
    canUserPayAndSubmit,
  } = useSelector((state: RootState) => state.user);

  const isRepresentative = useSelector((state: RootState) =>
    selectIsRepresentative(state),
  );

  const {
    submissionId,
    forms,
    formType: primaryFormType,
    attestation: {
      attested,
      attestationSignature,
      attestationFirstCheckbox,
      attestationSecondCheckox,
    },
    isSignaturePresent,
    isPollingForAttestationStatus,
    hasReviewedSignature,
  } = useSelector((state: RootState) => state.submission);

  const { elisEsignFlowEnabled } = useSelector(
    (state: RootState) => state.formMetadata.formMetadata,
  );

  const store = useSelector((state: RootState) => state);
  const primaryForm = forms?.find((form) => form.formType === primaryFormType);
  const formValidationState = getValidationForFormType(primaryForm?.formType!);


  useEffect(() => {
    document.title = "USCIS | Your Signature";
    if (!shouldNavigateNext) return;
    if (!hasReviewedSignature) return;
    navigateNextPage();
    setShouldNavigateNext(false);
  }, [shouldNavigateNext, hasReviewedSignature]);

  useInterval(
    async () => {
      try {
        const response = await SubmissionService.pollForAttestationStatus(
          myUscisId,
          submissionId,
          primaryForm!.formId,
          userGroupId,
        );
        if (response === ATTESTATION_STATUS.SUCCESS) {
          if (elisEsignFlowEnabled)
            await SubmissionService.updateSignatureReviewed(
              myUscisId,
              submissionId,
              hasReviewedSignature,
              userGroupId,
            );
          dispatch(setIsPollingForAttestationStatus(false));
          navigateNextPage();
        }
      } catch (e) {
        dispatch(setHasReviewedSignature(false));
        addAlert("Something went wrong when polling for attestation status");
        dispatch(setIsPollingForAttestationStatus(false));
      }
    },
    isPollingForAttestationStatus ? POLLING_DELAY : null,
  );


  const navigateNextPage = () => {
    const currentIndex = steps.findIndex(
      (step: Step) => step.id === currentStep.id,
    );
    document.documentElement.scrollTo(0, 0);
    if (currentIndex + 1 < steps.length)
      navigate("../" + steps[currentIndex + 1].id);
  };

  const isNextValid = nextButtonValidation({
  formType: store.formMetadata.formMetadata.formType,
  eligibilitySubcategory: store.submission.eligibilitySubcategory,
  attested,
  attestationFirstCheckbox,
  attestationSecondCheckox,
});

  const ReturnCheckSection = (sectionName: string) => {
    if (sectionName === "I129Checkbox_employer") {
      return (
        <>
          <label style={{ display: "flex" }}>
            <input
              id="employer_checkbox"
              name="applicant employer"
              style={{
                position: "relative",
                margin: "unset",
                marginRight: "5px",
              }}
              checked={attestationFirstCheckbox}
              onChange={(e) => {
                dispatch(setFirstAttestationSignature(e.target.checked));
              }}
              type="checkbox"
            />
            I have read and agree to the statement.
          </label>
          <USCISDivider />
        </>
      );
    }

    if (sectionName === "I129Checkbox_legal") {
      return (
        <>
          <label style={{ display: "flex" }}>
            <input
              id="legal_checkbox"
              name="legal agreement"
              style={{
                position: "relative",
                margin: "unset",
                marginRight: "5px",
              }}
              checked={attestationSecondCheckox}
              onChange={(e) => {
                dispatch(setSecondAttestationSignature(e.target.checked));
              }}
              type="checkbox"
            />
            I have read and agree to the statement.
          </label>
          <USCISDivider />
        </>
      );
    }

    return (
      <>
        <label style={{ display: "flex" }}>
          <input
            id="employer_checkbox"
            name="applicant employer"
            style={{
              position: "relative",
              margin: "unset",
              marginRight: "5px",
            }}
            type="checkbox"
          />
          If I have selected this box, I am certifying that I have received a notice of acceptance from the Department of Labor for the
          ETA Case Number identified in Part 5., Item Number 2. and am not required to submit the temporary labor certification at the time of filing.
        </label>
        <USCISDivider />
      </>
    );
  };

  const startEsignProcess = async () => {
    try {
      const response = await fetch("https://geolocation-db.com/json/");
      const data = await response.json();
      const submission = await SubmissionService.esignForm(
        myUscisId,
        submissionId,
        primaryForm!.formId,
        {
          esignDate: new Date(),
          applicantFullName: attestationSignature,
          timeZone: timeZone,
          browserInformation: navigator.userAgent,
          ipAddress: data.IPv4,
        },
        userGroupId,
      );
      dispatch(setShowPayAndSubmitInAccordion(true));
      dispatch(setUserAttestedAt(submission.attestedAt));
      dispatch(setIsPollingForAttestationStatus(true));
      dispatch(setHasReviewedSignature(true));
    } catch (error) {
      console.error(error);
    }
  };

  const skipEsign = async () => {
    try {
      setShouldNavigateNext(true);
      const submission = await SubmissionService.updateSignatureReviewed(
        myUscisId,
        submissionId,
        true,
        userGroupId,
      );
      dispatch(setUserAttestedAt(submission.attestedAt));
      dispatch(setHasReviewedSignature(true));
      dispatch(setShowPayAndSubmitInAccordion(true));
    } catch (error) {
      setShouldNavigateNext(false);
      console.error(error);
    }
  };

  let attestationContent;
  const formType = store.formMetadata.formMetadata.formType;

  if (formType === "I-129H1B") {
    const eligibilitySubcategory = store.submission.eligibilitySubcategory;
    attestationContent = getCertificationContent(accountType, eligibilitySubcategory);
  } else {
    attestationContent = getCertificationContent(accountType, primaryFormType);
  }

  const is140OrgFiler = (primaryForm?.formType === FormTypes.I140) && isUserPartOfOrg;

  // Use the helper function for e-sign eligibility
  const shouldShowEsign = shouldShowEsignForm({
    isSignaturePresent,
    attested,
    isUserPartOfOrg,
    accountType: accountType as ShouldShowEsignFormParams["accountType"],
    canUserPayAndSubmit,
    formType: primaryFormType,
  });

  const nextDisabled = isNextDisabled({
  attested,
  attestationSignature,
  isSignaturePresent,
  isRepresentative,
  isUserPartOfOrg,
  nextButtonValidation: () => isNextValid,
});

  return (
    <Section className={classes.wrapper}>
      <h2>{attestationContent.title}</h2>
      <Markdown>{attestationContent.content}</Markdown>
      <div role="alert" aria-live="assertive">
        {is140OrgFiler && !isSignaturePresent && (
          <Alert variant="error" maxWidth focus>
            <AlertHeader>Error</AlertHeader>
            <AlertDescription>
              Please sign your form with a wet signature.
              <br />
              <br />
              {formValidationState?.details.map((validation) => {
                if (validation.validator === Validators.SIGNATURE) {
                  formValidationState?.details
                    ?.filter(
                      (validation) =>
                        validation.validator !== Validators.SIGNATURE
                    )
                    .map((validation) =>
                      validation.reasons.map((reason) => (
                        <span
                          key={reason}
                          style={{ display: "block", margin: "12px 0" }}
                        >
                          <Markdown>{reason}</Markdown>
                        </span>
                      )),
                    );
                }
                return null;
              })}
            </AlertDescription>
          </Alert>
        )}
        <div className={classes.blueBox}>
          <img
            src={RoundLogo}
            className={classes.logo}
            style={{ margin: "0" }}
            alt="U.S. Citizenship and Immigration Services, Upholding America's Promise"
          />
          <div className={classes.blueBoxContent}>
            {attestationContent.sections.map((section: any, idx: number) => (
              <div className={classes.markdown} key={idx}>
                <Markdown>{section.sectionText}</Markdown>
                <USCISDivider />
                {section.sectionElement && ReturnCheckSection(section.sectionElement)}
              </div>
            ))}
            <label className={classes.checkboxLabel}>
              <input
                id="agreement_checkbox"
                name="applicant agreement"
                style={{
                  position: "relative",
                  margin: "unset",
                  marginRight: "5px",
                }}
                type="checkbox"
                onChange={(e) => {
                  dispatch(setUserAttested(e.target.checked));
                }}
                checked={attested}
              />
              {attestationContent.labelText}
            </label>

            {/* Signature Detected Message */}
            {isSignaturePresent && attested && (
              <>
                <h3>Your Signature Is Detected</h3>
                <p>We have detected a signature on your uploaded form.</p>
                <p>
                  By checking the box you agree and affirm to this Declaration and
                  Certification. We will record your agreement with your uploaded
                  form.
                </p>
                <p>
                  Before pressing the &quot;SUBMIT&quot; button, please ensure that the signature
                  you provided on the PDF complies with USCIS regulations and policies.
                  Namely, the signature must be handwritten, may not be typed, created by
                  a typewriter, word processor, stamp, auto-pen, or similar device.
                </p>
                <p>
                  We may deny your benefit request if you do not complete the form
                  or you do not include required evidence.
                </p>
              </>
            )}

            {/* E-sign UI */}
            {shouldShowEsign && (
              <>
                <h3>You Must Sign Your Form</h3>
                <p>
                  You must provide your electronic signature below by typing your full legal name.
                </p>
                <p>
                  We may deny your benefit request if you do not completely fill out the form or fail to submit required documents. We will record the date of your signature with your petition.
                </p>
                <label className={classes.textInputLabel}>
                  <input
                    type="text"
                    id="signature_field"
                    name="signature"
                    required
                    style={{
                      position: "relative",
                      margin: "unset",
                      marginTop: "10px",
                      height: "40px",
                    }}
                    value={attestationSignature}
                    onChange={(e) => {
                      dispatch(setAttestationSignature(e.target.value));
                    }}
                  />
                  <b>Your signature</b>
                </label>
              </>
            )}
          </div>
        </div>

        <div>
          <USCISDivider />
          <NavigationButtons
            onNext={isSignaturePresent ? skipEsign : startEsignProcess}
            disableNext={nextDisabled}
          />
        </div>
        <AttestationLoadingDialog loading={isPollingForAttestationStatus} />
      </div>
    </Section>
  );
};

export default YourSignature;

const useStyles = makeStyles()((theme) => ({
  blueBox: {
    position: "relative",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    backgroundColor: "#e0f1ff",
    margin: "64px 0",
    padding: "32px",
    [theme.breakpoints.up("sm")]: {
      padding: "54px",
    },
  },
  logo: {
    position: "absolute",
    top: "-25px",
  },
  wrapper: {
    width: "80%",
    paddingTop: "32px",
  },
  blueBoxContent: {
    textAlign: "left",
    width: "100%",
  },
  checkboxLabel: {
    display: "flex",
    fontSize: "16px",
  },
  textInputLabel: {
    display: "flex",
    flexDirection: "column-reverse",
    marginTop: "32px",
  },
  submitButton: {
    display: "flex",
    flexDirection: "column",
  },
  desktopButton: {
    display: "flex",
    justifyContent: "space-between",
    margin: "32px 0",
  },
  markdown: {
    "& p": {
      margin: 0,
      "&:first-of-type": {
        marginTop: "18px",
      },
    },
    "& ol": {
      paddingLeft: "12px",
      margin: "0 !important",
      "& li::marker": {
        fontSize: "18px",
      },
    },
  },
}));
