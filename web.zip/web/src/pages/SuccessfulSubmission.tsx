import { useEffect, useLayoutEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { makeStyles } from "tss-react/mui";
import { Grid, Button, Typography } from "myuscis-material";

import Section from "../components/shared/Section";
import USCISDivider from "../components/shared/USCISDivider";
import { RootState } from "../redux/store";

const useStyles = makeStyles()((theme) => ({
  container: {
    backgroundColor: "#ffffff",
    margin: "64px auto",
    [theme.breakpoints.up("sm")]: {
      maxWidth: "1028px",
      maxHeight: "auto",
    },
  },
  content: {
    position: "relative",
    justifyContent: "left",
    padding: "0 20%",
  },
  button: {
    width: "100%",
    overflowWrap: "break-word",
    whiteSpace: "normal",
    [theme.breakpoints.up("sm")]: {
      width: "min-content",
    },
  },
}));

interface Props {
  isNotify: boolean
}

export const SuccessfulSubmission = ({isNotify}: Props) => {
  useEffect(() => {document.title = "USCIS | Successful Submission";}, []);
  const { classes } = useStyles();
  const navigate = useNavigate();

  const { isSubmissionSubmitted, feeTotal } = useSelector(
    (state: RootState) => state.submission,
  );

  const { formMetadata } = useSelector(
    (state: RootState) => state.formMetadata,
  );

  useLayoutEffect(() => {
    if (!isSubmissionSubmitted && !isNotify) {
      navigate(`/pdf-intake/${formMetadata.formType}`);
    }
  }, [isSubmissionSubmitted, navigate, formMetadata.formType, isNotify]);

  return (
    <Section>
      <Grid container className={classes.container}>
        <Grid item container xs={12} className={classes.content}>
          {!isNotify && (
            <>
            <Typography variant="h2">
              You successfully submitted the PDF of Form {formMetadata.formType} 
            </Typography>
            {feeTotal === 0 ? (
              <>
                <p>
                  The acceptance of your case may take up to 30 days.
                </p>
                <p>
                  If you requested a fee waiver, your fee waiver request is
                  currently being evaluated. In the event your fee waiver request is
                  denied, your form will be rejected. You may resubmit your form if
                  it is rejected. We will contact you if we have any questions or
                  need additional information. You can track the status of your
                  application or petition through your USCIS online account.
                </p>
              </>
            ) : (
              <>
                <p>
                  Initial processing of your online PDF submission may take up to 30 days. 
                  You will receive a notification in your USCIS online account after your form has completed initial processing. 
                </p>
                <p>
                  If your online PDF submission meets the criteria for initial processing, 
                  we will mail you a Receipt Notice to the mailing addresses provided on your form.
                </p>
                <p>
                  <b>Note:</b> If you requested a fee waiver and it is denied,
                 your Form I-765 will be rejected. If your form is rejected, you can resubmit your form by starting a new draft.
                </p>
              </>
              )}
            </>
          )}
          {isNotify && (
            <>
              <Typography variant="h2">
                The notification to review your draft {formMetadata.formType} PDF form was sent.
              </Typography>
              <p>If the administrator does not approve the information provided, you will need to edit the information in the form and submit the form for review again.</p>
            </>
          )}
          <Grid item xs={12}>
            <USCISDivider />
          </Grid>

          <Button
            variant="contained"
            onClick={() => {}}
            href="redirect/account"
            className={classes.button}
            style={{ color: "#ffffff" }}
          >
            Go to my cases
          </Button>
        </Grid>
      </Grid>
    </Section>
  );
};
