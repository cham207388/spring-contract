import { Checkbox, CheckboxGroup, Grid, Typography } from "myuscis-material";
import { makeStyles } from "tss-react/mui";
import { useAppDispatch } from "../redux/store";
import USCISDivider from "../components/shared/USCISDivider";
import NavigationButtons from "../components/NavigationButtons";
import { FormTypes } from "../types/FormMetaData";
import { useState } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../redux/store";
import AcceptedFormTypes from "../constants/AcceptedFormTypes";
import { setSelectedConcurrentForms } from "../redux/submissionSlice";
import Section from "../components/shared/Section";

const useStyles = makeStyles()((theme) => ({
  container: {
    backgroundColor: "#ffffff",
    margin: "64px auto",
    paddingInline: "2rem",
    [theme.breakpoints.up("md")]: {
      maxWidth: "1028px",
      maxHeight: "auto",
      display: "flex",
      displayDirection: "column",
      paddingInline: 0,
      "& .MuiGrid-grid-xs-10": {
        marginLeft: "-3rem",
      },
    },
  },
  divider: {
    paddingLeft: "25%",
    maxWidth: "85%",
    paddingTop: "32px",
  },
  section: {
    position: "relative",
    justifyContent: "left",
    padding: "0 25%",
  },
}));

type Props = {
  handlePrevious?: () => void;
  handleNext: () => void;
  formType: string;
  concurrentForms: string[]
};

export const ConcurrentFiling = ({
  handlePrevious,
  handleNext,
  formType,
  concurrentForms
}: Props) => {
  const { classes } = useStyles();
  const [concurrentFormTypes, setConcurrentFormTypes] = useState<FormTypes[]>([]);
  const dispatch = useAppDispatch();
  const { isApplicantOrRep } = useSelector((state: RootState) => state.user);

  const getFormLabel = (form: string) => {
    if(formType === AcceptedFormTypes.I_485) {
      if(isApplicantOrRep && form === AcceptedFormTypes.I_485J) {
        return `${form} only available for I-485 Employment Based Applications`
      }
    }
    return form;
  }

  const setConcurrentForms = (value: String, checked: boolean) => {
    let form = value as FormTypes;
    checked ? setConcurrentFormTypes(currentForms => [...currentForms, form]) :
      setConcurrentFormTypes(currentForms => currentForms.filter(f => f !== form))
    dispatch(setSelectedConcurrentForms(concurrentFormTypes));
  };

  const setupHandleNext = (next: () => void) => {
    dispatch(setSelectedConcurrentForms(concurrentFormTypes))
    handleNext();
  };

  return <>
    <Section>
      <Grid container columns={1} className={classes.container}>
        <Grid item container className={classes.section}>

          <Typography
            variant="h3"
          >
            If you would like to concurrently file other forms with your {formType},
            please select the form type(s) you would like to file from the dropdown menu.
          </Typography>
          <CheckboxGroup>
            {concurrentForms.length > 0 && concurrentForms.map((form) => (
              <div key={form}>
                <Checkbox label={`${getFormLabel(form)}`} value={form} checked={concurrentFormTypes.includes(form as FormTypes)} onChange={(e) => setConcurrentForms(e.target.value, e.target.checked)} />
              </div>
            ))}
          </CheckboxGroup>
        </Grid>

      <Grid item container xs={12}>
        <Grid item xs={12} className={classes.divider}>
          <USCISDivider />
          <NavigationButtons
            showBackButton={typeof handlePrevious !== "undefined"}
            customPrevious={handlePrevious}
            disableNext={false}
            onNext={setupHandleNext}
          />
        </Grid>
      </Grid>
      </Grid>
    </Section>

  </>
};

export default ConcurrentFiling;