import { Alert, AlertDescription, AlertHeader } from "myuscis-material";
import { SetStateAction, useEffect, useId, useState } from "react";
import { FileRejection } from "react-dropzone";
import { useDispatch, useSelector } from "react-redux";
import { makeStyles } from "tss-react/mui";

import { Typography } from "@mui/material";
import { redirect } from "react-router-dom";
import { SubmissionService } from "../api/SubmissionService";
import FeeWaiverDropzone from "../components/FeeWaiverDropzone";
import FeeWaiverSupportDropzone from "../components/FeeWaiverSupportDropzone";
import FileErrorAlert from "../components/FileErrorAlert";
import NavigationButtons from "../components/NavigationButtons";
import YesNoChoiceComponent from "../components/YesNoChoice";
import AlertWindow from "../components/shared/AlertWindow";
import { EvidenceWarning } from "../components/shared/EvidenceWarning";
import OtherFileRequirements from "../components/shared/FileRequirements";
import Section from "../components/shared/Section";
import USCISDivider from "../components/shared/USCISDivider";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";
import { AppDispatch, RootState } from "../redux/store";
import {
  hydrateState,
  setFeeWaiverRequested,
  setPartialFeeWaiverRequested,
} from "../redux/submissionSlice";

import {
  setIsPollingForFormValidation,
  setIsPollingForFeeWaiverValidation,
  setFeeWaiverValidation,
} from "../redux/validationsSlice";

import { possibleFileTypes } from "../types/Dropzone";
import { EvidenceGroup, FormTypes } from "../types/FormMetaData";
import { Paths } from "../router/Paths";

const useStyles = makeStyles()({
  alertWindow: {
    margin: "32px 0",
  },
  mobileRadioButtons: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: "32px",
  },
  marginTop: {
    marginTop: "20px",
  },
  marginBottom: {
    marginBottom: "32px",
  },
  label: {
    fontSize: "20px",
  },
});

const FeeWaiverInformation = ({
  classes,
}: {
  classes: Record<
    "alertWindow" | "marginBottom" | "mobileRadioButtons" | "label",
    string
  >;
}) => {
  return (
    <div className={classes.alertWindow} role="alert" aria-live="assertive">
      <Alert variant="warning" maxWidthOverride="100%">
        <AlertHeader>
          <Typography variant="h3">Requesting a Fee Waiver</Typography>
        </AlertHeader>
        <AlertDescription>
          <p>
            Complete the most current version of{" "}
            <a
              href="https://www.uscis.gov/i-912"
              target="_blank"
              rel="noopener noreferrer"
            >
              Form I-912, Request for Fee Waiver
            </a>
            , or write and sign a letter asking for a fee waiver and provide all
            the necessary information and supporting evidence to establish your
            eligibility. You must clearly demonstrate that you are unable to pay
            the filing fees.
          </p>
          <p>
            Please follow all instructions, complete all necessary sections of
            Form I-912, or your letter, and submit proper documentation to avoid
            common rejection reasons. (
            <a
              href="https://www.uscis.gov/forms/filing-fees/additional-information-on-filing-a-fee-waiver"
              target="_blank"
              rel="noopener noreferrer"
            >
              See Common reasons why we reject fee waiver requests
            </a>
            ).
          </p>
          <Typography variant="h3">Eligibility for a Fee Waiver</Typography>
          <p>You can request a fee waiver if:</p>
          <ul>
            <li>
              The form you are filing is eligible for a fee waiver and you meet
              any applicable conditions (see our{" "}
              <a
                href="https://www.uscis.gov/g-1055"
                target="_blank"
                rel="noopener noreferrer"
              >
                Additional Information on Filing a Fee Waiver
              </a>{" "}
              page)
            </li>
            <li>
              You must provide documentation showing that you qualify based upon
              one of the following criteria:
              <ul>
                <li>
                  You, your spouse, your child, your parent (if you are under 21
                  or disabled), or your sibling (if you and the sibling are
                  under 21) living with you, are currently receiving a
                  means-tested benefit.
                </li>
                <li>
                  Your household income is at or below 150% of the{" "}
                  <a
                    href="https://aspe.hhs.gov/topics/poverty-economic-mobility/poverty-guidelines"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Federal Poverty Guidelines
                  </a>{" "}
                  at the time you file.
                </li>
                <li>
                  You are currently experiencing extreme financial hardship,
                  including hardship from unexpected medical bills or
                  emergencies, that prevents you from paying the filing fee.
                </li>
              </ul>
            </li>
          </ul>
          <p>
            See the{" "}
            <a
              href="https://www.uscis.gov/forms/filing-fees/additional-information-on-filing-a-fee-waiver"
              target="_blank"
              rel="noopener noreferrer"
            >
              USCIS Fee Waiver Policy
            </a>{" "}
            for information on what you can upload as supplemental evidence to
            support your fee waiver request.
          </p>
          <Typography variant="h4">Paperwork Reduction Act</Typography>
          <p>
            USCIS may not conduct or sponsor an information collection, and you
            are not required to respond to a collection of information, unless
            it displays a currently valid Office of Management and Budget (OMB)
            control number. The public reporting burden for this collection of
            information is estimated at 1 hour per response, including the time
            for reviewing instructions, gathering the required documentation and
            information, completing the request, preparing statements, attaching
            necessary documentation, and submitting the request. Send comments
            regarding this burden estimate or any other aspect of this
            collection of information, including suggestions for reducing this
            burden, to:
          </p>
          <p>
            U.S. Citizenship and Immigration Services, Office of Policy and
            Strategy, Regulatory Coordination Division, 5900 Capitol Gateway
            Drive, Mail Stop #2140, Camp Springs, MD 20588-0009; OMB No.
            1615-0116.
          </p>
          <p>
            <b>
              Do not mail your completed Form I-912 to this address. We
              recommend that you print or save a copy of your completed request
              to review in the future and for your records.
            </b>
          </p>
          <p>
            OMB No. 1615-0116
            <br />
            Expires: 03/31/2027
          </p>
        </AlertDescription>
      </Alert>
    </div>
  );
};

const Dropzone = ({
  setShowAlert,
  setFileRejections,
  fileRejections,
  showAlert,
}: {
  setShowAlert: (value: SetStateAction<boolean> | boolean) => void;
  setFileRejections: (
    value: SetStateAction<FileRejection[]> | FileRejection[],
  ) => void;
  fileRejections: FileRejection[];
  showAlert: boolean;
}) => {
  return (
    <>
      <div>
        <Section>
          <Typography variant="h3">Upload Form I-912</Typography>
          <>
            <ul>
              <li>Upload one PDF file of the form;</li>
              <li>Include <strong>all</strong> pages of the form in the file, even if you did not provide any information on the page; and</li>
              <li>Arrange the form in the same order as its page numbers.</li>
            </ul>
            <p><strong>Do not</strong> include any evidence in the file. You will add your evidence later in the process.</p>
          </>

            <OtherFileRequirements
              maxFiles={1}
              accept={{
                "image/jpeg": possibleFileTypes.jpegTiff,
                "application/pdf": possibleFileTypes.pdf,
              }}
            />
          </Section>

          <FeeWaiverDropzone
            setShowAlert={setShowAlert}
            setFileRejections={setFileRejections}
          />
      </div>

      <FileErrorAlert
        fileRejections={fileRejections}
        showAlert={showAlert}
        setShowAlert={setShowAlert}
        acceptedTypes={{
          "image/jpeg": possibleFileTypes.jpegTiff,
          "application/pdf": possibleFileTypes.pdf,
        }}
      />
    </>
  );
};

const FeeSupportDropzone = ({
  setShowAlert,
  setFileRejections,
  fileRejections,
  showAlert,
  setShowEvidenceWarning,
}: {
  setShowAlert: (value: SetStateAction<boolean> | boolean) => void;
  setFileRejections: (
    value: SetStateAction<FileRejection[]> | FileRejection[],
  ) => void;
  fileRejections: FileRejection[];
  showAlert: boolean;
  setShowEvidenceWarning: (value: SetStateAction<boolean> | boolean) => void;
}) => {
  const { partialRequested: partialFeeWaiverRequested } = useSelector(
    (state: RootState) => state.submission.feeWaiver,
  );

  const conditionalText = partialFeeWaiverRequested ? "partial" : "";

  return (
    <>
      <AlertWindow
        headerText={`You are applying for a ${conditionalText} fee waiver`}
        variant="warning"
      >
        {`In the event your ${conditionalText} fee waiver request is denied, your form will be
rejected. You may resubmit your form if it is rejected.


Please ensure you have submitted supporting documentary evidence for
your ${conditionalText} fee waiver request. Failure to do so may result in your form
being rejected. You may upload any supporting documentary evidence
below.`}
      </AlertWindow>
      <div style={{ paddingTop: "2rem" }}>
        <Typography variant="h3">
          {partialFeeWaiverRequested
            ? "Upload supporting documents for your partial fee waiver request"
            : "Upload mandatory supporting documents for your fee waiver request"}
        </Typography>
        <Section>
          <OtherFileRequirements
            maxFiles={5}
            isFeeWaiverSupport
            accept={{
              "image/jpeg": possibleFileTypes.images,
              "application/pdf": possibleFileTypes.pdf,
            }}
          />
        </Section>
        <FeeWaiverSupportDropzone
          setShowAlert={setShowAlert}
          setFileRejections={setFileRejections}
          deleteWarningText={`"This will delete the ${conditionalText} fee waiver support"`}
          evidenceGroupType={"feeWaiver"}
          setShowEvidenceWarning={setShowEvidenceWarning}
          dropzoneProps={{
            maxSize: 12000000,
            maxFiles: 5,
            accept: {
              "image/jpeg": possibleFileTypes.images,
              "application/pdf": possibleFileTypes.pdf,
            },
          }}
        />
      </div>

      <FileErrorAlert
        fileRejections={fileRejections}
        showAlert={showAlert}
        setShowAlert={setShowAlert}
        acceptedTypes={{
          "image/jpeg": possibleFileTypes.jpegTiff,
          "application/pdf": possibleFileTypes.pdf,
        }}
      />
    </>
  );
};

const FeeWaiver = () => {
  useEffect(() => {document.title = "USCIS | Fee Waiver";}, []);
  const [showAlert, setShowAlert] = useState<boolean>(false);
  const [showProvideEvidenceWarning, setShowProvideEvidenceWarning] =
    useState<boolean>(false);
  const [fileRejections, setFileRejections] = useState<FileRejection[]>([]);
  const [showSupportAlert, setShowSupportAlert] = useState<boolean>(false);
  const [supportFileRejections, setSupportFileRejections] = useState<
    FileRejection[]
  >([]);
  const { classes } = useStyles();
  const radioLabelId = useId();

  const { formMetadata } = useSelector(
    (state: RootState) => state.formMetadata,
  );
  const formType = formMetadata.formType;

  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);
  const { submissionId, evidences } = useSelector(
    (state: RootState) => state.submission,
  );

  const {
    requested: feeWaiverRequested,
    partialRequested: partialFeeWaiverRequested,
    files: uploadedFiles,
  } = useSelector((state: RootState) => state.submission.feeWaiver);

  const dispatch = useDispatch<AppDispatch>();
  const evidenceGroups: EvidenceGroup[] = useSelector(
    (state: RootState) => state.evidence.evidenceGroups,
  );

  const { addAlert } = useAlertSnackbar();

  useEffect(() => {
    if (!!formMetadata && !formMetadata.feeWaiverEnabled)
      redirect(Paths.selectEligibility);
  }, [formMetadata]);

  const handleFeeWaiverSelection = (requestingFeeWaiver: boolean) => {
    SubmissionService.updateUserRequestedFeeWaiver(
      myUscisId,
      submissionId,
      requestingFeeWaiver,
      userGroupId,
    )
      .then((submission) => {
        dispatch(setFeeWaiverValidation(undefined));
        dispatch(setFeeWaiverRequested(requestingFeeWaiver));
        dispatch(hydrateState({ submission: submission, evidenceGroups }));
        if (!requestingFeeWaiver)
          dispatch(setIsPollingForFeeWaiverValidation(false));
        if (submission?.forms?.length > 0)
          dispatch(setIsPollingForFormValidation(true));
      })
      .catch((err) => {
        addAlert(
          "Ability to pay was not able to be updated. Please try again later",
        );
      });
  };

  const handlePartialFeeWaiverSelection = (
    requestingPartialFeeWaiver: boolean,
  ) => {
    SubmissionService.updateUserRequestedPartialFeeWaiver(
      myUscisId,
      submissionId,
      requestingPartialFeeWaiver,
      userGroupId,
    )
      .then((submission) => {
        dispatch(setFeeWaiverValidation(undefined));
        dispatch(setIsPollingForFeeWaiverValidation(false));
        dispatch(setPartialFeeWaiverRequested(requestingPartialFeeWaiver));
        dispatch(hydrateState({ submission: submission, evidenceGroups }));
      })
      .catch((err) => {
        addAlert(
          "Ability to pay was not able to be updated. Please try again later",
        );
      });
  };

  const handleNext = (next: () => void) => {
    if (!feeWaiverRequested) next();

    const foundSupportingEvidences = evidences.some(
      (evidence) => evidence.evidenceGroup === "feeWaiver",
    );

    foundSupportingEvidences || showProvideEvidenceWarning
      ? next()
      : setShowProvideEvidenceWarning(true);
  };

  const disableNext = partialFeeWaiverRequested
    ? false
    : !!feeWaiverRequested && uploadedFiles.length < 1;

  return (
    <div className={classes.marginTop}>
      <YesNoChoiceComponent
        direction="row"
        alignment={"center"}
        radioLabelId={radioLabelId}
        classes={classes}
        labelOverrideStyle={{ maxWidth: "20.4rem" }}
        choiceText={"Are you able to pay the filing fee?"}
        choiceTextVariant={"h3"}
        label={["Yes", "No"]}
        value={feeWaiverRequested ? "No" : "Yes"}
        handleOnChange={(e) =>
          handleFeeWaiverSelection(e.target.value === "No")
        }
      />

      {formType === FormTypes.N400 && feeWaiverRequested && (
        <div className={classes.marginTop}>
          <YesNoChoiceComponent
            direction="row"
            alignment={"center"}
            radioLabelId={radioLabelId}
            classes={classes}
            choiceText={"What type of fee waiver are you applying for?"}
            choiceTextVariant={"h3"}
            label={["Full", "Partial"]}
            value={partialFeeWaiverRequested ? "Partial" : "Full"}
            handleOnChange={(e) =>
              handlePartialFeeWaiverSelection(e.target.value === "Partial")
            }
          />

          {!partialFeeWaiverRequested && (
            <div role="alert" aria-live="assertive">
              <FeeWaiverInformation classes={classes} />
              <Dropzone
                setShowAlert={setShowAlert}
                setFileRejections={setFileRejections}
                fileRejections={fileRejections}
                showAlert={showAlert}
              />
              <Alert variant="warning" maxWidthOverride="100%">
                <AlertHeader>Your signature is required</AlertHeader>
                <AlertDescription>
                  <p>
                    Please ensure you have signed your fee waiver request.
                    Failure to do so may result in your application or petition being
                    rejected.
                  </p>
                </AlertDescription>
              </Alert>
              {uploadedFiles.length > 0 && (
                <div>
                  <FeeSupportDropzone
                    setShowAlert={setShowSupportAlert}
                    setFileRejections={setSupportFileRejections}
                    fileRejections={supportFileRejections}
                    showAlert={showSupportAlert}
                    setShowEvidenceWarning={setShowProvideEvidenceWarning}
                  />
                </div>
              )}
            </div>
          )}

          {partialFeeWaiverRequested && (
            <div>
              <FeeSupportDropzone
                setShowAlert={setShowSupportAlert}
                setFileRejections={setSupportFileRejections}
                fileRejections={supportFileRejections}
                showAlert={showSupportAlert}
                setShowEvidenceWarning={setShowProvideEvidenceWarning}
              />
            </div>
          )}
        </div>
      )}

      {formType !== FormTypes.N400 && feeWaiverRequested && (
        <div role="alert" aria-live="assertive">
          <FeeWaiverInformation classes={classes} />
          <Dropzone
            setShowAlert={setShowAlert}
            setFileRejections={setFileRejections}
            fileRejections={fileRejections}
            showAlert={showAlert}
          />
          <Alert variant="warning" maxWidthOverride="100%">
            <AlertHeader>Your signature is required</AlertHeader>
            <AlertDescription>
              <p>
                Please ensure you have signed your fee waiver request. Failure
                to do so may result in your application or petition being rejected.
              </p>
            </AlertDescription>
          </Alert>

          {uploadedFiles.length > 0 && (
            <div>
              <FeeSupportDropzone
                setShowAlert={setShowSupportAlert}
                setFileRejections={setSupportFileRejections}
                fileRejections={supportFileRejections}
                showAlert={showSupportAlert}
                setShowEvidenceWarning={setShowProvideEvidenceWarning}
              />
            </div>
          )}
        </div>
      )}

      {showProvideEvidenceWarning &&
        (partialFeeWaiverRequested ||
          (!!feeWaiverRequested && uploadedFiles.length > 0)) && (
          <EvidenceWarning
            variant="error"
            header="Supporting evidence required for fee waiver"
            message={
              <span>
                See the{" "}
                <a
                  href="https://www.uscis.gov/forms/filing-fees/additional-information-on-filing-a-fee-waiver"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  USCIS Fee Waiver Policy
                </a>{" "}
                for information on what you can upload as supplemental evidence
                to support your fee waiver request.
              </span>
            }
          />
        )}
      <USCISDivider />

      <NavigationButtons onNext={handleNext} disableNext={disableNext} />
    </div>
  );
};

export default FeeWaiver;
