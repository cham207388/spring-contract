import FormDropzone from "../components/FormDropzone";
import NavigationButtons from "../components/NavigationButtons";
import OtherFileRequirements from "../components/shared/FileRequirements";
import Section from "../components/shared/Section";
import USCISDivider from "../components/shared/USCISDivider";

const UploadG28Pdf = () => {
  const formType = "G-28";

  return (
    <>
      <Section>
        <h2>{formType} PDF Form Upload</h2>

        <p>
          Upload all pages of the Form&nbsp;
          <a
            href={`https://www.uscis.gov/${formType}`}
            target="_blank"
            rel="noreferrer"
          >
            {formType}
          </a>
          &nbsp;in PDF file format only. Place all pages in the correct order by
          referring to the page numbers on the form. Include all pages when
          uploading, whether filled out with your information or left
          intentionally blank.
        </p>
        <OtherFileRequirements
          maxFiles={1}
          accept={{
            "application/pdf": [".pdf"],
          }}
        />
      </Section>

      <FormDropzone formType={formType} />

      <USCISDivider />

      <NavigationButtons />
    </>
  );
};

export default UploadG28Pdf;
