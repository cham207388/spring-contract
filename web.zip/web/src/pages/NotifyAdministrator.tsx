import { Button, Checkbox, CheckboxGroup, RedAsterisk } from "myuscis-material";
import Section from "../components/shared/Section";
import { SubmissionService } from "../api/SubmissionService";
import { useSelector } from "react-redux";
import { RootState } from "../redux/store";
import { useEffect, useState } from "react";
import { Admin } from "../types/Admin";
import USCISDivider from "../components/shared/USCISDivider";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";
import { useNavigate } from "react-router-dom";
import AlertWindow from "../components/shared/AlertWindow";

const NotifyAdministrator = () => {

    const [administrators, setAdministrators] = useState<(Admin & {checked: boolean})[]>([]);

    const { submissionId, formType, sentNotify } = useSelector((state: RootState) => state.submission);
    const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);

    const { addAlert } = useAlertSnackbar();
    const navigate = useNavigate();
    
    useEffect(() => {
        async function getAdministrators() {
            const response = await SubmissionService.getAdministrators(
                myUscisId,
                submissionId,
                userGroupId
            );
            const administrators = response.map(admin => ({
                ...admin,
                checked: false
            }));
            setAdministrators(administrators);
        }
        getAdministrators();
    }, []);

    const handleCheck = (uuid: string) => {
        setAdministrators(administrators => 
            administrators.map(admin => 
                admin.uuid === uuid ? { ...admin, checked: !admin.checked } : admin
            )
        )
    }

    const notifyAdministrators = async () => {
        const uuids = administrators.filter(admin => admin.checked)
            .map(admin => admin.uuid);
        try {
            await SubmissionService.notifyAdministrator(
                myUscisId,
                submissionId,
                uuids,
                userGroupId
            );
            navigate(`/pdf-intake/${formType}/notify-success`);
        } catch(error) {
            addAlert('Unable to notify administrators, please try again later.')
        }
    }

    return (
        <div>
            <Section>
                <h2>Notify Administrator</h2>
                <p>
                    We will prepare a draft submission for an administrator to review and sign. If they do not approve the information provided, you will need to edit the information in the form and submit the form for review again.
                </p>
            </Section>
            <Section>
                <p>You must complete all fields with an asterick (<RedAsterisk />) to submit this form.</p>
            </Section>
            <Section>
                <p>Select the administrators who should review and sign the forms.<RedAsterisk/></p>
            </Section>
            <CheckboxGroup>
                {administrators.map((admin, index) => (
                    <Checkbox key={index} label={`${admin.lastName}, ${admin.firstName}`} 
                        checked={admin.checked}
                        onChange={(e) => handleCheck(admin.uuid)} />
                ))}
            </CheckboxGroup>
            <USCISDivider />
            {sentNotify && (
              <AlertWindow variant={"warning"}>
                Admin has already been notified.
              </AlertWindow>
            )}
            <Button variant="contained"
                disabled={!administrators.some(admin => admin.checked) || sentNotify}
                onClick={notifyAdministrators}>
                Notify Administrator
            </Button>
            
        </div>
    )
}

export default NotifyAdministrator;