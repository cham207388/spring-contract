import AlertWindow from "../../components/shared/AlertWindow";

export const I130Info = () => {
  return (
    <AlertWindow
      variant="information"
      headerText={`Before you begin`}
    >
    A petitioner is the U.S. citizen or legal permanent resident who files an alien petition on behalf of a family member.
    A beneficiary is the family member you are petitioning for. Currently, only the Petition for Alien Relative (I-130) is available online. <br/> <br/>
    <b>NOTE:</b> You cannot file Form I-485 or Form I-129F online at this time. Please see our Form I-485 and Form I-129F webpages for current filing information, 
    and refer to the form instructions for specific instructions on completing each of these forms. Only forms properly filed can be receipted and adjudicated. 
    Any Form I-485 or I-129F included as supporting evidence for your Form I-130 cannot be receipted or adjudicated.
    </AlertWindow>
  );
};

export const SpouseWarning = () => {
  return (
    <AlertWindow
      variant="warning"
      headerText={`You selected you are petitioning for a spouse`}
    >
      You will need to upload the Supplemental Information for Spouse Beneficiary &nbsp;     
      <a
        href="https://www.uscis.gov/sites/default/files/document/forms/i-130a.pdf"
        target="_blank"
        rel="noopener noreferrer"
      >
        I-130A
      </a> 
      &nbsp; as a part of the evidence for this petition.
    </AlertWindow>
  );
};

export const ParentWarning = () => {
  return (
    <AlertWindow
      variant="warning"
      headerText={`You may not meet the eligibility requirement for your petition`}
    >
      If you are petitioning for your parent, you must be a U.S. citizen at the time of your petition.
    </AlertWindow>
  );
};
