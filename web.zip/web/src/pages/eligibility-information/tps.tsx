import AlertWindow from "../../components/shared/AlertWindow";

export const TPS = () => {
  return (
    <AlertWindow variant="warning" headerText={`You must file Form I-821`}>
      {`Based on the eligibility category you selected and your A-number, 
      you may be a TPS applicant or recipient and must file Form I-821 before 
      you file Form I-765. If you are not a TPS recipient, amend your eligibility 
      category before proceeding.
      \\
      \\
      If you are a TPS applicant or recipient, upload evidence that we accepted or 
      approved your Form I-821, otherwise, we will reject your application and 
      you will not receive a refund.`}
    </AlertWindow>
  );
};
