import { Typography } from "myuscis-material";
import AlertWindow from "../../components/shared/AlertWindow";

export const C9Warning = () => {
  return (
    <AlertWindow variant="warning">
      If you are applying for the (c)(9) Pending Adjustment of Status category
      of Form I-765 that is fee exempted, do not submit your application through
      PDF Intake at this time.{" "}
      <strong>
        <u>
          If you file an I-765 for the (c)(9) category you will be required to
          pay a fee or submit a fee waiver request
        </u>
      </strong>
      . If you are fee-exempt and proceed with paying the fee and submitting
      your application through PDF Intake,{" "}
      <strong>USCIS will not issue you a refund</strong>.
      <Typography
        variant="h5"
        sx={{ fontSize: "16px", fontWeight: "bold", marginTop: "16px" }}
      >
        Fee Exemptions:
      </Typography>
      The following (c)(9) categories are exempt from a filing fee for Form
      I-765:
      <ul>
        <li>Special Immigrant Juveniles (SIJ) seeking to adjust status</li>
        <li>
          T nonimmigrants seeking to adjust status under the Immigration and
          Nationality Act (INA) section 245(l)
        </li>
        <li>
          Persons seeking adjustment of status as a Special Immigrant Iraqi or
          Afghan national
        </li>
        <li>
          Persons seeking adjustment of status as an abused spouse and children
          under the Cuban Adjustment Act (CAA) or the Haitian Refugee
          Immigration Fairness Act (HRIFA)
        </li>
        <li>
          U nonimmigrants seeking to adjust status under INA section 245(m)
        </li>
        <li>
          Persons seeking adjustment of status as a Special Immigrant Iraqi or
          Afghan national
        </li>
        <li>
          Persons seeking adjustment of status as a Violence Against Women Act
          (VAWA) self-petitioner (including derivatives)
        </li>
        <li>
          Refugees, persons paroled as refugees, or LPRs who obtained status as
          refugees
        </li>
      </ul>
    </AlertWindow>
  );
};
