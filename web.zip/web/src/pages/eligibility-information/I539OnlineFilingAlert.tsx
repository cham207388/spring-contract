import AlertWindow from "../../components/shared/AlertWindow";

export const I539OnlineFilingAlert = () => {
 return (
   <AlertWindow variant="warning">
     <strong>Online filing is only available for certain applicants</strong>
     <br />
     At this time, you cannot file online if you:
     <ul>
       <li>Are including derivative co-applicants in your application, or</li>
       <li>Currently hold A, G, NATO, V, T, or U nonimmigrant status.</li>
     </ul>
     If you are ineligible for online filing must file by mailing a{" "}
     <a href="https://www.uscis.gov/i-539" target="_blank">paper Form I-539</a> to USCIS at the designated address. See{" "}
     <a href="https://www.uscis.gov/i-539-addresses" target="_blank">https://www.uscis.gov/i-539-addresses</a>.
   </AlertWindow>
 );
};