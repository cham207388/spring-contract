import AlertWindow from "../../components/shared/AlertWindow";
import { FormTypes } from "../../types/FormMetaData";
import { I539DerivativeAlertCategories, I539DerivativeAlertSubCategories } from "../../types/I539Types";

const { E1, E2, E2C, E3 } = I539DerivativeAlertCategories;
const { EXTENSION_OF_STAY_IN_CURRENT_STATUS } = I539DerivativeAlertSubCategories;

const derivativeAlertCategories: string[] = [E1, E2, E2C, E3];
const derivativeAlertSubcategories: string[] = [EXTENSION_OF_STAY_IN_CURRENT_STATUS];

export const EligibilityAlerts = ({ formType, eligibilityType, eligibilitySubType }: {
  formType: string
  eligibilityType: string,
  eligibilitySubType: string | undefined
}) => {
  return (
    <>
      <AlertWindow
        variant="warning"
        headerText={`You can file your request online only for certain statuses`}
      >
        {(formType === FormTypes.I539) &&
          <p>
            Read <a href={`https://www.uscis.gov/sites/default/files/document/forms/${formType.toLowerCase()}instr.pdf`} target="_blank">Instructions for Form {formType}</a> to see if you can use this online form for your nonimmigrant status.
          </p>
        }

        <p>
          If your nonimmigrant status does not appear on the current nonimmigrant status dropdown list, you must file a <a href={`https://www.uscis.gov/${formType}`} target="_blank">paper Form {formType}</a>.
        </p>

      </AlertWindow>

      {(derivativeAlertCategories.includes(eligibilityType) && derivativeAlertSubcategories.includes(eligibilitySubType ?? "")) && (
        <AlertWindow
          variant="warning"
          headerText={`You can only request an extension of stay if you are a derivative`}>
          <p>
            Based on your selected current nonimmigrant status, you can only extend your stay if you are a derivative. If you are a principal, you cannot extend your stay with this status.
          </p>
        </AlertWindow>
      )}
    </>
  );
};
