import AlertWindow from "../../components/shared/AlertWindow";

export const Parolee = () => {
  return (
    <AlertWindow
      variant="information"
      headerText={`You can now file an EAD application after being paroled into the United States`}
    >
      Pursuant to the Feb. 7, 2022 ruling in Asylumworks et al. v. Mayorkas et
      al., credible fear parolees may file an EAD application at any time after
      being paroled into the United States, and may seek employment
      authorization under the (c)(11) category at the time of filing.
    </AlertWindow>
  );
};
