import { RadioButtons } from "myuscis-material"
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";

export type I129H2ARequestedActionProps = {
    eligibilityType: string,
    handleOnChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
};

export const I129H2A_REQUESTED_ACTIONS = {
    NOTIFY_OFFICE: 'NOTIFY_OFFICE',
    CHANGE_STATUS: 'CHANGE_STATUS',
    EXTEND_STAY: 'EXTEND_STAY',
    AMEND_STAY: 'AMEND_STAY'
}

const I129H2ARequestedAction = ({ eligibilityType, handleOnChange }: I129H2ARequestedActionProps) => {

    const {
        reasonForFiling
      } = useSelector((state: RootState) => state.submission);

    const options = [
        {
            label: 'Notify the office so each beneficiary can obtain a visa or be admitted',
            value: I129H2A_REQUESTED_ACTIONS.NOTIFY_OFFICE,
            exclude: []
        },
        {
            label: 'Change the status and extend the stay of each beneficiary because the beneficiary(ies) is/are now in the United States in another status',
            value: I129H2A_REQUESTED_ACTIONS.CHANGE_STATUS,
            exclude: ['CONTINUATION_OF_PREVIOUSLY_APPROVED_EMPLOYMENT_WITH_SAME_EMPLOYER', 'CHANGE_IN_PREVIOUSLY_APPROVED_EMPLOYMENT', 'NEW_CONCURRENT_EMPLOYMENT', 'CHANGE_OF_EMPLOYER', 'AMENDED_PETITION']
        },
        {
            label: 'Extend the stay of each beneficiary because the beneficiary(ies) now hold(s) this status',
            value: I129H2A_REQUESTED_ACTIONS.EXTEND_STAY,
            exclude: []
        },
        {
            label: 'Amend the stay of each beneficiary because the beneficiary(ies) now hold(s) this status and is/are not seeking additional time from the current authorized period of stay',
            value: I129H2A_REQUESTED_ACTIONS.AMEND_STAY,
            exclude: []
        }
    ];

    return (
        <div>
            <h4>Requested Action</h4>
            <RadioButtons id='h2a-requested-action-radio-buttons' 
                onChange={handleOnChange}
                value={reasonForFiling}
                options={options.filter((option => option.exclude.indexOf(eligibilityType) === -1))} />
        </div>
    );
}

export default I129H2ARequestedAction;