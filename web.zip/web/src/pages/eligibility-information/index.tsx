import { ReactNode } from "react";
import { Asylum } from "./asylum";
import { C9Warning } from "./C9Warning";
import { Parolee } from "./parolee";
import { TPS } from "./tps";

export const eligibilityInformationMap: Record<string, ReactNode> = {
  A12: <TPS />,
  C19: <TPS />,
  "C11 - Parole": <Parolee />,
  "C11 - Afghan Parolee": <Parolee />,
  "C11 - Ukraine Parolee": <Parolee />,
  C8: <Asylum />,
  C9: <C9Warning />,
};
