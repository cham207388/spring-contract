import AlertWindow from "../../components/shared/AlertWindow";

export const Asylum = () => {
  return (
    <div>
      <AlertWindow
        variant="warning"
        headerText={`Special filing instructions for applicants with pending asylum applications`}
      >
        You must wait 150-days after you file your asylum application before you
        can apply for employment authorization. There is also a 30-day wait period
        before we can issue your employment authorization card. You are subject to
        a total waiting period of 180-days.&nbsp;
        <a
          href="https://www.uscis.gov/sites/default/files/document/forms/i-765instr.pdf"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn more about special filing instructions for asylum applications.
        </a>
      </AlertWindow>
      <AlertWindow
        variant="warning"
        headerText={`Special Filing Instructions for ABC`}>
        If you are applying as ABC, you will have to mark on your form Question 6 under Part 3.
      </AlertWindow>
    </div>
  );
};
