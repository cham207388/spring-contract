import {
  Box,
  DataWrapper,
  FormControlSpacer,
  RadioButtons,
} from "myuscis-material";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "../../redux/store";
import { useMemo } from "react";
import { setFormSpecificInfo } from "../../redux/submissionSlice";
import { SubmissionService } from "../../api/SubmissionService";
import USCISDivider from "../../components/shared/USCISDivider";
import { FormMetaData } from "../../types/FormMetaData";

const ActionRequested = () => {
  const {
    formType,
    submissionId,
    formSpecificInfo,
    eligibilityCategory,
    eligibilitySubcategory
  } = useSelector((state: RootState) => state.submission);
  const {
    formMetadata
  } = useSelector((state: RootState) => state.formMetadata);
  const { myUscisId } = useSelector((state: RootState) => state.user);

  const getActionRequestedOptions = (formMetadata: FormMetaData, eligibilityCategoryCode: string, eligibilitySubcategoryCode: string) => {
    if (!(formMetadata && eligibilityCategoryCode && eligibilitySubcategoryCode)) { return []; }
    const eligibilityCategory = formMetadata.eligibilityCategories.find(eligibilityCategory => eligibilityCategory.category === eligibilityCategoryCode);
    if (!eligibilityCategory) { return []; }
    const eligibilitySubcategory = eligibilityCategory.metaData?.subcategories.find(eligibilitySubcategory => eligibilitySubcategory?.category === eligibilitySubcategoryCode);
    if (!eligibilitySubcategory) { return []; }
    return eligibilitySubcategory.actionRequestedOptions || [];

  }

  const actionRequestedOptions = useMemo(
    () => getActionRequestedOptions(formMetadata, eligibilityCategory, eligibilitySubcategory || '')
      .map(option => { return {
        label: option.label,
        value: option.category
      } }),
    [formMetadata, eligibilityCategory, eligibilitySubcategory]
  );

  const dispatch = useAppDispatch();
  const actionRequested = formSpecificInfo?.actionRequested ?? '';

  const handleSelectActionRequested = async (value: string) => {
    const updatedFormSpecificInfo = {...formSpecificInfo, actionRequested: value, formType };

    try {
      await SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        updatedFormSpecificInfo
      );

      dispatch(setFormSpecificInfo(updatedFormSpecificInfo))
    } catch (error) {
      console.error(error)
    }
  }

  if(!(actionRequestedOptions && actionRequestedOptions.length)) return (<></>);
  return (
    <>
    <USCISDivider/>
    <Box
      sx={{
        '& h3': {
          fontWeight: "bold",
          lineHeight: "1.15",
          color: "black"
        },
      }}>
    <DataWrapper
        noDivider={true}
        question="What action are you requesting?"
    >
      <FormControlSpacer columns={1}>
        <RadioButtons
          onChange={(event, value) => handleSelectActionRequested(value)}
          name={"action-requested"}
          value={actionRequested}
          options={actionRequestedOptions}
        />
      </FormControlSpacer>
    </DataWrapper>
    </Box>
    </>
  );
};

export default ActionRequested;