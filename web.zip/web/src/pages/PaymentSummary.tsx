import {
  faCircleCheck,
  faCircleXmark,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useMediaQuery, useTheme } from "@mui/material";
import { Grid, Typography } from "myuscis-material";
import { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLoaderData, useNavigate } from "react-router-dom";
import { makeStyles } from "tss-react/mui";
import { PaymentService } from "../api/PaymentService";
import { SubmissionService } from "../api/SubmissionService";
import UploadingDialog from "../components/Dialogs/UploadingDialog";
import Section from "../components/shared/Section";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";
import { Steps } from "../hooks/useSteps";
import { RootState } from "../redux/store";
import { setIsSubmissionSubmitted } from "../redux/submissionSlice";

const useStyles = makeStyles()({
  accordion: {
    boxShadow: "none",
    borderTop: "1px solid #EBEBEB",
    borderRadius: "0 !important",
    fontSize: "16px",
  },
  activeAccordionItem: {
    borderLeft: "4px solid rgb(0, 84, 153)",
    backgroundColor: "#EBEBEB",
    fontSize: "16px",
  },
  accordionTextPadding: {
    padding: "16px",
  },
  desktopContainer: {
    maxWidth: "1028px",
    maxHeight: "auto",
    backgroundColor: "#ffffff",
    margin: "64px auto",
    display: "flex",
    displayDirection: "column",
  },
  mobileContainer: {
    backgroundColor: "#ffffff",
    margin: "64px auto",
  },
  timelineVericalLine: {
    marginTop: "65px",
    position: "relative",
    backgroundColor: " #CCCCCC",
    width: "1px",
    height: "98.5%",
  },
  timelineIcon: {
    color: "#666666",
    borderRadius: "50%",
    fontSize: "25px",
    width: "40px",
    height: "40px",
    marginRight: "1rem",
  },
  topSection: {
    position: "relative",
    justifyContent: "left",
    padding: "0 20%",
  },
  timelineSection: {
    justifyContent: "right",
    paddingRight: "30px",
  },
  title: {
    paddingTop: "32px",
  },
  subContentTitle: {
    display: "flex",
  },
  subContentIcon: {
    fontSize: "24px",
    color: "#666666",
    paddingRight: "10px",
    transform: "translateY(34px)",
  },
  subContentItem: {
    paddingLeft: "40px",
  },
  divider: {
    paddingLeft: "25%",
    maxWidth: "85%",
    paddingTop: "32px",
  },
  desktopButton: {
    display: "flex",
    justifyContent: "right",
    margin: "32px 0",
  },
  mobileButton: {
    display: "flex",
    justifyContent: "right",
    margin: "16px 0",
  },
});

export const PaymentSummaryScreen = (props: any) => {
  useEffect(() => {document.title = "USCIS | Payment Summary";}, []);
  const { classes } = useStyles();
  const navigate = useNavigate();
  const theme = useTheme();
  const dispatch = useDispatch();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"), {
    defaultMatches: true,
  });
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);
  const { formType, formDescription } = useSelector(
    (root: RootState) => root.formMetadata.formMetadata,
  );
  const { addAlert } = useAlertSnackbar();

  const submitFinalSubmission = useCallback(
    async (myUscisId: string, submissionId: string, formType: string) => {
      try {
        await SubmissionService.submitFinalSubmission(myUscisId, submissionId, userGroupId);
        dispatch(setIsSubmissionSubmitted(true));
        navigate(`/pdf-intake/${formType}/success`);
      } catch (error) {
        addAlert(
          "Draft was not able to be submitted for processing. Please try again later",
        );

        navigate(`/pdf-intake/${formType}/${submissionId}`);
      }
    },
    [dispatch, navigate, addAlert],
  );

  const removePaymentAuthorization = useCallback(
    async (submissionId: string, formType: string) => {
      try {
        await PaymentService.removePaymentAuthorization(submissionId);
        // console.debug("Payment authorization removed");
        navigate(`/pdf-intake/${formType}/${submissionId}/submit`);
      } catch (error) {
        navigate(`/pdf-intake/${formType}/${submissionId}`);
      }
    },
    [navigate],
  );
  const params = useLoaderData() as {
    formType: string;
    status: string;
    submissionId: string;
  };

  if (params.status === "success" && !isProcessing) {
    setIsProcessing(true);
    submitFinalSubmission(myUscisId, params.submissionId, params.formType);
  }
  if (params.status === "cancel" && !isProcessing) {
    setIsProcessing(true);
    removePaymentAuthorization(params.submissionId, params.formType);
  }

  return (
    <Section>
      <Grid
        container
        columns={1}
        className={
          isMobile ? classes.mobileContainer : classes.desktopContainer
        }
      >
        <UploadingDialog
          loading
          setLoading={() => {}}
          currentStep={Steps.PayAndSubmit}
          showCancelButton={false}
          dialogHeader={
            <>
              <FontAwesomeIcon
                className={classes.timelineIcon}
                icon={
                  params.status === "success" ? faCircleCheck : faCircleXmark
                }
              />
              <Typography variant={"h4"}>
                Payment authorization{" "}
                {params.status === "success" ? "complete" : "canceled"}!
              </Typography>
            </>
          }
        />
        <Grid item container xs={12} className={classes.topSection}>
          <Typography variant="h1">
            {formType}, {formDescription}
          </Typography>
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
            }}
          ></div>
        </Grid>
      </Grid>
    </Section>
  );
};
