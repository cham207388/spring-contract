import { useContext, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { makeStyles } from "tss-react/mui";
import { PaymentService } from "../api/PaymentService";
import { SubmissionService } from "../api/SubmissionService";
import USCISDivider from "../components/shared/USCISDivider";
import { DocumentUploadContext } from "../contexts/DocumentUploadContext";
import { RootState } from "../redux/store";
import { setIsSubmissionSubmitted } from "../redux/submissionSlice";
import PayAndSubmitContent from "./submit/PayAndSubmitContent";
import SubmitContent from "./submit/SubmitContent";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";

const useStyles = makeStyles()((theme) => ({
  content: {
    margin: "0px 0px 0px 20px",
  },
  authSteps: {
    margin: "0.5rem 0",
  },
  blueBox: {
    width: "100%",
    position: "relative",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#e0f1ff",
    margin: "64px 0",
    padding: "32px",
    [theme.breakpoints.up("sm")]: {
      padding: "54px",
    },
  },
}));

export const PayAndSubmit = () => {
  useEffect(() => {document.title = "USCIS | Pay and Submit";}, []);
  const { classes } = useStyles();
  const dispatch = useDispatch();
  const { setLoading, setLoadingForPayment } = useContext(
    DocumentUploadContext,
  );

  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);
  const { submissionId, eligibilityCategory, feeTotal } =
    useSelector((state: RootState) => state.submission);
  const { formType, formDescription } = useSelector(
    (root: RootState) => root.formMetadata.formMetadata,
  );
  const { paygovMaintenanceEnabled } = useSelector(
    (root: RootState) => root.coreMetadata,
  );

  const navigate = useNavigate();
  const { addAlert } = useAlertSnackbar();
  const requirePaymentAuth = feeTotal! > 0;

  const checkFormValidations = async () => {
    await SubmissionService.checkValidationStatuses(myUscisId, submissionId)
    .then((response) => {
      console.log(response);
      if(response.length > 0) {
        window.location.replace(`/pdf-intake/${formType}/${submissionId}/review`);
      } 
      determineSubmit();    
    })
    .catch((error) => {
      addAlert(
        "Error occured retrieving form validations"
      );
      setIsSubmissionSubmitted(false);
      setLoading(false);
    });
  }

  const determineSubmit = () => {
    return !requirePaymentAuth ? handleSubmitForNoPayment() : handleSubmitForPaymentAuth();
  }

  const handleSubmitForPaymentAuth = async () => {
    try {
      const paymentStatusResponse = await PaymentService.getPaymentAuthorizationStatus(
        submissionId,
        feeTotal as number,
        formType,
      );
      if (paymentStatusResponse.status === "Authorized") {
        await PaymentService.removePaymentAuthorization(submissionId);
      }
      
        setLoading(true);
        setLoadingForPayment(true);
        const baseUrl = window.location.href.replace("/submit", "");
        const response = await PaymentService.getPaymentAuthorization(
          submissionId,
          feeTotal as number,
          formType,
          `${baseUrl}/payment/success`,
          `${baseUrl}/payment/cancel`,
        );
        window.location.replace(response.redirectUrl);
    } catch (error) {
      addAlert(
        "Payment authorization initiation failed. Please try again later",
      );
      setLoadingForPayment(false);
      setIsSubmissionSubmitted(false);
      setLoading(false);
    }
  };

  const handleSubmitForNoPayment = async () => {
    try {
      setLoading(true);
      await SubmissionService.submitFinalSubmission(myUscisId, submissionId, userGroupId);

      dispatch(setIsSubmissionSubmitted(true));
      navigate(`/pdf-intake/${formType}/success`);
    } catch (e) {
      setLoading(false);
      addAlert(
        "Draft was not able to be submitted for processing. Please try again later",
      );
      setIsSubmissionSubmitted(false);
    }
  };

  return (
    <div
      className={classes.content}
      style={{ marginTop: paygovMaintenanceEnabled ? "4rem" : "0" }}
    >
      {!requirePaymentAuth ? (
        <SubmitContent
          formType={formType}
          classes={classes}
          shouldShowWarning={eligibilityCategory === "C9"}
          handleSubmit={checkFormValidations}
        />
      ) : (
        <PayAndSubmitContent
          formType={formType}
          formDescription={formDescription}
          shouldShowWarning={eligibilityCategory === "C9"}
          classes={classes}
          handleSubmit={checkFormValidations}
          payGovMaintenanceEnabled={paygovMaintenanceEnabled}
        />
      )}
      {paygovMaintenanceEnabled && <USCISDivider />}
    </div>
  );
};
