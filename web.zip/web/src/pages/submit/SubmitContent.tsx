import { Button } from "myuscis-material";
import Logo from "../../components/shared/Logo/Logo";
import Section from "../../components/shared/Section";
import { C9Warning } from "../eligibility-information/C9Warning";

interface Props {
  formType: string;
  classes: Record<string, string>;
  handleSubmit: () => Promise<void>;
  shouldShowWarning?: boolean;
}
const SubmitContent = ({
  formType,
  classes,
  handleSubmit,
  shouldShowWarning = false,
}: Props) => {
  return (
    <>
      <h2>Submit your {formType} PDF</h2>
      {shouldShowWarning && <C9Warning />}
      <div className={classes.blueBox}>
        <Logo variant="round" />
        <Section>
          <p>
            Once you submit this application, you will receive confirmation. You
            can track the status of your application through your USCIS online
            account.
          </p>
        </Section>
        <Button
          variant="contained"
          onClick={handleSubmit}
          id="submitButton"
          sx={{
            width: "100%",
            maxWidth: "100%",
          }}
        >
          Submit the PDF upload of {formType}
        </Button>
      </div>
    </>
  );
};

export default SubmitContent;
