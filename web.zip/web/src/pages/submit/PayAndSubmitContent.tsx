import { Divider } from "@mui/material";
import { Button } from "myuscis-material";
import { useSelector } from "react-redux";
import AlertWindow from "../../components/shared/AlertWindow";
import Logo from "../../components/shared/Logo/Logo";
import Section from "../../components/shared/Section";
import { RootState } from "../../redux/store";
import { C9Warning } from "../eligibility-information/C9Warning";

interface Props {
  formType: string;
  formDescription: string;
  classes: Record<string, string>;
  handleSubmit: () => Promise<void>;
  payGovMaintenanceEnabled: boolean;
  shouldShowWarning?: boolean;
}

const PayAndSubmitContent = ({
  formType,
  formDescription,
  classes,
  handleSubmit,
  payGovMaintenanceEnabled,
  shouldShowWarning = false,
}: Props) => {
  const feeTotal =
    useSelector((root: RootState) => root.submission.feeTotal) ?? 0;
  if (payGovMaintenanceEnabled)
    return (
      <div>
        <AlertWindow
          variant={"error"}
          headerText="Pay.gov is temporarily unavailable because of maintenance"
        >
          You can return to pay for your application later. All of the choices
          and documents uploaded have been saved.
          <br />
          <br />
          To pay for your application later, save or bookmark this url address:{" "}
          <a href={window.location.href}>{formType} Application</a>
        </AlertWindow>
      </div>
    );
  return (
    <>
      <h2>Authorize Payment and submit your application</h2>
      <Section>
        <p>
          The final step to submit your Form {formType}, {formDescription}, is
          to authorize the payment for the required fee,
        </p>
        <p>
          Your application fee is: [<b>${feeTotal}</b>]
        </p>
        <p>
          Refund Policy: By continuing this transaction, you agree that you are
          authorizing payment for a government service and that the filing fee,
          biometric services fee, and all related financial transactions are
          final and not refundable, regardless of any action USCIS takes on an
          application, petition or request, or how long USCIS takes to issue a
          decision. You must authorize the payment of all fees in the exact
          amounts.
        </p>
      </Section>

      {shouldShowWarning && <C9Warning />}

      <div className={classes.blueBox}>
        <Logo variant="round" />
        <Section>
          <p>
            We will redirect you to Pay.gov - our safe, secure payment website —
            to authorize the payment of your fees and submit your application
            online.
          </p>
          <Divider />
          <p>
            Here are the steps in the payment authorization and submission
            process:
            <ol>
              <li className={classes.authSteps}>
                Provide your billing information on Pay.gov
              </li>
              <li className={classes.authSteps}>
                Provide your credit card of U.S. bank account information
              </li>
              <li className={classes.authSteps}>Submit your payment</li>
            </ol>
          </p>
          <Divider />
          <p>
            When you have authorized the payment of your fee, your application
            will be submitted.
          </p>
          <p>
            Pay.gov will redirect you to your submission confirmation screen.
            You can track the status of your of your application through your
            USCIS online account.
          </p>
          <p> If your application is rejected you will not be charged. </p>
        </Section>
        <Button
          variant="contained"
          onClick={handleSubmit}
          id="submitButton"
          sx={{
            width: "100%",
            maxWidth: "100%",
          }}
        >
          Pay and submit
        </Button>
      </div>
    </>
  );
};

export default PayAndSubmitContent;
