import { faPrint } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Box, Button, Grid } from "myuscis-material";
import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useReactToPrint } from "react-to-print";
import { makeStyles } from "tss-react/mui";
import FileViewerDialog from "../components/Dialogs/FileViewerDialog";
import NavigationButtons from "../components/NavigationButtons";
import Section from "../components/shared/Section";
import USCISDivider from "../components/shared/USCISDivider";
import { RootState } from "../redux/store";
import { setReviewed } from "../redux/submissionSlice";
import { formatFileName } from "../utils/formatFileName";

const useStyles = makeStyles()({
  iconLink: {
    display: "flex",
    gap: "8px",
    alignItems: "center",
    margin: "0 !important",
  },
  printContainer: {
    margin: "16px",
  },
  buttonAsLink: {
    background: "none!important",
    border: "none",
    padding: "0!important",
  },
  sectionHeader: {
    "& h2, & h3, & h4": {
      padding: "15px",
      margin: 0,
      fontWeight: "normal",
    },
    "& h2": {
      background: "#EBEBEB",
      fontSize: "21px",
    },
    "& h3": {
      fontSize: "16px",
      background: "#F9F9F9",
    },
  },
  row: {
    position: "relative",
    marginLeft: "6%",
    marginBottom: "16px",
    "& .MuiGrid-item": {
      marginTop: "8px",
      fontSize: "16px",
      borderTop: "1px solid #EBEBEB",
    },
  },
});

export const ApplicationSummary = () => {
  useEffect(() => {document.title = "USCIS | Application Summary";}, []);
  const { classes } = useStyles();
  const dispatch = useDispatch();
  const submission = useSelector((state: RootState) => state.submission);
  const { evidenceGroups } = useSelector((state: RootState) => state.evidence);
  const componentRef = useRef<HTMLDivElement>(null);
  const [showFileViewer, setShowFileViewer] = useState(false);
  const [fileViewerUri, setFileViewerUri] = useState("");
  dispatch(setReviewed(true));
  const myUscisId = useSelector((state: RootState) => state.user.myUscisId);

  const { formMetadata } = useSelector(
    (state: RootState) => state.formMetadata,
  );

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  const onNext = (next: () => void) => {
    dispatch(setReviewed(true));
    next();
  };

  const prettyPrintEvidenceType = (type: string | undefined) => {
    // Split on "-" unless preceded by an "i"
    const test = /(?<!i)-(?=(?:-)*(?!-))/g;
    return type ? type.split(test).join(" ") : "";
  };

  const handleViewFormClick = (formId: string) => {
    setFileViewerUri(
      `/pdf-intake/api/intake/${myUscisId}/submissions/${submission.submissionId}/form/${formId}`,
    );
    setShowFileViewer(true);
  };

  const handleViewEvidenceClick = (fileName: string, evidenceId: string) => {
    setFileViewerUri(
      `/pdf-intake/api/intake/${myUscisId}/submissions/${submission.submissionId}/evidences/${evidenceId}/${fileName}`,
    );
    setShowFileViewer(true);
  };

  return (
    <>
      <div ref={componentRef} className={classes.printContainer}>
        <Section>
          <h3>Review the {submission.formType} form information</h3>
          <p>
            Here is a summary of all the information you provided in your
            application or petition.
          </p>
          <p>
            Make sure you have provided responses for everything that applies to
            you before you submit your application or petition. You can edit your responses
            by going to each section using the site navigation.
          </p>
          <Box sx={{ display: "flex", gap: "16px" }}>
            <Button
              onClick={handlePrint}
              variant="text"
              className={classes.iconLink}
            >
              <FontAwesomeIcon icon={faPrint} />
              Print
            </Button>
          </Box>
        </Section>
        <Grid container>
          <Grid item xs={12} className={classes.sectionHeader}>
            <h2>Getting Started</h2>
            <h3>Basis of eligibility</h3>
            <Grid container item spacing={6} padding={2}>
              <Grid item xs={7}>
                What is your eligibility category?
              </Grid>
              <Grid item xs={5}>
                {submission.eligibilityCategory}
              </Grid>
            </Grid>
            {formMetadata.feeWaiverEnabled && (
              <>
                <h3>Fee Waiver</h3>
                <Grid container item spacing={6} padding={2}>
                  <Grid item xs={7}>
                    Are you applying for a fee waiver
                  </Grid>
                  <Grid item xs={5}>
                    {submission.feeWaiver.requested ? "Yes" : "No"}
                  </Grid>
                </Grid>
              </>
            )}
            {submission.feeWaiver.requested &&
              submission.feeWaiver.files.map((feeWaiverFile) => (
                <>
                  <h3>Form {feeWaiverFile.documentType}</h3>
                  <Grid
                    container
                    item
                    spacing={3}
                    padding={2}
                    className={classes.row}
                  >
                    <Grid item xs={6}>
                      File Name
                    </Grid>
                    <Grid item xs={5}>
                      <Button
                        className={classes.buttonAsLink}
                        onClick={() =>
                          handleViewEvidenceClick(
                            feeWaiverFile.fileName,
                            feeWaiverFile.id,
                          )
                        }
                        variant={"text"}
                      >
                        {formatFileName(feeWaiverFile.fileName)}
                      </Button>
                    </Grid>
                    <Grid item xs={6}>
                      Document Type
                    </Grid>
                    <Grid item xs={5}>
                      {feeWaiverFile.documentType}
                    </Grid>
                  </Grid>
                </>
              ))}
            <h2>PDF</h2>
            {submission.forms.map((form) => (
              <>
                <h3>Form {form.formType}</h3>
                <Grid
                  container
                  item
                  spacing={3}
                  padding={2}
                  className={classes.row}
                >
                  <Grid item xs={6}>
                    File Name
                  </Grid>
                  <Grid item xs={5}>
                    <Button
                      className={classes.buttonAsLink}
                      onClick={() => handleViewFormClick(form!.formId)}
                      variant={"text"}
                    >
                      {formatFileName(form!.fileName)}
                    </Button>
                  </Grid>
                  <Grid item xs={6}>
                    Document Type
                  </Grid>
                  <Grid item xs={5}>
                    {form.formType}
                  </Grid>
                </Grid>
              </>
            ))}
            <h2>Evidence</h2>
            {submission.evidences.map((evidence) => (
              <>
                <h3>
                  {evidenceGroups.find((e) => e.id === evidence.evidenceGroup)
                    ?.name || ""}
                </h3>
                {evidence.files.map((evidenceItem) => (
                  <>
                    <Grid
                      container
                      item
                      spacing={3}
                      padding={2}
                      className={classes.row}
                    >
                      <Grid item xs={6}>
                        File Name
                      </Grid>
                      <Grid item xs={5}>
                        <Button
                          className={classes.buttonAsLink}
                          onClick={() =>
                            handleViewEvidenceClick(
                              evidenceItem.fileName,
                              evidenceItem.id,
                            )
                          }
                          variant={"text"}
                        >
                          {formatFileName(evidenceItem.fileName)}
                        </Button>
                      </Grid>
                      <Grid item xs={6}>
                        Document Type
                      </Grid>
                      <Grid item xs={5} sx={{ textTransform: "capitalize" }}>
                        {prettyPrintEvidenceType(evidenceItem.type)}
                      </Grid>
                    </Grid>
                  </>
                ))}
              </>
            ))}
          </Grid>
        </Grid>
      </div>
      <USCISDivider />
      <NavigationButtons onNext={onNext} />
      <FileViewerDialog
        isOpen={showFileViewer}
        setIsOpen={setShowFileViewer}
        uri={fileViewerUri}
      />
    </>
  );
};
