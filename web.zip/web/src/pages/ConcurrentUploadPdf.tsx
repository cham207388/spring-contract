import { useSelector } from "react-redux";
import FormDropzone from "../components/FormDropzone";
import NavigationButtons from "../components/NavigationButtons";
import { FileRequirementsNoAdditionalEvidence, PrimaryFormFileRequirements } from "../components/shared/FileRequirements";
import Section from "../components/shared/Section";
import USCISDivider from "../components/shared/USCISDivider";
import { RootState } from "../redux/store";
import { FormMetaDataState } from "../redux/formMetadataSlice";
import { FormTypes } from "../constants/AcceptedFormTypes";
import Box from "@mui/material/Box/Box";

const ConcurrentUploadPdf = () => {
  const { selectedConcurrentForms } = useSelector((state: RootState) => state.submission);
  const { concurrentFormMetadata } = useSelector((state: FormMetaDataState) => state);

  const additionalEvidences = ["additional-evidence", "additional-evidence-i129", "additional-evidence-i129tn-e-r"];

  const hasAdditionalEvidence = (form: FormTypes) => {
    const metadata = concurrentFormMetadata?.find(el => el.formType === form);
    return metadata?.eligibilityCategories.some(category =>
      category.metaData.evidenceGroups.some(evidence => additionalEvidences.includes(evidence.id))
    );
  };

  const getFileRequirements = () => {
    const formType = selectedConcurrentForms.filter(formType => hasAdditionalEvidence(formType)).pop()

    const acceptedTypes = {
      "application/pdf": [".pdf"],
    };
    return formType ? <PrimaryFormFileRequirements
      maxFiles={1}
      accept={acceptedTypes}
      formType={formType} />
      : <FileRequirementsNoAdditionalEvidence
        maxFiles={1}
        accept={acceptedTypes} />;
  }

  return (
    <>
      <Section>
        <Box>
          <h2>Concurrent PDF Form Upload(s)</h2>
        </Box>
        <p>
          Upload all pages of the Form(s)&nbsp;
          {selectedConcurrentForms.map((form) => (
            <a key={form}
              href={`https://www.uscis.gov/${form}`}
              target="_blank"
              rel="noreferrer"
              style={{ marginRight: 10}}
            >
            {form}
            </a>
          ))}
          in PDF file format only. Place all pages in the correct order by
          referring to the page numbers on the form. For forms that have been
          scanned into PDF format, include all pages when uploading, even pages
          where you were not required to provide information.
        </p>

        <>
          <p>You must:</p>
          <ul>
            <li>Upload one PDF file per form;</li>
            <li>Include <strong>all</strong> pages of the form(s) in the file(s), even if you did not provide any information on the page; and</li>
            <li>Arrange the form(s) in the same order as its page numbers.</li>
          </ul>
          <p><strong>Do not</strong> include any evidence in the file(s). You will add your evidence later in the process.</p>
        </>
        {getFileRequirements()}

      </Section>

      {selectedConcurrentForms.map((form) => (
        <div key={form}>
          <h2>{`${form} upload`} </h2>
          <FormDropzone formType={form} />
        </div>
      ))}


      <USCISDivider />

      <NavigationButtons />
    </>
  );
};

export default ConcurrentUploadPdf;
