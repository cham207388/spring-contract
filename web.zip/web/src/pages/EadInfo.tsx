import AlertWindow from "../components/shared/AlertWindow";

export const EadInfo = ({ formType }: { formType: string }) => {
  return (
    <AlertWindow variant="information">
      {formType} form submissions requesting an EAD are currently not being
      accepted via PDF Intake. Please follow the paper filing guidelines if you
      are requesting an EAD.
    </AlertWindow>
  );
};
