import { library } from "@fortawesome/fontawesome-svg-core";
import {
  faFloppyDisk,
  faLock,
  faMobileScreen,
  faRectangleList,
  faSitemap,
  faSquareCheck,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Grid, Typography } from "myuscis-material";
import { makeStyles } from "tss-react/mui";
import MarkdownWithLinks from "../../components/shared/MarkdownWithLinks";
import Section from "../../components/shared/Section";
import USCISDivider from "../../components/shared/USCISDivider";
import NavigationButtons from "../../components/NavigationButtons";
import { CompleteYourFormSection } from "../../types/FormMetaData";
import { useEffect } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";

type Props = {
  handlePrevious?: () => void;
  handleNext?: () => void;
  formCopy: CompleteYourFormSection;
  customNextLabel?: string;
  currentPageFormType: String;
  disableButtons: boolean;
};

const useStyles = makeStyles()((theme) => ({
  container: {
    backgroundColor: "#ffffff",
    margin: "32px auto 64px auto",
    paddingInline: "2rem",
    [theme.breakpoints.up("md")]: {
      maxWidth: "1028px",
      maxHeight: "auto",
      display: "flex",
      displayDirection: "column",
      paddingInline: 0,
    },
  },
  divider: {
    paddingLeft: "25%",
    maxWidth: "85%",
    paddingTop: "56px",
  },
  timelineVerticalLine: {
    marginTop: "65px",
    position: "relative",
    backgroundColor: " #CCCCCC",
    width: "1px",
    height: "98.5%",
  },
  timelineRoundIcon: {
    transform: "translate(-50%, -85%)",
    position: "absolute",
    backgroundColor: "#666666",
    borderRadius: "50%",
    display: "flex",
    width: "40px",
    height: "40px",
  },
  timelineIcon: {
    transform: "translate(60%, 30%)",
    position: "absolute",
    color: "white",
    borderRadius: "50%",
    fontSize: "24px",
    display: "flex",
  },
  timelineSection: {
    justifyContent: "right",
    paddingRight: "30px",
  },
  title: {
    paddingTop: "32px",
    paddingBottom: "16px"
  },
  subContent: {
    paddingLeft: "40px",
  },
  subContentTitle: {
    display: "flex",
  },
  subContentIcon: {
    fontSize: "24px",
    color: "#666666",
    paddingRight: "10px",
    transform: "translateY(16px)",
  },
}));

const layoutColumns: Record<string, number> = {
  timeline: 3,
  content: 9,
  row: 9,
};

export const CompleteYourForm = ({
  handleNext,
  handlePrevious,
  customNextLabel,
  formCopy,
  currentPageFormType,
  disableButtons
}: Props) => {
  useEffect(() => {
    document.title = `USCIS | Complete Your Form (${currentPageFormType})`;
  }, [currentPageFormType]);
  const { classes } = useStyles();

  library.add(
    faFloppyDisk,
    faLock,
    faMobileScreen,
    faRectangleList,
    faSitemap,
    faSquareCheck,
  );

  return (
    <Section>
      <Grid container columns={1} className={classes.container}>
        <Grid
          item
          container
          xs={layoutColumns.timeline}
          className={classes.timelineSection}
        >
          <Grid item className={classes.timelineVerticalLine}>
            <Grid item className={classes.timelineRoundIcon}>
              <FontAwesomeIcon
                icon={faMobileScreen}
                className={classes.timelineIcon}
              />
            </Grid>
          </Grid>
        </Grid>
        <Grid item container xs={layoutColumns.content}>
          <Typography variant="h2" className={classes.title}>
            {formCopy.title}
          </Typography>
          {formCopy.categories?.map((category) => (
            <div key={category.title}>
              <Grid
                item
                xs={layoutColumns.row}
                className={classes.subContentTitle}
              >
                {category.icon && (
                  <FontAwesomeIcon
                    icon={category.icon}
                    className={classes.subContentIcon}
                  />
                )}
                <Typography variant="h3">{category.title}</Typography>
              </Grid>
              <Grid item xs={layoutColumns.row} className={classes.subContent}>
                <MarkdownWithLinks>{category.body}</MarkdownWithLinks>
              </Grid>
            </div>
          ))}

          <Grid item xs={layoutColumns.row}>
            <USCISDivider />
          </Grid>

          {formCopy.notices.map((notice) => (
            <>
              <Grid
                item
                xs={layoutColumns.row}
                className={classes.subContent}
                key={notice.title}
              >
                <Typography variant="h3">{notice.title}</Typography>
                <MarkdownWithLinks>{notice.body}</MarkdownWithLinks>
              </Grid>
            </>
          ))}

          <SecurityReminder row={layoutColumns.row} />
        </Grid>

        <Grid item container xs={12}>
          <Grid item xs={12} className={classes.divider}>
            <NavigationButtons
              customNext={handleNext}
              nextLabel={customNextLabel}
              customPrevious={handlePrevious}
              disablePrevious={disableButtons}
              disableNext={disableButtons}
            />
          </Grid>
        </Grid>
      </Grid>
    </Section>
  );
};

const SecurityReminder = ({ row }: { row: number }) => {
  const { classes } = useSecurityStyles();
  return (
    <Grid item container xs={row} className={classes.securityBox}>
      <FontAwesomeIcon icon={faLock} className={classes.lockIcon} />
      <Typography variant="h2" className={classes.securityContent}>
        Security Reminder
      </Typography>
      <Grid item className={classes.securityContent}>
        <p>
          If you do not work on your application for more than 30 days, we will
          delete your data in order to prevent storing personal information
          indefinitely.
        </p>
      </Grid>
    </Grid>
  );
};

const useSecurityStyles = makeStyles()({
  securityBox: {
    marginTop: "32px",
    display: "flex",
    backgroundColor: "#003366",
    padding: "32px 32px",
    "& h2": {
       color: "#ffffff"
    }
  },
  securityContent: {
    color: "#ffffff",
    paddingLeft: "50px",
    marginBottom: "15px"
  },
  lockIcon: {
    position: "absolute",
    fontSize: "28px",
    color: "#ffffff",
    textAlign: "left",
    transform: "translateY(-5%)",
  },
});
