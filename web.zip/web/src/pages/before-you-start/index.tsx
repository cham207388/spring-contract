import {
  useLoaderData,
  useNavigate,
  useSearchParams,
} from "react-router-dom";
import { useDispatch } from "react-redux";
import { BeforeYouStart } from "./BeforeYouStart";
import { CompleteYourForm } from "./CompleteYourForm";

import { Box } from "myuscis-material";
import { useSelector } from "react-redux";
import { AppDispatch, RootState } from "../../redux/store";
import { useState } from "react";
import { createSubmissionAndFetchEvidence } from "../../redux/thunks/createSubmissionAndFetchEvidence";
import { FormMetaData, FormTypes } from "../../types/FormMetaData";
import { Paths } from "../../router/Paths";
import { selectIsRepresentative } from "../../redux/userSlice";
import AlertWindow from "../../components/shared/AlertWindow";
import { resetLoader, showLoader } from "../../redux/loaderSlice";
import { useAlertSnackbar } from "../../hooks/useAlertSnackbar";
import ConcurrentFiling from "../ConcurrentFiling";

interface LoaderData {
  canUserFile: boolean;
  g28Metadata: FormMetaData;
  primaryFormMetadata: FormMetaData;
  concurrentFormMetadata: FormMetaData[];
  concurrentFormTypes: string[];
  showConcurrentFiling: boolean;
}

const BeforeYouStartStepperContainer = () => {
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const { addAlert } = useAlertSnackbar();

  const isRepresentative = useSelector((state: RootState) =>
    selectIsRepresentative(state),
  );
  const { canUserFile, primaryFormMetadata, g28Metadata, concurrentFormMetadata, concurrentFormTypes, showConcurrentFiling } =
    useLoaderData() as LoaderData;
  const { isLoading } = useSelector( ( state: RootState) => state.loader );


  const [currentStep, setCurrentStep] = useState<number>(0);
  const [concurrentStep, setConcurrentStep] = useState<number>(0);
  const [concurrentFormIndex, setConcurrentFormIndex] = useState<number>(0);
  const [searchParams] = useSearchParams();
  const [benefitTypeCode, setBenefitTypeCode] = useState<String | null>(null);
  const [appReasonCode, setAppReasonCode] = useState<String | null>(null);
  const [immigrationClassCode, setImmigrationClassCode] = useState<String | null>(null);
  const [concurrentStepsSet, setConcurrentStepsSet] = useState<boolean>(false);
  const { selectedConcurrentForms} = useSelector((state: RootState) => state.submission);

  const handleNextStep = async () => {
    setBenefitTypeCode(searchParams.get("benefitTypeCode"));
    setAppReasonCode(searchParams.get("applicationReasonCode"));
    setImmigrationClassCode(searchParams.get("immigrationClassCode"));
    window.scrollTo(0, 0);
    if (currentStep < beforeYouStartSteps.length - 1 && !concurrentStepsSet) {
      setCurrentStep(currentStep + 1);
    } 
    else if(currentStep === beforeYouStartSteps.length - 1 && selectedConcurrentForms.length 
        && !(concurrentFormIndex >= selectedConcurrentForms.length - 1 && concurrentStep >= 2)) {
      setConcurrentStepsSet(true);
      if(concurrentStep < 2) {
        setConcurrentStep(concurrentStep + 1);
      } else {
        setConcurrentStep(1);
        setConcurrentFormIndex(concurrentFormIndex + 1);
      }
    } 
    else {
      dispatch(
        showLoader({
          title: "Starting Draft",
          message:
            "Your Draft submission is starting. Please wait and do not refresh the page.",
        }),
      );
      try {
        const {
          submission: { submissionId },
        } = await dispatch(createSubmissionAndFetchEvidence()).unwrap();
        primaryFormMetadata.formType === FormTypes.I907 ? navigate(`${submissionId}/${Paths.form}`) :
        navigate(`${submissionId}/${Paths.selectEligibility}`, {
          state: {
            appReasonCode: appReasonCode,
            benefitTypeCode: benefitTypeCode,
            immigrationClassCode: immigrationClassCode
          },
        });
        //dispatch(resetLoader());
      } catch (error) {
        dispatch(resetLoader());
        addAlert("Unable to create draft. Please try again later.");
      }
    }
  };
  const handlePreviousStep = () => {
    window.scrollTo(0, 0);
    if (currentStep > 0 && !concurrentStepsSet) {
      setCurrentStep(currentStep - 1);
    } else {
      if(concurrentStep > 1) {
        setConcurrentStep(concurrentStep - 1);
      } else {
        if(concurrentFormIndex > 0) {
          setConcurrentFormIndex(concurrentFormIndex - 1);
          setConcurrentStep(2);
        } else {
          setConcurrentStepsSet(false);
          setConcurrentStep(0);
          setCurrentStep(beforeYouStartSteps.length - 1);
        }
      }
    }
  };

  const primaryFormSteps: JSX.Element[] = [
    <BeforeYouStart
      key="PrimaryForm_BeforeYouStart"
      formCopy={primaryFormMetadata.pages.beforeYouStart}
      handleNext={handleNextStep}
      primaryFormType={primaryFormMetadata.formType}
      currentPageFormType={primaryFormMetadata.formType}
    />,
    <CompleteYourForm
      disableButtons={isLoading}
      key="PrimaryForm_CompleteYourForm"
      formCopy={primaryFormMetadata.pages.completeYourForm}
      handleNext={handleNextStep}
      handlePrevious={handlePreviousStep}
      customNextLabel={isRepresentative ? undefined : "Start"}
      currentPageFormType={primaryFormMetadata.formType}
    />,
  ];

  const g28FormSteps: JSX.Element[] = [
    <BeforeYouStart
      key="G28_BeforeYouStart"
      formCopy={g28Metadata.pages.beforeYouStart}
      handleNext={handleNextStep}
      handlePrevious={handlePreviousStep}
      primaryFormType={primaryFormMetadata.formType}
      currentPageFormType={g28Metadata.formType}
    />,
    <CompleteYourForm
      disableButtons={isLoading}
      key="G28_BeforeYouStart"
      formCopy={g28Metadata.pages.completeYourForm}
      handleNext={handleNextStep}
      handlePrevious={handlePreviousStep}
      customNextLabel="Start"
      currentPageFormType={g28Metadata.formType}
    />,
  ];

  const concurrentFilingStep: JSX.Element[] = [
    <ConcurrentFiling
      key="concurrentFiling"
      handlePrevious={handlePreviousStep}
      handleNext={handleNextStep}
      formType={primaryFormMetadata.formType}
      concurrentForms={concurrentFormTypes}
    />
  ];

  const concurrentBeforeYouStartSteps: JSX.Element[][] = 
    concurrentFormMetadata.map(metadata => {
      return ([
        <BeforeYouStart
          key={`${metadata.formType}`}
          formCopy={metadata.pages.beforeYouStart}
          handleNext={handleNextStep}
          handlePrevious={handlePreviousStep}
          primaryFormType={primaryFormMetadata.formType} 
          currentPageFormType={metadata.formType}       
        />,
        <CompleteYourForm
          key={`Concurrent_CompleteYourForm_${metadata.formType}`}
          formCopy={metadata.pages.completeYourForm}
          handleNext={handleNextStep}
          handlePrevious={handlePreviousStep}
          customNextLabel="Start" 
          currentPageFormType={metadata.formType}
          disableButtons={false}        
        />,
    ])
  })
  
  let beforeYouStartSteps: JSX.Element[] = [
    ...(concurrentFormTypes.length > 0 && showConcurrentFiling ? concurrentFilingStep : []),
    ...primaryFormSteps,
    ...(isRepresentative ? g28FormSteps : []),
  ];
  const headerText=`An ${primaryFormMetadata.formType} already exists in this account`

  if (!canUserFile) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          minHeight: "26rem",
          alignItems: "center",
        }}
      >
        <AlertWindow
          variant="information"
          headerText={headerText}
        >
          You already submitted Form {primaryFormMetadata.formType} or started a draft. You cannot file a
          new one.
        </AlertWindow>
      </Box>
    );
  }
  if (beforeYouStartSteps.length < 1) {
    return <div>Something went wrong</div>;
  }
  if (currentStep < 0 || currentStep >= beforeYouStartSteps.length) {
    setCurrentStep(0);
  }
  return !concurrentStepsSet 
    ? beforeYouStartSteps[currentStep] 
    : concurrentBeforeYouStartSteps.find((steps) => steps[0].key!.includes(selectedConcurrentForms[concurrentFormIndex]))![concurrentStep - 1];
};

export default BeforeYouStartStepperContainer;


