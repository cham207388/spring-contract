import { useEffect, useState } from "react";
import {
  faCalendarCheck,
  faCircleArrowRight,
  faCircleCheck,
  faComments,
  faCompass,
  faEnvelope,
  faEnvelopesBulk,
  faFileAlt,
  faFingerprint,
  faFlag,
  faHandPointer,
  faIdCard,
  faLanguage,
  faListAlt,
  faMoneyBill1,
  faPenToSquare,
  faReplyAll,
  faSpinner,
  faUndo,
  faUserPlus,
  faUser,
  faUsers,
  faWheelchair,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Accordion, Grid, Typography } from "myuscis-material";
import { makeStyles } from "tss-react/mui";
import { useSelector } from "react-redux";

import Section, { sectionStyles } from "../../components/shared/Section";
import { library } from "@fortawesome/fontawesome-svg-core";
import MarkdownWithLinks from "../../components/shared/MarkdownWithLinks";
import NavigationButtons from "../../components/NavigationButtons";
import { ContentSection, FormTypes } from "../../types/FormMetaData";
import LowerEnvTestControls from "./LowerEnvTestControls";
import { RootState } from "../../redux/store";
import { AccountTypes } from "../../redux/userSlice";
import { I539OnlineFilingAlert } from "../eligibility-information/I539OnlineFilingAlert";

const useStyles = makeStyles()((theme) => ({
  markdown: {
    ...sectionStyles,
    marginBottom: "0px",
    "& p": {
      marginTop: "0px",
      marginBottom: "16px",
    },
    "& ol": {
      fontSize: "1rem",
      paddingInline: "1rem",
    },
    "& ol ol": {
      listStyleType: "upper-alpha",
      paddingInlineStart: "1.5rem",
      margin: 0,
    },
    "& h4": {
      fontSize: "20px",
    },
    "& h5": {
      fontSize: "18px",
      marginTop: "0 !important",
      marginBottom: "16px !important"
    },
  },
  accordion: {
    boxShadow: "none",
    borderTop: "1px solid #EBEBEB",
    borderRadius: "0 !important",
    fontSize: "16px",
    lineHeight: "1.15",
    fontWeight:"bold"
  },
  activeAccordionItem: {
    borderLeft: "4px solid rgb(0, 84, 153)",
    backgroundColor: "#EBEBEB",
    fontSize: "16px",
    lineHeight: "1.15",
    fontWeight:"bold"
  },
  accordionBody: {
    padding: "16px",
    "& p": {
      fontWeight: "normal"
    }
  },
  container: {
    backgroundColor: "#ffffff",
    margin: "32px auto 64px auto",
    paddingInline: "2rem",
    [theme.breakpoints.up("md")]: {
      maxWidth: "1028px",
      maxHeight: "auto",
      display: "flex",
      displayDirection: "column",
      paddingInline: 0,
      "& .MuiGrid-grid-xs-10": {
        marginLeft: "-3rem",
      },
    },
    "& h5": {
      fontSize: "18px",
      marginTop: "16px !important",
    },
  },
  divider: {
    paddingLeft: "25%",
    maxWidth: "85%",
    paddingTop: "56px",
  },
  title: {
    paddingTop: "32px",
    paddingBottom: "16px"
  },
  subContentItem: {
    paddingLeft: "40px",
  },
  subContentTitle: {
    display: "flex",
  },
  subContentIcon: {
    fontSize: "24px",
    color: "#666666",
    paddingRight: "10px",
    transform: "translateY(16px)",
  },
  timelineVerticalLine: {
    marginTop: "65px",
    position: "relative",
    backgroundColor: " #CCCCCC",
    width: "1px",
    height: "98.5%",
  },
  timelineSection: {
    justifyContent: "right",
    paddingRight: "35px",
  },
  timelineIcon: {
    transform: "translate(-50%, -85%)",
    position: "absolute",
    color: "#666666",
    borderRadius: "50%",
    fontSize: "25px",
    display: "flex",
    width: "40px",
    height: "40px",
  },
  topSection: {
    position: "relative",
    justifyContent: "left",
    padding: "0 17%",
    display: "block"
  },
}));

const layoutColumns: Record<string, number> = {
  timeline: 2.75,
  content: 9.25,
  row: 9,
};

type Props = {
  handlePrevious?: () => void;
  handleNext?: () => void;
  formCopy: ContentSection;
  primaryFormType: String;
  currentPageFormType: String;
};

export const BeforeYouStart = ({
  handlePrevious,
  handleNext,
  formCopy,
  primaryFormType,
  currentPageFormType
}: Props) => {
  useEffect(() => {
    document.title = `USCIS | Before You Start (${currentPageFormType})`;
  }, [currentPageFormType]);
  const { classes } = useStyles();
  interface Accordion {
    [key: string]: boolean;
  }

  const keys = formCopy.beforeYouStartCategories[0].accordionCategories
    ?.map((item: { id: any }) => item.id)
    .reduce((acc: any, id: any) => ({ ...acc, [id]: false }), {});

  const [isActive, setIsActive] = useState<Accordion>(keys as Accordion);
  const {accountType, isUserPartOfOrg } = useSelector((state: RootState) => state.user);
  library.add(
    faIdCard,
    faMoneyBill1,
    faFileAlt,
    faFingerprint,
    faCompass,
    faReplyAll,
    faHandPointer,
    faCalendarCheck,
    faComments,
    faFlag,
    faEnvelope,
    faEnvelopesBulk,
    faLanguage,
    faListAlt,
    faPenToSquare,
    faSpinner,
    faUndo,
    faUserPlus,
    faUser,
    faUsers,
    faWheelchair,
  );

  const handleAccordionClick = (section: string) => {
    setIsActive((prevState) => ({
      ...prevState,
      [section]: !prevState[section],
    }));
  };

  return (
    <Section>
      <LowerEnvTestControls />
      <Grid container columns={1} className={classes.container}>
        <Grid item container className={classes.topSection}>
          <Typography variant="h1">{formCopy.title}</Typography>
          <MarkdownWithLinks>{formCopy.description}</MarkdownWithLinks>
          {currentPageFormType === FormTypes.I539 && <I539OnlineFilingAlert />}
        </Grid>
        <Grid
          item
          container
          xs={layoutColumns.timeline}
          className={classes.timelineSection}
        >
          <Grid item className={classes.timelineVerticalLine}>
            <FontAwesomeIcon
              className={classes.timelineIcon}
              icon={faCircleCheck}
            />
          </Grid>
        </Grid>
        <Grid item container xs={layoutColumns.content}>
          <Typography variant="h2" className={classes.title}>
            Before You Start Your Application Or Petition
          </Typography>
          {formCopy.beforeYouStartCategories.map((category) => (
            <div key={category.title}>
              <Grid
                item
                xs={layoutColumns.row}
                className={classes.subContentTitle}
              >
                {category.icon && (
                  <FontAwesomeIcon
                    icon={category.icon}
                    className={classes.subContentIcon}
                  />
                )}
                {category.title && (
                  <Typography variant="h3">{category.title}</Typography>
                )}
              </Grid>
              <Grid
                item
                xs={layoutColumns.row}
                className={classes.subContentItem}
              >
                <MarkdownWithLinks className={classes.markdown}>
                  {accountType === AccountTypes.REGISTRANT  || isUserPartOfOrg && accountType === AccountTypes.REPRESENTATIVE?
                  category.body.concat(category.orgSpecificText?? "") : category.body}
                </MarkdownWithLinks>
                {category.accordionCategories?.map((accordion) => (
                  <Accordion
                    key={accordion.title}
                    accordionTitle={accordion.title}
                    className={
                      isActive[accordion.id]
                        ? classes.activeAccordionItem
                        : classes.accordion
                    }
                    toggleExpansion={() => handleAccordionClick(accordion.id)}
                  >
                    <MarkdownWithLinks className={classes.accordionBody}>
                      {accordion.body}
                    </MarkdownWithLinks>
                  </Accordion>
                ))}
               {primaryFormType === FormTypes.I907 && category.title === "Eligibility" &&
                  <img src="/pdf-intake/premiumProcessingForms.png" alt="" height={412} width={614} style={{display: "flex"}}/>}
              </Grid>
            </div>
          ))}
        </Grid>
        <Grid
          item
          container
          xs={layoutColumns.timeline}
          className={classes.timelineSection}
        >
          <Grid item className={classes.timelineVerticalLine}>
            <FontAwesomeIcon
              className={classes.timelineIcon}
              icon={faCircleArrowRight}
            />
          </Grid>
        </Grid>
        <Grid item container xs={layoutColumns.content}>
          <Typography variant="h2" className={classes.title}>
            {`After You Submit Your ${primaryFormType === FormTypes.I485A || primaryFormType === FormTypes.I485J ? 'Supplement' : 'Application, Petition, or Request'}`}
          </Typography>
          {formCopy.afterYouFileCategories.map((category) => (
            <div key={category.title}>
              <Grid
                item
                xs={layoutColumns.row}
                className={classes.subContentTitle}
              >
                {category.icon && (
                  <FontAwesomeIcon
                    icon={category.icon}
                    className={classes.subContentIcon}
                  />
                )}
                <Typography variant="h3">{category.title}</Typography>
              </Grid>
              <Grid
                item
                xs={layoutColumns.row}
                className={classes.subContentItem}
              >
                <MarkdownWithLinks>{category.body}</MarkdownWithLinks>
              </Grid>
            </div>
          ))}
        </Grid>
        <Grid item container xs={12}>
          <Grid item xs={12} className={classes.divider}>
            <NavigationButtons
              showBackButton={typeof handlePrevious !== "undefined"}
              customPrevious={handlePrevious}
              customNext={handleNext}
            />
          </Grid>
        </Grid>
      </Grid>
    </Section>
  );
};
