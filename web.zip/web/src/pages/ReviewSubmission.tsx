import Divider from "@mui/material/Divider";
import { AlertActions, Button, Typography } from "myuscis-material";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { makeStyles } from "tss-react/mui";
import NavigationButtons from "../components/NavigationButtons";
import AlertWindow from "../components/shared/AlertWindow";
import USCISDivider from "../components/shared/USCISDivider";
import { useClientInformation } from "../hooks/useClientInformation";
import { useSubmissionIsComplete } from "../hooks/useSubmissionIsComplete";
import { RootState } from "../redux/store";
import { Paths } from "../router/Paths";
import {
  ErrorGroup,
  SubmissionStatusResponse,
} from "../types/SubmissionStatusResponse";
import {
  eligibilityErrorExists,
  formErrorIsEligibilitySelectPageRelated,
} from "../utils/errorExistsHelper";
import { formatToMoney } from "../utils/formatMoneyUSD";
import { useRouteNavigator } from "../hooks/useRouteNavigator";
import { Evidence } from "../redux/types/Submission";
import { FormTypes } from "../types/FormMetaData";

const useStyles = makeStyles()({
  marginBottom: {
    marginBottom: "32px",
  },
  marginTop: {
    marginTop: "32px",
  },
  unmarginBottom: {
    marginBottom: "0px",
  },
  unmarginTop: {
    marginTop: "0px",
  },
  verticalPadding: {
    padding: "32px 0",
  },
  dividerLessMargin: {
    width: "75%",
    borderColor: "#A6D7FF",
    margin: "6px 0",
  },
  divider: {
    borderColor: "#A6D7FF",
    margin: "48px 0",
  },
  dividerText: {
    color: "#005499",
    fontWeight: "bold",
  },
  skinnyAlert: {
    height: "64px",
    margin: "32px 0",
  },
  displayInline: {
    display: "inline",
  },
  mobileTextMargin: {
    margin: "12px 24px",
  },
  mobileDivider: {
    borderColor: "#A6D7FF",
    margin: "6px 0",
  },
  mobilePadding: {
    padding: "42px 0",
  },
  alertMargin: {
    marginTop: "12px",
    marginBottom: "4px",
  },
});

type Props = {
  isMobile: boolean;
};

export const ReviewSubmission = ({ isMobile }: Props) => {
  useEffect(() => {document.title = "USCIS | Review Your Submission";}, []);
  const { classes } = useStyles();
  const { routeTo } = useRouteNavigator();
  const [loading, setLoading] = useState<boolean>(true);

  const submission = useSelector((root: RootState) => root.submission);
  const feeTotal = submission.feeTotal ?? 0;
  const { requested: requestedFeeWaiver, files: feeWaiverFileArr } =
    submission.feeWaiver;
  const { evidences } = submission;

  const primaryForm = submission.forms?.find(
    (form) => form.formType === submission.formType,
  );
  const g28Form = submission.forms?.find((form) => form.formType === "G-28");

  const isFormPolling = useSelector(
    (state: RootState) => state.validations.isPollingForFormValidation,
  );

  const isEvidencePolling = useSelector(
    (state: RootState) => state.validations.isPollingForEvidenceValidation,
  );

  const isFeeWaiverPolling = useSelector(
    (state: RootState) => state.validations.isPollingForFeeWaiverValidation,
  );

  const eligibilityCategory = useSelector(
    (state: RootState) => state.submission.eligibilityCategory,
  );

  const { response: submissionStatusResponse } = useSelector(
    (root: RootState) => root.submissionStatus,
  );

  const { selectedConcurrentForms } = useSelector((state: RootState) => state.submission);

  const getEvidenceUrl = (evidence: Evidence) => {
    let formType = submission.formType;
    if(selectedConcurrentForms.length > 0) {
      formType = submission.forms?.find((form) => form.formId === evidence.files[0].formId)?.formType!;
    }

    return `${evidence.evidenceGroup}/${formType}/evidence`;
  }

  const {
    ready,
    hasEvidenceErrors,
    hasEvidenceError,
    hasEligibilityWarning,
    hasPhotoValidationWarning,
    hasMissingEligibilityCategories,
  } = useSubmissionIsComplete();

  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, []);

  const { missingClientInformationForRepresentative } = useClientInformation();

  function submissionAndEvidenceErrors(
    response: SubmissionStatusResponse | null,
  ) {
    if (!response) {
      return [];
    }
      const subErrors = (response.submissionErrors ?? []).map(err => ({
    message: err,
    formType: submission.formType, // fallback to primary
    isEvidence: false
  }));

  // Flatten the evidence groups into individual error objects
  const evidenceErrors = (response.evidenceErrors ?? []).flatMap(group => 
    group.errors.map(err => ({
      message: err,
      formType: group.formType,
      isEvidence: true
    }))
  );

    return [...subErrors, ...evidenceErrors];

  }

  const handleErrorEdit = (error: string, formType?: string) => {
    const i912Regex: RegExp = /I-912/i;
    const feeWaiverRegex: RegExp = /fee waiver/i;
    const i797Regex: RegExp = /I-797/i;
    const evidence908FDRegex: RegExp = /Form ETA-9089 Final Determination/i;

    if (i797Regex.test(error)) {
      if (eligibilityCategory === "C9" || eligibilityCategory === "C8")
        routeTo("form-i-797c");
      else routeTo(`form-i-797/${formType}/evidence`);
    } else if (eligibilityErrorExists(error)) {
      routeTo("select-eligibility");
    } else if (i912Regex.test(error) || feeWaiverRegex.test(error)) {
      routeTo("able-to-pay");
    } else if(evidence908FDRegex) {
      routeTo(`labor-certification/${formType}/evidence`);
    } else {
      routeTo("select-eligibility");
    }
  };

  const handleFormErrorEdit = (error: string, formType: string) => {
    if (formErrorIsEligibilitySelectPageRelated(error)) {
      routeTo(Paths.selectEligibility);
      return;
    }

    const g28Regex: RegExp = /G-28/i;
    if (g28Regex.test(formType)) {
      routeTo(Paths.formG28);
      return;
    }

    if (selectedConcurrentForms.includes(formType as FormTypes)){
      routeTo(Paths.concurrentForms);
      return;
    }

    routeTo(Paths.form);
  };

  return (
    <>
      <div className={isMobile ? classes.mobileTextMargin : ``}>
        <h2 className={classes.unmarginBottom}>
          Check your application or petition before you submit
        </h2>

        <Typography className={classes.marginBottom}>
          We will review your application or petition to check for accuracy and completeness
          before you submit it.
        </Typography>
        <Typography className={classes.marginBottom}>
          We encourage you to provide as many responses as you can throughout
          the application or petition to ensure that it is complete, true, and accurate.
        </Typography>
        <Typography className={classes.marginBottom}>
          You can return to this page to review your application or petition as many times
          as you want before you submit it.
        </Typography>
      </div>

      <div>
        <Typography className={classes.dividerText}>
          Alerts and warnings
        </Typography>
        <Divider
          className={
            isMobile ? classes.mobileDivider : classes.dividerLessMargin
          }
        />
      </div>

      {ready &&
        !hasEligibilityWarning &&
        !hasPhotoValidationWarning &&
        !hasEvidenceErrors && (
          <>
            <div className={isMobile ? classes.mobileTextMargin : ``}>
              <Typography className={classes.verticalPadding}>
                A green alert means you have completed all required fields and
                response
              </Typography>
            </div>
            <div className={classes.skinnyAlert && classes.displayInline}>
              <Typography component="div" className={classes.marginBottom}>
                <AlertWindow
                  variant="success"
                  headerText="We found no alerts or warnings in your application or petition"
                />
              </Typography>
            </div>
          </>
        )}

      {(!ready || hasEligibilityWarning || hasPhotoValidationWarning) && (
        <div className={isMobile ? classes.mobileTextMargin : ``}>
          <Typography>
            You have one or more alerts and warnings based on the information
            you provided in your application or petition.
          </Typography>
        </div>
      )}

      {hasMissingEligibilityCategories
        && (
          <AlertWindow
            variant="error"
            headerText="Missing eligibility category selection(s)"
          >
            <Button
              className={classes.alertMargin}
              variant="contained"
              aria-label={`Edit my responses; Missing eligibility category selection(s)"`}
              onClick={() =>
                routeTo(Paths.selectEligibility)
              }
            >
              Edit my responses
            </Button>
          </AlertWindow>
        )
      }

      {!ready && (
        <div className={classes.skinnyAlert && classes.displayInline}>
          <Typography component="div" className={classes.marginBottom}>
            {submissionStatusResponse?.formErrors?.map(
              (errorGroup: ErrorGroup, i) => {
                return (
                  <>
                    {errorGroup?.errors?.length > 0 && (
                      <>
                        <Typography
                          className={classes.dividerText}
                        >{`Form ${errorGroup.type}`}</Typography>
                        <Divider
                          className={
                            isMobile
                              ? classes.mobileDivider
                              : classes.dividerLessMargin
                          }
                        />
                      </>
                    )}
                    {errorGroup.errors.map((error: string, index: number) => {
                      return (
                        <AlertWindow
                          key={`form_${errorGroup.type}_errors[${index}]`}
                          variant="error"
                          headerText={error}
                        >
                          <Button
                            className={classes.alertMargin}
                            variant="contained"
                            aria-label={`Edit my responses; ${error}`}
                            onClick={() =>
                              handleFormErrorEdit(error, errorGroup.type)
                            }
                          >
                            Edit my responses
                          </Button>
                        </AlertWindow>
                      );
                    })}
                  </>
                );
              },
            )}
          </Typography>
        </div>
      )}

      {!ready && (
        <div className={classes.skinnyAlert && classes.displayInline}>
          <Typography component="div" className={classes.marginBottom}>
            {submissionAndEvidenceErrors(submissionStatusResponse).map(
              (e, i) => {
                const isI912Error = e.message.includes("I-912");

                return (
                  <AlertWindow
                    key={`submission.errors[${i}]`}
                    variant="error"
                    headerText={
                      isI912Error ? "You must upload a fee waiver request" : e.message
                    }
                  >
                    <Typography className={classes.alertMargin}>
                      {isI912Error && e.message}
                    </Typography>
                    <AlertActions>
                      <Button
                        className={classes.alertMargin}
                        variant="contained"
                        aria-label={`Edit my responses; ${e}`}
                        onClick={() => handleErrorEdit(e.message, e.formType)}
                      >
                        Edit my responses
                      </Button>
                    </AlertActions>
                  </AlertWindow>
                );
              },
            )}

            {primaryForm?.formId && isFormPolling && (
              <AlertWindow key="submission.complete" variant="information">
                Your form is currently being validated for completeness. This
                process may take several minutes. You will be notified of the
                validation progress.
              </AlertWindow>
            )}

            {g28Form?.formId && isFormPolling && (
              <AlertWindow key="submission.complete" variant="information">
                Your G-28 form is currently being validated for completeness.
                This process may take several minutes. You will be notified of
                the validation progress.
              </AlertWindow>
            )}

            {submission.evidences.length > 0 && isEvidencePolling && (
              <AlertWindow key="evidence.complete" variant="information">
                Your supporting document is currently being validated for
                completeness. This process may take several minutes. You will be
                notified of the validation progress.
              </AlertWindow>
            )}
            {submission.feeWaiver.files.length > 0 && isFeeWaiverPolling && (
              <AlertWindow key="feeWaiver.complete" variant="information">
                Your fee waiver is currently being validated. This process may
                take several minutes. You will be notified of the validation
                progress.
              </AlertWindow>
            )}
          </Typography>
        </div>
      )}

      {!loading && missingClientInformationForRepresentative && (
        <AlertWindow variant={"error"}>
          <Typography className={classes.alertMargin}>
            There is no client associated with this application or petition. Please add the
            client on the Add Client Information page
          </Typography>
          <AlertActions>
            <Button
              variant="contained"
              onClick={() => routeTo(Paths.clientInfo)}
            >
              Edit my responses
            </Button>
          </AlertActions>
        </AlertWindow>
      )}

      {hasEligibilityWarning && (
        <AlertWindow variant={"warning"}>
          <Typography className={classes.alertMargin}>
            There are warnings in Basis of Eligibility: Form Category Mismatch
          </Typography>
          <Typography className={classes.alertMargin}>
            Failure to correct the category mismatch may result in your
            application or petition being rejected.
          </Typography>
          <AlertActions>
            <Button
              variant="contained"
              onClick={() => routeTo("select-eligibility")}
            >
              Edit my responses
            </Button>
          </AlertActions>
        </AlertWindow>
      )}

      {hasPhotoValidationWarning && (
        <AlertWindow variant={"warning"}>
          <Typography className={classes.alertMargin}>
            Photo validation error
          </Typography>
          <Typography className={classes.alertMargin}>
            Your photo does not meet photo requirements. Failure to provide a
            compliant photo may result in your benefit request being denied.
          </Typography>
          <AlertActions>
            <Button
              variant={"contained"}
              onClick={() => routeTo("applicant-photo")}
            >
              Edit my responses
            </Button>
          </AlertActions>
        </AlertWindow>
      )}

      {hasEvidenceErrors &&
        evidences?.map(
          (evidence, evidenceId) =>
            evidence.files?.map(
              (file, id) =>
                hasEvidenceError(file) && (
                  <AlertWindow key={`${evidenceId}-${id}`} variant={"warning"}>
                    <Typography className={classes.alertMargin}>
                      Evidence {file.fileName} has incorrect evidence type
                    </Typography>
                    <AlertActions>
                      <Button
                        variant={"contained"}
                        onClick={() => routeTo(getEvidenceUrl(evidence))}
                      >
                        Edit my responses
                      </Button>
                    </AlertActions>
                  </AlertWindow>
                ),
            )
        )
      }

      <div>
        <Typography className={classes.dividerText}>Your fee</Typography>
        <Divider
          className={
            isMobile ? classes.mobileDivider : classes.dividerLessMargin
          }
        />
      </div>

      <div
        className={classes.skinnyAlert && isMobile ? classes.displayInline : ``}
      >
        <AlertWindow
          variant="information"
          headerText={`Your form filing fee is: ${formatToMoney(feeTotal)}`}
        />
      </div>

      {requestedFeeWaiver && feeWaiverFileArr.length > 0 && (
        <AlertWindow
          headerText="You have applied for a fee waiver"
          variant="warning"
        >
          <div>
            {" "}
            Your fee waiver request is currently being evaluated. In the event
            your fee waiver request is denied, your form will be rejected. You
            may resubmit your form if it is rejected.
            <br />
            <br />
            Please ensure you have submitted supporting documentary evidence for
            your fee waiver request. Failure to do so may result in your form
            being rejected.
          </div>
        </AlertWindow>
      )}

      <div className={isMobile ? classes.mobileTextMargin : ``}>
        <Typography className={classes.verticalPadding}>
          <b>Refund Policy:</b> USCIS does not refund fees, regardless of any
          action we take on your application, petition or request, or how long
          USCIS takes to reach a decision. By continuing this transaction, you
          acknowledge that you must submit fees in the exact amount and that you
          are paying the fees for a government service.
        </Typography>
      </div>

      <USCISDivider />

      <NavigationButtons disableNext={!ready || hasEvidenceErrors} />
    </>
  );
};
