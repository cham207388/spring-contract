import { useSelector } from "react-redux";
import FormDropzone from "../components/FormDropzone";
import NavigationButtons from "../components/NavigationButtons";
import { FileRequirementsNoAdditionalEvidence, PrimaryFormFileRequirements  } from "../components/shared/FileRequirements";
import Section from "../components/shared/Section";
import USCISDivider from "../components/shared/USCISDivider";
import { RootState } from "../redux/store";
import MarkdownWithLinks from "../components/shared/MarkdownWithLinks";

import { makeStyles } from "tss-react/mui";
import NewN400FormBanner from "../components/NewN400FormBanner";
import { useEffect } from "react";
import AcceptedFormTypes from "../constants/AcceptedFormTypes";
import { Box } from "myuscis-material";
const fontFamily = "SourceSansProRegular,Source Sans Pro,sans-serif";
const useStyles = makeStyles()({
  markdown: {
    paddingBlockStart: "32px",
    marginBlockEnd: "32px",
    "& > *": { marginBlock: "0 16px" },
    "& p, & ol, & ul, & input": {
      font: `normal normal normal 16px/24px ${fontFamily}`,
    },
    "& h2": {
      font: `normal normal bold 32px/32px ${fontFamily}`,
    },
    "& h3": {
      font: `normal normal bold 22px/28px ${fontFamily}`
    },
    "& li > p": {
      marginBlock: "0",
    },
    "& :not(p):not(ul):not(li):not(h2):not(svg):not(div):not(label):not(b):not(input)":
      {
        marginBlock: "32px",
      },
    "& & h2, & h3, & h4, & h5, & h6": { marginBlockEnd: "8px !important" },
    "& a": { color: "#006699" },
    "& a:hover": { color: "#00476B" },
  },
});


const UploadPdf = () => {
const { classes } = useStyles();
const { formType } = useSelector((state: RootState) => state.submission);
const { formMetadata } = useSelector(
  (state: RootState) => state.formMetadata,
);

 const isI129 = [
    AcceptedFormTypes.I_129H1B,
    AcceptedFormTypes.I_129E,
    AcceptedFormTypes.I_129TN,
    AcceptedFormTypes.I_129R,
    AcceptedFormTypes.I_129CW,
    AcceptedFormTypes.I_129E3,
    AcceptedFormTypes.I_129H3,
    AcceptedFormTypes.I_129L,
    AcceptedFormTypes.I_129OP,
    AcceptedFormTypes.I_129Q,
    AcceptedFormTypes.I_129S,
    AcceptedFormTypes.I_129H2B
  ].includes(formType as any);

const is907 = formType === AcceptedFormTypes.I_907;

const getUSCISFormType = (formType: String) => {
  if(isI129) {
    return "I-129"
  }
  return formType
}

useEffect(() => {
  document.title = `USCIS | Upload PDF (${formType})`;
}, [formType]);

const uploadFormProps = formMetadata?.pages?.uploadForm ?? {};
const additionalInfoPartNumber = uploadFormProps.additionalInfoPartNumber ?? undefined;
const pageMarkdown = uploadFormProps.pageMarkdown ?? undefined;
const optionalLinkText = uploadFormProps.optionalLinkText ?? undefined;

const additionalInfoContent = <span>
  &nbsp;(for example,{" "}
  <b>Part {additionalInfoPartNumber}. Additional Information</b> is a
  page that may be left blank, but you should still upload{" "}
  <b>Part {additionalInfoPartNumber}.</b> with your completed form).
</span>

  return (
    <>
      <Section>
        {formType === "N-400" && <NewN400FormBanner formType={formType} />}
        {
          pageMarkdown && (
            <MarkdownWithLinks className={classes.markdown}>
              {pageMarkdown}
            </MarkdownWithLinks>
          )
        }
        {!pageMarkdown && (
          <>
            <Box>
              <h2>PDF Form Upload</h2>
            </Box>
            <p>
              Upload all pages of the Form&nbsp;
              <a
                href={`https://www.uscis.gov/${getUSCISFormType(formType)}`}
                target="_blank"
                rel="noreferrer"
              >
                {optionalLinkText ? optionalLinkText : formType}
              </a>
              &nbsp;in PDF file format only. Place all pages in the correct order by
              referring to the page numbers on the form. For forms that have been
              scanned into PDF format, include all pages when uploading, even pages
              where you were not required to provide information
              {additionalInfoPartNumber ? (additionalInfoContent) : (`.`) }
            </p>

          </>
          )
        }
        <>
          <p>You must:</p>
          <ul>
            <li>Upload one PDF file of the form;</li>
            <li>Include <strong>all</strong> pages of the form in the file, even if you did not provide any information on the page; and</li>
            <li>Arrange the form in the same order as its page numbers.</li>
            <li>
              Please ensure that the signature you provided on the PDF complies with USCIS regulations and policies.
              Namely, the signature must be handwritten, may not be typed, created by a typewriter, word processor,
              stamp, auto-pen, or similar device.
            </li>
          </ul>
          <p><strong>Do not</strong> include any evidence in the file. You will add your evidence later in the process.</p>
        </>
        {
          is907 ?
          (
          <FileRequirementsNoAdditionalEvidence
            maxFiles={1}
            accept={{
              "application/pdf": [".pdf"],
            }}
          />
          )
          :
          (
            <PrimaryFormFileRequirements
              maxFiles={1}
              accept={{
                "application/pdf": [".pdf"],
              }}
              formType={formType}
            />
          )
        }
      </Section>

      <FormDropzone formType={formType} />

      <USCISDivider />

      <NavigationButtons />
    </>
  );
};

export default UploadPdf;
