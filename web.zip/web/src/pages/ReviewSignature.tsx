import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { makeStyles } from "tss-react/mui";
import { Button } from "myuscis-material";

import { RootState } from "../redux/store";
import { setHasReviewedSignature } from "../redux/submissionSlice";

import Section from "../components/shared/Section";
import NavigationButtons from "../components/NavigationButtons";
import USCISDivider from "../components/shared/USCISDivider";
import FileViewerDialog from "../components/Dialogs/FileViewerDialog";
import { SubmissionService } from "../api/SubmissionService";
import { formatFileName } from "../utils/formatFileName";

const useStyles = makeStyles()({
  checkboxLabel: {
    display: "flex",
    fontSize: "16px",
  },
});

export const ReviewSignature = () => {
  useEffect(() => {document.title = "USCIS | Review Signature";}, []);
  const { classes } = useStyles();
  const dispatch = useDispatch();
  const [showFileViewer, setShowFileViewer] = useState(false);

  const {
    hasReviewedSignature,
    submissionId,
    forms,
    formType: primaryFormType,
  } = useSelector((state: RootState) => state.submission);

  const primaryForm = forms.find((form) => form.formType === primaryFormType);

  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);

  const uri = `/pdf-intake/api/intake/${myUscisId}/submissions/${submissionId}/form/attested`;

  useEffect(() => {
    document.documentElement.scrollTo(0, 0);
  }, [hasReviewedSignature]);

  const onNext = async (next: () => void) => {
    await SubmissionService.updateSignatureReviewed(
      myUscisId,
      submissionId,
      hasReviewedSignature,
      userGroupId
    );
    next();
  };

  return (
    <>
      <Section>
        <h2>Review Your Signature</h2>
        <p>Please review your signature before proceeding.</p>
        <FileViewerDialog
          isOpen={showFileViewer}
          setIsOpen={setShowFileViewer}
          uri={uri}
        />
        <Button
          style={{
            background: "none!important",
            border: "none",
            padding: "0!important",
          }}
          onClick={() => setShowFileViewer(true)}
          variant={"text"}
        >
          {formatFileName(primaryForm?.fileName || "")}
        </Button>
        <label className={classes.checkboxLabel}>
          <input
            id="reviewed_checkbox"
            name="review signature"
            style={{
              position: "relative",
              margin: "unset",
              marginRight: "5px",
            }}
            type="checkbox"
            checked={hasReviewedSignature}
            onChange={(e) => {
              dispatch(setHasReviewedSignature(e.target.checked));
            }}
          />
          I have reviewed my signature
        </label>
      </Section>

      <USCISDivider />
      <NavigationButtons disableNext={!hasReviewedSignature} onNext={onNext} />
    </>
  );
};
