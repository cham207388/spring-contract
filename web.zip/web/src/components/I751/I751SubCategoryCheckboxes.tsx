import {
  Typography,
  Box,
  Checkbox,
  CheckboxGroup,
} from "myuscis-material";
import USCISDivider from "./../shared/USCISDivider";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "../../redux/store";
import { EligibilitySubcategory, FormMetaData } from "../../types/FormMetaData";
import { useState } from "react";
import { hydrateState, setEligibilitySubcategories } from "../../redux/submissionSlice";
import { SubmissionService } from "../../api/SubmissionService";
import { I751EligiilitySubcategories } from "../../types/I751Types";
import React from 'react';
import { setIsPollingForFormValidation } from "../../redux/validationsSlice";
import { calculateAndSetEvidenceGroups } from "../../redux/thunks/calculateAndSetEvidenceGroups";

export type CheckboxEligibilitySubcategory = {
  category: string;
  label: string;
  disabled: boolean;
  checked: boolean;
};

type props = {
  formMetadata: FormMetaData;
  eligibilityCategory: string;
};

const I751SubCategoryCheckboxes = ({ formMetadata, eligibilityCategory }: props) => {
  const {
    eligibilitySubcategories,
    submissionId,
  } = useSelector((state: RootState) => state.submission);
  const { evidenceGroups } = useSelector((state: RootState) => state.evidence);
  const { myUscisId } = useSelector((state: RootState) => state.user);

  const { SPOUSE_DECEASED, GOOD_FAITH_SPOUSE_EXTREME_CRUELTY, PARENT_GOOD_FAITH_EXTREME_CRUELTY, DIVORCE_ANNULMENT, EXTREME_HARDSHIP } = I751EligiilitySubcategories;
  const dispatch = useAppDispatch();
  const [checkboxState, setCheckboxState] = useState<CheckboxEligibilitySubcategory[]>(hydrateCheckBoxState(eligibilitySubcategories))

  function hydrateCheckBoxState(existingSubcategories: string[] | undefined): CheckboxEligibilitySubcategory[] {
    let currentState: CheckboxEligibilitySubcategory[] = formMetadata.eligibilityCategories
      .find((cat) => cat.category === eligibilityCategory)!
      .metaData.subcategories.filter(
        subCategory => subCategory.disabled === null || !subCategory.disabled
      ).map(({ category, label }: EligibilitySubcategory): CheckboxEligibilitySubcategory => {
        return {
          category,
          label,
          disabled: false,
          checked: false
        }
      })

    const existingSelections = existingSubcategories?.flatMap(existing => currentState.filter(el => el.category === existing).map(el => el.category))

    currentState = validateSelection(existingSelections ?? [], true, [...currentState]);
    return currentState
  }

  function validateSelection(selections: string[], checked: boolean, state: CheckboxEligibilitySubcategory[]): CheckboxEligibilitySubcategory[] {
    const validationGroupOne: string[] = [SPOUSE_DECEASED, DIVORCE_ANNULMENT, GOOD_FAITH_SPOUSE_EXTREME_CRUELTY]
    const validationGroupTwo: string[] = [PARENT_GOOD_FAITH_EXTREME_CRUELTY]


    selections.map(selection => {
      // update one selection
      const idx = state.findIndex(el => el.category === selection)
      state[idx] = {
        category: state[idx].category,
        label: state[idx].label,
        checked,
        disabled: false
      }

      // set checkboxes disabled
      if (validationGroupOne.includes(selection)) disableCheckBoxes(validationGroupTwo, state);
      if (validationGroupTwo.includes(selection)) disableCheckBoxes(validationGroupOne, state);
    })

    const checkedCount = state.filter(el => el.checked === true).length;
    const noSelections = checkedCount === 0;
    const extremeHardshipOnlySelection = checkedCount === 1 && state.find(el => el.category === EXTREME_HARDSHIP)?.checked === true;
    // clear disabled checkboxes when no selections are preset
    if (noSelections || extremeHardshipOnlySelection) state.forEach(checkbox => checkbox.disabled = false)

    return state
  }

  const handleSubCategoryCheckbox = async (event: React.ChangeEvent<HTMLInputElement>, checked: boolean) => {
    const updatedState = validateSelection([event.target.value], checked, [...checkboxState])
    let selectedItems = updatedState.filter(el => el.checked).map(el => el.category);
    const underOrders = I751EligiilitySubcategories.ACTIVE_MILITARY_OR_GOVERNMENT_ORDERS

    if (underOrders && eligibilitySubcategories?.includes(underOrders)) selectedItems = [underOrders, ...selectedItems]

    setCheckboxState(updatedState)
    dispatch(setEligibilitySubcategories(selectedItems))
    dispatch(calculateAndSetEvidenceGroups())

    const submission = await SubmissionService.updateEligibilitySubcategories(
      myUscisId,
      submissionId,
      selectedItems,
    );

    if (submission) dispatch(hydrateState({ submission, evidenceGroups }));
    if (submission?.forms?.length > 0) dispatch(setIsPollingForFormValidation(true));
  }

  function disableCheckBoxes(validationGroup: string[], checkboxState: CheckboxEligibilitySubcategory[]) {
    checkboxState.filter(el => validationGroup.includes(el.category)).map(checkbox => {
      const idx = checkboxState.findIndex(el => el.category === checkbox.category);
      checkboxState[idx] = {
        category: checkboxState[idx].category,
        label: checkboxState[idx].label,
        checked: false,
        disabled: true
      };
    });
  }

  const formatLabelAndNumber = (label: string) => {
    const idx = label.indexOf(" ");
    const questionNumber = label.slice(0, idx);
    const questionLabel = label.slice(idx + 1).trimStart();

    return { questionNumber, questionLabel };
  }

  return (
    <>
      <USCISDivider />

      <Typography>
        {
          formMetadata.eligibilityCategories.find(
            (cat) => cat.category === eligibilityCategory,
          )?.metaData.subCategoryHeader
        }
      </Typography>

      {checkboxState.map(({ label, category, disabled, checked }, index) => {
        const { questionNumber, questionLabel } = formatLabelAndNumber(label);
        return (
          <Box key={questionNumber} display="flex" flexDirection="row" gap={2} sx={{ paddingTop: "5px", paddingBottom: "5px" }}>
            <Typography component="span" sx={{ lineHeight: 2 }}>
              {questionNumber &&
                <strong>{questionNumber}</strong>}
            </Typography>
            <CheckboxGroup>
              <Checkbox label={questionLabel} checked={checked} disabled={disabled} value={category} onChange={(event, checked) => handleSubCategoryCheckbox(event, checked)} />
            </CheckboxGroup>
          </Box>
        );
      })}
    </>
  );
};

export default I751SubCategoryCheckboxes;
