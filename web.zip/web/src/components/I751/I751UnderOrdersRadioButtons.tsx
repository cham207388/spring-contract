import {
  RadioButtons,
} from "myuscis-material";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "../../redux/store";
import { useState } from "react";
import { setFormSpecificInfo } from "../../redux/submissionSlice";
import { SubmissionService } from "../../api/SubmissionService";
import USCISDivider from "../shared/USCISDivider";

const I751UnderOrdersRadioButtons = () => {
  const {
    formType,
    submissionId,
    formSpecificInfo
  } = useSelector((state: RootState) => state.submission);
  const { myUscisId } = useSelector((state: RootState) => state.user);

  const dispatch = useAppDispatch();
  const [isUnderOrders, setIsUnderOrders] = useState<boolean>(formSpecificInfo?.isUnderOrders ?? false)

  const handleSubCategoryCheckbox = async (value: boolean) => {
    try {
      await SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        { formType, isUnderOrders: value },
      );

      dispatch(setFormSpecificInfo({ formType, isUnderOrders: value }))
      setIsUnderOrders(value)
    } catch (error) {
      console.error(error)
    }
  }

  return (
    <>
    <USCISDivider/>
      <RadioButtons
        onChange={(event, value) => handleSubCategoryCheckbox(value === "true")}
        name={"name"}
        value={isUnderOrders}
        options={[
          {
            value: true,
            label: "Under Active Military Or Government Orders",
          },
          {
            value: false,
            label: "Not Under Active Military Or Government Orders",
          },
        ]}
      />
    </>
  );
};

export default I751UnderOrdersRadioButtons;
