import { useDispatch, useSelector } from "react-redux";
import { 
  Alert, 
  AlertHeader,
} from 'myuscis-material';
import { popAlert } from "../redux/alertSnackbarSlice";
import { AppDispatch, RootState } from "../redux/store";

const AlertSnackbar = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { alerts } = useSelector<RootState>(
    (state) => state.snackbar,
  ) as RootState["snackbar"];

  const topAlert = alerts.length > 0 ? alerts[alerts.length - 1] : null;

  if (!topAlert) return null;

  const handleOnDismiss = () => {
    dispatch(popAlert());
  };

  return (
    <div 
        role="alert"
        style={{ 
        position: 'fixed', 
        top: 20,
        left: '50%',
        transform: 'translateX(-26%)',
        zIndex: 9999,
        width: 'auto',
        maxWidth: '90vw'
       }}
      >
        <Alert 
          variant={topAlert.severity as any} 
          onDismiss={handleOnDismiss}
        >
          <AlertHeader>
            {topAlert.message}
          </AlertHeader>
        </Alert>
    </div>
  );
};

export default AlertSnackbar;
