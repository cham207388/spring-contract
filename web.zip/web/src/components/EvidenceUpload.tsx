import { useState } from "react";
import { FileRejection } from "react-dropzone";
import { useDispatch, useSelector } from "react-redux";

import EvidenceDropzone from "./EvidenceDropzone";
import USCISDivider from "./shared/USCISDivider";
import NavigationButtons from "./NavigationButtons";
import Section from "./shared/Section";
import OtherFileRequirements from "./shared/FileRequirements";
import { RootState } from "../redux/store";
import { Evidence } from "../redux/types/Submission";
import { selectedEvidencesForGroup } from "../redux/evidenceSlice";
import { setEvidenceConfirmed } from "../redux/submissionSlice";
import { EvidenceWarning } from "./shared/EvidenceWarning";
import AlertWindow from "./shared/AlertWindow";
import FileErrorAlert from "./FileErrorAlert";
import MarkdownWithLinks from "./shared/MarkdownWithLinks";
import { makeStyles } from "tss-react/mui";
import OfficialStatement from "./OfficialStatement";
import { useParams } from "react-router-dom";
import CircularProgress from "@mui/material/CircularProgress";
import { Grid, Typography } from "myuscis-material";

type Props = {
  id: string;
};

const fontFamily = "SourceSansProRegular,Source Sans Pro,sans-serif";

const useStyles = makeStyles()({
  markdown: {
    paddingBlockStart: "32px",
    marginBlockEnd: "32px",
    "& > *": { marginBlock: "0 16px" },
    "& p, & ol, & ul, & input": {
      font: `normal normal normal 16px/24px ${fontFamily}`,
    },
    "& h2": {
      font: `normal normal bold 32px/32px ${fontFamily}`,
      lineHeight: "1.15",
    },
    "& h3": {
      font: `normal normal bold 22px/28px ${fontFamily}`
    },
    "& li > p": {
      marginBlock: "0",
    },
    "& :not(p):not(ul):not(li):not(h2):not(svg):not(div):not(label):not(b):not(input)":
    {
      marginBlock: "32px",
    },
    "& & h2, & h3, & h4, & h5, & h6": { marginBlockEnd: "8px !important" },
    "& a": { color: "#006699" },
    "& a:hover": { color: "#00476B" },
  },
});

export const EvidenceUpload = ({ id }: Props) => {
  const dispatch = useDispatch();
  const { classes } = useStyles();
  const { selectedFormType } = useParams<{ selectedFormType: string }>();

  const evidencePage = useSelector(
    (state: RootState) => state.coreMetadata.evidencePages[id],
  );

  const [showAlert, setShowAlert] = useState(true);
  const [fileRejections, setFileRejections] = useState<FileRejection[]>([]);

  const evidences: Evidence = useSelector((state: RootState) =>
    selectedEvidencesForGroup(state, id),
  )[0];

  const eligibilityCategory = useSelector(
    (state: RootState) => state.submission.eligibilityCategory,
  );

  const handleNext = (next: () => void) => {
    if (!evidences?.files.length && !evidences?.confirmed) {
      dispatch(setEvidenceConfirmed(id));
      return;
    }
    next();
  };

  if (!evidencePage) {
    return (
      <Grid
        container
        justifyContent="center"
        alignItems="center"
        sx={{ minHeight: '100vh' }}
        className={classes.markdown}
      >
        <Grid item >
          <Typography variant="h2" gutterBottom>
            Now Loading...
          </Typography>
          <CircularProgress size="10rem" />
        </Grid>
      </Grid>
    )
  }

  return (
    <>
      <MarkdownWithLinks className={classes.markdown}>
        {evidencePage.component}
      </MarkdownWithLinks>
      {eligibilityCategory === "C9" && id === "form-i-797c" && (
        <AlertWindow variant="information">
          <strong>
            Include a copy of your Form I-797C, Notice of Action receipt notice
            for your previously accepted Form I-485 application
          </strong>
        </AlertWindow>
      )}

      {(eligibilityCategory === "C19" || eligibilityCategory === "A12") &&
        id === "form-i-797" && (
          <AlertWindow variant="information">
            <strong>
              Include a copy of your Form I-797, Notice of Action receipt notice
              for your previously accepted Form I-821 application.
            </strong>
          </AlertWindow>
        )}

      {eligibilityCategory === "I129H2A_UNNAMED" &&
        id === "temporary-labor-certification" && (
          <AlertWindow variant="information">
            <strong>
              Under certain emergent circumstances, as determined by USCIS,
              petitions requesting a continuation of employment with the same
              employer for 2 weeks or less are exempt from the temporary labor
              certification requirement. See 8 CFR 214.2(h)(5)(x)
            </strong>
          </AlertWindow>
        )}

      {id === "official-statement" && <OfficialStatement />}

      <Section>
        <OtherFileRequirements
          maxFiles={evidencePage.dropzoneProps.maxUploads}
          accept={evidencePage.dropzoneProps.accept}
        />
      </Section>

      {(eligibilityCategory === "ABUSED_SPOUSES_CHILDREN_AND_PARENTS") &&
        (
          <AlertWindow variant="information">
            A VAWA self-petitioning spouse or child of a U.S. citizen or lawful permanent
            resident, or a VAWA selfpetitioning parent of a U.S. citizen son or daughter,
            may submit any relevant credible evidence in place of the suggested evidence.
          </AlertWindow>
        )}

      <EvidenceDropzone
        deleteWarningText={"This will delete the image file."}
        evidenceGroupType={id}
        setFileRejectionsForAlert={setFileRejections}
        setShowFileRejectionsAlert={setShowAlert}
        dropzoneProps={evidencePage.dropzoneProps}
        selectedFormType={selectedFormType!}
      />

      <FileErrorAlert
        fileRejections={fileRejections}
        showAlert={showAlert}
        setShowAlert={setShowAlert}
        acceptedTypes={evidencePage.dropzoneProps.accept}
      />

      {!evidences?.files.length && evidences?.confirmed && <EvidenceWarning />}

      <USCISDivider />

      <NavigationButtons onNext={handleNext} />
    </>
  );
};