import { EvidenceUpload } from "./EvidenceUpload";
import { Step, useSteps } from "../hooks/useSteps";
import { ACCORDION_HEADERS } from "../types/Accordion";
import { useEffect } from "react";

export const EvidenceContainer = () => {
  const { currentStep, steps } = useSteps();

  useEffect(() => {
    document.title = currentStep.name ? `USCIS | Evidence - ${currentStep.name}` : 'USCIS | Evidence'
  }, [currentStep]);

  return (
    <>
      {steps.map(
        (step: Step) =>
          step.id === currentStep.id &&
          step.header === ACCORDION_HEADERS.EVIDENCE && (
            <EvidenceUpload key={step.id} id={step.id.substring(0, step.id.indexOf("/"))} />
          ),
      )}
    </>
  );
};
