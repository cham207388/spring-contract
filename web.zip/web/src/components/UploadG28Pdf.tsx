import AlertWindow from "./shared/AlertWindow";
import FormDropzone from "./FormDropzone";
import NavigationButtons from "../components/NavigationButtons";
import OtherFileRequirements from "../components/shared/FileRequirements";
import Section from "../components/shared/Section";
import USCISDivider from "../components/shared/USCISDivider";
import { useEffect } from "react";

const UploadG28Pdf = () => {
  const formType = "G-28";
  useEffect(() => { document.title = `USCIS | Upload PDF (${formType})`; }, []);

  return (
    <>
      <Section>
        <h2>{formType} PDF Form Upload</h2>

        <p>
          Upload all pages of the Form&nbsp;
          <a
            href={`https://www.uscis.gov/${formType}`}
            target="_blank"
            rel="noreferrer"
          >
            {formType}
          </a>
          &nbsp;in PDF file format only. Place all pages in the correct order by
          referring to the page numbers on the form. Include all pages when
          uploading, whether filled out with your information or left
          intentionally blank.
        </p>
          <p>You must:</p>
          <ul>
            <li>Upload one PDF file of the form;</li>
            <li>Include <strong>all</strong> pages of the form in the file, even if you did not provide any information on the page; and</li>
            <li>Arrange the form in the same order as its page numbers.</li>
            <li>
              Please ensure that the signature you provided on the PDF complies with USCIS regulations and policies.
              Namely, the signature must be handwritten, may not be typed, created by a typewriter, word processor,
              stamp, auto-pen, or similar device.
            </li>
          </ul>
        <OtherFileRequirements
          maxFiles={1}
          accept={{
            "application/pdf": [".pdf"],
          }}
        />
        <AlertWindow variant="warning">
          Please ensure you have signed your G-28 form. Failure to do so may
          result in your application being rejected.
        </AlertWindow>
      </Section>

      <FormDropzone formType={formType} />

      <USCISDivider />

      <NavigationButtons />
    </>
  );
};

export default UploadG28Pdf;
