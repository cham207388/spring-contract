import { faInfoCircle } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Typography } from "@mui/material";
import { makeStyles } from "tss-react/mui";

const useStyles = makeStyles()((_theme) => ({
  container: {
    backgroundColor: _theme.palette.background.default,
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
}));

const GlobalBanner = ({ bannerText }: { bannerText: string }) => {
  const { classes } = useStyles();

  const message = (
    <>
      <p>{bannerText}</p>
    </>
  );
  return (
    <div className={classes.container}>
      <FontAwesomeIcon
        icon={faInfoCircle}
        size="2x"
        color="#006699"
        style={{ marginRight: 10 }}
      />
      <Typography variant="h4" style={{ padding: "1rem 0" }}>
        {message}
      </Typography>
    </div>
  );
};

export default GlobalBanner;
