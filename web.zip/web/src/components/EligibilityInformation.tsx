import { eligibilityInformationMap } from "../pages/eligibility-information";

const EligibilityInformation = ({ eligibilityCategory }: {
  eligibilityCategory: string
}) => {
  return (
    <>
      {eligibilityCategory !== "" &&
        eligibilityInformationMap[eligibilityCategory]}
    </>
  );
};

export default EligibilityInformation;
