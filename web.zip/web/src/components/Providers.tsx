import MyUscisThemeProvider from "myuscis-material";
import React, { PropsWithChildren } from "react";
import { CookiesProvider } from "react-cookie";
import { Provider } from "react-redux";
import { DocumentUploadProvider } from "../contexts/DocumentUploadContext";
import { store } from "../redux/store";

const Providers = (props: PropsWithChildren) => {
  return (
    <React.StrictMode>
      <CookiesProvider>
        <MyUscisThemeProvider>
          <Provider store={store}>
            <DocumentUploadProvider>{props.children}</DocumentUploadProvider>
          </Provider>
        </MyUscisThemeProvider>
      </CookiesProvider>
    </React.StrictMode>
  );
};

export default Providers;
