import {
  Box,
  Link,
  List,
  ListItem,
  ListItemText,
  Stack,
  Typography,
} from "@mui/material";
import { makeStyles } from "tss-react/mui";

import { SharedLayoutProps } from "../../Layout/Layout";
import Logo from "../../shared/Logo/Logo";
import { externalRowLinks } from "../../../constants/NavLinks";

const useStyles = makeStyles<{ isMobile: boolean | undefined }>()(
  (_theme, { isMobile }) => ({
    footerSection: {
      backgroundColor: "#005288",
      padding: "20px 0",
      "&--heading": {
        color: "#edeeee",
        fontSize: "16px",
        "&__body": {
          fontWeight: _theme.typography.fontWeightBold,
        },
        "&__link": {
          textDecoration: "underline",
        },
      },
      "&--list": {
        "&__link": {
          color: "#c0c2c4",
          fontSize: "17px",
          textDecoration: "underline",
          "&:hover": { color: _theme.palette.background.default },
        },
      },
    },
    linkGrid: {
      padding: 0,
      columnCount: isMobile ? 1 : 3,
      columnGap: "32px",
    },
    container: {
      maxWidth: "1028px",
      margin: "0 auto",
      padding: "0 64px",
      display: "flex",
      justifyContent: "space-between",
      flexDirection: isMobile ? "column" : "row",
    },
  }),
);

const ExternalLinkRow = ({ isMobile }: SharedLayoutProps) => {
  const { classes } = useStyles({ isMobile });

  return (
    <nav className={classes.footerSection}>
      <Box className={classes.container}>
        <Stack spacing={3} sx={{ width: "100%" }}>
          <Stack direction={isMobile ? "column" : "row"} spacing={2}>
            <Logo variant="compact" />
            <Box>
              <Typography className={`${classes.footerSection}--heading`}>
                USCIS.gov
              </Typography>
              <Typography
                className={`${classes.footerSection}--heading ${classes.footerSection}--heading__body`}
              >
                An official website of the{" "}
                <Link
                  href="https://www.dhs.gov/"
                  className={`${classes.footerSection}--heading ${classes.footerSection}--heading__link`}
                >
                  U.S. Department of Homeland Security
                </Link>
              </Typography>
            </Box>
          </Stack>
          <List className={classes.linkGrid}>
            {externalRowLinks.map((link) => (
              <ListItem
                sx={{ padding: "0 0 12px 0", width: "75%" }}
                key={link.name}
              >
                <ListItemText
                  sx={{ margin: 0 }}
                  primary={
                    <Link
                      href={link.url()}
                      className={`${classes.footerSection}--list__link`}
                    >
                      {link.name}
                    </Link>
                  }
                />
              </ListItem>
            ))}
          </List>
        </Stack>
        <iframe
          src="https://www.dhs.gov/ntas/"
          name="National Terrorism Advisory System"
          title="National Terrorism Advisory System"
          width="170"
          height="180"
          style={{
            border: "none",
          }}
          seamless
        ></iframe>
      </Box>
    </nav>
  );
};

export default ExternalLinkRow;
