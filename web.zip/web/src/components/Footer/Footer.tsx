import InternalLinkRow from "./InternalLinkRow/InternalLinkRow";
import { SharedLayoutProps } from "../Layout/Layout";
import SocialLinkRow from "./SocialLinkRow/SocialLinkRow";
import ExternalLinkRow from "./ExternalLinkRow/ExternalLinkRow";

const Footer = ({ isMobile }: SharedLayoutProps) => {
  return (
    <footer>
      <InternalLinkRow isMobile={isMobile} />
      <SocialLinkRow isMobile={isMobile} />
      <ExternalLinkRow isMobile={isMobile} />
    </footer>
  );
};

export default Footer;
