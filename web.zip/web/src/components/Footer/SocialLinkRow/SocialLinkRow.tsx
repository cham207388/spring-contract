import { makeStyles } from "tss-react/mui";
import { Box, Link, Stack } from "@mui/material";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import { SharedLayoutProps } from "../../Layout/Layout";
import Logo from "../../shared/Logo/Logo";
import { socialLinks } from "../../../constants/NavLinks";

const useStyles = makeStyles<{ isMobile: boolean | undefined }>()(
  (_theme, { isMobile }) => ({
    footerSection: {
      backgroundColor: "#dedfe0",
      borderTop: "1px solid #a9aeb1",
      padding: isMobile ? "20px 16px" : "20px 32px",
      "&--container": {
        display: "flex",
        maxWidth: "1032px",
        margin: "0 auto",
        flexDirection: isMobile ? "column" : "row",
        justifyContent: "space-between",
        gap: "16px",
        padding: "0 32px",
      },
      "&--link": {
        cursor: "pointer",
        "&:focus": {
          outline: "4px solid black",
          outlineOffset: "2px",
        },
        "&__social": {
          padding: "10px",
          color: "#080808",
          backgroundColor: "rgba(0,0,0,0.1);",
          "&:hover": { backgroundColor: _theme.palette.background.default },
        },
        "&__contact": {
          alignSelf: isMobile ? "flex-start" : "flex-end",
          fontSize: "24px",
          fontWeight: _theme.typography.fontWeightBold,
          textDecoration: "underline",
          color: "#005288",
          width: "fit-content",
          "&:hover": { color: "#002b47" },
        },
      },
    },
  }),
);

const SocialLinkRow = ({ isMobile }: SharedLayoutProps) => {
  const { classes } = useStyles({ isMobile });

  return (
    <nav className={classes.footerSection}>
      <Box className={`${classes.footerSection}--container`}>
        <Logo variant="footer" style={{ marginLeft: isMobile ? "24px" : "" }} />
        <Stack gap={1}>
          <Stack direction="row" alignItems="center" gap={1}>
            {socialLinks.map((link) => (
              <Link
                key={link.name}
                href={link.url()}
                className={`${classes.footerSection}--link ${classes.footerSection}--link__social`}
                aria-label={`USCIS ${link.name} social media page`}
                target="_blank"
                rel="noreferrer"
              >
                <FontAwesomeIcon icon={link.iconName!} size="2xl" />
              </Link>
            ))}
          </Stack>
          <Link
            href="https://www.uscis.gov/about-us/contact-us"
            className={`${classes.footerSection}--link ${classes.footerSection}--link__contact`}
          >
            Contact USCIS
          </Link>
        </Stack>
      </Box>
    </nav>
  );
};

export default SocialLinkRow;
