import {
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Typography,
} from "@mui/material";
import { makeStyles } from "tss-react/mui";

import { SharedLayoutProps } from "../../Layout/Layout";
import { internalRowLinks } from "../../../constants/NavLinks";

const useStyles = makeStyles<{ isMobile: boolean | undefined }>()(
  (_theme, { isMobile }) => ({
    container: {
      maxWidth: "1024px",
      margin: "0 auto",
      padding: "0 16px",
      display: "flex",
      flexDirection: isMobile ? "column" : "row",
    },
    listButton: {
      borderTop: isMobile ? "1px solid #cfd1d2" : "",
      padding: "16px",
      "&:focus": {
        outline: "4px solid #2491ff",
        background: "none",
      },
      "&:hover": { color: "#005288", background: "none" },
    },
    link: {
      fontSize: "16px",
      color: "#002b47",
      fontWeight: _theme.typography.fontWeightBold,
      "&:hover": { color: "#005288" },
    },
  }),
);

const InternalLinkRow = ({ isMobile }: SharedLayoutProps) => {
  const { classes } = useStyles({ isMobile });

  return (
    <nav style={{ backgroundColor: "#edeeee" }}>
      <List disablePadding className={classes.container}>
        {internalRowLinks.map((link) => (
          <ListItem
            key={link.name}
            disablePadding
            sx={{ width: isMobile ? "100%" : "fit-content" }}
          >
            <ListItemButton
              className={classes.listButton}
              component="a"
              href={link.url()}
            >
              <ListItemText
                sx={{ margin: 0 }}
                primary={
                  <Typography className={classes.link}>{link.name}</Typography>
                }
              />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </nav>
  );
};

export default InternalLinkRow;
