import {
  Button,
  FormControlSpacer,
  RadioButtons,
  TextInput,
  Typography,
} from "myuscis-material";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "../../redux/store";
import { useEffect, useState } from "react";
import { setFormSpecificInfo } from "../../redux/submissionSlice";
import { SubmissionService } from "../../api/SubmissionService";
import USCISDivider from "../shared/USCISDivider";
import { I140PetitionTypes, I140ScheduleAPetitionType, I140ScheduleAPetitionTypeList } from "../../types/I140Types";
import { setIsPollingForEvidenceValidation } from "../../redux/validationsSlice";

type regexAndError = {
  pattern: RegExp,
  error: string,
}

const PETITION_TYPE_REGEX: Record<I140ScheduleAPetitionType, regexAndError> = {
  [I140PetitionTypes.MEMBER_OF_PROFESSIONS] : {pattern: /^G-(?:100|200|300|400)-\d{5}-\d{6}$/, error: "Invalid Format. Example: G-100-24365-001234"},
  [I140PetitionTypes.PROFESSIONAL] : {pattern: /^G-(?:100|200|300|400)-\d{5}-\d{6}$/, error: "Invalid Format. Example: G-100-24365-001234"},
  [I140PetitionTypes.SKILLED_WORKER] : {pattern: /^G-(?:100|200|300|400)-\d{5}-\d{6}$/, error: "Invalid Format. Example: G-100-24365-001234"},
}


const I140ScheduleARadioButtons = () => {
  const {
    formType,
    submissionId,
    formSpecificInfo,
    eligibilityCategory: eligibilityType,
    evidences,
  } = useSelector((state: RootState) => state.submission);
  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);

  const dispatch = useAppDispatch();

  const [isScheduleAState, setIsScheduleAState] = useState<boolean>(!!formSpecificInfo?.isScheduleA)
  const [dolNumber, setDolNumber] = useState<string>(formSpecificInfo?.dolNumber ?? "")
  const [errorMessage, setErrorMessage] = useState<string>("")
  const [isLocked, setIsLocked] = useState<boolean>(dolNumber !== "");
  const [submitting, setSubmitting] = useState(false);

  const inputDisabled = submitting || isLocked;

  useEffect(() => {
    const ready = !isScheduleAState && !!formSpecificInfo?.dolNumber && inputDisabled;
  }, [formSpecificInfo?.dolNumber, isScheduleAState, inputDisabled]);


  const handleScheduleASelections = async (isScheduleA: boolean) => {
    handleI140FormSpecificForm(isScheduleA, "");
    setErrorMessage("");
    setDolNumber("");

  }

  const handleDolNumberInput = async (isScheduleA: boolean, dolInput: string) => {
    if (!isValidDolNumberFormat(eligibilityType, dolInput)) return;
    handleI140FormSpecificForm(isScheduleA, dolInput);
  }

  const handleI140FormSpecificForm = async (isScheduleA: boolean, dolInput: string) => {
    setSubmitting(true);
    try {
      await SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        {
          formType,
          isScheduleA,
          dolNumber: dolInput
        },
        userGroupId,
      );

      dispatch(setFormSpecificInfo({
        formType,
        isScheduleA,
        dolNumber: dolInput
      }))
      setIsScheduleAState(isScheduleA);
      setIsLocked(dolInput !== "" ? true : false);
      var evidenceFinalDetermination = "labor-certification"
      if (evidences.some(el => el.evidenceGroup === evidenceFinalDetermination)) {
        dispatch(setIsPollingForEvidenceValidation(true))
      }

    } catch (error) {
      console.error(error);
    } finally {
      setSubmitting(false);
    }
  }

  const isValidDolNumberFormat = (eligibilityType: string, input: string): boolean => {
    const re = PETITION_TYPE_REGEX[eligibilityType as I140ScheduleAPetitionType];
    re.pattern.test(input.trim());

    if(re.pattern.test(input.trim())) {
      setErrorMessage("");
      return true;
    }

    setErrorMessage(re.error);
    return false;

  }

  return (
    <>
      {I140ScheduleAPetitionTypeList.includes(eligibilityType) &&
        <div>
          <USCISDivider/>
          <Typography variant="h4">
            Has the 2.b. field For the Schedule A, Group I or II designation been checked on your I-140 form?
          </Typography>
            <RadioButtons
              onChange={(event, value) => handleScheduleASelections(value === "true")}
              name={"name"}
              value={isScheduleAState}
              options={[
                {
                  value: false,
                  label: "No",
                },
                {
                  value: true,
                  label: "Yes",
                }
              ]}
            />

          {!isScheduleAState &&
            <FormControlSpacer columns={1}>
              <TextInput
              id={"id"}
              label="DOL Number"
              maxLength={20}
              style={{paddingTop: "30px"}}
              disabled={inputDisabled}
              type="text"
              required
              errorMessage={errorMessage}
              error={!!errorMessage}
              onChange={(event) => {
                setDolNumber(event.target.value.replace(/\s+/g, ""))
              }}
              value={dolNumber}
              />

             {!isLocked ? <Button
              style={{ visibility: isLocked ? "hidden" : "visible", position: "relative", marginBlockStart: "2rem" }}
              variant="contained"
              size="small"
              role="button"
              aria-label="Add DOL Number"
              type="submit"
              onClick={() => handleDolNumberInput(isScheduleAState, dolNumber)}
            >
              Add DOL Number
            </Button> : <Button
              style={{ visibility: isLocked ? "visible" : "hidden", position: "relative", marginBlockStart: "2rem" }}
              variant="contained"
              size="small"
              role="button"
              aria-label="Edit DOL Number"
              type="submit"
              onClick={() => {
                setIsLocked(false);
              }}
            >
              Edit DOL Number
            </Button> }

            </FormControlSpacer>
          }
        </div>
      }
    </>

  );
};

export default I140ScheduleARadioButtons;
