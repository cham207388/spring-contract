import { makeStyles } from "tss-react/mui";

const useStyles = makeStyles<{ }>()(
  ( _theme ) => ({
    skipLink: {
      top: "auto",
      "& a": {
        backgroundColor: _theme.palette.background.default,
        fontWeight: _theme.typography.fontWeightRegular,
        color: _theme.palette.primary.dark,
        margin: "10px",
        padding: "10px",
        fontSize: "18px",
        lineHeight: "24px",
        position: "absolute",
        left: "-10000px",
        textDecoration: "underline",
        "&:focus": {
          left: "auto",
          zIndex: 90000
        }
      }
    }
  }),
);

type props = {
  label: string
  hrefTarget: string
};

const SkipToContentButton = ({ label, hrefTarget }: props) => {
  const { classes } = useStyles({});
  return (
      <span
        className={classes.skipLink}
      >
        <a href={hrefTarget}  >{label}</a>
      </span>
  );
};

export default SkipToContentButton;
