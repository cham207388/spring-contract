import { DocRenderer } from "react-doc-viewer";
import { IMainState } from "react-doc-viewer/build/state/reducer";
import { makeStyles } from "tss-react/mui";
import { SubmissionService } from "../api/SubmissionService";
import { useEffect, useState } from "react";

const useStyles = makeStyles()({
  iframe: {
    height: "60vh",
    minWidth: "80vw",
  },
});

type Props = {
  mainState: IMainState;
};

const CustomPDFRenderer: DocRenderer = ({
  mainState: { currentDocument },
}: Props) => {
  const { classes } = useStyles();
  const [blob, setBlob] = useState<Blob>();

  useEffect(() => {
    if (currentDocument) {
      SubmissionService.downloadForm(
        currentDocument.uri.replace("/pdf-intake/", ""),
      ).then((bytes) =>
        setBlob(new Blob([bytes], { type: "application/pdf" })),
      );
    }
  }, [currentDocument]);

  return (
    <div id="my-pdf-renderer">
      {blob && (
        <iframe
          className={classes.iframe}
          title="pdf-doc"
          src={URL.createObjectURL(blob)}
        ></iframe>
      )}
    </div>
  );
};

CustomPDFRenderer.fileTypes = ["pdf", "application/pdf"];
CustomPDFRenderer.weight = 1;

export default CustomPDFRenderer;
