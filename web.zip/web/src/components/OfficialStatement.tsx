import { Accordion } from "myuscis-material";
import { makeStyles } from "tss-react/mui";

const useStyles = makeStyles()((theme) => ({
  accordion: {
    backgroundColor: "transparent",
    boxShadow: "none",
    font: "normal normal normal 18px SourceSansProRegular,Source Sans Pro,sans-serif",
    color: "#444444",
    "& .MuiAccordionSummary-content": {
      "&:hover": {
        textDecoration: "underline",
      },
      "&.Mui-expanded": {
        marginLeft: "-4px",
      },
    },
    "& .MuiAccordionDetails-root": {
      lineHeight: "18px",
      gap: "16px",
      flexDirection: "column",
      padding: theme.spacing(1, 0, 1, 4),
      color: "#444444",
    },
  },
  paragraph: {
    whiteSpace: "pre-line",
  },
}));

interface OfficialStatementType {
  title: string;
  body: string;
  url?: string;
}

interface OfficialStatementList {
  items: OfficialStatementType[];
}

const OfficialStatement = () => {
  const statementTypes: OfficialStatementList = {
    items: [
      {
        title: "Religious record",
        body: "Upload a copy or image of the document bearing the seal of the religious organization showing that the baptism, dedication, or comparable rite occurred within two months after birth, and showing the date and place of the child's birth, date of the religious ceremony, and the names of the parents.",
      },
      {
        title: "School record",
        body: "Upload a copy or image of an official letter from school authorities of the school attended showing the date of admission to the school, the child's date of birth or age at that time, place of birth, and names of the parents.",
      },
      {
        title: "Census records",
        body: "Upload a copy or image of State or Federal census records showing the names, place of birth, date of birth, or the age of the person listed.",
      },
      {
        title: "Written statements",
        body: 'If religious, school, or census records are not available, then you may submit two or more written statements from individuals who were living at the time and who have personal knowledge of the event you are trying to prove, such as the date and place of birth, marriage, or death. The individuals making the written statements do not have to be U.S. citizens.\n\nEach written statement must contain the following information regarding the individual making the written statement: his or her full name, address, date and place of birth, full information concerning the event, and complete details explaining how the individual acquired personal knowledge of the event.\n\nEach individual\'s written statement must include the following declaration:\n\n"I declare (or certify, verify, or state) under penalty of perjury under the laws of the United States of America that the foregoing is true and correct. Executed on [date], [signature]."',
      },
      {
        title: "DNA test results",
        body: "If other forms of evidence have proven inconclusive, the petitioner may submit on a voluntary basis other evidence of a birth parent and birth child relationship to include deoxyribonucleic acid (DNA) testing. DNA test results will only be accepted by USCIS from parentage-testing laboratories accredited by the American Association of Blood Banks (AABB). A list of laboratories can be viewed ",
        url: "https://www.aabb.org/sa/facilities/pages/RTestAccrFac.aspx",
      },
    ],
  };

  const { classes } = useStyles();
  return (
    <div>
      {statementTypes.items.map((item) => {
        return (
          <Accordion
            key={item.title}
            square
            accordionTitle={item.title}
            className={`${classes.accordion}`}
          >
            <p className={`${classes.paragraph}`}>
              {item.body}
              {item.url && <a href={item.url}>here.</a>}
            </p>
          </Accordion>
        );
      })}
    </div>
  );
};

export default OfficialStatement;
