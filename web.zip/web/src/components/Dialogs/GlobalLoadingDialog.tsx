import { CircularProgress } from "@mui/material";
import { Dialog, Typography } from "myuscis-material";
import { makeStyles } from "tss-react/mui";

import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import logoSmall from "../shared/logo-no-text.svg";

const useStyles = makeStyles()({
  dialog: {
    height: "30vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-evenly",
    padding: "16px",
    backgroundImage: `url(${logoSmall})`,
    backgroundPosition: "bottom -220px right -190px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "400px",
  },
  leftAligned: {
    height: "50%",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-evenly",
  },
  centered: {
    height: "50%",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-evenly",
  },
  subsectionHeading: {
    fontSize: "24px",
  },
});

const GlobalLoadingDialog = ({
  loaderOptions,
}: {
  loaderOptions?: { title: string; message: string; isLoading: boolean };
}) => {
  const { classes } = useStyles();
  const { isLoading, title, message } = useSelector<RootState>(
    (state) => state.loader,
  ) as RootState["loader"];

  const propTitle = loaderOptions?.title || title;
  const propMessage = loaderOptions?.message || message;
  const propIsLoading = loaderOptions?.isLoading || isLoading;

  return (
    <Dialog
      open={propIsLoading}
      disableEscapeKeyDown

    >
      <div className={classes.dialog}>
        <div className={classes.leftAligned}>
          <Typography className={classes.subsectionHeading}>
            {propTitle || "Processing"}
          </Typography>
          <Typography>
            {propMessage ||
              "Your request is being processed. Please wait and do not refresh the page."}
          </Typography>
        </div>
        <div className={classes.centered}>
          <CircularProgress />
        </div>
      </div>
    </Dialog>
  );
};

export default GlobalLoadingDialog;
