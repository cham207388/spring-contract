import { Button, Dialog } from "myuscis-material";
import { DialogActions } from "@mui/material";
import { makeStyles } from "tss-react/mui";
import DocViewer, {
  PNGRenderer,
  JPGRenderer,
  TIFFRenderer,
} from "react-doc-viewer";
import CustomPDFRenderer from "../CustomPDFRenderer";

const useStyles = makeStyles()({
  dialog: {
    minHeight: "50vh",
    minWidth: "50vw",
    maxWidth: "80vw",
    margin: "0 20px 0 20px",
  },
});

type FileViewerDialogProps = {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  uri: string;
};

const FileViewerDialog = ({
  isOpen,
  setIsOpen,
  uri,
}: FileViewerDialogProps) => {
  const { classes } = useStyles();
  const docs = [{ uri }];

  return (
    <Dialog maxWidth={false} open={isOpen} onClose={() => setIsOpen(false)}>
      <div className={classes.dialog}>
        <DocViewer
          pluginRenderers={[
            CustomPDFRenderer,
            PNGRenderer,
            JPGRenderer,
            TIFFRenderer,
          ]}
          documents={docs}
        />
      </div>
      <DialogActions>
        <Button
          style={{ margin: "10px" }}
          onClick={() => setIsOpen(false)}
          variant={"contained"}
        >
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FileViewerDialog;
