import { RootState } from "../../redux/store";
import { setShowLogoutConfirmationDialog } from "../../redux/userSlice";
import { DialogActions, DialogContent, DialogContentText } from "@mui/material";
import { Button, Dialog } from "myuscis-material";
import { useCookies } from "react-cookie";
import { useDispatch, useSelector } from "react-redux";

export const LogoutDialog = () => {
  const [cookies] = useCookies(["XSRF-TOKEN"]);

  const dispatch = useDispatch();

  const { showLogoutConfirmationDialog } = useSelector(
    (state: RootState) => state.user,
  );

  const close = () => {
    dispatch(setShowLogoutConfirmationDialog(false));
  };

  return (
    <Dialog
      open={showLogoutConfirmationDialog}
      onClose={close}
      fullWidth={false}
      maxWidth="xs"
    >
      <DialogContent>
        <DialogContentText>Are you sure you want to logout?</DialogContentText>
        <DialogActions sx={{ justifyContent: "center" }}>
          <form method="post" action="/pdf-intake/logout">
            <input type="hidden" name="_csrf" value={cookies["XSRF-TOKEN"]} />
            <Button variant="contained" type="submit">
              Sign out
            </Button>
          </form>
          <Button variant="outlined" onClick={close}>
            Close
          </Button>
        </DialogActions>
      </DialogContent>
    </Dialog>
  );
};
