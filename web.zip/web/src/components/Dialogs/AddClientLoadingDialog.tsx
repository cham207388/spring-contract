import { CircularProgress } from "@mui/material";
import { Dialog, Typography } from "myuscis-material";
import { makeStyles } from "tss-react/mui";

import logoSmall from "../shared/logo-no-text.svg";

const useStyles = makeStyles()({
  dialog: {
    height: "30vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-evenly",
    padding: "16px",
    backgroundImage: `url(${logoSmall})`,
    backgroundPosition: "bottom -220px right -190px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "400px",
  },
  leftAligned: {
    height: "50%",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-evenly",
  },
  centered: {
    height: "50%",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-evenly",
  },
  subsectionHeading: {
    fontSize: "24px",
  },
});

const AddClientLoadingDialog = ({ loading }: { loading: boolean }) => {
  const { classes } = useStyles();

  return (
    <Dialog open={loading}>
      <div className={classes.dialog}>
        <div className={classes.leftAligned}>
          <Typography className={classes.subsectionHeading}>
            Adding Client
          </Typography>
          <Typography>
            We are attempting to add your client. This may take a few minutes.
            Please do not leave or refresh this page.
          </Typography>
        </div>
        <div className={classes.centered}>
          <CircularProgress />
        </div>
      </div>
    </Dialog>
  );
};

export default AddClientLoadingDialog;
