import { CircularProgress } from "@mui/material";
import { Dialog, Typography } from "myuscis-material";
import { makeStyles } from "tss-react/mui";

import { ReactElement } from "react";
import { Step, Steps } from "../../hooks/useSteps";
import logoSmall from "../shared/logo-no-text.svg";

const useStyles = makeStyles()({
  dialog: {
    height: "30vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-evenly",
    padding: "16px",
    backgroundImage: `url(${logoSmall})`,
    backgroundPosition: "bottom -220px right -190px",
    backgroundRepeat: "no-repeat",
    backgroundSize: "400px",
  },
  dialogHeaderMessage: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    paddingBottom: "2em",
  },
  leftAligned: {
    height: "50%",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-evenly",
  },
  centered: {
    height: "60%",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-evenly",
  },
  subsectionHeading: {
    fontSize: "24px",
  },
});

type UploadingDialogProps = {
  loading: boolean;
  setLoading: (loading: boolean) => void;
  currentStep: Step;
  forPayment?: boolean;
  dialogHeader?: ReactElement;
  showCancelButton?: boolean;
};

const UploadingDialog = ({
  loading,
  currentStep,
  forPayment,
  dialogHeader,
}: UploadingDialogProps) => {
  const { classes } = useStyles();
  return (
    <Dialog
      open={loading}
      disableAutoFocus={true}
      disableEnforceFocus={true}
      disableRestoreFocus={true}
      role="alert"
      aria-live="assertive"
    >
      <div className={classes.dialog}>
        <div className={classes.dialogHeaderMessage}>{dialogHeader}</div>
        <div className={classes.leftAligned}>
          <Typography className={classes.subsectionHeading}>
            Processing{" "}
            {currentStep.id === Steps.UploadPDF.id
              ? `PDF Import`
              : currentStep.id === Steps.PayAndSubmit.id
                ? forPayment
                  ? "Fee Authorization for Submission"
                  : "Submission"
                : currentStep.name + " Import"}
          </Typography>
          <Typography>
            {currentStep.id === Steps.UploadPDF.id
              ? "We are verifying the PDF is valid and matches all requirements. This may take a few minutes. "
              : currentStep.id === Steps.PayAndSubmit.id
                ? forPayment
                  ? "You will be redirected to authorize payment. "
                  : "We are validating your submission. This may take a few minutes. "
                : `We are verifying the ${currentStep.name} is
            valid and matches all requirements. This may take a few minutes. `}
            Please do not leave or refresh this page.
          </Typography>
        </div>
        <div className={classes.centered}>
          <CircularProgress size={"4rem"} />
        </div>
      </div>
    </Dialog>
  );
};

export default UploadingDialog;
