import {
  Alert,
  AlertActions,
  AlertDescription,
  AlertHeader,
  Button,
  Dialog,
  Grid,
  Typography,
} from "myuscis-material";
import useModalFocusReturn from "../../hooks/useModalFocusReturn";

type Props = {
  isDialogOpen: boolean;
  handleDialogClose: () => void;
  handleDelete: () => void;
  header?: string;
  deleteWarningText?: string;
  deleteBody?: string;
  focusReturnFallbackElementRef: React.RefObject<HTMLElement|null>;
};

export const DeleteDialogConfirmation = ({
  isDialogOpen,
  handleDialogClose,
  handleDelete,
  header = "Are you sure you want to delete this?",
  deleteWarningText,
  deleteBody = "You cannot undo this action.",
  focusReturnFallbackElementRef
}: Props) => {
  // We should make this properly composable when we have copy updates for evidence/fee waiver
  const isFormDelete = deleteBody?.toLowerCase().includes("continue");
  useModalFocusReturn(isDialogOpen, focusReturnFallbackElementRef);
  return (
    <div role="alert" aria-live="assertive">
      <Dialog
        open={isDialogOpen}
        onClose={handleDialogClose}
        fullWidth={false}
        maxWidth="xs"
        disableRestoreFocus={true}
      >
        <Alert variant="warning">
          <AlertHeader>
            <Typography variant="h4">{header}</Typography>
            <Typography variant="h4">
              {isFormDelete ? null : deleteWarningText}
            </Typography>
          </AlertHeader>
          <AlertDescription>
            <Typography variant="subtitle1">{deleteBody}</Typography>
          </AlertDescription>
          <AlertActions>
            <Grid item>
              <Button variant="contained" onClick={handleDelete}>
                Delete
              </Button>
            </Grid>
            <Grid item>
              <Button variant="text" onClick={handleDialogClose}>
                {isFormDelete ? "Continue" : "Cancel"}
              </Button>
            </Grid>
          </AlertActions>
        </Alert>
      </Dialog>
    </div>
  );
};
