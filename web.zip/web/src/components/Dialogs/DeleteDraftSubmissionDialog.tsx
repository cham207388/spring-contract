import {
  Alert,
  AlertActions,
  AlertHeader,
  Button,
  Dialog,
  Grid,
  Typography,
} from "myuscis-material";

type Props = {
  isDialogOpen: boolean;
  handleDialogClose: () => void;
  handleDelete: () => any;
};

export const DeleteDraftSubmissionDialog = ({
  isDialogOpen,
  handleDialogClose,
  handleDelete,
}: Props) => {
  return (
    <div role="alert" aria-live="assertive">
      <Dialog open={isDialogOpen} onClose={handleDialogClose} fullWidth={false}>
        <Alert variant="information">
          <AlertHeader>
            <Typography variant="h4" style={{ marginBottom: "8px" }}>
              Are you sure you want to delete this case?
            </Typography>
          </AlertHeader>
          <AlertActions>
            <Grid
              container
              item
              xs={12}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-around",
              }}
            >
              <Grid item xs={6}>
                <Button variant="contained" onClick={handleDelete}>
                  Yes, delete this case
                </Button>
              </Grid>
              <Grid item xs={6}>
                <Button variant="text" onClick={handleDialogClose}>
                  No, keep this case
                </Button>
              </Grid>
            </Grid>
          </AlertActions>
        </Alert>
      </Dialog>
    </div>
  );
};
