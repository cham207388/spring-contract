import { PropsWithChildren } from "react";
import { AlertVariant, Dialog } from "myuscis-material";
import { makeStyles } from "tss-react/mui";

import AlertWindow from "../shared/AlertWindow";
import { SxProps } from "@mui/material";

const useStyles = makeStyles()({
  dialog: {
    margin: "0px",
  },
});

type AlertDialogProps = {
  showDialog: boolean;
  setShowDialog: (showDialog: boolean) => void;
  headerText?: string;
  variant?: AlertVariant;
  sx?: SxProps;
};

const AlertDialog = ({
  showDialog,
  setShowDialog,
  headerText,
  children,
  variant,
  sx,
}: PropsWithChildren<AlertDialogProps>) => {
  const { classes } = useStyles();

  return (
    <div role="alert" aria-live="assertive">
      <Dialog
        open={showDialog}
        className={classes.dialog}
        sx={sx}
        onClose={() => setShowDialog(false)}
      >
        <AlertWindow
          variant={variant || "warning"}
          headerText={headerText}
          isDialog={true}
        >
          {children}
        </AlertWindow>
      </Dialog>
    </div>
  );
};

export default AlertDialog;
