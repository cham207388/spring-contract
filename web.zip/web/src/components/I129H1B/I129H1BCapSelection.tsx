import { makeStyles } from "tss-react/mui";
import { RootState, useAppDispatch } from "../../redux/store";
import { Typography } from "myuscis-material";
import YesNoChoiceComponent from "../YesNoChoice";
import { useId } from "react";
import { useSelector } from "react-redux";
import USCISDivider from "../shared/USCISDivider";
import { SubmissionService } from "../../api/SubmissionService";
import { setFormSpecificInfo } from "../../redux/submissionSlice";

const useStyles = makeStyles()({
  dropdown: {
    margin: "2px 0",
  },
  mobileDropdown: {
    margin: "0 24px",
  },
  alertModalParagraph: {
    marginTop: "1rem",
  },
  alertModalButtons: {
    display: "flex",
    marginTop: "2rem",
    alignContent: "center",
  },
  textInputLabel: {
    display: "flex",
    flexDirection: "column-reverse",
    marginTop: "32px",
  },
  questionTextLabel: {
    fontWeight: "bold",
    lineHeight: "1.15",
    color: "black"
  },
});

const I129H1BCapSelection = () => {

  const {
    submissionId,
    formType,
    formSpecificInfo
  } = useSelector((state: RootState) => state.submission);

  const dispatch = useAppDispatch();
  const { myUscisId } = useSelector((state: RootState) => state.user)

  const isH1BCapEnabledId = useId();
  const isH1BCapGapId = useId();
  const { classes } = useStyles();

  const handleIsCap = async (key: string, value: boolean) => {
      const updatedFormSpecificInfo = { ...formSpecificInfo, [key]: value, formType };

    try {
      await SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        updatedFormSpecificInfo,
      );

      dispatch(setFormSpecificInfo(updatedFormSpecificInfo))
    } catch (error) {
      console.error(error)
    }
  };

  return (
    <div style={{ margin: "2rem 0 3rem 0" }}>
      <USCISDivider/>
      <div>
        <Typography variant="h6" className={classes.questionTextLabel}>
          Is this petition subject to the congressionally mandated annual numerical limit (cap) or 20,000 petition exemption based on the beneficiary's attainment of a master's degree or higher from a U.S. institution of higher education (master's cap)?*
        </Typography>
        <Typography variant="body1" fontWeight={"normal"} style={{marginTop: "1rem"}}>
          The numerical limitation is commonly known as the "regular cap" and the 20,000 petition exemption based on the beneficiary's attainment of a master's degree or higher from a U.S. institution of higher education is commonly referred to as the "master's cap" or "advanced degree exemption."
        </Typography>
        <YesNoChoiceComponent
          direction="column"
          radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
          radioLabelId={isH1BCapEnabledId}
          classes={classes}
          choiceText=""
          label={["Yes", "No"]}
          choiceTextVariant="h5"
          alignment={"flex-start"}
          value={formSpecificInfo?.isCapEnabled ? "Yes" : "No"}
          handleOnChange={(event) =>
            handleIsCap("isCapEnabled", event.target.value === "Yes")
          }
        />
      </div>
      <div style={{marginTop: "2rem"}}>
        <Typography variant="h6" className={classes.questionTextLabel}>
          If you are filing a cap-gap petition, indicate whether the beneficiary is eligible for cap-gap by making a selection below.*
        </Typography>
        <YesNoChoiceComponent
          direction="column"
          radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
          radioLabelId={isH1BCapGapId}
          classes={classes}
          choiceText=""
          label={["Yes", "No"]}
          choiceTextVariant="h5"
          alignment={"flex-start"}
          value={formSpecificInfo?.isCapGap ? "Yes" : "No"}
          handleOnChange={(event) =>
            handleIsCap("isCapGap", event.target.value === "Yes")
          }
        />
      </div>
    </div>
  )
}
export default I129H1BCapSelection;