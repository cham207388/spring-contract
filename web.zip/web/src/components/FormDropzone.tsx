import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { faSpinner, faTrashCan } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  Alert,
  AlertActions,
  AlertDescription,
  AlertHeader,
  Box,
  Button,
  Grid,
  MaterialTable,
} from "myuscis-material";
import { useCallback, useContext, useMemo, useRef, useState } from "react";
import { useDropzone } from "react-dropzone";
import { useDispatch, useSelector } from "react-redux";
import { SubmissionService } from "../api/SubmissionService";
import { DocumentUploadContext } from "../contexts/DocumentUploadContext";
import { useUploadDocument } from "../hooks/documentUpload";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";
import { useHydrateDraft } from "../hooks/useHydrateDraft";
import { useValidations } from "../hooks/useValidations";
import { RootState } from "../redux/store";
import {
  resetFormUpload,
  setFormHasError,
  setFormHasWarnings,
  setForms,
  setFormUpload,
  setIsFeeExempt,
  setIsNotFeeExempt
} from "../redux/submissionSlice";

import {
  deleteFormValidation,
  setIsPollingForFormValidation,
} from "../redux/validationsSlice";

import Markdown from "react-markdown";
import { selectIsRepresentative } from "../redux/userSlice";
import {
  FormRequest,
  FormUploadResponse,
  UploadRequest,
} from "../types/Upload";
import {
  VALIDATION_STATUS,
  ValidationDetails,
  ValidationResults,
  Validators,
} from "../types/Validations";
import { getDateFromNanoSeconds } from "../utils/dates";
import { fileNameValidator } from "../utils/fileNameValidator";
import { formatFileName } from "../utils/formatFileName";
import { DeleteDialogConfirmation } from "./Dialogs/DeleteConfirmationDialog";
import FileErrorAlert from "./FileErrorAlert";
import { ValidationStatusIndicator } from "./ValidationStatusIndicator";
import AlertWindow from "./shared/AlertWindow";
import { Submission } from "../types/Submission";
import { Form } from "../redux/types/Submission";

const baseStyle = {
  flex: 1,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "20px",
  borderWidth: 2,
  borderRadius: 2,
  borderColor: "#eeeeee",
  borderStyle: "dashed",
  backgroundColor: "#fafafa",
  color: "#666666",
  outline: "none",
  transition: "border .24s ease-in-out",
  marginBottom: "32px",
};

const focusedStyle = {
  borderColor: "#2196f3",
};

const acceptStyle = {
  borderColor: "#00e676",
};

const rejectStyle = {
  borderColor: "#ff1744",
};

const linkText = {
  color: "#006699",
  textDecoration: "underline",
  cursor: "pointer",
};

type DocumentDropzoneProps = {
  formType: string;
};

function renderEligibilityCategoryWarning(validation: ValidationDetails) {
  return (
    <span>
      Eligibility category on your form ({validation.warnings?.categoryOnForm})
      is not the Eligibility category you have selected to apply for (
      {validation.warnings?.categoryOnSubmission}). Please update your selection
      in order to provide the proper supporting documents for your application.
    </span>
  );
}

const FormDropzone = ({ formType }: DocumentDropzoneProps) => {
  const { uploadDocument } = useUploadDocument();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [showValidationAlert, setShowValidationAlert] = useState(true);
  const [errors, setErrors] = useState<string[]>([]);
  const { addAlert } = useAlertSnackbar();
  const { getValidationForFormType } = useValidations();

  const isReuploading = useRef(false);
  const { setLoading } = useContext(DocumentUploadContext);
  const { hydrateDraft } = useHydrateDraft();

  const dispatch = useDispatch();
  const { formMetadata } = useSelector(
    (state: RootState) => state.formMetadata,
  );
  const {
    forms,
    submissionId,
    isNotFeeExempt,
    isFeeExempt,
    eligibilityCategory,
    eligibilitySubcategory,
    formType: formTypeFromSubmission,
  } = useSelector((state: RootState) => state.submission);

  const { isPollingForFormValidation, isPollingForValidationTimedOut } =
    useSelector((state: RootState) => state.validations);

  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);
  const isApplicationByRepresentative = useSelector(selectIsRepresentative);
  if(isApplicationByRepresentative && !forms?.some((form) => form.formType === "G-28")) {
    const newForm: Form = {
      formType: "G-28",
      formId: "",
      fileName: undefined,
      dateTime: "",
      eligibilityCategory: "",
      eligibilitySubcategory: "",
      eligibilitySubcategoryList: [],
      benefitTypeCode: 0,
      applicationReasonCode: 0
    };
    const updatedForms = [...forms, newForm]
    dispatch(setForms(updatedForms));
  }
  const formState = forms?.find((form) => form.formType === formType);
  const formValidationState = getValidationForFormType(formType);

  const formHasError =
    formValidationState?.details.some(
      (validation) =>
        (validation.validator === Validators.CORE ||
          validation.validator === Validators.ELIGIBILITY_CATEGORY ||
          validation.validator === Validators.REASON_FOR_FILING ||
          validation.validator === Validators.PERSON ||
          validation.validator === Validators.PFVS ||
          (validation.validator === Validators.SIGNATURE &&
            isApplicationByRepresentative) ||
          validation.validator === Validators.G28_NAME_EMAIL ||
          validation.validator === Validators.ADDRESS ||
          validation.validator === Validators.G28_ATTORNEY_NAME ||
          ((validation.validator === Validators.G28_COMP ||
            validation.validator === Validators.G28_COMP_NAME) &&
            isApplicationByRepresentative)) &&
        validation.result === ValidationResults.FAIL,
    ) || false;

  const formHasWarnings =
    formValidationState?.details.some(
      (validation) => validation.result === ValidationResults.WARN,
    ) || false;

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      setErrors([]);
      if (isReuploading.current && formState) {
        const { formId } = formState;
        isReuploading.current = false;

        try {
          const response = await SubmissionService.deleteUploadedForm(
            myUscisId,
            submissionId,
            formId,
            userGroupId,
          );
          dispatch(deleteFormValidation(formState));
          dispatch(resetFormUpload(formState));
          dispatch(setFormHasError(false));
          dispatch(setFormHasWarnings(false));
          dispatch(setIsPollingForFormValidation(false));
          dispatch(setIsNotFeeExempt(false));
          dispatch(setIsFeeExempt(false));

          await hydrateDraft(response);
        } catch (error) {
          return;
        }
      }

      const file = acceptedFiles[0];
      if (!file) {
        setShowValidationAlert(true);
        return;
      }
      setLoading(true);
      const formRequest: FormRequest = {
        fileName: file.name,
        isForm: true,
        type: "FORM",
        formType,
      };
      const formData = new FormData();
      formData.append("file", file);
      formData.append(
        "uploadRequest",
        new Blob([JSON.stringify(formRequest)], { type: "application/json" }),
      );
      const uploadRequest: UploadRequest = {
        formData,
        myUscisId,
        submissionId,
      };

      uploadDocument(uploadRequest, userGroupId)
        .then((res: FormUploadResponse) => {
          setTimeout(() => {
            setLoading(false);
          }, 2000);
          dispatch(setFormUpload({ request: formRequest, response: res }));
          dispatch(setIsPollingForFormValidation(true));
          SubmissionService.getSubmission(
            myUscisId,
            submissionId,
            userGroupId,
          ).then((res: Submission) => {
            hydrateDraft(res);
          });
        })
        .catch((error) => {
          dispatch(setIsPollingForFormValidation(false));
          setLoading(false);
          if (error.response.data.includes("password protected")) {
            setErrors([...errors, "password"]);
          } else if (error.response.data.includes("Not a valid PDF")) {
            setErrors([...errors, "invalid_pdf"]);
          } else if (error.message.includes("401")) {
            addAlert("Upload failed. Please refresh the screen and try again");
          }
          return;
        });
    },
    [
      formState,
      setLoading,
      myUscisId,
      userGroupId,
      formType,
      submissionId,
      uploadDocument,
      dispatch,
      hydrateDraft,
      addAlert,
      isReuploading,
      errors,
    ],
  );

  const accept = {
    "application/pdf": [".pdf"],
  };

  const {
    fileRejections,
    getRootProps,
    getInputProps,
    isFocused,
    isDragAccept,
    isDragReject,
    open,
  } = useDropzone({
    onDrop,
    maxSize: 12000000,
    maxFiles: 1,
    accept,
    validator: fileNameValidator,
  });

  const handleDeleteFile = async () => {
    if (!formState?.formId) {
      return;
    }

    const { formId } = formState!;
    try {
      const response = await SubmissionService.deleteUploadedForm(
        myUscisId,
        submissionId,
        formId,
        userGroupId,
      );
      dispatch(deleteFormValidation(formState));
      dispatch(resetFormUpload(formState));
      dispatch(setFormHasError(false));
      dispatch(setFormHasWarnings(false));
      dispatch(setIsPollingForFormValidation(false));
      dispatch(setIsNotFeeExempt(false));
      dispatch(setIsFeeExempt(false));

      await hydrateDraft(response);
    } catch (error) {
      // no op
    }

    setIsDeleteDialogOpen(false);
  };

  const onOpenDeleteDialog = () => {
    setIsDeleteDialogOpen(true);
  };

  const style = useMemo(
    () => ({
      ...baseStyle,
      ...(isFocused ? focusedStyle : {}),
      ...(isDragAccept ? acceptStyle : {}),
      ...(isDragReject ? rejectStyle : {}),
    }),
    [isFocused, isDragAccept, isDragReject],
  );

  const isFeeWaiverEnabled = () => {
    if(eligibilityCategory !== null && eligibilitySubcategory != null) {
      return formMetadata.eligibilityCategories.find(
        (cat) => cat.category === eligibilityCategory
      )?.metaData.subcategories.find(
        (sub) => sub.category === eligibilitySubcategory
      )?.feeWaivable;
    } else if(eligibilityCategory !== null) {
      return formMetadata.eligibilityCategories.find(
        (cat) => cat.category === eligibilityCategory
      )?.metaData.feeWaivable;
    }
    return formMetadata.feeWaiverEnabled;
  }

  const tableContents =
    formState?.fileName !== undefined && formState?.fileName !== null
      ? [
          <td key={`rc0`}>
            <div
              style={{ width: "100%", display: "flex", alignItems: "center" }}
            >
              {isPollingForFormValidation &&
                formValidationState?.status ===
                  VALIDATION_STATUS.IN_PROGRESS && (
                  <FontAwesomeIcon
                    icon={faSpinner as IconProp}
                    spin
                    style={{
                      marginRight: "5px",
                    }}
                    title={`Checking ${formState.fileName}...`}
                  />
                )}
              {formatFileName(formState.fileName)}
            </div>
          </td>,
          <td key={`rc1`}>Form {formState.formType}</td>,
          <td key={`rc2`}>
            {isPollingForValidationTimedOut ? (
              <span>...</span>
            ) : (
              <ValidationStatusIndicator
                status={formValidationState?.status}
                error={formHasError}
              />
            )}
          </td>,
          <td key={`rc3`}>{getDateFromNanoSeconds(formState?.dateTime)}</td>,
          <td key={`rc4`}>
            <Button
              variant="text"
              startIcon={
                <FontAwesomeIcon
                  style={{ fontSize: "16px", color: "#08588F" }}
                  icon={faTrashCan}
                />
              }
              role="button"
              aria-label="Delete file"
              style={linkText}
              onClick={() => onOpenDeleteDialog()}
            >
              Delete
            </Button>
          </td>,
        ]
      : null;

  const formUploadContainerRef = useRef<HTMLDivElement>(null);

  return (
    <div
      className="container"
      tabIndex={-1}
      ref={formUploadContainerRef}
    >
      {formState?.fileName === undefined || formState?.fileName === null ? (
        <div {...getRootProps({ style, role: "button" })}>
          <input {...getInputProps()} />
          <p>
            <span style={linkText}>Choose</span> or drop file here to upload
          </p>
        </div>
      ) : (
        <MaterialTable
          headerContents={[
            <th style={{ whiteSpace: "nowrap" }} key="header-row-c0">
              File name
            </th>,
            <th key="header-row-c1">Document</th>,
            <th key="header-row-c2">Status</th>,
            <th key="header-row-c3">Date</th>,
            <th key="header-row-c4">Action</th>,
          ]}
          tableContents={[tableContents]}
        />
      )}
      <DeleteDialogConfirmation
        isDialogOpen={isDeleteDialogOpen}
        handleDialogClose={() => setIsDeleteDialogOpen(false)}
        handleDelete={handleDeleteFile}
        header="Are you sure you want to delete this document?"
        deleteBody="Select delete to stop processing your submitted PDF form.  Select Continue to complete processing your PDF submission."
        focusReturnFallbackElementRef={formUploadContainerRef}
      />

      {formValidationState?.status === VALIDATION_STATUS.IN_PROGRESS && !(formState?.fileName === undefined || formState?.fileName === null) && (
        <AlertWindow variant={"information"}>
          Your form is currently being validated for completeness. This process
          may take several minutes. You may continue to the next step. You will
          be notified of the validation progress.
        </AlertWindow>
      )}
      {formValidationState?.status === VALIDATION_STATUS.AWAITING && (
        <AlertWindow variant={"error"}>
          Validations will continue once an accepted{" "}
          {formType !== "G-28" ? "G-28" : formTypeFromSubmission} version is
          uploaded.
        </AlertWindow>
      )}
      {isNotFeeExempt && isFeeWaiverEnabled() && (
        <AlertWindow variant={"warning"}>
          We have determined that your application is NOT Fee Exempt. If you
          would like to request a Fee Waiver, please go to the Inability to
          Pay/Financial Hardship page (under Getting Started) and upload your
          Fee Waiver request or Fee Declaration
        </AlertWindow>
      )}
      {isFeeExempt && (
        <AlertWindow variant={"warning"}>
          We have determined that your application is fee exempt.
        </AlertWindow>
      )}
      {formHasError && (
        <Box
          role="alert"
          aria-live="assertive"
          mt="32px"
          mx="0 auto"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Alert variant="error" maxWidth focus>
            <AlertHeader>Error with uploaded form</AlertHeader>
            <AlertDescription>
              We found the following errors with your uploaded form.
              <br />
              <br />
              {formValidationState?.details
                ?.filter(
                  (validation) =>
                    validation.validator !== Validators.SIGNATURE ||
                    isApplicationByRepresentative,
                )
                .map((validation) =>
                  validation.reasons.map((reason) => (
                    <span
                      key={reason}
                      style={{ display: "block", margin: "12px 0" }}
                    >
                      <Markdown>{reason}</Markdown>
                    </span>
                  )),
                )}
            </AlertDescription>
            <AlertActions>
              <Grid item mt="16px">
                <Button
                  variant="contained"
                  onClick={() => {
                    isReuploading.current = true;
                    open();
                  }}
                >
                  Re-Upload PDF
                </Button>
              </Grid>
            </AlertActions>
          </Alert>
        </Box>
      )}
      {formHasWarnings && (
        <Box
          role="alert"
          aria-live="assertive"
          mt="32px"
          mx="0 auto"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Alert variant="error" maxWidth focus>
            <AlertHeader>Warning</AlertHeader>
            <AlertDescription>
              We found the following potential issues with the uploaded form
              <br />
              <br />
              {formValidationState?.details.map((validation) => {
                if (validation.validator === Validators.ELIGIBILITY_CATEGORY)
                  return renderEligibilityCategoryWarning(validation);
                return null;
              })}
            </AlertDescription>
            <AlertActions>
              <Grid item mt="16px">
                <Button
                  variant="contained"
                  onClick={() => {
                    isReuploading.current = true;
                    open();
                  }}
                >
                  Re-Upload PDF
                </Button>
              </Grid>
            </AlertActions>
          </Alert>
        </Box>
      )}
      {errors.includes("password") && (
        <AlertWindow
          variant={"error"}
          headerText="Your uploaded form cannot be password protected. Upload a document without a password."
        />
      )}
      {errors.includes("invalid_pdf") && (
        <AlertWindow
          variant={"error"}
          headerText="You have uploaded an invalid PDF, please upload a different form."
        />
      )}
      <FileErrorAlert
        fileRejections={fileRejections}
        showAlert={showValidationAlert}
        setShowAlert={setShowValidationAlert}
        acceptedTypes={accept}
      />
    </div>
  );
};

export default FormDropzone;
