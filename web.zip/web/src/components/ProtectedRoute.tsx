import { PropsWithChildren } from "react";
import { Navigate } from "react-router-dom";
import { useSteps } from "../hooks/useSteps";
import { Path, Paths } from "../router/Paths";

interface Props {
  redirectTo?: Path;
}

const ProtectedRoute = ({
  redirectTo = Paths.review,
  children,
}: PropsWithChildren<Props>) => {
  const { stepIsValidTarget } = useSteps();

  return stepIsValidTarget ? (
    <>{children}</>
  ) : (
    <Navigate to={`../${redirectTo}`} />
  );
};

export default ProtectedRoute;
