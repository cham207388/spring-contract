import { useEffect } from "react";

const ExternalRedirect = () => {
  useEffect(() => {
    window.location.replace(window.location.origin);
  }, []);

  return <></>;
};

export default ExternalRedirect;
