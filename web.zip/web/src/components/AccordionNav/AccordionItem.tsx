import React, { useContext, useMemo } from "react";
import { NavLink } from "react-router-dom";
import { Accordion } from "myuscis-material";
import { makeStyles } from "tss-react/mui";
import { AccordionHeaders } from "../../types/Accordion";
import { AccordionContext } from "../../contexts/AccordionContext";
import { Step } from "../../hooks/useSteps";

interface AccordionItemProps {
  name: AccordionHeaders;
  steps: Step[];
  disabled: boolean;
}

const useStyles = makeStyles()((theme) => ({
  accordion: {
    backgroundColor: "transparent",
    boxShadow: "none",
    fontSize: "16px",
    color: theme.palette.primary.dark,
    "& .MuiAccordionSummary-content": {
      "&:hover": { textDecoration: "underline" },
      "&.Mui-expanded": { marginLeft: "-4px" },
    },
    "& .MuiAccordionDetails-root": {
      display: "flex",
      gap: "16px",
      flexDirection: "column",
      padding: theme.spacing(1, 0, 1, 4),
    },
  },
  activeAccordion: {
    fontWeight: theme.typography.fontWeightBold,
    padding: theme.spacing(1, 0),
    backgroundColor: `${theme.palette.background.default} !important`,
    borderLeft: "4px solid rgb(0, 84, 153)",
    marginLeft: "-4px",
  },
  disabledHeader: {
    opacity: 0.45,
    cursor: "not-allowed",
    pointerEvents: "none",
  },
  stepBase: {
    textDecoration: "none",
    color: theme.palette.primary.dark,
    fontWeight: theme.typography.fontWeightRegular,
    display: "flex",
    maxWidth: "fit-content",
    minHeight: "24px",
    marginBottom: "1px",
    "&:focus": { outlineOffset: "1px" },
  },
  stepLink: {
    cursor: "pointer",
    "&:hover": { textDecoration: "underline" },
  },
  stepActive: {
    fontWeight: `${theme.typography.fontWeightBold} !important`,
  },
  stepDisabled: {
    opacity: 0.45,
    cursor: "not-allowed",
  },
}));

const StepLink = ({ step, onNavigate }: { step: Step; onNavigate: () => void }) => {
  const { classes, cx } = useStyles();
  const isDisabled = !!step.disabled;

  if (isDisabled) {
    return (
      <span 
        className={cx(classes.stepBase, classes.stepDisabled)} 
        aria-disabled="true"
      >
        {step.name}
      </span>
    );
  }

  return (
    <NavLink
      to={step.id}
      onClick={onNavigate}
      data-testid="accordion-step-link"
      className={({ isActive }) => 
        cx(classes.stepBase, classes.stepLink, isActive && classes.stepActive)
      }
    >
      {step.name}
    </NavLink>
  );
};

const AccordionItem: React.FC<AccordionItemProps> = ({ name, steps, disabled }) => {
  const { classes, cx } = useStyles();
  const context = useContext(AccordionContext);

  if (!context) {
    throw new Error("AccordionItem must be used within an AccordionProvider");
  }

  const {
    activeAccordionHeader,
    setActiveAccordionHeader,
    setIsMobileAccordionExpanded,
  } = context;

  const visibleSteps = useMemo(() => 
    steps.filter((s) => s.showInNav !== false), 
  [steps]);

  const isExpanded = activeAccordionHeader === name;

  const handleToggle = () => {
    if (disabled) return;
    setActiveAccordionHeader(isExpanded ? null : name);
  };

  return (
    <Accordion
      accordionTitle={name}
      className={cx(
        classes.accordion,
        isExpanded && classes.activeAccordion,
        disabled && classes.disabledHeader
      )}
      expanded={isExpanded}
      square
      toggleExpansion={handleToggle}
    >
      {visibleSteps.map((step) => (
        <StepLink 
          key={step.id} 
          step={step} 
          onNavigate={() => setIsMobileAccordionExpanded(false)} 
        />
      ))}
    </Accordion>
  );
};

export default AccordionItem;
