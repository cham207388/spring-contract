import AccordionNav from "./AccordionNav";
import { AccordionProvider } from "../../contexts/AccordionContext";

const AccordionContainer = () => {
  return (
    <AccordionProvider>
      <AccordionNav />
    </AccordionProvider>
  );
};

export default AccordionContainer;
