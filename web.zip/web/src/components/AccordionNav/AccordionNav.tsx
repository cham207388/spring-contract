import { Stack, Typography } from "@mui/material";
import { Accordion, Box } from "myuscis-material";
import { makeStyles } from "tss-react/mui";
import { RootState } from "../../redux/store";
import { useSelector } from "react-redux";
import AccordionItem from "./AccordionItem";
import { AccordionContext } from "../../contexts/AccordionContext";
import { useContext } from "react";
import { useSteps } from "../../hooks/useSteps";
import SkipToContentButton from "../SkipToContentButton";

const useStyles = makeStyles()((theme) => ({
  header: {
    maxWidth: "217px",
    fontWeight: "bold",
    width: "92%"
  },
  mobileHeader: {
    fontWeight: "bold"
  },
  parentAccordion: {
    backgroundColor: "#F3F3F3",
    boxShadow: "none",
    cursor: "pointer",
    "& > div:nth-of-type(1) .MuiAccordionSummary-expandIconWrapper svg": {
      fontSize: "2.185rem",
    },
  },
  mobileAccordion: {
    backgroundColor: "transparent",
    padding: "16px 0px 16px 0px",
    boxShadow: "rgba(50, 50, 50, 0.17) 0px 0px 8px",
    cursor: "pointer",
    "& > div:nth-of-type(1) .MuiAccordionSummary-expandIconWrapper svg": {
      fontSize: "2.185rem",
    }
  },
  sidebar: {
    backgroundColor: "#F3F3F3",
    boxShadow: "none",
    padding: theme.spacing(1.5, 0, 0, 2),
    maxWidth: "256px",
    [theme.breakpoints.down("md")]: {
      marginRight: "0",
      maxWidth: "unset",
      width: "100%",
      background: "white",
      padding: "0px"
    },
  },
    skipLink: {
      top: "auto",
      "& a": {
        backgroundColor: theme.palette.background.default,
        fontWeight: theme.typography.fontWeightRegular,
        color: theme.palette.primary.dark,
        margin: "10px",
        padding: "10px",
        fontSize: "18px",
        lineHeight: "24px",
        position: "absolute",
        left: "-10000px",
        textDecoration: "underline",
        "&:focus": {
          left: "auto",
          zIndex: 90000
        }
      }
    }
}));

const AccordionNav = () => {
  const { classes } = useStyles();

  const { formMetadata } = useSelector(
    (state: RootState) => state.formMetadata,
  );

  const { isMobile, isMobileAccordionExpanded, setIsMobileAccordionExpanded } =
    useContext(AccordionContext);

  const { mapHeadersToAccordionSteps } = useSteps();

  const items = mapHeadersToAccordionSteps.map(({ label, group, disabled }) => (
    <AccordionItem key={label} disabled ={disabled} name={label} steps={group} />
  ));

  const MobileAccordion = (
    <Accordion
      square
      className={classes.mobileAccordion}
      expanded={isMobileAccordionExpanded}
      toggleExpansion={() => setIsMobileAccordionExpanded((prev) => !prev)}
      accordionTitle={
        <Typography variant="h2" className={classes.mobileHeader}>{`${formMetadata.formType}, ${formMetadata.formDescription}`}</Typography>
      }
    >
      {items}
    </Accordion>
  );

  const DesktopAccordion = (
    <>
      <Stack pl="20px" mt={4}>
        <Typography variant="h4" className={classes.header}>
          {`${formMetadata.formType}, ${formMetadata.formDescription}`}
        </Typography>
        <Box
          sx={{
            width: "92%",
            borderBottom: "3px solid #EBEBEB",
          }}
          my={2}
        />
      </Stack>
      {items}
    </>
  );

  return (
    <Box className={classes.sidebar}>
      <SkipToContentButton label="Skip to main content" hrefTarget="#maincontent"/>
      {isMobile ? MobileAccordion : DesktopAccordion}
    </Box>
  );
};

export default AccordionNav;
