import { SxProps, Typography } from "@mui/material";
import { AlertDescription, Button } from "myuscis-material";
import AlertDialog from "./Dialogs/AlertDialog";

const sx: SxProps = {
  "& .MuiDialog-container": {
    alignItems: "flex-start",
  },
};

const ClientInformationAlertSnackbar = ({
  showAlert,
  dismiss,
  isSuccess,
  message,
}: {
  showAlert: boolean;
  dismiss: () => void;
  isSuccess: boolean;
  message?: string;
}) => {
  const handleOnDismiss = () => {
    dismiss();
  };

  return (
    <AlertDialog
      showDialog={showAlert}
      setShowDialog={() => handleOnDismiss()}
      sx={sx}
      variant={isSuccess ? "success" : "error"}
    >
      <AlertDescription>
        <Typography>
          {message ||
            (isSuccess
              ? "Your client has been successfully added"
              : "Your attempt to add a new client has caused an error. Please try again.")}
        </Typography>
        <Button
          variant="contained"
          style={{ marginTop: "32px" }}
          onClick={handleOnDismiss}
        >
          Okay
        </Button>
      </AlertDescription>
    </AlertDialog>
  );
};

export default ClientInformationAlertSnackbar;
