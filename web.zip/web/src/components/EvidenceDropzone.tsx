import {
  faCircleExclamation,
  faTrashCan,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { SelectChangeEvent, SelectProps } from "@mui/material/Select";
import {
  Alert,
  AlertActions,
  AlertDescription,
  AlertHeader,
  Button,
  Dropdown,
  Grid,
  MaterialTable,
  Typography,
} from "myuscis-material";
import { DropdownOption } from "myuscis-material/dist/components/table/paginatedTableFooter/paginatedTableFooter";
import React, {
  ReactNode,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
} from "react";
import { FileRejection, useDropzone } from "react-dropzone";
import { useDispatch, useSelector } from "react-redux";
import { JSX } from "react/jsx-runtime";
import { Dispatch } from "redux";
import { makeStyles } from "tss-react/mui";
import {
  SubmissionService,
  UpdateSubmissionResponse,
} from "../api/SubmissionService";
import { DocumentUploadContext } from "../contexts/DocumentUploadContext";
import { useUploadEvidence } from "../hooks/documentUpload";
import {
  selectedEvidenceGroup,
  selectedEvidencesForGroup,
  setPhotoUploadErrors,
} from "../redux/evidenceSlice";
import { RootState } from "../redux/store";
import {
  SubmissionState,
  addEvidenceUpload,
  deleteEvidence,
  hydrateState,
  setEvidenceHasError,
} from "../redux/submissionSlice";
import {
  setIsPollingForFormValidation,
  setIsPollingForEvidenceValidation,
  deleteEvidenceValidation,
} from "../redux/validationsSlice";

import { Evidence, EvidenceFile } from "../redux/types/Submission";
import { EvidenceDropzoneProps } from "../types/Dropzone";
import { FileObject } from "../types/File";
import { EvidenceGroup, FormTypes } from "../types/FormMetaData";
import { EvidenceUploadResponse, UploadRequest } from "../types/Upload";
import { Validation, ValidationResults } from "../types/Validations";
import { getDateFromNanoSeconds } from "../utils/dates";
import { fileNameValidator } from "../utils/fileNameValidator";
import { formatFileName } from "../utils/formatFileName";
import AlertDialog from "./Dialogs/AlertDialog";
import { DeleteDialogConfirmation } from "./Dialogs/DeleteConfirmationDialog";
import { ValidationStatusIndicator } from "./ValidationStatusIndicator";
import AlertWindow from "./shared/AlertWindow";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";
import { AlertColor } from "@mui/material";
import { isAxiosError, AxiosError } from "axios";
import { ValidationsState } from "../redux/validationsSlice";


const baseStyle = {
  flex: 1,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "20px",
  borderWidth: 2,
  borderRadius: 2,
  borderColor: "#eeeeee",
  borderStyle: "dashed",
  backgroundColor: "#fafafa",
  color: "#666666",
  outline: "none",
  transition: "border .24s ease-in-out",
};

const focusedStyle = {
  borderColor: "#2196f3",
};

const acceptStyle = {
  borderColor: "#00e676",
};

const rejectStyle = {
  borderColor: "#ff1744",
};

const linkText = {
  color: "#006699",
  textDecoration: "underline",
  cursor: "pointer",
};

const dropzoneMargin = {
  margin: "1em",
};

const useStyles = makeStyles()({
  dropdown: {
    width: "10rem",
    "& .MuiSelect-select span::before": {
      content: "'Select Type'", // string contains single quotes
    },
    "& .MuiInput-input": {
      fontSize: "16px",
      display: "flex",
      alignItems: "center",
      textWrap: "wrap",
    },
    "& .MuiMenuItem-root": {
      fontSize: "16px",
    },
  },
});

type Props = {
  setShowFileRejectionsAlert: (showAlert: boolean) => void;
  setFileRejectionsForAlert: React.Dispatch<
    React.SetStateAction<FileRejection[]>
  >;
  deleteWarningText: string;
  evidenceGroupType: string;
  dropzoneProps: EvidenceDropzoneProps;
  selectedFormType: string;
};

const renderType = (
  evidenceGroup: EvidenceGroup,
  evidenceFile: EvidenceFile,
) => {
  return evidenceFile.type === evidenceGroup.id
    ? evidenceGroup.name
    : evidenceGroup.evidenceTypes.filter(
        (type) => type.id === evidenceFile.type,
      )[0].name;
};

const EvidenceDropzone = ({
  deleteWarningText,
  evidenceGroupType,
  setShowFileRejectionsAlert,
  setFileRejectionsForAlert,
  dropzoneProps,
  selectedFormType
}: Props) => {
  const UPLOAD_FAILURE_MESSAGE =
    "Error attempting to upload file(s). Please try again later.";

  const { uploadEvidence } = useUploadEvidence();
  const { addAlert } = useAlertSnackbar();
  const [totalFiles, setTotalFiles] = useState<FileObject[]>([]);
  const [fileToBeDeleted, setFileToBeDeleted] = useState<EvidenceFile>();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [filesRejectionsForTableError, setFilesRejectionsForTableError] =
    useState<FileRejection[]>([]);
  const [showPhotoErrorAlert, setShowPhotoErrorAlert] = useState(false);

  const { setLoading } = useContext(DocumentUploadContext);
  const [uploadError, setUploadError] = useState<string>("");
  const evidenceGroups: EvidenceGroup[] = useSelector(
    (state: RootState) => selectedFormType === state.submission.formType
            ? state.evidence.evidenceGroups
            : state.evidence.concurrentEvidenceGroups.find((group) => group.formType === selectedFormType)!.evidenceGroups,
  );
  const formId = useSelector(
    (state: RootState) => state.submission.forms.find((form) => form.formType === selectedFormType)?.formId,
  );

  const selectedConcurrentEvidenceGroup = useSelector(
    (state: RootState) => state.evidence.concurrentEvidenceGroups.find((group) => group.formType === selectedFormType)?.evidenceGroups.find((group) => group.id === evidenceGroupType),
  );

  const evidenceGroup: EvidenceGroup = useSelector((state: RootState) =>
    selectedFormType === state.submission.formType ? selectedEvidenceGroup(state, evidenceGroupType) : selectedConcurrentEvidenceGroup,
  )!;

  const options = evidenceGroup?.evidenceTypes?.map((type) => ({
    value: type.id,
    label: type.name.replaceAll("/", "/\u200B"),
  }));

  const { submissionId, formSpecificInfo }: SubmissionState = useSelector(
    (state: RootState) => state.submission,
  );

  const { isPollingForEvidenceValidation }: ValidationsState = useSelector(
    (state: RootState) => state.validations,
  );

  const { photoUploadErrors } = useSelector(
    (state: RootState) => state.evidence,
  );

  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);

  const evidences: Evidence[] = useSelector((state: RootState) =>
    selectedEvidencesForGroup(state, evidenceGroupType),
  );

  const dispatch = useDispatch();
  const { maxUploads, validated, maxDrop } = dropzoneProps;

  const getUploadLimitFileRejections = useCallback(
    (inputFiles: File[], remainingAllowedUploads: number): FileRejection[] => {
      return inputFiles.slice(remainingAllowedUploads).map((file) => ({
        file,
        errors: [
          {
            message:
              totalFiles.length + inputFiles.length > maxUploads
                ? `You've reached maximum number of allowed uploads.`
                : `You can not upload more than ${maxDrop} at once. Try uploading them again.`,
            code: "too-many-files",
          },
        ],
      }));
    },
    [maxDrop, maxUploads, totalFiles.length],
  );
  const I140EvidenceCheck = FormTypes.I140 === selectedFormType && !formSpecificInfo?.isScheduleA === true && dropzoneProps.validated;

  const onDrop = useCallback(
    async (inputFiles: any[], inputFileRejections: FileRejection[]) => {
      setUploadError("");
      setFileRejectionsForAlert([]);

      const remainingAllowedUploads = Math.min(
        maxDrop,
        maxUploads - totalFiles.length,
      );

      const acceptedFiles = inputFiles.slice(0, remainingAllowedUploads);
      setTotalFiles((prev) => [...prev, ...acceptedFiles]);

      const uploadLimitFileRejections: FileRejection[] =
        getUploadLimitFileRejections(inputFiles, remainingAllowedUploads);

      setFilesRejectionsForTableError(uploadLimitFileRejections);

      setFileRejectionsForAlert(inputFileRejections);

      if (inputFileRejections.length > 0) {
        addAlert(UPLOAD_FAILURE_MESSAGE);
        setShowFileRejectionsAlert(true);
      }

      if (uploadLimitFileRejections.length > 0)
        addAlert(UPLOAD_FAILURE_MESSAGE);

      if (acceptedFiles.length === 0) return;

      setLoading(true);
      const formData = new FormData();
      const evidenceRequest = acceptedFiles.map((f) => {
        return {
          fileName: f.name,
          type:
            evidenceGroup.evidenceTypes.length === 1
              ? evidenceGroup.evidenceTypes[0].id
              : evidenceGroup.id,
          evidenceGroupType,
        };
      });

      acceptedFiles.forEach((f) => {
        formData.append("files", f);
      });

      evidenceRequest.forEach((e) => {
        formData.append(
          "uploadEvidenceRequests",
          new Blob([JSON.stringify(e)], {
            type: "application/json",
          }),
        );
      });

      const uploadRequest: UploadRequest = {
        formData,
        myUscisId,
        submissionId,
        selectedFormType
      };

      uploadEvidence(uploadRequest, userGroupId)
        .then((response: EvidenceUploadResponse[]) => {
          setTimeout(() => {
            setLoading(false);
          }, 2000);
          dispatch(
            addEvidenceUpload({
              request: evidenceRequest,
              evidenceGroup: evidenceGroup.id,
              response,
            }),
          );

          if (
            evidenceGroup.id === "applicant-photo" &&
            response &&
            response.length > 0 &&
            response[0].hasError
          ) {
            dispatch(
              setPhotoUploadErrors(
                response[0].errors?.map((error: any) => error.message) ?? [],
              ),
            );
            setShowPhotoErrorAlert(true);
          }

          if (dropzoneProps.validated && selectedFormType !== FormTypes.I140 || I140EvidenceCheck) {
            dispatch(setIsPollingForEvidenceValidation(true));
          }

          setLoading(false);
        })
        .catch((error: Error | AxiosError) => {
          let UPLOADING_ERROR_MESSAGE = "Error uploading document: ";
          if (isAxiosError(error)) {
            if (error.status === 415) {
              UPLOADING_ERROR_MESSAGE += "File format is not supported";
            }
            if (error.message.includes("400") && error.response) {
              UPLOADING_ERROR_MESSAGE += error.response.data.files
            }
          } else {
            UPLOADING_ERROR_MESSAGE += error;
          }
          setUploadError(UPLOADING_ERROR_MESSAGE);
          setTotalFiles((prevFiles) =>
            removeFile(
              prevFiles,
              inputFiles.map((f) => f.name),
            ),
          );
          setLoading(false);
          return;
        });
    },
    [
      setFileRejectionsForAlert,
      maxDrop,
      maxUploads,
      totalFiles.length,
      getUploadLimitFileRejections,
      addAlert,
      setLoading,
      myUscisId,
      userGroupId,
      submissionId,
      uploadEvidence,
      setShowFileRejectionsAlert,
      evidenceGroup.evidenceTypes,
      evidenceGroup.id,
      evidenceGroupType,
      dispatch,
      dropzoneProps.validated,
    ],
  );

  const removeFile = (
    prevFiles: Array<FileObject>,
    filesToRemove: string[],
  ) => {
    return prevFiles.filter((prevFile) =>
      filesToRemove.includes(prevFile.name),
    );
  };

  const {
    getRootProps,
    getInputProps,
    isFocused,
    isDragAccept,
    isDragReject,
    open,
  } = useDropzone({
    onDrop,
    validator: fileNameValidator,
    ...dropzoneProps,
  });

  const allowMultipleUploads = dropzoneProps.maxUploads > 1;
  const handleDeleteFile = async () => {
    if (!fileToBeDeleted) return;
    await performDelete(
      totalFiles,
      fileToBeDeleted,
      myUscisId,
      userGroupId,
      submissionId,
      setTotalFiles,
      dispatch,
      dropzoneProps,
      evidenceGroupType,
      addAlert,
    );
    setIsDeleteDialogOpen(false);
  };

  const handleChangeDocumentType = (evidence: EvidenceFile) => {
    return async (event: SelectChangeEvent<string>, child: ReactNode) => {
      try {
        const response: UpdateSubmissionResponse =
          await SubmissionService.updateEvidence(
            myUscisId,
            submissionId,
            evidence.id,
            event.target.value,
            userGroupId,
          );
        if (response.submission.forms?.length > 0) {
          dispatch(setIsPollingForFormValidation(true));
        }
        dispatch(
          hydrateState({
            submission: response.submission,
            evidenceGroups,
          }),
        );
      } catch (error) {
        addAlert("Unable to change document type. Please try again later");
      }
    };
  };

  const onOpenDeleteDialog = (clickedFile: EvidenceFile) => {
    setIsDeleteDialogOpen(true);
    setFileToBeDeleted(clickedFile);
  };

  const handleDeleteFileRejection = (clickedFile: FileRejection) => {
    const updatedRejectedFiles: FileRejection[] =
      filesRejectionsForTableError.filter((file) => file !== clickedFile);

    setFilesRejectionsForTableError(updatedRejectedFiles);
  };

  const style = useMemo(
    () => ({
      ...baseStyle,
      ...(isFocused ? focusedStyle : {}),
      ...(isDragAccept ? acceptStyle : {}),
      ...(isDragReject ? rejectStyle : {}),
    }),
    [isFocused, isDragAccept, isDragReject],
  );

  const evidenceValidations: Validation[] = useSelector(
    (state: RootState) => state.validations.evidenceValidations,
  );

  function lookupValidation(id: string) {
    return evidenceValidations.find((item) => id === item.id);
  }

  let tableContents: ((JSX.Element | null)[] | null)[] = [];
  const validationsForGroup = useMemo(
    () =>
      evidenceValidations.filter(
        (validation) => validation.groupType === evidenceGroupType,
      ),
    [evidenceValidations, evidenceGroupType],
  );
  const errors = useMemo(() => {
    if (!evidences) {
      return [];
    }
    return validationsForGroup
      .filter((validation) =>
        validation.details.some(
          (detail) => detail.result === ValidationResults.FAIL,
        ),
      )
      .map((validation) => ({
        id: validation.id,
        file: evidences[0].files.find((file) => file.id === validation.id)
          ?.fileName,
        details: validation.details ? validation.details[0] : undefined,
      }));
  }, [validationsForGroup, evidences]);

  const rejectedContents: ((JSX.Element | null)[] | null)[] =
    filesRejectionsForTableError.map(
      (rejectedFile: FileRejection, index: number) => [
        <td colSpan={3} key={`r${index}c-file-name`}>
          <div style={{ display: "flex", paddingTop: "20px" }}>
            <span style={{ paddingRight: "16px" }}>
              {rejectedFile.file.name}
            </span>
            <span style={{ verticalAlign: "middle", marginLeft: "auto" }}>
              <Button
                variant="text"
                role="button"
                aria-label="Delete file"
                onClick={() => handleDeleteFileRejection(rejectedFile)}
              >
                <FontAwesomeIcon
                  style={{ fontSize: "16px", color: "#08588F" }}
                  icon={faXmark}
                />
              </Button>
            </span>
          </div>
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              float: "left",
              flexGrow: 1,
              padding: "20px 0 16px 0px",
            }}
          >
            <span>
              <FontAwesomeIcon
                style={{ fontSize: "16px", color: "red" }}
                icon={faCircleExclamation}
              />
            </span>
            <span style={{ paddingLeft: "10px", fontWeight: "bold" }}>
              {rejectedFile.errors.map((error) => error.message)}
            </span>
          </div>
        </td>,
      ],
    );

  if (evidences.length) {
    evidences.forEach(
      (evidence, index) =>
        (tableContents = evidence.files.map((evidenceFile) => {
          const validation = lookupValidation(evidenceFile.id);
          return evidenceFile !== undefined && evidenceFile.formId === formId
              ? [
                <td key={`r${index}c-file-name`}>
                  {formatFileName(evidenceFile.fileName)}
                </td>,
                <td key={`r${index}c-document`}>
                  {options.length === 1 &&
                    renderType(evidenceGroup, evidenceFile)}
                  {options.length !== 1 && (
                    <DocumentTypeSelector
                      value={evidenceFile.type ?? ""}
                      options={options}
                      onChange={handleChangeDocumentType(evidenceFile)}
                    />
                  )}
                </td>,
                validated && FormTypes.I140 != selectedFormType|| I140EvidenceCheck? (
                  <td key={`r${index}c-status`}>
                    <ValidationStatusIndicator
                      status={validation?.status}
                      error={
                        validation?.details &&
                        validation.details.length > 0 &&
                        validation?.details[0].result === ValidationResults.FAIL
                      }
                    />
                  </td>
                ) : null,
                allowMultipleUploads ? null : (
                  <td key={`r${index}c-date`}>
                    {getDateFromNanoSeconds(evidenceFile.dateTime)}
                  </td>
                ),
                <td key={`r${index}c-action`}>
                  <Button
                    variant="text"
                    startIcon={
                      <FontAwesomeIcon
                        style={{ fontSize: "16px", color: "#08588F" }}
                        icon={faTrashCan}
                      />
                    }
                    role="button"
                    aria-label="Delete file"
                    style={linkText}
                    onClick={() => onOpenDeleteDialog(evidenceFile)}
                  >
                    Delete
                  </Button>
                </td>,
              ]
            : null;
        })),
    );
  }

  const headerContents = [
    <th key="header-row-c-file-name">File name</th>,
    <th key="header-row-c-document">Document</th>,
    validated && FormTypes.I140 != selectedFormType|| I140EvidenceCheck? <th key="header-row-c-status">Status</th> : null,
    allowMultipleUploads ? null : <th key="header-row-c-date">Date</th>,
    <th key="header-row-c-action">Action</th>,
  ];

  const tableContainterRef = useRef<HTMLDivElement>(null);

  return (
    <div
      className="container"
      style={{ display: "flex", flexDirection: "column", gap: "32px" }}
      tabIndex={-1}
      ref={tableContainterRef}
    >
      {(evidences[0]?.files.length ?? 0) < maxUploads && (
        <div {...getRootProps({ style, role: "button" })}>
          <input {...getInputProps()} />
          <p style={dropzoneMargin}>
            <span style={linkText}>Choose</span> or drop file here to upload
          </p>
        </div>
      )}

      {!!evidences[0]?.files.length && evidences[0]?.files.some((file) => file.formId === formId) && (
        <>
          <MaterialTable
            headerContents={[headerContents]}
            tableContents={[...tableContents, ...rejectedContents]}
          />

          {!!photoUploadErrors.length &&
            evidenceGroupType === "applicant-photo" && (
              <AlertWindow variant="warning">
                <strong>
                  You should delete this photo and upload a new photo that meets
                  the 2x2 photo requirements listed on this page.
                </strong>
              </AlertWindow>
            )}
        </>
      )}

      <DeleteDialogConfirmation
        isDialogOpen={isDeleteDialogOpen}
        handleDialogClose={() => setIsDeleteDialogOpen(false)}
        handleDelete={() => handleDeleteFile()}
        deleteWarningText={deleteWarningText}
        focusReturnFallbackElementRef={tableContainterRef}
      />

      {isPollingForEvidenceValidation && validated && (
        <AlertWindow variant={"information"}>
          Your document is currently being validated for completeness. This
          process may take several minutes. You may continue to the next step.
          You will be notified of the validation progress.
        </AlertWindow>
      )}

      {errors.map((error) =>
        error.details?.reasons.map((reason, index) => (
          <div key={`${reason}-${index}`} role="alert" aria-live="assertive">
            <Alert key={reason.substring(0, 10)} variant="error" maxWidth focus>
              <AlertHeader>Error with uploaded document</AlertHeader>
              <AlertDescription>
                We found the following errors with {error.file}
                <br />
                <br />
                <span
                  key={reason}
                  style={{ display: "block", margin: "12px 0" }}
                >
                  {reason}
                </span>
              </AlertDescription>
              <AlertActions>
                <Grid item mt="16px">
                  <Button
                    variant="contained"
                    onClick={async () => {
                      await performDelete(
                        totalFiles,
                        { fileName: error.file!, id: error.id },
                        myUscisId,
                        userGroupId,
                        submissionId,
                        setTotalFiles,
                        dispatch,
                        dropzoneProps,
                        evidenceGroupType,
                        addAlert,
                      );
                      open();
                    }}
                  >
                    Re-Upload PDF
                  </Button>
                </Grid>
              </AlertActions>
            </Alert>
          </div>
        )),
      )}

      <AlertDialog
        showDialog={showPhotoErrorAlert}
        setShowDialog={setShowPhotoErrorAlert}
        headerText="Your photo does not meet USCIS requirements"
      >
        <AlertDescription>
          <ul>
            {photoUploadErrors?.map((error) => <li key={error}>{error}</li>)}
          </ul>
          <Typography>
            Please upload a new photo that meets the requirements provided in
            the{" "}
            <a
              href="https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/photos.html"
              target="_blank"
              rel="noopener noreferrer"
            >
              photo composition tools
            </a>
          </Typography>
          <Button
            variant="contained"
            style={{ marginTop: "32px" }}
            onClick={() => setShowPhotoErrorAlert(false)}
          >
            Okay
          </Button>
        </AlertDescription>
      </AlertDialog>
      {uploadError && (
        <AlertWindow variant={"error"}>{uploadError}</AlertWindow>
      )}
    </div>
  );
};

type DocumentTypeProps = { options: DropdownOption[] } & SelectProps<string>;

async function performDelete(
  files: FileObject[],
  fileToBeDeleted: { fileName: string; id: string },
  myUscisId: string,
  orgMyUscisId: string,
  submissionId: string,
  setFiles: React.Dispatch<React.SetStateAction<FileObject[]>>,
  dispatch: Dispatch<any>,
  dropzoneProps: EvidenceDropzoneProps,
  evidenceGroupType: string,
  addAlert: (
    messageToDisplay: string,
    variant?: AlertColor | undefined,
  ) => void,
) {
  const updatedFiles = files.filter(
    (file) => file.name !== fileToBeDeleted.fileName,
  );

  const { id } = fileToBeDeleted!;

  try {
    await SubmissionService.deleteUploadedEvidence(myUscisId, submissionId, id, orgMyUscisId);
    setFiles(updatedFiles);
    dispatch(deleteEvidenceValidation(id));
    dispatch(deleteEvidence(id));

    if (evidenceGroupType === "applicant-photo")
      dispatch(setPhotoUploadErrors([]));
    if (dropzoneProps.validated) {
      dispatch(setIsPollingForEvidenceValidation(false));
      dispatch(setEvidenceHasError(false));
    }
  } catch (error) {
    addAlert(
      `Unable to delete ${fileToBeDeleted.fileName}. Please try again later`,
    );
  }
}

function DocumentTypeSelector(props: DocumentTypeProps) {
  const { classes } = useStyles();

  return (
    <Dropdown
      options={props.options}
      autoWidth={true}
      reduceLeftPadding
      className={classes.dropdown}
      {...(props as SelectProps<unknown>)}
    />
  );
}

export default EvidenceDropzone;