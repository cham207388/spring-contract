import { ValidationStatus } from "../types/Validations";

export interface ValidationStatusProps {
  status?: ValidationStatus;
  error?: boolean;
}

export function ValidationStatusIndicator(props: ValidationStatusProps) {
  let color;
  let text;
  const { status, error } = props;

  if (!status || "IN_PROGRESS" === status) {
    color = "#444444";
    text = "Pending";
  } else if ("COMPLETE" === status) {
    if (error) {
      color = "#CC3333";
      text = "Error";
    } else {
      color = "#006600";
      text = "Complete";
    }
  } else {
    color = "#006600";
    text = "...";
  }

  return (
    <span
      style={{
        color,
      }}
    >
      {text}
    </span>
  );
}
