import { useState } from "react";

import {
  faChevronUp,
  faChevronDown,
  faLandmark,
  faLock,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Stack } from "@mui/material";
import { Box, Typography, Button } from "myuscis-material";
import { makeStyles } from "tss-react/mui";

import { SharedLayoutProps } from "../Layout/Layout";
import SkipToContentButton from "../SkipToContentButton";

const useStyles = makeStyles<{ isMobile: boolean | undefined }>()(
  (_theme, { isMobile }) => ({
    container: {
      maxWidth: "100%",
      backgroundColor: "#F9F9F9",
      margin: "0 auto",
      display: "flex",
      flexDirection: isMobile ? "column" : "row",
      alignItems: "flex-start",
      padding: "5px 16px",
      gap: isMobile ? "0" : "8px",
    },
    body: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      "&--text__main": {
        fontSize: "12px",
      },
      "&--text__link": {
        fontSize: "12px",
        textDecoration: "underline",
        color: _theme.palette.primary.main,
      },
      "&--button": {
        padding: 0,
        marginLeft: isMobile ? "32px" : "0",
      },
    },
    popout: {
      minHeight: "129px",
      backgroundColor: "#F9F9F9",
      width: "100%",
      justifyContent: "space-between",
      maxWidth: "1028px",
      gap: "16px",
      margin: isMobile ? "" : "0 auto",
      padding: "24px 16px",
      "&--row": {
        flexDirection: "row",
        gap: "16px",
      },
      "&--icon": {
        borderRadius: "100%",
        padding: "13px",
        "&__lock": {
          color: "#719F2A",
          border: "1px solid #719F2A",
        },
        "&__gov": {
          color: "#2378C3",
          border: "1px solid #2378C3",
        },
      },
    },
    medium: {
      fontWeight: _theme.typography.fontWeightMedium,
    }
  }),
);

const TopBanner = ({ isMobile }: SharedLayoutProps) => {
  const [isHowYouKnowOpen, setIsHowYouKnowOpen] = useState(false);
  const { classes } = useStyles({ isMobile });

  return (
    <>
      <SkipToContentButton label="Jump to content" hrefTarget="#content"/>
      <Stack className={classes.container}>
        <Box className={classes.body}>
          <img src="/pdf-intake/flag.png" alt="" height={14} width={24} />
          <Typography className={`${classes.body}--text__main`}>
            An official website of the United States government
          </Typography>
        </Box>
        <Button
          variant="text"
          className={`${classes.body}--button`}
          onClick={() => setIsHowYouKnowOpen(!isHowYouKnowOpen)}
        >
          <Typography className={`${classes.body}--text__link`}>
            Here&apos;s how you know{" "}
            <FontAwesomeIcon
              size="xs"
              icon={isHowYouKnowOpen ? faChevronUp : faChevronDown}
            />
          </Typography>
        </Button>
      </Stack>
      <Box sx={{ backgroundColor: "#f3f3f3" }}>
        <Stack
          direction={{ xs: "column", md: "row" }}
          display={isHowYouKnowOpen ? "flex" : "none"}
          className={classes.popout}
        >
          <Stack className={`${classes.popout}--row`}>
            <FontAwesomeIcon
              className={`${classes.popout}--icon ${classes.popout}--icon__gov`}
              icon={faLandmark}
            />
            <Stack>
              <Typography className={classes.medium}>
                Official websites use .gov
              </Typography>
              <Typography>
                A <strong>.gov</strong> website belongs to an official
                government organization in the United States.
              </Typography>
            </Stack>
          </Stack>
          <Stack className={`${classes.popout}--row`}>
            <FontAwesomeIcon
              className={`${classes.popout}--icon ${classes.popout}--icon__lock`}
              icon={faLock}
            />
            <Stack>
              <Typography className={classes.medium}>
                Secure .gov websites use HTTPS
              </Typography>
              <Typography>
                A lock (<FontAwesomeIcon icon={faLock} />) or{" "}
                <strong>https://</strong> means you’ve safely connected to the
                .gov website. Share sensitive information only on official,
                secure websites.
              </Typography>
            </Stack>
          </Stack>
        </Stack>
      </Box>
    </>
  );
};

export default TopBanner;
