import { useMediaQuery, useTheme } from "@mui/material";
import { useContext, useEffect } from "react";
import { makeStyles } from "tss-react/mui";
import { RootState } from "../redux/store";

import { useDispatch, useSelector } from "react-redux";
import { Outlet, useLoaderData } from "react-router-dom";
import { Dispatch } from "redux";
import { SubmissionService } from "../api/SubmissionService";
import { DocumentUploadContext } from "../contexts/DocumentUploadContext";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";
import { useHydrateDraft } from "../hooks/useHydrateDraft";
import useInterval from "../hooks/useInterval";
import { useSteps } from "../hooks/useSteps";
import {
  SubmissionState,
  setAttestationSignature,
  setEvidenceHasError,
  setFeeTotal,
  setFormHasError,
  setFormHasWarnings,
  setIsFeeExempt,
  setIsNotFeeExempt,
  setIsSignaturePresent,
  setUserIsEligibleForFeeWaiver,
} from "../redux/submissionSlice";
import {
  setValidations,
  setEvidenceValidations,
  setFeeWaiverValidation,
  setIsPollingForFormValidation,
  setIsPollingForEvidenceValidation,
  setIsPollingForFeeWaiverValidation,
} from "../redux/validationsSlice";

import { Attestation } from "../redux/types/Submission";
import { AccountTypes, setMyUscisId, setUserGroupId } from "../redux/userSlice";
import { Submission } from "../types/Submission";
import {
  ValidationDetails,
  ValidationResults,
  ValidationStatusResponse,
  Validators,
  isAllValidationsComplete,
} from "../types/Validations";
import AccordionContainer from "./AccordionNav/AccordionContainer";
import UploadingDialog from "./Dialogs/UploadingDialog";
import { useSubmissionStatusFetch } from "../hooks/useSubmissionStatusFetch";
import { useRouteChangeFocus } from "../hooks/useRouteChangeFocus"

const useStyles = makeStyles()((theme) => ({
  navSideBackground: {
    backgroundColor: "#F3F3F3",
    height: "100%",
    width: "50%",
    position: "fixed",
    zIndex: "-1",
    bottom: 0,
    left: 0,
  },
  container: {
    display: "flex",
    flexDirection: "column",
    [theme.breakpoints.up("md")]: {
      width: "1028px",
      height: "100%",
      marginLeft: "auto",
      marginRight: "auto",
      flexDirection: "row",
      fontSize: "16px",
      lineHeight: "22px",
      backgroundColor: "#FFF",
    },
  },
  desktopMainPart: {
    display: "flex",
    flexDirection: "column",
    gap: "22px",
    textAlign: "left",
    padding: "0 48px",
    margin: "20px 0 96px 0",
    "& > p": { margin: "0" },
  },
  mobileMainPart: {
    height: "100%",
    display: "flex",
    flexDirection: "column",
    gap: "24px",
    margin: "24px 16px 64px 16px",
    "& > p": { margin: "0" },
  },
  desktopContent: {
    width: "550px",
  },
  desktopContentConstrained: {
    width: "fit-content",
  },
}));

const processFormValidation = async (
  response: ValidationStatusResponse,
  dispatch: Dispatch<any>,
  attestation: Attestation,
  userId: string,
  userOrgId: string,
  submission: SubmissionState,
  feeTotal: number,
  primaryFormType: string,
  accountType: string | undefined,
) => {
  const isRep = accountType === AccountTypes.REPRESENTATIVE;
  if (isAllValidationsComplete(response)) {
    dispatch(setIsPollingForFormValidation(false));

    // TODO add userRequestedFeeWaiverHere
  }

  dispatch(setValidations(response));

  if (response.status === "COMPLETE") {
    const primaryFormValidations = response.formValidations.find(
      (formValidation) => formValidation.groupType === primaryFormType,
    );

    const passSignatureValidation = primaryFormValidations?.details.some(
      (validation) =>
        validation.validator === Validators.SIGNATURE &&
        validation.result === ValidationResults.PASS,
    );

    if (passSignatureValidation) {
      dispatch(setIsSignaturePresent(true));
      dispatch(setAttestationSignature(attestation.attestationSignature));
    }


    const primaryFormHasError =
      primaryFormValidations?.details.some((validation) =>
        isRep
          ? hasRepBasedErrors(validation)
          : hasApplicantBasedErrors(validation),
      ) || false;

    dispatch(setFormHasError(primaryFormHasError));

    const primaryFormHasWarning =
      primaryFormValidations?.details.some(
        (validation) => validation.result === ValidationResults.WARN,
      ) || false;

    dispatch(setFormHasWarnings(primaryFormHasWarning));

    // Refactor opportunity: make this an async thunk
    const fetchedSubmission: Submission = await SubmissionService.getSubmission(
      userId,
      submission.submissionId,
      userOrgId,
    );
    const newFeeTotal = fetchedSubmission.feeTotal;
    if (newFeeTotal !== feeTotal && !fetchedSubmission.userRequestedFeeWaiver) {
      if (newFeeTotal > 0) dispatch(setIsNotFeeExempt(true));
      else dispatch(setIsFeeExempt(true));
    }
    dispatch(
      setUserIsEligibleForFeeWaiver(
        fetchedSubmission.userIsEligibleForFeeWaiver,
      ),
    );
    dispatch(setFeeTotal(newFeeTotal));
  }

  function hasApplicantBasedErrors(validation: ValidationDetails): unknown {
    return (
      (validation.validator === Validators.CORE ||
        validation.validator === Validators.ELIGIBILITY_CATEGORY ||
        validation.validator === Validators.REASON_FOR_FILING ||
        validation.validator === Validators.PFVS ||
        validation.validator === Validators.PERSON) &&
      validation.result === ValidationResults.FAIL
    );
  }

  function hasRepBasedErrors(validation: ValidationDetails): unknown {
    return (
      (validation.validator === Validators.CORE ||
        validation.validator === Validators.ELIGIBILITY_CATEGORY ||
        validation.validator === Validators.PERSON ||
        validation.validator === Validators.G28_COMP ||
        validation.validator === Validators.G28_NAME_EMAIL ||
        validation.validator === Validators.G28_ATTORNEY_NAME ||
        validation.validator === Validators.G28_COMP_NAME) &&
      validation.result === ValidationResults.FAIL
    );
  }
};

interface LoaderData {
  submission: Submission;
  userId: string;
  userGroupId: string;
}

const DocumentUpload = () => {
  const { currentStep } = useSteps();
  const { classes } = useStyles();
  const { loading, setLoading, loadingForPayment } = useContext(
    DocumentUploadContext,
  );

  const mainContentRef = useRouteChangeFocus();
  const { hydrateDraft } = useHydrateDraft();
  const theme = useTheme();
  const dispatch = useDispatch();
  const { addAlert } = useAlertSnackbar();
  useSubmissionStatusFetch();
  const {
    attestation,
    feeTotal,
    feeWaiver,
    formType: primaryFormType,
  } = useSelector((state: RootState) => state.submission);

  const {
    isPollingForFormValidation,
    isPollingForEvidenceValidation,
    isPollingForFeeWaiverValidation,
  } = useSelector((state: RootState) => state.validations);

  const { submission: loadedSubmission, userId, userGroupId } =
    useLoaderData() as LoaderData;
  const submission = useSelector((state: RootState) => state.submission);
  const accountType = useSelector((state: RootState) => state.user.accountType);

  dispatch(setMyUscisId(userId));
  dispatch(setUserGroupId(userGroupId));
  const POLLING_DELAY = 5000;

  useInterval(
    async () => {
      try {
        if (isPollingForFormValidation) {
          const response = await SubmissionService.pollForValidationStatus(
            userId,
            submission.submissionId,
            userGroupId
          );

          await processFormValidation(
            response,
            dispatch,
            attestation,
            userId,
            userGroupId,
            submission,
            feeTotal,
            primaryFormType,
            accountType,
          );
        }
      } catch (e) {
        addAlert("Something went wrong when polling for validation status");
        dispatch(setIsPollingForFormValidation(false));
      }
    },
    isPollingForFormValidation ? POLLING_DELAY : null,
    isPollingForFormValidation ? 5 : undefined,
  );

  useInterval(
    async () => {
      try {
        if (isPollingForEvidenceValidation) {
          const response = await SubmissionService.pollForValidationStatus(
            userId,
            submission.submissionId,
            userGroupId
          );

          if (isAllValidationsComplete(response, true)) {
            dispatch(setIsPollingForEvidenceValidation(false));
          }

          dispatch(
            setEvidenceValidations(
              response.evidenceValidations.filter(
                (evidenceValidation) =>
                  evidenceValidation.status === "COMPLETE",
              ),
            ),
          );

          dispatch(
            setEvidenceHasError(
              response.evidenceValidations.some((validation) =>
                validation.details.some(
                  (detail) => detail.result === ValidationResults.FAIL,
                ),
              ),
            ),
          );
        }
      } catch (e) {
        addAlert(
          "Something went wrong when polling for evidence validation status",
        );
        dispatch(setIsPollingForEvidenceValidation(false));
      }
    },
    isPollingForEvidenceValidation ? POLLING_DELAY : null,
  );

  useInterval(
    async () => {
      try {
        if (
          isPollingForFeeWaiverValidation &&
          feeWaiver.files.length > 0 &&
          feeWaiver.files[0].id
        ) {
          const response = await SubmissionService.pollForI912ValidationStatus(
            userId,
            submission.submissionId,
            feeWaiver.files[0].id,
            userGroupId
          );

          if (response.status === "COMPLETE") {
            dispatch(setFeeWaiverValidation(response.i912FeeWaiverValidation));
            dispatch(setIsPollingForFeeWaiverValidation(false));
            const fetchedSubmission: Submission = await SubmissionService.getSubmission(
              userId,
              submission.submissionId,
              userGroupId,
            );
            const newFeeTotal = fetchedSubmission.feeTotal;
            dispatch(setFeeTotal(newFeeTotal));
          }
        }
      } catch (e) {
        addAlert(
          "Something went wrong when polling for fee waiver validation status",
        );
        dispatch(setIsPollingForFeeWaiverValidation(false));
      }
    },
    isPollingForFeeWaiverValidation ? POLLING_DELAY : null,
  );

  useEffect(() => {
    if (submission.submissionId !== loadedSubmission.submissionId) {
      hydrateDraft(loadedSubmission);
    }
  }, [hydrateDraft, loadedSubmission, submission]);

  const isMobile = useMediaQuery(theme.breakpoints.down("md"), {
    defaultMatches: true,
  });

  return (
    <>
      <div className={`${!isMobile && classes.navSideBackground}`} />
      <div className={classes.container}>
        <AccordionContainer />
        <div
          className={
            isMobile ? classes.mobileMainPart : classes.desktopMainPart
          }
        >
          <div
            id="maincontent"
            className={isMobile ? `` : classes.desktopContent}
            ref={mainContentRef}
          >
            <Outlet />
          </div>
        </div>
        <UploadingDialog
          loading={loading}
          setLoading={setLoading}
          currentStep={currentStep}
          forPayment={loadingForPayment}
        />
      </div>
    </>
  );
};

export default DocumentUpload;
