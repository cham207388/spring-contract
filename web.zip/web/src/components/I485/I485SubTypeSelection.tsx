import { Typography } from "myuscis-material";
import { SubmissionService } from "../../api/SubmissionService";
import { setEligibilitySubcategory, setFormSpecificInfo } from "../../redux/submissionSlice";
import YesNoChoiceComponent from "../YesNoChoice";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "../../redux/store";
import { useId } from "react";
import { makeStyles } from "tss-react/mui";

const useStyles = makeStyles()({
  dropdown: {
    margin: "2px 0",
  },
  mobileDropdown: {
    margin: "0 24px",
  },
  alertModalParagraph: {
    marginTop: "1rem",
  },
  alertModalButtons: {
    display: "flex",
    marginTop: "2rem",
    alignContent: "center",
  },
  textInputLabel: {
    display: "flex",
    flexDirection: "column-reverse",
    marginTop: "32px",
  },
});

const I485SubTypeSelection = () => {

  const {
    submissionId,
    formType,
    formSpecificInfo
  } = useSelector((state: RootState) => state.submission);

  const dispatch = useAppDispatch();
  const { myUscisId, userGroupId, isApplicantOrRep } = useSelector((state: RootState) => state.user)
  const subTypeSelectionId = useId();
  const { classes } = useStyles();

  const handleSubTypeSelection = async (value: boolean) => {
    const updatedFormSpecificInfo = { ...formSpecificInfo, isFamilyBased: value, formType };
    try {

      const updatedSubmission = await SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        updatedFormSpecificInfo,
      );

      await SubmissionService.updateEligibility(
        updatedSubmission.myUscisId,
        updatedSubmission.submissionId,
        updatedSubmission.eligibilityCategory,
        undefined,
        updatedSubmission.benefitTypeCode,
        updatedSubmission.applicationReasonCode,
        updatedSubmission.formType,
        userGroupId,
      )

      dispatch(setEligibilitySubcategory(undefined))
      dispatch(setFormSpecificInfo(updatedFormSpecificInfo))
    } catch (error) {
      console.error(error)
    }
  }

  return (<div style={{ margin: "2rem 0 3rem 0" }}>
    <Typography variant="h6">
      Are you filing Family Based?
    </Typography>
    <YesNoChoiceComponent
      direction="column"
      radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
      radioLabelId={subTypeSelectionId}
      classes={classes}
      choiceText=""
      label={["Yes", "No"]}
      choiceTextVariant="h5"
      alignment={"flex-start"}
      value={formSpecificInfo?.isFamilyBased ? "Yes" : "No"}
      handleOnChange={(event) =>
        handleSubTypeSelection(event.target.value === "Yes")
      }
    />
  </div>
  )
}
export default I485SubTypeSelection;