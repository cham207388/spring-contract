import { Typography } from "myuscis-material";
import { SubmissionService } from "../../api/SubmissionService";
import { setFormSpecificInfo } from "../../redux/submissionSlice";
import YesNoChoiceComponent from "../YesNoChoice";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "../../redux/store";
import { useId } from "react";
import { makeStyles } from "tss-react/mui";


const useStyles = makeStyles()({
  dropdown: {
    margin: "2px 0",
  },
  mobileDropdown: {
    margin: "0 24px",
  },
  alertModalParagraph: {
    marginTop: "1rem",
  },
  alertModalButtons: {
    display: "flex",
    marginTop: "2rem",
    alignContent: "center",
  },
  textInputLabel: {
    display: "flex",
    flexDirection: "column-reverse",
    marginTop: "32px",
  },
  questionTextLabel: {
    fontWeight: "bold",
    lineHeight: "1.15",
    color: "black"
  },
});

const I485MilitaryVetSelection = () => {

  const {
    submissionId,
    formType,
    formSpecificInfo
  } = useSelector((state: RootState) => state.submission);
    
  const dispatch = useAppDispatch();
  const { myUscisId } = useSelector((state: RootState) => state.user)
  const isMilitaryVetId = useId();
  const { classes } = useStyles();

  const handleIsMilitaryVeteranSelection = async (value: boolean) => {
      const updatedFormSpecificInfo = { ...formSpecificInfo, isMilitaryVeteran: value, formType };

    try {
      await SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        updatedFormSpecificInfo,
      );

      dispatch(setFormSpecificInfo(updatedFormSpecificInfo))
    } catch (error) {
      console.error(error)
    }
  }

  return (<div style={{ margin: "2rem 0 3rem 0" }}>
        <Typography variant="h6" className={classes.questionTextLabel}>
            Are you filing as an applicant who served honorably on active duty in the U.S. armed forces and who is filing under INA section 101(a)(27)(K). Select Part 2., Item Number 3.c.: Certain U.S. Armed Forces Members (also known as the Six and Six program)?
        </Typography>
        <YesNoChoiceComponent
          direction="column"
          radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
          radioLabelId={isMilitaryVetId}
          classes={classes}
          choiceText=""
          label={["Yes", "No"]}
          choiceTextVariant="h5"
          alignment={"flex-start"}
          value={formSpecificInfo?.isMilitaryVeteran ? "Yes" : "No"}
          handleOnChange={(event) =>
            handleIsMilitaryVeteranSelection(event.target.value === "Yes")
          }
        />
      </div>
    )
}
export default I485MilitaryVetSelection;