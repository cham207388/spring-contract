import {
  Typography,
  Box,
  Checkbox,
  CheckboxGroup,
} from "myuscis-material";
import USCISDivider from "../shared/USCISDivider";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "../../redux/store";
import { setFormSpecificInfo } from "../../redux/submissionSlice";
import { SubmissionService } from "../../api/SubmissionService";
import { FormSpecificInfo } from "../../types/Submission";
import { FormTypes } from "../../types/FormMetaData";

export type CheckboxEligibilitySubcategory = {
  category: string;
  label: string;
  disabled: boolean;
  checked: boolean;
};

type props = {
  selectedFormType: string;
};

const I485ACheckboxes = ({ selectedFormType }: props) => {
  const {
    formSpecificInfo,
    submissionId,
    forms,
    formType
  } = useSelector((state: RootState) => state.submission);
  const { myUscisId } = useSelector((state: RootState) => state.user);
  const dispatch = useAppDispatch();
  const concurrentFormSpecificInfo = forms.find((form) => form.formType === selectedFormType)!.formSpecificInfo;

  const handleCheckbox = async (value: FormSpecificInfo) => {
    value.formType = FormTypes.I485A;
    try {
      await SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        create485AFormSpecificInfo(value)
      );

      dispatch(setFormSpecificInfo(value))
    } catch (error) {
      console.error(error)
    }
  }

  const create485AFormSpecificInfo = (specificInfo: FormSpecificInfo) => {
    return {
      formType : FormTypes.I485A,
      isApplicantUnder17Unmarried : specificInfo.isApplicantUnder17Unmarried,
      isSpouseOfLegalizedAlien : specificInfo.isSpouseOfLegalizedAlien,
      isUnmarriedChildUnder21 : specificInfo.isUnmarriedChildUnder21
    }
  }

  return (
    <>
      <USCISDivider />

      <Box display="flex" flexDirection="column" gap={0} sx={{ paddingTop: "0px", paddingBottom: "5px" }}>
        <Typography variant="h6">
          Select all that apply:
          <br />
          I am:
        </Typography>
        <CheckboxGroup >
          <Checkbox
            single
            label={"An unmarried child under 17 years of age"}
            checked={formType === selectedFormType ? formSpecificInfo?.isApplicantUnder17Unmarried
                    : forms.find((form) => form.formType === selectedFormType)!.formSpecificInfo?.isApplicantUnder17Unmarried}
            onChange={(event, checked) => handleCheckbox({ ...(formType === selectedFormType ? formSpecificInfo : concurrentFormSpecificInfo)
                    ?? { formType }, isApplicantUnder17Unmarried: checked }) ?? false} />
        </CheckboxGroup>
        <CheckboxGroup >
          <Checkbox
            single
            label={"The spouse of a legalized alien who filed a pending or approved Form I-817, Application for Family Unity Benefits"}
            checked={formType === selectedFormType ? formSpecificInfo?.isSpouseOfLegalizedAlien
                    : forms.find((form) => form.formType === selectedFormType)!.formSpecificInfo?.isSpouseOfLegalizedAlien ?? false}
            onChange={(event, checked) => handleCheckbox({ ...(formType === selectedFormType ? formSpecificInfo : concurrentFormSpecificInfo)
                    ?? { formType }, isSpouseOfLegalizedAlien: checked })} />
        </CheckboxGroup>
        <CheckboxGroup >
          <Checkbox
            single
            label={"An unnmarried child under 21 years of age, of a legalized alien who filed a pending or approved Form I-817, Application for Family Unity Benefits"}
            checked={formType === selectedFormType ? formSpecificInfo?.isUnmarriedChildUnder21
                    : forms.find((form) => form.formType === selectedFormType)!.formSpecificInfo?.isUnmarriedChildUnder21}
            onChange={(event, checked) => handleCheckbox({ ...(formType === selectedFormType ? formSpecificInfo : concurrentFormSpecificInfo)
                    ?? { formType }, isUnmarriedChildUnder21: checked }) ?? false} />
        </CheckboxGroup>
      </Box>

    </>
  );
};

export default I485ACheckboxes;
