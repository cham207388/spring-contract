import React from "react";
import {
  Button,
  Divider,
  ListSubheader,
  Menu,
  MenuItem,
} from "@mui/material";
import {
  faCaretDown,
  faCaretUp,
  faUpRightFromSquare,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { makeStyles } from "tss-react/mui";

import { useDispatch, useSelector } from "react-redux";
import {
  setShowLogoutConfirmationDialog,
} from "../../../redux/userSlice";
import { RootState } from "../../../redux/store";


const useStyles = makeStyles()((_theme) => ({
  navButton: {
    backgroundColor: _theme.palette.background.default,
    fontWeight: _theme.typography.fontWeightRegular,
    color: _theme.palette.primary.dark,
    fontSize: "18px",
    lineHeight: "24px",
    border: "none",
    padding: 0,
    maxWidth: "120px",
    "&:hover": {
      fontWeight: _theme.typography.fontWeightMedium,
      textDecoration: "underline"
    },
    "&:focus": {
      border: "none",
      outline: "3px solid #1D89BF",
      borderRadius: "2px",
      background: "none",
    },
  },
  popoverPaper: {
    backgroundColor: _theme.palette.background.default,
    width: "fit-content",
    overflowY: "scroll",
    borderRadius: 0,
  },
  divider: {
    borderWidth: "1.5px",
    borderColor: "#EBEBEB",
  },
  menuItem: {
    padding: "8px 20px",
    width: "100%",
    height: "100%",
    fontSize: "18px",
    lineHeight: "24px",
    color: _theme.palette.primary.main,
    textDecoration: "none",
  },
  icon: {
    paddingLeft: 8,
    color: _theme.palette.primary.dark,
  },
}));

interface NavLink {
  name: string;
  url: (id?: string) => string;
  newPage?: boolean;
  userRole?: string;
}

interface NavLinks {
  title: string;
  links: NavLink[];
}

interface NavMenuProps {
  label: string;
  links: NavLinks[];
  roleSpecificLinks?: NavLink[];
}



const NavMenu = ({ label, links, roleSpecificLinks }: NavMenuProps) => {

  const dispatch = useDispatch();

  const { classes } = useStyles();
  const userGroupId = useSelector((state: RootState) => state.user.userGroupId);

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const showLogoutDialog = () => {
    handleClose();
    dispatch(setShowLogoutConfirmationDialog(true));
  };

  const navMenuLinks = (navLinks? : NavLink[] ) => {
    if (!navLinks) return [];
    return (
          navLinks.map(
            (link: NavLink) => (
              <MenuItem
                className={classes.menuItem}
                onClick={handleClose}
                key={link.name}
                component="a"
                href={link.url(userGroupId)}
              >
                {link.name}
                {
                  link.newPage &&
                    (
                        <FontAwesomeIcon
                          icon={faUpRightFromSquare}
                          style={{ marginLeft: "4px" }}
                        />
                    )
                }
              </MenuItem>
            )
          )
    )
  }

  const navMenuSubheaders = (navMenuSublinks : NavLinks[]) => {
    return navMenuSublinks.map((link, idx) => (
      [
        <ListSubheader className={classes.menuItem}>
          {link.title}
        </ListSubheader>
        ,
        navMenuLinks(link.links),
        idx < links.length - 1 && <Divider className={classes.divider} />
      ]
    ))
  }

  const roleSpecificLinksNavMenu = (roleSpecificLinks?: NavLink[] ) => {
    if (!roleSpecificLinks) return [];
    return (
      [
            navMenuLinks(roleSpecificLinks),
            <Divider className={classes.divider} />
      ]
    );
  }

  const userSignOutLinksNavMenu = (roleSpecificLinks?: NavLink[] ) => {
    if (!roleSpecificLinks) return [];
    return (
      [
        <Divider className={classes.divider} />,
        <MenuItem className={classes.menuItem} onClick={showLogoutDialog} component="button">
          Sign Out
        </MenuItem>
      ]
    );
  }

return (
    <div>
      <Button
        id="basic-button"
        className={classes.navButton}
        aria-controls={open ? 'grouped-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
      >
        {label}
        <FontAwesomeIcon
          className={classes.icon}
          icon={anchorEl ? faCaretUp : faCaretDown}
        />
      </Button>
      <Menu
        id="grouped-menu"
        anchorEl={anchorEl}
        open={ open}
        onClose={handleClose}
        slotProps={{
          list: {
            'aria-labelledby': 'basic-button',
            sx: {
              py: 0,
            },
          },
        } as any}
      >
        {
          [
            ...roleSpecificLinksNavMenu(roleSpecificLinks),
            ...navMenuSubheaders(links),
            ...userSignOutLinksNavMenu(roleSpecificLinks)
          ]
        }
      </Menu>
    </div>
  );
};

export default NavMenu;
