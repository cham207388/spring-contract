import React, { useState } from "react";
import {
  Divider,
  Typography,
  Stack,
  Button,
  MenuItem,
  Menu,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Link,
} from "@mui/material";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faBars,
  faChevronDown,
  faClose,
  faUpRightFromSquare,
  faUserCircle,
} from "@fortawesome/free-solid-svg-icons";
import { makeStyles } from "tss-react/mui";

import { SharedLayoutProps } from "../../Layout/Layout";
import {
  applicantAccountSpecificActions,
  allLinks,
} from "../../../constants/NavLinks";
import { useDispatch, useSelector } from "react-redux";
import { setShowLogoutConfirmationDialog } from "../../../redux/userSlice";
import { RootState } from "../../../redux/store";

const useStyles = makeStyles<{ isMobile: boolean | undefined }>()(
  (_theme, { isMobile }) => ({
    menu: {
      fontSize: "18px",
      color: _theme.palette.primary.dark,
      fontWeight: _theme.typography.fontWeightMedium,
    },
    navButton: {
      backgroundColor: _theme.palette.background.default,
      fontWeight: _theme.typography.fontWeightRegular,
      color: _theme.palette.primary.dark,
      fontSize: "18px",
      lineHeight: "24px",
      border: "none",
      cursor: "pointer",
      padding: 0,
      minWidth: "130px",
      "&:hover": {
        fontWeight: _theme.typography.fontWeightBold,
      },
      "&:focus": {
        border: "3px solid #1D89BF",
        borderRadius: "2px",
      },
    },
    hamburgerMenu: {
      gap: "8px",
      display: isMobile ? "flex" : "none",
      minWidth: "130px",
      alignItems: "center",
      padding: "4px 4px 0",
    },
    popoverPaper: {
      backgroundColor: _theme.palette.background.default,
      padding: 0,
      boxShadow: "none",
      top: "130px !important",
      width: "100%",
      left: "0 !important",
      right: "0 !important",
      maxWidth: "unset",
      overflowY: "scroll",
      borderRadius: 0,
      maxHeight: "unset",
    },
    accordion: {
      padding: 0,
      margin: 0,
      boxShadow: "none",
      border: "none",
      borderBottom: "3px solid #EBEBEB",
      "&::before": { height: 0 },
    },
    linkSectionTitle: {
      fontSize: "16px",
      fontWeight: _theme.typography.fontWeightMedium,
      color: _theme.palette.primary.dark,
    },
    link: {
      color: _theme.palette.primary.dark,
      fontSize: "16px",
      textDecoration: "none",
    },
    divider: {
      borderWidth: "1.5px",
      borderColor: "#EBEBEB",
    },
    menuItem: {
      padding: "8px 16px",
      margin: 0,
      "&:hover": { background: "none" },
    },
  }),
);

const MobileMenu = ({ isMobile }: SharedLayoutProps) => {
  const userGroupId = useSelector((state: RootState) => state.user.userGroupId);

  const { classes } = useStyles({ isMobile });

  const [anchorElNav, setAnchorElNav] = useState<null | HTMLElement>(null);

  const handleOpenNavMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const dispatch = useDispatch();

  const showLogoutDialog = () => {
    handleCloseNavMenu();
    dispatch(setShowLogoutConfirmationDialog(true));
  };

  return (
    <Stack>
      <Button
        disableRipple
        className={`${classes.navButton} ${classes.hamburgerMenu}`}
        aria-label="mobile navigation menu"
        aria-controls="menu-appbar"
        aria-haspopup="true"
        onClick={handleOpenNavMenu}
      >
        <FontAwesomeIcon icon={anchorElNav ? faClose : faBars} size="xl" />
        <Typography className={classes.menu}>
          {anchorElNav ? "Close" : "Menu"}
        </Typography>
      </Button>

      <Menu
        id="menu-appbar"
        anchorEl={anchorElNav}
        PopoverClasses={{ paper: classes.popoverPaper }}
        open={Boolean(anchorElNav)}
        onClose={handleCloseNavMenu}
        sx={{
          borderRadius: "none",
          overflow: "scroll",
          display: isMobile ? "inherit" : "none",
        }}
      >
        <Divider className={classes.divider} />
        <Stack
          sx={{ padding: "8px 16px" }}
          direction="row"
          alignItems="center"
          gap={1}
        >
          <FontAwesomeIcon
            icon={faUserCircle}
            className={classes.linkSectionTitle}
          />
          <Typography className={classes.linkSectionTitle}>
            My Account
          </Typography>
        </Stack>
        {applicantAccountSpecificActions.map((link) => (
          <MenuItem
            key={link.name}
            onClick={handleCloseNavMenu}
            sx={{ padding: "8px 40px" }}
          >
            <Link href={link.url(userGroupId)} className={classes.link}>
              {link.name}
            </Link>
          </MenuItem>
        ))}
        <Divider className={classes.divider} />

        {allLinks.map((link, idx) => (
          <Accordion className={classes.accordion} key={link.title + idx}>
            <AccordionSummary
              expandIcon={<FontAwesomeIcon icon={faChevronDown} />}
              aria-controls={`panel${idx}a-content`}
              id={`panel${idx}a-header`}
              className={classes.menuItem}
            >
              <Typography className={classes.linkSectionTitle}>
                {link.title}
              </Typography>
            </AccordionSummary>
            {link.links.map((l) => (
              <AccordionDetails sx={{ margin: 0, border: "none" }} key={l.name}>
                <MenuItem
                  key={l.name}
                  onClick={handleCloseNavMenu}
                  className={classes.menuItem}
                >
                  <Link
                    href={l.url()}
                    target={l.newPage ? "_blank" : "_self"}
                    className={classes.link}
                  >
                    {l.name}{" "}
                    {l.newPage && (
                      <FontAwesomeIcon
                        icon={faUpRightFromSquare}
                        style={{ marginLeft: "4px" }}
                      />
                    )}
                  </Link>
                </MenuItem>
              </AccordionDetails>
            ))}
          </Accordion>
        ))}
        <MenuItem onClick={showLogoutDialog}>
          <Link className={classes.link}>Sign Out</Link>
        </MenuItem>
      </Menu>
    </Stack>
  );
};

export default MobileMenu;
