import { AppBar, Button, Container, Divider, Stack } from "@mui/material";
import { Link as RouterLink } from "react-router-dom";
import { makeStyles } from "tss-react/mui";

import { useDispatch, useSelector } from "react-redux";
import { AccountAction, allLinks, resourceLinks } from "../../constants/NavLinks";
import { RootState } from "../../redux/store";
import { SharedLayoutProps } from "../Layout/Layout";
import Logo from "../shared/Logo/Logo";
import MobileMenu from "./MobileMenu/MobileMenu";
import NavMenu from "./NavMenu/NavMenu";

import {
  setShowLogoutConfirmationDialog,
  AccountTypes,
} from "../../redux/userSlice";

import {
  applicantAccountSpecificActions,
  repAccountSpecificActions,
} from "../../constants/NavLinks";

const useStyles = makeStyles()((_theme) => ({
  body: {
    backgroundColor: _theme.palette.background.default,
    position: "relative",
    paddingTop: "7px",
    paddingBottom: "7px"
  },
  container: {
    maxWidth: "1064px",
    display: "flex",
    alignItems: "center",
    margin: "0 auto",
    justifyContent: "space-between",
  },
  navButton: {
    backgroundColor: _theme.palette.background.default,
    fontWeight: _theme.typography.fontWeightRegular,
    color: _theme.palette.primary.dark,
    fontSize: "18px",
    lineHeight: "24px",
    border: "none",
    cursor: "pointer",
    padding: 0,
    "&:hover": {
      fontWeight: _theme.typography.fontWeightMedium,
    },
    "&:focus": {
      border: "3px solid #1D89BF",
      borderRadius: "2px",
    },
  },
  buttonGroup: {
    padding: "28px 0 0 24px" 
  },
  signout: {
    fontWeight: _theme.typography.fontWeightMedium,
    "&:hover": {
      fontWeight: "underline",
    },
    color: _theme.palette.primary.dark,
    fontSize: "18px",
  },
}));

const Navbar = ({ isMobile }: SharedLayoutProps) => {
  const { classes } = useStyles();

  const dispatch = useDispatch();

  const confirmLogout = () => {
    dispatch(setShowLogoutConfirmationDialog(true));
  };

  const accountType = useSelector((state: RootState) => state.user.accountType);
  const accountLinks = allLinks.filter(
    (l) => l.title === "Account Actions" && l.userRole === accountType,
  );

  const accountSpecificLinks: AccountAction[] = accountType === AccountTypes.APPLICANT
    ? applicantAccountSpecificActions
    : repAccountSpecificActions;

  return (
    <AppBar position="static" className={classes.body}>
      <Container className={classes.container}>
        <RouterLink to="/">
          <Logo variant="header" />
        </RouterLink>
        <MobileMenu isMobile={isMobile} />
        <Stack
          direction="row"
          alignItems="center"
          spacing={3}
          sx={{
            display: isMobile ? "none" : "flex"
          }}
          className={classes.buttonGroup}
        >
          <Stack direction="row" alignItems="center" spacing={4}>
            <NavMenu
              label="My Account"
              links={accountLinks}
              roleSpecificLinks={accountSpecificLinks}
            />
            <NavMenu
              label="Resources"
              links={resourceLinks}
            />
          </Stack>
          <Divider orientation="vertical" flexItem />
          <Button
            disableFocusRipple
            onClick={confirmLogout}
            className={classes.navButton}
            sx={{ textDecoration: "none", minWidth: "70px" }}
          >
            Sign Out
          </Button>
        </Stack>
      </Container>
    </AppBar>
  );
};

export default Navbar;
