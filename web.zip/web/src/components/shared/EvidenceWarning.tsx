import { AlertVariant } from "myuscis-material";
import AlertWindow from "./AlertWindow";
import { PropsWithChildren, ReactElement } from "react";
import Markdown from "react-markdown";

const EVIDENCE_MISSING_MESSAGE =
  "It does not appear that you have uploaded any evidence. USCIS recommends you provide evidence to support your application. Failure to provide required evidence may delay processing of your application.";
const EVIDENCE_MISSING_TITLE = "Missing Evidence";

const CopyParagraph = (props: PropsWithChildren) => {
  const { children, ...inputs } = props;
  return <p {...inputs}>{children}</p>;
};

export const EvidenceWarning = (props: {
  variant?: AlertVariant;
  header?: string;
  message?: string | ReactElement;
}) => (
  <AlertWindow
    variant={props.variant || "warning"}
    headerText={props.header || EVIDENCE_MISSING_TITLE}
  >
    {typeof props.message === "string" ? (
      <Markdown>{props.message}</Markdown>
    ) : (
      props.message || EVIDENCE_MISSING_MESSAGE
    )}
  </AlertWindow>
);
