import { Button } from "myuscis-material";
import { AcceptedMimeTypes, DropzoneProps } from "../../types/Dropzone";
import AlertWindow from "./AlertWindow";
import { useRouteNavigator } from "../../hooks/useRouteNavigator";
import AcceptedFormTypes from "../../constants/AcceptedFormTypes";

export const getFileTypeString = (
  accept: Partial<Record<AcceptedMimeTypes, string[]>>,
): string => {
  const fileTypeStrings: string[] = [];

  Object.entries(accept).forEach(([fileTypeCollection, fileTypes]) => {
    fileTypes.forEach((fileType: string) => {
      fileTypeStrings.push(fileType.toUpperCase().replace(/\W/g, ""));
    });
  });

  fileTypeStrings.sort();

  const lastCommaRegex = /,(?!.*,)/;
  return fileTypeStrings.join(", ").replace(lastCommaRegex, " or");
};

const OtherFileRequirements = ({
  maxFiles,
  accept,
  isFeeWaiverSupport,
}: Pick<DropzoneProps, "maxFiles" | "accept" | "isFeeWaiverSupport">) => {
  return (
    <>
      <h3>File upload requirements</h3>
      <ul>
        <li>Clear and readable.</li>
        <li>Accepted file formats: {getFileTypeString(accept)}</li>
        <li>No encrypted or password-protected files.</li>
        <li>
          If your documents are in a foreign language, upload a full English
          translation and the translator&apos;s certification with each original
          document.
        </li>
        {maxFiles > 1 && <li>Upload no more than 5 documents at a time.</li>}
        <li>
          Accepted file name characters: English letters, numbers, spaces,
          periods, hyphens, underscores, and parentheses.
        </li>
        <li>Maximum size: 12MB per file.</li>
      </ul>
      <AlertWindow variant="information">
        If any password protected documents are uploaded, your case may be
        rejected, as we will not be able to view the evidence you submitted.
      </AlertWindow>
    </>
  );
};

export default OtherFileRequirements;

export const PrimaryFormFileRequirements = ({
  maxFiles,
  accept,
  formType
}: Pick<DropzoneProps, "maxFiles" | "accept" | "isFeeWaiverSupport"> & {
  formType: string
}) => {
  const { routeTo } = useRouteNavigator();

  const getAdditionalEvidenceLink = (formType: string) => {
    let evidenceUrlName : string;
    switch (formType) {
      case AcceptedFormTypes.I_129H1B: 
        evidenceUrlName = "additional-evidence-i129";
        break;
      case AcceptedFormTypes.I_129E: 
      case AcceptedFormTypes.I_129TN: 
      case AcceptedFormTypes.I_129R:
        evidenceUrlName = "additional-evidence-i129tn-e-r";
        break;
      default:
        evidenceUrlName = "additional-evidence";
    }
    return `${evidenceUrlName}/${formType}/evidence`;
  }

  return (
    <>
      <h3>File upload requirements</h3>
      <ul>
        <li>Clear and readable.</li>
        <li>Accepted file formats: {getFileTypeString(accept)}</li>
        <li>No encrypted or password-protected files.</li>
        <li>
          If your documents are in a foreign language, upload a full English
          translation and the translator&apos;s certification with each original
          document. This evidence cannot be uploaded in this section and should 
          be uploaded in the
          <Button
            sx={{
              padding: "0",
              paddingLeft: "4px",
              margin: "0 !important",
              backgroundColor: "white",
                "&:hover": {
                  backgroundColor: "white"
                }
            }}
            variant="text"
            onClick={() => routeTo(getAdditionalEvidenceLink(formType))}
          >
            Additional Evidence
          </Button>
          {" "}
          section.
        </li>
        {maxFiles > 1 && <li>Upload no more than 5 documents at a time.</li>}
        <li>
          Accepted file name characters: English letters, numbers, spaces,
          periods, hyphens, underscores, and parentheses.
        </li>
        <li>Maximum file size: 12MB</li>
      </ul>
    </>
  );
};

export const FileRequirementsNoAdditionalEvidence = ({
  maxFiles,
  accept,
}: Pick<DropzoneProps, "maxFiles" | "accept" | "isFeeWaiverSupport">) => {
  return (
    <>
      <h3>File upload requirements</h3>
      <ul>
        <li>Clear and readable.</li>
        <li>Accepted file formats: {getFileTypeString(accept)}</li>
        <li>No encrypted or password-protected files.</li>
        <li>
          If your documents are in a foreign language, upload a full English
          translation and the translator&apos;s certification with each original
          document.
        </li>
        {maxFiles > 1 && <li>Upload no more than 5 documents at a time.</li>}
        <li>
          Accepted file name characters: English letters, numbers, spaces,
          periods, hyphens, underscores, and parentheses.
        </li>
        <li>Maximum file size: 12MB</li>
      </ul>
      <p>If any password protected documents are uploaded, your case may be rejected, as we will not be able to view the evidence you submitted.</p>
    </>
  );
};

