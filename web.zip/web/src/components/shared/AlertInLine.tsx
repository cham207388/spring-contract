import { PropsWithChildren } from "react";
import { AlertVariant } from "myuscis-material";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCheckCircle,
  faExclamationCircle,
  faExclamationTriangle,
  faInfoCircle,
  IconDefinition,
} from "@fortawesome/free-solid-svg-icons";

interface AlertInLineProps {
  variant: AlertVariant;
  alertMessage: string;
  alertTitle: string;
}
const variantColor: Record<AlertVariant, string> = {
  error: "#CC3333",
  warning: "#FFB500",
  success: "#006600",
  information: "#003366",
};

const faIcon: Record<AlertVariant, IconDefinition> = {
  error: faExclamationCircle,
  warning: faExclamationTriangle,
  success: faCheckCircle,
  information: faInfoCircle,
};

const AlertInLine = ({
  alertTitle,
  alertMessage,
  variant,
  children,
}: PropsWithChildren<AlertInLineProps>) => {
  const iconText = {
    error: "alert",
    success: "success",
    warning: "caution",
    information: "important information",
  };
  const iconAltText = `${iconText[variant]} icon`;
  return (
    <div role="alert" aria-live="assertive">
      <p>
        <FontAwesomeIcon
          style={{
            marginRight: "5px",
            color: variantColor[variant],
          }}
          icon={faIcon[variant]}
          title={iconAltText}
          titleId="icon-text"
        />
        <b>{alertTitle}</b> {alertMessage}
      </p>
    </div>
  );
};

export default AlertInLine;
