import { faCircleInfo, IconDefinition } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { ComponentProps, PropsWithChildren } from "react";
import Markdown, { Options } from "react-markdown";

type MarkdownWithLinksProps = Options;

const iconMap: Record<string, IconDefinition>= {
  "fa-info": faCircleInfo,
}

export default function MarkdownWithLinks(props: MarkdownWithLinksProps) {
  const { children, ...rest } = props;
  return (
    <Markdown
      components={{
        a({ node, children, ...props }) {
          return <ContentLink {...props}>{children}</ContentLink>;
        },
        p({node, children, ...props}) {
          return <p {...props}>{renderWithIcons(children)}</p>
        },
        li: ({ children, ...props }) => {
          // Force react-markdown to always render list as a loose list
          const firstChild = React.Children.toArray(children)[0];
          const isAlreadyP = React.isValidElement(firstChild) && 
            (firstChild.type === 'p' || (firstChild.type as any).name === 'p');
          // Default
          if (isAlreadyP) {
            return <li {...props}>{children}</li>;
          }
          //  For list with single item, inject p element to force loose list
          return (
            <li {...props}>
              <p>{renderWithIcons(children)}</p>
            </li>
          );
        }
      }}
      {...rest}
    >
      {children}
    </Markdown>
  );
}

export function ContentLink(props: ComponentProps<"a"> & PropsWithChildren) {
  const { children, ...rest } = props;
  return (
    <a
      target="_blank"
      rel="noopener noreferrer"
      style={{ color: "#006699" }}
      {...rest}
    >
      {children}
    </a>
  );
}

function transformTextWithIcons(text: string){
  const parts = text.split(/:(fa-[a-z0-9-]+):/gi);
 
  return parts.map((part, idx) => {
    const icon = iconMap[part];
    if(!icon) return part;

    return(
      <FontAwesomeIcon
        key={idx}
        icon={icon}
        style={{color: "#006699", fontSize: "16px"}}
      />
    );
  })
}

function renderWithIcons(children: React.ReactNode) {
  const arr = React.Children.toArray(children);

  return arr.map((child) => {
    if (typeof child === "string"){
      return transformTextWithIcons(child);
    }
    return child;
  })
}

