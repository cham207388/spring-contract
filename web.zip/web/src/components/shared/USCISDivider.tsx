import { Divider } from "@mui/material";
import { styled } from "@mui/material/styles";

const StyledDivider = styled(Divider)({
  borderColor: "#A6D7FF",
  margin: "56px 0",
});

const USCISDivider = () => <StyledDivider />;

export default USCISDivider;
