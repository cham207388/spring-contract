import { ComponentPropsWithoutRef } from "react";
import RoundLogo from "../round-logo.svg";

interface LogoProps extends ComponentPropsWithoutRef<"img"> {
  variant: "header" | "footer" | "compact" | "round";
}

const Logo = ({ variant, ...rest }: LogoProps) => {
  let renderedLogo;

  switch (variant) {
    case "header":
      renderedLogo = (
        <img
          src="/pdf-intake/logo.svg"
          alt="U.S. Citizenship and Immigration Services, Upholding America's Promise"
          height={75}
          width={220}
          {...rest}
        />
      );
      break;
    case "footer":
      renderedLogo = (
        <img
          src="/pdf-intake/logo.svg"
          alt="U.S. Citizenship and Immigration Services, Upholding America's Promise"
          height={85}
          width={248}
          {...rest}
        />
      );
      break;
    case "compact":
      renderedLogo = (
        <img
          src="/pdf-intake/logo-small.svg"
          alt="U.S. Citizenship and Immigration Services, Upholding America's Promise"
          height={48}
          width={48}
          {...rest}
        />
      );
      break;
    case "round":
      renderedLogo = (
        <img
          src={RoundLogo}
          alt="U.S. Citizenship and Immigration Services, Upholding America's Promise"
          style={{
            position: "absolute",
            top: "-25px",
          }}
        />
      );
  }
  <img
    src="/pdf-intake/logo.svg"
    alt="U.S. Department of Homeland Security Seal, U.S. Citizenship and Immigration Services"
    height={75}
    width={220}
    {...rest}
  />;

  return renderedLogo;
};

export default Logo;
