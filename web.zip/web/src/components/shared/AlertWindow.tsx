import { makeStyles } from "tss-react/mui";
import {
  Alert,
  AlertDescription,
  AlertHeader,
  AlertVariant,
} from "myuscis-material";
import { PropsWithChildren } from "react";
import Markdown from "react-markdown";

interface AlertWindowProps {
  variant: AlertVariant;
  headerText?: string;
  isDialog?: boolean;
}

const useStyles = makeStyles()({
  alertWindowContainer: {
    margin: "32px 0",
  },
  unmarginTop: {
    "& p:first-of-type": {
      marginTop: "0",
    },
  },
});

const StyledParagraph = ({ children }: { children?: any }) => (
  <p style={{ margin: 0 }}>{children}</p>
);

const AlertWindow = ({
  headerText,
  variant,
  isDialog,
  children,
}: PropsWithChildren<AlertWindowProps>) => {
  const { classes } = useStyles();
  return (
    <div
      className={!isDialog ? classes.alertWindowContainer : ``}
      role="alert"
      aria-live="assertive"
    >
      <Alert variant={variant} maxWidthOverride="100%">
        {headerText && (
          <AlertHeader>
            <Markdown
              components={{
                p: StyledParagraph,
              }}
            >
              {headerText}
            </Markdown>
          </AlertHeader>
        )}
        <AlertDescription className={headerText ? "" : classes.unmarginTop}>
          {children}
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default AlertWindow;
