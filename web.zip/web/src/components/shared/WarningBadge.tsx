import { makeStyles } from "tss-react/mui";
import ErrorIcon from "@mui/icons-material/Error";
import { Typography } from "myuscis-material";

const useStyles = makeStyles()({
  badgeContainer: {
    display: "flex",
    width: "fit-content",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "6px 12px",
    backgroundColor: "#CC3232",
    borderRadius: "5px",
  },
  badgeElements: {
    color: "white",
    margin: "0px 6px",
  },
});

type WarningBadgeProps = {
  expirationDate: string;
};

export const WarningBadge = ({ expirationDate }: WarningBadgeProps) => {
  const { classes } = useStyles();

  return (
    <div className={classes.badgeContainer}>
      <ErrorIcon className={classes.badgeElements} />
      <Typography className={classes.badgeElements}>
        {expirationDate}
      </Typography>
    </div>
  );
};
