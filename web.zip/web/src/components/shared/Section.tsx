import { styled } from "@mui/material/styles";
import { ComponentProps, PropsWithChildren } from "react";

const fontFamily = "SourceSansProRegular,Source Sans Pro,sans-serif";
const h1FontFamily =
  "Source Sans Pro Light,SourceSansProRegular,Source Sans Pro,sans-serif";
export const sectionStyles = {
  marginBottom: "32px",
  "& > *": { marginTop: "0", marginBottom: "16px" },
  "& p, & ol, & ul, & input": {
    font: `normal normal normal 16px/24px ${fontFamily}`,
    margin: '0px 0px 16px 0px',
  },
  "& h2": {
    font: `normal normal bold 32px/32px ${fontFamily}`,
  },
  "& h3": {
    font: `normal normal bold 22px/28px ${fontFamily}`
  },
  "& :not(p):not(ul):not(li):not(h2):not(svg):not(div):not(label):not(b):not(input):not(span *)":
    {
      marginTop: "16px",
      marginBottom: "16px",
    },
  "& h1": {
    font: `normal normal bold 40px ${h1FontFamily}`,
    marginTop: "64px !important",
    marginBottom: "32px !important",
  },
  "& & h2, & h3, & h4, & h5, & h6": { marginBottom: "8px !important" },
  "& h1, & h2, & h3, & h4, & h5, & h6": { fontWeight: "bold", color: "black", lineHeight: "1.15" },
  "& a": { color: "#006699" },
  "& a:hover": { color: "#00476B" },
};
const StyledSection = styled("section")(sectionStyles);

const Section = ({
  children,
  ...rest
}: ComponentProps<"section"> & PropsWithChildren) => {
  return <StyledSection {...rest}>{children}</StyledSection>;
};

export default Section;
