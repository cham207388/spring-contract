import { InputAdornment, Stack, Typography } from "@mui/material";

import { isAxiosError } from "axios";
import {
  Button,
  ButtonSpacer,
  Checkbox,
  DataWrapper,
  FormControlSpacer,
  Grid,
  RedAsterisk,
  TextInput,
} from "myuscis-material";
import { useEffect, useState } from "react";
import { Controller, SubmitHandler, useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { SerializedError } from "../api/axios";
import Section from "../components/shared/Section";
import USCISDivider from "../components/shared/USCISDivider";
import { RootState } from "../redux/store";
import NavigationButtons from "./NavigationButtons";
import AlertWindow from "./shared/AlertWindow";
import { ContentLink } from "./shared/MarkdownWithLinks";
import { ClientService } from "../api/ClientService";
import ClientInformationAlertSnackbar from "./ClientInformationAlertSnackbar";
import { ClientInformation } from "../redux/types/Submission";
import AddClientLoadingDialog from "./Dialogs/AddClientLoadingDialog";
import { useClientInformation } from "../hooks/useClientInformation";
import LowerEnvTestControls from "../pages/before-you-start/LowerEnvTestControls";
import {
  AddClientFormStatus,
  useAddClientForm,
} from "../hooks/useAddClientForm";

const aNumberHelperText =
  'Provide a 7, 8, or 9-digit number. If your A-Number is fewer than 9 digits, the system will automatically add zero(s) after the "A" and before the first digit so there is a total of 9 digits, for example: A-001234567';

type ClientInfo = {
  firstName: string;
  middleName: string;
  lastName: string;
  aNumber: string;
  dateOfBirth: string;
  emailAddress: string;
  aNumberCheckbox: boolean;
};

const ClientInformationPage = () => {
  useEffect(() => { document.title = 'USCIS | Add Client Information'; }, []);
  const myUscisId = useSelector((state: RootState) => state.user.myUscisId);
  const { submissionId, clientInformation } = useSelector(
    (state: RootState) => state.submission,
  );

  const [aNumberKnown, setANumberKnown] = useState(false);
  const {
    alertVisible,
    dismiss,
    formHasErrors,
    startLoading,
    setSuccess,
    setError,
    status,
  } = useAddClientForm();
  const { clientObjectMissing, clientNotAssociated } = useClientInformation();
  let defaultValues = {};
  if (!clientNotAssociated) {
    defaultValues = {
      firstName: clientInformation?.name?.firstName,
      lastName: clientInformation?.name?.lastName,
    };
  }

  const hasClientInfo = !!clientInformation?.name?.firstName?.trim() || !!clientInformation?.name?.lastName?.trim();

  const {
    control,
    handleSubmit,
    setError: setFormError,
    formState: { errors },
  } = useForm<ClientInfo>({
    mode: "all",
    disabled: !clientNotAssociated,
    defaultValues,
  });

  const onSubmit: SubmitHandler<ClientInfo> = async (data) => {
    startLoading();
    try {
      await ClientService.addClient(myUscisId, submissionId, {
        clientData: {
          emailAddress: data.emailAddress,
          aNumber: data.aNumber,
          dateOfBirth: data.dateOfBirth,
          name: {
            lastName: data.lastName,
            firstName: data.firstName,
            middleName: data.middleName,
          },
        },
      });

      setSuccess();
    } catch (e) {
      if (isAxiosError(e)) {
        const response = e.response as unknown as SerializedError;
        const errorData = response?.data || "";

        if (errorData.includes("email address")) {
          setFormError("emailAddress", {
            type: "manual",
            message: errorData,
          });
          setError("repEmail");
        } else if (
          errorData.includes(
            "A new submission cannot be performed at this time",
          )
        ) {
          setError("clientAlreadyHasApplication");
        } else if (errorData.includes("Client already associated")) {
          setError("clientExists");
        } else if (
          errorData.includes(
            "Client information does not match input on the form",
          )
        ) {
          setError("infoMismatch");
        } else if (
          errorData.includes(
            "account associated with the email cannot be added",
          )
        ) {
          setError("cantAddAccount", errorData);
        } else {
          setError("generic", errorData);
        }
      }
    }
  };

  const NameInstructions = (
    <p>
      Their current legal name is the name on their birth certificate, unless it
      changed after birth by a legal action such as marriage or court order. Do
      not provide any nicknames here.
    </p>
  );



  return (
    <>
      <LowerEnvTestControls />
      <Grid
        container
        columns={12}
        component="form"
        onSubmit={handleSubmit(onSubmit)}
      >
        <AddClientLoadingDialog loading={status.loading} />
        <ClientInformationAlertSnackbar
          showAlert={alertVisible}
          dismiss={dismiss}
          message={status.errorMessage}
          isSuccess={status.isSuccess}
        />
        <Section>
          {clientObjectMissing && (
            <AlertWindow isDialog variant="error">
              <p>
                Add client is currently unavailable. Please try again later.
              </p>
            </AlertWindow>
          )}
          {!hasClientInfo ?
          <Stack
            sx={{
              borderBlock: "1px solid #A6D7FF",
              paddingBlock: "56px",
              "& > h2": {
                marginBlock: "0 8px",
              },
              "& > p": {
                marginBlock: "0 16px",
                ":last-child": {
                  margin: 0,
                },
              },
            }}
          >
            <>
              <h2>About Your New Client</h2>
                <p>
                  Provide you new client&apos;s information to add them to the client list in your account. After addding them you can:
                  <ul>
                    <li>File other forms for this client by online PDF submission;</li>
                    <li>Receive their case statuses and notices; and</li>
                    <li>Respond to their RFE&apos;s.</li>
                  </ul>
                </p>
            </>
          </Stack>
          : 
          <>
              <h2>Information About Your Client</h2>
              <p>
                You must complete all fields with an asterisk (
                <span style={{ color: "red" }}>*</span>) to submit this form.
              </p>
          </>
          }
        </Section>

        <div>
          <DataWrapper
            question={"What is your client's current legal name?"}
            instructions={NameInstructions}
          >
            <FormControlSpacer columns={2}>
              <Controller
                rules={{
                  required: "First name is required",
                  maxLength: {
                    value: 20,
                    message: "First name must be 20 characters or fewer.",
                  },
                }}
                render={({ field }) => (
                  <TextInput
                    {...field}
                    id="first_name"
                    label="Given name (first name)"
                    placeholder="John"
                    maxLength={20}
                    error={!!errors.firstName}
                    errorMessage={errors.firstName?.message}
                    required
                  />
                )}
                name="firstName"
                control={control}
              />
              <Controller
                rules={{
                  maxLength: {
                    value: 20,
                    message: "Middle name must be 20 characters or fewer.",
                  },
                }}
                render={({ field }) => (
                  <TextInput
                    {...field}
                    type="text"
                    id="middle_name"
                    label="Middle name (if applicable)"
                    aria-label="Middle name (if applicable)"
                    maxLength={20}
                    error={!!errors.middleName}
                    errorMessage={errors.middleName?.message}
                  />
                )}
                name="middleName"
                control={control}
              />
              <Controller
                rules={{
                  maxLength: {
                    value: 50,
                    message: "Last name must be 50 characters or fewer.",
                  },
                  required: "Last name is required",
                }}
                render={({ field }) => (
                  <TextInput
                    {...field}
                    id="family_name"
                    label="Family name (last name)"
                    placeholder="Smith"
                    maxLength={50}
                    required
                    error={!!errors.lastName}
                    errorMessage={errors.lastName?.message}
                  />
                )}
                name="lastName"
                control={control}
              />
            </FormControlSpacer>
          </DataWrapper>
        </div>
        {clientNotAssociated && (
          <div>
            <DataWrapper
              question="What is your client's A-number?"
              id="clientANumber"
              noDivider
            >
              <FormControlSpacer columns={1}>
                <Controller
                  name="aNumber"
                  rules={{
                    required: {
                      value: !aNumberKnown,
                      message: "Client A-number is required if known.",
                    },
                    maxLength: {
                      value: 9,
                      message: "A-number must be 9 characters or fewer.",
                    },
                    pattern: {
                      value: /^\d+$/,
                      message: "A-number can only contain numbers.",
                    },
                  }}
                  control={control}
                  render={({ field }) => (
                    <TextInput
                      {...field}
                      ariaLabelledByID="clientANumber"
                      helperText={aNumberHelperText}
                      maxLength={9}
                      disabled={aNumberKnown}
                      aria-disabled={aNumberKnown}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">A-</InputAdornment>
                        ),
                      }}
                      error={!!errors.aNumber}
                      errorMessage={errors.aNumber?.message}
                      maskOptions={{
                        numericOnly: true,
                        blocks: [9],
                      }}
                    >
                      <Checkbox
                        single
                        id="aNumberCheckbox"
                        label="The Client does not know or have their A-Number"
                        checked={aNumberKnown}
                        disabled={!clientNotAssociated}
                        aria-disabled={!clientNotAssociated}
                        onChange={(e) => {
                          setANumberKnown(e.target.checked);
                        }}
                      />
                    </TextInput>
                  )}
                />
              </FormControlSpacer>
            </DataWrapper>
            <DataWrapper
              id="clientDateOfBirth"
              question={
                <Typography
                  variant="h3"
                  component="h3"
                  sx={{ marginBlockStart: "56px" }}
                >
                  What is your client&apos;s date of birth?
                  <RedAsterisk />
                </Typography>
              }
            >
              <FormControlSpacer columns={1}>
                <Controller
                  rules={{
                    required: "Date of Birth is required.",
                  }}
                  render={({ field }) => (
                    <TextInput
                      {...field}
                      type="text"
                      id="clients_date_of_birth_field"
                      ariaLabelledByID="clientDateOfBirth"
                      name="dateOfBirth"
                      error={!!errors.dateOfBirth}
                      errorMessage={errors.dateOfBirth?.message}
                      maskOptions={{
                        alias: "datetime",
                        inputFormat: "mm/dd/yyyy",
                        placeholder: "MM/DD/YYYY",
                        clearMaskOnLostFocus: false,
                        clearIncomplete: true,
                      }}
                      required
                    />
                  )}
                  name="dateOfBirth"
                  control={control}
                />
              </FormControlSpacer>
            </DataWrapper>
          </div>
        )}

        {clientNotAssociated && (
          <div>
            <DataWrapper
              id="clientEmailAddress"
              question="What is your new client's email address?"
              instructions={ClientEmailInstructions(clientInformation)}
              noDivider
            >
              <FormControlSpacer columns={1}>
                <Controller
                  rules={{
                    required: "Email address is required",
                    maxLength: {
                      value: 40,
                      message: "Last name must be 40 characters or fewer.",
                    },
                  }}
                  name="emailAddress"
                  control={control}
                  render={({ field }) => (
                    <TextInput
                      {...field}
                      type="email"
                      id="emailAddress_text"
                      ariaLabelledByID="clientEmailAddress"
                      name="emailAddress"
                      required
                      helperText="Example: user@domain.com"
                      placeholder="johnsmith@example.com"
                      errorMessage={errors.emailAddress?.message}
                      error={!!errors.emailAddress}
                      maxLength={40}
                    />
                  )}
                />
                {formHasErrors && (
                  <AlertWindow
                    variant="error"
                    headerText={errorHeader(status)}
                  >
                    <ErrorTextForClient
                      status={status}
                      clientInformation={clientInformation}
                    />
                  </AlertWindow>
                )}
              </FormControlSpacer>
            </DataWrapper>
          </div>
        )}

        {clientNotAssociated && (
          <ButtonSpacer>
            <Button
              style={{ marginBlockStart: "2rem" }}
              variant="contained"
              size="small"
              role="button"
              aria-label="Add Client"
              disabled={status.clientAdded || !clientNotAssociated}
              aria-disabled={status.clientAdded || !clientNotAssociated}
              type="submit"
            >
              Add Client
            </Button>
          </ButtonSpacer>
        )}
      </Grid>
      {clientNotAssociated && <USCISDivider />}
      <NavigationButtons
        disableNext={!status.clientAdded && clientNotAssociated}
      />
    </>
  );
};

export default ClientInformationPage;

const fileAFormUrlForClient: (
  clientInformation?: ClientInformation,
) => string = (clientInformation?: ClientInformation) => {
  const baseUrl = "/accounts";
  const userGroupId = clientInformation?.userGroupIds[0] ?? "";
  const url = userGroupId ? `${baseUrl}/${userGroupId}/file-form` : baseUrl;
  return url;
};

const fileAFormInstructions = (clientInformation?: ClientInformation) => {
  return (
    <>
      Please return to the&nbsp;
      <ContentLink href={fileAFormUrlForClient(clientInformation)}>
        File A Form
      </ContentLink>{" "}
      page at the beginning of this form to select this client from the client
      list drop menu to complete and submit the form.
    </>
  );
};

const addAClientUrl: (
  clientInformation?: ClientInformation,
) => string = (clientInformation?: ClientInformation) => {
  const baseUrl = "/accounts";
  const userGroupId = clientInformation?.userGroupIds[0] ?? "";
  const url = userGroupId ? `${baseUrl}/${userGroupId}/my-clients/add-a-client` : baseUrl;
  return url;
};

const ClientEmailInstructions = (clientInformation?: ClientInformation) => {
  return (
    <>
        Your new client&apos;s email address must not be connected to any existing USCIS online account.
        <br /><br />
        If your client has an existing USCIS online account, you must first connect your accounts using the
        <ContentLink href={addAClientUrl(clientInformation)}>{" "}
          Add a Client page
        </ContentLink>, then start a new draft for this client.
        <br /><br />
        If you enter an email that does not match, the case will not be linked to your client&apos;s applicant account. 
    </>
  );
};

const errorHeader = (status: AddClientFormStatus) => {
  if (status.informationMismatch) {
    return "Your client has an existing account with this email address"
  }
}

const ErrorTextForClient = ({
  status,
  clientInformation,
}: {
  status: AddClientFormStatus;
  clientInformation?: ClientInformation;
}) => {
  if (status.clientAlreadyHasApplication) {
    return (
      <p>
        {status.errorMessage}&nbsp;
        {fileAFormInstructions(clientInformation)}
      </p>
    );
  }
  if (status.clientAlreadyExists) {
    return (
      <p>
        This client already exists within your client list.&nbsp;
        {fileAFormInstructions(clientInformation)}
      </p>
    );
  }
  if (status.informationMismatch) {
    return (
      <p>
        Your client has an existing USCIS online account. To file a
        form for them, you must first connect your accounts using the
        <ContentLink href={addAClientUrl(clientInformation)}>{" "}
          Add a Client page
        </ContentLink>, select them from the dropdown on the
        File a Form page, then start a new draft for this client.
      </p>
    );
  }
  return <p>{status.errorMessage}</p>;
};
