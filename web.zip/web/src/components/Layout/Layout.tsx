import { useMediaQuery, useTheme } from "@mui/material";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { LogoutDialog } from "../Dialogs/LogoutDialog";
import Footer from "../Footer/Footer";
import Navbar from "../Navbar/Navbar";
import TopBanner from "../TopBanner/TopBanner";
import AlertSnackbar from "../AlertSnackbar";
import ButterBar from "../ButterBar";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import GlobalLoadingDialog from "../Dialogs/GlobalLoadingDialog";
import { useEffect, useMemo } from "react";
import { BetaBanner } from "../../types/FormMetaData";
import { useSteps, Step } from "../../hooks/useSteps";
import { Paths } from "../../router/Paths";
import GlobalBanner from "../GlobalBanner";

export interface SharedLayoutProps {
  isMobile?: boolean;
}

const Layout = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"), { defaultMatches: true });
  const location = useLocation();
  const navigate = useNavigate();
  const steps: Step[] = useSteps().steps;

  const { formMetadata } = useSelector(
    (state: RootState) => state.formMetadata,
  );

  const coreMetaData = useSelector((state: RootState) => state.coreMetadata);
  const user = useSelector((state: RootState) => state.user);

  const bannerInfo: BetaBanner = useMemo(() => {
    const banner = coreMetaData.betaBanners.filter(
      (banner) =>
        banner.showBannerFor === user.accountType &&
        banner.formType === formMetadata.formType,
    );
    
    if (banner.length > 0) {
      return banner[0];
    }
    return {
      showBanner: false,
      formType: "",
      bannerText: "",
      showBannerFor: "",
    };
  }, [coreMetaData, user]);
    const secondaryBanner = coreMetaData.betaBanners[1];

useEffect(() => {
 const pathname = location.pathname;
 // Find a matching step for this route
 const matchingStep = steps.find((s) => pathname.includes(s.id));
 // If route is a disabled step, bounce user back to eligibility selection
 if (matchingStep?.disabled && pathname !== Paths.selectEligibility) {
   navigate(Paths.selectEligibility, { replace: true });
 }
}, [location.pathname, navigate, steps]);

  return (
    <div>
      <div>
        <AlertSnackbar />
        <GlobalLoadingDialog />
        <TopBanner isMobile={isMobile} />
        {secondaryBanner.showBanner && <GlobalBanner bannerText={secondaryBanner.bannerText} />}
        {bannerInfo.showBanner && <ButterBar formType={bannerInfo.formType} />}
        <Navbar isMobile={isMobile} />
        <LogoutDialog />
      </div>
      <main id="content">
        <Outlet />
      </main>
      <Footer isMobile={isMobile} />
    </div>
  );
};

export default Layout;
