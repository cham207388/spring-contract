import React from "react";
import { FormControl, Radio, RadioGroup, Stack } from "@mui/material";
import { makeStyles } from "tss-react/mui";
import { FormControlLabel, InputLabel, Typography } from "myuscis-material";
import { CSSProperties, Variant } from "@mui/material/styles/createTypography";

interface Props {
  radioLabelId?: string;
  classes: any;
  labelOverrideStyle?: any;
  choiceText: string;
  choiceTextVariant: Variant;
  radioStyle?: CSSProperties | undefined;
  direction: "row" | "row-reverse" | "column" | "column-reverse";
  alignment: any;
  label: string[];
  value: any;
  handleOnChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const useStyles = makeStyles()({
  labelText: {
    fontWeight: "bold",
    lineHeight: "1.15",
    color: "black"
  },
});

const YesNoChoiceComponent = ({ label, ...props }: Props) => {

  const { classes } = useStyles();
  
  return (
  <FormControl>
    <Stack direction={props.direction} spacing={1} alignItems={props.alignment}>
      <InputLabel
        id={props.radioLabelId}
        disableAnimation
        shrink={false}
        style={{ maxWidth: "20.4rem" }}
        className={props.classes.label}
        focused={false}
      >
        <Typography variant={props.choiceTextVariant} className={classes.labelText}>
          {props.choiceText}
        </Typography>
      </InputLabel>
      <div style={props.radioStyle || undefined}>
        <RadioGroup
          row
          aria-labelledby={props.radioLabelId}
          name="controlled-radio-buttons-group"
          value={props.value}
          onChange={props.handleOnChange}
          style={{ flexFlow: "unset" }}
        >
          <FormControlLabel
            value={label[0]}
            control={<Radio />}
            label={label[0]}
          />
          <FormControlLabel
            value={label[1]}
            control={<Radio />}
            label={label[1]}
          />
        </RadioGroup>
      </div>
    </Stack>
  </FormControl>
  );
};

export default YesNoChoiceComponent;
