import {
  Card,
  CardContent,
  Divider,
  Link,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import axios, { AxiosError } from "axios";
import { ReactElement } from "react";
import { useRouteError } from "react-router-dom";
import { makeStyles } from "tss-react/mui";
import { LogoutDialog } from "./Dialogs/LogoutDialog";
import Footer from "./Footer/Footer";
import Navbar from "./Navbar/Navbar";
import TopBanner from "./TopBanner/TopBanner";
import Section from "./shared/Section";

// TODO: Flesh out error pages. Get mockups
const useStyles = makeStyles()({
  wrapper: {
    minHeight: "58vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  container: {
    textAlign: "center",
  },
  divider: {
    width: "90%",
    borderColor: "#A6D7FF",
  },
});

function processFormTypeNotFound(
  response: AxiosError["response"],
): { errorTitle: string; errorContent: ReactElement } | undefined {
  if (response && response.data === "") {
    const url = response.config.url as string;
    const regexResult = /api\/intake\/forms\/(.*?)\/metadata/g.exec(url);

    if (regexResult && regexResult.length > 1) {
      const errorTitle = `Form type ${regexResult[1]} not supported.`;
      const errorContent = (
        <>
          <p> The form type you are looking for is not supported </p>
          <p> You should check to make sure the form type is correct. </p>
        </>
      );

      return { errorTitle, errorContent };
    }
  }
}

function processSubmissionNotFound(
  response: AxiosError["response"],
): { errorTitle: string; errorContent: ReactElement } | undefined {
  if (response && response.data === "Submission Not Found") {
    // api/intake/1aedb8d9-dc47-31e2-a9a3-35e371db8058/submissions/9319e6d4-fc9e-38fc-8abc-ccce55d11909
    const url = response.config.url as string;
    const regexResult = /api\/intake\/[\d\w-]+\/submissions\/([\d\w-]+)/g.exec(
      url,
    );

    if (regexResult && regexResult.length > 1) {
      const errorTitle = `Draft ${regexResult[1].substring(0, 8)}... not found.`;
      const errorContent = (
        <>
          <p>
            The Draft submission you are looking for may not exist or it may be
            temporarily unavailable.
          </p>
          <p>
            You should check to make sure the Draft Id is correct or try loading
            the page again in a few minutes.
          </p>
        </>
      );

      return { errorTitle, errorContent };
    }
  }
}
const ErrorBoundary = () => {
  const error = useRouteError() as Error | AxiosError;
  document.title = "USCIS - PDF Intake Error";
  const theme = useTheme();
  const { classes } = useStyles();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"), {
    defaultMatches: true,
  });

  let heading = "Something went wrong";
  let errorTitle = "Something went wrong";
  let errorContent = (
    <>
      <p>
        The page you are looking for may not exist or it may be temporarily
        unavailable.
      </p>
      <p>
        You should check to make sure the webpage address is correct or try
        loading the page again in a few minutes.
      </p>
    </>
  );

  if (axios.isAxiosError(error)) {
    const response = (error as AxiosError).response!;
    heading = `${response.status} Error`;

    const errorMapping =
      processFormTypeNotFound(response) || processSubmissionNotFound(response);
    if (errorMapping) {
      errorTitle = errorMapping.errorTitle;
      errorContent = errorMapping.errorContent;
    }
  }

  return (
    <div>
      <TopBanner isMobile={isMobile} />
      <Navbar isMobile={isMobile} />
      <LogoutDialog />
      <main className={classes.wrapper}>
        <div className={classes.container}>
          <Section>
            <h1>{heading}</h1>
            <Card
              sx={{ minWidth: "50vw", maxWidth: "90vw", paddingBottom: "2rem" }}
            >
              <CardContent>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "space-around",
                    alignItems: "center",
                  }}
                >
                  <Divider
                    className={classes.divider}
                    component="div"
                    role="presentation"
                  >
                    <h2 style={{ marginTop: 0, minWidth: "max-content" }}>
                      {errorTitle}
                    </h2>
                  </Divider>
                </div>
                <Section>{errorContent}</Section>
                <p>
                  <Link href="/">Go to the myUSCIS homepage</Link>
                </p>
              </CardContent>
            </Card>
          </Section>
        </div>
      </main>
      <Footer isMobile={isMobile} />
    </div>
  );
};

export default ErrorBoundary;
