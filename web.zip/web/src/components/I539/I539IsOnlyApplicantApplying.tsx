import { makeStyles } from "tss-react/mui";
import { RootState, useAppDispatch } from "../../redux/store";
import { Typography } from "myuscis-material";
import YesNoChoiceComponent from "../YesNoChoice";
import { useId } from "react";
import { useSelector } from "react-redux";
import USCISDivider from "../shared/USCISDivider";
import { SubmissionService } from "../../api/SubmissionService";
import { setFormSpecificInfo } from "../../redux/submissionSlice";
import AlertWindow from "../shared/AlertWindow";

const useStyles = makeStyles()({
  dropdown: {
    margin: "2px 0",
  },
  mobileDropdown: {
    margin: "0 24px",
  },
  alertModalParagraph: {
    marginTop: "1rem",
  },
  alertModalButtons: {
    display: "flex",
    marginTop: "2rem",
    alignContent: "center",
  },
  textInputLabel: {
    display: "flex",
    flexDirection: "column-reverse",
    marginTop: "32px",
  },
  questionTextLabel: {
    fontWeight: "bold",
    lineHeight: "1.15",
    color: "black"
  },
});

const I539IsOnlyApplicantApplying = () => {

  const {
    submissionId,
    formType,
    formSpecificInfo
  } = useSelector((state: RootState) => state.submission);

  const dispatch = useAppDispatch();
  const { myUscisId } = useSelector((state: RootState) => state.user)

  const isOnlyApplicantApplying = useId();
  const isOnlyApplicantApplyingValue =
    formSpecificInfo?.isOnlyApplicantApplying == undefined ? undefined :
    formSpecificInfo?.isOnlyApplicantApplying ? "Yes" : "No";
  const { classes } = useStyles();

  const handleIsOnlyApplicantApplying = async (key: string, value: boolean) => {
      const updatedFormSpecificInfo = { ...formSpecificInfo, [key]: value, formType };

    try {
      await SubmissionService.updateFormSpecificInfo(
        submissionId,
        myUscisId,
        updatedFormSpecificInfo,
      );

      dispatch(setFormSpecificInfo(updatedFormSpecificInfo))
    } catch (error) {
      console.error(error)
    }
  };

  return (
    <>
      <div style={{ margin: "2rem 0 3rem 0" }}>
        <USCISDivider/>
        <div>
          <Typography variant="h6" className={classes.questionTextLabel}>
            Are you the only applicant applying with this Form? *
          </Typography>
          <YesNoChoiceComponent
            direction="column"
            radioStyle={{ marginLeft: "1rem", marginTop: "1rem" }}
            radioLabelId={isOnlyApplicantApplying}
            classes={classes}
            choiceText=""
            label={["Yes", "No"]}
            choiceTextVariant="h5"
            alignment={"flex-start"}
            value={isOnlyApplicantApplyingValue}
            handleOnChange={(event) =>
              handleIsOnlyApplicantApplying("isOnlyApplicantApplying", event.target.value === "Yes")
            }
          />
        </div>
      </div>

      { isOnlyApplicantApplyingValue === "No" &&
        (
          <AlertWindow
            variant="error"
            headerText={`You must file a paper Form I-539`}
          >
            You must complete and submit a <a href="https://www.uscis.gov/i-539" target="_blank">paper Form I-539</a> offline if you are including co-applicants.
          </AlertWindow>
        )
      }

    </>
  )
}
export default I539IsOnlyApplicantApplying;