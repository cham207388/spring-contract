import {
  Alert,
  AlertHeader,
  Typography,
  AlertDescription,
  Box,
} from "myuscis-material";
import { FileRejection } from "react-dropzone";

type AcceptedTypes = { [key: string]: string[] };

type props = {
  fileRejections: FileRejection[];
  showAlert: boolean;
  setShowAlert: (showAlert: boolean) => void;
  acceptedTypes: AcceptedTypes;
};

const FileErrorAlert = ({
  fileRejections,
  showAlert,
  setShowAlert,
  acceptedTypes,
}: props) => {
  const prettifyAcceptedTypes = (acceptedTypes: AcceptedTypes): string => {
    const flattenedTypes = Object.values(acceptedTypes).flat();
    if (flattenedTypes.length > 1) {
      flattenedTypes[flattenedTypes.length - 1] =
        "or " + flattenedTypes[flattenedTypes.length - 1];
    }
    return flattenedTypes.join(", ");
  };

  const errorMessages: { [name: string]: string } = {
    "file-too-large":
      "Please make sure your file meets the provided size requirements.",
    "file-invalid-type": `Please make sure your file is in an accepted format: ${prettifyAcceptedTypes(acceptedTypes)}`,
  };

  return (
    <Box mt={4} role="alert" aria-live="assertive">
      {fileRejections.length > 0 && showAlert && (
        <Alert
          variant={"error"}
          onDismiss={() => {
            setShowAlert(false);
          }}
          maxWidthOverride="100%"
        >
          <AlertHeader>
            <Typography variant="h4">
              Your file could not be uploaded
            </Typography>
          </AlertHeader>
          <AlertDescription>
            <Typography variant="body1">
              {!!fileRejections[0]?.errors[0]?.message &&
                fileRejections[0].errors[0].message.includes(
                  "Your file name must only contain, English letters, numbers, certain special characters",
                ) && (
                  <Typography style={{ margin: "12px 0" }}>
                    Your file has an invalid name.
                  </Typography>
                )}
              {errorMessages[fileRejections[0].errors[0].code] ??
                fileRejections[0].errors[0].message}
            </Typography>
            {
              <Typography style={{ marginTop: "10px" }} variant="subtitle1">
                File{fileRejections.length > 1 ? "(s)" : null} affected:
              </Typography>
            }
            {fileRejections.map((file, index) => (
              <Typography key={file.file.name} variant="subtitle1">
                - {file.file.name.substring(0, 55)}
                {file.file.name.length > 55 ? "..." : null}
              </Typography>
            ))}
          </AlertDescription>
        </Alert>
      )}
    </Box>
  );
};

export default FileErrorAlert;
