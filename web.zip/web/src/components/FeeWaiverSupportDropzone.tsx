import { faTrashCan } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Button, MaterialTable } from "myuscis-material";
import { useCallback, useMemo, useRef, useState } from "react";
import { FileRejection, useDropzone } from "react-dropzone";
import { useDispatch, useSelector } from "react-redux";
import { JSX } from "react/jsx-runtime";
import { SubmissionService } from "../api/SubmissionService";
import { useUploadEvidence } from "../hooks/documentUpload";
import { selectedEvidencesForGroup } from "../redux/evidenceSlice";
import { RootState } from "../redux/store";
import {
  SubmissionState,
  addEvidenceUpload,
  deleteEvidence,
} from "../redux/submissionSlice";
import { Evidence, EvidenceFile } from "../redux/types/Submission";
import { DropzoneProps } from "../types/Dropzone";
import { FileObject } from "../types/File";
import { EvidenceUploadResponse, UploadRequest } from "../types/Upload";
import { getDateFromNanoSeconds } from "../utils/dates";
import { fileNameValidator } from "../utils/fileNameValidator";
import { formatFileName } from "../utils/formatFileName";
import { DeleteDialogConfirmation } from "./Dialogs/DeleteConfirmationDialog";
import FeeWaiverSupportDialog from "./Dialogs/FeeWaiverSupportDialog";
import { deleteEvidenceValidation } from "../redux/validationsSlice";

const baseStyle = {
  flex: 1,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "20px",
  borderWidth: 2,
  borderRadius: 2,
  borderColor: "#eeeeee",
  borderStyle: "dashed",
  backgroundColor: "#fafafa",
  color: "#666666",
  outline: "none",
  transition: "border .24s ease-in-out",
};

const focusedStyle = {
  borderColor: "#2196f3",
};

const acceptStyle = {
  borderColor: "#00e676",
};

const rejectStyle = {
  borderColor: "#ff1744",
};

const linkText = {
  color: "#006699",
  textDecoration: "underline",
  cursor: "pointer",
};

const dropzoneMargin = {
  margin: "1em",
};

type Props = {
  setShowAlert: (showAlert: boolean) => void;
  setFileRejections: (fileRejections: FileRejection[]) => void;
  deleteWarningText: string;
  evidenceGroupType: string;
  dropzoneProps: DropzoneProps;
  setShowEvidenceWarning: (showEvidenceWarning: boolean) => void;
};

const FeeWaiverSupportDropzone = ({
  deleteWarningText,
  evidenceGroupType,
  setFileRejections,
  setShowAlert,
  dropzoneProps,
  setShowEvidenceWarning,
}: Props) => {
  const { uploadEvidence } = useUploadEvidence();

  const [files, setFiles] = useState<FileObject[]>([]);
  const [fileToBeDeleted, setFileToBeDeleted] = useState<EvidenceFile>();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const { submissionId, formType }: SubmissionState = useSelector(
    (state: RootState) => state.submission,
  );
  const { partialRequested: partialFeeWaiverRequested } = useSelector(
    (state: RootState) => state.submission.feeWaiver,
  );

  const { myUscisId, userGroupId } = useSelector((state: RootState) => state.user);

  const evidences: Evidence[] = useSelector((state: RootState) =>
    selectedEvidencesForGroup(state, evidenceGroupType),
  );

  const dispatch = useDispatch();
  const { maxFiles } = dropzoneProps;

  const onDrop = useCallback(
    async (acceptedFiles: any[], fileRejections: FileRejection[]) => {
      const projectedNumberOfFiles = files.length + 1;
      if (projectedNumberOfFiles > maxFiles) return;

      setFiles((prevFiles) => [...prevFiles, ...acceptedFiles]);

      if (fileRejections.length > 0) {
        setFileRejections(fileRejections);
        setShowAlert(true);
      }

      if (acceptedFiles.length > 0) {
        setLoading(true);

        const formData = new FormData();
        const evidenceRequest = acceptedFiles.map((f) => {
          return {
            fileName: f.name,
            type: "Other",
            evidenceGroupType,
          };
        });
        acceptedFiles.forEach((f) => {
          formData.append("files", f);
        });
        evidenceRequest.forEach((e) => {
          formData.append(
            "uploadEvidenceRequests",
            new Blob([JSON.stringify(e)], {
              type: "application/json",
            }),
          );
        });

        const uploadRequest: UploadRequest = {
          formData,
          myUscisId,
          submissionId,
          selectedFormType: formType
        };

        uploadEvidence(uploadRequest, userGroupId)
          .then((response: EvidenceUploadResponse[]) => {
            setTimeout(() => {
              setLoading(false);
            }, 2000);
            dispatch(
              addEvidenceUpload({
                request: evidenceRequest,
                evidenceGroup: evidenceGroupType,
                response,
              }),
            );

            setLoading(false);
            setShowEvidenceWarning(false);
          })
          .catch((error: any) => {
            setFiles((prevFiles) =>
              removeFile(
                prevFiles,
                acceptedFiles.map((f) => f.name),
              ),
            );
            setLoading(false);
            return;
          });
      }
    },
    [
      files.length,
      maxFiles,
      setLoading,
      myUscisId,
      userGroupId,
      evidenceGroupType,
      submissionId,
      uploadEvidence,
      setFileRejections,
      setShowAlert,
      dispatch,
      setShowEvidenceWarning,
    ],
  );

  const removeFile = (
    prevFiles: Array<FileObject>,
    filesToRemove: string[],
  ) => {
    return prevFiles.filter((prevFile) =>
      filesToRemove.includes(prevFile.name),
    );
  };

  const { getRootProps, getInputProps, isFocused, isDragAccept, isDragReject } =
    useDropzone({
      onDrop,
      validator: fileNameValidator,
      ...dropzoneProps,
    });

  const handleDeleteFile = async () => {
    if (!fileToBeDeleted) return;
    const updatedFiles = files.filter(
      (file) => file.name !== fileToBeDeleted.fileName,
    );

    const { id } = fileToBeDeleted!;

    try {
      await SubmissionService.deleteUploadedEvidence(
        myUscisId,
        submissionId,
        id,
        userGroupId,
      );
      setFiles(updatedFiles);
      dispatch(deleteEvidenceValidation(id));
      dispatch(deleteEvidence(id));
    } catch (error) {
      console.error(`Delete file ${fileToBeDeleted.fileName} failed: `, error);
    }

    setIsDeleteDialogOpen(false);
  };

  const onOpenDeleteDialog = (clickedFile: EvidenceFile) => {
    setIsDeleteDialogOpen(true);
    setFileToBeDeleted(clickedFile);
  };

  const style = useMemo(
    () => ({
      ...baseStyle,
      ...(isFocused ? focusedStyle : {}),
      ...(isDragAccept ? acceptStyle : {}),
      ...(isDragReject ? rejectStyle : {}),
    }),
    [isFocused, isDragAccept, isDragReject],
  );

  let tableContents: ((JSX.Element | null)[] | null)[] = [];
  if (evidences.length) {
    evidences.forEach(
      (evidence, index) =>
        (tableContents = evidence.files.map((evidenceFile) =>
          evidenceFile !== undefined
            ? [
                <td key={`r${index}c0`}>
                  {formatFileName(evidenceFile.fileName)}
                </td>,
                <td key={`r${index}c1`}>
                  {partialFeeWaiverRequested ? "Other" : "Fee Waiver Support"}
                </td>,
                <td key={`r${index}c2`}>
                  {getDateFromNanoSeconds(evidenceFile.dateTime)}
                </td>,
                <td key={`r${index}c3`}>
                  <Button
                    variant="text"
                    startIcon={
                      <FontAwesomeIcon
                        style={{ fontSize: "16px", color: "#08588F" }}
                        icon={faTrashCan}
                      />
                    }
                    role="button"
                    aria-label="Delete file"
                    style={linkText}
                    onClick={() => onOpenDeleteDialog(evidenceFile)}
                  >
                    Delete
                  </Button>
                </td>,
              ]
            : null,
        )),
    );
  }

  const headerContents = [
    <th key="header-row-c0">File name</th>,
    <th key="header-row-c1">Document</th>,
    <th key="header-row-c2">Date</th>,
    <th key="header-row-c3">Action</th>,
  ];

  const feeWaiverSupportUploadContainerRef = useRef<HTMLDivElement>(null);

  return (
    <div
      className="container"
      style={{ display: "flex", flexDirection: "column", gap: "32px" }}
      tabIndex={-1}
      ref={feeWaiverSupportUploadContainerRef}
    >
      {evidences[0]?.files.length !== maxFiles && (
        <div {...getRootProps({ style })}>
          <input {...getInputProps()} />
          <p style={dropzoneMargin}>
            <span style={linkText}>Choose</span> or drop file here to upload
          </p>
        </div>
      )}

      {!!evidences[0]?.files.length && (
        <MaterialTable
          headerContents={[headerContents]}
          tableContents={[...tableContents]}
        />
      )}

      <DeleteDialogConfirmation
        isDialogOpen={isDeleteDialogOpen}
        handleDialogClose={() => setIsDeleteDialogOpen(false)}
        handleDelete={() => handleDeleteFile()}
        deleteWarningText={deleteWarningText}
        focusReturnFallbackElementRef={feeWaiverSupportUploadContainerRef}
      />
      <FeeWaiverSupportDialog loading={loading} />
    </div>
  );
};

export default FeeWaiverSupportDropzone;
