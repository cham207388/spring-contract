import {
  ReactElement,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
} from "react";

import { faTrashCan } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Box, Grid, SelectChangeEvent, SelectProps } from "@mui/material";
import {
  Alert,
  AlertActions,
  AlertDescription,
  AlertHeader,
  Button,
  Dropdown,
  DropdownProps,
  MaterialTable,
} from "myuscis-material";
import { FileRejection, useDropzone } from "react-dropzone";
import { useDispatch, useSelector } from "react-redux";
import { makeStyles } from "tss-react/mui";
import { SubmissionService } from "../api/SubmissionService";
import { DocumentUploadContext } from "../contexts/DocumentUploadContext";
import { useHydrateDraft } from "../hooks/useHydrateDraft";
import { RootState } from "../redux/store";
import { updateFeeWaiverFiles } from "../redux/submissionSlice";

import {
  resetFeeWaiverValidation,
  setFeeWaiverValidation,
  setIsPollingForFeeWaiverValidation,
} from "../redux/validationsSlice";

import { FeeWaiverFile, FeeWaiverFileType } from "../redux/types/Submission";
import { FileExtension, possibleFileTypes } from "../types/Dropzone";
import { FileObject } from "../types/File";
import { FeeWaiverRequest, UploadRequest } from "../types/Upload";
import { getDateFromNanoSeconds } from "../utils/dates";
import { fileNameValidator } from "../utils/fileNameValidator";
import { formatFileName } from "../utils/formatFileName";
import { DeleteDialogConfirmation } from "./Dialogs/DeleteConfirmationDialog";
import { Submission } from "../types/Submission";
import { ValidationResults } from "../types/Validations";
import * as FileUtils from "../utils/FileUtils";
import { useAlertSnackbar } from "../hooks/useAlertSnackbar";

const baseStyle = {
  flex: 1,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "20px",
  borderWidth: 2,
  borderRadius: 2,
  borderColor: "#eeeeee",
  borderStyle: "dashed",
  backgroundColor: "#fafafa",
  color: "#666666",
  outline: "none",
  transition: "border .24s ease-in-out",
  marginBottom: "32px",
};

const focusedStyle = {
  borderColor: "#2196f3",
};

const acceptStyle = {
  borderColor: "#00e676",
};

const rejectStyle = {
  borderColor: "#ff1744",
};

const linkText = {
  color: "#006699",
  textDecoration: "underline",
  cursor: "pointer",
};

const useStyles = makeStyles()({
  dropdown: {
    width: "10rem",
    "& .MuiSelect-select span::before": {
      content: "'Select Type *'", // string contains single quotes
      color: "#ff0000",
    },
    "& .MuiInput-input": {
      fontSize: "16px",
      display: "flex",
      alignItems: "center",
    },
    "& .MuiMenuItem-root": {
      fontSize: "16px",
    },
  },
});

type Props = {
  setShowAlert: (showAlert: boolean) => void;
  setFileRejections: (fileRejections: FileRejection[]) => void;
};

const FeeWaiverDropzone = ({ setFileRejections, setShowAlert }: Props) => {
  const { setLoading } = useContext(DocumentUploadContext);
  const { hydrateDraft } = useHydrateDraft();
  const isReuploading = useRef(false);
  const { addAlert } = useAlertSnackbar();

  const [files, setFiles] = useState<FileObject[]>([]);
  const [fileToBeDeleted, setFileToBeDeleted] = useState<FeeWaiverFile>();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const uploadedFiles = useSelector(
    (state: RootState) => state.submission.feeWaiver.files,
  );
  const { submissionId } = useSelector((state: RootState) => state.submission);
  const { i912FeeWaiverValidation, isPollingForFeeWaiverValidation } =
    useSelector((state: RootState) => state.validations);

  const isI912Form = i912FeeWaiverValidation?.warnings?.IS_I912_FORM === "true";

  const feeWaiverHasError =
    i912FeeWaiverValidation?.result === ValidationResults.FAIL;

  const myUscisId = useSelector((state: RootState) => state.user.myUscisId);
  const userGroupId = useSelector((state: RootState) => state.user.userGroupId);
  const dispatch = useDispatch();

  const reset912Validation = useCallback(() => {
    if (feeWaiverHasError) dispatch(resetFeeWaiverValidation());
  }, [feeWaiverHasError, dispatch]);

  const onDrop = useCallback(
    async (acceptedFiles: any, fileRejections: FileRejection[]) => {
      if (files.length > 0) reset912Validation();
      setFiles((prevFiles) => [...prevFiles, ...acceptedFiles]);
      const file = acceptedFiles[0];

      if (!file) {
        setFileRejections(fileRejections);
        setShowAlert(true);
        return;
      }

      setLoading(true);
      const feeWaiverRequest: FeeWaiverRequest = {
        fileName: file.name,
      };

      const formData = new FormData();
      formData.append("file", file);
      formData.append(
        "uploadFeeWaiverRequest",
        new Blob([JSON.stringify(feeWaiverRequest)], {
          type: "application/json",
        }),
      );

      const uploadRequest: UploadRequest = {
        formData,
        myUscisId,
        submissionId,
      };

      try {
        const response = await SubmissionService.uploadFeeWaiver(uploadRequest, userGroupId);
        await hydrateDraft(response.submission);

        setTimeout(() => {
          setLoading(false);
        }, 2000);
      } catch (error: any) {
        setLoading(false);
             let UPLOADING_ERROR_MESSAGE = "Error uploading document: ";

            if (error.status === 400 && error.response) {
              UPLOADING_ERROR_MESSAGE += error.response.data['uploadFeeWaiver.file'];
            }
         addAlert(UPLOADING_ERROR_MESSAGE);

        return;
      }
    },
    [
      setLoading,
      hydrateDraft,
      submissionId,
      setFileRejections,
      setShowAlert,
      myUscisId,
      userGroupId,
      files.length,
      reset912Validation,
      dispatch,
    ],
  );

  const fileLimit = { maxFiles: 1 };
  const {
    getRootProps,
    getInputProps,
    isFocused,
    isDragAccept,
    isDragReject,
    open,
  } = useDropzone({
    onDrop,
    maxSize: 12000000,
    ...fileLimit,
    validator: fileNameValidator,
    accept: {
      "image/jpeg": possibleFileTypes.jpegTiff,
      "application/pdf": possibleFileTypes.pdf,
    },
  });

  const handleDeleteFile = async () => {
    if (!fileToBeDeleted) return;
    const updatedFiles = files.filter(
      (file) => file.name !== fileToBeDeleted.fileName,
    );
    const { id } = fileToBeDeleted;

    try {
      const response: Submission =
        await SubmissionService.deleteUploadedFeeWaiver(
          myUscisId,
          submissionId,
          id,
          userGroupId
        );
      if (!updatedFiles.length) setFiles(updatedFiles);
      dispatch(
        updateFeeWaiverFiles(
          uploadedFiles.filter((file: FeeWaiverFile) => file.id !== id),
        ),
      );

      await hydrateDraft(response);
    } catch (error) {
      // no op
    }
    dispatch(setFeeWaiverValidation(undefined));
    dispatch(setIsPollingForFeeWaiverValidation(false));
    setIsDeleteDialogOpen(false);
  };

  const onOpenDeleteDialog = (clickedFile: FeeWaiverFile) => {
    setIsDeleteDialogOpen(true);
    setFileToBeDeleted(clickedFile);
  };

  async function updateFeeWaiverEvidence(feeWaiverId: string, type: string) {
    try {
      const res = await SubmissionService.updateFeeWaiverEvidence(
        myUscisId,
        submissionId,
        feeWaiverId,
        {
          type,
        },
        userGroupId,
      );
      return hydrateDraft(res.submission);
    } catch (error) {
      console.error(error);
    }
  }

  function handleChangeDocumentType(feeWaiverId: string) {
    return async (event: SelectChangeEvent<string>) => {
      await updateFeeWaiverEvidence(feeWaiverId, event.target.value);
    };
  }

  const renderStatusColumn = () => {
    let color;
    let text;
    const setFeeWaiverStatus = () => {
      if (isPollingForFeeWaiverValidation) {
        color = "#444444";
        text = "Pending";
        return;
      }
      if (!i912FeeWaiverValidation) {
        color = "#006600";
        text = "...";
        return;
      }
      if (feeWaiverHasError) {
        color = "#CC3333";
        text = "Error";
        return;
      }
      color = "#006600";
      text = "Complete";
    };
    setFeeWaiverStatus();

    return (
      <td
        key={`rc2`}
        style={{
          color,
        }}
      >
        {text}
      </td>
    );
  };

  const filesJsx: ReactElement[] =
    uploadedFiles.length > 0
      ? uploadedFiles.map((file, index) => {
          const isNotPDFDocument = !FileUtils.fileHasExtension(
            file.fileName,
            FileExtension.PDF,
          );
          const documentTypeSelected = isNotPDFDocument
            ? FeeWaiverFileType.FEE_DECLARATION
            : isI912Form
              ? FeeWaiverFileType.I_912
              : file.documentType ?? "";
          return (
            <>
              <td key={`r${index}c0`}>{formatFileName(file.fileName)}</td>
              <td key={`r${index}c1`}>
                <DocumentTypeSelector
                  disabled={isNotPDFDocument || isI912Form || !file.isEditable}
                  value={documentTypeSelected}
                  onChange={handleChangeDocumentType(file.id)}
                />
              </td>
              {renderStatusColumn()}
              <td key={`r${index}c3`}>
                {getDateFromNanoSeconds(file.dateTime)}
              </td>
              <td key={`r${index}c4`}>
                <Button
                  variant="text"
                  startIcon={
                    <FontAwesomeIcon
                      style={{ fontSize: "16px", color: "#08588F" }}
                      icon={faTrashCan}
                    />
                  }
                  role="button"
                  aria-label="Delete file"
                  style={linkText}
                  onClick={() => onOpenDeleteDialog(file)}
                >
                  Delete
                </Button>
              </td>
            </>
          );
        })
      : [];

  const style = useMemo(
    () => ({
      ...baseStyle,
      ...(isFocused ? focusedStyle : {}),
      ...(isDragAccept ? acceptStyle : {}),
      ...(isDragReject ? rejectStyle : {}),
    }),
    [isFocused, isDragAccept, isDragReject],
  );

  const feeWaiverUploadContainerRef = useRef<HTMLDivElement>(null);

  return (
    <div
      className="container"
      tabIndex={-1}
      ref={feeWaiverUploadContainerRef}
    >
      {uploadedFiles.length !== fileLimit.maxFiles && (
        <div {...getRootProps({ style, role: "button" })}>
          <input {...getInputProps()} />
          <p>
            <span style={linkText}>Choose</span> or drop file here to upload a
            I-912 form
          </p>
        </div>
      )}
      {uploadedFiles.length > 0 && (
        <MaterialTable
          headerContents={[
            <th key="header-row-c0">File name</th>,
            <th key="header-row-c1">Document</th>,
            <th key="header-row-c2">Status</th>,
            <th key="header-row-c3">Date</th>,
            <th key="header-row-c4">Action</th>,
          ]}
          tableContents={filesJsx}
        />
      )}
      {feeWaiverHasError && (
        <Box
          role="alert"
          aria-live="assertive"
          mt="32px"
          mx="0 auto"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Alert variant="error" maxWidth focus>
            <AlertHeader>Error with uploaded form</AlertHeader>
            <AlertDescription>
              We found the following errors with the uploaded form.
              <br />
              <br />
              {i912FeeWaiverValidation.reasons.map((reason) => (
                <span
                  key={reason}
                  style={{ display: "block", margin: "12px 0" }}
                >
                  {reason}
                </span>
              ))}
            </AlertDescription>
            <AlertActions>
              <Grid item mt="16px">
                <Button
                  variant="contained"
                  onClick={() => {
                    setFileToBeDeleted(uploadedFiles[0]);
                    handleDeleteFile();
                    isReuploading.current = true;
                    open();
                  }}
                >
                  Re-Upload PDF
                </Button>
              </Grid>
            </AlertActions>
          </Alert>
        </Box>
      )}

      {
        <DeleteDialogConfirmation
          isDialogOpen={isDeleteDialogOpen}
          handleDialogClose={() => setIsDeleteDialogOpen(false)}
          handleDelete={handleDeleteFile}
          deleteWarningText=""
          focusReturnFallbackElementRef={feeWaiverUploadContainerRef}
        />
      }
    </div>
  );
};

type DocumentTypeProps = SelectProps<string>;

function DocumentTypeSelector(props: DocumentTypeProps) {
  const { classes } = useStyles();
  const options: DropdownProps["options"] = [
    { label: FeeWaiverFileType.I_912, value: FeeWaiverFileType.I_912 },
    {
      label: FeeWaiverFileType.FEE_DECLARATION,
      value: FeeWaiverFileType.FEE_DECLARATION,
    },
  ];

  return (
    <Dropdown
      options={options}
      autoWidth={true}
      reduceLeftPadding
      className={classes.dropdown}
      {...(props as SelectProps<unknown>)}
      required
      error={!props.value}
    />
  );
}

export default FeeWaiverDropzone;
