import { Button } from "myuscis-material";
import { makeStyles } from "tss-react/mui";
import { useNavigate } from "react-router-dom";
import { Step, useSteps } from "../hooks/useSteps";
import { useMediaQuery, useTheme } from "@mui/material";

export type NavigationHandler = () => Promise<void> | (() => void) | void;
type NextChain = () => void;
type HandleNextFunction = (next: NextChain) => void;

interface Props {
  onNext?: HandleNextFunction;
  onPrevious?: NavigationHandler;
  customNext?: NavigationHandler;
  nextLabel?: string;
  customPrevious?: NavigationHandler;
  disableNext?: boolean;
  disablePrevious?: boolean;
  showBackButton?: boolean;
}

const useStyles = makeStyles()((theme) => ({
  buttonsSection: {
    display: "flex",
    justifyContent: "space-between",
    gap: "16px",
  },
  buttonSection: {
    display: "flex",
    justifyContent: "end",
  },
  button: {
    width: "auto",
    overflowWrap: "break-word",
    whiteSpace: "normal",
  },
}));

const NavigationButtons = ({
  onNext = (next) => next(),
  onPrevious = () => {},
  customNext,
  nextLabel = "Next",
  customPrevious,
  disableNext = false,
  disablePrevious = false,
  showBackButton = true,
}: Props) => {
  const navigate = useNavigate();

  const { classes } = useStyles();

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"), {
    defaultMatches: true,
  });

  const { currentStep, steps } = useSteps();

  const currentIndex = steps.findIndex(
    (step: Step) => step.id === currentStep.id,
  );

  const next = () => {
    window.scrollTo(0, 0);
    if (currentIndex + 1 < steps.length) {
      navigate("../" + steps[currentIndex + 1].id);
    }
  };

  const handleNext = () => {
    if (customNext) {
      customNext();
    } else {
      onNext(next);
    }
  };

  const handlePrevious = () => {
    if (customPrevious) {
      customPrevious();
    } else {
      window.scrollTo(0, 0);
      if (currentIndex - 1 >= 0) {
        navigate("../" + steps[currentIndex - 1].id);
      }
      onPrevious();
    }
  };

  return (
    <div
      className={
        showBackButton ? classes.buttonsSection : classes.buttonSection
      }
    >
      {showBackButton && (
        <Button
          data-testid="back-btn"
          variant="outlined"
          onClick={handlePrevious}
          disabled={disablePrevious}
          className={isMobile ? classes.button : ``}
        >
          Back
        </Button>
      )}
      <Button
        data-testid="next-btn"
        variant="contained"
        onClick={handleNext}
        disabled={disableNext}
        className={classes.button}
      >
        {nextLabel}
      </Button>
    </div>
  );
};

export default NavigationButtons;
