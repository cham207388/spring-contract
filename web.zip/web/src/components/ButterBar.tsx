import { faInfoCircle } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Typography } from "@mui/material";
import { makeStyles } from "tss-react/mui";

const useStyles = makeStyles()((_theme) => ({
  container: {
    backgroundColor: _theme.palette.background.default,
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
}));

const ButterBar = ({ formType }: { formType: string }) => {
  const { classes } = useStyles();

  const message = (
    <>
      <b>PDF Intake BETA Preview!</b> PDF Intake is currently in beta mode.
      Limited functionality and periodic timeouts may be experienced. You may
      still submit your <b>Form {formType}</b> during this time.
    </>
  );
  return (
    <div className={classes.container}>
      <FontAwesomeIcon
        icon={faInfoCircle}
        size="2x"
        color="#006699"
        style={{ marginRight: 10 }}
      />
      <Typography variant="h4" style={{ padding: "1rem 0" }}>
        {message}
      </Typography>
    </div>
  );
};

export default ButterBar;
