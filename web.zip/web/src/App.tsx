import { RouterProvider } from "react-router-dom";
import Providers from "./components/Providers";
import { router } from "./router/routes";
import { useEffect } from "react";

function App() {
  useEffect(() => {
    if(location.hostname === ("my.uscis.gov")){
      addGTMSnippets();
      addQualtricsSnippets();
    }}, [location.hostname]);

  return (
    <Providers>
      <RouterProvider router={router} />
    </Providers>
  );
}

function addGTMSnippets() {
  let gtmScript = document.createElement("script");
  gtmScript.innerHTML = "(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':\
      new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],\
      j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=\
      'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);\
      })(window,document,'script','dataLayer','GTM-W4ZXKMQ');";
  let gtmNoscript = document.createElement("noscript");
  let iframe = document.createElement("iframe");
  iframe.src = "https://www.googletagmanager.com/ns.html?id=GTM-5H8HDQ3";
  iframe.height = "0";
  iframe.width = "0";
  iframe.setAttribute("style", "display: none; visibility: hidden");
  gtmNoscript.appendChild(iframe);

  document.head.append(
    document.createComment(" Google Tag Manager "),
    gtmScript,
    document.createComment(" End Google Tag Manager ")
  );
  document.body.append(
    document.createComment(" Google Tag Manager (noscript) "),
    gtmNoscript,
    document.createComment(" End Google Tag Manager (noscript) "),
  );
}

function addQualtricsSnippets() {
  let qualtricsScript = document.createElement("script");
  qualtricsScript.innerHTML = '(function(){var g=function(e,h,f,g){\
      this.get=function(a){for(var a=a+"=",c=document.cookie.split(";"),b=0,e=c.length;b<e;b++){for(var d=c[b];" "==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return null};\
      this.set=function(a,c){var b="",b=new Date;b.setTime(b.getTime()+6048E5);b="; expires="+b.toGMTString();document.cookie=a+"="+c+b+"; path=/; "};\
      this.check=function(){var a=this.get(f);if(a)a=a.split(":");else if(100!=e)"v"==h&&(e=Math.random()>=e/100?0:100),a=[h,e,0],this.set(f,a.join(":"));else return!0;var c=a[1];if(100==c)return!0;switch(a[0]){case "v":return!1;case "r":return c=a[2]%Math.floor(100/c),a[2]++,this.set(f,a.join(":")),!c}return!0};\
      this.go=function(){if(this.check()){var a=document.createElement("script");a.type="text/javascript";a.src=g+ "&t=" + (new Date()).getTime();document.body&&document.body.appendChild(a)}};\
      this.start=function(){var a=this;window.addEventListener?window.addEventListener("load",function(){a.go()},!1):window.attachEvent&&window.attachEvent("onload",function(){a.go()})}};\
      try{(new g(100,"r","QSI_S_ZN_37xWsbwLQWWzZFr","https://zn37xwsbwlqwwzzfr-uscisomnichannel.gov1.siteintercept.qualtrics.com/SIE/?Q_ZID=ZN_37xWsbwLQWWzZFr")).start()}catch(i){}})();'
  let qualtricsDiv = document.createElement("div");
  qualtricsDiv.id = "ZN_37xWsbwLQWWzZFr";
  qualtricsDiv.appendChild(document.createComment("DO NOT REMOVE-CONTENTS PLACED HERE"));

  document.body.append(
    document.createComment("BEGIN QUALTRICS WEBSITE FEEDBACK SNIPPET"),
    qualtricsScript,
    qualtricsDiv,
    document.createComment("END WEBSITE FEEDBACK SNIPPET")
  );
}

export default App;
