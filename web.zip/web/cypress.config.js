import { defineConfig } from "cypress";

// https://github.com/bahmutov/cypress-split
import cypressSplit from 'cypress-split';
import { TOTP as totplib } from 'totp-generator';
import { DynamoDBClient, DeleteItemCommand } from "@aws-sdk/client-dynamodb";
import { NodeHttpHandler } from "@smithy/node-http-handler";
var envName = process.env.environment || 'https://dev-my.uscis.dhs.gov';
var pdfAdminKey = process.env.pdfiAdminKey || `api-key`;
var pdfiAdminUrl = process.env.pdfiAdminUrl || `https://dev-my.uscis.dhs.gov`;
import https from "https";

let agent = new https.Agent({
  maxSockets: 25,
  keepAlive: false
});

let dynamodbClient = new DynamoDBClient({
  requestHandler: new NodeHttpHandler({
    requestTimeout: 3_000,
    httpsAgent: agent
  }),
  region: 'us-east-1'
});

export default defineConfig({
  defaultCommandTimeout: 6000,
  pageLoadTimeout: 15000,
  requestTimeout: 10000,
  responseTimeout: 10000,
  execTimeout: 10000,
  projectId: "4b7344",
  video: true,
  videoCompression: 32,
  e2e: {
    setupNodeEvents(on, config) {
      cypressSplit(on, config)
      // implement node event listeners here
      on("task", {
        log(message) {
          console.log(message);

          return null;
        },
        table(message) {
          console.table(message);

          return null;
        },
        generateTOTP(secret) {
          //require("totp-generator");
          return totplib.generate(secret);
        },
       async deleteSubmission({tablePrefix, submissionId}) {
          const input = {
            Key: {
              submissionId: {
                S: submissionId
              }
            },
            TableName: `${tablePrefix}-Submission`
          };
          const command = new DeleteItemCommand(input);
          return await dynamodbClient.send(command);
        },
      });
      // IMPORTANT: return the config object
      return config
    },
    baseUrl: `${envName}/pdf-intake/I-765`,
    pdfAdminKey: pdfAdminKey,
    pdfiAdminUrl: pdfiAdminUrl,
    environment: envName,
    supportFile: "cypress/support/index.js",
    fixturesFolder: false,
    retries: 3,
    experimentalRunAllSpecs: true,
    waitForAnimations: false,
    viewportWidth: 1280,
    viewportHeight: 880,
  },
  reporterEnabled: "spec, mocha-junit-reporter, mochawesome",
  mochaJunitReporterReporterOptions: {
    mochaFile: "cypress/results/results-[hash].xml",
  },
  reporter: "mochawesome",
  reporterOptions: {
    reportDir: "cypress/results",
    overwrite: false,
    html: false,
    json: true,
  },
  blockHosts: ["*.google-analytics.com", "*.github.com", 'js-agent.newrelic.com',],
});
