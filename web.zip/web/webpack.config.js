module.exports = {
 infrastructureLogging: {    appendOnly: true,    level: 'verbose',}, 
};