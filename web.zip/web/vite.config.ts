/// <reference types="vitest" />

import { defineConfig } from "vite";
import { configDefaults, coverageConfigDefaults } from "vitest/config";
import react from "@vitejs/plugin-react";
import viteTsconfigPaths from "vite-tsconfig-paths";
import { nodePolyfills } from "vite-plugin-node-polyfills";
import browserslistToEsbuild from "browserslist-to-esbuild";

export default defineConfig({
  base: "/pdf-intake",
  build: {
    outDir: "build",
    emptyOutDir: true,
    target: browserslistToEsbuild([">0.2%", "not dead", "not op_mini all"]),
    sourcemap: true
  },
  resolve: {
    alias: {
      "myuscis-material": "myuscis-material/dist/myuscis-material.es.js",
    },
  },
  plugins: [
    react({
      jsxImportSource: "@emotion/react",
      babel: {
        plugins: ["@emotion/babel-plugin"],
      },
    }),
    viteTsconfigPaths(),
    nodePolyfills(),
  ],
  server: {
    // this ensures that the browser opens upon server start
    open: '/pdf-intake/I-765',
    // this sets a default port to 3000
    port: 3000,
    proxy: {
      "/pdf-intake/api/": {
        // proxy api requests
        target: "http://localhost:8383",
        changeOrigin: true,
        secure: false,
      },
    },
  },
  test: {
    exclude: [...configDefaults.exclude],
    globals: true,
    environment: "happy-dom",
    setupFiles: ["./src/setupTests.ts"],
    coverage: {
      provider: "istanbul",
      reporter: ["text", "lcov"],
      exclude: ["build/**", ...coverageConfigDefaults.exclude],
    },
  },
});
